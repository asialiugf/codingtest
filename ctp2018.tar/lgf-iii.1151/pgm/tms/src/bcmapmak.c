/*
 *&N& File : bcmapmak.c
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&                 main()               ����TMS�ѷӪ��w�q��
 */

/* ------------------------- INCLUDE FILES ---------------------------- */
#include <stdio.h>
#include <errno.h>
#include "errlog.h"

/* ------------------------- CONSTANT DEFINITION  --------------------- */

#define  MAX_EXEC_PATH_LEN     80
#define  FILE_NAME_LEN         80
#define  MAX_APFUN_NUM          1
#define  APFUN_CNFG_ERR	       -4
#define  OPEN_FILE_ERR	       -5
#define  APFUN_FILE	 "bcdapfun.dat"
#define  TMS_APFUN_DEF	 "bcdapfun.def"
#define  TMS_APFUN_H	 "bcgapfun.h"
#define  APFUN_H_TMP_FILE   "apfun_h.tmp"
#define  APFUN_DEF_TMP_FILE "apfun_def.tmp"

static char caApName[20];     /* AP name    */

extern int  errno;

main(int iArgc,char *pcaArgv[])
{
  int i;
  int iRc;
  int iTblSize;
  int iChiPid;
  int iWaitCode;
  char caExePath[MAX_EXEC_PATH_LEN];    /* buf for keep exec path str */
  char caFlName[FILE_NAME_LEN];
  char caApDefFlName[FILE_NAME_LEN];
  char caSortedFile[FILE_NAME_LEN];
  char caApDefSortedFile[FILE_NAME_LEN];
  int  iStatus;
  int  iHadLoadNum;
  FILE *zApFun;
  FILE *zTmsDef;
  FILE *zTmsh;

   if(iArgc != 2) {
     printf("Usage:bcxapmak.x buss_name\n");
     exit(-1);
   }

   memset(caSortedFile,'\0',FILE_NAME_LEN);
   sprintf(caSortedFile,"%s/iii/etc/bsl/%s/%s",(char *) getenv("III_DIR"),
           pcaArgv[1],TMS_APFUN_H);

   memset(caApDefSortedFile,'\0',FILE_NAME_LEN);
   sprintf(caApDefSortedFile,"%s/iii/etc/bsl/%s/%s",
          (char *) getenv("III_DIR"),pcaArgv[1],TMS_APFUN_DEF);

     /* -------------------- */
     /* get open file name   */
     /* -------------------- */
   memset(caFlName,'\0',FILE_NAME_LEN);
   sprintf(caFlName,"%s/iii/etc/bsl/%s/%s",(char *) getenv("III_DIR"),
           pcaArgv[1], APFUN_FILE);

  /* open tmdapfun.dat file name */
  if((zApFun=fopen(caFlName,"r")) == NULL){
    printf("bcxapmak.x:open file=%s error, errno=%d\n",caFlName,errno);
    exit(OPEN_FILE_ERR);
  } 

   memset(caApDefFlName,'\0',FILE_NAME_LEN);
   sprintf(caApDefFlName,"%s/iii/etc/bsl/%s/%s", (char *) getenv("III_DIR"),
           pcaArgv[1], APFUN_DEF_TMP_FILE);

  if((zTmsDef=fopen(caApDefFlName,"w")) == NULL){
    printf("bcxapmak.x:open file=%s error, errno=%d\n",caApDefFlName,errno);
    exit(OPEN_FILE_ERR);
  } 

   memset(caFlName,'\0',FILE_NAME_LEN);
   sprintf(caFlName,"%s/iii/etc/bsl/%s/%s", (char *) getenv("III_DIR"),
           pcaArgv[1], APFUN_H_TMP_FILE);

  if((zTmsh=fopen(caFlName,"w")) == NULL){
    printf("tmmxapmak.x:open file=%s error, errno=%d\n",caFlName,errno);
    exit(OPEN_FILE_ERR);
  } 

   i=0;
   while((iRc=fscanf(zApFun,"%s\n", caApName)) != EOF){
     if(iRc < MAX_APFUN_NUM){
       printf("bcxapmak.x: fscanf input %d item < %d\n",iRc,MAX_APFUN_NUM);
       exit(APFUN_CNFG_ERR);
     }

    if ( strncmp(caApName,"NULL",4) !=0 ) {
      fprintf(zTmsDef,"\x22%s\x22, %s,\n", caApName, caApName);
      fprintf(zTmsh,"extern int %s();\n",caApName);
    }

   } /* FOR while((iRc=fscanf(....))  */
 
  fclose(zTmsh);
  fclose(zTmsDef);
  fclose(zApFun);
    
  SortTmsApH(caFlName,caSortedFile);
  SortTmsApDef(caApDefFlName,caApDefSortedFile);
  printf("Generate bcdapfun.def, bcgapfun.h OK!!\n");
  exit(0);
}


SortTmsApH(char *pcFileName,char *pcSortedFile)
{
  char caCmdBuf[250];
  sprintf(caCmdBuf,"sort +2 -3 -u < %s > %s",pcFileName,pcSortedFile);
  system(caCmdBuf);
}

SortTmsApDef(char *pcFileName,char *pcSortedFile)
{
  char caCmdBuf[250];
  sprintf(caCmdBuf,"sort -u < %s > %s",pcFileName,pcSortedFile);
  system(caCmdBuf);
}
