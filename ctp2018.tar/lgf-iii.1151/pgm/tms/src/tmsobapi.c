/*
 *&N& File : tmsobapi.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int       TPEONBH1()
 */

/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include "errlog.h"
#include "tms.h"

/* -------------------- CONSTANT DEFINE  --------------------------- */
#define P_TPEONBH1            29901
/* -------------------- GLOBAL DECLARATION ------------------ */
int g_iBrhCodeLen;
int g_iTmCodeLen ;

/*
 *&N& ROUNTINE NAME : TPEONBH1()
 *&A& ARGUMENTS: �L
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D&
 */
int
TPEONBH1(char *pcApa, struct OnBh1CtlSt *pstOnBh1Ctl,char *pcOnBh1Data)
{
  char   caTmpBuf[5];
  static s_cFirstCallFlag = 'y';
  int    iRc;

  UCP_TRACE(P_TPEONBH1);

  sprintf(g_caMsg,"TPEONBH1:enter dump pstOnBh1Ctl"); 
  ErrLog(100,g_caMsg,RPT_TO_LOG,pstOnBh1Ctl,sizeof(struct OnBh1CtlSt));
  memcpy(caTmpBuf,pstOnBh1Ctl->caDataLen,4);
  caTmpBuf[4] = '\0';
  sprintf(g_caMsg,"TPEONBH1:enter dump pcOnBh1Data"); 
  ErrLog(100,g_caMsg,RPT_TO_LOG,pcOnBh1Data,atoi(caTmpBuf));

  if ( s_cFirstCallFlag == 'y'){
    /* get config.dat */
    iRc = GetCwaKey();
    if(iRc < 0){
      pstOnBh1Ctl->cOnBh1RtnCode=TMS_ONBH1_SYS_ERR;
      memset(pstOnBh1Ctl->caErrCode, '0', 5);
      ErrLog(1000,"TPEONBH1:GetCwaKey fail!",RPT_TO_LOG,0,0);
      UCP_TRACE_END(-1);
    }
  
    /* get BIT of CWA pointer */
    iRc = AccessCwa(iRc);
    if(iRc != 0){
      pstOnBh1Ctl->cOnBh1RtnCode=TMS_ONBH1_SYS_ERR;
      memset(pstOnBh1Ctl->caErrCode, '0', 5);
      ErrLog(1000,"TPEONBH1:AccessCwa fail!",RPT_TO_LOG,0,0);
      UCP_TRACE_END(-1);
    }

    /* Get Terminal Code Len & Branch Code Len */
    iRc=GetBrTmCodeLen(&g_iBrhCodeLen,&g_iTmCodeLen);
    if (iRc == -1) {
      pstOnBh1Ctl->cOnBh1RtnCode=TMS_ONBH1_SYS_ERR;
      memset(pstOnBh1Ctl->caErrCode, '0', 5);
      sprintf(g_caMsg,"TPEONBH1:get Br Tm Code Len falil !");
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(-1);
    }

    s_cFirstCallFlag = 'n';

  } /* end of if ( s_cFirstCallFlag == 'y') */

  OnBatch1(pstOnBh1Ctl,pcOnBh1Data);

  sprintf(g_caMsg,"TPEONBH1:exit dump pstOnBh1Ctl"); 
  ErrLog(100,g_caMsg,RPT_TO_LOG,pstOnBh1Ctl,sizeof(struct OnBh1CtlSt));
  memcpy(caTmpBuf,pstOnBh1Ctl->caDataLen,4);
  caTmpBuf[4] = '\0';
  sprintf(g_caMsg,"TPEONBH1:exit dump pcOnBh1Data"); 
  ErrLog(100,g_caMsg,RPT_TO_LOG,pcOnBh1Data,atoi(caTmpBuf));

  UCP_TRACE_END(0);

}
