/*
 *&N& File : tmsatm.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int       StartRequest()
 *&N&    int       SendSifToServ()
 *&N&    int       RecSofFromServ()
 *&N&    int       EndRequest()
 *&N&    int       TpeCtSndSif()
 *&N&    int       TpeCtRcvSof()
 *&N&    int       RcvAllSof()
 *&N&    int       MemWrite()
 */

/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include        <errno.h>
#include "errlog.h"
#include "dcs.h"
#include "twa.h"
#include "ucp.h"

/* -------------------- CONSTANT DEFINE  --------------------------- */
#define P_StartRequest        90001
#define P_SendSifToServ       90002
#define P_RecSofFromServ      90003
#define P_EndRequest          90004
#define P_TpeCtSndSif         90005
#define P_TpeCtRcvSof         90006
#define P_RcvAllSof           90007
#define P_MemWrite            90008
#define P_LoadTpuMap          90009	
#define P_SrhTpuMapTbl        90010 

#define  DCS_SK_HEAD		8
#define  CTL_ON			1
#define  CTL_OFF		0
#define  LAST_MSG_MASK		0x80
#define  TPEO_MSG_MASK          0x02
#define  IS_AP_ABEND           	& 0x08
#define  PRINT_MSG_MASK		0x10

#define MAX_TPUMAP_LINES	70
/* -------------------- GLOBAL DECLARATION ------------------ */
struct DcsBuf  g_stDcsBuf;
struct DcsSiof g_stDcsSiof;
static char    sg_cSifComeFlag='n';
static int     sg_iCtlFlowFlag=CTL_ON; 
static char    sg_cProtoType='\0';
int            g_iCtSessId; 
static int     sg_iCurOffset=0;
/***************************************************************************/
char g_caMemBuf[MAX_MSGP_LEN * 2];
struct  MemBufCtlSt{
  int iMsgCnt;
  int iNextOffset;
};
struct  MemBufCtlSt g_stMemBufCtl;
/* -------------------- GLOBAL DECLARATION ------------------ */

char g_caDesCode[10];
static int gs_iMaxTpuMapLoad;
struct TpuMapSt {
  char caBussId[4];
  char caDesCode[10];
}  g_stTpuMap[MAX_TPUMAP_LINES];


int SrhTpuMapTbl(char cBussId, char *pcDesCode);


/*
 *&N& ROUNTINE NAME : StartRequest()
 *&A& ARGUMENTS: �L
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D& �ǰeSIF�ܻ��ݥD����TPU���A��.
 *&D&
 */
int
StartRequest()
{
  UCP_TRACE(P_StartRequest);
  UCP_TRACE_END( 0 );
}


/*
 *&N& ROUNTINE NAME : SendSifToServ()
 *&A& ARGUMENTS: �L
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ < 0 
 *&R&
 *&D& DESCRIPTION:
 *&D& �ǰeSIF�ܻ��ݥD����TPU���A��.
 *&D&   < 0 : �����~
 *&D&
 */
int
SendSifToServ(char *pcSifBuf,int iSifLen)
{
  int iRc;
  UCP_TRACE(P_SendSifToServ);
  ErrLog(10,"SendSifToServ:Begin.",RPT_TO_LOG,0,0);
  iRc=TpeCtSndSif(pcSifBuf,iSifLen);
  if ( iRc < 0 ) {
    UCP_TRACE_END(-1);
  }
  ErrLog(10,"SendSifToServ:End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(0);
}


/*
 *&N& ROUNTINE NAME : RecSofFromServ()
 *&A& ARGUMENTS: �L
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D&
 */
int
RecSofFromServ(char *pcSofData)
{
  char caMsgCode[SOF_MSG_CODE_LEN];

  UCP_TRACE(P_RecSofFromServ);
  ErrLog(10,"RecSofFromServ:Begin.",RPT_TO_LOG,0,0);
  TpeCtRcvSof(pcSofData);
  /* move the form-id to the first 4 bytes */
  memset(caMsgCode, '\0', SOF_MSG_CODE_LEN);
  memcpy(caMsgCode, (char *)pcSofData+SOF_MSG_CODE_OFFSET+3, 4);
  memcpy(caMsgCode+4, (char *)pcSofData+SOF_MSG_CODE_OFFSET, 3);
  memcpy((char *)pcSofData+SOF_MSG_CODE_OFFSET, caMsgCode, SOF_MSG_CODE_LEN);
  /* end of move */
  ErrLog(10,"RecSofFromServ:End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END ( 0 );
}


/*
 *&N& ROUNTINE NAME : EndRequest()
 *&A& ARGUMENTS: �L
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D& �ǰeSIF�ܻ��ݥD����TPU���A��.
 *&D&
 */
int
EndRequest()
{
  UCP_TRACE(P_EndRequest);
  UCP_TRACE_END( 0 );
}


/*
 *&N& ROUNTINE NAME : TpeCtSndSif()
 *&A& ARGUMENTS: �L
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D& �ǰeSIF�ܻ��ݥD����TPU���A��.
 *&D& -1 : call sequence error!!
 *&D& -2 : SIF length error!!
 *&D& -3 : ConnectWrite SIF to TPU server error!!
 *&D& -4 : Compress SIF error!!
 *&D&  0 : Txn. has done and is normal.
 *&D&  1 : Txn. has done and is abnormal.
 */
int
TpeCtSndSif(char *pcSifBuf,int iSifLen)
{
  int iRc;
  char cTxnRtnCode;
  char caTmpBuf[10];
  char caBuf[80];
  /* ------------------ compress SIF -------------------- */
  char caCnvOutBuff[1024];
  int  iSifCprsLen;
  /* ------------------ compress SIF -------------------- */
  char *pcTemp;
  static int s_iTpuMapNotFound=0;

  UCP_TRACE(P_TpeCtSndSif);

  ErrLog(10,"TpeCtSndSif:Begin.",RPT_TO_LOG,0,0);

  if ( sg_cSifComeFlag == 'y' ) {
    sprintf(g_caMsg,"TpeCtSndSif: call seq. error! sg_cSifComeFlag=%c",
            sg_cSifComeFlag);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    sg_cSifComeFlag = 'n';
    UCP_TRACE_END(-1);
  }

  if ((iSifLen < SIF_HEAD_LEN) || (iSifLen > MAX_SIF_LEN)) {
    sprintf(g_caMsg,"TpeCtSndSif: SIF data len=%d error!",iSifLen);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    sg_cSifComeFlag = 'n';
    UCP_TRACE_END(-2);
  }

  /* ------------------ compress SIF -------------------- */
  iRc = SifCprs(pcSifBuf,caCnvOutBuff,iSifLen);
  if ( iRc < 0 ) {
    sg_cSifComeFlag = 'n';
    sprintf(g_caMsg,"TPE sif code compress error iRc=%d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,pcSifBuf,iSifLen);
    UCP_TRACE_END(-4);
  }
  iSifCprsLen = iRc;
  /* ------------------ compress SIF -------------------- */

  if (sg_cProtoType == '\0') {
    memset(caBuf, '\0', 80);
    pcTemp=(char *)getenv("TPE_CLT_PROTOCOL");
    if(pcTemp != NULL) {
      strcpy(caBuf, pcTemp);
    }
    else {
      caBuf[0]='\0';
    }
    if (caBuf[0] != '\0') {
      sg_cProtoType = caBuf[0];
    }
    else {
      sg_cProtoType = QUEUE_DCS;
    }

    if(sg_cProtoType == QUEUE_DCS) {
      iRc=LoadTpuMap(g_stTpuMap);
      if(iRc < 0) {
        s_iTpuMapNotFound=1;
      }
    }
  }

  if(sg_cProtoType == QUEUE_DCS && s_iTpuMapNotFound == 0) {
     SrhTpuMapTbl(pcSifBuf[4],g_caDesCode);
  }
  else {
     memcpy(g_caDesCode,"0000000000",10);
  }

  MpstDcsSiof(g_stDcsBuf) = &g_stDcsSiof;
  memcpy(McaDesCode(g_stDcsBuf),g_caDesCode,10);
  memcpy(McaServCode(g_stDcsBuf),pcSifBuf+4,4);
  McRqstCode(g_stDcsBuf) = DCSCONNECTWRITE;
  McMoreByte(g_stDcsBuf) = '1';
  McKind(g_stDcsBuf) = '1';
  McProtoType(g_stDcsBuf) = sg_cProtoType;
  McProto(g_stDcsBuf) = sg_cProtoType;
  MlWaiTime(g_stDcsBuf) = DCS_TIMEOUT;
  MiDataLen(g_stDcsBuf) = DCS_SK_HEAD+iSifCprsLen;
  memset(caTmpBuf,0,10);
  sprintf(caTmpBuf,"%.5d",iSifCprsLen+DCS_SK_HEAD);
  memcpy(McaDataLen(g_stDcsBuf),caTmpBuf,5);
  memcpy(McaData(g_stDcsBuf),caCnvOutBuff,iSifCprsLen);

  /* for debug dump send Data */
  ErrLog(10,"TpeCtSndSif: DcsSiof data=",RPT_TO_LOG,
         MpstDcsSiof(g_stDcsBuf),MiDataLen(g_stDcsBuf));

  DcsDispatch(&g_stDcsBuf);

  if (MiReply(g_stDcsBuf) != DCS_NORMAL) {
    sg_cSifComeFlag = 'n';
    sprintf(g_caMsg,"TpeCtSndSif: Error Rtn Code=%d",MiReply(g_stDcsBuf));
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-3);
  } 

  g_iCtSessId = MiSesIdx(g_stDcsBuf);
  sprintf(g_caMsg,"TpeCtSndSif: Client Session Id=%d",g_iCtSessId);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
  sg_cSifComeFlag='y';
/* mark by WuChihLiang 19960612 for dalien IBS 
  iRc=RcvAllSof(&cTxnRtnCode);
  if ( iRc < 0 ) {
    iRc = iRc - 4; /x for shifting retrun code x/
    UCP_TRACE_END( iRc );
  }
  else {
    sg_iCurOffset = sizeof(struct MemBufCtlSt);
    if(cTxnRtnCode == '0') {
      UCP_TRACE_END( 0 );
    }
    else {
      UCP_TRACE_END( 1 );
    }
  }*/
  ErrLog(10,"TpeCtSndSif:End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END( 0 );
} 



/*
 *&N& ROUNTINE NAME : RcvAllSof()
 *&A& ARGUMENTS: �L
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D& -1 : read SOF from server error!
 *&D& -2 : write SOF to memory error!
 *&D& -3 : write TPEO to server error!
 *&D& -4 : write ACK to server error!
 *&D& -5 : decompress SOF error!
 *&D&
 *&D&
 */
int
RcvAllSof(char *pcRmtApFlag)
{
  int   iRc;
  int   iReadSize;
  int   iCtlFlowFlag; 
  char  caAckBuf[80];
  char  cSofCtlData1;
  int   iSofCnt = 0;
  char  cFirstCtlDataFlag = '1';
  char  cFirstSofCtlData;
  short sDataLen;
  char  caTmpBuf[10];
  struct  MemBufCtlSt *pstMemBufCtl;
  /* ------------------- Decompress SOF ---------------------- */
  int   i;  
  int   iSofLen;
  char  caCnvInBuff[3072];
  /* ------------------- Decompress SOF ---------------------- */

  UCP_TRACE(P_RcvAllSof);

  ErrLog(10,"RcvAllSof:Begin.",RPT_TO_LOG,0,0);
  /* Clear  g_caMemBuf */
  memset(g_caMemBuf, '\0', sizeof(g_caMemBuf));
  pstMemBufCtl = (struct MemBufCtlSt *)&g_stMemBufCtl ;
  pstMemBufCtl->iNextOffset = sizeof(struct MemBufCtlSt);
  pstMemBufCtl->iMsgCnt     = 0;

  iCtlFlowFlag = CTL_ON;
  MpstDcsSiof(g_stDcsBuf) = &g_stDcsSiof;

  for (iSofCnt=0; ; iSofCnt++) {
    /* receive Sof From Remote Host TPU */
    McRqstCode(g_stDcsBuf) = DCSREAD;
    MlWaiTime(g_stDcsBuf) = DCS_TIMEOUT;
    MiDataLen(g_stDcsBuf) = DCS_MAX_DATA_LEN;
    McProto(g_stDcsBuf) = sg_cProtoType;
    MiSesIdx(g_stDcsBuf) = g_iCtSessId;
    DcsDispatch(&g_stDcsBuf);
    if (MiReply(g_stDcsBuf) != DCS_NORMAL) {
      sg_cSifComeFlag = 'n';
      sg_iCtlFlowFlag=CTL_ON; 
      sprintf(g_caMsg,"RcvAllSof: sofCnt=%d,dcsreceive reply=%d,errno=%d",
              iSofCnt, MiReply(g_stDcsBuf),MiErrno(g_stDcsBuf));
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      /* disconnect */
      McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
      DcsDispatch(&g_stDcsBuf);
      UCP_TRACE_END(-1);
    }
    iReadSize = MiDataLen(g_stDcsBuf);

    sprintf(g_caMsg,"RcvAllSof: iSofCnt=%d,iReadSize=%d, DATA=",
            iSofCnt,iReadSize-8);
    ErrLog(100, g_caMsg, RPT_TO_LOG, McaData(g_stDcsBuf), iReadSize-8);

    /* ------------------- Decompress SOF ---------------------- */
    iSofLen=iReadSize-8;
    iRc = SofDecprs(McaData(g_stDcsBuf),&iSofLen,caCnvInBuff);
    if ( iRc < 0 ) {
      sg_cSifComeFlag = 'n';
      sg_iCtlFlowFlag=CTL_ON; 
      sprintf(g_caMsg,"TPE sof code decompress error iRc=%d",iRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,McaData(g_stDcsBuf),iSofLen);
      UCP_TRACE_END(-5);
    }
    /* ------------------- Decompress SOF ---------------------- */

    /* access control byte from SOF header */
    cSofCtlData1 = caCnvInBuff[SOF_CTL_CODE_OFFSET] ;

    /* bypass the CNETER host TPESDOUT data */
    if ( cSofCtlData1 & PRINT_MSG_MASK ){ /* AP call TPESDOUT API */
      cFirstCtlDataFlag = '1'; /* reset first control flag */
      continue; /* goto begin of while loop */
    }

    if ( iCtlFlowFlag == CTL_ON ) {

      if ( cFirstCtlDataFlag == '1'){
        cFirstSofCtlData = cSofCtlData1;
        if ( cSofCtlData1 IS_AP_ABEND ) {
          *pcRmtApFlag = '5';
          sprintf(g_caMsg,"<APD>Remote Txn failed, Control SOF MsgCode=[%.7s]",
                  &caCnvInBuff[SOF_MSG_CODE_OFFSET]);
          ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
        }
        else {
          ErrLog(100,"<APD>Remote Txn succeed",RPT_TO_LOG,0,0);
          *pcRmtApFlag = '0';
        }

        /* --- test the SOF whether the SOF is PIGGYBACK SOF or not     ---- */
        if(strncmp(&caCnvInBuff[SOF_OUT_DEV_OFFSET],"@@@@@@@@",8)== 0){
          i=SOF_HEAD_LEN_PLUS_2;
          while ( i < iSofLen ) {
            sDataLen=(unsigned char)caCnvInBuff[i+SOF_DATA_LEN_OFFSET]*256
                    +(unsigned char)caCnvInBuff[i+SOF_DATA_LEN_OFFSET+1];
            iRc = MemWrite(&caCnvInBuff[i],SOF_HEAD_LEN_PLUS_2+sDataLen, 1);
            if( iRc !=  (SOF_HEAD_LEN_PLUS_2+sDataLen) ) {
              sg_cSifComeFlag = 'n';
              sg_iCtlFlowFlag=CTL_ON; 
              sprintf(g_caMsg,"RcvAllSof:MemWrite error! size=%d, rtn size=%d",
                      SOF_HEAD_LEN_PLUS_2+sDataLen,iRc);
              ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
              /* disconnect */
              McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
              DcsDispatch(&g_stDcsBuf);
              UCP_TRACE_END(-2);
            }
            i += (SOF_HEAD_LEN_PLUS_2+sDataLen);
          } /* end while */
          break;
        } /* end of processing PIGGYBACK SOF */
    
        cFirstCtlDataFlag = '0';
      }

      /* write Data of Remote Host TPU Sof to File */
      iRc = MemWrite(caCnvInBuff,iSofLen, 1);
      if( iRc !=  iSofLen ) {
        sg_cSifComeFlag = 'n';
        sg_iCtlFlowFlag=CTL_ON; 
        sprintf(g_caMsg,"RcvAllSof:MemWrite error! size=%d, rtn size=%d",
                iSofLen,iRc);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        /* disconnect */
        McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
        DcsDispatch(&g_stDcsBuf);
        UCP_TRACE_END(-2);
      }

      if ( cSofCtlData1 & LAST_MSG_MASK ) {

        iCtlFlowFlag = CTL_OFF;
        if ( !(cFirstSofCtlData & TPEO_MSG_MASK) ){
          break; /* exit while loop */
        }

        /* send TPEO to Remote Host TPU */
        McRqstCode(g_stDcsBuf) = DCSWRITE;
        McProto(g_stDcsBuf)=sg_cProtoType;
        MiSesIdx(g_stDcsBuf)=g_iCtSessId;
        sprintf(McaDataLen(g_stDcsBuf),"%.5d",4 + DCS_SK_HEAD);
        memcpy(McaData(g_stDcsBuf), "TPEO", 4);
        MiDataLen(g_stDcsBuf) = 4 + DCS_SK_HEAD;
        DcsDispatch(&g_stDcsBuf);
        if(MiReply(g_stDcsBuf) != DCS_NORMAL){
          sg_cSifComeFlag = 'n';
          sg_iCtlFlowFlag=CTL_ON; 
          sprintf(g_caMsg,"RcvAllSof: DCSWRITE reply=%d errno=%d",
                  MiReply(g_stDcsBuf),MiErrno(g_stDcsBuf));
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
          DcsDispatch(&g_stDcsBuf);
          UCP_TRACE_END(-3);
        }

      }/* end of "if ( cSofCtlData1 & LAST_MSG_MASK ) " */

    }
    else {

      /* --- test the SOF whether the SOF is PACKED SOF or not     ---- */
      if(strncmp(&caCnvInBuff[SOF_OUT_DEV_OFFSET],"@@@@@@@@",8)== 0){
        i=SOF_HEAD_LEN_PLUS_2;
        while ( i < iSofLen ) {
          sDataLen=(unsigned char)caCnvInBuff[i+SOF_DATA_LEN_OFFSET]*256
                  +(unsigned char)caCnvInBuff[i+SOF_DATA_LEN_OFFSET+1];
          iRc = MemWrite(&caCnvInBuff[i],SOF_HEAD_LEN_PLUS_2+sDataLen, 1);
          if( iRc !=  (SOF_HEAD_LEN_PLUS_2+sDataLen) ) {
            sg_cSifComeFlag = 'n';
            sg_iCtlFlowFlag=CTL_ON; 
            sprintf(g_caMsg,"RcvAllSof:MemWrite error! size=%d, rtn size=%d",
                    SOF_HEAD_LEN_PLUS_2+sDataLen,iRc);
            ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
            /* disconnect */
            McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
            DcsDispatch(&g_stDcsBuf);
            UCP_TRACE_END(-2);
          }
          i += (SOF_HEAD_LEN_PLUS_2+sDataLen);
        } /* end while */
      } /* end of processing PACKED SOF */
      else {
        /* write Data of Remote Host TPU Sof to File */
        iRc = MemWrite(caCnvInBuff,iSofLen, 1);
        if( iRc !=  iSofLen ) {
          sg_cSifComeFlag = 'n';
          sg_iCtlFlowFlag=CTL_ON; 
          sprintf(g_caMsg,"RcvAllSof:MemWrite error! size=%d, rtn size=%d",
                  iSofLen,iRc);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          /* disconnect */
          McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
          DcsDispatch(&g_stDcsBuf);
          UCP_TRACE_END(-2);
        }  /* end of processing Single SOF */
      }

      if ( cSofCtlData1 & LAST_MSG_MASK ){
        break; /* exit while loop */
      }

      /* send ACK to Remote Host TPU */
      McRqstCode(g_stDcsBuf) = DCSWRITE;
      McProto(g_stDcsBuf)=sg_cProtoType;
      MiSesIdx(g_stDcsBuf)=g_iCtSessId; 
      sprintf(McaDataLen(g_stDcsBuf),"%.5d",1 + DCS_SK_HEAD);
      McaData(g_stDcsBuf)[0]='\0';
      MiDataLen(g_stDcsBuf) = 1 + DCS_SK_HEAD;
      DcsDispatch(&g_stDcsBuf);
      if(MiReply(g_stDcsBuf) != DCS_NORMAL){
        sg_cSifComeFlag = 'n';
        sg_iCtlFlowFlag=CTL_ON; 
        sprintf(g_caMsg,"RcvAllSof: DCSWRITE reply=%d errno=%d",
                MiReply(g_stDcsBuf),MiErrno(g_stDcsBuf));
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
        DcsDispatch(&g_stDcsBuf);
        UCP_TRACE_END(-4);
      }

   }

  } /* while(cLoopFlag == 'y') */

  sg_cSifComeFlag = 'n';
  sg_iCtlFlowFlag=CTL_ON; 

  /* disconnect TPU session */
  McProto(g_stDcsBuf)=sg_cProtoType;
  MiSesIdx(g_stDcsBuf)=g_iCtSessId;
  McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
  DcsDispatch(&g_stDcsBuf);
  

  sprintf(g_caMsg,"MemBuf:Cnt=[%d],NextOffset=[%d]",pstMemBufCtl->iMsgCnt,pstMemBufCtl->iNextOffset);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
  ErrLog(10,"DUMP All SOF in g_caMemBuf[]=",RPT_TO_LOG,&g_caMemBuf[sizeof(struct MemBufCtlSt)],pstMemBufCtl->iNextOffset-sizeof(struct MemBufCtlSt));

  ErrLog(10,"RcvAllSof:End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END ( 0 );
}


/*
 *&N& ROUNTINE NAME : TpeCtRcvSof()
 *&A& ARGUMENTS: �L
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ < 0 
 *&R&
 *&D& DESCRIPTION:
 *&D&   1: more SOF 
 *&D&   0: last SOF
 *&D&  -1: no SOF
 *&D& -2 : read SOF from server error!
 *&D& -3 : write SOF to memory error!
 *&D& -4 : write TPEO to server error!
 *&D& -5 : write ACK to server error!
 *&D& -6 : decompress SOF error!
 *&D&
 */
int
TpeCtRcvSof(char *pcaSofBuf)
{
  struct  MemBufCtlSt *pstMemBufCtl;
  short sDataLen; 

/* added by WuChihLiang 19960612 for dalien IBS -- BEGIN */
  char cTxnRtnCode;
  int  iRc;
/* added by WuChihLiang 19960612 for dalien IBS -- END */
  
  UCP_TRACE(P_TpeCtRcvSof);

/* added by WuChihLiang 19960612 for dalien IBS -- BEGIN */
  if ( sg_cSifComeFlag == 'y' ) {
    iRc=RcvAllSof(&cTxnRtnCode);
    if ( iRc < 0 ) {
      iRc = iRc - 1; /* for shifting retrun code */
      UCP_TRACE_END( iRc );
    }
    else {
      sg_iCurOffset = sizeof(struct MemBufCtlSt);
    }
  }
/* added by WuChihLiang 19960612 for dalien IBS -- END */
 
  pstMemBufCtl = (struct MemBufCtlSt *)&g_stMemBufCtl ;
  if (sg_iCurOffset >= pstMemBufCtl->iNextOffset) {
    UCP_TRACE_END( -1 ); 
  } 
  else {
    sDataLen=(unsigned char)g_caMemBuf[sg_iCurOffset+SOF_DATA_LEN_OFFSET]*256
            +(unsigned char)g_caMemBuf[sg_iCurOffset+SOF_DATA_LEN_OFFSET+1];

    memcpy(pcaSofBuf,&g_caMemBuf[sg_iCurOffset],SOF_HEAD_LEN_PLUS_2+sDataLen);
    sg_iCurOffset += (SOF_HEAD_LEN_PLUS_2+sDataLen);
    if (sg_iCurOffset >= pstMemBufCtl->iNextOffset) {
      UCP_TRACE_END( 0 ); 
    }
    else {
      UCP_TRACE_END( 1 );
    }
  }
}


/*
 *&N& ROUNTINE NAME : MemWrite()
 *&A& ARGUMENTS: �L
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ < 0 
 *&R&
 *&D& DESCRIPTION:
 *&D&   1: more SOF 
 *&D&   0: last SOF
 *&D& < 0: no SOF
 *&D&
 */
MemWrite(char *pcBuf, int iBufLen, int iMsgCnt)
{
  struct  MemBufCtlSt *pstMemBufCtl;
  
  UCP_TRACE(P_MemWrite);
  pstMemBufCtl = (struct MemBufCtlSt *)&g_stMemBufCtl ;

  if ( ( (pstMemBufCtl->iNextOffset)+iBufLen ) > sizeof(g_caMemBuf) ){
    sprintf(g_caMsg,
 "MemWrite:write data length=%d plus iNextOffset=%d over sizeof(g_caMemBuf)=%d",
           iBufLen, pstMemBufCtl->iNextOffset, sizeof(g_caMemBuf) );
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  }
  
  memcpy(g_caMemBuf+(pstMemBufCtl->iNextOffset), pcBuf, iBufLen);

  pstMemBufCtl->iNextOffset += iBufLen;
  pstMemBufCtl->iMsgCnt += iMsgCnt;

  UCP_TRACE_END(iBufLen);
  
}

/*
int
SifCprs(char *pcInput,char *pcOutput,int iInputLen)
{
  memcpy(pcOutput,pcInput,iInputLen);
  return(iInputLen);
}


int
SofDecprs(char *pcInput,int *piSofLen,char *pcOutput)
{
  sprintf(g_caMsg,"SofDecprs: len=%d",*piSofLen);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
  memcpy(pcOutput,pcInput,*piSofLen);
  return(0);
}
*/

/*
*&N& ROUTINE NAME: LoadTpuMap
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   load tpumap table: the table has 2 fields. One is buss-id, another
*&D&                      is destination code
*/
int
LoadTpuMap(struct TpuMapSt *pstTpuMap)
{
  int i,j,k;
  FILE *pfTpuMapFd;
  char caFileName[256];

  UCP_TRACE(P_LoadTpuMap);

  sprintf(caFileName,"%s/iii/etc/dcd/tpumap.dat",(char *)getenv("III_DIR"));

  pfTpuMapFd = fopen(caFileName,"r");
  if(pfTpuMapFd == (FILE *) 0){
    sprintf (g_caMsg,
             "LoadTpuMap:Failure to open tpumap table [%s]! (errno:%d)",
             caFileName, errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-11);
  }

  i = 0;
  while(fscanf(pfTpuMapFd,"%s %s", pstTpuMap[i].caBussId,
        pstTpuMap[i].caDesCode) != EOF){
    i++;
    if(i > MAX_TPUMAP_LINES){
      sprintf (g_caMsg,
               "LoadTpuMap: TpuMap table size [%d] exceeds the limit [%d]",
               i, MAX_TPUMAP_LINES);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      fclose (pfTpuMapFd);
      UCP_TRACE_END (-12);
    }
  }

  gs_iMaxTpuMapLoad = i;
  fclose(pfTpuMapFd);

  UCP_TRACE_END(0);
}


/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   search tpumap table to find out correct destination code by buss-id
*&D&
*/

int
SrhTpuMapTbl(char cBussId, char *pcDesCode)
{
  int iIdx,iRc;
  struct TpuMapSt *pstTpuMap;

  UCP_TRACE(P_SrhTpuMapTbl);

  pstTpuMap = g_stTpuMap;
  iIdx = 0;
  /* find out in the net work table array */
  while( iIdx < gs_iMaxTpuMapLoad ){
    if (cBussId == pstTpuMap[iIdx].caBussId[0]) {
      break;
    }
    iIdx++;
  }
  
  if(iIdx == gs_iMaxTpuMapLoad){
    /* not found use default destination */
    memcpy(pcDesCode,"0000000000",10);
  }
  else{
    /* found */
    memcpy(pcDesCode,pstTpuMap[iIdx].caDesCode,10);
  }

  UCP_TRACE_END(0);
}
