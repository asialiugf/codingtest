#include "errlog.h"
#include "twa.h"
#include "tms.h"
#include "ucp.h"
#include "tmcpgdef.h"

extern struct TMA *g_pstTma;
extern struct TBA *g_pstTba;
extern int g_iBrhCodeLen;    /* Branch code real length */
extern int g_iTmCodeLen;     /* Term code real length   */
extern int g_iSifLen;       /* record the length of SIF           */

/*
 *&N& ROUTINE NAME: SifCvtIn()
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : MAC check error
 *&R&   -2      : Decompress SIF error
 *&R&
 *&D& DESCRIPTION:
 *&D& This function will check DES value and decompressing SIF
 */
int
SifCvtIn(char *pcaSif,char *pcaCnvInBuff,int iSifLen)
{
  int iRc;

  ErrLog(10,"SifCvtIn: before DUMP SIF=",RPT_TO_LOG,pcaSif,iSifLen);
  iRc = SifDecprs(pcaSif,&iSifLen,pcaCnvInBuff);
  if ( iRc < 0 ) {
    return(-2);
  }
  memcpy(g_pstTba->caSif, pcaCnvInBuff, iSifLen);
  g_iSifLen = iSifLen;
  ErrLog(10,"SifCvtIn: after DUMP SIF=",RPT_TO_LOG,g_pstTba->caSif,iSifLen);

  iRc = CheckDes();
  if( iRc < 0 ) {
    return( -1 );
  }

  return(iSifLen);
}


#ifdef DESKEY

#define MAX_MAC_IN_LEN  256
#define MAX_MAC_DATA_LEN  32
#define CHECK_DATA_LEN     8
#define CHECK_DATA_LEN     8
#define SIFHEADLEN        51      /* add by jesswu 19950128 */

struct MacSt {
  char caRtnCode[2];
  char caMacOut[8];
  char caKeyCode[7];
  char caDataLen[4];
  char caMacIn[MAX_MAC_IN_LEN];
};


int
CheckDes()
{
  int i;
  int iRc;
  int iSifLen;    /*  add by JessWu 19950127  */
  int iSifDataLen;    /*  add by JessWu 19950127  */
  char caTmpBuf[10];
  char caDataBuf[MAX_MAC_DATA_LEN+1];
  struct MacSt stMac;
  static char s_cFirst='y';
  static char s_caNullStr[21];

  UCP_TRACE(P_CheckDes);
  
  ErrLog(100,"Enter CheckDes ...",RPT_TO_LOG,0,0);

  iSifLen = g_iSifLen;    /*  add by JessWu 19950127  */

  if ( s_cFirst == 'y' ) {
    for ( i=0;i<21;i++) {
      s_caNullStr[i]='\0';
    }
    s_cFirst = 'n';
  }

  memset(&stMac,0,sizeof(struct MacSt));
  switch ( g_pstTma->stTSSA.cSystemRole ) {
    case CENTER_HOST:
      if ( memcmp(&g_pstTba->caSif[USER_DEFINE_OFFSET],s_caNullStr,20) == 0 ) {
        ErrLog(100,"<CheckDes> Center: By-pass txn ...",RPT_TO_LOG,0,0);
        UCP_TRACE_END( 0 ); /* bypass SIF */
      }

      ErrLog(100,"<CheckDes> Center: Receive MAC value=",RPT_TO_LOG,
             &g_pstTba->caSif[USER_DEFINE_OFFSET],CHECK_DATA_LEN);

      iRc = DesOpen();
      if ( iRc < 0 ) {
        sprintf(g_caMsg,"<CheckDes> Center DesOpen error!");
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END( -1 );
      }

      memset(caTmpBuf,0,10);
      sprintf(caTmpBuf,"%.4d",MAX_MAC_DATA_LEN);
      memcpy(stMac.caDataLen,caTmpBuf,4);
      memcpy(stMac.caKeyCode,&g_pstTba->caSif[BR_CODE_OFFSET],g_iBrhCodeLen);

      /* --- If SIF's Data less than MAX_MAC_DATA_LEN, we must fill '0' until
       * --- length is equal to MAX_MAC_DATA_LEN.
       */
      memset(caDataBuf,'\0',MAX_MAC_DATA_LEN);
      if ( (iSifLen - SIFHEADLEN) < MAX_MAC_DATA_LEN ) {
       memcpy(caDataBuf,&g_pstTba->caSif[SIF_HEAD_LEN],(iSifLen-SIFHEADLEN));
      }
      else {
       memcpy(caDataBuf,&g_pstTba->caSif[SIF_HEAD_LEN],MAX_MAC_DATA_LEN);
      }
      caDataBuf[MAX_MAC_DATA_LEN]='\0';

      ErrLog(100,"<CheckDes> Center: dump input MAC data=",RPT_TO_LOG,
             caDataBuf,MAX_MAC_DATA_LEN);

      /* --- prepare the data for DESMACOP --- */
      memcpy(stMac.caMacIn,caDataBuf,MAX_MAC_DATA_LEN);
      DESMACOP(stMac.caRtnCode,stMac.caMacOut,stMac.caKeyCode,stMac.caDataLen,
               stMac.caMacIn);

      ErrLog(100,"<CheckDes> Center: after DESMACOP 8 Bytes=",RPT_TO_LOG,
             stMac.caMacOut,CHECK_DATA_LEN);

      if ( memcmp(stMac.caRtnCode,"00",2) != 0 ) {
        sprintf(g_caMsg,"<CheckDes> Center DESMACOP error!");
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);

        /* Added by Willy in Dalian 1995/5/26 */
        iRc = DesClose();
        if ( iRc < 0 ) {
          sprintf(g_caMsg,"<CheckDes> Center DesClose error!");
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        }
        /* End Addition */

        UCP_TRACE_END( -1 );
      }

      if (memcmp(&g_pstTba->caSif[USER_DEFINE_OFFSET],stMac.caMacOut,CHECK_DATA_LEN) != 0 ) {
        /* MAC value check error */
        iRc = DesClose();

        if ( iRc < 0 ) {
          sprintf(g_caMsg,"<CheckDes> Center DesClose error!");
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        }

        UCP_TRACE_END( -1 );
      }

      /* Added by Willy in Dalian 1995/5/26 */
      iRc = DesClose();
      if ( iRc < 0 ) {
        sprintf(g_caMsg,"<CheckDes> Center DesClose error!");
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END( -1 );
      }
      /* End Addition */
      
      break;
    case BRANCH_HOST:
      iRc = DesOpen();
      if ( iRc < 0 ) {
        sprintf(g_caMsg,"<CheckDes> Branch DesOpen error!");
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END( -1 );
      }

      memset(caTmpBuf,0,10);
      sprintf(caTmpBuf,"%.4d",MAX_MAC_DATA_LEN);
      memcpy(stMac.caDataLen,caTmpBuf,4);
      memcpy(stMac.caKeyCode,&g_pstTba->caSif[BR_CODE_OFFSET],g_iBrhCodeLen);

      /* --- If SIF's Data less than MAX_MAC_DATA_LEN, we must fill '0' until
       * --- length is equal to MAX_MAC_DATA_LEN.
       */
      memset(caDataBuf,'\0',MAX_MAC_DATA_LEN);
      iSifDataLen = iSifLen - SIFHEADLEN;    /* modify by JessWu 19950128 */

      if ( iSifDataLen < MAX_MAC_DATA_LEN) {
       memcpy(caDataBuf,&g_pstTba->caSif[SIF_HEAD_LEN],iSifDataLen);
      }
      else {
       memcpy(caDataBuf,&g_pstTba->caSif[SIF_HEAD_LEN],MAX_MAC_DATA_LEN);
      }
      caDataBuf[MAX_MAC_DATA_LEN]='\0';

      ErrLog(100,"<CheckDes> Branch: dump input MAC data=",RPT_TO_LOG,
             caDataBuf,MAX_MAC_DATA_LEN);

      ErrLog(100,"<CheckDes> Branch: before DESMACOP... ",RPT_TO_LOG,0,0);
      /* --- prepare the data for DESMACOP --- */
      memcpy(stMac.caMacIn,caDataBuf,MAX_MAC_DATA_LEN);
      DESMACOP(stMac.caRtnCode,stMac.caMacOut,stMac.caKeyCode,stMac.caDataLen,
               stMac.caMacIn);
      ErrLog(100,"<CheckDes> Branch: after DESMACOP... ",RPT_TO_LOG,0,0);

      if ( memcmp(stMac.caRtnCode,"00",2) != 0 ) {
        /* Mac error , then branch put 20 null char to SIF USER_DEFINE_AREA */
        ErrLog(100,"<CheckDes> Branch: DESMACOP error!",RPT_TO_LOG,0,0);
        memset(&g_pstTba->caSif[USER_DEFINE_OFFSET],0,20);
      }
      else {
        memcpy(&g_pstTba->caSif[USER_DEFINE_OFFSET],stMac.caMacOut,
               CHECK_DATA_LEN);
        ErrLog(100,"<CheckDes> Branch: generate MAC value=",RPT_TO_LOG,
               &g_pstTba->caSif[USER_DEFINE_OFFSET],CHECK_DATA_LEN);
      }

      iRc = DesClose();
      if ( iRc < 0 ) {
        sprintf(g_caMsg,"<CheckDes> Branch DesClose error!");
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END( -1 );
      }

      break;
    default:
      ;
  }
 
  UCP_TRACE_END( 0 );
}


int
DesOpen()
{
  unsigned char caRc[2];

  ErrLog(10,"DesOpen: befoer DESINIT",RPT_TO_LOG,0,0);
  DESINIT(caRc);
  ErrLog(10,"DesOpen: after DESINIT",RPT_TO_LOG,0,0);
  if ( strncmp(caRc,"00",2) != 0 ) {
    sprintf(g_caMsg,"DESINIT error! error code=%.2s",caRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    return( -1 );
  }
  return( 0 );
}

int
DesClose()
{
  unsigned char caRc[2];

  ErrLog(10,"befoer DESCLOSE",RPT_TO_LOG,0,0);
  DESCLOSE(caRc);
  ErrLog(10,"after DESCLOSE",RPT_TO_LOG,0,0);

/* mark for unknown reason
*/
  if ( strncmp(caRc,"00",2) != 0 ) {
    sprintf(g_caMsg,"DESCLOSE error! error code=%.2s",caRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    return( -1 );
  }

  return( 0 );
}

#else

int
CheckDes()
{
  return(0);
}

#endif


