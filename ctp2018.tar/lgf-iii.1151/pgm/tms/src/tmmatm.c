/*
 *&N& File : tmmamt.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int       main()
 */

/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include "errlog.h"	/* �O�����~�T���ɨϥΨ쪺�`�Ƥθ�Ƶ��c */
#include "ucp.h"	/* �O�����~�T���ɨϥΨ쪺�`�Ƥθ�Ƶ��c */

#define  LAST_MSG_STATUS   0x80

/*
 *&N& ROUNTINE NAME : main()
 *&A& ARGUMENTS: �L
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D&
 */

int
main()
{
  int iRc;
  int iSifLen;
  int iSofLen;
  char cSofCtlByte;
  char caSifBuf[MAX_SIF_LEN];
  char caSofBuf[6400];
  char caLogName[256];

  sprintf(caLogName, "%s/iii/log/atm_errlog", getenv("III_DIR") );
  ChgLog(LOG_CHG_MODE,"1");
  ChgLog(LOG_CHG_LOG,caLogName);

  iRc = StartRequest();
  if ( iRc < 0 ) {
    return( -1 );
  }

  while( 1 ) {
    /* iRc --> SIF length , iRc < 0 --> err */
    memset(caSifBuf,0,MAX_SIF_LEN);
    iRc = GetSif(caSifBuf);
    if ( iRc < 0 ) {
      return( -1 );
    }

    iSifLen = iRc ;
    ErrLog(100,"ATM main: dump SIF:",RPT_TO_LOG,caSifBuf,iRc);

    iRc = SendSifToServ(caSifBuf,iSifLen);
    if ( iRc < 0 ) {
      return( -1 );
    }
    
    do {
      iRc = RecSofFromServ(caSofBuf);
      sprintf(g_caMsg,"RecSofFromServ: return code = %d",iRc);
      ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
      if ( iRc < 0 ) {
        return( -1 );
      }
      iSofLen = 256 * caSofBuf[SOF_DATA_LEN_OFFSET] + 
                caSofBuf[SOF_DATA_LEN_OFFSET+1];
      cSofCtlByte = caSofBuf[SOF_CTL_CODE_OFFSET];
      ErrLog(100,"ATM main: dump SOF cntl byte:",
             RPT_TO_LOG,&cSofCtlByte,1);
      if ( cSofCtlByte == 0x88 ) {
        ErrLog(100,"ATM main: ERROR MSG=",
               RPT_TO_LOG,&caSofBuf[18],4);
      }
      if ( cSofCtlByte == 0x20 ) {
        ErrLog(100,"ATM main: REINPUT MSG",
               RPT_TO_LOG,caSofBuf,SOF_HEAD_LEN);
      }
      if ( cSofCtlByte == 0x80 ) {
        ErrLog(100,"ATM main: TPEWRITE MSG",
               RPT_TO_LOG,&caSofBuf[18],4);
      }
      ErrLog(100,"ATM main: dump SOF DATA=",
             RPT_TO_LOG,caSofBuf,SOF_HEAD_LEN+iSofLen);
    } while ( !(cSofCtlByte & LAST_MSG_STATUS) || (cSofCtlByte == 0x82) ); 
  }  /* while loop for SendSifToServ & RecSofFromServ() */
  
  iRc = EndRequest();
  if ( iRc < 0 ) {
    return( -1 );
  }

  return( 0 );

}




int 
GetSif(char *pcSifBuf)
{
  char caTxnCode[10];
  char *pcData;
  int  iSifLen;

  iSifLen = 51;
  pcData = (char *) (pcSifBuf+51);
  while( 1 ) {
    printf("Please input ATM txn id -->");
    scanf("%s",caTxnCode);
    if ( caTxnCode[0] == 'q' || caTxnCode[0] == 'Q' ) {
      return ( -1 ) ;
    }
    if ( memcmp( caTxnCode,"1020",4) != 0 &&
       memcmp( caTxnCode,"1030",4) != 0 &&
       memcmp( caTxnCode,"1050",4) != 0 &&
       memcmp( caTxnCode,"1861",4) != 0  )  {
      printf("No such %s ATM txn id.\n");
    }
    else {
      break;
    }
  }

  memcpy(pcSifBuf,"TPEI",4);
  memcpy(pcSifBuf+10,"0000023",7);
  memcpy(pcSifBuf+20,"01",2);
  memcpy(pcSifBuf+24,"99",2);
  if ( memcmp( caTxnCode,"1020",4) == 0 ) {
    memcpy(pcSifBuf+4,"1020",4);
    *(pcData)=strlen("0000001")/256;
    *(pcData+1)=strlen("0000001")%256;
    pcData+=2;
    iSifLen+=2;
    memcpy(pcData,"0000001",strlen("0000001"));
    pcData+=strlen("0000001");
    iSifLen+=strlen("0000001");

    *(pcData)=strlen("210600011")/256;
    *(pcData+1)=strlen("210600011")%256;
    pcData+=2;
    iSifLen+=2;
    memcpy(pcData,"210600011",strlen("210600011"));
    pcData+=strlen("210600011");
    iSifLen+=strlen("210600011");

    *(pcData)=strlen("01")/256;
    *(pcData+1)=strlen("01")%256;
    pcData+=2;
    iSifLen+=2;
    memcpy(pcData,"01",strlen("01"));
    iSifLen+=strlen("01");
    pcData+=strlen("01");

    *(pcData)=strlen("300")/256;
    *(pcData+1)=strlen("300")%256;
    pcData+=2;
    iSifLen+=2;
    memcpy(pcData,"300",strlen("300"));
    iSifLen+=strlen("300");

    return( iSifLen );
  }
  if ( memcmp( caTxnCode,"1030",4) == 0 ) {
    memcpy(pcSifBuf+4,"1030",4);
    *(pcData)=strlen("0000001")/256;
    *(pcData+1)=strlen("0000001")%256;
    pcData+=2;
    iSifLen+=2;
    memcpy(pcData,"0000001",strlen("0000001"));
    pcData+=strlen("0000001");
    iSifLen+=strlen("0000001");

    *(pcData)=strlen("210600011")/256;
    *(pcData+1)=strlen("210600011")%256;
    pcData+=2;
    iSifLen+=2;
    memcpy(pcData,"210600011",strlen("210600011"));
    pcData+=strlen("210600011");
    iSifLen+=strlen("210600011");

    *(pcData)=strlen("01")/256;
    *(pcData+1)=strlen("01")%256;
    pcData+=2;
    iSifLen+=2;
    memcpy(pcData,"01",strlen("01"));
    iSifLen+=strlen("01");
    pcData+=strlen("01");

    *(pcData)=strlen("200")/256;
    *(pcData+1)=strlen("200")%256;
    pcData+=2;
    iSifLen+=2;
    memcpy(pcData,"200",strlen("200"));
    iSifLen+=strlen("200");

    return( iSifLen );
  }
  if ( memcmp( caTxnCode,"1050",4) == 0 ) {
    memcpy(pcSifBuf+4,"1050",4);

    *(pcData)=strlen("0000001")/256;
    *(pcData+1)=strlen("0000001")%256;
    pcData+=2;
    iSifLen+=2;
    memcpy(pcData,"0000001",strlen("0000001"));
    pcData+=strlen("0000001");
    iSifLen+=strlen("0000001");

    *(pcData)=strlen("210600011")/256;
    *(pcData+1)=strlen("210600011")%256;
    pcData+=2;
    iSifLen+=2;
    memcpy(pcData,"210600011",strlen("210600011"));
    pcData+=strlen("210600011");
    iSifLen+=strlen("210600011");

    *(pcData)=strlen("01")/256;
    *(pcData+1)=strlen("01")%256;
    pcData+=2;
    iSifLen+=2;
    memcpy(pcData,"01",strlen("01"));
    iSifLen+=strlen("01");
    pcData+=strlen("01");

    return( iSifLen );
  }
  if ( memcmp( caTxnCode,"1861",4) == 0 ) {
    memcpy(pcSifBuf+4,"1861",4);
    return( 20 );
  }
  
  return( 0 );
}
