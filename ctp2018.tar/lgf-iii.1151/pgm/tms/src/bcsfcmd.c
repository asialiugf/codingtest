#include <stdio.h>
#include <errno.h>
#include <ctype.h>
#include <fcntl.h>
#include <signal.h>
#include "errlog.h"
#include "upcioara"
#define CONSOLE           "/dev/console"
#define MAX_DD_FILE       40
#define MAX_FILE_LEN      40
#define MAX_PATH_LEN      80
#define MAX_TOKEN_LEN     80
#define MAX_LINE_LEN      1024
#define NO_PATH           20
#define BACKUP            '1'
#define RESTORE           '2'
#define VERIFY            '3'
#define UBC               '4'
#define EXEC              '5'
#define SORT              '6'
#define MERGE             '7'
#define DELETE            '8'
#define DELDEF            '9'
#define DLBL              'a'
#define STEPEND           'b'
#define DEFAULTPATH       'c'
#define PATHDEF           'd'
#define PAUSE             'e'
#define END               'E'
#define SORT1             'f'


FILE *fp,*jfp;
char p[MAX_LINE_LEN];               /* store one command line            */
char cmd_buf[MAX_LINE_LEN];         /* buffer of one command             */
char token[MAX_TOKEN_LEN];          /* buffer one token                  */
char rev_token[MAX_TOKEN_LEN];      /* buffer of reverse token           */
char jobrpt[80];                    /* buffer report file name           */
char *getline();
char *gettoken();
char convert();
static int  num_DD_file=0;          /* numbers of define by DLBL         */
static int  path_no=0;              /* numbers of define path name       */
static int  DD_mv_flag=0;           /* flag of rename or not for DLBL    */
char c,tmp[80];
int  r_code;
int  fd1,fd2,tmpfd,rec_size,r_code;
int  fd,out_fd,tmp_fd,tmp_fd0;
int  fd123;
static char default_path[MAX_FILE_LEN]=".";/* buffer of default pathname */
struct DD_FILE_st{                  /*  define DLBL struct               */
  char index_flag;                  /*  index file = 1,otherwise = 0     */ 
  char path_name[MAX_PATH_LEN];     /*  path name of file                */
  char logic_file[MAX_FILE_LEN];    /*  logic file name                  */
  char physi_file[MAX_FILE_LEN];    /*  physic file name                 */
} ;
struct path_st{                     /*  define path name struct          */
  char busi_type[3];                /*  business type                    */ 
  char path_name[MAX_PATH_LEN];     /*  path name                        */ 
} ;
static struct path_st path_def[NO_PATH];
static struct DD_FILE_st DD_file[MAX_DD_FILE];
/* ----- add by chi-fu-song 1994/12/07 for compatible ------- */
static char caTmpFile[80];
#define TMP_PREFIX  "tmp."
#define UCPIO TPGIO
/*
#define start_ucpio StartUcpio
#define end_ucpio EndUcpio
*/
/*-----------------------------------------------*/
/* command interpreter for the BATCH PROCEDURE   */
/*-----------------------------------------------*/
ucpfcmd(jobname,ap_pgm_exe_path,prg_name,b_status)
char *jobname;
char *ap_pgm_exe_path;
char *prg_name;
char *b_status;
{
  char caCmdBuf[80];
  char *pLinePtr;

  if (*b_status=='I') {
     start_ucpio();
     num_DD_file=0;
     path_no=0;
     DD_mv_flag=0;
     if ( (fp=fopen(jobname,"r")) != NULL ) {
        if ((pLinePtr = getline()) == NULL) {
           fclose(fp);
           *b_status='1';
       printf("command file empty statement,strike ENTER to continue\n");
           scanf("%c",&c);
           end_ucpio();
           return (-1);
        }
        strcpy(p,pLinePtr);
        strcpy(token,gettoken(p,1));
        if (strncmp("BEGIN",token,5) && strncmp("begin",token,5)) {
           fclose(fp);
           *b_status='1';
       printf("command file no 'BEGIN' statement,strike any key to continue\n");
           scanf("%c",&c);
           end_ucpio();
           return (-1);
        }
        strcpy(jobrpt,gettoken(p,0));
        sprintf(jobrpt,"%s.rpt\0",jobname);
        if( (jfp=fopen(jobrpt,"w")) == NULL ) {
          printf("can't open --- %s\n",jobrpt);
          return(-1);     /* added by YEN 950713 */
        }
        fprintf(jfp,"%s\n",p);
        /* ---- Add by chi-fu-song 1994/12/08 ------ */
        memset(caTmpFile,0,80);
        sprintf(caTmpFile,"%s/iii/tmp",getenv("III_DIR"));
        strcpy(caTmpFile,tempnam(caTmpFile,TMP_PREFIX));
        sprintf(g_caMsg, "JCL's tmp filename is %s", caTmpFile);
        ErrLog(100, g_caMsg, RPT_TO_LOG, 0, 0);
        *b_status='0'; /* normal return */
        /* ---------- mark by chi-fu-song, 1994/12/09, if ......
         * end_ucpio();
         * ------------*/
        return(0);
     }
     else {
        printf("command file not found !strike any key to continue\n");
        scanf("%c",&c);
        *b_status='2';
        end_ucpio();
        return(-1);
     } 
  }
/*
  fprintf(jfp,"********** b_status = %c********** ?! >>\n",*b_status);
*/
  if (*b_status=='1'  || *b_status == '5'){
     fprintf(jfp,"<< AP exectue error ?! >>\n");
/*
     printf("<< AP exectue error ?! >>\n");
*/
     print_error_msg("UBC",jobrpt);
     fd123=open(caTmpFile,O_RDWR|O_CREAT,0666);
     /* ------ add by chi-fu-song 1994/12/08 -------- */
     if ( fd123 == -1 ) {
        fclose(fp);
        fclose(jfp);
        *b_status='4';
        end_ucpio();
        return (-1);
     }
     /* -------- write(fd123,'0',1); --------error code ----- */
     write(fd123,"0",1);
     close(fd123);
     if (prn_conti_msg() < 0){
        fclose(fp);
        fclose(jfp);
        *b_status='2';
        end_ucpio();
        return (-1);
     }
     /* ---- add by chi-fu-song 1994/12/09 --- AP EXEC error ,
         BATCH process will stop now .
     */
     /* ---- add by chi-fu-song 1994/12/09--- rm temp file ----*/
     sprintf(caCmdBuf,"rm %s",caTmpFile);
     system(caCmdBuf);
     fclose(fp);
     fclose(jfp);
     *b_status='1';
     end_ucpio();
     return (-1);
  }

  pLinePtr = getline();
  while (1){ 
    if (pLinePtr == NULL) {
      strcpy(rev_token,"END");
      sprintf(g_caMsg, "JCL %s has no END statement", jobname);
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      fprintf(jfp,"<< Warning >> no END statement\n");
    } else {
      signal(SIGCLD,SIG_DFL);
      strcpy(p, pLinePtr);
      fprintf(jfp,"%s\n",p);
      strcpy(rev_token,gettoken(p,1));
    }
    if (rev_token[0] == '\0'){
       pLinePtr = getline();
       /* strcpy(p,getline()); */
       continue;
    }
    switch (convert(rev_token)){
    case '#'    : 
                 break;
    case '*'    : 
                 break;
    case BACKUP :
                 strcpy(token,gettoken(p,0));
                 if ((r_code=backup_fun(token)) < 0){
                    /* ---- add by chi-fu-song 1994/12/09--- rm temp file ----*/
                    sprintf(caCmdBuf,"rm %s",caTmpFile);
                    system(caCmdBuf);
                    fprintf(jfp,"<< Error ?! >>\n");
                    fclose(fp);
                    fclose(jfp);
                    *b_status='2';
                    print_error_msg(rev_token,jobrpt);
                    return (r_code);
                 }
                 break;
    case RESTORE:
                 strcpy(token,gettoken(p,0));
                 if ((r_code=restore_fun(token)) < 0){
                    /* ---- add by chi-fu-song 1994/12/09--- rm temp file ----*/
                    sprintf(caCmdBuf,"rm %s",caTmpFile);
                    system(caCmdBuf);
                    fprintf(jfp,"<< Error ?! >>\n");
                    fclose(fp);
                    fclose(jfp);
                    *b_status='2';
                    print_error_msg(rev_token,jobrpt);
                    return (r_code);
                 }
                 break;
    case VERIFY :
                 if ((r_code=verify_fun()) < 0){
                    fprintf(jfp,"<<Error ?!>>errno=%d\n",errno);
                    fclose(fp);
                    fclose(jfp);
                    *b_status='2';
                    print_error_msg(rev_token,jobrpt);
                    return (r_code);
                 }
                 break;
    case EXEC   :
                 if ((r_code=EXEC_fun()) < 0){
                    /* ---- add by chi-fu-song 1994/12/09--- rm temp file ----*/
                    sprintf(caCmdBuf,"rm %s",caTmpFile);
                    system(caCmdBuf);
                    fprintf(jfp,"<< Error ?! >>\n");
                    fclose(fp);
                    fclose(jfp);
                    *b_status='2';
                   /* print_error_msg(rev_token,jobrpt);*/
                    print_error_msg(p,jobrpt);
                    return (r_code);
                 }
                 break;
    case UBC    :
                 if (UBC_fun(prg_name,ap_pgm_exe_path) < 0){ 
                    fprintf(jfp,"<< Error ?! >>\n");
                    fclose(fp);
                    fclose(jfp);
                    *b_status='2';
                    print_error_msg(rev_token,jobrpt);
                    return (r_code);
                 }
                 *b_status='0';
                 /* ---- mark for normal display , 1995/04/15
                 end_ucpio();
                 */
                 return;
    case SORT   :
                 if ((r_code=sort_fun()) < 0){
                    /* ---- add by chi-fu-song 1994/12/09--- rm temp file ----*/
                    sprintf(caCmdBuf,"rm %s",caTmpFile);
                    system(caCmdBuf);
                    fprintf(jfp,"<< Error ?! >>\n");
                    fclose(fp);
                    fclose(jfp);
                    *b_status='2';
                    print_error_msg(rev_token,jobrpt);
                    return (r_code);
                 }
                 break;
    case SORT1  :
                 if ((r_code=sort1_fun()) < 0){
                    /* ---- add by chi-fu-song 1994/12/09--- rm temp file ----*/
                       sprintf(caCmdBuf,"rm %s",caTmpFile);
                    system(caCmdBuf);
                    fprintf(jfp,"<< Error ?! >>\n");
                    fclose(fp);
                    fclose(jfp);
                    *b_status='2';
                    print_error_msg(rev_token,jobrpt);
                    return (r_code);
                 }
                 break;
    case MERGE  :
                 if ((r_code=merge_fun()) < 0){
                    /* ---- add by chi-fu-song 1994/12/09--- rm temp file ----*/
                    sprintf(caCmdBuf,"rm %s",caTmpFile);
                    system(caCmdBuf);
                    fprintf(jfp,"<< Error ?! >>\n");
                    fclose(fp);
                    fclose(jfp);
                    *b_status='2';
                    print_error_msg(rev_token,jobrpt);
                    return (r_code);
                 }
                 break;
    case DELETE :
                 if ((r_code=DELETE_fun()) < 0){
                    /* ---- add by chi-fu-song 1994/12/09--- rm temp file ----*/
                    sprintf(caCmdBuf,"rm %s",caTmpFile);
                    system(caCmdBuf);
                    fprintf(jfp,"<< Error ?! >>\n");
                    fclose(fp);
                    fclose(jfp);
                    *b_status='2';
                    print_error_msg(rev_token,jobrpt);
                    return (r_code);
                 }
                 break;
    case DELDEF :
                 if ((r_code=DELDEF_fun()) < 0){
                    fprintf(jfp,"<< Error ?! >>\n");
                    fclose(fp);
                    fclose(jfp);
                    *b_status='2';
                    print_error_msg(rev_token,jobrpt);
                    return (r_code);
                 }
                 break;
    case DLBL   :
                 if ((r_code=DLBL_fun()) < 0){
                    fprintf(jfp,"<< Error ?! >>\n");
                    fclose(fp);
                    fclose(jfp);
                    *b_status='2';
                    print_error_msg(rev_token,jobrpt);
                    return (r_code);
                 }
                 break;
    case STEPEND :
                 if ((r_code=STEPEND_fun()) < 0){
                    fprintf(jfp,"<< Error ?! >>\n");
                    fclose(fp);
                    fclose(jfp);
                    *b_status='2';
                    print_error_msg(rev_token,jobrpt);
                    return (r_code);
                 }
                 num_DD_file=0;
                 break;
    case DEFAULTPATH:
                 /*strcpy(default_path,gettoken(p,0));*/
                 strcpy(cmd_buf,gettoken(p,0));
                 if (cmd_buf[0] != '/'){
                   sprintf(default_path,"%s/%s",getenv("III_DIR"),cmd_buf);
                 }else{
                   strcpy(default_path,cmd_buf);
                 }
/*
     printf("default_path = %s\n",default_path);
     fprintf(jfp,"default_path = %s\n",default_path);
*/
                 chdir(default_path);
                 break;
    case PATHDEF:
                 strcpy(path_def[path_no].busi_type,gettoken(p,0));
                 strcpy(path_def[path_no].path_name,gettoken(p,0));
/*
    printf("path_def[path_no].busi_type=%s\n",path_def[path_no].busi_type);
    printf("path_def[path_no].path_name=%s\n",path_def[path_no].path_name);
    fprintf(jfp,"path_def[path_no].busi_type=%s\n",path_def[path_no].busi_type);
    fprintf(jfp,"path_def[path_no].path_name=%s\n",path_def[path_no].path_name);*/
                 path_no++;
                 break;
    case PAUSE  :
                 strcpy(token,gettoken(p,0));
                 while (token[0] != '\0'){
                    printf("%s ",token);
                    strcpy(token,gettoken(p,0));
                 }
                 printf("\n");
                 scanf("%c",&c);
                 break;
    case END    :
                 /* ---- add by chi-fu-song 1994/12/09--- rm temp file ----*/
                 fd123=open(caTmpFile,O_RDONLY,0);
                 if ( fd123 != -1 ) {
		   close(fd123);
                   sprintf(caCmdBuf,"rm %s",caTmpFile);
                   system(caCmdBuf);
		 }
                 fclose(fp);
                 fclose(jfp);
                 /*------ mark by chi-fu-song 1994/12/09 ------
                 *b_status='2';
                 */
                 *b_status='3';
                 end_ucpio();
                 return (0);
    default     : 
                 fprintf(jfp,"Unexcept command --- %s\n",rev_token);
                 fclose(fp);
                 fclose(jfp);
                 *b_status='2';
/*
                 printf("Unexcept command --- %s\n",rev_token);
*/
                 print_error_msg(rev_token,jobrpt);
                 return (-1);
                 break;
    }/* end of switch */
    pLinePtr = getline();
    /* strcpy(p,getline()); */
  }/* end of while */ 
} 

/* ------------------------------------------------------------ */
/* This subroutine gets one line command from the command file. */
/* ------------------------------------------------------------ */
char *getline() 
{ 
  static char cs[MAX_LINE_LEN]; 
  int  i=0,c;

  while ((c=getc(fp))!=EOF){
/*
     printf("c=%c",c);
*/
     if ((cs[i]=c)=='\\')
        if ((c=getc(fp))=='\n')
           continue;
     if (cs[i]=='\n')
        break;
     i++;
  }
  cs[i]='\0';
  return ((c==EOF ) ? NULL : cs);
}

/* ---------------------------------------------------------- */
/* This subroutine gets one token from the command line.      */
/* ---------------------------------------------------------- */
char *gettoken(str,flg)
char *str;
int  flg;
{
  static int   str_idx=0;
  static char  str_buf[80];
  int    i=0;
  char   c;
  char   delimitor_flag; 

  if (flg==1)
     str_idx=0;
  if (str[str_idx] == '\0'){
     str_buf[i]='\0';
     str_idx=0;
     /*printf("*************str_buf=%s\n",str_buf);*/
     return (str_buf);
  }
  while ((c=str[str_idx++]) == ' ' || c == '\t');
  str_idx--;
  /*printf("str_idx=%d\n",str_idx);*/
  delimitor_flag='0';  /* reset delimitor flag */
  while(1) {
    c=str[str_idx];
    if ( delimitor_flag == '0' ) {
       if ( (c == ' ') || (c == '\t') || (c =='\0') ) {
         break;
       }
       else {
         if ( (c == '\'') || (c=='\"') ) {
           delimitor_flag='1';
         }
       } 
    }
    else {
       if ( c == '\0' ) {
         break;
       }
       else {
         if ( (c == '\'') || (c=='\"') ) {
           delimitor_flag='0';
         }
       } 
    } 
    str_buf[i++] = str[str_idx++];
  } /* for while(1) */
  str_buf[i]='\0';
  /*printf("str_buf=%s\n",str_buf);*/
  return (str_buf);
}

/* ---------------------------------------------------------- */
/* This subroutine convert the command to the prescribe char. */
/* ---------------------------------------------------------- */
char convert(str)
char str[];
{
  int i;

  for (i=0 ; i < strlen(str); i++)
      str[i] = toupper(str[i]);
  if (!strncmp("#",str,1))   
      return ('#');
  if (!strncmp("*",str,1))   
      return ('*');
  if (!strncmp("BACKUP",str,6))   
      return ('1');
  if (!strncmp("RESTORE",str,7))   
      return ('2');
  if (!strncmp("VERIFY",str,6))   
      return ('3');
  if (!strncmp("UBC",str,3)) 
      return ('4');
  if (!strncmp("EXEC",str,4))   
      return ('5');
  if (!strncmp("SORT1",str,5))   
      return (SORT1);
  if (!strncmp("SORT",str,4))   
      return ('6');
  if (!strncmp("MERGE",str,5))   
      return ('7');
  if (!strncmp("DELETE",str,6))   
      return ('8');
  if (!strncmp("DELDEF",str,6))   
      return ('9');
  if (!strncmp("DLBL",str,4))   
      return ('a');
  if (!strncmp("&/*",str,3))   
      return ('b');
  if (!strncmp("DEFAULTPATH",str,11))   
      return ('c');
  if (!strncmp("PATHDEF",str,7))   
      return ('d');
  if (!strncmp("PAUSE",str,5))   
      return ('e');
  if (!strncmp("END",str,3))   
      return ('E');
}    

backup_fun(device_name)
char *device_name;
{
  char c;

  sprintf(cmd_buf,"tar cvf %s",device_name);
  strcpy(token,gettoken(p,0));
  while (token[0] != '\0'){
    if (token[0] == '/')
      sprintf(cmd_buf,"%s %s",cmd_buf,token);
    else
      sprintf(cmd_buf,"%s %s/%s",cmd_buf,default_path,token);
    strcpy(token,gettoken(p,0));
    if (!(strncmp("index",token,5) && strncmp("INDEX",token,5))){
       sprintf(cmd_buf,"%s.idx %s.dat",cmd_buf,cmd_buf);
       strcpy(token,gettoken(p,0));
    }
  }
  sprintf(cmd_buf,"%s ; echo $? >%s\0",cmd_buf,caTmpFile);
/*
  printf("Insert the tape for backup,please\n");
  scanf("%c",&c);
  fprintf(jfp,"\n%s\n",cmd_buf);
*/
  system(cmd_buf);
  return(prn_conti_msg());
}

restore_fun(device_name)
char *device_name;
{
  char c;
  sprintf(cmd_buf,"tar xvf %s",device_name);
  strcpy(token,gettoken(p,0));
  while (token[0] != '\0'){
    if (token[0] == '/')
      sprintf(cmd_buf,"%s %s",cmd_buf,token);
    else
      sprintf(cmd_buf,"%s %s/%s",cmd_buf,default_path,token);
    strcpy(token,gettoken(p,0));
    if (!(strncmp("index",token,5) && strncmp("INDEX",token,5))){
       sprintf(cmd_buf,"%s.idx %s.dat",cmd_buf,cmd_buf);
       strcpy(token,gettoken(p,0));
    }
  }
  sprintf(cmd_buf,"%s ; echo $? >%s\0",cmd_buf,caTmpFile);
/*
  printf("Insert the tape for restore,please\n");
  scanf("%c",&c);
*/
  system(cmd_buf);
  return(prn_conti_msg());
}

verify_fun()
{
  int rtn_code;

  strcpy(token,gettoken(p,0));
  if (token[0] == '/')
    sprintf(cmd_buf,"%s",token);
  else
    sprintf(cmd_buf,"%s/%s",default_path,token);
  strcpy(token,gettoken(p,0));
  if (strncmp("index",token,5) && strncmp("INDEX",token,5)){
     if ((rtn_code=open(cmd_buf,O_RDONLY)) < 0)
        return (rtn_code);
     else
        close (rtn_code);
  }
  else{
     strcpy(p,cmd_buf);
     sprintf(cmd_buf,"%s.idx",cmd_buf);
     if ((rtn_code=open(cmd_buf,O_RDONLY)) < 0)
        return (rtn_code);
     else
        close (rtn_code);
     sprintf(cmd_buf,"%s.dat",p);
     if ((rtn_code=open(cmd_buf,O_RDONLY)) < 0)
        return (rtn_code);
     else{
        close (rtn_code);
        return (rtn_code);
     }
  }
}

EXEC_fun()
{
  int iRc;

  sprintf(cmd_buf,"\0");
  strcpy(token,gettoken(p,0));
  while (token[0] != '\0'){
    sprintf(cmd_buf,"%s %s",cmd_buf,token);
    strcpy(token,gettoken(p,0));
  }
  sprintf(cmd_buf,"%s ; echo $? >%s\0",cmd_buf,caTmpFile);
  iRc = system(cmd_buf);
  if (iRc !=0) {
    sprintf(g_caMsg, "EXEC: system(%s) fails, RC=%d, errno=%d",
			cmd_buf, iRc, errno);
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
  }
  return(prn_conti_msg());
}

UBC_fun(n_program,n_ap_exe_path)
char *n_program,*n_ap_exe_path;
{
  int rtn_code;
  char n_busi;
/*
  DD_mv_flag=1;
  link_physi_logic();
*/

  strcpy(n_program,gettoken(p,0));
  strcpy(n_ap_exe_path,gettoken(p,0));
/*
  printf("ucpfcmd: n_program=%s\n",n_program);
  printf("ucpfcmd: n_ap_exe_path=%s\n",n_ap_exe_path);
  fflush(stdin);
  scanf("%c",&n_busi);
*/
/****** mark by chi-fu-song 1994/12/08*****
  strcpy(n_program,gettoken(p,0));
  strcpy(token,gettoken(p,0));
  memcpy(n_ap_exe_path,"../../pb/exe/",13);
  token[0] = tolower(token[0]);
  token[1] = tolower(token[1]);
  memcpy(n_ap_exe_path+6,token,2);
******************************************* /

/*
  if (!(strncmp(token,"pb",2) && strncmp(token,"PB",2)))
     *n_busi='1';
  else if (!(strncmp(token,"ct",2) && strncmp(token,"CT",2)))
     *n_busi='2';
  else if (!(strncmp(token,"ck",2) && strncmp(token,"CK",2)))
     *n_busi='3';
  else if (!(strncmp(token,"rt",2) && strncmp(token,"RT",2)))
     *n_busi='6';
  else
     *n_busi='0';
*/
  return (0);
}

sort_fun()
{
  int i;
  int tmp_fd0,tmp_fd,out_fd;
  char buf[80];
  char tmp[10];
  char tmp_buf[MAX_LINE_LEN];

  memset(tmp_buf,0x00,sizeof(tmp_buf));
  tmp_buf[0]=' ';
  strcpy(token,gettoken(p,0));
  for(i=0;i<strlen(token);i++) {
    if(token[i] < '0' || token[i] > '9') {
      fprintf(jfp,"Invalid record size --> %s\n",token);
      return(-1);
    }
  }
  rec_size=atoi(token);
  sprintf(cmd_buf,"sort -o");
  strcpy(token,gettoken(p,0));
  if (token[0] != '/')
     sprintf(buf,"%s/%s",default_path,token);
  else
     sprintf(buf,"%s",token);
  out_fd=open(buf,O_TRUNC|O_CREAT|O_WRONLY,0666);
  tmp_fd0=open("tmp0",O_TRUNC|O_CREAT|O_RDWR,0666);
  sprintf(cmd_buf,"%s tmp0",cmd_buf);
  i=1;
  strcpy(token,gettoken(p,0));
  while (isalpha(token[0])){
    if (token[0] != '/')
       sprintf(buf,"%s/%s",default_path,token);
    else
       sprintf(buf,"%s",token);
    fd=open(buf,O_RDONLY);
    sprintf(tmp,"tmp%d",i);
    tmp_fd=open(tmp,O_TRUNC|O_CREAT|O_RDWR,0666);
    add_newline(fd,tmp_fd);
    sprintf(tmp_buf,"%s %s",tmp_buf,tmp);
    strcpy(token,gettoken(p,0));
    i++;
/* added by YEN 800603 */
    close(tmp_fd);
/* end of insertion */
    close(fd);
  }

  /* Modify by dragon(III_WUHAN) 19970522  	 --- begin */
  /* purpose: remove the temp file tmp0 and tmp1           */
  /*
  if ((r_code=sort_key()) < 0)
     return (r_code);
  */
  if ((r_code=sort_key()) < 0){
     close(out_fd);
     close(tmp_fd0);
     system("rm tmp*");
     return (r_code);
  }
  /* Modify by dragon(III_WUHAN) 19970522  	 --- end */

  sprintf(cmd_buf,"%s %s",cmd_buf,tmp_buf);
  sprintf(cmd_buf,"%s ; echo $? >%s\0",cmd_buf,caTmpFile);
  fprintf(jfp,"sort-->%s\n",cmd_buf);
  system(cmd_buf);
  del_newline(tmp_fd0,out_fd);
/* added by YEN 800603 */
    close(tmp_fd0);
    close(out_fd);
/* end of insertion */
  r_code=prn_conti_msg();
  system("rm tmp*");
  return(r_code);
}

merge_fun()
{
  int i;
  int tmp_fd0,tmp_fd,out_fd;
  char buf[80];
  char tmp[10];
  char buf1[80];  /* added by YEN 1994/12/27 */

  strcpy(token,gettoken(p,0));
  for(i=0;i<strlen(token);i++) {
    if(token[i] < '0' || token[i] > '9') {
      fprintf(jfp,"Invalid record size --> %s\n",token);
      return(-1);
    }
  }
  rec_size=atoi(token);
  sprintf(cmd_buf,"sort -m -o");
  strcpy(token,gettoken(p,0));
  if (token[0] != '/')
     sprintf(buf,"%s/%s",default_path,token);
  else
     sprintf(buf,"%s",token);
  out_fd=open(buf,O_TRUNC|O_CREAT|O_WRONLY,0666);
  tmp_fd0=open("tmp0",O_TRUNC|O_CREAT|O_RDWR,0666);
  sprintf(cmd_buf,"%s tmp0",cmd_buf);
  i=1;
  strcpy(token,gettoken(p,0));
  buf1[0]='\0';   /* added by YEN 1994/12/27 */
  while (isalpha(token[0])){
    if (token[0] != '/')
       sprintf(buf,"%s/%s",default_path,token);
    else
       sprintf(buf,"%s",token);
    fd=open(buf,O_RDONLY);
    sprintf(tmp,"tmp%d",i);
    tmp_fd=open(tmp,O_TRUNC|O_CREAT|O_RDWR,0666);
    add_newline(fd,tmp_fd);
  /* move the input file names to the end of the sort cmd */
/*  replaced by YEN 1994/12/27
    sprintf(cmd_buf,"%s %s",cmd_buf,tmp);
*/
    sprintf(buf1,"%s %s",buf1,tmp); 
    strcpy(token,gettoken(p,0));
    i++;
/* added by YEN 800603 */
    close(tmp_fd);
/* end of insertion */
    close(fd);
  }

  /* Modify by dragon(III_WUHAN) 19970522  	 --- begin */
  /* purpose: remove the temp file tmp0 and tmp1           */
  /*
  if ((r_code=sort_key()) < 0)
     return (r_code);
  */
  if ((r_code=sort_key()) < 0){
     close(out_fd);
     close(tmp_fd0);
     system("rm tmp*");
     return (r_code);
  }
  /* Modify by dragon(III_WUHAN) 19970522  	 --- end */

/*  replaced by YEN 1994/12/27
  sprintf(cmd_buf,"%s ; echo $? >%s\0",cmd_buf,caTmpFile);
*/
  sprintf(cmd_buf,"%s %s ; echo $? >%s\0",cmd_buf,buf1,caTmpFile);
/*
  printf("merge-->%s\n",cmd_buf);
*/
  system(cmd_buf);
  del_newline(tmp_fd0,out_fd);
/* added by YEN 800603 */
    close(tmp_fd0);
    close(out_fd);
/* end of insertion */
  r_code=prn_conti_msg();
  system("rm tmp*");
  return(r_code);
}

sort1_fun()
{
  char buf[80];

  strcpy(token,gettoken(p,0));
  rec_size=atoi(token);
  sprintf(cmd_buf,"sort -o");
  strcpy(token,gettoken(p,0));
  if (token[0] != '/')
     sprintf(buf,"%s/%s",default_path,token);
  else
     sprintf(buf,"%s",token);
  sprintf(cmd_buf,"%s %s",cmd_buf,buf);
  strcpy(token,gettoken(p,0));
  while (isalpha(token[0])){
    if (token[0] != '/')
       sprintf(buf,"%s/%s",default_path,token);
    else
       sprintf(buf,"%s",token);
    sprintf(cmd_buf,"%s %s",cmd_buf,buf);
    strcpy(token,gettoken(p,0));
  }
  if ((r_code=sort_key()) < 0)
     return (r_code);
  sprintf(cmd_buf,"%s ; echo $? >%s\0",cmd_buf,caTmpFile);
  fprintf(jfp,"sort-->%s\n",cmd_buf);
  system(cmd_buf);
  r_code=prn_conti_msg();
  return(r_code);
}
/*
sort_fun()
{
  strcpy(token,gettoken(p,0));
  sprintf(cmd_buf,"sort -o %s",token);
  strcpy(token,gettoken(p,0));
  sprintf(cmd_buf,"%s %s",cmd_buf,token);
  strcpy(token,gettoken(p,0));
  if ((r_code=sort_key()) < 0)
     return (r_code);
  sprintf(cmd_buf,"%s\0",cmd_buf);
  system(cmd_buf);
  printf("Do you want to continue ? ('y' or 'n')-->");
  scanf("%c",&c);
  scanf("%c",&d);
  if (c=='Y' || c=='y' || c=='\012')
     r_code=0;
  else
     r_code=-1;
  return (r_code);
}

merge_fun()
{
  sprintf(cmd_buf,"sort -m -o");
  strcpy(token,gettoken(p,0));
  while (isalpha(token[0])){
    sprintf(cmd_buf,"%s %s",cmd_buf,token);
    strcpy(token,gettoken(p,0));
  }
  if ((r_code=sort_key()) < 0)
     return (r_code);
  sprintf(cmd_buf,"%s\0",cmd_buf);
  printf("merge-->%s\n",cmd_buf);
  system(cmd_buf);
  printf("Do you want to continue ? ('y' or 'n')-->");
  scanf("%c",&c);
  scanf("%c",&d);
  if (c=='Y' || c=='y' || c=='\012')
     r_code=0;
  else
     r_code=-1;
  return (r_code);
}
*/

DELETE_fun()
{
  sprintf(cmd_buf,"rm");
  strcpy(token,gettoken(p,0));
  while (token[0] != '\0'){
    if (token[0] == '/')
      sprintf(cmd_buf,"%s %s",cmd_buf,token);
    else
      sprintf(cmd_buf,"%s %s/%s",cmd_buf,default_path,token);
    strcpy(token,gettoken(p,0));
    if (!(strncmp("index",token,5) && strncmp("INDEX",token,5))){
       sprintf(cmd_buf,"%s.idx %s.dat",cmd_buf,cmd_buf);
       strcpy(token,gettoken(p,0));
    }
  }
  sprintf(cmd_buf,"%s ; echo $? >%s\0",cmd_buf,caTmpFile);
  system(cmd_buf);
  return(prn_conti_msg());
}


DELDEF_fun()
{
  int rtn_code,i;

  strcpy(token,gettoken(p,0));
  if (token[0] == '/')
    sprintf(cmd_buf,"");
  else
    sprintf(cmd_buf,"%s/",default_path);
  for (i=0;token[i] != '\0';i++){
    if (token[i] == '/')
       if ((rtn_code = open(cmd_buf,O_RDONLY)) == -1)
          mkdir(cmd_buf,0755);
       else 
          close (rtn_code);
    sprintf(cmd_buf,"%s%c",cmd_buf,token[i]);
  }
  strcpy(token,gettoken(p,0));
  if (strncmp("index",token,5) && strncmp("INDEX",token,5)){
     if ((rtn_code=open(cmd_buf,O_CREAT|O_TRUNC,0666)) < 0)
        return (rtn_code);
     else
        close (rtn_code);
  }
  else{
     strcpy(p,cmd_buf);
     sprintf(cmd_buf,"%s.idx",cmd_buf);
     if ((rtn_code=open(cmd_buf,O_CREAT|O_TRUNC,0666)) < 0)
        return (rtn_code);
     else
        close (rtn_code);
     sprintf(cmd_buf,"%s.dat",p);
     if ((rtn_code=open(cmd_buf,O_CREAT|O_TRUNC,0666)) < 0)
        return (rtn_code);
     else
        close (rtn_code);
  }
  return(0);
}

DLBL_fun()
{
  int i;
  int flag;
  int rtn_code;

  strcpy(DD_file[num_DD_file].logic_file,gettoken(p,0));
  strcpy(DD_file[num_DD_file].physi_file,gettoken(p,0));
  strcpy(token,gettoken(p,0));
  if (strncmp("index",token,5) && strncmp("INDEX",token,5)){
     DD_file[num_DD_file].index_flag='0';
  }
  else{
     DD_file[num_DD_file].index_flag='1';
     strcpy(token,gettoken(p,0));
  }
  if (token[0] == '\0')
     strcpy(DD_file[num_DD_file].path_name,default_path);
  else{
     flag=0;
     for (i=0; i<path_no ;i++)
        if (strncmp(path_def[i].busi_type,token,2))
           continue;
        else{
           strcpy(DD_file[num_DD_file].path_name,path_def[i].path_name);
           flag=1;
           break;
        }
     if (flag == 0)
        fprintf(jfp,"<< undefine pathname >>\n");
  }   
  num_DD_file++;
  DD_mv_flag=1;
  if ((rtn_code=link_physi_logic()) < 0)
     return (rtn_code);
  return (0);
}

STEPEND_fun()
{
  if (DD_mv_flag){
    DD_mv_flag=0;
    return(link_logic_physi());
  }
  return(0);
}

/* ---------------------------------------------------------------------- */
/* This function rename physical file to logic file                       */
/* ---------------------------------------------------------------------- */
link_physi_logic()
{
  int i;
  int r_code;

/*
  fprintf(jfp,"enter link_physi_logic \n");
  for (i=0 ;i < num_DD_file ;i++){
*/
  for (i=num_DD_file-1 ;i < num_DD_file ;i++){
/*
    fprintf(jfp,"source_file=%s\n",DD_file[i].physi_file);
    fprintf(jfp,"target_file=%s\n",DD_file[i].logic_file);
*/
    if (DD_file[i].index_flag == '1'){
     if (DD_file[i].logic_file[0] == '/'){
     sprintf(cmd_buf,"%s.idx",DD_file[i].logic_file);
     } /* logic_file name is absolute pathname */
     else{
     sprintf(cmd_buf,"%s/%s.idx",DD_file[i].path_name,DD_file[i].logic_file);
     }
     /* if wanted link file has been existed then delete it */
     if (open(cmd_buf,O_RDONLY) > 0){
     sprintf(cmd_buf,"rm %s/%s.idx",DD_file[i].path_name,DD_file[i].logic_file);
     system(cmd_buf);
     }
     if (DD_file[i].logic_file[0] == '/'){
     sprintf(cmd_buf,"%s.idx",DD_file[i].logic_file);
     } /* logic_file name is absolute pathname */
     else{
     sprintf(cmd_buf,"%s/%s.idx",DD_file[i].path_name,DD_file[i].logic_file);
     }
     if (DD_file[i].physi_file[0] == '/'){
     sprintf(token,"%s.idx",DD_file[i].physi_file);
     } /* physi_file name is absolute pathname */
     else{
     sprintf(token,"%s/%s.idx",DD_file[i].path_name,DD_file[i].physi_file);
     }
     r_code=link(token,cmd_buf);
     if (r_code == -1){
        fprintf(jfp,"r_code=%d\n",r_code);
        return(r_code);
     }
     if (DD_file[i].logic_file[0] == '/'){
     sprintf(cmd_buf,"%s.dat",DD_file[i].logic_file);
     } /* logic_file name is absolute pathname */
     else{
     sprintf(cmd_buf,"%s/%s.dat",DD_file[i].path_name,DD_file[i].logic_file);
     }
     /* if wanted link file has been existed then delete it */
     if (open(cmd_buf,O_RDONLY) > 0){
     sprintf(cmd_buf,"rm %s/%s.dat",DD_file[i].path_name,DD_file[i].logic_file);
     system(cmd_buf);
     }
     if (DD_file[i].physi_file[0] == '/'){
     sprintf(token,"%s.dat",DD_file[i].physi_file);
     } /* physi_file name is absolute pathname */
     else{
     sprintf(token,"%s/%s.dat",DD_file[i].path_name,DD_file[i].physi_file);
     }
     if (DD_file[i].logic_file[0] == '/'){
     sprintf(cmd_buf,"%s.dat",DD_file[i].logic_file);
     } /* logic_file name is absolute pathname */
     else{
     sprintf(cmd_buf,"%s/%s.dat",DD_file[i].path_name,DD_file[i].logic_file);
     }
     r_code=link(token,cmd_buf);
     if (r_code == -1){
        fprintf(jfp,"r_code=%d\n",r_code);
        return(r_code);
     }
    }
    else{
     if (DD_file[i].logic_file[0] == '/'){
     sprintf(cmd_buf,"%s",DD_file[i].logic_file);
     } /* logic_file name is absolute pathname */
     else{
     sprintf(cmd_buf,"%s/%s",DD_file[i].path_name,DD_file[i].logic_file);
     }
     /* if wanted link file has been existed then delete it */
     if (open(cmd_buf,O_RDONLY) > 0){
     sprintf(cmd_buf,"rm %s/%s",DD_file[i].path_name,DD_file[i].logic_file);
     system(cmd_buf);
     }
     if (DD_file[i].logic_file[0] == '/'){
     sprintf(cmd_buf,"%s",DD_file[i].logic_file);
     } /* logic_file name is absolute pathname */
     else{
     sprintf(cmd_buf,"%s/%s",DD_file[i].path_name,DD_file[i].logic_file);
     }
     if (DD_file[i].physi_file[0] == '/'){
     sprintf(token,"%s",DD_file[i].physi_file);
     } /* physi_file name is absolute pathname */
     else{
     sprintf(token,"%s/%s",DD_file[i].path_name,DD_file[i].physi_file);
     }
     r_code=link(token,cmd_buf);
/*
     fprintf(jfp,"token=%s\n",token);
     fprintf(jfp,"cmd_buf=%s\n",cmd_buf);
     fprintf(jfp,"r_code=%d\n",r_code);
*/
     if (r_code == -1)
        return(r_code);
    }
  }
/*
  fprintf(jfp,"exit link_physi_logic \n");
*/
  return (r_code);
}

/* ---------------------------------------------------------------------- */
/* This function rename logic file to physical file                       */
/* ---------------------------------------------------------------------- */
link_logic_physi()
{
  int i;
  int r_code;

/*
  fprintf(jfp,"enter link_logic_physi\n");
*/
  for (i=0;i < num_DD_file ;i++){
/*
    fprintf(jfp,"source_file=%s\n",DD_file[i].logic_file);
    fprintf(jfp,"target_file=%s\n",DD_file[i].physi_file);
*/
    if (DD_file[i].index_flag == '1'){
     if (DD_file[i].logic_file[0] == '/'){
     sprintf(cmd_buf,"%s.idx",DD_file[i].logic_file);
     } /* logic_file name is absolute pathname */
     else{
     sprintf(cmd_buf,"%s/%s.idx",DD_file[i].path_name,DD_file[i].logic_file);
     }
/*
     fprintf(jfp,"%s\n",cmd_buf);
*/
     r_code=unlink(cmd_buf);
     fprintf(jfp,"r_code=%d\n",r_code);
     if (r_code == -1)
        return(r_code);
     if (DD_file[i].logic_file[0] == '/'){
     sprintf(cmd_buf,"%s.dat",DD_file[i].logic_file);
     } /* logic_file name is absolute pathname */
     else{
     sprintf(cmd_buf,"%s/%s.dat",DD_file[i].path_name,DD_file[i].logic_file);
     }
/*
     fprintf(jfp,"%s\n",cmd_buf);
*/
     r_code=unlink(cmd_buf);
     if (r_code == -1){
        fprintf(jfp,"r_code=%d\n",r_code);
        return(r_code);
     }
    }
    else{
     if (DD_file[i].logic_file[0] == '/'){
     sprintf(cmd_buf,"%s",DD_file[i].logic_file);
     } /* logic_file name is absolute pathname */
     else{
     sprintf(cmd_buf,"%s/%s",DD_file[i].path_name,DD_file[i].logic_file);
     }
/*
     fprintf(jfp,"%s\n",cmd_buf);
*/
     r_code=unlink(cmd_buf);
     if (r_code == -1){
        fprintf(jfp,"r_code=%d\n",r_code);
        return(r_code);
     }
    }
  }
/*
  fprintf(jfp,"exit link_logic_physi\n");
*/
  return(r_code);
}

/* ---------------------------------------------------------------------- */
/* When error happened this routine return (-1) else return (0).          */
/* ---------------------------------------------------------------------- */
prn_conti_msg()
{
  char c,d;
  int  rtn_code,fd123;
  char buf[5];

  fd123=open(caTmpFile,O_RDONLY);
  if (fd123 < 0) {
    sprintf(g_caMsg, "TMP_FILE: %s not found, errno=%d", caTmpFile,errno);
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    return -1;
  }
  read(fd123,buf,1);
  close(fd123);
/*
  fprintf(jfp,"/tmp/tmp123=%c\n",buf[0]);
*/
  if (buf[0] != '0'){
/*
    printf("Do you want to continue ? ('y' or 'n')-->");
    scanf("%c",&c);
    scanf("%c",&d);
    if (c=='Y' || c=='y' || c=='\012')
       rtn_code=0;
    else
       rtn_code=-1;
    return (rtn_code);
*/
    sprintf(g_caMsg, "!!ERROR!! TMPFILE's first byte is not 0");
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    return (-1);
   }
   else
     return (0);
}

/* ---------------------------------------------------------------------- */
/* This function transfer the sort key (k1,k2,k3,k4) to UNIX sort type    */
/*                        k1 : the initial sort position of the line.     */
/*                        k2 : number chars of sort.                      */
/*                        k3 : type of sort.('c' : char ; 'n' : numerical)*/
/*                        k4 : order of sort('a' : ascend ; 'd' : descent)*/
/* Modify record:							  */
/*   Dragon(III_WUHAN) modified it at 19970522 for three reason:	  */
/*     1. sort key just have four parameter, not any more or less.	  */ 
/*     2. para. one and  para. two must number.				  */ 
/*     3. modified the statement if k3 is N/n.                            */  
/* ---------------------------------------------------------------------- */
sort_key()
{
  char key1[6],key2[6],key3,key4;
  int  i,j;

  while (token[0] != '\0'){
    /* modify by dangon(III_WUHAN) 19970522   ----- begin	*/
    /* purpose: check if parameter is less than four parameter  */
    /*
    if (token[0] != '(' || token[strlen(token)-1] != ')'){
       fprintf(jfp,"Invalid sort key--> %s\n",token);
       return (-1);
    }
    */
    if ( strlen(token) < 9 || token[0] != '(' || token[strlen(token)-1] != ')'){
       fprintf(jfp,"Invalid sort key--> %s\n",token);
       return (-1);
    }
    /* modify by dangon(III_WUHAN) 19970522   ----- end   	*/
    key4=token[strlen(token)-2];
    key3=token[strlen(token)-4];
    if(toupper(key3) != 'N' && toupper(key3) != 'C') {
      fprintf(jfp,"Invalid sort key--> %c\n",key3);
      return (-1);
    }
    if(toupper(key4) != 'A' && toupper(key4) != 'D') {
      fprintf(jfp,"Invalid sort key--> %c\n",key4);
      return (-1);
    }
    for (i=1;i<strlen(token)-6;i++)
        if (token[i]==',')
            break;
    if (i==strlen(token)-6){
       fprintf(jfp,"Invalid sort key--> %s\n",token);
       return (-1);
    }

    /* modify by dragon(III_WUHAN) 9970520  --- begin */
    /* purpose: ensure k1 and k2  is number           */
    /*          ensure sort_key is less than 4 para.  */
    /*
    for (j=0;j<i-1;j++)
        key1[j]=token[j+1];
    key1[j]='\0';
    */
    for (j=0;j<i-1;j++){
      key1[j]=token[j+1];
      if ( key1[j] < '0' || key1[j] > '9'){
        fprintf(jfp,"Invalid sort key--> %s\n",token);
        return (-1);
      }
    }
    key1[j]='\0';

    /* 
    for (j=0;j<strlen(token)-i-6;j++)
        key2[j]=token[j+i+1];
    key2[j]='\0';
    */
    for (j=0;j<strlen(token)-i-6;j++){
        key2[j]=token[j+i+1];
        if ( key2[j] < '0' || key2[j] > '9'){
          fprintf(jfp,"Invalid sort key--> %s\n",token);
          return (-1);
        }
    }
    key2[j]='\0';
    /* modify by dragon(III_WUHAN) 9970520  --- end   */

    i=atoi(key1);
    j=atoi(key2);
    i=i-1;
    j=i+j;
    itoa(i,key1);
    itoa(j,key2);
    if (key4=='d' || key4=='D')
       sprintf(key1,"%sr",key1);
    /* modify by dragon(III_WUHAN) 9970520  --- begin */
    /* purpose: correct the key3 case N/n             */
    /* if (key3=='n' || key4=='N')                    
       sprintf(key1,"%sn",key1);                    
    */
    if (key3=='n' || key3=='N')
       sprintf(key1,"%sn",key1);
    /* modify by dragon(III_WUHAN) 9970520  --- end   */
    sprintf(token,"+0.%s -0.%s",key1,key2);
    sprintf(cmd_buf,"%s %s",cmd_buf,token);
    strcpy(token,gettoken(p,0));
  }
  return (0);
}

/* ---------------------------------------------------------- */
/* add the newline char to prescribe file                     */
/* ---------------------------------------------------------- */
add_newline(fd1,fd2)
int fd1;
int fd2;
{ 
  char tmp_buf[MAX_LINE_LEN];
 
/*
  printf("rec_size=%d\n",rec_size);
*/
  while ((r_code=read(fd1,tmp_buf,rec_size)) == rec_size ){
/*
    printf("r_code=%d",r_code);
*/
    tmp_buf[rec_size]='\n';
    write(fd2,tmp_buf,rec_size+1);
/*
    printf("tmp_buf=%s",tmp_buf);
*/
  }
}

/* ---------------------------------------------------------- */
/* delete the newline char for prescribe file                 */
/* ---------------------------------------------------------- */
del_newline(fd1,fd2)
int fd1;
int fd2;
{
  char tmp_buf[MAX_LINE_LEN];
  int i;

  lseek(fd1,0,0);
  while ((i=read(fd1,tmp_buf,rec_size+1)) == (rec_size+1) ){
    write(fd2,tmp_buf,rec_size);
  }
}
/* This funtion convert the integer to string */
/*
*/
itoa(i,s)
int i;
char s[];
{
  int j;

  j=0;
  do{
    s[j++]=i%10+'0';
  } while ((i/=10) > 0);
  s[j]='\0';
  reverse(s);
}

reverse(s)
char s[];
{
  int c,i,j;

  for(i=0,j=strlen(s)-1;i<j;i++,j--){
     c=s[i];
     s[i]=s[j];
     s[j]=c;
  }
}

print_error_msg(msg,filename)
char *msg;
{
  printf("\nExecute < %s > error,please check file-->%s\n",msg,filename);
  printf("Strike any key to exit\n");
  scanf("%c",&c);
}
print_error_msg1(msg,filename)
char *msg;
{
    struct ioarea cmd_list;
    char   tmp_buf[MAX_LINE_LEN+40]; 
    char   tmp_buf1[3]; 
    int    len;

    cmd_list.cmd_no = '3';
    cmd_list.cmd[0].cmd_id = '6';	/* Output data  */	
    strncpy(cmd_list.cmd[0].row, "20", 2);
    strncpy(cmd_list.cmd[0].col, "01", 2);
/*
    sprintf(tmp_buf,"Execute < %s > error,please check file-->%s",msg,filename);
*/
    sprintf(tmp_buf,"ִ�� < %s > ����,<< �����ĵ� >> -->%s",msg,filename);
    len = strlen(tmp_buf);
/* Mark by chi-fu-song, replace by <sprintf> system call
    itoa1(len, tmp_buf1,2);
*/
    sprintf(tmp_buf1,"%.2d",len);
    strncpy(cmd_list.cmd[0].data_len,tmp_buf1, 2);
    strncpy(cmd_list.cmd_data, tmp_buf, strlen(tmp_buf));
    cmd_list.cmd[1].cmd_id = '6';	/* Output data  */	
    strncpy(cmd_list.cmd[1].row, "21", 2);
    strncpy(cmd_list.cmd[1].col, "01", 2);
/*
    sprintf(tmp_buf,"Strike any key to exit-->");
*/
    sprintf(tmp_buf,"�밴������˳�!");
/* Mark by chi-fu-song, replace by <sprintf> system call
    itoa1(strlen(tmp_buf), tmp_buf1,2);
*/
    sprintf(tmp_buf1,"%.2d",len);
    strncpy(cmd_list.cmd[1].data_len,tmp_buf1, 2);
    strncpy(&(cmd_list.cmd_data[len]),tmp_buf, strlen(tmp_buf));
    cmd_list.cmd[2].cmd_id = '5';	/* Read   data  */
    cmd_list.cmd[2].data_type = 'X';	
    strncpy(cmd_list.cmd[2].row, "22", 2);
    strncpy(cmd_list.cmd[2].col, "01", 2);
    strncpy(cmd_list.cmd[2].data_len, "01", 2);
    UCPIO(&cmd_list);
    end_ucpio();
}
print_error_msg2(msg,filename)
char *msg;
{
    struct ioarea cmd_list;
    char   tmp_buf[MAX_LINE_LEN+40]; 
    char   tmp_buf1[3]; 
    int    len;

    cmd_list.cmd_no = '3';
    cmd_list.cmd[0].cmd_id = '6';	/* Output data  */	
    strncpy(cmd_list.cmd[0].row, "10", 2);
    strncpy(cmd_list.cmd[0].col, "02", 2);
/*
    sprintf(tmp_buf,"Execute < %s > error,please check file-->%s",msg,filename);
    len = strlen(tmp_buf);
    itoa1(len, tmp_buf1,2);
    strncpy(cmd_list.cmd[0].data_len,tmp_buf1, 2);
    strncpy(cmd_list.cmd_data, tmp_buf, strlen(tmp_buf));
*/
    strncpy(cmd_list.cmd[0].data_len,"20", 2);
    strcpy(cmd_list.cmd_data, "12345678901234567890");
    cmd_list.cmd[1].cmd_id = '6';	/* Output data  */	
    strncpy(cmd_list.cmd[1].row, "11", 2);
    strncpy(cmd_list.cmd[1].col, "02", 2);
    sprintf(tmp_buf,"Strike any key to exit-->");
/* Mark by chi-fu-song, replace by <sprintf> system call
    itoa1(strlen(tmp_buf), tmp_buf1,2);
*/
    sprintf(tmp_buf1,"%.2d",len);
    strncpy(cmd_list.cmd[1].data_len,tmp_buf1, 2);
    strncpy(&(cmd_list.cmd_data[len]),tmp_buf, strlen(tmp_buf));
    cmd_list.cmd[2].cmd_id = '5';	/* Read   data  */
    cmd_list.cmd[2].data_type = '9';	
    strncpy(cmd_list.cmd[2].row, "12", 2);
    strncpy(cmd_list.cmd[2].col, "01", 2);
    strncpy(cmd_list.cmd[2].data_len, "01", 2);
    UCPIO(&cmd_list);
    end_ucpio();
}
start_ucpio()
{
}
end_ucpio()
{
}
