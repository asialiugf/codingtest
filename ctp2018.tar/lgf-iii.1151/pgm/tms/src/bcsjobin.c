
/*
 *&N& File: tmbtxin.c   ����޲z�l�t�ΥD�{��
 *&N&
 *&N&    TYPE      NAME                 DESCRIPTION
 *&N& --------- ---------- ----------------------------------------
 *&N&    int     JclInput  Ū���妸�B�z�{��(JCL PROGRAM), �ð���t��
 *&N&                      �R�O(system command), �p�J�W UBC �R�O, �h
 *&N&                      ��� TPU �h�I�s BATCH AP �h����.
 *&N&
 *&N&
*/
/* --------------------- INCLUDE FILE --------------------- */
#include <stdio.h>
#include <time.h>
#include "twa.h"
#include "tms.h"
#include "ucp.h"
#include "errlog.h"
#include "tmcpgdef.h"

/* --------------------- CONSTANT DEFINE --------------------- */
#define  SIF_CTL_STATUS   "\x00\x00"

/* --------------------- EXTERN VARIABLES --------------------- */
extern struct TMA *g_pstTma;
extern struct TBA *g_pstTba;
extern int    g_iTxnCodeLen;
extern int    g_iBrhCodeLen;
extern int    g_iTmCodeLen ;


/*
 *&N& ROUTINE NAME: JclInput
 *&A& ARGUMENTS:
 *&N&    TYPE      NAME                 DESCRIPTION
 *&N& --------- ---------- ----------------------------------------
 *&A&     char *pcaBussName       JCL program �Ҧb���~�ȦW��
 *&A&     char *pcaJclFileName    JCL program ���W��
 *&A&
 *&R& RETURN VALUES:
 *&R&   -99 :  �� JCL program �� return code �����T
 *&R&   -4  :  open tmp file error
 *&R&   -3  :  �� ���� JCL program �� UNIX system command ���~�� JCL ����
 *&R&   -2  :  �� JCL program �� "BEGIN" �B "begin" ���s�b
 *&R&   -1  :  �� JCL program ���s�b
 *&R&    0  :  �� �}�ɥ��`
 *&R&    1  :  �� "UBC" �R�O
 *&R&    2  :  �� JCL ����
 *&R&
 *&D& DESCRIPTION:
 *&D&     ����Ƭ��I�supcfcmd()�v�@�h����JCL language, �ð���t�ΩR�O
 *&D& �p�J�W "UBC" ,�h���� TPU �I�s BATCH AP ���� .
 */

int
JclInput(char *pcErrStep,char *pcaBussName,char *pcaJclFileName,char *pcaTxnCode)
{
  int iRc;
  char cReturnCode;
  static char s_cFirst='y';
  char caApPgmName[80];
  char caApPgmExePath[80];

  UCP_TRACE(P_JclInput);

  *pcErrStep = '0';

  if ( s_cFirst == 'y' ) {
    cReturnCode = 'I';
    ucpfcmd(pcaJclFileName ,caApPgmExePath ,caApPgmName ,&cReturnCode);
/*
    printf("----ucpfcmd() return code = %c------\n",cReturnCode);
*/
    s_cFirst = 'n';
    switch( cReturnCode ) {
      case '0': /* ���}�ɥ��` */
        iRc = 0;
        break;
      case '1': /* �� JCL program �� "BEGIN" �B "begin" ���s�b */
        iRc = -2;
        break;
      case '2': /* �� JCL program ���s�b */
        iRc = -1;
        break;
      default:
        iRc = -99;
    }
  }
  else {
    memset(caApPgmName,0,80);
    memset(caApPgmExePath,0,80);
    cReturnCode = g_pstTma->stTCFA.cBatApRtnCode;
    ucpfcmd(pcaJclFileName ,caApPgmExePath ,caApPgmName ,&cReturnCode);
    switch(cReturnCode) {
      case '0':  /* JCL request UBC command */
        iRc = 1;
/*
        printf("-----pcaJclFileName=%s\n",pcaJclFileName);
        printf("-----caApPgmExePath=%s\n",caApPgmExePath);
        printf("-----caApPgmName=%s\n",caApPgmName);
*/
        MakPsuSif(pcaTxnCode);
        SetTwaForBatch(caApPgmExePath,caApPgmName);
        break;
      case '1':  /* AP EXEC error, BATCH process will stop now  */
        iRc = 3;
        break;
      case '2':  /* ���� JCL �� UNIX system command ���~�� JCL ���� */
        iRc = -3;
        break;
      case '3':  /* JCL ���� */
        iRc = 2;
        break;
      case '4':  /* open tmp file error */
        iRc = -4;
        break;
      default:
        iRc = -99;
    }
  }

  UCP_TRACE_END( iRc );
}


/*
 *&N& ROUTINE NAME: MakPsuSif
 *&A& ARGUMENTS:
 *&N&    TYPE      NAME                 DESCRIPTION
 *&N& --------- ---------- ----------------------------------------
 *&A&
 *&R& RETURN VALUES:
 *&R&
 *&D& DESCRIPTION:
 */
int
MakPsuSif(pcaTxnCode)
{
  UCP_TRACE(P_MakPsuSif);
  memcpy( g_pstTba->caSif,"TPEI", SIF_FMT_LEN );
  memcpy( g_pstTba->caSif + TXN_CODE_OFFSET,pcaTxnCode,
          g_iTxnCodeLen );
  memcpy( g_pstTba->caSif + BR_CODE_OFFSET,GetBatBrCode(),
          g_iBrhCodeLen );
  memcpy( g_pstTba->caSif + TM_CODE_OFFSET,GetBatTmCode(),
          g_iTmCodeLen );
  memcpy( g_pstTba->caSif + TELLER_CODE_OFFSET,GetBatTellCode(),
          TELLER_CODE_LEN );
  memcpy( &g_pstTba->caSif[ CTL_BYTE_OFFSET ],SIF_CTL_STATUS,
          CTL_BYTE_LEN );
  UCP_TRACE_END( 0 );
}

/*
 *&N& ROUTINE NAME: SetTwaForBatch
 *&A& ARGUMENTS:
 *&N&    TYPE      NAME                 DESCRIPTION
 *&N& --------- ---------- ----------------------------------------
 *&A&     char *pcaApPgmExePath  JCL program �Ҧb���~�ȦW��
 *&A&     char *pcaApPgmName      AP program ���W��
 *&A&
 *&R& RETURN VALUES:
 *&R&
 *&D& DESCRIPTION:
 */
int
SetTwaForBatch(char *pcaApPgmExePath,char *pcaApPgmName)
{
  time_t stCurrTime;
  char *pcTime;

  UCP_TRACE(P_SetTwaForBatch);
  stCurrTime = time( NULL );
  pcTime = ctime( &stCurrTime );

  g_pstTma->stTCFA.cTxnPattern=LOCAL_TXN;
  memset(g_pstTma->stTSSA.caBussDir,0,MAX_NAME_LEN);
  memset(g_pstTma->stTSSA.caPrgName,0,MAX_NAME_LEN);
  strcpy(g_pstTma->stTSSA.caBussDir,pcaApPgmExePath);
  strcpy(g_pstTma->stTSSA.caPrgName,pcaApPgmName);
  g_pstTma->stTCFA.cInDataType=GENERAL_TXN;
  memcpy(g_pstTma->stTSSA.caStartTxnTime, &pcTime[11], 2);
  memcpy(g_pstTma->stTSSA.caStartTxnTime + 2, &pcTime[14], 2);
  memcpy(g_pstTma->stTSSA.caStartTxnTime + 4, &pcTime[17], 2);
  UCP_TRACE_END( 0 );
}

/*
 *&N& ROUTINE NAME: CheckJclFile
 *&A& ARGUMENTS:
 *&N&    TYPE      NAME                 DESCRIPTION
 *&N& --------- ---------- ----------------------------------------
 *&A&     char *pcaJclFileName   JCL program ���W��
 *&A&
 *&R& RETURN VALUES:
 *&R&
 *&D& DESCRIPTION:
 */
int
CheckJclFile(char *pcErrStep,char *pcaJclFileName)
{
  FILE *pzJclFile;

  UCP_TRACE(P_CheckJclFile);
  *pcErrStep = '0';

  if ( (pzJclFile = fopen(pcaJclFileName,"r")) == NULL ) {
    UCP_TRACE_END ( -1 );
  }
  else {
    fclose(pzJclFile);
    UCP_TRACE_END( 0 );
  }

}
int
UnixToCicsSif(pcUnixSif, pcCicsSif)
char *pcUnixSif;
char *pcCicsSif;
{
}
