
/*
 *&N& File : tmmcalap.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int          ApCode               �������ε{�����i�J�I
 */

/* -------------------- INCLUDE FILES DECLARATION ------------------ */
/*
#include "errlog.h"
*/

/* -------------------- CONSTANT  DEFINE   ------------------------- */
#define P_main	         	25300
#define P_ApCode		25301

/* -------------------- STATIC GLOBAL DECLARATION ------------------ */

/* ------ CALL FUNCTION & SUBROUTINE PROTOTYPE DECLARATIONS -------- */
extern int ApMain();
extern int DPCBIFAM();

/*
 *&N& ROUTINE NAME: main(int iArgc,char *pacArgv[])
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                DESCRIPTION
 *&A& ---------  ---------------------    -------------------------
 *&A& pacArgv[1]     char *               TWA SHM �� ID
 *&A&
 *&R& RETURN VALUE(S):
 *&R&
 *&R&    �L
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& ��tmsexec.c��fork()�X�Ӥ�process,�å�execl()�N��child process �m����
 *&D& �i����~�ȵ{��������,��execl()�ǨӤ�TWA Share Memory��ID,�إ߰_����
 *&D& ���ҡC
 *&D&
 */
main(int iArgc,char *pacArgv[])
{
  int iRc ;
  iRc = ApMain(iArgc,pacArgv);
  exit( iRc );
}


/*
 *&N& ROUTINE NAME: ApCode()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                 DESCRIPTION
 *&A&   ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&
 *&R&    �L
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&N& ApCode()����COBOL AP���{���X�C
 *&D&
 */
ApCode(char *pcArg1,char *pcArg2,char *pcArg3)  
{
  /* call individual AP name using apa_buf ctf_buf rev_buf */
  /*  $ucp_ap_link */
  DPCBIFAM(pcArg1,pcArg2,pcArg3);  
}
