/*
 *&N& File : tmmppgen.c
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&                 main()               ����TMS�ѷӪ��w�q��
 */

/* ------------------------- INCLUDE FILES ---------------------------- */
#include <stdio.h>
#include <errno.h>
#include "errlog.h"

/* ------------------------- CONSTANT DEFINITION  --------------------- */

#define  MAX_EXEC_PATH_LEN     80
#define  FILE_NAME_LEN         80
#define  MAX_PPFUN_NUM         3
#define  PPFUN_CNFG_ERR	       -4
#define  OPEN_FILE_ERR	       -5
#define  PPFUN_FILE	 "iii/etc/tbl/txn2fun.dat"
#define  TMS_PPFUN_DEF	 "iii/bin/lib/tmcppfun.def"
#define  TMS_PPFUN_H	 "iii/bin/lib/tmgppfun.h"
#define  PPFUN_H_TMP_FILE   "iii/tmp/ppfun_h.tmp"
#define  PPFUN_DEF_TMP_FILE "iii/tmp/ppfun_def.tmp"

static
struct PrevPostSt {
  char caTxnCode[10];      /* txn code                */
  char caPrevName[20];     /* prev-process AP name    */
  char caPostName[20];     /* post-process AP name    */
} sg_stPrevPost;

extern int  errno;

main()
{
  int i;
  int iRc;
  int iTblSize;
  int iChiPid;
  int iWaitCode;
  char caExePath[MAX_EXEC_PATH_LEN];    /* buf for keep exec path str */
  char caFlName[FILE_NAME_LEN];
  char caPpDefFlName[FILE_NAME_LEN];
  char caSortedFile[FILE_NAME_LEN];
  char caPpDefSortedFile[FILE_NAME_LEN];
  int  iStatus;
  int  iHadLoadNum;
  FILE *zPpFun;
  FILE *zTmsDef;
  FILE *zTmsh;


   memset(caSortedFile,'\0',FILE_NAME_LEN);
   strcpy(caSortedFile,(char *) getenv("III_DIR"));
   strcat(caSortedFile,(char *) "/");
   strcat(caSortedFile,TMS_PPFUN_H);

   memset(caPpDefSortedFile,'\0',FILE_NAME_LEN);
   strcpy(caPpDefSortedFile,(char *) getenv("III_DIR"));
   strcat(caPpDefSortedFile,(char *) "/");
   strcat(caPpDefSortedFile,TMS_PPFUN_DEF);

     /* -------------------- */
     /* get open file name   */
     /* -------------------- */
   memset(caFlName,'\0',FILE_NAME_LEN);
   strcpy(caFlName,(char *) getenv("III_DIR"));
   strcat(caFlName,(char *) "/");
   strcat(caFlName,PPFUN_FILE);

  /* open ifmod file name */
  if((zPpFun=fopen(caFlName,"r")) == NULL){
    printf("tmmppfun:open ems ifmod file=%s errno=%d\n",caFlName,errno);
    exit(OPEN_FILE_ERR);
  } /* FOR if((zPpFun=fopen(caFlname,"r")) == NULL) */

   memset(caPpDefFlName,'\0',FILE_NAME_LEN);
   strcpy(caPpDefFlName,(char *) getenv("III_DIR"));
   strcat(caPpDefFlName,(char *) "/");
   strcat(caPpDefFlName,PPFUN_DEF_TMP_FILE);

  /* open ifmod file name */
  if((zTmsDef=fopen(caPpDefFlName,"w")) == NULL){
    printf("tmmppfun:open tms def file=%s errno=%d\n",caPpDefFlName,errno);
    exit(OPEN_FILE_ERR);
  } /* FOR if((zPpFun=fopen(caFlname,"r")) == NULL) */

   memset(caFlName,'\0',FILE_NAME_LEN);
   strcpy(caFlName,(char *) getenv("III_DIR"));
   strcat(caFlName,(char *) "/");
   strcat(caFlName,PPFUN_H_TMP_FILE);

  /* open ifmod file name */
  if((zTmsh=fopen(caFlName,"w")) == NULL){
    printf("tmmppfun:open tms header file=%s errno=%d\n",caFlName,errno);
    exit(OPEN_FILE_ERR);
  } /* FOR if((zPpFun=fopen(caFlname,"r")) == NULL) */

   i=0;
   while((iRc=fscanf(zPpFun,"%s %s %s\n",
                     sg_stPrevPost.caTxnCode,
                     sg_stPrevPost.caPrevName,
                     sg_stPrevPost.caPostName)) != EOF){
     if(iRc < MAX_PPFUN_NUM){
       printf("tmmppfun: fscanf input %d item < %d\n",iRc,MAX_PPFUN_NUM);
       exit(PPFUN_CNFG_ERR);
     }

    if ( strncmp(sg_stPrevPost.caPrevName,"NULL",4) !=0 ) {
      fprintf(zTmsDef,"\x22%s\x22, %s,\n", sg_stPrevPost.caPrevName,
            sg_stPrevPost.caPrevName);
      fprintf(zTmsh,"extern int %s();\n",sg_stPrevPost.caPrevName);
    }

    if ( strncmp(sg_stPrevPost.caPostName,"NULL",4) !=0 ) {
      fprintf(zTmsDef,"\x22%s\x22, %s,\n", sg_stPrevPost.caPostName,
            sg_stPrevPost.caPostName);
      fprintf(zTmsh,"extern int %s();\n",sg_stPrevPost.caPostName);
    }

   } /* FOR while((iRc=fscanf(....))  */
 
  fclose(zTmsh);
  fclose(zTmsDef);
  fclose(zPpFun);
    
  SortTmsPpH(caFlName,caSortedFile);
  SortTmsPpDef(caPpDefFlName,caPpDefSortedFile);
  printf("Generate tmcppfun.def, tmgppfun.h OK!!\n");
  exit(0);
}


SortTmsPpH(char *pcFileName,char *pcSortedFile)
{
  char caCmdBuf[250];
  sprintf(caCmdBuf,"sort +2 -3 -u < %s > %s",pcFileName,pcSortedFile);
  system(caCmdBuf);
}

SortTmsPpDef(char *pcFileName,char *pcSortedFile)
{
  char caCmdBuf[250];
  sprintf(caCmdBuf,"sort -u < %s > %s",pcFileName,pcSortedFile);
  system(caCmdBuf);
}
