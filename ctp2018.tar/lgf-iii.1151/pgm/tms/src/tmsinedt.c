/* ------------------------- INCLUDE FILES ---------------------------- */
#include "errlog.h"
#include "ucp.h"
#include "twa.h"
#include "tmcinedt.h"
#include "tmctxin.h"
#include "tms.h"
#include "tmcpgdef.h"	/* TMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */

/* ------------------------- CONSTANT DEFINITION ---------------------- */
/* tmsinedt.c 
#define P_EditItem 		24201
#define P_GetCitAddr 		24202
#define P_GetCtfDesc 		24203
#define P_GetItmStartAddr 	24204
#define P_GetSifFmt 		24205
#define P_GetTxnCode 		24206
#define P_InputEdt 		24207
#define P_ReadIet 		24208
#define P_SetTwaByIet 		24209
*/
#define P_UnixToCicsSif 	24210
#define P_EditItemUnixToCics	24211
#define P_StuffDigit        	24212

#define DATA_ATTR_MASK           0x02

/* ------------------ EXTERN VARIABLE DECLARATION --------------------- */
extern char *g_pcIct;
extern char *g_pcCtf;
extern struct TMA *g_pstTma;
extern int g_iTxnCodeLen;       /* Txn code real length  1994/09/14  */
extern int g_iSifLen;
extern char g_cOnBthTxn;

/*Added by baiyj on 1998/10/06 for W000078 begin*/
extern char g_cNeedRelseTrm;
/*Added by baiyj on 1998/10/06 for W000078 end*/

/*Added by baiyj on 1998/10/06 for W000086 begin*/
extern int  g_iTmaTermno;
/*Added by baiyj on 1998/10/06 for W000086 end*/

/*
 *&N& ROUNTINE NAME : InputEdt()
 *&A& ARGUMENTS:
 *&A&   NAME           TYPE         DESCRIPTION
 *&A& ------------ ----------- -----------------------
 *&A&  pcSif        char *      ��J��Ƥ��зǿ�J�榡
 *&A&  pcCtf        char *      ��J������ݦ@�P����榡
 *&A&
 *&R& RETURN VALUE(I);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&   
 *&D& DESCRIPTION:
 *&D&  �̾ڿ�J���зǿ�J�榡(SIF)���O,��ӤU�z�T����:�����J���ؽs���(IET),
 *&D&  �@�P����榡���شy�z��(CFT)�Φ@�P����榡���ت�Ȫ�(CIT),�ഫ��
 *&D&  �@�P����榡(CTF).
 *&D&
 *&D&  i.e  SIF -> CTF 
 */

int
InputEdt(pcSif, pcCtf)
char *pcSif;
char *pcCtf;
{
  int i;
  int iRc;
  char caTxnCode[ MAX_TXN_LEN ];
  busi_head stBusiDesc; /* business name description               */
  txn_head stTxnDesc;   /* transaction characteristic description  */
  txn_item stItmDesc;   /* transcation input item description      */
  busi_ctf stCtfDesc;   /* busi_ctf node description               */
  char *pcCit;          /* the CIT starting address in ICT         */
  char cSifFmt;

  UCP_TRACE( P_InputEdt );

  GetTxnCode( caTxnCode, pcSif );
  /*
   * Add By Chi Fu-Song 1994/07/12
   */
  memcpy(pcCtf,caTxnCode,g_iTxnCodeLen);

  iRc = ReadIet( BUSI_DESC, RANDOM_READ, caTxnCode, (char *)&stBusiDesc );
  if (iRc < 0) {
    sprintf(g_caMsg, "InputEdt:ReadIet() fails!(business node)TxnCode=%.*s",
            g_iTxnCodeLen, caTxnCode);
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( INPUTEDT_BUSI_ERR, g_caMsg );
    UCP_TRACE_END( INPUTEDT_BUSI_ERR );
  }

  iRc = ReadIet( TXN_DESC, RANDOM_READ, caTxnCode, (char *)&stTxnDesc );
  if (iRc < 0) {
    sprintf(g_caMsg, "InputEdt:ReadIet() fails!(transcation node)TxnCode=%.*s",
            g_iTxnCodeLen, caTxnCode);
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( INPUTEDT_TXN_ERR, g_caMsg );
    UCP_TRACE_END( INPUTEDT_TXN_ERR );
  }

  SetTwaByIet( &stBusiDesc, &stTxnDesc );

  /*
   *  business type = the first character of txn code
   */
  iRc = GetCtfDesc( g_pcCtf, caTxnCode[0], (char *)&stCtfDesc );

  if (iRc < 0) {
    sprintf( g_caMsg, "InputEdt: GetCtfDesc() fails! caTxnCode[0]=%c",
             caTxnCode[0] );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( iRc );
  }

  /*
   * Mark by Chi Fu-Song 1994/07/11. Because no function initialize global
   * pointer <g_pcIct>, pcCit can not get correct value from  GetCitAddr().
   */
  GetCitAddr( &pcCit );
  memcpy( pcCtf, pcCit + stCtfDesc.iInitIdx, MAX_CTF_LEN );
/*
  sprintf(g_caMsg, "InputEdt:Ctf.iInitIdx=%d,dump pcCtf", stCtfDesc.iInitIdx);
  ErrLog(100, g_caMsg, RPT_TO_LOG, pcCtf, MAX_CTF_LEN);
*/
  /*
   * Add by Chi Fu-Song 1994/07/15. If Txn has not any input item , then
   * function does not need to call ReadIet() & EditItem()
   */
  if ( stTxnDesc.sTotItem > 0 ) {
    /*
     * begin to convert the first item 
     */
    iRc = ReadIet( ITM_DESC, RANDOM_READ, caTxnCode, (char *)&stItmDesc );
    if (iRc < 0) {
      sprintf(g_caMsg, "InputEdt: ReadIet() fails! (first item node)");
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      DetErrRpt( INPUTEDT_ITM1_ERR, g_caMsg );
      UCP_TRACE_END( INPUTEDT_ITM1_ERR );
    }
    iRc = EditItem( pcSif, pcCtf, &stBusiDesc, &stTxnDesc, &stItmDesc, 0);
    if (iRc < 0) {
      ErrLog(1000, "InputEdt: EditItem() fails! (first item node)",
             RPT_TO_LOG, 0, 0);
      UCP_TRACE_END( iRc );
    }

    /*
     * to convert the other items
     */
    for ( i = 1; i < stTxnDesc.sTotItem; i ++ ) {
      iRc = ReadIet( ITM_DESC, READ_NEXT, caTxnCode, (char *)&stItmDesc );

      if (iRc < 0) {
        sprintf(g_caMsg, "InputEdt: ReadIet() fails! (next item node)");
        ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
        DetErrRpt( INPUTEDT_ITMn_ERR, g_caMsg );
        UCP_TRACE_END( INPUTEDT_ITMn_ERR );
      }
    
      iRc=EditItem(pcSif, pcCtf, &stBusiDesc, &stTxnDesc, &stItmDesc, i);

      if (iRc < 0) {
        ErrLog(1000, "InputEdt: EditItem() fails! (next item node)",
               RPT_TO_LOG, 0, 0);
        UCP_TRACE_END( iRc );
      }
    }
  }

  /*
   *  To convert SIF of format FMT_2 or FMT_3 to standard SIF format (FMT_1)
   */
  iRc = GetSifFmt( (char *)&cSifFmt, pcSif );

  if (iRc < 0) {
    ErrLog(1000, "InputEdt: GetSifFmt() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( iRc );
  }

  if ( cSifFmt == FMT_2 || cSifFmt == FMT_3 ) {
    iRc = CtfToSif( CTF_TYPE, caTxnCode, pcCtf, pcSif );
    if (iRc < 0) {
      ErrLog(1000, "InputEdt: CtfToSif() fails!", RPT_TO_LOG, 0, 0);
      UCP_TRACE_END( iRc );
    }
    g_iSifLen = iRc;
    memcpy(pcSif, SIF_FMT_1, SIF_FMT_LEN);
  }
  UCP_TRACE_END( 0 );
}

int
GetTxnCode( pcTxnCode, pcSif )
char *pcTxnCode;
char *pcSif;
{
  struct SIF *pstSif;

  UCP_TRACE( P_GetTxnCode );

  pstSif = (struct SIF *) pcSif;
  /*
   * get txn code from SIF
   */
  memcpy( pcTxnCode, pstSif->caTxnCode, g_iTxnCodeLen );

  UCP_TRACE_END( 0 );

}

int
ReadIet( cSection, cReadMode, pcTxnCode, pcDescBuf )
char cSection;
char cReadMode;
char *pcTxnCode;
char *pcDescBuf;
{
  int iRc;
  char caKey[ IET_KEY_LEN + 1 ];
 
  UCP_TRACE( P_ReadIet );

  switch( cSection ) {
    case BUSI_DESC:
         strcpy( caKey, "........." );
         caKey[ 0 ] = pcTxnCode[ 0 ];
         break;
    case TXN_DESC:
         strcpy( caKey, "........." );
         memcpy( caKey, pcTxnCode, g_iTxnCodeLen );
         break;
    case ITM_DESC:
         strcpy( caKey, "000001001");
         memcpy( caKey, pcTxnCode, g_iTxnCodeLen );
         break;
  }

  iRc = ImfTblRd( IET, caKey, pcDescBuf, cReadMode );

  if (iRc < 0) {
    UCP_TRACE_END( -1 );
  }

  UCP_TRACE_END( 0 );
}

/*
 *&N& ROUNTINE NAME : GetSifFmt()
 *&A& ARGUMENTS:
 *&A&   NAME           TYPE          DESCRIPTION
 *&A& ------------ ------------ --------------------
 *&A&  pcSifFmt        char *      SIF ���榡���O 
 *&A&
 *&R& RETURN VALUE(I);
 *&R&   0:   valid SIF format
 *&R&  -1:   invalid SIF format
 *&R&   
 *&D& DESCRIPTION:
 *&D&  �̥���N�X�]�w���ݤ��зǿ�J�榡���O :
 *&D&  ���O 1(UCP1): SIF_HEAD + ���Ӹ�ƶ�1 + ���Ӹ�ƶ�1 + ... + ..
 *&D&               ���Ӹ�ƶ�1 : ��ƶ�����(��ڿ�J��ƪ���)
 *&D&                             ��ƶ���(��ڿ�J��ƭ�)
 *&D&                              ��J��l���        ���������
 *&D&                             -------------- ---------------------
 *&D&                      �Ҧp : 124            (��ƶ����� 3,��ƶ��� 124)
 *&D&                             124.00         (��ƶ����� 6,��ƶ��� 124.00)
 *&D&                            +124            (��ƶ����� 4,��ƶ��� +124)
 *&D&                            -124.00         (��ƶ����� 7,��ƶ��� +124.00)
 *&D&              �ϥΥ�����A : ���a�D�����,���ݥD�����
 *&D&
 *&D&  ���O 2(UCP2): SIF_HEAD + ���Ӹ�ƶ�2 + ���Ӹ�ƶ�2 + ... + ..
 *&D&               ���Ӹ�ƶ�2 : ��ƶ���(��J��Ƴ̤j���׭�)
 *&D&                      �Ҧp : ��ƶ��̤j���� 8�Ӧ줸��(BYTES)
 *&D&                              ��J��l���        ���������
 *&D&                             --------------  ---------------------
 *&D&                             "00124.00"       (��ƶ��� "00124.00")
 *&D&                             "+0000124"       (��ƶ��� "+0000124")
 *&D&                             "-0124.00"       (��ƶ��� -124.00)
 *&D&              �ϥΥ�����A : ���P�@�~�t�ΥD�������
 *&D&
 *&D&  ���O 3(UCP3): SIF_HEAD + ���Ӹ�ƶ�3 + ���Ӹ�ƶ�3 + ... + ..
 *&D&               ���Ӹ�ƶ�3 : ��ƶ���(��J��ƪ��ץH�Ҩϥε{���y����
 *&D&                                      �����x�s�覡�өw)
 *&D&
 *&D&              �ϥΥ�����A : �ۦP�@�~�t��,�B�ۦP�{���y���D������P�����,
 *&D&                             �U����I�s DCS ��ͮɸ�ƶǰe�榡
 *&D&
 *&D&
 *&D&
 */

int
GetSifFmt( pcSifFmt, pcSif )
char *pcSifFmt;
char *pcSif;
{
  struct SIF *pstSif;

  UCP_TRACE( P_GetSifFmt );

  pstSif = (struct SIF *) pcSif;

  if (memcmp( pstSif->caSifFmt, SIF_FMT_1, SIF_FMT_LEN ) == 0) {
    *pcSifFmt = FMT_1;
  }
  else if (memcmp( pstSif->caSifFmt, SIF_FMT_2, SIF_FMT_LEN ) == 0) {
    *pcSifFmt = FMT_2;
  }
  else if (memcmp( pstSif->caSifFmt, SIF_FMT_3, SIF_FMT_LEN ) == 0) {
    *pcSifFmt = FMT_3;
  }
  else {  /* invalid SIF format */
    sprintf(g_caMsg, "GetSifFmt: Invlaid SIF format (%.4s)", pstSif->caSifFmt);
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( GETSIFFMT_ERR, g_caMsg );
    UCP_TRACE_END( GETSIFFMT_ERR );
  }

  UCP_TRACE_END( 0 );
}

/*
 *&N& ROUNTINE NAME : GetCtfDesc()
 *&A& ARGUMENTS:
 *&A&   NAME             TYPE        DESCRIPTION
 *&A& ------------   ------------  ---------------------------------
 *&A&  cBusiType      char          �~�ȫ��A    
 *&A&  pcCtfDesc      busi_ctf *    �@�P����榡��ƼȦs�Ϥ���}
 *&A&
 *&R& RETURN VALUE(I);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&   
 *&D& DESCRIPTION:
 *&D&  �̷~�ȫ��A,���o�ӷ~�ȩ��ݤ��@�P����榡��ƭ�,�s�b�Ȧs�ϫ�Ǧ^
 */

int
GetCtfDesc( pcCtf, cBusiType, pcCtfDesc )
char *pcCtf;
char cBusiType;
char *pcCtfDesc;
{
  int i;  
  int iBusiCnt;               /* the number of businesses in this CTF BOOK */
  busi_ctf *pstCtfDescNode;   /* pointer to some busi_ctf node             */
  char *pcCtfBusi;            /* pointer to the first busi_ctf node        */

  UCP_TRACE( P_GetCtfDesc );

  memcpy( &iBusiCnt, pcCtf, sizeof(long) );
  pcCtfBusi = pcCtf + sizeof(long);
/*
  sprintf(g_caMsg, "GetCtfDesc: Business Cnt = %d", iBusiCnt);
  ErrLog(100, g_caMsg, RPT_TO_LOG, 0, 0);
*/

  for (i = 0; i < iBusiCnt; i ++) {
    pstCtfDescNode = (busi_ctf *) ( pcCtfBusi + i * sizeof(busi_ctf) );
    if ( pstCtfDescNode->cBusiType == cBusiType ) {
      memcpy( pcCtfDesc, pstCtfDescNode, sizeof(busi_ctf) );
      UCP_TRACE_END( 0 );  
    }
  }

  sprintf(g_caMsg, "GetCtfDesc: Business type (%c) not found!", cBusiType);
  ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
  DetErrRpt( GETCTFDESC_ERR, g_caMsg );
  UCP_TRACE_END( GETCTFDESC_ERR );
}

/*
 *&N& ROUNTINE NAME : GetCitAddr()
 *&A& ARGUMENTS:
 *&A&   NAME     TYPE                DESCRIPTION
 *&A& --------  ---------  --------------------------------------
 *&A&  pcCit    char **     �@�Υ���榡��ƪ�l�ȰO�аϩ��J�Ҳ�
 *&A&                       �@�Ϊ���O�аϤ��ҩl��}
 *&A&  
 *&R& RETURN VALUE(I);
 *&R&   �L
 *&R&   
 *&D& DESCRIPTION:
 *&D&  ��J�Ҳզ@�Ϊ���O�аϵ��c
 *&D&
 *&D&                  �z�w�w�w�w�w�w�w�w�w�w�w�w�w�{
 *&D&                  �x��J�Ҳզ@�Ϊ�����Y����Ϣx
 *&D& ��ƪ�l�ȰO     �x    ict_head              �x
 *&D& �аϱҩl��}  �w>�u�w�w�w�w�w�w�w�w�w�w�w�w�w�t
 *&D&                  �x      CIT                 �x
 *&D&                  �u�w�w�w�w�w�w�w�w�w�w�w�w�w�t
 *&D&                  �x      GDT                 �x
 *&D&                  �u�w�w�w�w�w�w�w�w�w�w�w�w�w�t
 *&D&                  �x      MDT                 �x
 *&D&                  �u�w�w�w�w�w�w�w�w�w�w�w�w�w�t
 *&D&                  �x      HLP                 �x
 *&D&                  �u�w�w�w�w�w�w�w�w�w�w�w�w�w�t
 *&D&                  �x      MST                 �x
 *&D&                  �|�w�w�w�w�w�w�w�w�w�w�w�w�w�}
 *&D&     
 *&D& 1.�I�s�t�Ψ�Ƴs����J�Ҳզ@�Ϊ���O�а�.
 *&D& 2.���o���Y�����,��ƪ�l�ȰO�аϱҩl��}.
 *&D&     
 */

int
GetCitAddr( ppcCit )
char **ppcCit;
{
  ict_head *pstIctHead;

  UCP_TRACE( P_GetCitAddr );

  pstIctHead = (ict_head *) g_pcIct;
  *ppcCit = g_pcIct + pstIctHead->iCitOffs;

  UCP_TRACE_END( 0 );
}

int
GetItmStartAddr( pcCtf, ppcItmStart )
char *pcCtf;
char **ppcItmStart;
{
  int iBusiCnt;

  UCP_TRACE( P_GetItmStartAddr );

  memcpy( &iBusiCnt, pcCtf, sizeof(long) );
  *ppcItmStart = pcCtf + sizeof(long) + iBusiCnt * sizeof(busi_ctf);

  UCP_TRACE_END( 0 );
}

int
SetTwaByIet( pstBusiDesc, pstTxnDesc )
busi_head *pstBusiDesc;
txn_head *pstTxnDesc;
{
  UCP_TRACE( P_SetTwaByIet );

  memset( g_pstTma->stTSSA.caBussDir, '\0', MAX_NAME_LEN );
  memcpy( g_pstTma->stTSSA.caBussDir,
          pstBusiDesc->caBusiDir, BUSI_DIR_LEN + 1 );
  memset( g_pstTma->stTSSA.caPrgName, '\0', MAX_NAME_LEN );
  memcpy( g_pstTma->stTSSA.caPrgName,
          pstTxnDesc->caTxnPgm, TXN_PGM_LEN + 1 );

  /* pstTxnDesc->cCharc: '3' --> remote txn && '8'--> remote reinput txn */ 
  /* modify by WuChihLiang 19950302 for COOPERATIVE TXN -- Begin */
  if (g_pstTma->stTCFA.cTxnPattern != COOPERATIVE_TXN){
  
    if ( pstTxnDesc->cCharc == '3' || pstTxnDesc->cCharc == '8' ) {  
      g_pstTma->stTCFA.cTxnPattern = REMOTE_TXN;
    }
    else {
      g_pstTma->stTCFA.cTxnPattern = LOCAL_TXN;
    }

  }
  /* modify by WuChihLiang 19950302 for COOPERATIVE TXN -- End */

  /* --- add for REENTRY txn , TPU send a message to DBP to indicate the */
  /* --- txn is been processed, 1995/03/31                               */
  if ( pstTxnDesc->cCharc == '7' ) {
    g_cOnBthTxn = 'y';
  }
  else {
    g_cOnBthTxn = 'n';
  }

  UCP_TRACE_END( 0 );
}

int
EditItem( pcSif, pcCtf, pstBusiDesc, pstTxnDesc, pstItmDesc, iItemNo)
char *pcSif;
char *pcCtf;
busi_head *pstBusiDesc; 
txn_head *pstTxnDesc;   
txn_item *pstItmDesc;  
int iItemNo; /* indicate Seq. No. of item in SIF to be edited */
{
  int iRc;
  char cNeedFmtCnv;
  char cSifFmt;
  int iSifDataLen;
  int iCtfRelatNo;       /* from 0 ... */
  static char *s_pcSifData;       /* pointer to the the first data in SIF */
  char *pcItmStart;      /* The first tbl_item starting address in CTF_BOOK */
  tbl_item  *pstCtfItem; /* transcation input item attribute description    */
  char caSifData[ MAX_SIF_LEN ];  /* buffer for one item data of SIF      */
  char caCtfData[ MAX_CTF_LEN ];  /* buffer for one item data of CTF      */
/*static int s_iItemNo = 0; /x indicate Seq. No. of item in SIF to be edited */
  int  iInputLen;
  

  UCP_TRACE( P_EditItem );

  if ( iItemNo == 0 ) {
    s_pcSifData = pcSif + SIF_HEAD_LEN;
  } 

  cNeedFmtCnv = pstItmDesc->cDatAttr & DATA_ATTR_MASK ;
  if ( ! cNeedFmtCnv ) { /* for no data input field */
/*
    sprintf(g_caMsg,"EditItem: total input Item=%d !",pstTxnDesc->sTotItem); 
    ErrLog(100,g_caMsg, RPT_TO_LOG,0,0);
    sprintf(g_caMsg,"EditItem: Item[%d] is not necessary to be edited!",
            iItemNo);
    ErrLog(100,g_caMsg, RPT_TO_LOG,0,0);
*/
    UCP_TRACE_END( 0 );
  }

  GetItmStartAddr( g_pcCtf, &pcItmStart );
  iCtfRelatNo = pstItmDesc->iCtfRelat - 1;
  pstCtfItem = (tbl_item *)(pcItmStart + iCtfRelatNo * sizeof(tbl_item));

  iRc = GetSifFmt( (char *)&cSifFmt, pcSif );
  if (iRc < 0) {
    sprintf(g_caMsg,"EditItem: GetSifFmt() fails! dump SIF=");
    ErrLog(1000, g_caMsg, RPT_TO_LOG, pcSif , g_iSifLen);
    UCP_TRACE_END( iRc );
  }

  switch( cSifFmt ) {
    case FMT_1:
         iSifDataLen = (unsigned char)s_pcSifData[ HIGH_BYTE ] * 256 + (unsigned char)s_pcSifData[ LOW_BYTE ];
         if (iSifDataLen > pstCtfItem->iDataLen ) {
           sprintf(g_caMsg,"EditItem: edit (%d) item error!",iItemNo);
           ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
           sprintf(g_caMsg,
           "EditItem:SIF data len=%d is larger than CTF data len=%d",
           iSifDataLen,pstCtfItem->iDataLen);
           ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
           ErrLog(1000, "EditItem: dump SIF=", RPT_TO_LOG, pcSif , g_iSifLen);
           DetErrRpt( EDITITEM_LEN_ERR, g_caMsg );

           /*Added by baiyj on 1998/10/06 for W000078 begin*/
           g_cNeedRelseTrm='y';
           /*Added by baiyj on 1998/10/06 for W000078 begin*/

           /*Added by baiyj on 1998/10/06 for W000086 begin*/
           g_iTmaTermno=0;
           /*Added by baiyj on 1998/10/06 for W000086 begin*/

           UCP_TRACE_END( EDITITEM_LEN_ERR );
         }

         if (iSifDataLen == 0) { 
           /* no input data, then set to be initial value */
           switch (pstCtfItem->cDataType) {
             case 'q' :
             case 'r' :
             case 't' :
              iInputLen = pstCtfItem->iDataLen - pstCtfItem->iDotPos - 2;
              break;
             case 'f' :
             case 'g' :
             case 'h' :
              iInputLen = pstCtfItem->iDataLen - pstCtfItem->iDotPos - 1;
              break;
             case 'i' :
             case 'j' :
             case 'k' :
              iInputLen = pstCtfItem->iDataLen - 1;
              break;
             default  :
              iInputLen = pstCtfItem->iDataLen;
           } /* switch (pstCtfItem->cDataType) */
           memset( caSifData, pstCtfItem->cIniValue, iInputLen );
         }
         else {
           memcpy( caSifData, s_pcSifData + 2, iSifDataLen );
           iInputLen = iSifDataLen;
         }

/*
         sprintf(g_caMsg,"EditItem: SIF->CTF caSifData[%d]=",iItemNo); 
         ErrLog(100,g_caMsg,RPT_TO_LOG,caSifData, iSifDataLen);
*/

         iRc = DataCnv( pstCtfItem, caSifData, caCtfData, iInputLen );
         if (iRc < 0) {
           sprintf(g_caMsg,"EditItem: datacnv (%d) item error!",iItemNo);
           ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
           ErrLog(1000, "EditItem: datacnv error , dump SIF=",
                  RPT_TO_LOG, pcSif , g_iSifLen);
           UCP_TRACE_END( iRc );
         }

         s_pcSifData += 2; /* forward 2 bytes (data_len field) for each data */
         break;
    case FMT_2:
         iSifDataLen = pstCtfItem->iDataLen;
         memcpy( caSifData, s_pcSifData, iSifDataLen );

         iRc = DataCnv( pstCtfItem, caSifData, caCtfData, iSifDataLen );
         if (iRc < 0) {
           sprintf(g_caMsg,"EditItem: datacnv (%d) item error!",iItemNo);
           ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
           ErrLog(1000, "EditItem: datacnv error , dump SIF=",
                  RPT_TO_LOG, pcSif , g_iSifLen);
           UCP_TRACE_END( iRc );
         }

         break;
    case FMT_3:
         iSifDataLen = pstCtfItem->iCtfLen;
         memcpy( caCtfData, s_pcSifData, iSifDataLen );
         break;
  }

  s_pcSifData += iSifDataLen; /* forward one data with length iSifDataLen */
  memcpy( pcCtf + pstCtfItem->iCtfOffs, caCtfData, pstCtfItem->iCtfLen );

/*
  sprintf(g_caMsg,"EditItem: SIF->CTF caCtfData[%d]=",iItemNo); 
  ErrLog(100,g_caMsg,RPT_TO_LOG,caCtfData, pstCtfItem->iCtfLen );
*/

  UCP_TRACE_END( 0 );
}
/*
 *&N& ROUNTINE NAME : UnixToCicsSif()
 *&A& ARGUMENTS:
 *&A&   NAME           TYPE         DESCRIPTION
 *&A& ------------ ----------- -----------------------
 *&A&  pcSif        char *      ��J��Ƥ��зǿ�J�榡
 *&A&  pcCtf        char *      ��J������ݦ@�P����榡
 *&A&
 *&R& RETURN VALUE(I);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&   
 *&D& DESCRIPTION:
 *&D&  �̾ڿ�J���зǿ�J�榡(SIF)���O,��ӤU�z�T����:�����J���ؽs���(IET),
 *&D&  �@�P����榡���شy�z��(CFT)�Φ@�P����榡���ت�Ȫ�(CIT),�ഫ��
 *&D&  �@�P����榡(CTF).
 *&D&
 *&D&  i.e  SIF -> CTF 
 */

int
UnixToCicsSif(pcUnixSif, pcCicsSif)
char *pcUnixSif;
char *pcCicsSif;
{
  int i;
  int iRc;
  char caTxnCode[ MAX_TXN_LEN ];
  busi_head stBusiDesc; /* business name description               */
  txn_head stTxnDesc;   /* transaction characteristic description  */
  txn_item stItmDesc;   /* transcation input item description      */
  busi_ctf stCtfDesc;   /* busi_ctf node description               */
  char cSifFmt;

  UCP_TRACE( P_UnixToCicsSif );

  GetTxnCode( caTxnCode, pcUnixSif );

  iRc = ReadIet( BUSI_DESC, RANDOM_READ, caTxnCode, (char *)&stBusiDesc );
  if (iRc < 0) {
    sprintf(g_caMsg,"UnixToCicsSif:ReadIet() fails!(business node),caTxnCode=%s"
            ,caTxnCode);
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( INPUTEDT_BUSI_ERR, g_caMsg );
    UCP_TRACE_END( INPUTEDT_BUSI_ERR );
  }

  iRc = ReadIet( TXN_DESC, RANDOM_READ, caTxnCode, (char *)&stTxnDesc );
  if (iRc < 0) {
    sprintf(g_caMsg,
            "UnixToCicsSif:ReadIet() fails!(transcation node),caTxnCode=%s"
            ,caTxnCode);
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( INPUTEDT_TXN_ERR, g_caMsg );
    UCP_TRACE_END( INPUTEDT_TXN_ERR );
  }

  /*
   *  business type = the first character of txn code
   */
  iRc = GetCtfDesc( g_pcCtf, caTxnCode[0], (char *)&stCtfDesc );

  if (iRc < 0) {
    sprintf( g_caMsg, "UnixToCicsSif: GetCtfDesc() fails! caTxnCode[0]=%c",
             caTxnCode[0] );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( iRc );
  }

  /*
   * Add by Chi Fu-Song 1994/07/15. If Txn has not any input item , then
   * function does not need to call ReadIet() & EditItem()
   */
  if ( stTxnDesc.sTotItem > 0 ) {
    /*
     * begin to convert the first item 
     */
    iRc = ReadIet( ITM_DESC, RANDOM_READ, caTxnCode, (char *)&stItmDesc );
    if (iRc < 0) {
      sprintf(g_caMsg, "UnixToCicsSif: ReadIet() fails! (first item node)");
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      DetErrRpt( INPUTEDT_ITM1_ERR, g_caMsg );
      UCP_TRACE_END( INPUTEDT_ITM1_ERR );
    }

    iRc=EditItemUnixToCics( pcUnixSif, pcCicsSif, &stBusiDesc, &stTxnDesc, 
                            &stItmDesc, 0);
    if (iRc < 0) {
      ErrLog(1000,"UnixToCicsSif:EditItemUnixToCics() fails! (first item node)",
             RPT_TO_LOG, 0, 0);
      UCP_TRACE_END( iRc );
    }

    /*
     * to convert the other items
     */
    for ( i = 1; i < stTxnDesc.sTotItem; i ++ ) {
      iRc = ReadIet( ITM_DESC, READ_NEXT, caTxnCode, (char *)&stItmDesc );

      if (iRc < 0) {
        sprintf(g_caMsg, "UnixToCicsSif: ReadIet() fails! (next item node)");
        ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
        DetErrRpt( INPUTEDT_ITMn_ERR, g_caMsg );
        UCP_TRACE_END( INPUTEDT_ITMn_ERR );
      }
    
      iRc=EditItemUnixToCics(pcUnixSif,pcCicsSif,&stBusiDesc,&stTxnDesc,
                             &stItmDesc, i);

      if (iRc < 0) {
        ErrLog(1000,"UnixToCicsSif:EditItemUnixToCics() fails!(next item node)",
               RPT_TO_LOG, 0, 0);
        UCP_TRACE_END( iRc );
      }
    }
  }
/* added by YEN for handling no input item SOF 950709 begin */
  else {
    iRc=EditItemUnixToCics( pcUnixSif, pcCicsSif, &stBusiDesc, &stTxnDesc, 
                            &stItmDesc, 0);
    if (iRc < 0) {
      ErrLog(1000,"UnixToCicsSif:EditItemUnixToCics() fails! (first item node)",
             RPT_TO_LOG, 0, 0);
      UCP_TRACE_END( iRc );
    }
  } /* for 'if ( stTxnDesc.sTotItem > 0 )' */ 
/* added by YEN for handling no input item SOF 950709 end */
  UCP_TRACE_END( iRc );
}

int
EditItemUnixToCics( pcUnixSif, pcCicsSif, pstBusiDesc, pstTxnDesc, pstItmDesc,iItemNo)
char *pcUnixSif;
char *pcCicsSif;
busi_head *pstBusiDesc; 
txn_head *pstTxnDesc;   
txn_item *pstItmDesc;  
int iItemNo; /* indicate Seq. No. of item in SIF to be edited */
{
  int iRc;
  short sLenOfReentry;
  char cNeedFmtCnv;
  int iSifDataLen;
  int iSifDataLenCics;
  int iCtfRelatNo;       /* from 0 ... */
  char *pcItmStart;      /* The first tbl_item starting address in CTF_BOOK */
  tbl_item  *pstCtfItem; /* transcation input item attribute description    */
  char caSifData[ MAX_SIF_LEN ];  /* buffer for one item data of UnixSIF      */
  char caSifDataCics[ MAX_SIF_LEN ];  /* buffer for one item data of CICS SIF */
/*static int s_iItemNo=0;/xindicate Seq. No. of item in SIF to be edited */
  static char *s_pcSifDataUnix;/* pointer to the the first data in UnixSIF */
  static char *s_pcSifDataCics;/* pointer to the the first data in CicsSIF */
  

  UCP_TRACE( P_EditItemUnixToCics );


  if ( iItemNo == 0 ) {
    memcpy(pcCicsSif, pcUnixSif, SIF_HEAD_LEN );
    if ( g_pstTma->stTCFA.cReentryStatus == TMS_TXN_NOT_REENTRY) {
      /* normal TXN. to TPE/CICS ,added by chi-fusong 1995/03/16 */
      /* copy the UNIX-SIF's first data(reentry-seq-no) len=0 to CICS-SIF */
      memset(pcCicsSif + SIF_HEAD_LEN, 0, 2 );
      s_pcSifDataUnix = pcUnixSif + SIF_HEAD_LEN;
      s_pcSifDataCics = pcCicsSif + SIF_HEAD_LEN + 2;
    }
    else {
      /* Reentry TXN. to TPE/CICS ,added by chi-fusong 1995/03/16 */
      /* copy the UNIX-SIF's first data(reentry-seq-no) len=5 to CICS-SIF */
      s_pcSifDataUnix = pcUnixSif + SIF_HEAD_LEN;
      sLenOfReentry = (unsigned char) (*s_pcSifDataUnix) * 256 + 
                      (unsigned char) *(s_pcSifDataUnix+1) ;
      memcpy(pcCicsSif + SIF_HEAD_LEN, s_pcSifDataUnix, 2 );
      s_pcSifDataUnix += 2;
      memcpy(pcCicsSif + SIF_HEAD_LEN + 2, s_pcSifDataUnix , sLenOfReentry );
      s_pcSifDataUnix += sLenOfReentry;
      s_pcSifDataCics = pcCicsSif + SIF_HEAD_LEN + 2 + sLenOfReentry;
    } 
    /* added by YEN for no-input-field SIF 950709 Begin */
    if ( pstTxnDesc->sTotItem == 0 ) {   
      UCP_TRACE_END( s_pcSifDataCics-pcCicsSif );
    }
    /* added by YEN for no-input-field SIF 950709 End */
  } 

  cNeedFmtCnv = pstItmDesc->cDatAttr & DATA_ATTR_MASK ;
  if ( ! cNeedFmtCnv ) { /* for no data input field */
/*
    sprintf(g_caMsg,"EditItemUnixToCics: total input Item=%d !",
            pstTxnDesc->sTotItem); 
    ErrLog(100,g_caMsg, RPT_TO_LOG,0,0);
   sprintf(g_caMsg,"EditItemUnixToCics:Item[%d] is not necessary to be edited!",
            iItemNo);
    ErrLog(100,g_caMsg, RPT_TO_LOG,0,0);
*/
    UCP_TRACE_END( s_pcSifDataCics-pcCicsSif );
  }

  GetItmStartAddr( g_pcCtf, &pcItmStart );
  iCtfRelatNo = pstItmDesc->iCtfRelat - 1;
  pstCtfItem = (tbl_item *)(pcItmStart + iCtfRelatNo * sizeof(tbl_item));

  iSifDataLen=(unsigned char)s_pcSifDataUnix[ HIGH_BYTE ] * 256 + (unsigned char)s_pcSifDataUnix[ LOW_BYTE ];
  if (iSifDataLen > pstCtfItem->iDataLen ) {
    sprintf(g_caMsg,"EditItemUnixToCics: edit (%d) item error!",iItemNo);
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    sprintf(g_caMsg,
            "EditItemUnixToCics:SIF data len=%d is larger than CTF data len=%d",
            iSifDataLen,pstCtfItem->iDataLen);
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    ErrLog(1000, "EditItemUnixToCics: dump SIF=", RPT_TO_LOG, pcUnixSif , 
           g_iSifLen);
    DetErrRpt( EDITITEM_LEN_ERR, g_caMsg );
    UCP_TRACE_END( EDITITEM_LEN_ERR );
  }

  memcpy( caSifData, s_pcSifDataUnix + 2, iSifDataLen );

/*  sprintf(g_caMsg,"EditItemUnixToCics:before StuffDigit caSifData[%d]=",
          iItemNo); 
  ErrLog(100,g_caMsg,RPT_TO_LOG,caSifData, iSifDataLen); */

  iRc = StuffDigit( pstCtfItem, caSifData, caSifDataCics, iSifDataLen );
  if (iRc < 0) {
    sprintf(g_caMsg,"EditItemUnixToCics: datacnv (%d) item error!",iItemNo);
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    ErrLog(1000, "EditItemUnixToCics: datacnv error , dump SIF=",
           RPT_TO_LOG, pcUnixSif , g_iSifLen);
    UCP_TRACE_END( iRc );
  }

  iSifDataLenCics = iRc;
/*sprintf(g_caMsg,"EditItemUnixToCics:after StuffDigit caSifDataCics[%d]=",
          iItemNo); 
  ErrLog(100,g_caMsg,RPT_TO_LOG,caSifDataCics, iSifDataLenCics); */

  *s_pcSifDataCics = iSifDataLenCics / 256; 
  *(s_pcSifDataCics+1) = iSifDataLenCics % 256; 

  s_pcSifDataUnix += 2; /* forward 2 bytes (data_len field) for each data */
  s_pcSifDataCics += 2; /* forward 2 bytes (data_len field) for each data */

  memcpy(s_pcSifDataCics, caSifDataCics, iSifDataLenCics);

  s_pcSifDataUnix += iSifDataLen; /* forward one data with length iSifDataLen */
  s_pcSifDataCics += iSifDataLenCics; /* forward one data with length 
        				 iSifDataLenCics*/

/* sprintf(g_caMsg,"EditItemUnixToCics: UnixSif->CiCsSif caCtfData[%d]=",
           iItemNo); 
  ErrLog(100,g_caMsg,RPT_TO_LOG,caCtfData, pstCtfItem->iCtfLen ); */

  UCP_TRACE_END( s_pcSifDataCics-pcCicsSif  );
}

int
StuffDigit( pstCtfItem, pcInData, pcOutData, iInDataLen )
tbl_item *pstCtfItem;
char *pcInData;
char *pcOutData;
int iInDataLen;
{
  int i,j;

  UCP_TRACE(P_StuffDigit);

  /* if no digital part the copy pcInData to pcOutData */
  if (pstCtfItem->iDotPos == 0){
    memcpy(pcOutData,pcInData,iInDataLen);
    UCP_TRACE_END(iInDataLen);
  }

  /* copy integer part from pcInData to pcOutData */
  for ( i=0; i < iInDataLen && pcInData[i]!='.' ; i++){
    pcOutData[i] = pcInData[i]; 
  }
  
  /* copy digital part from pcInData to pcOutData, bypass '.'  */
  for(j = 0; j+i+1 < iInDataLen; j++){
    pcOutData[j+i] = pcInData[j+i+1]; 
  }
  
  /* stuff digital part to pcOutData  */
  if (j != pstCtfItem->iDotPos){
    memset(&pcOutData[i+j], '0', pstCtfItem->iDotPos - j);
  }

  UCP_TRACE_END(i+pstCtfItem->iDotPos);

}
