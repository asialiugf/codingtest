/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include <stdlib.h>
#include "twa.h"
#include "errlog.h"
#include "tms.h"
#include "apa.h"
#include "imctblld.def"
#include "tmcpgdef.h"

/* ------------------- global variable ------------------------------ */
#define REINPUT_MSG_MASK    0x20
extern int errno;
extern struct TMA *g_pstTma;
extern struct TBA *g_pstTba;
extern struct ApaSt *g_pstApa;
extern int g_iTxnCodeLen;
extern int g_iSifLen; 
extern char g_cOnBthTxn;
extern int  g_iMsgpFileFd;
extern char g_caReinputBuffer[MAX_SIF_LEN + SOF_HEAD_LEN_PLUS_2];
extern char g_cRqtApiBeenCalled;
extern int GetLastSofOffset();
extern int SetLastSofOffset();

#define MAX_STACK_SIZE	9

struct LinkNode {       /* The vars saved/restored are as follows : */
  char *pcSif;		/* g_pstTba->caSif (dynamic allocation) */
  int  iSifLen;		/* g_iSifLen */
  char caTxnCode[10];	/* g_pstTma->stTSSA.caTxnCode, 
                           g_pstApa->caTxnCode */
  char cTxnReturnCode;	/* g_pstApa->cTxnReturnCode */
  char cApAbendNoRlbk;	/* g_pstApa->cApAbendNoRlbk */
  char cTxnStatus;	/* g_pstApa->cTxnStatus */
  char caBussDir[MAX_NAME_LEN];	/* g_pstTma->stTSSA.caBussDir */
  char caPrgName[MAX_NAME_LEN];	/* g_pstTma->stTSSA.caPrgName */
  char cTxnPattern;	/* g_pstTma->stTCFA.cTxnPattern */
  char cTxnReinput;     /* g_pstTma->stTCFA.cTxnReinput */
  char cOnBthTxn;	/* g_cOnBthTxn */
  char *pcMsgp;		/* g_pstTba->caMsgp (dynamic allocation) */
  int  iMsgpSize;	/* size of memory pointed by pcMsgp */
  /* following lines added by peter 19970624 */
  char *pcReinputBuf;   /* pointer to g_caReinputBuffer */
  char cRevTxn;         /* g_pstTma->stTCFA.cRevTxn */
  char cRvsApRdLogFlag; /* g_pstTma->cRvsApRdLogFlag */
  char cRendoRequest;   /* g_pstTma->cRendoRequest */
  char cTpeWriteMsgKind;/* g_pstTma->stTCFA.cTpeWriteMsgKind */
  int  iApEjCnt;        /* g_pstTma->stTCFA.iApEjCnt */
  int  iApEjLen;        /* g_pstTma->stTCFA.iApEjLen */
  char *pcPost;         /* pointer to g_pstTba->caPost */
  int  iMsgpFileFd;     /* g_iMsgpFileFd */
  int  iLastSofOffset;  /* g_iLastSofOffset */
  char cAprqt;          /* g_pstApa->cAprqt */
  char cRqtApiBeenCalled; /* g_cRqtApiBeenCalled */
};

/* struct MsgBufCtlSt is the same as and copied from tmsoutpt.c */
struct MsgBufCtlSt {
  int iErrMsgCnt;
  int iMsgCnt;
  int iNextOffset;
};

static struct LinkNode sg_staLinkStack[ MAX_STACK_SIZE ];
static int sg_iStackTop=-1;  /* points to the top node of LinkStack */

int InitLinkStack() /* Should be called for each txn beginning */
{
  int i;
  UCP_TRACE(P_InitLinkStack);
  sg_iStackTop = -1;
  for (i=0;i<MAX_STACK_SIZE;i++) {
    memset(sg_staLinkStack[i], 0, sizeof(struct LinkNode));
  }

  UCP_TRACE_END(0);
}

int PushLinkStack()
{
  char *pcSif;
  char *pcMsgp;
  struct MsgBufCtlSt *pstBufCtl;
  int iMsgpSize;
  char *pcReinputBuf;
  char *pcPost;
  int iLen;

  UCP_TRACE(P_PushLinkStack);

  sg_iStackTop ++;
  if (sg_iStackTop >= MAX_STACK_SIZE) {
    sprintf(g_caMsg,"staLinkStack overflow sg_iStackTop=%d, max=%d",
	    sg_iStackTop,MAX_STACK_SIZE);
    ErrLog(4000,g_caMsg,RPT_TO_LOG,0,0);
    sg_iStackTop --;
    UCP_TRACE_END(-1);
  } 
  
  /* For saveing SIF data -begin */
  pcSif = (char *) calloc(g_iSifLen, 1);
  if (pcSif == NULL) {
    sprintf( g_caMsg, "PushLinkStack: pcSif calloc() fails! errno=%d",
             errno );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    sg_iStackTop --;
    UCP_TRACE_END(-1);
  }
  memcpy(pcSif,g_pstTba->caSif,g_iSifLen);
  sg_staLinkStack[sg_iStackTop].pcSif=pcSif;
  /* For saveing SIF data -end */

  sg_staLinkStack[sg_iStackTop].iSifLen=g_iSifLen;
  memcpy(sg_staLinkStack[sg_iStackTop].caTxnCode,
         g_pstTma->stTSSA.caTxnCode, g_iTxnCodeLen);
  sg_staLinkStack[sg_iStackTop].cTxnReturnCode=g_pstApa->cTxnReturnCode;
  sg_staLinkStack[sg_iStackTop].cApAbendNoRlbk=g_pstApa->cApAbendNoRlbk;
  sg_staLinkStack[sg_iStackTop].cTxnStatus=g_pstApa->cTxnStatus;
  memcpy(sg_staLinkStack[sg_iStackTop].caBussDir,
         g_pstTma->stTSSA.caBussDir, BUSI_DIR_LEN + 1);
  memcpy(sg_staLinkStack[sg_iStackTop].caPrgName,
         g_pstTma->stTSSA.caPrgName, TXN_PGM_LEN + 1);
  sg_staLinkStack[sg_iStackTop].cTxnPattern=g_pstTma->stTCFA.cTxnPattern;
  sg_staLinkStack[sg_iStackTop].cTxnReinput=g_pstTma->stTCFA.cTxnReinput;
  sg_staLinkStack[sg_iStackTop].cOnBthTxn=g_cOnBthTxn;

  /* For saveing output data -begin */
  sg_staLinkStack[sg_iStackTop].iMsgpFileFd=g_iMsgpFileFd;
  if(g_iMsgpFileFd < 0) {
    pstBufCtl = (struct MsgBufCtlSt *) (g_pstTba->caMsgp);
    iMsgpSize = sizeof(struct MsgBufCtlSt)+pstBufCtl->iNextOffset;
    pcMsgp = (char *) calloc(iMsgpSize, 1);
    if (pcMsgp == NULL) {
      sprintf( g_caMsg, "PushLinkStack: pcMsgp calloc() fails! errno=%d",
               errno );
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      sg_iStackTop --;
      free(pcSif); 
      UCP_TRACE_END(-1);
    }
    memcpy(pcMsgp,g_pstTba->caMsgp,iMsgpSize);
    sg_staLinkStack[sg_iStackTop].pcMsgp=pcMsgp;
    sg_staLinkStack[sg_iStackTop].iMsgpSize=iMsgpSize;
    sprintf( g_caMsg, "PushLinkStack: dump pcMsgp[%d],iMsgpSize=%d",
	     sg_iStackTop, iMsgpSize);
    ErrLog(100, g_caMsg, RPT_TO_LOG, pcMsgp, iMsgpSize);
  }
  else {
    sg_staLinkStack[sg_iStackTop].pcMsgp=NULL;
    sg_staLinkStack[sg_iStackTop].iMsgpSize=0;
  }
  /* For saveing output data -end */


  /* following lines added by peter 19970624 ----BEGIN---- */
  if(g_caReinputBuffer[SOF_CTL_CODE_OFFSET] & REINPUT_MSG_MASK) {
    iLen=(unsigned char)g_caReinputBuffer[SOF_DATA_LEN_OFFSET]*256 +
	 (unsigned char)g_caReinputBuffer[SOF_DATA_LEN_OFFSET+1] +
	 SOF_HEAD_LEN_PLUS_2;
    pcReinputBuf = (char *) calloc(iLen, 1);
    if (pcReinputBuf == NULL) {
      sprintf( g_caMsg, "PushLinkStack: pcReinputBuf calloc() fails! errno=%d",
               errno );
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      free(pcSif);
      free(pcMsgp);
      sg_iStackTop --;
      UCP_TRACE_END(-1);
    }
    memcpy(pcReinputBuf,g_caReinputBuffer,iLen);
    sg_staLinkStack[sg_iStackTop].pcReinputBuf=pcReinputBuf;
  }
  else {
    sg_staLinkStack[sg_iStackTop].pcReinputBuf=NULL;
  }

  sg_staLinkStack[sg_iStackTop].cRevTxn=g_pstTma->stTCFA.cRevTxn;
  sg_staLinkStack[sg_iStackTop].cRvsApRdLogFlag= \
			        g_pstTma->stTCFA.cRvsApRdLogFlag;
  sg_staLinkStack[sg_iStackTop].cRendoRequest=g_pstTma->stTCFA.cRendoRequest;
  sg_staLinkStack[sg_iStackTop].cTpeWriteMsgKind= \
				g_pstTma->stTCFA.cTpeWriteMsgKind;
  sg_staLinkStack[sg_iStackTop].iApEjCnt=g_pstTma->stTCFA.iApEjCnt;
  sg_staLinkStack[sg_iStackTop].iApEjLen=g_pstTma->stTCFA.iApEjLen;
  if(g_pstTma->stTCFA.iApEjCnt > 0) {
    iLen=SOF_HEAD_LEN_PLUS_2+
	 (g_pstTma->stTCFA.iApEjCnt * g_pstTma->stTCFA.iApEjLen);
    pcPost = (char *) calloc(iLen, 1);
    if (pcPost == NULL) {
      sprintf( g_caMsg, "PushLinkStack: pcPost calloc() fails! errno=%d",
               errno );
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      free(pcSif);
      free(pcMsgp);
      free(pcReinputBuf);
      sg_iStackTop --;
      UCP_TRACE_END(-1);
    }
    memcpy(pcPost,g_pstTba->caPost,iLen);
    sg_staLinkStack[sg_iStackTop].pcPost=pcPost;
  }
  else {
    sg_staLinkStack[sg_iStackTop].pcPost=NULL;
  }
  sg_staLinkStack[sg_iStackTop].iLastSofOffset=GetLastSofOffset();
  sg_staLinkStack[sg_iStackTop].cAprqt=g_pstApa->cAprqt;
  sg_staLinkStack[sg_iStackTop].cRqtApiBeenCalled=g_cRqtApiBeenCalled;

  /* initialing the value of pushed variables */
  memset(g_pstTba->caSif,0,MAX_SIF_LEN);
  g_iSifLen=0;
  memset(g_pstTma->stTSSA.caTxnCode,' ',g_iTxnCodeLen);
  memset(g_pstApa->caTxnCode,' ',g_iTxnCodeLen);
  g_pstApa->cTxnReturnCode=TMS_AP_ACC_NORMAL;
  g_pstApa->cApAbendNoRlbk=' ';
  g_pstApa->cTxnStatus=' ';
  memset(g_pstTma->stTSSA.caBussDir,0,BUSI_DIR_LEN + 1);
  memset(g_pstTma->stTSSA.caPrgName,0,TXN_PGM_LEN + 1);
  g_pstTma->stTCFA.cTxnPattern=LOCAL_TXN;
  g_pstTma->stTCFA.cTxnReinput=TMS_TXN_REINPUT_OFF;
  g_cOnBthTxn='n';
  memset(g_pstTba->caMsgp, 0, MAX_MSGP_LEN);
  memset(g_caReinputBuffer,0,sizeof(g_caReinputBuffer));
  g_pstTma->stTCFA.cRevTxn         = TMS_TXN_NOT_REVERSE;
  g_pstTma->stTCFA.cRvsApRdLogFlag  = TMS_RVSAP_HAS_NOT_BEEN_RD_LOG;
  g_pstTma->stTCFA.cRendoRequest   = TMS_TXN_NOT_RENDO;
  g_pstTma->stTCFA.cTpeWriteMsgKind = TMS_RCV_AP_NORMAL_MSG;
  g_pstTma->stTCFA.iApEjCnt=0;
  g_pstTma->stTCFA.iApEjLen=0;
  memset(g_pstTba->caPost,0,MAX_TBA_POST_LEN);
  g_iMsgpFileFd=-1;
  SetLastSofOffset(0);
  g_pstApa->cAprqt=' ';
  g_cRqtApiBeenCalled=' ';
  /* following lines added by peter 19970624  ----END---- */

  UCP_TRACE_END(0);
}

int PopLinkStack()
{
  char *pcSif;
  char *pcMsgp;
  char *pcReinputBuf;
  int iMsgpSize;
  int iLen;

  UCP_TRACE(P_PopLinkStack); 
  if (sg_iStackTop < 0) {
    sprintf(g_caMsg,"staLinkStack underflow sg_iStackTop=%d",sg_iStackTop);
    ErrLog(4000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  } 

  g_iSifLen=sg_staLinkStack[sg_iStackTop].iSifLen;

  pcSif=sg_staLinkStack[sg_iStackTop].pcSif;
  memset(g_pstTba->caSif, 0, MAX_SIF_LEN);
  memcpy(g_pstTba->caSif,pcSif,g_iSifLen);
  free(pcSif);

  memcpy(g_pstTma->stTSSA.caTxnCode,
         sg_staLinkStack[sg_iStackTop].caTxnCode,g_iTxnCodeLen);
  memcpy(g_pstApa->caTxnCode,
         sg_staLinkStack[sg_iStackTop].caTxnCode,g_iTxnCodeLen);
  g_pstApa->cTxnReturnCode=sg_staLinkStack[sg_iStackTop].cTxnReturnCode;
  g_pstApa->cApAbendNoRlbk=sg_staLinkStack[sg_iStackTop].cApAbendNoRlbk;
  g_pstApa->cTxnStatus=sg_staLinkStack[sg_iStackTop].cTxnStatus;
  memcpy(g_pstTma->stTSSA.caBussDir,
         sg_staLinkStack[sg_iStackTop].caBussDir,BUSI_DIR_LEN + 1);
  memcpy(g_pstTma->stTSSA.caPrgName,
         sg_staLinkStack[sg_iStackTop].caPrgName,TXN_PGM_LEN + 1);
  g_pstTma->stTCFA.cTxnPattern=sg_staLinkStack[sg_iStackTop].cTxnPattern;
  g_pstTma->stTCFA.cTxnReinput=sg_staLinkStack[sg_iStackTop].cTxnReinput;
  g_cOnBthTxn=sg_staLinkStack[sg_iStackTop].cOnBthTxn;

  iMsgpSize=sg_staLinkStack[sg_iStackTop].iMsgpSize;
  if(iMsgpSize > 0) {
    pcMsgp=sg_staLinkStack[sg_iStackTop].pcMsgp;
    memset(g_pstTba->caMsgp, 0, MAX_MSGP_LEN);
    memcpy(g_pstTba->caMsgp,pcMsgp,iMsgpSize);
    sprintf( g_caMsg, "PopLinkStack: dump pcMsgp[%d],iMsgpSize=%d",
	     sg_iStackTop, iMsgpSize);
    ErrLog(100, g_caMsg, RPT_TO_LOG, pcMsgp, iMsgpSize);
    free(pcMsgp);
  }
  
  /* following lines added by peter 19970624 ----BEGIN---- */
  if(sg_staLinkStack[sg_iStackTop].pcReinputBuf != NULL) {
    pcReinputBuf=sg_staLinkStack[sg_iStackTop].pcReinputBuf;
    iLen=(unsigned char)pcReinputBuf[SOF_DATA_LEN_OFFSET]*256 +
	 (unsigned char)pcReinputBuf[SOF_DATA_LEN_OFFSET+1] +
	 SOF_HEAD_LEN_PLUS_2;
    memcpy(g_caReinputBuffer,sg_staLinkStack[sg_iStackTop].pcReinputBuf,iLen);
    free(pcReinputBuf);
  }

  g_pstTma->stTCFA.cRevTxn=sg_staLinkStack[sg_iStackTop].cRevTxn;
  g_pstTma->stTCFA.cRvsApRdLogFlag= \
                   sg_staLinkStack[sg_iStackTop].cRvsApRdLogFlag= \
  g_pstTma->stTCFA.cRendoRequest=sg_staLinkStack[sg_iStackTop].cRendoRequest;
  g_pstTma->stTCFA.cTpeWriteMsgKind= \
                   sg_staLinkStack[sg_iStackTop].cTpeWriteMsgKind;
  g_pstTma->stTCFA.iApEjCnt=sg_staLinkStack[sg_iStackTop].iApEjCnt;
  g_pstTma->stTCFA.iApEjLen=sg_staLinkStack[sg_iStackTop].iApEjLen;
  if(sg_staLinkStack[sg_iStackTop].pcPost != NULL) {
    iLen=SOF_HEAD_LEN_PLUS_2+
	 (g_pstTma->stTCFA.iApEjCnt * g_pstTma->stTCFA.iApEjLen);
    memcpy(g_pstTba->caPost,sg_staLinkStack[sg_iStackTop].pcPost,iLen);
    free(sg_staLinkStack[sg_iStackTop].pcPost);
  }

  g_iMsgpFileFd=sg_staLinkStack[sg_iStackTop].iMsgpFileFd;
  SetLastSofOffset(sg_staLinkStack[sg_iStackTop].iLastSofOffset);
  g_pstApa->cAprqt=sg_staLinkStack[sg_iStackTop].cAprqt;
  g_cRqtApiBeenCalled=sg_staLinkStack[sg_iStackTop].cRqtApiBeenCalled;

  /* following lines added by peter 19970624 ----END---- */

  memset(&sg_staLinkStack[sg_iStackTop], 0, sizeof(struct LinkNode));

  sg_iStackTop --;

  UCP_TRACE_END(0);
}


int
GetStackTop()
{
  return(sg_iStackTop);
}
