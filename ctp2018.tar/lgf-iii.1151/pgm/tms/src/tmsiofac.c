#include <ctype.h>
#include <curses.h>
#include "tmciofac.h"

/* UCPIO command id */

#define	UCP_CLR_SCRN	'1'
#define	UCP_CLR_EOL	'2'
#define	UCP_CLR_BOT	'3'
#define	UCP_MOVE	'4'
#define	UCP_IN		'5'
#define	UCP_OUT		'6'

/* UCPIO data type */

#define	CHINESE_FLD	'C'
#define	ENGLISH_FLD	'E'
#define	ALNUM_FLD	'X'
#define	ALPHA_FLD	'A'
#define	NUM_FLD		'9'
#define	CHINESE_FLD_P	'c'		/* Password chinese field */
#define	ENGLISH_FLD_P	'e'		/* Password english field */
#define	ALNUM_FLD_P	'x'		/* Password alpha-numeric field */
#define	ALPHA_FLD_P	'a'		/* Password alphabetic field */
#define	NUM_FLD_P	'0'		/* Password numeric field */

/* UCPIO return code */

#define	UCPIO_OK	'0'
#define	ERR_CMD_NO	'1'
#define	ERR_CMD_ID	'2'
/*modified on 19970909 by Paul  begin
 *   #define	ERR_DATA_LEN	'3'
 *   #define	ERR_DATA_TYPE	'4'
 */
#define	ERR_DATA_TYPE	'3'
#define	ERR_DATA_LEN	'4'
/*modified on 19970909 by Paul  end    */
#define	ERR_ROW_COL	'5'

#define	MIN_CMD		1
#define	MAX_ROW		24
#define	MIN_ROW		1
#define	MAX_COL		80
#define	MIN_COL		1
#define	MAX_LEN		99
#define	MIN_LEN		1

#define	IS_PASSWORD	& 0x10
#define	IS_CHINESE	& 0x80
#define	CHINESE_SIZE	2
#define	IS_PRINTABLE	>= ' ' && ch <= '~'

#define	CTL_A		0x01
#define	CTL_H		0x08
#define	SPACE		0x20
#define	NL		0x0a

char	*c_string();

/*  move to upcioara  by  YEN 810212
#define	MAX_CMD		5
struct	io_cmd
	{
	char	cmd_id;		/X command id             X/
	char	data_type;	/X input data type        X/
	char	data_len[2];	/X data length            X/
	char	row[2];		/X row of I/O position    X/
	char	col[2];		/X column of I/O position X/
	};

struct	ioarea
	{
	char		cmd_no;			/X toatl command no X/
	struct	io_cmd	cmd[MAX_CMD];		/X command content  X/
	char		cmd_data[MAX_CMD * 99]; /X I/O data         X/
	char		retn_code;		/X return code      X/
	};
*/

struct	wk_cmd		/* working area of command for ucpio */
	{
	char	cmd_id;
	char	data_type;
	int	data_len;
	int	row;
	int	col;
	};

static	char	chinese;
static	int	cur_row;
static	int	cur_col;
static	char	ck_io_parm();

/* used to control StartUcpio & EndUcpio */
static	char	sg_cStartUcpio='n';

TPGIO(cmd_list)
struct	ioarea	*cmd_list;
{
int	i;
int	col;
int	row;
int	data_len;
int	cmd_no;
char	*data_ptr;
char	retn_code;
struct	wk_cmd	cmd;

    StartUcpio();

    cmd_no = atoi(c_string(&(cmd_list->cmd_no), 1));
    if (cmd_no > MAX_CMD || cmd_no < MIN_CMD)
	{
	cmd_list->retn_code = ERR_CMD_NO;
	return;
	}
    data_ptr = cmd_list->cmd_data;
    for (i = 0; i < cmd_no; i ++)
	{
	retn_code = ck_io_parm(cmd_list->cmd[i], &cmd);
	if (retn_code != 0)
	    {
	    cmd_list->retn_code = retn_code;
	    return;
	    }
	switch(cmd.cmd_id)
	    {
	    case UCP_CLR_SCRN :
		clear();
		refresh();
		break;
	    case UCP_CLR_EOL :
		clrtoeol();
		refresh();
		break;
	    case UCP_CLR_BOT :
		clrtobot();
		refresh();
		break;
	    case UCP_MOVE :
		ucp_move(cmd);
		break;
	    case UCP_IN :
		ucp_move(cmd);
		ucp_in(cmd, data_ptr);
		data_ptr = data_ptr + cmd.data_len;
		break;
	    case UCP_OUT :
		ucp_move(cmd);
		ucp_out(cmd, data_ptr);
		data_ptr = data_ptr + cmd.data_len;
		break;
	    }
	}
    cmd_list->retn_code = UCPIO_OK;
}

StartUcpio()
{
  if(sg_cStartUcpio == 'n') {
/*  putenv("TERM=vt220"); */
    initscr();
/*    system("stty onlcr"); */
/* unmark by WuChihLiang 19951107 for SunOS 5.3 */
    noecho();
    raw();
/* unmark by WuChihLiang 19951107 for SunOS 5.3 */

    sg_cStartUcpio='y';
  }
}

EndUcpio()
{
/*
    noraw();
    echo();
*/
  if(sg_cStartUcpio == 'y') {  
    endwin();
    sg_cStartUcpio='n';
  }
}

static	char
ck_io_parm(parm, cmd)
struct	io_cmd	parm;
struct	wk_cmd	*cmd;
{
int	row;
int	col;

    cmd->cmd_id = parm.cmd_id;
    cmd->data_type = parm.data_type;
    cmd->data_len  = atoi(c_string(parm.data_len, 2));
    cmd->row = atoi(c_string(parm.row, 2));
    cmd->col = atoi(c_string(parm.col, 2));
    switch(parm.cmd_id)
	{
	case UCP_CLR_SCRN :
	case UCP_CLR_EOL :
	case UCP_CLR_BOT :
	    return(0);
	case UCP_MOVE :
	case UCP_IN :
	case UCP_OUT :
	    if (cmd->row > MAX_ROW || cmd->row < MIN_ROW)
		return(ERR_ROW_COL);
	    if (cmd->col > MAX_COL || cmd->col < MIN_COL)
		return(ERR_ROW_COL);
	    if (cmd->cmd_id == UCP_MOVE)
		return(0);
	    break;
	default :
	    return(ERR_CMD_ID);
	}
    if (cmd->data_len > MAX_LEN || cmd->data_len < MIN_LEN)
	return(ERR_DATA_LEN);
    if (cmd->cmd_id == UCP_OUT)
	return(0);
    switch(cmd->data_type)
	{
	case CHINESE_FLD :
	case ENGLISH_FLD :
	case NUM_FLD :
	case ALPHA_FLD :
	case ALNUM_FLD :
	case CHINESE_FLD_P :
	case ENGLISH_FLD_P :
	case NUM_FLD_P :
	case ALPHA_FLD_P :
	case ALNUM_FLD_P :
	    return(0);
	default :
	    return(ERR_DATA_TYPE);
	}
}

static
ucp_move(cmd)
struct	wk_cmd	cmd;
{
int	row;
int	col;
int	i;

    i = move(cmd.row - 1, cmd.col - 1);
    i = refresh();
}

static
ucp_out(cmd, data)
struct	wk_cmd	cmd;
char	*data;
{
char	out_data[100];

    memcpy(out_data, data, cmd.data_len);
    out_data[cmd.data_len] = '\0';
    addstr(out_data);
    refresh();
}

static
ucp_in(cmd, data)
struct	wk_cmd	cmd;
char	*data;
{
int	i;
int	ch;
int	buf_len;
int	curn_pos;
int	char_cnt;
int	data_len;
char	end_of_input;
char	insert_mode;
char	ch_buf[3];
char	data_buf[100];
char	data_attr;

    buf_len = cmd.data_len;
    if (isupper(cmd.data_type) || cmd.data_type == NUM_FLD)
	data_attr = 0;
    else
	data_attr = 0x10;	/* Password field */
    for (i = 0; i <= buf_len; i ++)
	data_buf[i] = '\0';
    chinese = 0;
    curn_pos  = 0;
    data_len = 0;
    insert_mode = 0;
    getyx(stdscr, cur_row, cur_col);
    w_lprint(23, 72, "Replace");
    dsp_line(buf_len);
    set_cusr(cur_col, cur_row);
    keypad(stdscr, TRUE);
    ch_buf[2] = '\0';
    end_of_input = FALSE;
    do
	{
	ch = getch();
	switch(ch)
	    {
            case NL :
		end_of_input = TRUE;
                break;
            case KEY_BACKSPACE :
            case CTL_H :
		if (curn_pos == 0)
		    break;
		char_cnt = get_byte_cnt(data_buf, curn_pos - 2);
		curn_pos = curn_pos - char_cnt;
		/* modified on 1996/10/07
                del_char(data_buf, curn_pos, char_cnt, 0);
		*/
                del_char(data_buf, curn_pos, char_cnt, data_attr);
		data_len = strlen(data_buf);
                break;
            case CTL_A :
                dsp_line(buf_len);
                set_cusr(cur_col, cur_row);
                data_len = 0;
		for (i = 0; i < buf_len; i++)
		    data_buf[i] = '\0';
		curn_pos = 0;
                break;
            case KEY_F(10) :		/* Delete Key */
		if (curn_pos >= data_len)
		    break;
		if (is_chinese_code(data_buf[curn_pos]))
		    char_cnt = CHINESE_SIZE;
		else
		    char_cnt = 1;
		/* modified on 1996/10/07
                del_char(data_buf, curn_pos, char_cnt, 0);
		*/
                del_char(data_buf, curn_pos, char_cnt, data_attr);
		data_len = strlen(data_buf);
		break;
            case KEY_LEFT :
		if (curn_pos == 0)
		    break;
		char_cnt = get_byte_cnt(data_buf, curn_pos - 2);
		curn_pos = curn_pos - char_cnt;
        	set_cusr(cur_col + curn_pos, cur_row);
                break;
            case KEY_RIGHT :
		if (curn_pos == data_len || data_len == 0)
		    break;
		if (is_chinese_code(data_buf[curn_pos]))
		    char_cnt = CHINESE_SIZE;
		else
		    char_cnt = 1;
		if (curn_pos == buf_len - char_cnt)
		    break;
		curn_pos = curn_pos + char_cnt;
        	set_cusr(cur_col + curn_pos, cur_row);
                break;
            case KEY_IC :		/* Insert Key */
		insert_mode = ~insert_mode;
		if (insert_mode)
		    w_lprint(23, 72, "Insert ");
		else
		    w_lprint(23, 72, "Replace");
        	set_cusr(cur_col + curn_pos, cur_row);
		break;
	    case KEY_F(11) :	/* Home Key */
		curn_pos = 0;
        	set_cusr(cur_col + curn_pos, cur_row);
                break;
	    case KEY_F(12) :	/* End Key */
		if (data_len == buf_len)
		    curn_pos = data_len - 1;
		else
		    curn_pos = data_len;
        	set_cusr(cur_col + curn_pos, cur_row);
		break;
            default :
		if (ck_data_type(cmd, ch) != 0)
		    break;
		if (chinese)
		    {
		    ch_buf[1] = ch;
		    if (insert_mode)
			char_cnt = ins_char(data_buf, buf_len,
					    ch_buf, curn_pos, data_attr);
		    else
			char_cnt = rep_char(data_buf, buf_len,
					    ch_buf, curn_pos, data_attr);
		    curn_pos = curn_pos + char_cnt;
		    chinese = 0;
		    }
		else
		    {
		    ch_buf[0] = ch;
		    if (ch IS_PRINTABLE)
			{
			ch_buf[1] = '\0';
			if (insert_mode)
			    char_cnt = ins_char(data_buf, buf_len,
						ch_buf, curn_pos, data_attr);
			else
			    char_cnt = rep_char(data_buf, buf_len,
				 		ch_buf, curn_pos, data_attr);
			curn_pos = curn_pos + char_cnt;
			}
		    else
			{
			if (is_chinese_code(ch))
			    chinese = 1;
			else
			    beep();
			}
		    }
		data_len = strlen(data_buf);
		/* modified on 1996/10/07
		if (curn_pos == buf_len)
		*/
		if (data_len >= buf_len)
		    end_of_input = TRUE;
		break;
            }
        }
    while (end_of_input == FALSE);
    keypad(stdscr, FALSE);
    data_len = strlen(data_buf);
    if ((cmd.data_type == NUM_FLD) || (cmd.data_type == NUM_FLD_P))
	{
	for (i = 0; i < buf_len; i ++)
	    data[i] = '0';
	memcpy(&data[buf_len - data_len], data_buf, data_len);
	}
    else
	{
	for (i = 0; i < buf_len; i ++)
	    data[i] = ' ';
	memcpy(data, data_buf, data_len);
	}
    return(0);
}

static
is_chinese_byte(buf, pos)
char	*buf;
int	pos;
{
char	chinese;
int	i;

    chinese = 0;
    for (i = 0; i <= pos; i ++)
	{
	if (chinese)
	    chinese = 0;
	else
	    if (is_chinese_code(buf[i]))
		chinese = 1;
	}
    return(chinese);
}

static
get_byte_cnt(buf, pos)
char	*buf;
int	pos;
{
    if (is_chinese_byte(buf, pos))
	return(CHINESE_SIZE);
    else
	return(1);
}

static
is_chinese_code(byte)
int	byte;
{
    if (byte IS_CHINESE)
	return(1);
    else
	return(0);
}

static
del_char(fld_buf, del_pos, del_cnt, dat_attr)
char	*fld_buf;
int	del_pos;
int	del_cnt;
char	dat_attr;
{
int	i;
int	buf_len;

    buf_len = strlen(fld_buf);
    strcpy(&fld_buf[del_pos], &fld_buf[del_pos + del_cnt]);
    buf_len = buf_len - del_cnt;
    if (!(dat_attr IS_PASSWORD))
	w_lprint(cur_row, cur_col + del_pos, &fld_buf[del_pos]);
    set_cusr(cur_col + buf_len, cur_row);
    for (i = 0; i < del_cnt; i ++)
	{
    	w_putc('_');
	fld_buf[buf_len + i] = '\0';
	}
    set_cusr(cur_col + del_pos, cur_row);
    return(0);
}

static
rep_char(fld_buf, fld_len, rep_str, rep_pos, dat_attr)
char	*fld_buf;
int	fld_len;
char	*rep_str;
int	rep_pos;
char	dat_attr;
{
int	rep_cnt;
int	rep_len;
int	buf_len;
int	i;
char	blank_buf[100];

    rep_len = strlen(rep_str);
    buf_len = strlen(fld_buf);
    if (rep_pos + rep_len > fld_len)
	return(0);
    for (i = 0; i < 80; i ++)
	blank_buf[i] = SPACE;
    blank_buf[i] = '\0';
    if (is_chinese_code(*rep_str))
	{
	if (is_chinese_code(fld_buf[rep_pos]))
	    {
	    if (dat_attr IS_PASSWORD)
		{
		blank_buf[CHINESE_SIZE] = '\0';
		w_puts(blank_buf);
		}
	    else
		w_puts(rep_str);
	    strncpy(&fld_buf[rep_pos], rep_str, rep_len);
	    return(CHINESE_SIZE);
	    }
	else
	    {
	    if (is_chinese_code(fld_buf[rep_pos + 1]))
		{
		strcpy(&fld_buf[rep_pos + CHINESE_SIZE],
		       &fld_buf[rep_pos + CHINESE_SIZE + 1]);
		strncpy(&fld_buf[rep_pos], rep_str, rep_len);
		if (dat_attr IS_PASSWORD)
		    {
		    blank_buf[strlen(fld_buf)] = '\0';
		    w_puts(&blank_buf[rep_pos]);
		    }
		else
		    w_puts(&fld_buf[rep_pos]);
		w_putc('_');
		set_cusr(cur_col + rep_pos + CHINESE_SIZE, cur_row);
		return(CHINESE_SIZE);
		}
	    else
		{
		if (dat_attr IS_PASSWORD)
		    {
		    blank_buf[CHINESE_SIZE] = '\0';
		    w_puts(blank_buf);
		    }
		else
		    {
/* Print blank before display chinese character    BY TSAI 810104 */
/* To prevent unpredict result when the code of 2nd byte is '_' */
		    blank_buf[CHINESE_SIZE] = '\0';
		    w_puts(blank_buf);
		    w_lprint(cur_row, cur_col + rep_pos, rep_str);
		    }
		strncpy(&fld_buf[rep_pos], rep_str, rep_len);
		return(CHINESE_SIZE);
		}
	    }
	}
    else
	{
	if (is_chinese_code(fld_buf[rep_pos]))
	    {
	    strcpy(&fld_buf[rep_pos + 1], &fld_buf[rep_pos + CHINESE_SIZE]);
	    fld_buf[rep_pos] = *rep_str;
	    if (dat_attr IS_PASSWORD)
		{
		blank_buf[strlen(fld_buf)] = '\0';
		w_puts(&blank_buf[rep_pos]);
		}
	    else
	        w_puts(&fld_buf[rep_pos]);
	    w_putc('_');
	    set_cusr(cur_col + rep_pos + 1, cur_row);
	    return(1);
	    }
	else
	    {
	    if (dat_attr IS_PASSWORD)
		w_putc(SPACE);
	    else
		w_puts(rep_str);
	    strncpy(&fld_buf[rep_pos], rep_str, rep_len);
	    return(1);
	    }
	}
}

static
ins_char(fld_buf, fld_len, ins_str, ins_pos, dat_attr)
char	*fld_buf;
int	fld_len;
char	*ins_str;
int	ins_pos;
char	dat_attr;
{
int	ins_len;
int	buf_len;
int	i;
char	blank_buf[100];

    ins_len = strlen(ins_str);
    buf_len = strlen(fld_buf);
    if (ins_pos + ins_len > fld_len)
	return(0);
/*?*/for (i = (buf_len +ins_len - 1); i >= (ins_pos + ins_len); i --)
	if (i < fld_len)
	    fld_buf[i] = fld_buf[i - ins_len];
    strncpy(&fld_buf[ins_pos], ins_str, ins_len);
    if (is_chinese_byte(fld_buf, fld_len - 1))
	{
	for (i = 0; i < CHINESE_SIZE; i ++)
	    fld_buf[fld_len + i - 1] = '\0';
	w_lprint(cur_row, cur_col + fld_len - 1, "_ ");
	}
    if (dat_attr IS_PASSWORD)
	{
	for (i = 0; i < strlen(fld_buf); i ++)
	    blank_buf[i] = SPACE;
	blank_buf[strlen(fld_buf)] = '\0';
	w_lprint(cur_row, cur_col + ins_pos, &blank_buf[ins_pos]);
	}
    else
	{
/* Print blank before display chinese character    BY TSAI 810104 */
/* To prevent unpredict result when the code of 2nd byte is '_' */
	for (i = 0; i < strlen(fld_buf); i ++)
	    blank_buf[i] = SPACE;
	blank_buf[strlen(fld_buf)] = '\0';
	w_lprint(cur_row, cur_col + ins_pos, &blank_buf[ins_pos]);
	w_lprint(cur_row, cur_col + ins_pos, &fld_buf[ins_pos]);
	}
    set_cusr(cur_col + ins_pos + ins_len, cur_row);
    return(ins_len);
}

static
w_lprint(row, col, str)
int	row;
int	col;
char	*str;
{
    mvaddstr(row, col, str);
    refresh();
}

static
w_puts(str)
char	*str;
{
    addstr(str);
    refresh();
}

static
w_putc(ch)
char	ch;
{
    addch(ch);
    refresh();
}

static
set_cusr(col, row)
int	col;
int	row;
{
    move(row, col);
    refresh();
}

static
dsp_line(buf_len)
int   buf_len;
{
int	i;
char	undr_line[100];

    for (i = 0; i < buf_len; i++)
        undr_line[i] = '_';
    undr_line[i] = '\0';
    w_lprint(cur_row, cur_col, undr_line);
}

static
ck_data_type(cmd, ch)
struct	wk_cmd	cmd;
int	ch;
{
    if (chinese)
	return(0);
    switch(cmd.data_type)
	{
	case CHINESE_FLD :
	case CHINESE_FLD_P :
	    if (!is_chinese_code(ch))
		{
		beep();
		return(-1);
		}
	    break;
	case ENGLISH_FLD :
	case ENGLISH_FLD_P :
	    if (is_chinese_code(ch))
		{
		beep();
		getch();
		return(-1);
		}
	    break;
	case ALPHA_FLD :
	case ALPHA_FLD_P :
	    if (!isalpha(ch))
		{
		beep();
		return(-1);
		}
	    break;
	case NUM_FLD :
	case NUM_FLD_P :
	    if ((!isdigit(ch)) && (ch != '.'))
		{
		beep();
		return(-1);
		}
	    break;
	case ALNUM_FLD :
	case ALNUM_FLD_P :
	    if (!isalnum(ch))
		{
		beep();
		return(-1);
		}
	    break;
	}
    return(0);
}

/* ----------------------------------------------------------------- */
/*     character string packing                                      */
/* ----------------------------------------------------------------- */
static
   char  *c_string(char_list,n_char)
   char  *char_list ;
   int   n_char     ;                        
   {
   /*  this procedure can pack character at most 12 chars.           */
       static
       char   char_string[14] ;

       if (n_char <= 12) {
          strncpy(char_string,char_list,n_char) ;
          char_string[n_char] = '\0' ;
       }
       return(char_string) ;
   }
