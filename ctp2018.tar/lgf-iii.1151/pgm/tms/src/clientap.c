/* *&N& File : clientap.c
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int       main()
 */
#include <stdio.h>

#define MAX_SIF_LEN     1000
#define MAX_SOF_LEN     2000
#define MAX_LINE_LEN    256
#define SIF_CICSTXN_OFFSET	0
#define SIF_TXN_OFFSET		4
#define SIF_BRH_OFFSET		10
#define SIF_TERM_OFFSET		20
#define SIF_TELLER_OFFSET	24
#define SIF_DATA_OFFSET		51
#define SOF_BRANCH_OFFSET	3
#define SOF_TERMINAL_OFFSET	13
#define SOF_DEVICE_OFFSET	17
#define SOF_ERRCODE_OFFSET	18
#define SOF_CTLBYTE_OFFSET	25
#define SOF_DATALEN_OFFSET	27
#define SOF_DATA_OFFSET		29
#define LAST_MSG_STATUS      0x80

/*
 *&N& ROUNTINE NAME : main()
 *&D& DESCRIPTION:
 *&D&  Sample program of using TPE client APIs.
 *&D&  Compile:
 *&D&   cc -o clientap.x clientap.c $III_DIR/iii/bin/obj/tpeclientSQ.o \
 *&D&      $III_SOCKET_LIBS
 *&D&
 */

int main()
{
  int iRc;
  int iSifLen;
  int iSofLen;
  int iSofDataLen;
  int iSofCount;
  char cSofCtlByte;
  char caSifBuf[MAX_SIF_LEN];
  char caSofBuf[MAX_SOF_LEN];

  while( 1 ) {
    memset(caSifBuf,0,MAX_SIF_LEN);
    iSifLen = GetSif(caSifBuf);

    iRc = TpeCtSndSif(caSifBuf,iSifLen);
    if ( iRc < 0 ) {
      printf("Error occurs while sending SIF to server\n");
      printf("Return code of TpeCtSndSif = %d\n", iRc);
      exit( 1 );
    }

    iSofCount = 0;
    
    do {
      iRc = TpeCtRcvSof(caSofBuf);
      if ( iRc < 0 ) {
        printf("Error occurs while receiving SOF from server\n");
        printf("Return code of TpeCtRcvSof = %d\n", iRc);
        exit(2);
      }

      /* print SOF header */
      if ( iSofCount != 0 ){
        printf("SOF begin --------------------------------------------\n");
        printf("iSofCount = %d\n", iSofCount);
        printf("Branch   code =[%.10s]\n"  , caSofBuf+SOF_BRANCH_OFFSET);
        printf("Terminal code =[%.4s]\n"   , caSofBuf+SOF_TERMINAL_OFFSET);
        printf("Device   type =[%c]\n"     , caSofBuf[SOF_DEVICE_OFFSET]);
        printf("Form       id =[%.7s]\n"   , caSofBuf+SOF_ERRCODE_OFFSET);
        printf("Status        =[0x%.2x]\n" , (unsigned char)
					       caSofBuf[SOF_CTLBYTE_OFFSET]);
      }

      iSofCount++;

      cSofCtlByte = caSofBuf[SOF_CTLBYTE_OFFSET];

      if ( cSofCtlByte & 0x08 ) {
	printf("Transaction Error Occurs!\n");
	printf("Error Message = [%.7s]\n", caSofBuf+SOF_ERRCODE_OFFSET);
	break;
      }

      if (( cSofCtlByte == 0x80 ) && (iSofCount == 1)){
	printf("Transaction Normally Ended. No Output Result.\n");
        break;
      }

      iSofLen = SOF_DATALEN_OFFSET;
      if(iSofCount > 1){
        printf("SOF Data -->\n");
        iSofDataLen = caSofBuf[iSofLen]*256 + caSofBuf[iSofLen+1];
        iSofLen += 2;
        printf("   id: %.10s\n", caSofBuf+iSofLen); 

        iSofLen += 10;
        printf("   name: %.10s\n", caSofBuf+iSofLen); 

        iSofLen += 10;
        printf("   br-code: %.10s\n", caSofBuf+iSofLen); 

        iSofLen += 10;
        printf("   tm-code: %.4s\n", caSofBuf+iSofLen); 

        iSofLen += 4;
        printf("   ap comm area: %.400s\n", caSofBuf+iSofLen);  
        printf("SOF end ----------------------------------------------\n");
	if(iRc == 1){
       	  printf("Strike any key to print next SOF -> ");
          if(iSofCount == 2) getchar();
	  getchar();
        }
      }
    } while ( iRc == 1 ); 

    printf("\n");
  }  
  
  return( 0 );
}

int GetSif(char *pcSifBuf)
{
  char caID[256];
  char caName[256];
  int iSifLen;

  printf("Please input ID ('q' for quit)  --> ");
  scanf("%s",caID);
  if ( caID[0] == 'q' || caID[0] == 'Q' ) {
      exit(0);
  }
  printf("Please input NAME --> ");
  scanf("%s",caName);

  memcpy(pcSifBuf+SIF_CICSTXN_OFFSET,"TPEI",4);
  memcpy(pcSifBuf+SIF_TXN_OFFSET,"S001",4);
  memcpy(pcSifBuf+SIF_BRH_OFFSET,"2220101",7);
  memcpy(pcSifBuf+SIF_TERM_OFFSET,"02",2);
  memcpy(pcSifBuf+SIF_TELLER_OFFSET,"99",2);

  iSifLen = SIF_DATA_OFFSET;

  pcSifBuf[iSifLen] = strlen(caID)/256;
  pcSifBuf[iSifLen+1] = strlen(caID)%256;
  iSifLen += 2;
  memcpy(pcSifBuf+iSifLen, caID, strlen(caID));
  iSifLen += strlen(caID);

  pcSifBuf[iSifLen] = strlen(caName)/256;
  pcSifBuf[iSifLen+1] = strlen(caName)%256;
  iSifLen += 2;
  memcpy(pcSifBuf+iSifLen, caName, strlen(caName));
  iSifLen += strlen(caName);

  return( iSifLen );
}
