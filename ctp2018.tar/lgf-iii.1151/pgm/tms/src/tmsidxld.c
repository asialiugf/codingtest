/*  Header:   C:\ui\fas2\iom\src\smsidxld.c_v   1.0   15 Dec 1993 11:40:50   OLTPDBP  $  */
/*  $Log:   C:\ui\fas2\iom\src\smsidxld.c_v  $
 *
 *    Rev 1.0   15 Dec 1993 11:40:50   OLTPDBP
 * Initial revision.
 *
 */
/*****************************************************************************/
/*& PROGRAM-NAME:smsidxld.c                                                  */
/*& This program loads the txn_file index file into the memory, to accelerate*/
/*& and simplfy the txn-file search process                                  */
/*****************************************************************************/
/* #include    <io.h>  */
#include    <fcntl.h>
#include    <stdio.h>
#include    <curses.h>
/*
#include    "err_rpt.h"
#include    "err_rpt.glb"  
#include    "sbbs.typ"
#include    "sbbs.glb"
#include    "imcpgdef.def"
*/
#include    "tmcpgdef.h"	/* TMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */
#include    "errlog.h"
#include    "imctblld.def"
#include    "imctblld.str"
#include    "itctblof.str"  /* used for porting              */
#include    "itctxnld.def"  /* new add 2 by Jess Wu 830308   */


struct txn_idx {
    char key[TXN_KEY_LEN+1];            /*& txn_code+pg_no+input_sequence_no] */
};
/* struct hlp_idx {
    char key[GUD_NO_LEN+1];             /x& help-id x/
    long rec_no;                        /x& the record number of the help-id x/
};   */

/*  global to this program file   */
static INT txn_tot_cnt;  /*& number of the records in the txn_file */
static struct txn_idx txn_idx_node;
static INT hlp_tot_cnt;  /*& number of the records in the online help file */
static INT mst_tot_cnt;  /*& number of the records in the online help file */
static struct hlp_idx hlp_idx_node;
static int iet_fp; /*& file descriptor of the txn-file, set in imftxnld() */
static int gdt_fp; /*& file descriptor of the guide-file */
static int hlp_fp; /*& file descriptor of the online help file */
static int rtn_fp; /*& file descriptor of the routine file  */
static int mst_fp; /*& file descriptor of the mst file  */
static char l_txnid[MAX_TXN_LEN+1];
extern int errno;
extern int g_iIctKey;
extern int g_iIetKey;
extern int g_iTxnCodeLen;       /* Txn code real length  1994/09/14  */

/*extern char Tm_type;*/
/*  used for IET & ICT SHM */
int iet_shm_id; /*& IET SHM ID of the txn-file, set in imftxnld() */
int ict_shm_id; /*& ICT SHM ID of the txn-file, set in imftxnld() */
int shmflg,cshmflg;
/* char *iet_ptr,*ict_ptr,*gdt_ptr,*mdt_ptr,*hlp_ptr,*mst_ptr; */
  struct  busi_head_node *busi;
  struct  txn_head_node  *txn;
  struct  txn_item_node  *item;
  char   *gdt_ptr;
  char   *hlp_ptr;
  char   *cit_ptr;
extern char *g_pcIct;
  hlp_head   *hlp_idx_ptr;
  char   *mst_ptr;  /* defined in sbmst.h */
  int     gdt_offs,cit_offs,mdt_offs,hlp_offs,mst_offs,mst_idx_offs;
  /* global variable begin */
  INT     Mdt_cnt;
  struct  menu_node  *Mdt_ptr;
  /* global variable end */

/* global variable for MST begin */
/*
#define    MAX_MST_LINE        1000
static char mst_array[MAX_MST_LINE][MST_NO_LEN+1];
static int mst_total_cnt;
*/
/* global variable for MST end   */
/*****************************************************************************/
/*& ROUTINE-NAME:imftxnld()                                                  */
/*& return value:0 -> load successfully                                      */
/*&             -1 -> load failed                                            */
/*& create the index according to the txn_file to accelerate the txn_file    */
/*& search process in input module process (the index table is txn_id_node[])*/
/*& The file descriptors(iet_fp, gdt_fp, hlp_fp, rtn_fp) will be set in this */
/*& routine, too. After calling this routine, calling routine can get the    */
/*& record from the specified definition file according to the record number.*/
/*& txn_tot_cnt:a global value to this program file, count the number of the */
/*&             total txn count loaded                                       */
/*****************************************************************************/
imftxnld()
{
  char    buff[sizeof(struct busi_head_node)];
  char    temp[20];
  int     j;
  int     idx_tot_cnt;
/*  swa_type  *swa; */

  int     ori_page;      /* add by Jess Wu for multipage 830113  */
  int     item_cnt;      /* number of items in a transaction */

/* -------- for test online help loading ------------begin */
/*
  char    hlp_id[20];
  short   hlppg_ary[30];
  INT     hlp_base_add;
  int     i;
  char    sel_data[20];
*/
/* -------- for test online help loading ------------  end */

    UCP_TRACE(P_imftxnld);
    /* attach IET SHM  */
    iet_size = 0;
    shmflg = 0;
    /*iet_shm_id = shmget(IET_SHM_KEY, iet_size, shmflg);*/
    iet_shm_id = shmget(g_iIetKey, iet_size, shmflg);
    if (iet_shm_id == -1) {
     sprintf(g_caMsg,"imftxnld--IET share memory error,errno=%d",errno);
     ErrLog(41000,g_caMsg,RPT_TO_LOG|RPT_TO_TTY,0,0);
    };
    ietadd  = (char *)shmat(iet_shm_id, 0, 0);
    idxadd  = (char *)(ietadd+4);   /* tot_idx_cnt int type occupy 4 bytes */
    memcpy(&txn_tot_cnt,ietadd,4);
    badd   = (char *)(idxadd+txn_tot_cnt*10);  /* badd = IET data begin addr */

    /* attach ICT SHM  */
    ict_size = 0;
    cshmflg = 0;
    /*ict_shm_id = shmget(ICT_SHM_KEY, ict_size, cshmflg);*/
    ict_shm_id = shmget(g_iIctKey, ict_size, cshmflg);
    if (ict_shm_id == -1) {
     sprintf(g_caMsg,"imftxnld--ICT share memory error,errno=%d",errno);
     ErrLog(41000,g_caMsg,RPT_TO_LOG|RPT_TO_TTY,0,0);
    };
    ict_ptr = (char *)shmat(ict_shm_id, 0, 0);
    g_pcIct  = ict_ptr;
    ict_hd = (ict_head *)ict_ptr;

    /* attach CIT */
    cit_offs = ict_hd->cit_offs;
    cit_ptr  = (char *)(ict_ptr + cit_offs);

    /* attach GDT */
    gdt_offs = ict_hd->gdt_offs;
    gdt_ptr  = (char *)(ict_ptr + gdt_offs);

    /* attach MDT */
    mdt_offs = ict_hd->mdt_offs;
    mdt_size = ict_hd->reserve2;
    Mdt_cnt  = mdt_size / sizeof(struct menu_node) ;
    Mdt_ptr  = (struct menu_node *)(ict_ptr + mdt_offs);

    /* attach HLP and HLP Index Table */
    imfhlpld();

    /* attach MST and MST array Table */
    imfmstld();

    /* open the routine file */
/*
    if ( (rtn_fp=open(DF_rtn_file,O_RDONLY|O_BINARY)) == -1 ) {
      sprintf(g_caMsg,"%s open error ! errno=%d",DF_rtn_file,errno);
      ErrLog(2000,g_caMsg,RPT_TO_LOG|RPT_TO_TTY,0,0);
      UCP_TRACE_END(-1);
    }
*/
    UCP_TRACE_END(0);

}


get_gud(g_relat,g_ptr)
INT g_relat;
struct gud_node *g_ptr;

{
  char rec_no[20];
  int  rc;

   sprintf(rec_no,"%u",g_relat);
   rc=imftblrd(GDT,rec_no,(char *)g_ptr,RANDOM_READ);
   if ( rc != 0 ) {
     sprintf(g_caMsg,"get_gud error, g_relat=%s rc=%d",rec_no,rc);
     ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
     return(-1);
   }
   return(rc);
}

char *get_msg(msg_code)
char *msg_code;
{
  static char msg_cont[MST_CONT_LEN+1];
  int  rc;

  memset(msg_cont,'\0',MST_CONT_LEN+1);
  rc=imftblrd(MST,msg_code,msg_cont,RANDOM_READ);
  if ( rc != 0 ) {
    sprintf(g_caMsg,"get_msg error, msgccode=%s,rc=%d",msg_code,rc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    strcpy(msg_cont,"search MST error");
  }
  return(msg_cont+4);
}
/*****************************************************************************/
/*& ROUTINE-NAME:imftblrd(tbl_name,s_key,buff,op_fun)                        */
/*& tbl_name:(char) the definition file which is going to be searched        */
/*& s_key   :(char *) the key record which is going to be searched           */
/*& buff   :(char *)the record content which found by specification of s_key */
/*& op_fun  :RANDOM_READ -> search the table by s_key                        */
/*&          READ_NEXT   -> search the next item record in a txn_node.  The  */
/*&                         result of using this option to search busi-node  */
/*&                         & txn_node always is NOTFOUND.                   */
/*&          READ_PREV   -> search the previous item record in a txn_node.   */
/*&                         The result of using this option to search        */
/*&                         busi-node & txn_node always is NOTFOUND.         */
/*&          READ_LAST   -> search the last item record in a txn_node.  The  */
/*&                         result of using this option to search busi-node  */
/*&                         & txn_node always is NOTFOUND.                   */
/*& return value:0 -> find the record which calling specified.               */
/*&             -1 -> record not found                                       */
/*&             -2 -> invalid table name                                     */
/*&             -3 -> invalid operation                                      */
/*&                   If the current item record is the 1st record in a txn  */
/*&                   node, then call READ_PREV, the return-code is NOTFOUND */
/*&                   If the current item record is the last record in a txn */
/*&                   node, then call READ_NEXT, the return-code is NOTFOUND */
/*****************************************************************************/

imftblrd(tbl_name,s_key,buff,op_fun)
char tbl_name;
char *s_key;
char *buff;
char op_fun;
{
  static char   gdt_buff[200];
  static char   mst_buff[200];
  static INT l_iet_pt = -1; /*last record position of the txn_file */
  static INT l_dgt_pt = -1; /*last record position of the gud_file */
  static INT l_hlp_pt = -1; /*last record position of the hlp_file */
  static INT l_rtn_pt = -1; /*last record position of the rtn_file */
  static INT l_mst_pt = -1; /*last record position of the mst      */

  static char l_rectype=' ';  /* the last record type read */
                              /* '1' -> business node record */
                              /* '2' -> transaction node record */
                              /* '3' -> item node record */
  int     r_code;
  char    *idxtmp;

  UCP_TRACE(P_imftblrd);
  if ( (op_fun != READ_NEXT) && (op_fun != READ_PREV)
       && (op_fun != READ_LAST) && (op_fun != RANDOM_READ) ) {
     UCP_TRACE_END(INVALID_CMD);
  }

  /* support RANDOM_READ command for HLP, RTN, GDT file only */
  if ( (tbl_name != IET) && (op_fun != RANDOM_READ) ) {
     UCP_TRACE_END(INVALID_CMD);
  }

  switch(tbl_name) {
      case IET: /* search txn_file */
                /* the index table of the txn-file is txn_idx_node */
         switch (op_fun) {
            case RANDOM_READ:
                           /* get the record from index table */
                           if ( iet_srh(&l_iet_pt,s_key) == -1 ) {
                             UCP_TRACE_END(NOTFOUND);
                           }
                           else {
                             if (tbl_read(IET,l_iet_pt,buff) == -1) {
                               ErrLog(40000,"iet file io error",RPT_TO_LOG,
                                       0,0);
                               UCP_TRACE_END(NOTFOUND);
                             }
                           /* set the l_txnid to the txnid of the record read */
                             idxtmp = (char *)(idxadd + l_iet_pt *10) ;
                             memcpy(txn_idx_node.key,idxtmp,10);
                             strncpy(l_txnid,txn_idx_node.key,g_iTxnCodeLen);
                           /* if an item record read ? */

                             if (strncmp(txn_idx_node.key+g_iTxnCodeLen
                               ,".....",TXN_KEY_LEN-g_iTxnCodeLen) != 0) {
                               l_rectype = '3';
                              }
                              else {
                               l_rectype = '2';  
                              }
                              UCP_TRACE_END(FOUND);
                           } /* for if ( iet_srh(&l_iet_pt,s_key) == -1 ) */
                           break;
            case READ_PREV:if ( (l_iet_pt <= 0)||(l_rectype != '3') ) {
                              /* the current index is on the top of index tbl*/
                              /* or last record read is not a item node      */
                              UCP_TRACE_END(NOTFOUND);
                           }
                           idxtmp = (char *)(idxadd + (l_iet_pt-1) *10) ;
                           memcpy(txn_idx_node.key,idxtmp,10);
/* compare the current */  if ((strncmp(l_txnid,txn_idx_node.key,
/* txnid with the last */               g_iTxnCodeLen) == 0) &&
/* record's key and last */    (strncmp(txn_idx_node.key+g_iTxnCodeLen
/* record isn't a txn item */   ,".....",TXN_KEY_LEN-g_iTxnCodeLen) != 0) ) {
                              if ( tbl_read(IET,l_iet_pt-1,buff) == -1 ) {
                                 UCP_TRACE_END(NOTFOUND);
                              }
                              else {
                                 l_iet_pt--; /* update the index pointer */
                                 UCP_TRACE_END(FOUND);
                              }
                           }
                           else {
                              UCP_TRACE_END(NOTFOUND);
                           }
                           break;
            case READ_NEXT:if ( (l_iet_pt == -1) || (l_rectype != '3') ||
                                ((l_iet_pt+1) == txn_tot_cnt) ) {
                             /* last record read is not a item node or the  */
                             /* the pointer is at bottom of the index table */
                              UCP_TRACE_END(NOTFOUND);
                           }
                           idxtmp = (char *)(idxadd + (l_iet_pt+1) *10) ;
                           memcpy(txn_idx_node.key,idxtmp,10);
                           if ( strncmp(l_txnid,txn_idx_node.key,
                                        g_iTxnCodeLen) == 0 ) { /* in a txn */
/*
                              sprintf(g_caMsg,"in 1,l_txnid=%s,next_txnid=%s ",l_txnid,txn_idx_node.key);
                              ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
*/
                              if ( tbl_read(IET,l_iet_pt+1,buff) == -1 ) {
                                 UCP_TRACE_END(NOTFOUND);
                              }
                              else {
                                 l_iet_pt++; /* update the index pointer */
                                 UCP_TRACE_END(FOUND);
                              }
                           }
                           else {
                              UCP_TRACE_END(DIFF_TXN_ID);
                           }
                           break;
            case READ_LAST:/* have not implemented yet */
                           UCP_TRACE_END(INVALID_CMD);
         }   /* for switch (op_fun) */
           break;
      case  GDT: /* search guide file */
                l_dgt_pt = atol(s_key);

                if (tbl_read(GDT,l_dgt_pt,gdt_buff) != 0) {
                   UCP_TRACE_END(NOTFOUND);
                }
                else {
                   memcpy(buff,gdt_buff,sizeof(struct gud_node));
                   UCP_TRACE_END(FOUND);
                }
                break;
      case  HLP: /* search help file */
                break;
      case  RTN: /* search routine file */
                break;
      case  MST: /* search message file */
                r_code = get_mst(s_key);
                l_mst_pt = (long)r_code;
                if (tbl_read(MST,l_mst_pt,mst_buff) != 0) {
                   UCP_TRACE_END(NOTFOUND);
                }
                else {
                   memcpy(buff,mst_buff,sizeof(struct mst_node));
                   UCP_TRACE_END(FOUND);
                }
                break;
      default  : /* invalid table name */
                sprintf(g_caMsg,"invalid table name specified->%c",tbl_name);
                ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
                UCP_TRACE_END(INVALID_NAME);
  }
  UCP_TRACE_END(FOUND);
}
/*****************************************************************************/
/*& ROUTINE-NAME:iet_srh(iet_pt,s_key)                                       */
/*& iet_pt:(INT *) pointer to the record number with key value s_key         */
/*& s_key:(char *) the key string which to be searched in the iet index table*/
/*& return value:0 -> found, and chang the value of the iet_pt               */
/*&             -1 -> notfound, and does not change the value of the iet_pt  */
/*****************************************************************************/
iet_srh(iet_pt,s_key)
INT  *iet_pt;
char *s_key;
{
  INT i;
  int cmp;
  char    *idxtmp;

  UCP_TRACE(P_iet_srh);
  for (i=0; i< txn_tot_cnt; i++) {
     idxtmp = (char *)(idxadd + i*10) ;
     memcpy(txn_idx_node.key,idxtmp,10);
     if ( i > 826 && i < 830){
        sprintf(g_caMsg,"txn_idx_node.key=%.9s",txn_idx_node.key);
        ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
     }
     if ( (cmp = strncmp(s_key,txn_idx_node.key,TXN_KEY_LEN)) == 0 ) {
#ifdef NCR_UNIX
       (INT) (*iet_pt)=i;
#endif
       *iet_pt=i;
       UCP_TRACE_END(FOUND);
     }
 /*  if ( cmp < 0 ) {   /x s_key < txn_idx_node[i].key --> NOTFOUND x/
       UCP_TRACE_END(NOTFOUND);
     }                           */
  }      /*  end for  */
  UCP_TRACE_END(NOTFOUND);
}

/*****************************************************************************/
/*& ROUTINE-NAME:tbl_read(tbl_name,rec_no,buff)                              */
/*& tbl_name:(char) specify which table file is going to be read             */
/*& rec_no:(INT ) the record number that is going to be read                 */
/*& buff:(char *) the content of the record will be returned throuth buff    */
/*& return value:0 -> read the specified record in the table file            */
/*&             -1 -> read error                                             */
/*****************************************************************************/
tbl_read(tbl_name,rec_no,buffer)
char tbl_name;
INT  rec_no;
char *buffer;
{
  long f_offset;
  char *btmp;

  UCP_TRACE(P_tbl_read);
  switch (tbl_name) {
    case IET:
             /* adjust the offset of the record which is going to be read */
             f_offset=rec_no*sizeof(struct busi_head_node);
             btmp = (char *)(badd+f_offset);
             memcpy(buffer,btmp,sizeof(struct busi_head_node));

                UCP_TRACE_END(0);
    case GDT: /* search guide file */
             /* adjust the offset of the record which is going to be read */
             f_offset=rec_no*sizeof(struct gud_node);
             btmp = (char *)(gdt_ptr+f_offset);
             memcpy(buffer,btmp,sizeof(struct gud_node));
                UCP_TRACE_END(0);
    case HLP: /* search help file */
              /* adjust the offset of the record which is going to be read */
             f_offset=rec_no*sizeof(struct help_node);
             btmp = (char *)(hlp_ptr+f_offset);
             memcpy(buffer,btmp,sizeof(struct help_node));
                UCP_TRACE_END(0);
/*  case RTN: /x search routine file x/
             /x adjust the offset of the record which is going to be read x/
             f_offset=rec_no*sizeof(struct routine_node);
             if ( lseek(rtn_fp,f_offset,SEEK_SET) == -1L ) {
                sprintf(g_caMsg,"rtn file lseek error, offset=%u,errno=%d",
                        f_offset,errno);
                ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
                UCP_TRACE_END(-1);
             }
             else {
                if ( read(rtn_fp,buff,sizeof(struct routine_node)) !=
                     sizeof(struct routine_node) ) {
                   sprintf(g_caMsg,"rtn file read error,errno=%d",errno);
                   ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
                   UCP_TRACE_END(-1);
                }
                UCP_TRACE_END(0);
             }
             break;                      */
    case MST: /* search message file */
             f_offset=rec_no*sizeof(struct mst_node);
             btmp = (char *)(mst_ptr+f_offset);  
             memcpy(buffer,btmp,sizeof(struct mst_node));
                UCP_TRACE_END(0);
    default : /* invalid table name */
             sprintf(g_caMsg,"invalid table name specified->%c",tbl_name);
             ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
             UCP_TRACE_END(INVALID_NAME);
  }
  UCP_TRACE_END(0);
}
/* ----------------------------------------------------------------- */
/*         get MST entry procedure                                   */
/* ----------------------------------------------------------------- */
get_mst(msg_code)
char   *msg_code;
{
    int     min_inx , mid_inx , max_inx ;
    char    *tmp_ptr;

    min_inx = 0 ;
    max_inx = mst_tot_cnt;
    do {
        mid_inx = (min_inx + max_inx) / 2 ;
        tmp_ptr = (char *)(mst_array_ptr + 4 * mid_inx ) ;
        if (strncmp(msg_code,
                    tmp_ptr,MST_NO_LEN)<=0)
            max_inx = mid_inx - 1 ;
        if (strncmp(msg_code,
                    tmp_ptr,MST_NO_LEN)>=0)
            min_inx = mid_inx + 1 ;
    } while(min_inx <= max_inx) ;
    if (min_inx - 1 > max_inx)
        return(mid_inx) ;
    else
        return(0) ;
}

/*****************************************************************************/
/*& ROUTINE-NAME:imfhlpmk(hlp_id,hlppg_ary,hlp_base_add)                     */
/*& hlp_id:(char *)-> the id of the online help to be retrieved              */
/*& hlppg_ary (short *) -> �O���C�@���Ĥ@��۹��� help id �� ����          */
/*& hlp_base_add (INT *) -> �� help ���Ĥ@����help file �� record no         */
/*& return value:0 -> help id found and the content of the hlppg_ary are set */
/*&             -1 -> help id not found                                      */
/*& create the page index array according to the online help file            */
/*****************************************************************************/
imfhlpmk(hlp_id,hlppg_ary,hlp_base_add)
char  *hlp_id;
short *hlppg_ary;
INT   *hlp_base_add;
{
 struct  hlp_idx *buff_ptr;
 struct  help_node buff;
 int i,j;
 char c_win_len[3];
 int win_len;
 long  offset;

 j=0;
 for (i=0; i < hlp_tot_cnt; i++ ) {
   offset = i*sizeof(hlp_head);
   buff_ptr = (struct hlp_idx *)(hlp_idx_ptr + i);
   if ( strncmp(hlp_id,buff_ptr->key,GUD_NO_LEN) == 0 ) {
     if ( tbl_read(HLP,buff_ptr->rec_no,&buff) == -1 ) {
        sprintf(g_caMsg,"help rec %d read error !",buff_ptr->rec_no);
        ErrLog(2000,g_caMsg,RPT_TO_LOG,0,0);
        return(-1);
     }
     *hlp_base_add=buff_ptr->rec_no;
     hlppg_ary[0]=1;
     j++;
     /* get the length of the window */
     memcpy(c_win_len,buff.hlp_line+5,2); /*type(1)+X(2)+Y(2)+LEN(2)+WIDTH(2)*/
     c_win_len[2]='\0';
     win_len=atoi(c_win_len);
     while(1) {
        /* number of the help lines of a page = window length -2 */
       if (tbl_read(HLP,(*hlp_base_add)+hlppg_ary[j-1]+win_len-2,&buff) != -1) {
         if ( strncmp(hlp_id,buff.hlp_no,GUD_NO_LEN) == 0 ) {
            hlppg_ary[j]=hlppg_ary[j-1]+win_len-2; /* reserve 2 lines for */
            j++;                                   /* showing the edges   */
         }
         else {
            break;
         }
       }
       else {
         break;
       }
     }  /* for while(1) */
     return(0);    /* help id is found */
   }
 }  /* for 'for (i=0; i < hlp_tot_cnt; i++ ) ' */
 return(-1);     /* help id is not found */
}

/* ******************************************************************** */
/*      imfmdtld() : menu data description table load                   */
/* ******************************************************************** */
int   imfmdtld(node_cnt,menu_ptr)
INT   *node_cnt;
struct menu_node *menu_ptr;
{
    /*  this routine had been done in imftxnld()  */
    /*  attach the MDT SHM                        */
    return(0) ;
}
/****************************************************************************x/
/x& ROUTINE-NAME:imfmstld()                                                  x/
/x& return value:0 -> load successfully                                      x/
/x&             -1 -> load failed                                            x/
/x& create the index according to the mst      to accelerate the mst         x/
/x& search process in input module process (the index table is txn_id_node[])x/
/x& The file descriptors(iet_fp, gdt_fp, hlp_fp, rtn_fp) will be set in this x/
/x& routine, too. After calling this routine, calling routine can get the    x/
/x& record from the specified definition file according to the record number.x/
/x& txn_tot_cnt:a global value to this program file, count the number of the x/
/x&             total txn count loaded                                       x/
/x***************************************************************************x/
imfmstld()
{
    /x attach SWA SHM  x/
    swa_shm_id = shmget(SWA_SHM_KEY, 0, 0);
    if (swa_shm_id == -1) {
     sprintf(g_caMsg,"imftxnld--SWA share memory error,errno=%d",errno);
     ErrLog(41000,g_caMsg,RPT_TO_LOG|RPT_TO_TTY,0,0);
     return(-1);
    };
    swa = (swa_type *)shmat(swa_shm_id, 0, 0);
    mst_ptr = (char *)(&(swa->mst.mesg[0]));
    return(0);
}
*/
/******************************************************************************/
/*& ROUTINE-NAME:imfhlpld()                                                   */
/*& return value:0 -> load successfully                                       */
/*&             -1 -> load failed                                             */
/*& create the index according to the helpfile to accelerate the online help  */
/*& search process in input module process (the index table is hlp_idx_node[])*/
/*& The file descriptor hlp_fp has been set in imftxnld() routine.            */
/*& hlp_tot_cnt:a global value to this program file, count the number of the  */
/*&             total online help records loaded.                             */
/******************************************************************************/
imfhlpld()
{
    hlp_offs = ict_hd->hlp_offs;
    hlp_ptr  = (char *)(ict_ptr + hlp_offs);
    hcnt_add = (char *)(ict_ptr+sizeof(ict_head));
    hlp_idx_ptr = (hlp_head *)(hcnt_add + 4); 
    memcpy(&hlp_tot_cnt,hcnt_add,4);
    return(0);
}
/*****************************************************************************/
/*& ROUTINE-NAME:imfmstld()                                                  */
/*& return value:0 -> load successfully                                      */
/*&             -1 -> load failed                                            */
/*& create the index according to the mst      to accelerate the mst         */
/*& search process in input module process (the index table is txn_id_node[])*/
/*& The file descriptors(iet_fp, gdt_fp, hlp_fp, rtn_fp) will be set in this */
/*& routine, too. After calling this routine, calling routine can get the    */
/*& record from the specified definition file according to the record number.*/
/*& txn_tot_cnt:a global value to this program file, count the number of the */
/*&             total txn count loaded                                       */
/*****************************************************************************/
imfmstld()
{ 
    int   mst_idx_offs;

    mst_offs = ict_hd->mst_offs;
    mst_idx_offs = ict_hd->mst_idx_offs;
    mst_ptr  = (char *)(ict_ptr + mst_offs);
    mcnt_add = (char *)(ict_ptr+ mst_idx_offs);
    mst_array_ptr = (char *)(mcnt_add + 4); 
    memcpy(&mst_tot_cnt,mcnt_add,4);
    return(0);
}
