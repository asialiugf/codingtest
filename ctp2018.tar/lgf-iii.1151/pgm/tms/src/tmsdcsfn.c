/* ------------------------- INCLUDE FILES ---------------------------- */
#include "errlog.h"
#include "ucp.h"
#include "dcs.h"
#include "tmcpgdef.h"	/* TMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */
#include "tmc.h"
/* add by chi-fusong , 1995/03/26 */
#include "tmcerror.h"
#include "twa.h"
#include "tms.h"

/* ------------------------- CONSTANT DEFINITION ---------------------- */
/* tmsdcsfn.c 
#define P_GetInput 		24101
#define P_TmsDataSend 		24102
#define P_SendErrToDbp 		24103
#define P_SendAckToEms 		24104
#define P_SendShutOkToEms	24105
#define P_GetAck        	24106
#define P_ReqEmsToRestart      	24107
#define P_RcvTmsRestartStus   	24108
#define P_GetEmsDisconnect 	24110
#define P_SendDisconnect 	24111
#define P_RcvTmsShutStus   	24112
#define P_DoDcsAbort		24113
*/
/* define error message code */
#define RECEIVE_SIF_ERR         -1
#define SEND_SOF_ERR            -2
#define SEND_MSG_ERR            -3
#define RECEIVE_ACK_ERR         -4
#define RECEIVE_STATUS_ERR      -5
#define RESTART_TMS_ERR         -6
#define RECEIVE_DISCONNECT_ERR  -7
#define SEND_DISCONNECT_ERR     -8

#define PROTOCOL_TYPE		"III_PROTOCOL"
#define QUEUE_DCS		'Q'
#define CENTER_HOST_DES		"0000000000"
#define DEST_NAME_LEN		10
#define CONV_OUT	   1

/* add by chi-fusong, 1995/03/26 */
#define ERR_MSG_STATUS           "\x88\x00"
#define REENTRY_ERR_CONT         "\xc8\x00"
/* ------------------------- VARIABLE DECLARATION --------------------- */
static int sg_iSessIdx;
static int sg_iSessEmsIdx;
static int sg_iSessRestartTms;
static char sg_caDestCode[DEST_NAME_LEN];

static char g_cProtocoltype = '\0';
extern struct TpuMap g_stPrgIdTbl[MAX_PROGRAM];	/* SERVER �ݵ{���N�X���� */

/* ------------------EXTERN  VARIABLE DECLARATION --------------------- */
extern int g_iTmCodeLen;       /* Txn code real length          */
extern int g_iBrhCodeLen;      /* Branch code real length       */
extern int g_iToffset;

/* add by chi-fusong, 1995/03/26 */
extern struct TMA *g_pstTma;

/*
 *&N& ROUTINE NAME:GetInput()
 *&A& ARGUMENTS:
 *&A&    NAME         TYPE            DESCRIPTION
 *&A& -------------  ------  -------------------------------
 *&A&  pcInputData    char*   �����ѿ�X�J�Ҳհe�ӿ�J�����
 *&A&
 *&R& RETURN VALUE(S):
 *&R&  0 : ������J��ƪ�����
 *&R& -1 : ������J��ƥ���
 *&R&
 *&D& DESCRIPTION
 *&D& �ھڳq�T��w�����ܼ�( �t��_PROTOCOL ) 
 *&D& �I�s�����A�ȵ{�������ѿ�J�Ҳհe�Ӥ����
 *&D&
 */

int
GetInput(paInputData)
char *paInputData;
{
  char caProtoType[80];  /* enviroment variable buffer */
  struct DcsBuf stDcsBuf;
  struct DcsSiof stDcsSiof;

  UCP_TRACE( P_GetInput );

  if (g_cProtocoltype == '\0') {
    memset(caProtoType, '\0', 80);
    strcpy(caProtoType, (char *)getenv( PROTOCOL_TYPE ));
    if (caProtoType[0] != '\0') {
      g_cProtocoltype = caProtoType[0];
    }
    else {
      g_cProtocoltype = QUEUE_DCS;
    }
  }

  MpstDcsSiof(stDcsBuf) = &stDcsSiof;
  memcpy(McaDesCode(stDcsBuf), sg_caDestCode, DEST_NAME_LEN);
  McRqstCode(stDcsBuf) = DCSACCEPTREAD;
  MlWaiTime(stDcsBuf) = DCS_BLOCK;
  MiDataLen(stDcsBuf) = DCS_MAX_DATA_LEN;
  McProto(stDcsBuf) = g_cProtocoltype;

  DcsDispatch( &stDcsBuf );

  if (MiReply(stDcsBuf) != DCS_NORMAL) {
    sprintf( g_caMsg, "GetInput: DcsDispatch() fails! reply=%d",
             MiReply(stDcsBuf) );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( RECEIVE_SIF_ERR, g_caMsg );
    UCP_TRACE_END( RECEIVE_SIF_ERR );
  }

  sg_iSessIdx = MiSesIdx(stDcsBuf);
/*
  ErrLog(100,"GetInput() sg_iSessIdx:",RPT_TO_LOG,&sg_iSessIdx,sizeof(int));
*/

  memcpy(paInputData, McaData(stDcsBuf), MiDataLen(stDcsBuf)-8);

  if ( paInputData[CTL_BYTE_OFFSET] & COOPERATIVE_MASK ) {
    g_stPrgIdTbl[0].iSesIdx = sg_iSessIdx ;
    g_stPrgIdTbl[0].cProto  = g_cProtocoltype;
  }
/*
  ErrLog(100,"tmsdcsfn.c SIF =",RPT_TO_LOG,paInputData, 
         MiDataLen(stDcsBuf)-8);
*/

  UCP_TRACE_END( MiDataLen(stDcsBuf) - 8 );
}


/*
 *&N& ROUTINE NAME:TmsDataSend()
 *&A& ARGUMENTS:
 *&A&    NAME         TYPE            DESCRIPTION
 *&A& -------------  ------  -------------------------------
 *&A&
 *&R& RETURN VALUE(S):
 *&R&  0 : ������J��Ʀ��\
 *&R& SEND_SOF_ERR : ������J��ƥ���
 *&R&
 *&D& DESCRIPTION
 *&D&
 */
int
TmsDataSend(iDataLen, caData, cMoreData, piDcsRtnCode)
int iDataLen;
char *caData;
char cMoreData;
int *piDcsRtnCode;
{
  char caProtoType[80];  /* enviroment variable buffer */
  static struct DcsBuf stDcsBuf;
  static struct DcsSiof stDcsSiof;

  UCP_TRACE( P_TmsDataSend );

/*
  ErrLog(100,"TmsDataSend() DATA:",RPT_TO_LOG,caData,iDataLen);
  ErrLog(100,"TmsDataSend() FLAG:",RPT_TO_LOG,&cMoreData,1);
  ErrLog(100,"TmsDataSend() sg_iSessIdx:",RPT_TO_LOG,&sg_iSessIdx,sizeof(int));
*/

  memset(&stDcsBuf,0,sizeof(struct DcsBuf));
  memset(&stDcsSiof,0,sizeof(struct DcsSiof));

  if (g_cProtocoltype == '\0') {
    memset(caProtoType, '\0', 80);
    strcpy(caProtoType, (char *)getenv( PROTOCOL_TYPE ));
    if (caProtoType[0] != '\0') {
      g_cProtocoltype = caProtoType[0];
    }
    else {
      g_cProtocoltype = QUEUE_DCS;
    }
  } 

  MpstDcsSiof(stDcsBuf) = &stDcsSiof;
  McMoreByte(stDcsBuf) = cMoreData;
  memcpy(McaDesCode(stDcsBuf), sg_caDestCode, DEST_NAME_LEN);

  if (cMoreData != '1') {
    McRqstCode(stDcsBuf) = DCSWRDISCONECT;
  }
  else {
    McRqstCode(stDcsBuf) = DCSWRITE;
  }

  sprintf(McaDataLen(stDcsBuf),"%.5d",iDataLen + 8);
  memcpy(McaData(stDcsBuf), caData, iDataLen);
/*
  ErrLog(100,"TmsDataSend() McaDataLen:",RPT_TO_LOG,McaDataLen(stDcsBuf),5);
*/
  MiDataLen(stDcsBuf) = iDataLen + 8;
  McProto(stDcsBuf) = g_cProtocoltype;
  /*
   * Add by Chi Fu-Song   1994/07/19 
   * Assign Sessin id to stDcsBuf.stDcsInfo.iSesIdx
   */
  MiSesIdx(stDcsBuf) = sg_iSessIdx ;

/*
  ErrLog(100,"TmsDataSend() DcsBuf.DcsInfo:",RPT_TO_LOG,&stDcsBuf.stDcsInfo,
       sizeof(struct DcsBuf) );
  ErrLog(100,"TmsDataSend() DcsBuf.unData:",RPT_TO_LOG,
       stDcsBuf.unData.pstDcsSiof,200);
*/
      
  DcsDispatch( &stDcsBuf );
  *piDcsRtnCode = MiReply(stDcsBuf);

  if (MiReply(stDcsBuf) != DCS_NORMAL) {
    sprintf( g_caMsg, "TmsDataSend: DcsDispatch() fails! reply=%d",
             MiReply(stDcsBuf) );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( SEND_SOF_ERR, g_caMsg );
    UCP_TRACE_END( SEND_SOF_ERR );
  }
  
  UCP_TRACE_END( 0 );
}



/*
 *&N& ROUTINE NAME:SendErrToDbp()
 *&A& ARGUMENTS:
 *&A&    NAME         TYPE            DESCRIPTION
 *&A& -------------  ------  -------------------------------
 *&A&
 *&R& RETURN VALUE(S):
 *&R&  0 : ������J��Ʀ��\
 *&R& -1 : ������J��ƥ���
 *&R&
 *&D& DESCRIPTION
 *&D&
 */
int
SendErrToDbp(char *pcBrCode,char *pcTmCode,char *pcErrCode)
{
  int iRc;
  char caProtoType[80];  /* enviroment variable buffer */
  static struct DcsBuf stDcsBuf;
  static struct DcsSiof stDcsSiof;
  static char caErrSof[SOF_HEAD_LEN_PLUS_2];
  int   iDcsRtnCode;
  char caDataFmt[SIF_FMT_LEN+1];
  char caCnvOutBuff[1024];
  int (*GetConvPgm(char *,int))();
  int (*pfConvOutPgm)();

  UCP_TRACE( P_SendErrToDbp );
  memset(caErrSof, 0 , SOF_HEAD_LEN_PLUS_2);
  memcpy(caErrSof+SOF_BR_CODE_OFFSET, pcBrCode, g_iBrhCodeLen);
  memcpy(caErrSof+SOF_TM_CODE_OFFSET, pcTmCode, g_iTmCodeLen);
  memcpy(caErrSof+SOF_MSG_CODE_OFFSET, pcErrCode, SOF_MSG_CODE_SIZE);

/*Modified by WuChihLiang 19950510 for 7 bytes message  code*/
  memcpy(caErrSof+SOF_MSG_CODE_OFFSET, pcErrCode, SOF_MSG_CODE_LEN);
/*
      memcmp(pcErrCode,INPUT_EDT_BUSI_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
  --> memcmp(pcErrCode+3,INPUT_EDT_BUSI_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
  */

  /* add by chi-fusong, 1995/03/26 */
  if ( g_pstTma->stTCFA.cReentryStatus == TMS_TXN_REENTRY ) {
    if ( memcmp(pcErrCode+3,REENTRY_CHK_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,INPUT_EDT_BUSI_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,INPUT_EDT_TXN_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,INPUT_EDT_ITM1_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,INPUT_EDT_ITMn_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,GET_SIF_FMT_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,EDIT_ITEM_LEN_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,COMP3_CNV_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,SHORT_CNV_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,LONG_CNV_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,ASI_CNV_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,ASCII_CNV_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,SASCII_CNV_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,CTF_TO_SIF_BUSI_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,CTF_TO_SIF_TXN_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,CTF_TO_SIF_ITM1_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,CTF_TO_SIF_ITMn_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,CTF_TO_SIF_CNV_ITM1_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,CTF_TO_SIF_CNV_ITMn_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,TXN_TYPE_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,RENDO_REQUEST_ERR_E51,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,TXN_PATTERN_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,AP_NOT_EXIST_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,AP_EXE_NOT_EXIST_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,AP_ABEND_EXIT_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,AP_ABEND_NO_RLBK_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,INPUT_TXN_TYPE_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,RENDO_REQUEST_ERR_E65,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,AP_NORMAL_END_BUT_SND_MXXX_MSG_E,SOF_MSG_CODE_SIZE)==0 ||
      memcmp(pcErrCode+3,AP_ABNORMAL_END_BUT_SND_TXXX_E,SOF_MSG_CODE_SIZE)==0 ||
      memcmp(pcErrCode+3,TPEWRITE_CALL_SEQ_ERR_E,SOF_MSG_CODE_SIZE) == 0 ||
      memcmp(pcErrCode+3,GET_SEQINT_ERR_E,SOF_MSG_CODE_SIZE) == 0 )
    {
      memcpy(caErrSof+SOF_CTL_CODE_OFFSET, REENTRY_ERR_CONT, SOF_CTL_CODE_SIZE);
    }
    else {
      memcpy(caErrSof+SOF_CTL_CODE_OFFSET, ERR_MSG_STATUS, SOF_CTL_CODE_SIZE);
    }
  }
  else {
    memcpy(caErrSof+SOF_CTL_CODE_OFFSET,ERR_MSG_STATUS,SOF_CTL_CODE_SIZE);
  }

  
  /* -------  for testing  ............................................ 
  iRc = TmsDataSend(SOF_HEAD_LEN_PLUS_2,caErrSof,'1');
  if (iRc != 0) {
    sprintf(g_caMsg,"TmsDataSend() error iRc = %d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END ( SEND_SOF_ERR );
  }  */

  /* modify 1-line By WuChihLiang 19950408 for convert out -- BEGIN */
  /*iRc = TmsDataSend(SOF_HEAD_LEN_PLUS_2,caErrSof,'0', &iDcsRtnCode);*/
  /*memset(caDataFmt,0,SIF_FMT_LEN+1);
  memcpy(caDataFmt,g_pstTba->caSif,SIF_FMT_LEN);*/
  GetFmtCode(caDataFmt);
  pfConvOutPgm = GetConvPgm(caDataFmt,CONV_OUT);
  if ( pfConvOutPgm != NULL ) {
    iRc =(int) (*pfConvOutPgm)(caErrSof, caCnvOutBuff,SOF_HEAD_LEN_PLUS_2);
    if ( iRc < 0 ) {
      sprintf(g_caMsg,"SendErrToDbp:Call convert out function error=%d"
              ,iRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END (-1);
    }
    iRc=TmsDataSend(iRc,caCnvOutBuff,'0',&iDcsRtnCode);
  }else{
    iRc=TmsDataSend(SOF_HEAD_LEN_PLUS_2,caErrSof,'0',&iDcsRtnCode);
  }
  if (iRc != 0) {
    sprintf(g_caMsg,"TmsDataSend() error iRc = %d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END ( SEND_SOF_ERR );
  }  

  UCP_TRACE_END( 0 );
}



/*
 *&N& ROUTINE NAME:SendAckToEms()
 *&A& ARGUMENTS:
 *&A&    NAME         TYPE            DESCRIPTION
 *&A& -------------  ------  -------------------------------
 *&A&
 *&R& RETURN VALUE(S):
 *&R&  0 : ������J��Ʀ��\
 *&R& -1 : ������J��ƥ���
 *&R&
 *&D& DESCRIPTION
 *&D&
 */

int
SendAckToEms( char *pcServerId , char cStatus)
{
  static char   caProtocol[80];
  struct FkdStat stFkdStat;
  static struct DcsBuf stDcsBuf;
  static struct DcsSiof stDcsSiof;
  char *pcTemp;

  UCP_TRACE(P_SendAckToEms);
  strcpy( stFkdStat.caTblidx, pcServerId ); 
  if( cStatus == PRC_NORMAL )
    stFkdStat.cStatus =  PRC_NORMAL;
  else
    stFkdStat.cStatus =  PRC_EXEC_ERR;
  stFkdStat.lProcPid =  getpid();

  /* get env III_PROTOCOL for protocol type */
  memset(caProtocol,'\0',80);
  pcTemp=(char *)getenv("III_PROTOCOL");
  if(pcTemp != NULL) {
    strcpy((char *)caProtocol,pcTemp); 
  }
  else {
    caProtocol[0]='\0';
  }
  if(caProtocol[0] != '\0') {
    g_cProtocoltype = caProtocol[0];
  }
  else{
    g_cProtocoltype = QUEUE_DCS;
  }

  /*   1.accept and read  */
  memcpy(McaDesCode(stDcsBuf),"00Monitor2",10);
  McRqstCode(stDcsBuf) = DCSCONNECTWRITE;
  stDcsSiof.cMoreByte  = '0';
  stDcsSiof.cKind      = '1';
  stDcsSiof.cProtoType = ' ';
  MiDataLen(stDcsBuf) = 8 + sizeof(struct FkdStat) ;
  sprintf(stDcsSiof.caDataLen,"%.5d",MiDataLen(stDcsBuf));   
  MpstDcsSiof(stDcsBuf) = &stDcsSiof;
  memcpy(McaData(stDcsBuf),&stFkdStat,sizeof(struct FkdStat));
  memcpy(McaServCode(stDcsBuf),"0000",4);
  McProto(stDcsBuf) =  g_cProtocoltype ; 
  DcsDispatch( &stDcsBuf );

  if(MiReply(stDcsBuf) != DCS_NORMAL) {
/*
    printf("WaitCmd:dcsacceptread reply %d errno %d\n", 
            MiReply(stDcsBuf),MiErrno(stDcsBuf)); 
 */
    sprintf( g_caMsg, "SendAckToEms: DcsDispatch() fails! reply=%d",
             MiReply(stDcsBuf) );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( SEND_MSG_ERR, g_caMsg );
    UCP_TRACE_END( SEND_MSG_ERR );
  }

  sg_iSessEmsIdx = MiSesIdx(stDcsBuf);
/*
  ErrLog(100,"SendAckToEms() sg_iSessEmsIdx:",RPT_TO_LOG,
         &sg_iSessEmsIdx,sizeof(int));
*/

  UCP_TRACE_END( 0 );

}



/*
 *&N& ROUTINE NAME:SendShutOkToEms()
 *&A& ARGUMENTS:
 *&A&    NAME         TYPE            DESCRIPTION
 *&A& -------------  ------  -------------------------------
 *&A&
 *&R& RETURN VALUE(S):
 *&R&  0 : ������J��Ʀ��\
 *&R& -1 : ������J��ƥ���
 *&R&
 *&D& DESCRIPTION
 *&D&
 */

int
SendShutOkToEms( char *pcServerId )
{
  static char   caProtocol[80];
  struct FkdStat stFkdStat;
  static struct DcsBuf stDcsBuf;
  static struct DcsSiof stDcsSiof;
  char *pcTemp;

  UCP_TRACE(P_SendShutOkToEms);
  strcpy( stFkdStat.caTblidx, pcServerId ); 
  stFkdStat.cStatus =  PRC_SHUTDOWN_OK;
  stFkdStat.lProcPid =  getpid();

  /* get env III_PROTOCOL for protocol type */
  memset(caProtocol,'\0',80);
  pcTemp=(char *)getenv("III_PROTOCOL");
  if(pcTemp != NULL) {
    strcpy((char *)caProtocol,pcTemp); 
  }
  else {
    caProtocol[0]='\0';
  }
  if(caProtocol[0] != '\0') {
    g_cProtocoltype = caProtocol[0];
  }
  else{
    g_cProtocoltype = QUEUE_DCS;
  }

  /*   1.accept and read  */
  memcpy(McaDesCode(stDcsBuf), sg_caDestCode, DEST_NAME_LEN);
  McRqstCode(stDcsBuf) = DCSWRDISCONECT;
  stDcsSiof.cMoreByte  = '0';
  stDcsSiof.cKind      = '1';
  stDcsSiof.cProtoType = ' ';
  MiDataLen(stDcsBuf) = 8 + sizeof(struct FkdStat) ;
  sprintf(stDcsSiof.caDataLen,"%.5d",MiDataLen(stDcsBuf));   
  MpstDcsSiof(stDcsBuf) = &stDcsSiof;
  memcpy(McaData(stDcsBuf),&stFkdStat,sizeof(struct FkdStat));
  memcpy(McaServCode(stDcsBuf),"0000",4);
  McProto(stDcsBuf) =  g_cProtocoltype ; 
  MiSesIdx(stDcsBuf) = sg_iSessIdx ;
/*
  ErrLog(100,"SendShutOkToEms() sg_iSessIdx:",RPT_TO_LOG,
         &sg_iSessIdx,sizeof(int));
*/

  DcsDispatch( &stDcsBuf );

  if(MiReply(stDcsBuf) != DCS_NORMAL) {
/*
    printf("WaitCmd:dcsacceptread reply %d errno %d\n", 
            MiReply(stDcsBuf),MiErrno(stDcsBuf)); 
*/
    sprintf( g_caMsg, "SendShutOkToEms: DcsDispatch() fails! reply=%d",
             MiReply(stDcsBuf) );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( SEND_MSG_ERR, g_caMsg );
    UCP_TRACE_END( SEND_MSG_ERR );
  }

  UCP_TRACE_END( 0 );

}



/*
 *&N& ROUTINE NAME:GetAck()
 *&A& ARGUMENTS:
 *&A&    NAME         TYPE            DESCRIPTION
 *&A& -------------  ------  -------------------------------
 *&A&  pcInputData    char*   �����ѿ�X�J�Ҳհe�ӿ�J�����
 *&A&
 *&R& RETURN VALUE(S):
 *&R&  0 : ������J��ƪ�����
 *&R& -1 : ������J��ƥ���
 *&R&
 *&D& DESCRIPTION
 *&D& �ھڳq�T��w�����ܼ�( �t��_PROTOCOL ) 
 *&D& �I�s�����A�ȵ{�������ѿ�J�Ҳհe�Ӥ����
 *&D&
 */

int
GetAck(paInputData, piDcsRtnCode,iAckSize)
char *paInputData;
int *piDcsRtnCode;
int iAckSize;
{
  char caProtoType[80];  /* enviroment variable buffer */
  struct DcsBuf stDcsBuf;
  struct DcsSiof stDcsSiof;

  UCP_TRACE( P_GetAck );

  if (g_cProtocoltype == '\0') {
    memset(caProtoType, '\0', 80);
    strcpy(caProtoType, (char *)getenv( PROTOCOL_TYPE ));
    if (caProtoType[0] != '\0') {
      g_cProtocoltype = caProtoType[0];
    }
    else {
      g_cProtocoltype = QUEUE_DCS;
    }
  }

  MpstDcsSiof(stDcsBuf) = &stDcsSiof;
  memcpy(McaDesCode(stDcsBuf), sg_caDestCode, DEST_NAME_LEN);
  McRqstCode(stDcsBuf) = DCSREAD;
  MlWaiTime(stDcsBuf) = g_iToffset;
  MiDataLen(stDcsBuf) = iAckSize;
  McProto(stDcsBuf) = g_cProtocoltype;

  MiSesIdx(stDcsBuf) = sg_iSessIdx ;
/*
  ErrLog(100,"GetAck() sg_iSessIdx:",RPT_TO_LOG,&sg_iSessIdx,sizeof(int));
*/

  DcsDispatch( &stDcsBuf );
  *piDcsRtnCode = MiReply(stDcsBuf);

  if (MiReply(stDcsBuf) != DCS_NORMAL) {
    sprintf( g_caMsg, "GetAck: DcsDispatch() fails! reply=%d",
             MiReply(stDcsBuf) );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( RECEIVE_SIF_ERR, g_caMsg );
    UCP_TRACE_END( RECEIVE_ACK_ERR );
  }

  if (MiDataLen(stDcsBuf) > 8){
    memcpy(paInputData, McaData(stDcsBuf), MiDataLen(stDcsBuf)-8);
/* ----- mark by chi-fu-song , 1994/12/21  ------- */
/*    memcpy(paInputData, McaData(stDcsBuf), MiDataLen(stDcsBuf)); */
  }

  ErrLog(100,"tmsdcsfn.c ACK =",RPT_TO_LOG,paInputData, MiDataLen(stDcsBuf)-8);

  UCP_TRACE_END( MiDataLen(stDcsBuf) - 8 );
}



/*
 *&N& ROUTINE NAME:ReqEmsToRestart()
 *&A& ARGUMENTS:
 *&A&    NAME         TYPE            DESCRIPTION
 *&A& -------------  ------  -------------------------------
 *&A&
 *&R& RETURN VALUE(S):
 *&R&  0 : ������J��Ʀ��\
 *&R& -1 : ������J��ƥ���
 *&R&
 *&D& DESCRIPTION
 *&D&
 */

int
ReqEmsToRestart( char *pcServerId )
{
  static char   caProtocol[80];
  struct MonCmd stMonCmd;
  static struct DcsBuf stDcsBuf;
  static struct DcsSiof stDcsSiof;
  char *pcTemp;

  UCP_TRACE(P_ReqEmsToRestart);
  strcpy( stMonCmd.caTblidx, pcServerId ); 
  stMonCmd.cCmd =  MON_RESTART;

  /* get env III_PROTOCOL for protocol type */
  memset(caProtocol,'\0',80);
  pcTemp=(char *)getenv("III_PROTOCOL");
  if(pcTemp != NULL) {
    strcpy((char *)caProtocol,pcTemp); 
  }
  else {
    caProtocol[0]='\0';
  }

  if(caProtocol[0] != '\0') {
    g_cProtocoltype = caProtocol[0];
  }
  else{
    g_cProtocoltype = QUEUE_DCS;
  }

  /*   1.connect and write   */
  memcpy(McaDesCode(stDcsBuf),"00Monitor1",10);
  McRqstCode(stDcsBuf) = DCSCONNECTWRITE;
  stDcsSiof.cMoreByte  = '0';
  stDcsSiof.cKind      = '1';
  stDcsSiof.cProtoType = ' ';
  MiDataLen(stDcsBuf) = 8 + sizeof(struct MonCmd) ;
  sprintf(stDcsSiof.caDataLen,"%.5d",MiDataLen(stDcsBuf));   
  MpstDcsSiof(stDcsBuf) = &stDcsSiof;
  memcpy(McaData(stDcsBuf),&stMonCmd,sizeof(struct MonCmd));
  memcpy(McaServCode(stDcsBuf),"0000",4);
  McProto(stDcsBuf) = g_cProtocoltype ; 
  DcsDispatch( &stDcsBuf );

  if(MiReply(stDcsBuf) != DCS_NORMAL) {
/*
    printf("WaitCmd:dcsacceptread reply %d errno %d\n", 
            MiReply(stDcsBuf),MiErrno(stDcsBuf)); 
*/
    sprintf( g_caMsg, "ReqEmsToRestart: DcsDispatch() fails! reply=%d",
             MiReply(stDcsBuf) );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( SEND_MSG_ERR, g_caMsg );
    UCP_TRACE_END( SEND_MSG_ERR );
  }

  sg_iSessRestartTms = MiSesIdx(stDcsBuf);
/*
  ErrLog(100,"ReqEmsToRestart() sg_iSessRestartTms:",RPT_TO_LOG,
         &sg_iSessRestartTms,sizeof(int));
*/

  UCP_TRACE_END( 0 );

}



/*
 *&N& ROUTINE NAME:RcvTmsRestartStus()
 *&A& ARGUMENTS:
 *&A&    NAME         TYPE            DESCRIPTION
 *&A& -------------  ------  -------------------------------
 *&A&
 *&R& RETURN VALUE(S):
 *&R&  0 : ������J��Ʀ��\
 *&R& -1 : ������J��ƥ���
 *&R&
 *&D& DESCRIPTION
 *&D&
 */

int
RcvTmsRestartStus()
{

  static char   caProtocol[80];
  struct FkdStat stFkdStat;
  static struct DcsBuf stDcsBuf;
  static struct DcsSiof stDcsSiof;
  char *pcTemp;

  UCP_TRACE(P_RcvTmsRestartStus);

  /* get env III_PROTOCOL for protocol type */
  memset(caProtocol,'\0',80);
  pcTemp=(char *)getenv("III_PROTOCOL");
  if(pcTemp != NULL) {
    strcpy((char *)caProtocol,pcTemp); 
  }
  else {
    caProtocol[0]='\0';
  }

  if(caProtocol[0] != '\0') {
    g_cProtocoltype = caProtocol[0];
  }
  else{
    g_cProtocoltype = QUEUE_DCS;
  }

  /*  read  */
  MpstDcsSiof(stDcsBuf) = &stDcsSiof;
  memcpy(McaDesCode(stDcsBuf),"00Monitor1",10);
  McRqstCode(stDcsBuf) = DCSREAD;
  MlWaiTime(stDcsBuf) = g_iToffset;
  MiDataLen(stDcsBuf) = sizeof(stFkdStat)+8;
  McProto(stDcsBuf) =  g_cProtocoltype ; 

  MiSesIdx(stDcsBuf) = sg_iSessRestartTms ;
/*
  ErrLog(100,"RcvTmsRestartStus() sg_iSessRestartTms:",RPT_TO_LOG,
         &sg_iSessRestartTms,sizeof(int));
*/

  DcsDispatch( &stDcsBuf );

  if(MiReply(stDcsBuf) != DCS_NORMAL) {
/*
    printf("WaitCmd:dcsacceptread reply %d errno %d\n", 
            MiReply(stDcsBuf),MiErrno(stDcsBuf)); 
*/
    sprintf( g_caMsg, "RcvTmsRestartStus: DcsDispatch() fails! reply=%d",
             MiReply(stDcsBuf) );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( SEND_MSG_ERR, g_caMsg );
    UCP_TRACE_END( RECEIVE_STATUS_ERR );
  }

  memcpy(&stFkdStat, McaData(stDcsBuf), MiDataLen(stDcsBuf) - 8 );
/*
  ErrLog(100,"RcvTmsRestartStus: DUMP RCV DATA=",RPT_TO_LOG,
         &stMonCmd,sizeof(struct MonCmd));
*/

  if ( stFkdStat.cStatus != (char) 0 ) {
    sprintf( g_caMsg, "RcvTmsRestartStus: Restart TMS fails! reply=%c",
             stFkdStat.cStatus );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( SEND_MSG_ERR, g_caMsg );
    UCP_TRACE_END( RESTART_TMS_ERR );
  }

  UCP_TRACE_END( 0 );

}



/*
 *&N& ROUTINE NAME:GetEmsDisconnect()
 *&A& ARGUMENTS:
 *&A&    NAME         TYPE            DESCRIPTION
 *&A& -------------  ------  -------------------------------
 *&A&  pcInputData    char*   �����ѿ�X�J�Ҳհe�ӿ�J�����
 *&A&
 *&R& RETURN VALUE(S):
 *&R&  0 : ������J��ƪ�����
 *&R& -1 : ������J��ƥ���
 *&R&
 *&D& DESCRIPTION
 *&D&   Ū��EMS��DISCONNECT���
 */

int
GetEmsDisconnect()
{
  char caProtoType[80];  /* enviroment variable buffer */
  struct DcsBuf stDcsBuf;
  struct DcsSiof stDcsSiof;

  UCP_TRACE( P_GetEmsDisconnect );

  if (g_cProtocoltype == '\0') {
    memset(caProtoType, '\0', 80);
    strcpy(caProtoType, (char *)getenv( PROTOCOL_TYPE ));
    if (caProtoType[0] != '\0') {
      g_cProtocoltype = caProtoType[0];
    }
    else {
      g_cProtocoltype = QUEUE_DCS;
    }
  }

  MpstDcsSiof(stDcsBuf) = &stDcsSiof;
  memcpy(McaDesCode(stDcsBuf), "00Monitor2", DEST_NAME_LEN);
  McRqstCode(stDcsBuf) = DCSREAD;
  MlWaiTime(stDcsBuf) = g_iToffset;
  MiDataLen(stDcsBuf) = DCS_MAX_DATA_LEN;
  McProto(stDcsBuf) = g_cProtocoltype;

  MiSesIdx(stDcsBuf) = sg_iSessEmsIdx ;
/*
  ErrLog(100,"GetEmsDisconnect() sg_iSessEmsIdx:",RPT_TO_LOG,
              &sg_iSessEmsIdx,sizeof(int));
*/

  DcsDispatch( &stDcsBuf );

  if (MiReply(stDcsBuf) != DCS_NORMAL) {
    sprintf( g_caMsg, "GetEmsDisconnect: DcsDispatch() fails! reply=%d",
             MiReply(stDcsBuf) );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( RECEIVE_SIF_ERR, g_caMsg );
    UCP_TRACE_END( RECEIVE_DISCONNECT_ERR );
  }

  UCP_TRACE_END( 0 );
}



/*
 *&N& ROUTINE NAME:SendDisconnect()
 *&A& ARGUMENTS:
 *&A&    NAME         TYPE            DESCRIPTION
 *&A& -------------  ------  -------------------------------
 *&A&
 *&R& RETURN VALUE(S):
 *&R&  0 : ������J��Ʀ��\
 *&R& -1 : ������J��ƥ���
 *&R&
 *&D& DESCRIPTION
 *&D&
 */

int
SendDisconnect()
{
  static char   caProtocol[80];
  static struct DcsBuf stDcsBuf;
  static struct DcsSiof stDcsSiof;
  char *pcTemp;

  UCP_TRACE(P_SendDisconnect);

  /* get env III_PROTOCOL for protocol type */
  memset(caProtocol,'\0',80);
  pcTemp=(char *)getenv("III_PROTOCOL");
  if(pcTemp != NULL) {
    strcpy((char *)caProtocol,pcTemp); 
  }
  else {
    caProtocol[0]='\0';
  }

  if(caProtocol[0] != '\0') {
    g_cProtocoltype = caProtocol[0];
  }
  else{
    g_cProtocoltype = QUEUE_DCS;
  }

  /*   send disconnect   */
  memcpy(McaDesCode(stDcsBuf),"00Monitor2",10);
  McRqstCode(stDcsBuf) = DCSDISCONNECT;
  MiDataLen(stDcsBuf) = 0;
  memcpy(McaServCode(stDcsBuf),"0000",4);
  McProto(stDcsBuf) =  g_cProtocoltype ; 

  MiSesIdx(stDcsBuf) = sg_iSessEmsIdx;
/*
  ErrLog(100,"SendDisconnect() sg_iSessEmsIdx:",RPT_TO_LOG,
         &sg_iSessEmsIdx,sizeof(int));
*/

  DcsDispatch( &stDcsBuf );

  if(MiReply(stDcsBuf) != DCS_NORMAL) {
    sprintf( g_caMsg, "SendDisconnect: DcsDispatch() fails! reply=%d",
             MiReply(stDcsBuf) );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( SEND_MSG_ERR, g_caMsg );
    UCP_TRACE_END( SEND_DISCONNECT_ERR );
  }

  UCP_TRACE_END( 0 );

}



/*
 *&N& ROUTINE NAME:RcvTmsShutStus()
 *&A& ARGUMENTS:
 *&A&    NAME         TYPE            DESCRIPTION
 *&A& -------------  ------  -------------------------------
 *&A&
 *&R& RETURN VALUE(S):
 *&R&  0 : ������J��Ʀ��\
 *&R& -1 : ������J��ƥ���
 *&R&
 *&D& DESCRIPTION
 *&D&  Ū��EMS��DISCONNECT���
 */
int
RcvTmsShutStus()
{

  static char   caProtocol[80];
  static struct DcsBuf stDcsBuf;
  static struct DcsSiof stDcsSiof;
  char *pcTemp;

  UCP_TRACE(P_RcvTmsShutStus);

  /* get env III_PROTOCOL for protocol type */
  memset(caProtocol,'\0',80);
  pcTemp=(char *)getenv("III_PROTOCOL");
  if(pcTemp != NULL) {
    strcpy((char *)caProtocol,pcTemp); 
  }
  else {
    caProtocol[0]='\0';
  }

  if(caProtocol[0] != '\0') {
    g_cProtocoltype = caProtocol[0];
  }
  else{
    g_cProtocoltype = QUEUE_DCS;
  }

  /*  read  */
  MpstDcsSiof(stDcsBuf) = &stDcsSiof;
  memcpy(McaDesCode(stDcsBuf), sg_caDestCode, DEST_NAME_LEN);
  McRqstCode(stDcsBuf) = DCSREAD;
  MlWaiTime(stDcsBuf) = g_iToffset;
  MiDataLen(stDcsBuf) = DCS_MAX_DATA_LEN;
  McProto(stDcsBuf) =  g_cProtocoltype ; 

  MiSesIdx(stDcsBuf) = sg_iSessIdx;
/*
  ErrLog(100,"RcvTmsShutStus() sg_iSessIdx:",RPT_TO_LOG,
         &sg_iSessIdx,sizeof(int));
*/

  DcsDispatch( &stDcsBuf );

  if(MiReply(stDcsBuf) != DCS_NORMAL) {
    sprintf( g_caMsg, "RcvTmsShutStus: DcsDispatch() fails! reply=%d",
             MiReply(stDcsBuf) );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( SEND_MSG_ERR, g_caMsg );
    UCP_TRACE_END( RECEIVE_DISCONNECT_ERR );
  }

  UCP_TRACE_END( 0 );

}

/*
 *&N& ROUTINE NAME:DoDcsAbort()
 *&A& ARGUMENTS:
 *&A&    NAME         TYPE            DESCRIPTION
 *&A& -------------  ------  -------------------------------
 *&A&
 *&R& RETURN VALUE(S):
 *&R&  0 : ���\
 *&R& -1 : ����
 *&R&
 *&D& DESCRIPTION
 *&D&   Abort DCS session.
 */
int
DoDcsAbort()
{
  char caProtoType[80];  /* enviroment variable buffer */
  struct DcsBuf stDcsBuf;
  struct DcsSiof stDcsSiof;

  UCP_TRACE( P_DoDcsAbort );

  if (g_cProtocoltype == '\0') {
    memset(caProtoType, '\0', 80);
    strcpy(caProtoType, (char *)getenv( PROTOCOL_TYPE ));
    if (caProtoType[0] != '\0') {
      g_cProtocoltype = caProtoType[0];
    }
    else {
      g_cProtocoltype = QUEUE_DCS;
    }
  }

  MpstDcsSiof(stDcsBuf) = &stDcsSiof;
  McRqstCode(stDcsBuf) = DCSABORT;
  MlWaiTime(stDcsBuf) = g_iToffset;
  MiDataLen(stDcsBuf) = DCS_MAX_DATA_LEN;
  McProto(stDcsBuf) = g_cProtocoltype;
  MiSesIdx(stDcsBuf) = sg_iSessIdx ;

  DcsDispatch( &stDcsBuf );
  if (MiReply(stDcsBuf) != DCS_NORMAL) {
    sprintf( g_caMsg, "DoDcsAbort: DcsDispatch() fails! reply=%d",
             MiReply(stDcsBuf) );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( -1 );
  }

  UCP_TRACE_END( 0 );
}

int
SetDestinationCode(char *pcaDestCode)
{
  memcpy(sg_caDestCode,pcaDestCode,DEST_NAME_LEN);
}
