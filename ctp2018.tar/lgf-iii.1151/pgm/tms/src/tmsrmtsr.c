/*
 *&N& File : tmsrmtsr.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int       RmtProc()
 *&N&    int       RcvHostDataToFile()
 *&N&    int       SndSifToRmtHost()
 */

/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include <errno.h>
#include "twa.h"	/* �w�q TWA �ҨϥΨ쪺��Ƶ��c�α`�� */
#include "tms.h"	/* �w�q tm �t�ΨϥΨ쪺��Ƶ��c�α`�� */
#include "ucp.h"
#include "errlog.h"	/* �O�����~�T���ɨϥΨ쪺�`�Ƥθ�Ƶ��c */
#include "dcs.h"
#include "tmcpgdef.h"

/* -------------------- CONSTANT DEFINE  --------------------------- */
#define  CTL_ON				 1
#define  CTL_OFF			 0
#define  LAST_MSG_MASK              	0x80
#define  TPEO_MSG_MASK              	0x02
#define  PRINT_MSG_MASK              	0x10
#define  IS_AP_ABEND              	& 0x08

#define  RCV_OK 			'1'
#define  RCV_ERR			'0'
#define  OUTPT_PREFIX	                "iii/log/output"

/* ---end----add for PTT random BIF scanning ---1994/01/05 ------- */
#define  PTT_DCS_TIMEOUT                1800
/* ---end----add for PTT random BIF scanning ---1994/01/05 ------- */

/* -------------------- GLOBAL DECLARATION ------------------ */
extern struct TMA *g_pstTma;
extern struct TBA *g_pstTba;
extern struct APA *g_pstApa;
extern int    g_iBrhCodeLen;
extern int    g_iTmCodeLen;
extern int    g_iTmin;
extern int    g_iToffset;

struct DcsBuf  g_stDcsBuf;
struct DcsSiof g_stDcsSiof;
char           g_cProtoType;
int            g_iActSess;   /* local host to remote host's Session Index */
char           g_cRcvRmtDataFlag; /* indicate rcv rmt data OK or not?     */
extern char g_cApRtnCode;       /* record the return code of AP       */

/*
 *&N& ROUNTINE NAME : RmtProc()
 *&A& ARGUMENTS: �L
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D& �ǰeSIF�ܻ��ݥD����TPU���A��.
 *&D&
 */
int
RmtProc(char *pcSif,int iSifLen,char *pcRmtApFlag)
{
  int    iRc;
  char   caTmpBuf[10];
  char   caFileName[80];
  struct DcsApi stDcsApi;

  UCP_TRACE(P_RmtProc);
  /* format conversion function() reserved in here */
  /* code   conversion function() reserved in here */
  /* decide host server name                     */
  memcpy(pcSif,"TPEI",4);

  stDcsApi.cFunCode = DCS_M_RMT_START_PGM;
  sprintf(caTmpBuf,"%.4d",iSifLen);
  memcpy(stDcsApi.caDataLen,caTmpBuf,4);
  iRc = SndSifToRmtHost(&stDcsApi,pcSif);
  if( iRc < 0 ) {
    sprintf(g_caMsg,"<RemoteTxn>: send data to RMT HOST error!");
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END( -4 );
  }

  memset(caFileName,'\0',80);
  sprintf(caFileName,"%s/%s%.*s.%.*s",getenv("III_DIR"),OUTPT_PREFIX,
          g_iTmCodeLen, g_pstTma->stTSSA.caTmCode,
          g_iBrhCodeLen, g_pstTma->stTSSA.caBrCode);
  iRc = NewRcvHostDataToFile(caFileName,pcRmtApFlag,g_pstTba->caPara);
  if( iRc < 0 ){
    sprintf(g_caMsg,"<RemoteTxn>: receive data from DCS error!");
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END( -5 );
  }
  g_cRcvRmtDataFlag = RCV_OK;

  UCP_TRACE_END( 0 );
}

/*
 *&N& ROUNTINE NAME : RcvHostDataToFile()
 *&A& ARGUMENTS: �L
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D&  ���� TPU ����X�����e��Ʀ�File.
 *&D&  2.Ū�� TPU �Ҷǰe����X��� SOF.
 *&D&  3.��e TPU �Ҷǰe����X��� SOF �� DBP.
 *&D&  4.�P�O TPU �Ҷǰe����X��� SOF �� status �O�_���� dbp �� ack
 *&D&    �Y�O�h���� DBP �� ack, ����e�� tpu.
 *&D&    �_�h��������.
 *&D&
 */
int
RcvHostDataToFile(char *pcaFileName,char *pcRmtApFlag,char *pcPostArea)
{
  int   iRc;
  int   iFd;
  int   iReadSize;
  char  cMoreData;
  int   iCtlFlowFlag; 
  char  caAckBuf[800];
  char  cSofCtlData1;
  int   iSofCnt = 0;
  char  cFirstCtlDataFlag = '1';
  char  cFirstSofCtlData;
  short sPostDataLen;
  char  caTmpBuf[10];
  int   iSifLen;

  UCP_TRACE(P_RcvHostDataToFile);

  iCtlFlowFlag = CTL_ON;
  MpstDcsSiof(g_stDcsBuf) = &g_stDcsSiof;

  iFd = open(pcaFileName,O_CREAT|O_TRUNC|O_RDWR,0660);
  if ( iFd < 0 ) {
      sprintf(g_caMsg,"<RcvHostDataToFile>: open File=%s error!",pcaFileName);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      /* disconnect */
      McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
      DcsDispatch(&g_stDcsBuf);
      UCP_TRACE_END(-1);
  }

  for (iSofCnt=0; ; iSofCnt++) {
    /* receive Sof From Remote Host TPU */
    McRqstCode(g_stDcsBuf) = DCSREAD;
    MlWaiTime(g_stDcsBuf) = g_iTmin+g_iToffset;
    MiDataLen(g_stDcsBuf) = DCS_MAX_DATA_LEN;
    McProto(g_stDcsBuf) = g_cProtoType; /* g_cProtocol by SndSifToRmtHost() */
    MiSesIdx(g_stDcsBuf) = g_iActSess ; /* g_iActSess  by SndSifToRmtHost() */
    DcsDispatch(&g_stDcsBuf);
    if (MiReply(g_stDcsBuf) != DCS_NORMAL) {
      sprintf(g_caMsg,
              "<RcvHostDataToFile>: sofCnt=%d,dcsreceive reply=%d,errno=%d",
              iSofCnt, MiReply(g_stDcsBuf),MiErrno(g_stDcsBuf));
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      /* disconnect */
      McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
      DcsDispatch(&g_stDcsBuf);
      UCP_TRACE_END(-1);
    }
    iReadSize = MiDataLen(g_stDcsBuf);

    sprintf(g_caMsg,"<RcvHostDataToFile>: iSofCnt=%d,iReadSize=%d,dump data is",
            iSofCnt,iReadSize);
    ErrLog(100, g_caMsg, RPT_TO_LOG, McaData(g_stDcsBuf), iReadSize);

    /* access control byte from SOF header */
    cSofCtlData1 = McaData(g_stDcsBuf)[SOF_CTL_CODE_OFFSET] ;

    /* bypass the CNETER host TPESDOUT data */
    if ( cSofCtlData1 & PRINT_MSG_MASK ){ /* AP call TPESDOUT API */
      cFirstCtlDataFlag = '1'; /* reset first control flag */
      continue; /* goto begin of while loop */
    }

    if ( iCtlFlowFlag == CTL_ON ) {

      if ( cFirstCtlDataFlag == '1'){
        cFirstSofCtlData = cSofCtlData1;
        if ( cSofCtlData1 IS_AP_ABEND ) {
          *pcRmtApFlag = TMS_AP_ABEND;
        }
        /* --- write POST(EJ) data to branch TPU to prepare for POST AP ---- */
        sPostDataLen=(unsigned char)McaData(g_stDcsBuf)[SOF_DATA_LEN_OFFSET]*256
                     +(unsigned char)McaData(g_stDcsBuf)[SOF_DATA_LEN_OFFSET+1];
        sprintf(g_caMsg,"RcvHostData byte num=%d",sPostDataLen);
        ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
        sprintf(g_caMsg,"RcvHostData POST DATA=");
        ErrLog(100,g_caMsg,RPT_TO_LOG,McaData(g_stDcsBuf),sPostDataLen+29);
        if(sPostDataLen > 0 ) {
          memset(pcPostArea,0,MAX_TBA_PARA_LEN);
          memcpy(pcPostArea,&McaData(g_stDcsBuf)[SOF_HEAD_LEN_PLUS_2],
                 sPostDataLen);
        }

        cFirstCtlDataFlag = '0';
      }

      /* write Data of Remote Host TPU Sof to File */
      iRc = write(iFd,McaData(g_stDcsBuf),MiDataLen(g_stDcsBuf)-8);
      if( iRc !=  (MiDataLen(g_stDcsBuf)-8) ) {
        sprintf(g_caMsg,
        "<RcvHostDataToFile>: write() error! write size=%d,write() rtn size=%d",
                MiDataLen(g_stDcsBuf)-8,iRc);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        /* disconnect */
        McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
        DcsDispatch(&g_stDcsBuf);
        UCP_TRACE_END(-1);
      }

      if ( cSofCtlData1 & LAST_MSG_MASK ) {

        iCtlFlowFlag = CTL_OFF;
        if ( !(cFirstSofCtlData & TPEO_MSG_MASK) ){
          break; /* exit while loop */
        }

        /* send TPEO to Remote Host TPU */
        McRqstCode(g_stDcsBuf) = DCSWRITE;
        McProto(g_stDcsBuf)=g_cProtoType;/* g_cProtocol by SndSifToRmtHost() */
        MiSesIdx(g_stDcsBuf)=g_iActSess; /* g_iActSess by  SndSifToRmtHost() */
        sprintf(McaDataLen(g_stDcsBuf),"%.5d",4 + 8);
        memcpy(McaData(g_stDcsBuf), "TPEO", 4);
        MiDataLen(g_stDcsBuf) = 4 + 8;
        DcsDispatch(&g_stDcsBuf);
        if(MiReply(g_stDcsBuf) != DCS_NORMAL){
          sprintf(g_caMsg,"<RcvHostDataToFile>: DCSWRITE reply=%d errno=%d",
                  MiReply(g_stDcsBuf),MiErrno(g_stDcsBuf));
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
          DcsDispatch(&g_stDcsBuf);
          UCP_TRACE_END(-1);
        }

      }/* end of "if ( cSofCtlData1 & LAST_MSG_MASK ) " */

    }
    else {

      /* write Data of Remote Host TPU Sof to File */
      iRc = write(iFd,McaData(g_stDcsBuf),MiDataLen(g_stDcsBuf)-8);
      if( iRc !=  (MiDataLen(g_stDcsBuf)-8) ) {
        sprintf(g_caMsg,
        "<RcvHostDataToFile>: write() error! write size=%d,write() rtn size=%d",
                MiDataLen(g_stDcsBuf)-8,iRc);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        /* disconnect */
        McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
        DcsDispatch(&g_stDcsBuf);
        UCP_TRACE_END(-1);
      }

      if ( cSofCtlData1 & LAST_MSG_MASK ){
        break; /* exit while loop */
      }

      /* send ACK to Remote Host TPU */
      McRqstCode(g_stDcsBuf) = DCSWRITE;
      McProto(g_stDcsBuf)=g_cProtoType;/* g_cProtocol by SndSifToRmtHost() */
      MiSesIdx(g_stDcsBuf)=g_iActSess; /* g_iActSess  by SndSifToRmtHost() */
/* add ----- by chi-fu-song 1994/12/24   ------ */
      sprintf(McaDataLen(g_stDcsBuf),"%.5d",1 + 8);
      McaData(g_stDcsBuf)[0]='\0';
      MiDataLen(g_stDcsBuf) = 1 + 8;
/* add     ----- by chi-fu-song 1994/12/24   ------ */
      DcsDispatch(&g_stDcsBuf);
      if(MiReply(g_stDcsBuf) != DCS_NORMAL){
        sprintf(g_caMsg,"<RcvHostDataToFile>: DCSWRITE reply=%d errno=%d",
                MiReply(g_stDcsBuf),MiErrno(g_stDcsBuf));
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
        DcsDispatch(&g_stDcsBuf);
        UCP_TRACE_END(-1);
      }

   }

  } /* while(cLoopFlag == 'y') */


  iRc = close(iFd);
  if ( iRc < 0 ) {
    sprintf(g_caMsg,"<RcvHostDataToFile>: close() File=%s error!",pcaFileName);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    /* disconnect */
    McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
    DcsDispatch(&g_stDcsBuf);
    UCP_TRACE_END(-1);
  }

  /* disconnect TPU session */
  McProto(g_stDcsBuf)=g_cProtoType;/* g_cProtocol by SndSifToRmtHost() */
  MiSesIdx(g_stDcsBuf)=g_iActSess; /* g_iActSess  by SndSifToRmtHost() */
  McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
  DcsDispatch(&g_stDcsBuf);

  UCP_TRACE_END ( 0 );
}  /* RcvHostDataToFile() */


/*
 *&N& ROUNTINE NAME : SndSifToRmtHost()
 *&A& ARGUMENTS: �L
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D& �ǰeSIF�ܻ��ݥD����TPU���A��.
 *&D&
 */
int
SndSifToRmtHost(struct DcsApi *pstDcsApi,char *pcDataBuf)
{
  int iRc;
  int iLen;
  char caTmpBuf[20];
  /* ------------------ compress SIF -------------------- */
  char caCnvOutBuff[1024];
  int  iSifCprsLen;
  /* ------------------ compress SIF -------------------- */

  UCP_TRACE(P_SndSifToRmtHost);

  ErrLog(10,"SndSifToRmtHost:Begin.",RPT_TO_LOG,0,0);

  memcpy(caTmpBuf,pstDcsApi->caDataLen,4);
  caTmpBuf[4] = '\0';
  iLen = atoi(caTmpBuf);
  if(iLen < 0){
    sprintf(g_caMsg,"SndSifToRmtHost: SIF data len=%d error!",iLen);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  } 

  /* ------------------ compress SIF -------------------- */
  iRc = SifCprs(pcDataBuf,caCnvOutBuff,iLen);
  if ( iRc < 0 ) {
    sprintf(g_caMsg,"TPE sif code compress error iRc=%d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,pcDataBuf,iLen);
    UCP_TRACE_END(iRc);
  }
  iSifCprsLen = iRc;
  /* ------------------ compress SIF -------------------- */

  /* prepare data to connect to remote application */
  McRqstCode(g_stDcsBuf) = DCSCONNECT;
  memset(McaDesCode(g_stDcsBuf),'0',10);
  /* mark on 19960822 */
  /* memcpy(McaDesCode(g_stDcsBuf)+5,pstDcsApi->caDesAddr,5); */
  g_cProtoType = SOCKET_DCS;
  McProto(g_stDcsBuf) = g_cProtoType;
  memcpy(g_stDcsSiof.caDataLen,"00000",5);
  MiDataLen(g_stDcsBuf) = 0+8;
  memcpy(McaServCode(g_stDcsBuf),pcDataBuf+4,4);
  MpstDcsSiof(g_stDcsBuf) = &g_stDcsSiof;

  DcsDispatch(&g_stDcsBuf);

  if (MiReply(g_stDcsBuf) != DCS_NORMAL) {
    sprintf(g_caMsg,"SndSifToRmtHost:Error Rtn Code = %d",MiReply(g_stDcsBuf));
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  } 

  g_iActSess = MiSesIdx(g_stDcsBuf);
   
  /* prepare data to dcscontrl */ 
  McRqstCode(g_stDcsBuf) = DCSWRITE;
  MpstDcsSiof(g_stDcsBuf) = &g_stDcsSiof;
  McMoreByte(g_stDcsBuf) = '1';
  McProtoType(g_stDcsBuf) = g_cProtoType;
  McKind(g_stDcsBuf) = '1';
  MiSesIdx(g_stDcsBuf) = g_iActSess;
  sprintf(caTmpBuf,"%.5d",iSifCprsLen+8);
  memcpy(g_stDcsSiof.caDataLen,caTmpBuf,5);
  memcpy(McaData(g_stDcsBuf),caCnvOutBuff,iSifCprsLen);
  MiDataLen(g_stDcsBuf) = 8+iSifCprsLen;

  /* for debug dump send Data */
  ErrLog(10,"<APD>SndSifToRmtHost: SIF=",RPT_TO_LOG,McaData(g_stDcsBuf),
         MiDataLen(g_stDcsBuf));

  DcsDispatch(&g_stDcsBuf);

  if (MiReply(g_stDcsBuf) != DCS_NORMAL) {
    sprintf(g_caMsg,"SndSifToRmtHost: Error Rtn Code=%d",MiReply(g_stDcsBuf));
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
   /* begin: added by pjw for tu995004      1999 6 8*/
   McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
   DcsDispatch(&g_stDcsBuf);
   /* end: added by pjw for tu995004      1999 6 8*/
    UCP_TRACE_END(-1);
  } 

  UCP_TRACE_END( 0 );
} 


/* ****************************************************************************/
/* g_caMemBuf contain MemBufCtl MSGP + REINPUT SIF + remote reverse txn SIF + 
   POST + SOF_HEAD_LEN_PLUS_2*2 (for control) + g_stHostToBrhInfo(100 bytes) */
extern char g_caMemBuf[MAX_MSGP_LEN * 2];
struct  MemBufCtlSt{
  int iMsgCnt;
  int iNextOffset;
};
extern struct  MemBufCtlSt g_stMemBufCtl;

/*
 *&N& ROUNTINE NAME : NewRcvHostDataToFile()
 *&A& ARGUMENTS: �L
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D&  ���� TPU ����X�����e��Ʀ�File.
 *&D&  2.Ū�� TPU �Ҷǰe����X��� SOF.
 *&D&  3.��e TPU �Ҷǰe����X��� SOF �� DBP.
 *&D&  4.�P�O TPU �Ҷǰe����X��� SOF �� status �O�_���� dbp �� ack
 *&D&    �Y�O�h���� DBP �� ack, ����e�� tpu.
 *&D&    �_�h��������.
 *&D&
 */
int
NewRcvHostDataToFile(char *pcaFileName,char *pcRmtApFlag,char *pcPostArea)
{
  int   iRc;
  int   iReadSize;
  char  cMoreData;
  int   iCtlFlowFlag; 
  char  caAckBuf[80];
  char  cSofCtlData1;
  int   iSofCnt = 0;
  char  cFirstCtlDataFlag = '1';
  char  cFirstSofCtlData;
  short sDataLen;
  char  caTmpBuf[10];
  int   iSifLen;
  struct  MemBufCtlSt *pstMemBufCtl;
  /* ------------------- Decompress SOF ---------------------- */
  int   i,j;  
  int iSofLen;
  char caCnvInBuff[3072];
  /* ------------------- Decompress SOF ---------------------- */

  UCP_TRACE(P_RcvHostDataToFile);

  /* Clear  g_caMemBuf */
  memset(g_caMemBuf, '\0', sizeof(g_caMemBuf));
  pstMemBufCtl = (struct MemBufCtlSt *)&g_stMemBufCtl ;
  pstMemBufCtl->iNextOffset = sizeof(struct MemBufCtlSt);
  pstMemBufCtl->iMsgCnt     = 0;

  iCtlFlowFlag = CTL_ON;
  MpstDcsSiof(g_stDcsBuf) = &g_stDcsSiof;

  for (iSofCnt=0; ; iSofCnt++) {
    /* receive Sof From Remote Host TPU */
    McRqstCode(g_stDcsBuf) = DCSREAD;
    MlWaiTime(g_stDcsBuf) = g_iTmin+g_iToffset;
    MiDataLen(g_stDcsBuf) = DCS_MAX_DATA_LEN;
    McProto(g_stDcsBuf) = g_cProtoType; /* g_cProtocol by SndSifToRmtHost() */
    MiSesIdx(g_stDcsBuf) = g_iActSess ; /* g_iActSess  by SndSifToRmtHost() */
    DcsDispatch(&g_stDcsBuf);
    if (MiReply(g_stDcsBuf) != DCS_NORMAL) {
      sprintf(g_caMsg,
              "<NewRcvHostDataToFile>: sofCnt=%d,dcsreceive reply=%d,errno=%d",
              iSofCnt, MiReply(g_stDcsBuf),MiErrno(g_stDcsBuf));
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      /* disconnect */
      McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
      DcsDispatch(&g_stDcsBuf);
      UCP_TRACE_END(-1);
    }
    iReadSize = MiDataLen(g_stDcsBuf);

    sprintf(g_caMsg,"<NewRcvHostDataToFile>: iSofCnt=%d,iReadSize=%d, DATA=",
            iSofCnt,iReadSize-8);
    ErrLog(100, g_caMsg, RPT_TO_LOG, McaData(g_stDcsBuf), iReadSize-8);

    /* ------------------- Decompress SOF ---------------------- */
    iSofLen=iReadSize-8;
    iRc = SofDecprs(McaData(g_stDcsBuf),&iSofLen,caCnvInBuff);
    if ( iRc < 0 ) {
      sprintf(g_caMsg,"TPE sof code decompress error iRc=%d",iRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,McaData(g_stDcsBuf),iSofLen);

      /* begin: added by pjw for tu995004      1999 6 8*/
      McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
      DcsDispatch(&g_stDcsBuf);
      /* end: added by pjw for tu995004      1999 6 8*/

      UCP_TRACE_END(iRc);
    }
    /* ------------------- Decompress SOF ---------------------- */

    /* access control byte from SOF header */
    cSofCtlData1 = caCnvInBuff[SOF_CTL_CODE_OFFSET] ;

    /* bypass the CNETER host TPESDOUT data */
    if ( cSofCtlData1 & PRINT_MSG_MASK ){ /* AP call TPESDOUT API */
      cFirstCtlDataFlag = '1'; /* reset first control flag */
      continue; /* goto begin of while loop */
    }

    if ( iCtlFlowFlag == CTL_ON ) {

      if ( cFirstCtlDataFlag == '1'){
        cFirstSofCtlData = cSofCtlData1;
        if ( cSofCtlData1 IS_AP_ABEND ) {
          g_cApRtnCode='1';
          *pcRmtApFlag = TMS_AP_ABEND;
          sprintf(g_caMsg,"<APD>Remote Txn failed, Control SOF MsgCode=[%.7s]",
                  &caCnvInBuff[SOF_MSG_CODE_OFFSET]);
          ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
        }
        else {
          g_cApRtnCode='0';
          ErrLog(100,"<APD>Remote Txn succeed",RPT_TO_LOG,0,0);
        }

        /* --- test the SOF whether the SOF is PIGGYBACK SOF or not     ---- */
        if(strncmp(&caCnvInBuff[SOF_OUT_DEV_OFFSET],"@@@@@@@@",8)== 0){
          i=SOF_HEAD_LEN_PLUS_2;
          j=0;
          while ( i < iSofLen ) {
            sDataLen=(unsigned char)caCnvInBuff[i+SOF_DATA_LEN_OFFSET]*256
                    +(unsigned char)caCnvInBuff[i+SOF_DATA_LEN_OFFSET+1];
            if ( j == 0 ) {
              /*  write POST(EJ) data to branch TPU to prepare for POST AP  */
              sprintf(g_caMsg,"<APD>POST DATA=");
              ErrLog(100,g_caMsg,RPT_TO_LOG,&caCnvInBuff[i+SOF_HEAD_LEN_PLUS_2],sDataLen);
              if(sDataLen > 0 ) {
                memset(pcPostArea,0,MAX_TBA_PARA_LEN);
                memcpy(pcPostArea,&caCnvInBuff[i+SOF_HEAD_LEN_PLUS_2],
                       sDataLen);
              }
              j++;
            }

            iRc = MemWrite(&caCnvInBuff[i],SOF_HEAD_LEN_PLUS_2+sDataLen, 1);
            if( iRc !=  (SOF_HEAD_LEN_PLUS_2+sDataLen) ) {
              sprintf(g_caMsg,
              "<NewRcvHostDataToFile>:MemWrite error! size=%d, rtn size=%d",
                      SOF_HEAD_LEN_PLUS_2+sDataLen,iRc);
              ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
              /* disconnect */
              McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
              DcsDispatch(&g_stDcsBuf);
              UCP_TRACE_END(-1);
            }

            i += (SOF_HEAD_LEN_PLUS_2+sDataLen);
          } /* end while */
          break;
        } /* end of processing PIGGYBACK SOF */
    
        /* --- write POST(EJ) data to branch TPU to prepare for POST AP ---- */
        sDataLen=(unsigned char)caCnvInBuff[SOF_DATA_LEN_OFFSET]*256
                     +(unsigned char)caCnvInBuff[SOF_DATA_LEN_OFFSET+1];
        sprintf(g_caMsg,"<APD>POST DATA=");
        ErrLog(100,g_caMsg,RPT_TO_LOG,&caCnvInBuff[SOF_HEAD_LEN_PLUS_2],sDataLen);
        if(sDataLen > 0 ) {
          memset(pcPostArea,0,MAX_TBA_PARA_LEN);
          memcpy(pcPostArea,&caCnvInBuff[SOF_HEAD_LEN_PLUS_2],
                 sDataLen);
        }

        cFirstCtlDataFlag = '0';
      }

      /* write Data of Remote Host TPU Sof to File */
      iRc = MemWrite(caCnvInBuff,iSofLen, 1);
      if( iRc !=  iSofLen ) {
        sprintf(g_caMsg,
        "<NewRcvHostDataToFile>:MemWrite error! size=%d, rtn size=%d",
                iSofLen,iRc);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        /* disconnect */
        McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
        DcsDispatch(&g_stDcsBuf);
        UCP_TRACE_END(-1);
      }

      if ( cSofCtlData1 & LAST_MSG_MASK ) {

        iCtlFlowFlag = CTL_OFF;
        if ( !(cFirstSofCtlData & TPEO_MSG_MASK) ){
          break; /* exit while loop */
        }

        /* send TPEO to Remote Host TPU */
        McRqstCode(g_stDcsBuf) = DCSWRITE;
        McProto(g_stDcsBuf)=g_cProtoType;/* g_cProtocol by SndSifToRmtHost() */
        MiSesIdx(g_stDcsBuf)=g_iActSess; /* g_iActSess by  SndSifToRmtHost() */
        sprintf(McaDataLen(g_stDcsBuf),"%.5d",4 + 8);
        memcpy(McaData(g_stDcsBuf), "TPEO", 4);
        MiDataLen(g_stDcsBuf) = 4 + 8;
        DcsDispatch(&g_stDcsBuf);
        if(MiReply(g_stDcsBuf) != DCS_NORMAL){
          sprintf(g_caMsg,"<NewRcvHostDataToFile>: DCSWRITE reply=%d errno=%d",
                  MiReply(g_stDcsBuf),MiErrno(g_stDcsBuf));
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
          DcsDispatch(&g_stDcsBuf);
          UCP_TRACE_END(-1);
        }

      }/* end of "if ( cSofCtlData1 & LAST_MSG_MASK ) " */

    }
    else {

      /* write Data of Remote Host TPU Sof to File */
      iRc = MemWrite(caCnvInBuff,iSofLen, 1);
      if( iRc !=  iSofLen ) {
        sprintf(g_caMsg,
        "<NewRcvHostDataToFile>:MemWrite error! size=%d, rtn size=%d",
                iSofLen,iRc);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        /* disconnect */
        McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
        DcsDispatch(&g_stDcsBuf);
        UCP_TRACE_END(-1);
      }

      if ( cSofCtlData1 & LAST_MSG_MASK ){
        break; /* exit while loop */
      }

      /* send ACK to Remote Host TPU */
      McRqstCode(g_stDcsBuf) = DCSWRITE;
      McProto(g_stDcsBuf)=g_cProtoType;/* g_cProtocol by SndSifToRmtHost() */
      MiSesIdx(g_stDcsBuf)=g_iActSess; /* g_iActSess  by SndSifToRmtHost() */
/* add ----- by chi-fu-song 1994/12/24   ------ */
      sprintf(McaDataLen(g_stDcsBuf),"%.5d",1 + 8);
      McaData(g_stDcsBuf)[0]='\0';
      MiDataLen(g_stDcsBuf) = 1 + 8;
/* add     ----- by chi-fu-song 1994/12/24   ------ */
      DcsDispatch(&g_stDcsBuf);
      if(MiReply(g_stDcsBuf) != DCS_NORMAL){
        sprintf(g_caMsg,"<NewRcvHostDataToFile>: DCSWRITE reply=%d errno=%d",
                MiReply(g_stDcsBuf),MiErrno(g_stDcsBuf));
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
        DcsDispatch(&g_stDcsBuf);
        UCP_TRACE_END(-1);
      }

   }

  } /* while(cLoopFlag == 'y') */

  /* disconnect TPU session */
  McProto(g_stDcsBuf)=g_cProtoType;/* g_cProtocol by SndSifToRmtHost() */
  MiSesIdx(g_stDcsBuf)=g_iActSess; /* g_iActSess  by SndSifToRmtHost() */
  McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
  DcsDispatch(&g_stDcsBuf);
  /*
  iRc = SaveOutputToFile(pcaFileName,  
          g_caMemBuf+ sizeof(struct MemBufCtlSt),
          pstMemBufCtl->iNextOffset-sizeof(struct MemBufCtlSt));
  if (iRc != 0){
    UCP_TRACE_END ( iRc );
  }*/

  UCP_TRACE_END ( 0 );
}  /* NewRcvHostDataToFile() */
