/*
 *&N& File : tmmapgen.c
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&                 main()               ����TMS�ѷӪ��w�q��
 */

/* ------------------------- INCLUDE FILES ---------------------------- */
#include <stdio.h>
#include <errno.h>
#include "errlog.h"

/* ------------------------- CONSTANT DEFINITION  --------------------- */

#define  MAX_EXEC_PATH_LEN     80
#define  FILE_NAME_LEN         80
#define  MAX_APFUN_NUM          1
#define  APFUN_CNFG_ERR	       -4
#define  OPEN_FILE_ERR	       -5
#define  APFUN_FILE	 "iii/etc/tbl/tmdapfun.dat"
#define  TMS_APFUN_DEF	 "iii/bin/lib/tmdapfun.def"
#define  TMS_APFUN_H	 "iii/bin/lib/tmgapfun.h"
#define  APFUN_H_TMP_FILE   "iii/tmp/apfun_h.tmp"
#define  APFUN_DEF_TMP_FILE "iii/tmp/apfun_def.tmp"

static char caApName[20];     /* AP name    */

extern int  errno;

main()
{
  int i;
  int iRc;
  int iTblSize;
  int iChiPid;
  int iWaitCode;
  char caExePath[MAX_EXEC_PATH_LEN];    /* buf for keep exec path str */
  char caFlName[FILE_NAME_LEN];
  char caApDefFlName[FILE_NAME_LEN];
  char caSortedFile[FILE_NAME_LEN];
  char caApDefSortedFile[FILE_NAME_LEN];
  int  iStatus;
  int  iHadLoadNum;
  FILE *zApFun;
  FILE *zTmsDef;
  FILE *zTmsh;


   memset(caSortedFile,'\0',FILE_NAME_LEN);
   strcpy(caSortedFile,(char *) getenv("III_DIR"));
   strcat(caSortedFile,(char *) "/");
   strcat(caSortedFile,TMS_APFUN_H);

   memset(caApDefSortedFile,'\0',FILE_NAME_LEN);
   strcpy(caApDefSortedFile,(char *) getenv("III_DIR"));
   strcat(caApDefSortedFile,(char *) "/");
   strcat(caApDefSortedFile,TMS_APFUN_DEF);

     /* -------------------- */
     /* get open file name   */
     /* -------------------- */
   memset(caFlName,'\0',FILE_NAME_LEN);
   strcpy(caFlName,(char *) getenv("III_DIR"));
   strcat(caFlName,(char *) "/");
   strcat(caFlName,APFUN_FILE);

  /* open ifmod file name */
  if((zApFun=fopen(caFlName,"r")) == NULL){
    printf("tmmapgen:open ems ifmod file=%s errno=%d\n",caFlName,errno);
    exit(OPEN_FILE_ERR);
  } /* FOR if((zApFun=fopen(caFlname,"r")) == NULL) */

   memset(caApDefFlName,'\0',FILE_NAME_LEN);
   strcpy(caApDefFlName,(char *) getenv("III_DIR"));
   strcat(caApDefFlName,(char *) "/");
   strcat(caApDefFlName,APFUN_DEF_TMP_FILE);

  /* open ifmod file name */
  if((zTmsDef=fopen(caApDefFlName,"w")) == NULL){
    printf("tmmapgen:open tms def file=%s errno=%d\n",caApDefFlName,errno);
    exit(OPEN_FILE_ERR);
  } /* FOR if((zApFun=fopen(caFlname,"r")) == NULL) */

   memset(caFlName,'\0',FILE_NAME_LEN);
   strcpy(caFlName,(char *) getenv("III_DIR"));
   strcat(caFlName,(char *) "/");
   strcat(caFlName,APFUN_H_TMP_FILE);

  /* open ifmod file name */
  if((zTmsh=fopen(caFlName,"w")) == NULL){
    printf("tmmapgen:open tms header file=%s errno=%d\n",caFlName,errno);
    exit(OPEN_FILE_ERR);
  } /* FOR if((zApFun=fopen(caFlname,"r")) == NULL) */

   i=0;
   while((iRc=fscanf(zApFun,"%s\n", caApName)) != EOF){
     if(iRc < MAX_APFUN_NUM){
       printf("tmmapgen: fscanf input %d item < %d\n",iRc,MAX_APFUN_NUM);
       exit(APFUN_CNFG_ERR);
     }

    if ( strncmp(caApName,"NULL",4) !=0 ) {
      fprintf(zTmsDef,"\x22%s\x22, %s,\n", caApName, caApName);
      fprintf(zTmsh,"extern int %s();\n",caApName);
    }

   } /* FOR while((iRc=fscanf(....))  */
 
  fclose(zTmsh);
  fclose(zTmsDef);
  fclose(zApFun);
    
  SortTmsApH(caFlName,caSortedFile);
  SortTmsApDef(caApDefFlName,caApDefSortedFile);
  printf("Generate tmdapfun.def, tmgapfun.h OK!!\n");
  exit(0);
}


SortTmsApH(char *pcFileName,char *pcSortedFile)
{
  char caCmdBuf[250];
  sprintf(caCmdBuf,"sort +2 -3 -u < %s > %s",pcFileName,pcSortedFile);
  system(caCmdBuf);
}

SortTmsApDef(char *pcFileName,char *pcSortedFile)
{
  char caCmdBuf[250];
  sprintf(caCmdBuf,"sort -u < %s > %s",pcFileName,pcSortedFile);
  system(caCmdBuf);
}
