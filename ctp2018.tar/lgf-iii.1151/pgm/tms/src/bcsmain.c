/*
 *&N& File: bcsmain.c �妸����޲z�l�t�ΥD�{��
 *&N&
 *&N&    TYPE      NAME                 DESCRIPTION
 *&N& --------- ---------- ----------------------------------------
 *&N&    int       BCSMAIN    �妸����޲z�l�t�ΥD�{�� (for COBOL_BTPU)
 *&N&    int       CMAIN      �妸����޲z�l�t�ΥD�{�� (for C_BTPU)
 *&N&
 */

/* ---------------------- INCLUDE FILES DECLARATION ------------------- */
#include "errlog.h"
#include "tmcpgdef.h"   /* TMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */
#include "tms.h"
#include "ucp.h"
/* -------------------------------------------------------------------- */


/* ------------------------- CONSTANT DEFINITION ---------------------- */
/*
#define         P_Mtmmbmain                20000
*/

#define         UCP_SYSTEM                 'S'
#define         TMS_SUB_SYSTEM             '2'
#define         ENVSETUP_STEP              '1'
#define         FLTXRLBK_STEP              '2'
#define         TXINIT_STEP                '3'
#define         TXINPUT_STEP               '4'
#define         TXSTART_STEP               '5'
#define         TXPROCES_STEP              '6'
#define         TXEND_STEP                 '7'
#define         TXOUTPUT_STEP              '8'
#define         TXRELESE_STEP              '9'

/* -------------------------------------------------------------------- */


/* -----------------  GLOBAL VARIABLES DECLARATION -------------- */
int g_iTwaKey;
int g_iCwaKey;
int g_iCtfKey;
int g_iIctKey;
int g_iDbtKey;
int g_iIetKey;
int g_iSysOpMode;
int g_iTestMode;
int g_iMaxPacketSize;
int g_iTmax;
int g_iTmin;
int g_iToffset;
int g_iPiggyBackSize;
int g_iTcumTpuSleep;   /* the cumulative time of TPU sleep */
int g_iTapAlarm;       /* the amount of time used to detect ap each time */
int g_iTtxnTimeout;    /* the total amount of time elapsed in a transaction 
                          (perhaps including 2 or above AP processes),
                          excluding the time elapsed in TPE's API */

char *g_pcCtf;
char *g_pcIet;
char *g_pcIct;

struct TMA *g_pstTma;
struct COA *g_pstCoa;
struct TBA *g_pstTba;
struct APA *g_pstApa;
struct TCT *g_pstTctTbl;

int g_iBrhCodeLen;
int g_iTmCodeLen ;
int g_iTxnCodeLen ;
int g_iTellerCodeLen ;
int g_iSifLen ;    /* for REMOTE TXN SIF LENGTH */
char g_cOnBthTxn ;    /* for ONBTH 1995/03/31 */
char g_caReinputBuffer[MAX_SIF_LEN + SOF_HEAD_LEN_PLUS_2];
char g_cNeedRelseTrm='n';

/* BIT 1 :
 *        when TPE receives SIF , bit is set to ON.
 *        when TPE sends data to AP over, bit is set to OFF.
 * BIT 2 :
 *        when TPE strats txn , bit is set to ON
 *        when TPE ends txn , bit is set to OFF
 *
 *   (ERROR ACTION: REFERENCE FLAG)
 *   00011111
 *      ^^^^^
 *      |||||-----> when TPE needs to report to teller, bit is set to ON.
 *      ||||------> when TPE needs to do rollback, bit is set to ON.
 *      |||-------> when TPE needs to report TPE monitor, bit is set to ON.
 *      ||--------> when TPE needs to abend, bit is set to ON.
 *      | --------> when TPE needs to kill AP, bit is set to ON.
 */
char g_cErrActFlag = 0x00;

/* -------------------------------------------------------------------- */

/* ------ CALLED FUNCTION AND SUBROUTINE PROTOTYPE DECLARATIONS ------- */
int   SetServerId(char *); /* save Server Id to TWA   */
int   SetSysMode(char);    /* save System mode to TWA */
int   EnvSetup(char *);
int   FlTxRlbk(char *);
int   TxInit(char *);
int   TxInput(char *);
int   TxStart(char *);
int   TxProces(char *);
int   TxEnd(char *);
int   TxOutput(char *);
int   TxRelese(char *);
int   ErrorRpt(char, char, char, char, int);
/* -------------------------------------------------------------------- */

/*
 *&N& ROUTINE NAME:
 *&A& ARGUMENTS:
 *&A&     int iArgCnt;       �������޲z�l�t�ΥD�{���ҿ�J���ѼƭӼ�
 *&A&     char *pcaArgV[];   �������޲z�l�t�ΥD�{���ҿ�J���Ѽư}�C
 *&A&           pcaArgV[0]:  �������ɦW��
 *&A&           pcaArgV[1]:  �����檺����Ҧ�
 *&A&                        '0' : ���� Online  mode
 *&A&                        '1' : ���� Batch   mode
 *&A&                        '2' : ���� Special mode
 *&A&           pcaArgV[2]:  business name
 *&A&           pcaArgV[3]:  JCL program name
 *&A&           pcaArgV[4]:  JCL program JOB ID
 *&A&
 *&R& RETURN VALUES:
 *&R&
 *&R&
 *&D& DESCRIPTION:
 *&D&     ����Ƭ�����޲z�l�t�ΥD�{��, �t�d�إߥ���޲z�����ҤΥ���y
 *&D& �{���޲z, �æP�ɫO�������ƪ����T�ʻP�@�P�ʡC
 *&D&
 */

#include <string.h>

BCSMAIN(char *pcCmdLineLen, char *pcCmdLine)
{
  int  i, iCmdLineLen = 0;
  char caCmdLineLen[10];
  char caCmdLine[256];
  char *pcArgv[20];
  char *pcToken;
  int   iArgc = 0;
  
  memset(caCmdLine, 0, sizeof(caCmdLine));
  memset(caCmdLineLen, 0, sizeof(caCmdLineLen));
  memcpy(caCmdLineLen, pcCmdLineLen, 4);
  iCmdLineLen = atoi(caCmdLineLen);
  /*printf("iCmdLineLen=%d\n",iCmdLineLen);*/
  if ( iCmdLineLen < 0 || iCmdLineLen > sizeof(caCmdLine)){
    printf("Command line too long\n");
    return(-1);
  }
  else{
    memcpy(caCmdLine, pcCmdLine, iCmdLineLen);
    iArgc = 0;
    pcArgv[iArgc++] = "btpu.x";
    if ((pcToken=(char *)strtok(caCmdLine," \t\n")) != (char*) NULL){
      pcArgv[iArgc++] = pcToken;
      /*printf("pcArgv[%d] = %s\n",iArgc-1,pcArgv[iArgc-1]);*/
      while ((pcToken=(char *)strtok(NULL," \t\n")) != (char*) NULL){
        pcArgv[iArgc++] = pcToken;
        /*printf("pcArgv[%d] = %s\n",iArgc-1,pcArgv[iArgc-1]);*/
        if (iArgc >= 20){
          printf("Arguments in command line are exceed 20\n");
          return(-2);
        }
      }
    }
    /*printf("iArgc = %d\n",iArgc);*/
  }
  
  Cmain(iArgc, pcArgv);
  return (0);
}

Cmain(int iArgCnt, char *pcaArgV[])
{
  int iRc;          /* return code of function. */
  char cL2Step='0'; /* step of level 2; '1' is step 1, '2' is step 2, etc */
  char caLogName[256];
  char caJclFileName[256];
  char caBussName[256];
  char caTxnCode[10];

  /*
   * UCP_TRACE(P_Mtmmain);
   */

  /* check iArgCnt */
  if (iArgCnt != 5){
     printf("Usage:%s SysMode BussName JclName JobId\n", pcaArgV[0]);
     exit(1);
  }

  sprintf(caLogName, "%s/iii/log/btms_errlog", getenv("III_DIR") );
  ChgLog(LOG_CHG_MODE,"1");
  ChgLog(LOG_CHG_LOG,caLogName);

  /* save pcaArgV to TWA */
  SetServerId("BatchTpu");    /* save Server Id to TWA   */
  SetSysMode(pcaArgV[1][0]);  /* save System mode to TWA */
  if ( pcaArgV[1][0] != BATCH_MODE ) {
     printf("Usage:%s SysMode BussName JclName JobId\n", pcaArgV[0]);
     printf("%s argument[1]: SysMode=%c error!\n",pcaArgV[0], pcaArgV[1][0]);
     printf("Please check argument[1]: SysMode must be ['1'->BATCH_MODE]\n");
     exit(1);
  }
  memset(caBussName,0,256);
  sprintf(caBussName, "%s/%s", getenv("III_DIR"), pcaArgV[2] );
  memset(caJclFileName,0,256);
  sprintf(caJclFileName,"%s/%s/jcl/%s",getenv("III_DIR"),pcaArgV[2],pcaArgV[3]);
  memset(caTxnCode,0,10);
  sprintf(caTxnCode,"%s",pcaArgV[4]);

  /* Check JCL program file exists or not  */
  iRc = CheckJclFile(&cL2Step,caJclFileName);
  if (iRc < 0){
     sprintf(g_caMsg,"P_Bmain:JCL program [%s] does not exist.",
             caJclFileName);
     PrintErrMsg(g_caMsg);
     TmsErrHdl(cL2Step,iRc);
  }

  /* Environment Setup */
  iRc = EnvSetup(&cL2Step);
  if (iRc < 0){
    ErrorRpt(UCP_SYSTEM, TMS_SUB_SYSTEM, ENVSETUP_STEP, cL2Step, iRc);
    sprintf(g_caMsg, "P_Bmain:EnvSetup error, return code=%d.", iRc);
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PrintErrMsg(g_caMsg);
    TmsErrHdl(cL2Step,iRc);
  }

  /* while loop for serving client request. (JCL program) */
  while(1){

    /* Initialization of each txn. in JCL program */
    iRc = TxInit(&cL2Step);
    if (iRc < 0){
      ErrorRpt(UCP_SYSTEM, TMS_SUB_SYSTEM, TXINIT_STEP, cL2Step, iRc);
      sprintf(g_caMsg, "P_Bmain:TxInit error, return code=%d.", iRc);
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      PrintErrMsg(g_caMsg);
      break;
    }

    /* Process JCL Program File */
    do {
      iRc=JclInput(&cL2Step,caBussName,caJclFileName,caTxnCode) ;
      switch( iRc ) {
        case -1: /* ��JCL program ���s�b                                */
        case -2: /* ��JCL program �� "BEGIN"�B"begin" ���s�b            */
        case -3: /* ������JCL program��UNIX system command���~          */
        case -4: /* open tmp file error                                  */
        case -99:/* �� JCL program �� return code �����T  */
          TmsErrHdl(cL2Step,iRc);
          break;
        case 0: /* �� �}�ɥ��`    */
        case 1: /* �� "UBC" �R�O  */
          break;
        case 2: /* �� JCL ���浲��  */
          AbendRtn( 0 );
        case 3:
          AbendRtn( -1 );
      }
    } while ( iRc == 0 );

    /* Process Txn Start */
    iRc = TxStart(&cL2Step);
    if (iRc < 0){
      ErrorRpt(UCP_SYSTEM, TMS_SUB_SYSTEM, TXSTART_STEP, cL2Step, iRc);
      sprintf(g_caMsg, "P_Bmain:TxBegin error, return code=%d.", iRc);
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      PrintErrMsg(g_caMsg);
      break;
    }

    /* Txn Process */
    iRc = TxProces(&cL2Step);
    if (iRc < 0){
      ErrorRpt(UCP_SYSTEM, TMS_SUB_SYSTEM, TXPROCES_STEP, cL2Step, iRc);
      sprintf(g_caMsg, "P_Bmain:TxProces error, return code=%d.", iRc);
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      PrintErrMsg(g_caMsg);
      break;
    }

    /* Process Txn End */
    iRc = TxEnd(&cL2Step);
    if (iRc < 0){
      ErrorRpt(UCP_SYSTEM, TMS_SUB_SYSTEM, TXEND_STEP, cL2Step, iRc);
      sprintf(g_caMsg, "P_Bmain:TxEnd error, return code=%d.", iRc);
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      PrintErrMsg(g_caMsg);
      break;
    }

    /* Release resource for each Application Program */
    iRc = TxRelese(&cL2Step);
    if (iRc < 0){
      ErrorRpt(UCP_SYSTEM, TMS_SUB_SYSTEM, TXRELESE_STEP, cL2Step, iRc);
      sprintf(g_caMsg, "P_Bmain:TxRelese error, return code=%d.", iRc);
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      PrintErrMsg(g_caMsg);
      break;
    }

  } /* end of while(1) */

  iRc = TmsErrHdl(cL2Step,iRc);

}/* end of main */





