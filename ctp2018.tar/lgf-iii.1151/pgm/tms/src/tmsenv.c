/*
 *&N& File : tmsenv.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int       EnvSetup()             �t�����ҫظm
 *&N&    int       GetSysRs()             �ھڲ{�b���������Ҩ��o�t�θ귽
 *&N&    int       GetTwa()               ���ͦ@�ΰO���^ TWA
 *&N&    int       GetKernl()             �ǳ� TPE KERNEL ����������
 *&N&    int       AccessCwa()            CWA ����\��ɭ�
 *&N&    int       GetTblAddr()           �̰ѼƤ��O���o CTF, IET, ICT ��
 *&N&                                     �@�θ�ư�
 *&N&    int       GetPtrFromTwa
 *&N&
 */

/* ------------------------- INCLUDE FILES ---------------------------- */
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/signal.h>
#include <fcntl.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <sys/shm.h>
#include <sys/param.h>
#include <sys/errno.h>

#include "errlog.h"
#include "cwa.h"
#include "twa.h"
#include "tmcenv.h"
#include "tmcpgdef.h"	/* TMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */
#include "tms.h"

/* ------------------------- CONSTANT DEFINITION ---------------------- */
/* tmsenv.c 
#define P_EnvSetup 		21001
#define P_AccessCwa 		21002
#define P_GetConfg 		21003
#define P_GetKernl 		21004
#define P_GetPtrFromTwa		21005
#define P_GetSysRs 		21006
#define P_GetTblAddr 		21007
#define P_GetTct 		21008
#define P_GetTwa 		21009
#define P_SignOn 		21010
*/
#define  CWA_SHM_KEY		"CWA_SHM_KEY"
#define  CTF_SHM_KEY		"CTF_SHM_KEY"
#define  ICT_SHM_KEY		"ICT_SHM_KEY"
#define  DBT_SHM_KEY		"DBT_SHM_KEY"
#define  IET_SHM_KEY		"IET_SHM_KEY"
#define  SYS_MODE		"SYSMODE"
#define  TEST_MODE		"TEST_MODE"
#define  MAX_PACKET_SIZE	"MAX_PACKET_SIZE"
#define  T_MAX "T_MAX"
#define  T_MIN "T_MIN"
#define  T_OFFSET "T_OFFSET"
#define  T_APALARM "T_APALARM"
#define  PIGGYBACK_SIZE		"PIGGYBACK_SIZE"

#define CONFIG_FILE  		"iii/etc/tbl/config.dat"
#define FILE_NAME_LEN 		80

/* ------------------ EXTERN VARIABLE DECLARATION --------------------- */
extern int g_iTwaKey;
extern int g_iCwaKey;
extern int g_iCtfKey;
extern int g_iIctKey;
extern int g_iDbtKey;
extern int g_iIetKey;
extern int g_iSysOpMode;
extern int g_iTestMode;
extern int g_iMaxPacketSize;
extern int g_iTmax;
extern int g_iTmin;
extern int g_iToffset;
extern int g_iTapAlarm;
extern int g_iTtxnTimeout;
extern int g_iPiggyBackSize;

extern char *g_pcCtf;
extern char *g_pcIet;
extern char *g_pcIct;

extern struct TMA *g_pstTma;
extern struct COA *g_pstCoa;
extern struct TBA *g_pstTba;
extern struct APA *g_pstApa;
char *g_pstTerm;

extern int g_iBrhCodeLen;
extern int g_iTmCodeLen ;
extern int g_iTxnCodeLen ;
int g_iErrLogSize = 1024;

/*
 *&N& ROUTINE NAME: EnvSetup()
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&   �t�θ귽���o, ���檺�إ�, �öi����U�n�O
 *&D&
 */

int
EnvSetup( cErrStep )
char *cErrStep;
{
  int iRc;

  UCP_TRACE( P_EnvSetup );

  *cErrStep = '0';
  iRc = GetConfg();
  if (iRc < 0){
    *cErrStep = '1';
    ErrLog(1000, "EnvSetUp: GetConfg() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( iRc );
  }
  /* ---------------------------------------------------------------- */
  /* change log's mode by system value of TEST_MODE.                  */ 
  /* ( 1 -> TEST mode , 0 -> non-TEST mode )                          */
  /* ---------------------------------------------------------------  */
  if ( g_iTestMode == 1 ) {
    ChgLog(LOG_CHG_MODE,"1");
  }
  else {
    ChgLog(LOG_CHG_MODE,"0");
  }

  /* TCC: 1997/04/25 */
  if( (char) GetSysMode() == '0') {
    Daemon_Start (0);
  }

  iRc = GetSysRs();
  if (iRc < 0){
    *cErrStep = '2';
    ErrLog(1000, "EnvSetUp: GetSysRs() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( iRc );
  }

  iRc = GetKernl();
  if (iRc < 0){
    *cErrStep = '3';
    ErrLog(1000, "EnvSetUp: GetKernl() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( iRc );
  }

  iRc = StSysVal();
  if (iRc < 0){
    *cErrStep = '5';
    ErrLog(1000, "EnvSetUp: StSysVal() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( iRc );
  }

  /* For setting a txn's total amount of time to timeout -- BEGIN */
  if (g_pstTma->stTSSA.cSystemRole == CENTER_HOST){
    g_iTtxnTimeout=(((g_iTmin-g_iToffset)<=0)? 30 : (g_iTmin-g_iToffset));
  }
  else {
    g_iTtxnTimeout=(((g_iTmax-g_iToffset)<=0)? 30 : (g_iTmax-g_iToffset));
  }
  /* For setting a txn's total amount of time to timeout -- END */

  /* TCC: 1997/04/25 
  if(g_pstTma->stTSSA.cSysMode == '0') {
    Daemon_Start(0);
  }
  */

  iRc = AttIfEnv();
  if (iRc < 0){
    *cErrStep = '4';
    ErrLog(1000, "EnvSetUp: AttIfEnv() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( ATT_IF_ENV_ERR );
  }

  iRc = SignOn();
  if (iRc < 0){
    *cErrStep = '6';
    ErrLog(1000, "EnvSetUp: SignOn() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( iRc );
  }
  
  UCP_TRACE_END( 0 );
}

/*
 *&N& ROUTINE NAME: GetSysRs()
 *&A& ARGUMENTS:
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&   ����Ʈھڲ{�b���������Ҩ��o�U�C�t�θ귽
 *&D&    1. COBOL-II ����l�]�w (�Y�`�� COBOL_II ���w�q)
 *&D&    2. �T�����]�w�P�B�z
 *&D&    3. ���o�@�ΰO���^ TWA ����}
 */

int
GetSysRs()
{
  int iRc;

  UCP_TRACE( P_GetSysRs );

  iRc = CobInit();
  if (iRc < 0) {
    ErrLog(1000, "GetSysRs: CobInit() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( iRc );
  }

  iRc = SignlHdl();
  if (iRc < 0) {
    ErrLog(1000, "GetSysRs: SignlHdl() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( SIGNL_HDL_ERR );
  }

  iRc = GetTwa();
  if (iRc < 0) {
    ErrLog(1000, "GetSysRs: GetTwa() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( iRc );
  }

  UCP_TRACE_END( 0 );
}

/*
 *&N& ROUTINE NAME: GetTwa()
 *&A& ARGUMENTS:
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&  1. ����ƥH TPU �� process id ������ TPU �ҨϥΤ��@�ΰO���^ TWA �� key,
 *&D&     �Y��ư��榨�\,�h���ͦ@�ΰO���^ TWA 
 *&D&     *�S�O�`�N*
 *&D&     ����� �I�s TwaCtlFac()
 *&D&
 *&D&  2. Create Sync. Mechanism
 *&D&
 */

int
GetTwa()
{
  int iRc;
  struct TwaCtl stTwaCtl;
  struct TwaCreatIobuf stTCBuf;
  char *pcDummy;

  UCP_TRACE( P_GetTwa );

  /* Set global vaiable */
  g_iTwaKey = getpid();

  /* Creat Twa */
  stTwaCtl.cFunCode = TWA_CREAT;
  stTCBuf.iShmKey = g_iTwaKey;

  iRc = TwaCtlFac( &stTwaCtl, &stTCBuf );
  if (iRc != TWA_NORMAL) {
    sprintf( g_caMsg, "GetTwa: TwaCtlFac() fails! iRc=%d", iRc );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( GET_TWA_TWACTLFAC_ERR, g_caMsg );
    UCP_TRACE_END( GET_TWA_TWACTLFAC_ERR );
  }

  /* Attach Twa */
  stTwaCtl.cFunCode = TWA_ATTACH;

  iRc = TwaCtlFac( &stTwaCtl, &pcDummy );
  if (iRc != TWA_NORMAL) {
    sprintf( g_caMsg, "GetTwa: TwaCtlFac() fails! iRc=%d", iRc );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( GET_TWA_TWACTLFAC_ERR, g_caMsg );
    UCP_TRACE_END( GET_TWA_TWACTLFAC_ERR );
  }

  iRc = GetPtrFromTwa();
  if (iRc < 0) {
    ErrLog(1000, "GetTwa: GetPtrFromTwa() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( iRc );
  }

  iRc = InitSync();
  if (iRc < 0) {
    ErrLog(1000, "GetTwa: InitSync() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( INIT_SYNC_ERR );
  }

  UCP_TRACE_END( 0 );
}

/*
 *&N& ROUTINE NAME: AccessCwa()
 *&A& ARGUMENTS:
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D&   *�S�O�`�N*
 *&D&    ����� �I�s CwaCtlFac()
 *&D&
 */

int
AccessCwa()
{
  int iRc;
  struct SPA *pstSpa;
  struct CwaCtl stCwaCtl;
  struct CwaCreatIobuf stCCBuf;
  char *pcDummy;

  UCP_TRACE( P_AccessCwa );

  /* Creat CWA */
  stCwaCtl.cFunCode = CWA_GET_ID;
  stCCBuf.iShmKey = g_iCwaKey;
  stCCBuf.iSemKey =  g_iCwaKey;
  iRc = CwaCtlFac(&stCwaCtl , &stCCBuf);

  if(iRc != CWA_NORMAL){
    sprintf( g_caMsg, "AccessCwa: CwaCtlFac() CWA_GET_ID fails! iRc=%d", iRc );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( ACCESS_CWA_ERR, g_caMsg );
    UCP_TRACE_END( ACCESS_CWA_ERR );
  }

  /* Attach Cwa */
  stCwaCtl.cFunCode = CWA_ATTACH;
  stCCBuf.iShmKey = g_iCwaKey;
  stCCBuf.iSemKey =  g_iCwaKey;

  iRc = CwaCtlFac(&stCwaCtl , &stCCBuf);
  if(iRc != CWA_NORMAL){
    sprintf( g_caMsg, "AccessCwa: CwaCtlFac() fails! iRc=%d", iRc );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( ACCESS_CWA_ERR, g_caMsg );
    UCP_TRACE_END( ACCESS_CWA_ERR );
  }

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SPA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSpa);
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }

  g_iBrhCodeLen = (int) pstSpa->cBrCodeLen ;
  g_iTmCodeLen  = (int) pstSpa->cTmCodeLen ;
  g_iTxnCodeLen  = (int) pstSpa->cTxnCodeLen ;

  sprintf(g_caMsg,"AccessCwa:BrhCodeLen=%ld,TmCodeLen=%d,TxnCodeLen=%d",
                   g_iBrhCodeLen,g_iTmCodeLen,g_iTxnCodeLen);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
  /****  It is unnecessary to attach BIT
  iRc = GetTct();
  if(iRc <  0){
    ErrLog(1000, "AccessCwa: GetTct() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( iRc );
  }
  ****/

  UCP_TRACE_END( 0 );
}

/*
 *&N& ROUTINE NAME: GetTct()
 *&A& ARGUMENTS:
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D&   *�S�O�`�N*
 *&D&    ����� �I�s CwaCtlFac()
 *&D&
 */

int
GetTct()
{
  int iRc;
  struct CwaCtl stCwaCtl;

  UCP_TRACE( P_GetTct );

  /* Read Lock TCT Segment */
  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_BIT_TM;
  sprintf(stCwaCtl.caTblIdx, "%.3d", 0);
  iRc = CwaLowCtlFac(&stCwaCtl, &g_pstTerm);

  if(iRc != CWA_NORMAL){
    sprintf( g_caMsg, "GetTct: CwaLowCtlFac() fails! iRc=%d", iRc );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( GET_TCT_ERR, g_caMsg );
    UCP_TRACE_END( GET_TCT_ERR );
  }

  UCP_TRACE_END(0);
}

/*
 *&N& ROUTINE NAME: GetKernl()
 *&A& ARGUMENTS:
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&   ����ƥΥH�ǳ� TPE KERNEL ����������,�ѦҨ쪺�����ܼƦ�
 *&D&   g_pstCtf : CTF ���_�l��}
 *&D&   g_pstIet : IET ���_�l��}
 *&D&   g_pstIct : ICT ���_�l��}
 */

int
GetKernl()
{
  int iRc;

  UCP_TRACE( P_GetKernl );

  iRc = AccessCwa();
  if (iRc < 0) {
    ErrLog(1000, "GetKernl: AccessCwa() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( iRc );
  }

  iRc = GetTblAddr( CTF_SHM_KEY, g_iCtfKey );
  if (iRc < 0) {
    ErrLog(1000, "GetKernl: GetTblAddr() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( iRc );
  }

/*
  iRc = GetTblAddr( IET_SHM_KEY, g_iIetKey );
  if (iRc < 0) {
    ErrLog(1000, "GetKernl: GetTblAddr() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( iRc );
  }

  iRc = GetTblAddr( ICT_SHM_KEY, g_iIctKey );
  if (iRc < 0) {
    ErrLog(1000, "GetKernl: GetTblAddr() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( iRc );
  }
*/

  iRc = imftxnld();
  if (iRc < 0) {
    ErrLog(1000, "GetKernl: GetTblAddr() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( iRc );
  }

  UCP_TRACE_END( 0 );
}

/*
 *&N& ROUTINE NAME: GetTblAddr()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                   DESCRIPTION
 *&A& ---------------------------------------------------------------
 *&A&  pcTblName      char  *                �����o��}�� Table Name
 *&A&  iKey           int                    �� Table �� key
 *&A& 
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&   �ھڰѼƪ��]�w,���O���o CTF, ICT, IET �� Table( share memory )
 *&D&   ���_�l��},���o����O�]�������ܼ� g_pcCtf, g_pcIct, g_pcIet
 */

int
GetTblAddr( pcTblName, iKey )
char *pcTblName;
int iKey;
{
  int iRc;

  UCP_TRACE( P_GetTblAddr );

  if (strcmp( pcTblName, CTF_SHM_KEY ) == 0) {
    iRc = IpcShmat( iKey, &g_pcCtf );
    if (iRc < 0) {
      ErrLog(1000, "GetTblAddr: Attach fails! iRc=%d, pcTblName=%s, iKey=%d",
             iRc, pcTblName, iKey );
      UCP_TRACE_END( ATTCH_CTF_ERR );
    }
  }
  else if (strcmp( pcTblName, IET_SHM_KEY ) == 0) {
/*
    iRc = AttchIet( iKey, &g_pcIet );
    if (iRc < 0) {
      ErrLog(1000, "GetTblAddr: Attach fails! iRc=%d, pcTblName=%s, iKey=%d",
             iRc, pcTblName, iKey );
      UCP_TRACE_END( ATTCH_IET_ERR );
    }
*/
  }
  else if (strcmp( pcTblName, ICT_SHM_KEY ) == 0) {
/*
    iRc = AttchIct( iKey, &g_pcIct );
    if (iRc < 0) {
      ErrLog(1000, "GetTblAddr: Attach fails! iRc=%d, pcTblName=%s, iKey=%d",
             iRc, pcTblName, iKey );
      UCP_TRACE_END( ATTCH_ICT_ERR );
    }
*/
  }

  UCP_TRACE_END( 0 );
}

/*
 *&N& ROUTINE NAME: SignOn()
 *&A& ARGUMENTS:
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&   ����ƥΥH�q�� TPE �}�l�B�z���,�i�@��������A�ʷ�����
 *&D&   ( �ȮɥH dummy function �N��,����� implement )
 */

int
SignOn()
{
  /* Dummy */
  UCP_TRACE( P_SignOn );
  UCP_TRACE_END( 0 );
}

int
GetPtrFromTwa()
{
  int iRc;
  struct TwaCtl stTwaCtl;
  char *pcDummy;

  UCP_TRACE( P_GetPtrFromTwa );

  stTwaCtl.cFunCode = TWA_GET_SEG_PTR;
  stTwaCtl.cSegCode = TWA_SEG_TMA;
/* iRc = TwaLowCtlFac(&stTwaCtl,&g_pstTma); */
  iRc = TwaLowCtlFac(&stTwaCtl,&pcDummy);
  g_pstTma = (struct TMA *) pcDummy;

  if (iRc != TWA_NORMAL) {
    sprintf( g_caMsg, "GetPtrFromTwa: TwaLowCtlFac() fails! iRc=%d", iRc );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( GETPTRFROMTWA_TMA_ERR, g_caMsg );
    UCP_TRACE_END( GETPTRFROMTWA_TMA_ERR );
  }

  stTwaCtl.cFunCode = TWA_GET_SEG_PTR;
  stTwaCtl.cSegCode = TWA_SEG_COA;
  iRc = TwaLowCtlFac(&stTwaCtl,&g_pstCoa);

  if (iRc != TWA_NORMAL) {
    sprintf( g_caMsg, "GetPtrFromTwa: TwaLowCtlFac() fails! iRc=%d", iRc );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( GETPTRFROMTWA_COA_ERR, g_caMsg );
    UCP_TRACE_END( GETPTRFROMTWA_COA_ERR );
  }

  stTwaCtl.cFunCode = TWA_GET_SEG_PTR;
  stTwaCtl.cSegCode = TWA_SEG_APA;
  iRc = TwaLowCtlFac(&stTwaCtl,&g_pstApa);

  if (iRc != TWA_NORMAL) {
    sprintf( g_caMsg, "GetPtrFromTwa: TwaLowCtlFac() fails! iRc=%d", iRc );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( GETPTRFROMTWA_APA_ERR, g_caMsg );
    UCP_TRACE_END( GETPTRFROMTWA_APA_ERR );
  }

  stTwaCtl.cFunCode = TWA_GET_SEG_PTR;
  stTwaCtl.cSegCode = TWA_SEG_TBA;
  iRc = TwaLowCtlFac(&stTwaCtl,&g_pstTba);

  if (iRc != TWA_NORMAL) {
    sprintf( g_caMsg, "GetPtrFromTwa: TwaLowCtlFac() fails! iRc=%d", iRc );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( GETPTRFROMTWA_TBA_ERR, g_caMsg );
    UCP_TRACE_END( GETPTRFROMTWA_TBA_ERR );
  }

  UCP_TRACE_END( 0 );
}

/*
 *&N& ROUTINE NAME: GetConfg()
 *&A& ARGUMENTS:
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&   ����ƥΥH���o�t�ΰѼ��� config.dat ���Ҵy�z���t�ΰѼƭ�,�P�ɱN�ȳ]�w
 *&D&   ���۹����������ܼ�
 *&D&               �t�ΰѼ�                �����ܼ�
 *&D&       ----------------------------------------------
 *&D&        CWA Shared Memory Key          g_iCwaKey
 *&D&        CTF Shared Memory Key          g_iCtfKey
 *&D&        ICT Shared Memory Key          g_iIctKey
 *&D&        DBT Shared Memory Key          g_iDbtKey
 *&D&        IET Shared Memory Key          g_iIetKey
 *&D&        SYSMODE                        g_iSysOpMode
 *&D&                                         0 : �^��
 *&D&                                         1 : ����
 *&D&   �U�C���Τ��@,�|�Ϧ���ư��楢��
 *&D&       1. �L�k�}�� config.dat ��
 *&D&       2. �Өt�ΰѼƤ��s�b
 *&D&       3. config.dat �ɤ����t�ΰѼƭӼƶW�X�̤j����
 *&d&          (�Ѧұ`�� MAX_PARA_NO ����)
 *&D&       4. �t�ΰѼƦW�٤����׶W�X�̤j����
 *&D&          (�Ѧұ`�� MAX_PARA_NAME_LEN ����)
 *&D&
 */

int
GetConfg()
{
  int iRc;
  char caFileName[ FILE_NAME_LEN + 1 ];
  char caErrLogSize[ 30 ];

  UCP_TRACE( P_GetConfg );

  strcpy(caFileName, (char *)getenv( "III_DIR" ));
  strcat(caFileName, "/");
  strcat(caFileName, CONFIG_FILE);

  iRc = InitCnfTbl( caFileName );
  if ( iRc < 0 ) {
    ErrLog(1000, "GetConfg: InitCnfTbl() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( INIT_CNF_TBL_ERR );
  }

  g_iCwaKey = GetCnfValue( CWA_SHM_KEY );
  if (g_iCwaKey < 0){
    ErrLog(1000, "GetConfg: GetCnfValue() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( GET_CWAKEY_ERR );
  }

  g_iCtfKey = GetCnfValue( CTF_SHM_KEY );
  if (g_iCtfKey < 0){
    ErrLog(1000, "GetConfg: GetCnfValue() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( GET_CTFKEY_ERR );
  }

  g_iIctKey = GetCnfValue( ICT_SHM_KEY );
  if (g_iIctKey < 0){
    ErrLog(1000, "GetConfg: GetCnfValue() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( GET_ICTKEY_ERR );
  }

  g_iIetKey = GetCnfValue( IET_SHM_KEY );
  if (g_iIetKey < 0){
    ErrLog(1000, "GetConfg: GetCnfValue() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( GET_IETKEY_ERR );
  }

  g_iDbtKey = GetCnfValue( DBT_SHM_KEY );
  if (g_iDbtKey < 0){
    ErrLog(1000, "GetConfg: GetCnfValue() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( GET_DBTKEY_ERR );
  }

  g_iSysOpMode = GetCnfValue( SYS_MODE );
  if (g_iSysOpMode < 0){
    ErrLog(1000, "GetConfg: GetCnfValue() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( GET_SYSOPMODE_ERR );
  }

  g_iTestMode = GetCnfValue( TEST_MODE );
  if (g_iTestMode < 0){
    ErrLog(1000, "GetConfg: GetCnfValue() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( GET_TESTMODE_ERR );
  }

  g_iMaxPacketSize = GetCnfValue( MAX_PACKET_SIZE );
  if (g_iMaxPacketSize < 0){
    ErrLog(1000, "GetConfg: GetCnfValue() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( GET_MAXPACKETSIZE_ERR );
  }

  g_iTmax = GetCnfValue( T_MAX );
  if ( g_iTmax < 0 ) {
    UCP_TRACE_END( GET_TMAX_ERR );
  }

  g_iTmin = GetCnfValue( T_MIN );
  if ( g_iTmin < 0 ) {
    UCP_TRACE_END( GET_TMIN_ERR );
  }

  g_iToffset = GetCnfValue( T_OFFSET );
  if ( g_iToffset < 0 ) {
    UCP_TRACE_END( GET_TOFFSET_ERR );
  }

  /* For detecting Ap process every T_APALARM seconds -- BEGIN */
  g_iTapAlarm = GetCnfValue( T_APALARM );
  if ( g_iTapAlarm <= 0 ) {
    g_iTapAlarm = 10; /* default */
    /* For compatiabe pervious TPE/UNIX version */
    /* And this will result in TPU detecting AP every g_iTapAlarm seconds */
  }
  /* For detecting Ap process every T_APALARM seconds -- END */

  g_iPiggyBackSize = GetCnfValue( PIGGYBACK_SIZE );
  if ( g_iPiggyBackSize <= 0 ) {
    g_iPiggyBackSize = 0;
    /* using original TPEI/TPEO protocol */
  }

  g_iErrLogSize = GetCnfValue( "ERRLOG_MAX" );
  if ( g_iErrLogSize <= 1 ) { /* for compatiabe pervious TPE/UNIX version */
    g_iErrLogSize = 1024;     /* condig.dat ERRLOG_MAX default value is 1 */
  }
  sprintf(caErrLogSize, "%d", g_iErrLogSize);
  ChgLog(LOG_CHG_SIZE, caErrLogSize );

  UCP_TRACE_END( 0 );
}



/*************************************************************************/

Daemon_Start (ignsigcld)
int ignsigcld;  /* this variable is used for telling whether ignore CLD */
{
	register  int	iChildPid,iFd;
        char      caCdPath[80];

	if (getppid() == 1) {
	       goto out;
        }

#ifdef SIGTTOU
	signal(SIGTTOU, SIG_IGN);
#endif
#ifdef SIGTTIN
	signal(SIGTTIN, SIG_IGN);
#endif
#ifdef SIGTSTP
	signal(SIGTSTP, SIG_IGN);
#endif

	if (  (iChildPid = fork() ) < 0)
	     printf("can't fork the first child");
	else if (iChildPid > 0)
	     exit(0);

	if (setpgrp() == -1)
	     printf("can't change process group");

 	signal(SIGHUP, SIG_IGN);

	if (  (iChildPid = fork() ) < 0)
     printf("can't fork the second child");
	else if (iChildPid > 0)
	     exit(0);


out:
#ifdef SCO_UNIX
	for (iFd=0; iFd < NOFILES_MAX; iFd++) {
#else
	for (iFd=0; iFd < NOFILE; iFd++) {
#endif

          if ( (iFd == 1) || (iFd == 2) ) {
	  }
  	  else {
	     close(iFd);
	  }

	}

	errno = 0;

        memset(caCdPath,'\0',80);
        strcpy(caCdPath,(char *) getenv("III_DIR"));
        strcat(caCdPath,"/iii/log");
	chdir(caCdPath);
	umask(0);
	
	if (ignsigcld) {
	     signal(SIGCLD, SIG_IGN);
	}
}
