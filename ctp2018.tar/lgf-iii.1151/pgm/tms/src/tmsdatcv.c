/* ------------------------- INCLUDE FILES ---------------------------- */
#include "errlog.h"
#include "tmctxin.h"
#include "tmcpgdef.h"	/* TMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */
#include "ucp.h"

/* ------------------------- CONSTANT DEFINITION ---------------------- */
/* tmsdatcv.c 
#define P_AsciiCnv 		24501
#define P_AsiCnv 		24502
#define P_CharStuff 		24503
#define P_Comp3Cnv 		24504
#define P_DataCnv 		24505
#define P_FloatStuff 		24506
#define P_IntStuff 		24507
#define P_LongCnv 		24508
#define P_PackFunc 		24509
#define P_SasciiCnv 		24510
#define P_ShortCnv 		24511
#define P_SignStuff 		24512
#define P_StuffData 		24513
*/
#ifdef LPI_COBOL

#define PLUS_SIGN		0x10
#define MINUS_SIGN		0x19
#define PLUS_ZERO		0x4b
#define MINUS_ZERO		0x4d

#elif defined( MF_COBOL )

#define PLUS_SIGN		0x00
#define MINUS_SIGN		0x40
#define PLUS_ZERO		0x00
#define MINUS_ZERO		0x40

#else

#define PLUS_SIGN		0x00
#define MINUS_SIGN		0x40
#define PLUS_ZERO		0x00
#define MINUS_ZERO		0x40

#endif

#define CTF_NAME_LEN		30

/*  CFT entry data structure     */
struct  tbl_item_def {          /* item entry of item tbl. format define */
   char caCtfName[CTF_NAME_LEN+1]; /* ctf item name                      */
   char cDataType;              /* type of data item                     */
   int  iDataLen;               /* input item length                     */
   int  iCtfLen;                /* data length in ctf                    */
   int  iCtfOffs;               /* offset relate to ctf                  */
   int  iCtfRelat;              /* relative number to ctf table          */
   int  iDotPos;                /* floating point position from right    */
   char cIniValue;              /* initial value for item ( 0 or blank ) */
};
typedef struct tbl_item_def tbl_item;

int
DataCnv( pstCtfItem, pcInData, pcOutData, iInDatLen )
tbl_item *pstCtfItem;
char *pcInData;
char *pcOutData;
int iInDatLen;
{
  int  iRc;
  char caConvData[ MAX_SIF_LEN ];
  char caOutBuf[ MAX_SIF_LEN ];

  UCP_TRACE( P_DataCnv );

  memset(caOutBuf,   '\0', MAX_SIF_LEN);
  memset(caConvData, '\0', MAX_SIF_LEN);
  memcpy(caConvData, pcInData, iInDatLen);
  caConvData[ iInDatLen ] = '\0';
/*
  sprintf(g_caMsg, "DataCnv: dump pcInData");
  ErrLog(100, g_caMsg, RPT_TO_LOG, pcInData, iInDatLen);
*/

  switch(pstCtfItem->cDataType) {
  /* following data type can't have 2 or more than 2's '.' in the data area */ 
    case 'q':
    case 'r':
    case 't':
    case 'f':
    case 'g':
    case 'h':
      iRc=CountDot(caConvData); 
      if (iRc >= 2) {
        sprintf(g_caMsg,"DataCnv: CountDot() finds out incorrect %d dots!",iRc);
        ErrLog(1000, g_caMsg , RPT_TO_LOG, 0, 0);
        UCP_TRACE_END( DOT_NUMBER_ERR  );
      }
  }

  StuffData( pstCtfItem, caConvData, iInDatLen );

  iRc = 0;
  switch ( pstCtfItem->cDataType ) {
    case 'p':
    case 'k':
    case 'h':
    case 't':
         iRc = Comp3Cnv( caConvData, caOutBuf );
         if  (iRc < 0)   {
           ErrLog(1000, "DataCnv: Comp3Cnv() fails!", RPT_TO_LOG, 0, 0);
           UCP_TRACE_END( iRc );
         }
         /* PACK CONVERT OK */
         break;
    case 'b':
    case 'j':
    case 'g':
    case 'r':
         if (pstCtfItem->iDataLen < 5) {
           iRc = ShortCnv( caConvData, caOutBuf );
           if  (iRc < 0)  {
             ErrLog(1000, "DataCnv: ShortCnv() fails!", RPT_TO_LOG, 0, 0);
             UCP_TRACE_END( iRc );
           }
           /* SHORT CONVERT OK */
         }
         else {
           iRc = LongCnv( caConvData, caOutBuf );
           if (iRc < 0)   {
             ErrLog(1000, "DataCnv: LongCnv() fails!", RPT_TO_LOG, 0, 0);
             UCP_TRACE_END( iRc );
           }
           /* LONG CONVERT OK */
         }
         break;
    case '9':
    case 'f':
         iRc = AsiCnv( caConvData, caOutBuf );
         if (iRc < 0)  {
           ErrLog(1000, "DataCnv: AsiCnv() fails!", RPT_TO_LOG, 0, 0);
           UCP_TRACE_END( iRc );
         }
         break;
    case 'x':
    case 'y':
/* Modify By WuChihLiang 19950912 for process data content is binary -- BEGIN */
         /*iRc = AsciiCnv( caConvData, caOutBuf );
         if (iRc < 0)   {
           sprintf(g_caMsg, "DataCnv: AsciiCnv() data convert error!");
           ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
           DetErrRpt( ASCIICNV_ERR, g_caMsg );
           UCP_TRACE_END( ASCIICNV_ERR );
         }*/
         memcpy(caOutBuf, caConvData, pstCtfItem->iCtfLen );
/* Modify By WuChihLiang 19950912 for process data content is binary -- END   */
         /* ASCII CONVERT OK */
         break;
    case 'i':
    case 'q':
         iRc = SasciiCnv( caConvData, caOutBuf );
         if (iRc < 0)   {
           ErrLog(1000, "DataCnv: SasciiCnv() fails!", RPT_TO_LOG, 0, 0);
           UCP_TRACE_END( iRc );
         }
         /* SIGNED ASCII CONVERT OK */
  }

  memcpy( pcOutData, caOutBuf, pstCtfItem->iCtfLen );

  UCP_TRACE_END(0);
}

/************************************************************************/
/*      StuffData() : stuffing data                                      */
/************************************************************************/
int
StuffData( pstCtfItem, pcData, iInDataLen )
tbl_item *pstCtfItem;
char *pcData;
int  iInDataLen;
{
  UCP_TRACE(P_StuffData);

  switch( pstCtfItem->cDataType ) {
    case 'i':
    case 'j':
    case 'k':
         SignStuff( pcData );
    case '9':
    case 'b':
    case 'p':
         IntStuff( pstCtfItem->iDataLen, pcData );
         break;
    case 'q':
    case 'r':
    case 't':
         SignStuff( pcData );
    case 'f':
    case 'g':
    case 'h':
         FloatStuff( pstCtfItem, pcData );
         break;
    case 'x':
    case 'y':
         CharStuff( pstCtfItem, pcData, iInDataLen );
  }

  UCP_TRACE_END( 0 );
}

/************************************************************************/
/*      SignStuff() : sign symbol stuffing                               */
/************************************************************************/
int
SignStuff( pcData )
char *pcData;
{
  int i;
  char caStuffData[ MAX_SIF_LEN ];

  UCP_TRACE(P_SignStuff);

  if (pcData[0] != '+' && pcData[0] != '-') {
    caStuffData[0] = '+';
    strcpy(caStuffData + 1, pcData);
    strcpy(pcData, caStuffData);
  }

  UCP_TRACE_END(0);
}

/************************************************************************/
/*      IntStuff() : integer data stuffing                              */
/************************************************************************/
int
IntStuff( iDataLen, pcData )
int iDataLen;
char *pcData;
{
  int  i, j, k;
  char cCh;
  char caStuffData[ MAX_SIF_LEN ];

  UCP_TRACE(P_IntStuff);

  i = 0;
  while (pcData[ i ]) {
    i++;
  }

  k = iDataLen;
  caStuffData[ k-- ] = '\0';

  for (j = i - 1; j > 0 ; j --) {
    caStuffData[ k-- ] = pcData[ j ];
  }

  if ( j < 0 ) {
    j = 0;
    pcData[ j ] = '0';
  }

  if ((cCh = pcData[ j ]) != '+' && cCh != '-') {
    caStuffData[ k-- ] = cCh;
    cCh = '0';
  }

  if (k >= 0) {
    for ( ; k > 0; k-- ) {
      caStuffData[ k ] = '0';
    }
    caStuffData[ k ] = cCh;
  }

  strcpy(pcData, caStuffData);

  UCP_TRACE_END(0);
}

/************************************************************************/
/*      FloatStuff() : floating point data stuffing                       */
/************************************************************************/
FloatStuff( pstCtfItem, pcData )
tbl_item *pstCtfItem;
char *pcData;
{
  int  i, j, k, l;
  char cCh;
  char caStuffData[ MAX_SIF_LEN ];

  UCP_TRACE(P_FloatStuff);

  i = j = 0;
  while ((cCh = pcData[i]) != '.' && cCh != '\0') {
    i++;
  }

  l = i + 1;
  k = pstCtfItem->iDataLen - pstCtfItem->iDotPos;

  while (pcData[l]) {
    caStuffData[ k++ ] = pcData[ l++ ];
    j ++;
  }

  for ( ; j < pstCtfItem->iDotPos; j++) {
    caStuffData[ k++ ] = '0';
  }
  caStuffData[ k ] = '\0';

  k = pstCtfItem->iDataLen - pstCtfItem->iDotPos - 1;
  caStuffData[ k-- ] = '.';

  for (j = i - 1; j > 0; j--) {
    caStuffData[ k-- ] = pcData[ j ];
  }

  if (j < 0) {
    j = 0;
    pcData[ j ] = '0';
  }

  if ((cCh = pcData[ j ]) != '+' && cCh != '-') {
    caStuffData[ k-- ] = cCh;
    cCh = '0';
  }

  if (k >= 0) {
    for ( ; k > 0; k-- ) {
      caStuffData[ k ] = '0';
    }
    caStuffData[ k ] = cCh;
  }

  strcpy(pcData, caStuffData);

  UCP_TRACE_END(0);
}

/************************************************************************/
/*      CharStuff() : character data stuffing                            */
/************************************************************************/
CharStuff( pstCtfItem, pcData, iInDataLen )
tbl_item *pstCtfItem;
char *pcData;
int  iInDataLen;
{
  int   i, j;
  char  cCh;
  char  caStuffData[ MAX_SIF_LEN ];

  UCP_TRACE(P_CharStuff);

  i = 0;
  /* Modify By WuChihLiang 19950925 for support input data is binary -- BEGIN*/
  /*while (cCh = pcData[ i ]) {
    caStuffData[ i++ ] = cCh;
  }*/
  while (i < iInDataLen) {
    cCh = pcData[ i ];
    caStuffData[ i++ ] = cCh;
  }
  /* Modify By WuChihLiang 19950925 for support input data is binary -- END  */

  j = pstCtfItem->iDataLen;
  for ( ; i < j; i++) {
    caStuffData[ i ] = 0x20;
  }

  /* Modify By WuChihLiang 19950925 for support input data is binary -- BEGIN*/
  /*caStuffData[ i ] = '\0';
  strcpy(pcData, caStuffData);*/
  memcpy(pcData, caStuffData, pstCtfItem->iDataLen);
  /* Modify By WuChihLiang 19950925 for support input data is binary -- END  */

  UCP_TRACE_END(0);
}

/************************************************************************/
/*      PackFunc() : pack data convert function                         */
/************************************************************************/
char *
PackFunc(pcUnpackList, iUnpackLen)
char *pcUnpackList;
int iUnpackLen;
{
  int i, j;
  char cHighByte;
  static char caPackList[ MAX_SIF_LEN / 2 ]; /* for returning, must be static */
  char caUnpackData[ MAX_SIF_LEN ];

  UCP_TRACE(P_PackFunc);

  if (iUnpackLen % 2) {
    memcpy(caUnpackData + 1, pcUnpackList, iUnpackLen);
    caUnpackData[ 0 ] = '0';
    iUnpackLen ++;
  }
  else {
    memcpy(caUnpackData, pcUnpackList, iUnpackLen);
  }

  for (i = j = 0; i < iUnpackLen; j++) {
    if (i % 2) {
      caPackList[j/2] = (caUnpackData[ i++ ] - '0') + cHighByte;
    }
    else {
      cHighByte = ((caUnpackData[ i++ ] - '0') << 4) & 0xf0;
    }
  }
  caPackList[ j/2 ] = '\0';

  UCP_TRACE_END(caPackList);
}

/************************************************************************/
/*      Comp3Cnv() : comp-3 data convert                                */
/************************************************************************/
int
Comp3Cnv( pcComp3Data, pcOutBuf )
char *pcComp3Data;
char *pcOutBuf;
{
  int   i, j;
  int   iPackLen;
  char  cCh;
  char  cSign;
  char  caPackData[ MAX_SIF_LEN ];

  UCP_TRACE(P_Comp3Cnv);

  i = j = 0;
  cCh = pcComp3Data[i];
  if (cCh == '+' || cCh == '-') {
    if (cCh == '+') {
      cSign = 0x3c;
    }
    else {
      cSign = 0x3d;
    }

    i++;
  }
  else {
    cSign = 0x3c;
  }

  while (cCh = pcComp3Data[i++]) {
    if (cCh >= '0' && cCh <= '9' || cCh == '.') {
      if (cCh != '.') {
        caPackData[ j++ ] = cCh;
      }
    }
    else {
      sprintf(g_caMsg, "Comp3Cnv: Data convert error!");
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      DetErrRpt( COMP3CNV_ERR, g_caMsg );
      UCP_TRACE_END( COMP3CNV_ERR );
    }
  }

  caPackData[ j++ ] = cSign;
  caPackData[ j  ] = '\0';
  iPackLen = j / 2 + j % 2;
  memcpy(pcOutBuf, PackFunc(caPackData, j), iPackLen);

  UCP_TRACE_END(0);
}

/************************************************************************/
/*      ShortCnv() : short data convert                                 */
/************************************************************************/
int
ShortCnv( pcShortList, pcOutBuf )
char *pcShortList;
char *pcOutBuf;
{
  int   i;
  char  cCh;
  short sShortData;

  UCP_TRACE(P_ShortCnv);

  i = 0;
  while (cCh = pcShortList[ i++ ]) {
    if (cCh < '0' || cCh > '9') {
      sprintf(g_caMsg, "ShortCnv: Data convert error!");
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      DetErrRpt(  SHORTCNV_ERR, g_caMsg );
      UCP_TRACE_END( SHORTCNV_ERR );
    }
  }

  sShortData = atoi( pcShortList );
  memcpy(pcOutBuf, &sShortData, sizeof( short ));

  UCP_TRACE_END(0);
}


/************************************************************************/
/*      LongCnv() : long data convert                                  */
/************************************************************************/
int
LongCnv( pcLongList, pcOutBuf )
char *pcLongList;
char *pcOutBuf;
{
  int  i;
  char cCh;
  long lLongData;

  UCP_TRACE(P_LongCnv);

  i = 0;
  while (cCh = pcLongList[ i++ ]) {
    if (cCh < '0' || cCh > '9') {
      sprintf(g_caMsg, "LongCnv: Data convert error");
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      DetErrRpt( LONGCNV_ERR, g_caMsg );
      UCP_TRACE_END( LONGCNV_ERR );
    }
  }

  lLongData = atol( pcLongList );
  memcpy( pcOutBuf, &lLongData, sizeof( long ));

  UCP_TRACE_END(0);
}

/************************************************************************/
/*      AsciiCnv() : ascii data convert                                 */
/************************************************************************/
int
AsciiCnv( pcCharList, pcOutBuf )
char *pcCharList;
char *pcOutBuf;
{
  UCP_TRACE(P_AsciiCnv);

  memcpy( pcOutBuf, pcCharList, strlen( pcCharList ));

  UCP_TRACE_END(0);
}

int
AsiCnv( pcCharList, pcOutBuf )
char *pcCharList;
char *pcOutBuf;
{
  int  i, j;
  char cCh;
  char caCharData[ MAX_SIF_LEN ];

  UCP_TRACE(P_AsiCnv);

  i = j = 0;
  while (cCh = pcCharList[ i++ ]) {
    if (cCh >= '0' && cCh <= '9' || cCh == '.') {
      if (cCh != '.') {
        caCharData[ j++ ] = cCh;
      }
    }
    else {
      sprintf(g_caMsg, "AsiCnv: Data convert error");
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      DetErrRpt( ASICNV_ERR, g_caMsg );
      UCP_TRACE_END( ASICNV_ERR );
    }
  }

  caCharData[ j ] = '\0';
  memcpy(pcOutBuf, caCharData, strlen( caCharData ));

  UCP_TRACE_END(0);
}

/* ******************************************************************** */
/*      SasciiCnv() : signed ascii data convert                         */
/*                                                                      */
/*      LPI COBOL          MF COBOL                                     */
/*        cSign             cSign                                       */
/*   -----------------------------------                                */
/*    +d  0x10              0x00   ( d = 1 .. 9 )                       */
/*    -d  0x19              0x40   ( d = 1 .. 9 )                       */
/*    +0  0x4b              0x00                                        */
/*    -0  0x4d              0x40                                        */
/* ******************************************************************** */
int
SasciiCnv( pcCharList, pcOutBuf )
char *pcCharList;
char *pcOutBuf;
{
  int   i, j, k;
  char  cCh;
  char  cSign;
  char  caCharData[ MAX_SIF_LEN ];

  UCP_TRACE(P_SasciiCnv);

  k = strlen( pcCharList );
  i = j = 0;
  cCh = pcCharList[i];

  if (cCh == '+' || cCh == '-') {
    if (cCh == '+')
      cSign = PLUS_SIGN;
    else
      cSign = MINUS_SIGN;
    i++;
  }
  else {
    cSign = 0x00;
  }

  while (cCh = pcCharList[ i++ ]) {
    if (cCh >= '0' && cCh <= '9' || cCh == '.') {
      if (cCh != '.') {
        caCharData[ j++ ] = cCh;
      }
    }
    else {
      sprintf(g_caMsg, "SasciiCnv: Data convert error");
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      DetErrRpt( SASCIICNV_ERR, g_caMsg );
      UCP_TRACE_END( SASCIICNV_ERR );
    }
  }

  if (caCharData[ j - 1 ] == '0') {
    if (pcCharList[ 0 ] == '+') {
      cSign = PLUS_ZERO;
    }
    else if (pcCharList[ 0 ] == '-') {
      cSign = MINUS_ZERO;
    }
  }

  caCharData[ j - 1 ] = caCharData[ j - 1 ] + cSign;
  caCharData[ j ] = 0;
  memcpy(pcOutBuf, caCharData, strlen( caCharData ));

  UCP_TRACE_END(0);
}


int
CountDot(char *pcData)
{
  int iDotCnt;
  int i;

  iDotCnt=0;
  for(i=0;i<strlen(pcData);i++) {
    if (pcData[i] == '.') {
      iDotCnt++;
    }
  }
  return(iDotCnt); 
}
