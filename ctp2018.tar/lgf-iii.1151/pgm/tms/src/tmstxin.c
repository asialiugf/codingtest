/*
 *&N& File : tmstxin.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int       TxInput()              �����J��Ʒǳ�
 *&N&    char      TxKind()               �P�_�����J��ƪ�����
 *&N&    int       ListTxIn()             �B�z��C��J
 *&N&    int       MultTxIn()             �B�z�h����J
 *&N&    int       SeqIntIn()             �`�ǳs�ʸ�Ʒǳ� (�ǳƳs�ʿ�J���)
 *&N&    int       InputChk()             ��J��ƨӷ��ˮ�
 *&N&    int       SetInDataType()        �]�w��J����ƫ��A
 *&N&    char      GetInTypeFromSif()     ���o��J��ƪ� SIF ������줸
 *&N&    int       SetTime()              �]�w�ɶ�
 *&N&    int       RentryCk()             �ˬd��e�Ǹ��O�_����
 *&N&    int       IsRentryTm()           �ھ� SIF ������줸�P�_�O�_��
 *&N&                                     ��e�׺ݾ��e�Ӫ����
 *&N&    int       ChkTerml()             �׺ݾ��X�k���ˮ�
 *&N&    int       ComputTime()           �p�����B�z�ɶ�
 *&N&    int       IsMultipleBegin()      �h����ƪ��C�ӥ���}�l
 *&N&    int       IsListBegin()          ��C��ƪ��C�ӥ���}�l
 *&N&    int       IsMultipleEnd()        �h����ƪ��C�ӥ������
 *&N&    int       IsListEnd()            ��C��ƪ��C�ӥ������
 *&N&    int       IsMultipleDataEnd()    �h����ƬO�_�wŪ��
 *&N&    int       IsListDataEnd()        ��C��ƬO�_�wŪ��
 */

/* ------------------------- INCLUDE FILES ---------------------------- */
#include <sys/types.h>
#include <sys/times.h>
#include <time.h>
#include "errlog.h"
#include "twa.h"
#include "cwa.h"
#include "tms.h"
#include "tmctxin.h"
#include "tmcinedt.h"
#include "tmcpgdef.h"	/* TMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */

/* ------------------------- CONSTANT DEFINITION ---------------------- */
/* tmstxin.c 
#define P_TxInput 		24001
#define P_TxKind 		24002
#define P_ListTxIn 		24003
#define P_SeqIntIn 		24004
#define P_InputChk 		24005
#define P_SetInDataType 	24006
#define P_GetInTypeFromSif 	24007
#define P_SetTime 		24008
#define P_ChkTerml 		24009
#define P_IsRentryTm 		24010
#define P_RentryCk 		24011
#define P_ComputTime 		24012
#define P_MultTxIn 		24013
#define P_IsMultipleBegin       24014
#define P_IsListBegin           24015
#define P_IsMultipleEnd         24016
#define P_IsListEnd             24017
#define P_IsMultipleDataEnd     24018
#define P_IsListDataEnd         24019
*/
#define INIT_INPUT		'I'
#define LIST_INPUT		'L'
#define MULT_INPUT		'M'
#define SEQ_INPUT		'S'

#define PRE_TX_END		'0'
#define TX_START		'1'

#define NO			'0'
#define YES			'1'

#define  REENTRY_TM             '9'  /* added by chi-fusong, 1995/03/26 */
#define DATA_FMT_LEN		4
#define CONV_IN			0
#define CONV_OUT		1

#define  TXN_ENABLE         0x0200

/* To avoid duplication of txn seq. no of the same terminal -- BEGIN */ 
#define IS_ON_TXN               0x80
extern char g_cNeedRelseTrm;
/* To avoid duplication of txn seq. no of the same terminal -- END */ 

/* ------------------ EXTERN VARIABLE DECLARATION --------------------- */
extern int errno;            /* Added by Willy 19970110 */
extern struct TMA *g_pstTma;   /*  Before looping into TxInput,         */
                               /*  g_pstTma->stTCFA.cInDataType         */
                               /*  should be set GENERAL_TXN.           */
extern struct TBA *g_pstTba;
extern struct CWA *g_pstCwa;
extern char g_cErrActFlag;
extern int g_iBrhCodeLen;    /* Branch code real length */
extern int g_iTmCodeLen;     /* Term code real length   */
extern int g_iTxnCodeLen;    /* Txn  code real length   */
extern int g_iSifLen;    /* record the length of SIF,modify by Jess 19950128*/
extern int g_iSeqTxnSifLen;

static int sg_iListTxLen;    /* record the length of List Txn      */
static int sg_iMultTxLen;    /* record the length of Multiple Txn  */
static int sg_iListEndFlag;  /* flag indicate whether LIST is over */
static int sg_iMultEndFlag;  /* flag indicate whether MULT is over */

char g_cApRtnCode='1';       /* record the return code of AP       */

/*--------- CALLED FUNCTION & SUBROUTINE PROTOTYPE DECLARATIONS ------*/
char TxKind();
char GetInTypeFromSif();
char *GetServerId();

/* TCC: 1997/05/14 */
extern int g_iTestMode;

/*
 *&N& ROUTINE NAME: TxInput()
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&   ����Ʈھڿ�J����ƫ��A�H���ͼзǪ� SIF �� CTF
 */

int
TxInput( cErrStep )
char *cErrStep;
{
  char cInDataType;
  char cRendoRqst;
  char cRevTxn;
  char cKind;
  int iRc, iRc0;
  struct MonCmd{
	 char caTblidx[5];
	 char cCmd;
  } stMonCmd;
  char *pcServerId;
  struct CwaCtl stCwaCtl;
  struct SSA    *pstSsa;

  UCP_TRACE( P_TxInput );

  *cErrStep = '0';
  cInDataType  = g_pstTma->stTCFA.cInDataType; 
  cRendoRqst   = g_pstTma->stTCFA.cRendoRequest; 
  cRevTxn      = g_pstTma->stTCFA.cRevTxn;         
  /*
   * after first loop, AP will update these 2 fields above in stTCFA 
   */

  cKind = TxKind( cInDataType, cRendoRqst );
  switch( cKind ) {
    case INIT_INPUT:
         SetTime( PRE_TX_END );
         /*ComputTime(); mark byWuChihLiang*/
         /* added one line by WuChihLiang for clear content of SIF */
         memset( g_pstTba->caSif , '\0', MAX_SIF_LEN);
         iRc = GetInput( g_pstTba->caSif );
         g_iSifLen = iRc ;
         sprintf(g_caMsg,"###<tmstxin.c>g_iSifLen=%d", g_iSifLen);
         ErrLog(100, g_caMsg, RPT_TO_LOG, 0, 0);

         /* TCC: 1997/05/14 Begin */
         stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
         stCwaCtl.cSegCode = CWA_SEG_SSA;
         iRc0 = CwaLowCtlFac(&stCwaCtl,&pstSsa);
         if (iRc0 != 0) {
           sprintf (g_caMsg, "<TMS> Failure to get SSA pointer!");
           ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
           UCP_TRACE_END (GET_SSA_PTR_ERR);
         }

         if (pstSsa->cSysOperatingMode == '1') /* Production Mode */
         {
            if (g_iTestMode == 1)
            {
              ChgLog (LOG_CHG_MODE,"0");
              g_iTestMode = 0;
              ErrLog (1000, "<TMS> Switch to PRODUCT mode", RPT_TO_LOG, 0, 0);
            }
         }
         else
         if (pstSsa->cSysOperatingMode == '2') /* Test Mode */
         {
            if (g_iTestMode == 0)
            {
              ChgLog (LOG_CHG_MODE,"1");
              g_iTestMode = 1;
              ErrLog (1000, "<TMS> Switch to TEST mode", RPT_TO_LOG, 0, 0);
            }
         }
         /* TCC: 1997/05/14 End */

        /* add for sif too long error */
         if ( g_iSifLen > MAX_SIF_LEN ) {
           sprintf(g_caMsg,
     "###<tmstxin.c>SIF length(before decompressed) > MAX_SIF_LEN=520 error");
           ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);         
           UCP_TRACE_END( SIF_LEN_OVERFLOW );
         }

         /* printf("-------SIF len ---------%d------------\n",iRc); */
         if ( iRc  <  SIF_HEAD_LEN ) {
           memcpy(&stMonCmd, &g_pstTba->caSif[4], sizeof(struct MonCmd) );
           /*
           ErrLog(100,"MonCmd=",RPT_TO_LOG,&stMonCmd,sizeof(struct MonCmd) );
           */
           if ( stMonCmd.cCmd == MON_SHUTDOWN) {
             pcServerId = GetServerId();
             iRc = SendShutOkToEms( pcServerId );
             if ( iRc < 0 ) {
               sprintf(g_caMsg, "TxInput: SendShutOkToEms()fails! iRc=%d", iRc);
               ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
             }

             /*
             iRc = RcvTmsShutStus();
             if ( iRc < 0 ) {
               sprintf(g_caMsg, "TxInput: RcvTmsShutStus()fails! iRc=%d", iRc);
               ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
             }
             */

             iRc = EnvRelse();
             if ( iRc < 0 ) {
               exit( -1 );
             }
             exit( 0 );
           }
         }

         ErrLog(100,"<APD>SIF=",RPT_TO_LOG,g_pstTba->caSif, g_iSifLen);
         if (iRc < 0) {
           *cErrStep = '2';
           sprintf(g_caMsg, "TxInput: GetInput() fails! iRc=%d", iRc);
           ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
           UCP_TRACE_END( GET_INPUT_ERR );
         }

         /* TCC: 1997/05/14 Begin */
         if (!(pstSsa->sSysStatus & TXN_ENABLE))
         {
            sprintf (g_caMsg, "<TMS> TPE TXN_ENABLE is disabled! [0x%0x]",
                     pstSsa->sSysStatus & 0x0FFFF);
            ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
            UCP_TRACE_END( TXN_ENABLE_ERR );
         }         
         /* TCC: 1997/05/14 End */
         /*
          * g_cErrActFlag is set to ON (i.e.  already receives SIF )
          */
         g_cErrActFlag = INFORM_DBP_FLAG | g_cErrActFlag;

         cInDataType = GetInTypeFromSif();
         SetInDataType( cInDataType );

         switch( cInDataType ) {
           case LIST_TXN:
                sg_iListTxLen = iRc ;
                sg_iListEndFlag = NO;
                iRc = ListTxIn();
                if (iRc < 0) {
                  *cErrStep = '8';
                  ErrLog(1000,
                         "TxInput: ListTxIn() fails when list input!",
                         RPT_TO_LOG, 0, 0);
                  UCP_TRACE_END( iRc );
                }
                break;
           case MULTIPLE_TXN:
                sg_iMultTxLen = iRc ;
                sg_iMultEndFlag = NO;
                iRc = MultTxIn();
                if (iRc < 0) {
                  *cErrStep = '3';
                  ErrLog(1000,
                         "TxInput: MultTxIn() fails when multiple input!",
                         RPT_TO_LOG, 0, 0);
                  UCP_TRACE_END( iRc );
                }

                iRc = InputChk();
                if (iRc < 0) {
                  *cErrStep = '6';
                  ErrLog(1000, "TxInput: InputChk() fails!", RPT_TO_LOG, 0, 0);
                  UCP_TRACE_END( iRc );
                }

                break;
           default:
                SetTime( TX_START );

                iRc = InputCnv();
                if (iRc < 0) {
                  *cErrStep = '5';
                  ErrLog(1000, "TxInput: InputCnv() fails!", RPT_TO_LOG, 0, 0);
                  UCP_TRACE_END( iRc );
                }

                iRc = InputChk();
                if (iRc < 0) {
                  *cErrStep = '6';
                  ErrLog(1000, "TxInput: InputChk() fails!", RPT_TO_LOG, 0, 0);
                  UCP_TRACE_END( iRc );
                }
                break;
         }
         break;
    case LIST_INPUT:
         iRc = ListTxIn();
         if (iRc < 0) {
           *cErrStep = '8';
           ErrLog(1000, "TxInput: ListTxIn() fails when list input!",
                  RPT_TO_LOG, 0, 0);
           UCP_TRACE_END( iRc );
         }
         break;
    case MULT_INPUT:
         iRc = MultTxIn();
         if (iRc < 0) {
           *cErrStep = '3';
           ErrLog(1000, "TxInput: MultTxIn() fails when multiple input!",
                  RPT_TO_LOG, 0, 0);
           UCP_TRACE_END( iRc );
         }
         break;
    case SEQ_INPUT:
         iRc = SeqIntIn();
         if (iRc < 0) {
           *cErrStep = '4';
           ErrLog(1000, "TxInput: SeqIntIn() fails!", RPT_TO_LOG, 0, 0);
           UCP_TRACE_END( GET_SEQINT_ERR );
         }
         break;
    default:  /* error input type */
         *cErrStep = '1';
         sprintf(g_caMsg, "TxInput: Invalid input data type=%c,%2x", 
                 cKind, cKind );
         ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
         UCP_TRACE_END( TXINPUT_TYPE_ERR );
  }

  iRc = InputEdt( g_pstTba->caSif, g_pstTba->caCtf );
  if (iRc < 0) {
    *cErrStep = '7';
    ErrLog(1000, "TxInput: InputEdt() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( iRc );
  }

  UCP_TRACE_END( 0 );
}

/*
 *&N& ROUTINE NAME: TxKind()
 *&A& ARGUMENTS:
 *&A&     NAME                TYPE                  DESCRIPTION
 *&A&   -------------------------------------------------------------
 *&A&    cDataType            char                 ��J����ƫ��A
 *&A&    cRendoRqst           char                 ����B�z���A
 *&A&    cRevTxn              char                 �O�_���R�����X��
 *&A&
 *&R& RETURN VALUE(S):
 *&R&   INIT_INPUT: �����J��Ƭ����`��J
 *&R&   COMP_INPUT: �����J��Ƭ��ƦX��J (�h���Φ�C)
 *&R&   SEQ_INPUT : �����J��Ƭ��s�ʿ�J (�R���δ`��)
 *&R&      -1     : �H�W�ҫD
 *&R&
 *&D& DESCRIPTION:
 *&D&   ����Ʈھڿ�J����ƫ��A (cDataType) �P����B�z���A (cRendoRqst),
 *&D&   �Ǧ^�@�r���ΥH���������J��ƪ�����,����ƪ��I�s��ƥi�ڦ��A�M�w
 *&D&   �O�_�n�����������J���
 */

char
TxKind( cDataType, cRendoRqst )
char cDataType;
char cRendoRqst;
{
  char cKind;

  UCP_TRACE( P_TxKind );

/*
  sprintf(g_caMsg, "TxKind: cDataType = %c, cRendoRqst = %c",
          cDataType, cRendoRqst);
  ErrLog(100, g_caMsg, RPT_TO_LOG, 0, 0);
*/

  if((cDataType == GENERAL_TXN || cDataType == COOPERATIVE_TXN) 
     && cRendoRqst == TMS_TXN_NOT_RENDO){
    cKind = INIT_INPUT;
  }
  else if (cDataType == LIST_TXN && cRendoRqst == TMS_TXN_NOT_RENDO){
    cKind = LIST_INPUT;
  }
  else if (cDataType == MULTIPLE_TXN && cRendoRqst == TMS_TXN_NOT_RENDO){
    cKind = MULT_INPUT;
  }
  else if (cRendoRqst == TMS_TXN_RENDO ){
    cKind = SEQ_INPUT;
  }
  else {
    cKind = -1;
  }

  UCP_TRACE_END( cKind );
}

/*
 *&N& ROUTINE NAME: SetInDataType()
 *&A& ARGUMENTS:
 *&A&     NAME                TYPE                  DESCRIPTION
 *&A&   -------------------------------------------------------------
 *&A&    cDataType            char                  ��J����ƫ��A
 *&A&
 *&R& RETURN VALUE(S):
 *&R&   �L
 *&R&   
 *&D& DESCRIPTION:
 *&D&   �]�w��J����ƫ��A (��s TCFA ���� cInDataType )
 */

int
SetInDataType( cDataType )
char cDataType;
{
  UCP_TRACE( P_SetInDataType );

  g_pstTma->stTCFA.cInDataType = cDataType;

  UCP_TRACE_END( 0 );
}

/*
 *&N& ROUTINE NAME: GetInTypeFromSif()
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&   LIST_TXN    :     �����J��Ƭ���C��J
 *&R&   MULTIPLE_TXN:     �����J��Ƭ��h����J
 *&R&   GENERAL_TXN  :     �����J��Ƭ��浧��J
 *&R&   
 *&D& DESCRIPTION:
 *&D&   ����ƥΥH���o��J��ƪ� SIF ������줸,�Y�Ӧ줸�N����J��ƬO�h����J
 *&D&   �h�Ǧ^ MULTIPLE_TXN, �O��C��J�h�Ǧ^ LIST_TXN, ��l�h�Ǧ^ GENERAL_TXN
 *&D&   ps. �ثe�� tms �u�B�z�浧���,�ҥH�Ǧ^ GENERAL_TXN, ��l�O�d�H��ϥ�
 */

char
GetInTypeFromSif()
{
  char cSifCtlData1;

  UCP_TRACE( P_GetInTypeFromSif );


  cSifCtlData1 = g_pstTba->caSif[CTL_BYTE_OFFSET];
  /* 
   * �p�G�O��e���,�h�]�wTCFA.cReentryStatus,�H��TxEndInform()�@���g�ɪ�
   * �̾�. �Y�O��e���, �u���g�J�Ĥ@��SOF���ɮרçi���w�LTPEO���
   */
  if ( cSifCtlData1 & REENTRY_MASK ) {
    g_pstTma->stTCFA.cReentryStatus = TMS_TXN_REENTRY; /* ��e��� */
  }
  else {
    g_pstTma->stTCFA.cReentryStatus = TMS_TXN_NOT_REENTRY; /* �@���� */
  }

  /* added by WuChihLiang 19950302 for COOPERATIVE TXN -- Begin */
  if ( cSifCtlData1 & COOPERATIVE_MASK ) {
    g_pstTma->stTCFA.cTxnPattern = COOPERATIVE_TXN;
    UCP_TRACE_END( COOPERATIVE_TXN );
  }else{
    g_pstTma->stTCFA.cTxnPattern = LOCAL_TXN;
  }
  /* added by WuChihLiang 19950302 for COOPERATIVE TXN -- End   */

  if ( cSifCtlData1 & LIST_MASK ) {
    UCP_TRACE_END( LIST_TXN );
  }
  else {
    if ( cSifCtlData1 & MULTIPLE_MASK ) {
      UCP_TRACE_END( MULTIPLE_TXN );
    }
    else {
      UCP_TRACE_END( GENERAL_TXN );
    }
  }
}

/*
 *&N& ROUTINE NAME: ListTxIn()
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&   �B�z��C��J
 */
int 
ListTxIn()
{
  UCP_TRACE( P_ListTxIn );
  UCP_TRACE_END( 0 );
}


/*
 *&N& ROUTINE NAME: MultTxIn()
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    1      : ����ư��榨�\, No Multiple data.
 *&R&    0      : ����ư��榨�\, Still have Multiple.
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&   �B�z�h����J
 */
int
MultTxIn()
{

  static char s_caMultTxData[MAX_SIF_LEN];
  static int s_iBeenReadLen ;        /* the total length until last read */
  static char s_cFirstFlag = NULL ;
  char caTxnCode[4];
  txn_head stTxnDesc;   /* transaction characteristic description  */
  short sItemLen;       /* used to store the length of each item   */ 
  int iCurSifLen;       /* current SIF length                      */
  int iCurPtr;          /* dynamic ptr                             */
  int iRc , i;
  
  UCP_TRACE( P_MultTxIn );

  if ( s_cFirstFlag == NULL ) {
    memset(s_caMultTxData, 0, MAX_SIF_LEN);
    memcpy(s_caMultTxData, g_pstTba->caSif, sg_iMultTxLen);
    s_iBeenReadLen = 0 ;
    s_cFirstFlag = 'N';
  }
  
  iCurSifLen = 0;
  iCurPtr = s_iBeenReadLen;

  GetTxnCode( caTxnCode, &s_caMultTxData[iCurPtr] );

  iRc = ReadIet( TXN_DESC, RANDOM_READ, caTxnCode, (char *)&stTxnDesc );
  if (iRc < 0) {
    sprintf(g_caMsg, "MultTxIn: ReadIet() fails! (transcation node)");
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( MULTTXIN_TXN_ERR, g_caMsg );
    UCP_TRACE_END( MULTTXIN_TXN_ERR );
  }
  
  iCurSifLen += SIF_HEAD_LEN;
  iCurPtr += SIF_HEAD_LEN;

  if ( stTxnDesc.sTotItem > 0 ) {
    for ( i = 0 ; i < stTxnDesc.sTotItem ; i++) {
      memcpy(&sItemLen, &s_caMultTxData[iCurPtr], sizeof(short) );
      iCurPtr += sizeof(short);
      iCurPtr += sItemLen;
      iCurSifLen += sizeof(short);
      iCurSifLen += sItemLen;
    }
  }

  memcpy( g_pstTba->caSif, &s_caMultTxData[s_iBeenReadLen], iCurSifLen );
  s_iBeenReadLen += iCurSifLen;

  if ( s_iBeenReadLen == sg_iMultTxLen ) { /* Mult. Data has been read over */
    s_cFirstFlag = NULL;
    sg_iMultEndFlag = YES;
    UCP_TRACE_END( 1 );
  }

  UCP_TRACE_END( 0 );
}


/*
 *&N& ROUTINE NAME: SeqIntIn()
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&   �`�ǳs�ʸ�Ʒǳ� (�ǳƳs�ʿ�J���)
 */

int
SeqIntIn()
{
  int iRc ;

  UCP_TRACE( P_SeqIntIn );

  if ( g_pstTma->stTCFA.cRevTxn == TMS_TXN_NOT_REVERSE ) {
    memset(g_pstTba->caSif, 0, MAX_SIF_LEN);
    memcpy(g_pstTba->caSif, g_pstTba->caRendo, MAX_SIF_LEN);
    g_iSifLen = g_iSeqTxnSifLen;
    ErrLog(100,"SeqIntIn: SIF DUMP=",RPT_TO_LOG, g_pstTba->caSif, g_iSifLen);
  }
  else {
    memset(g_pstTba->caSif, 0, MAX_SIF_LEN);
    memset(g_pstTba->caRev, 0, MAX_REV_LEN);
    iRc = GetRvsSif(g_pstTba->caRev,g_pstTba->caSif);
    if ( iRc < 0 ) {
      UCP_TRACE_END(-1);
    }

    /*
     * iRc = 0 indicate that this is the last SIF & REV 
     * iRc > 0 indicate that this is not the last SIF & REV
     */
    if ( iRc == 0 ) {
      g_pstTma->stTCFA.cRevContinue=TMS_REV_CONTINUE_OFF;
    }
    else {
      g_pstTma->stTCFA.cRevContinue=TMS_REV_CONTINUE_ON;
    }

    ErrLog(100,"SeqIntIn: GetRev SIF DUMP=",RPT_TO_LOG, 
           g_pstTba->caSif,MAX_SIF_LEN);
    ErrLog(100,"SeqIntIn: GetRev REV DUMP=",RPT_TO_LOG,
           g_pstTba->caRev,MAX_REV_LEN);
  }

  UCP_TRACE_END( 0 );
}

/*
 *&N& ROUTINE NAME: InputChk()
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&    ��J��ƨӷ��ˮ�
 */

int
InputChk()
{
  int iRc;
  int iTctIndex;
  int iIsRentryTm;
  char caBr[MAX_BR_LEN];
  char caTm[MAX_TM_LEN];
  char caBuf[MAX_SIF_LEN];
  char *pcTerm=NULL;
  struct TermArea *pstTerm;

  UCP_TRACE( P_InputChk );

  memset(caBr,0,MAX_BR_LEN);
  memcpy(caBr,&g_pstTba->caSif[BR_CODE_OFFSET],g_iBrhCodeLen);
  memset(caTm,0,MAX_TM_LEN);
  memcpy(caTm,&g_pstTba->caSif[TM_CODE_OFFSET],g_iTmCodeLen);

  iRc = ChkTerml( caBr , caTm , &pcTerm , g_pstTma->stTCFA.cReentryStatus);
  if (iRc < 0 ) {
    sprintf( g_caMsg, "InputChk: ChkTerml() fails! ");
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( iRc );
  }

  /* To avoid duplication of txn seq. no of the same terminal -- BEGIN */ 
  iRc = ChkTrmAvailable(caBr,caTm);
  if (iRc < 0 ) {
    sprintf( g_caMsg, "InputChk: ChkTrmAvailable() fails! ");
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( iRc );
  }
  /* To avoid duplication of txn seq. no of the same terminal -- END */ 

  /* Add By ChiiFuSong 1994/10/15 */
/*
  sprintf(g_caMsg,"pcTerm Address=%4x Br=%.3s Tm=%.2s",pcTerm,caBr,caTm);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
*/
  pstTerm = (struct TermArea *) pcTerm;
  g_pstTma->stTSSA.lAccTxnSeqNo    = pstTerm->lAccTxnNo;
  g_pstTma->stTSSA.lNonAccTxnSeqNo = pstTerm->lNonAccTxnNo;
  g_pstTma->stTSSA.lBtchTxnSeqNo = pstTerm->lBtchTxnNo;
/* add by WuChihLiang 19950315 -- BEGIN */
  g_pstTma->stTSSA.cTmType  = pstTerm->cTermType ;
/* add by WuChihLiang 19950315 -- END   */

/*
  sprintf(g_caMsg,"InputChk: lAccTxnSeqNo=%d,lNonAccTxnSeqNo=%d",
          pstTerm->lAccTxnNo,pstTerm->lNonAccTxnNo);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
*/

  iIsRentryTm = IsRentryTm( &g_pstTba->caSif[ CTL_BYTE_OFFSET ] );
  if ( iIsRentryTm ) {
    iRc = RentryCk( g_pstTba->caSif + SIF_HEAD_LEN,
                    &( ((struct TermArea *)pcTerm)->lBtchTxnNo ) );
  
    if (iRc < 0) {
      ErrLog(1000, "InputChk: RentryCk() fails!", RPT_TO_LOG, 0, 0);
      UCP_TRACE_END( iRc );
    }

    /* --- add by chi-fusong , 1995/03/29 -------------------------- */
    /* ---added for cuting the first input item (reentry seqno) ---- */
    memset(caBuf, 0, MAX_SIF_LEN);
    memcpy(caBuf,g_pstTba->caSif,SIF_HEAD_LEN);
    memcpy(&caBuf[SIF_HEAD_LEN],&g_pstTba->caSif[SIF_HEAD_LEN+2+g_iBrhCodeLen
           +g_iTmCodeLen+5], 
           g_iSifLen-SIF_HEAD_LEN-2-g_iBrhCodeLen-g_iTmCodeLen-5);
    g_iSifLen = g_iSifLen - 2 - g_iBrhCodeLen- g_iTmCodeLen - 5;
    memcpy(g_pstTba->caSif,caBuf,g_iSifLen);
    ErrLog(100,"### <tmstxin.c> shifted SIF =",
           RPT_TO_LOG,g_pstTba->caSif, g_iSifLen );
  }

  UCP_TRACE_END( 0 );
}

/*
 *&N& ROUTINE NAME: ChkTerml()
 *&A& ARGUMENTS:
 *&A&   NAME         TYPE                DESCRIPTION
 *&A& ------------------------------------------------------------------
 *&A& pcBrCode       char *              ����N��
 *&A& pcTmCode       char *              �׺ݾ��N��
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    int     : �Y�Ӳ׺ݾ��b BIT �����w�q,�h�Ǧ^�b BIT ���� index
 *&R&    -1      : �_�h,�Ǧ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D&    �ھ� SIF ������O�P�׺ݾ��N��,�ˮָӲ׺ݾ��O�_�b�t�Ϊ�
 *&D&    ����ݥ�����( BIT )�����w�q 
 */

int
ChkTerml( pcBrCode, pcTmCode , ppcTerm , cReentryStatus)
char *pcBrCode;
char *pcTmCode;
char **ppcTerm;
char cReentryStatus;
{
  int iRc;
  struct CwaCtl stCwaCtl;

  UCP_TRACE( P_ChkTerml );
  stCwaCtl.cFunCode = CWA_GET_TERM_PTR;
  memcpy(stCwaCtl.caBrhId, pcBrCode, g_iBrhCodeLen);
  memcpy(stCwaCtl.caTermId, pcTmCode, g_iTmCodeLen);
  iRc = CwaLowCtlFac(&stCwaCtl, ppcTerm);
  if ( iRc < 0 ) {
    /* the terminal has not been registered in BIT */
    sprintf( g_caMsg, "ChkTerml: Terminal not registered in BIT" );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( CHK_TERML_ERR, g_caMsg );
    UCP_TRACE_END( CHK_TERML_ERR );
  }
/*
  ErrLog(100,"ChkTerml: Terml struct=",RPT_TO_LOG,
         *ppcTerm, sizeof(struct TermArea) );
*/

  /* added by chi-fusong, 1995/03/26 */
  if ( cReentryStatus == TMS_TXN_REENTRY ) {
    if ( ((struct TermArea *)(*ppcTerm))->cTermType != REENTRY_TM ) {
      sprintf(g_caMsg,
        "ChkTerml: Branch[%.*s] Terminal[%.*s] is not a Reentry TM in BIT",
        g_iBrhCodeLen,pcBrCode,g_iTmCodeLen,pcTmCode );
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      UCP_TRACE_END( CHK_REENTRY_TM_ERR );
    }
  }
  else {
    if ( ((struct TermArea *)(*ppcTerm))->cTermType == REENTRY_TM ) {
      sprintf(g_caMsg,
        "ChkTerml: Branch[%.*s] Terminal[%.*s] is not a Online TM in BIT",
        g_iBrhCodeLen,pcBrCode,g_iTmCodeLen,pcTmCode );
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      UCP_TRACE_END( CHK_ONLINE_TM_ERR );
    }
  }

  UCP_TRACE_END( 0 ) ;
}

/*
 *&N& ROUTINE NAME: IsRentryTm()
 *&A& ARGUMENTS:
 *&A&   NAME         TYPE                DESCRIPTION
 *&A& ------------------------------------------------------------------
 *&A&  cSifCtlByte   char                SIF ������줸
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : SIF ������줸�� bit 7 �� 0 (���`)
 *&R&    1      : SIF ������줸�� bit 7 �� 1 (��e)
 *&R&
 *&D& DESCRIPTION:
 *&D&    �ھ� SIF ������줸�P�_�O�_����e�׺ݾ��e�Ӫ����
 */

int
IsRentryTm(char *pcSifCtlData)
{
  char cSifCtlData1;

  UCP_TRACE( P_IsRentryTm );
  cSifCtlData1 = (char) *pcSifCtlData;

  if ( cSifCtlData1 & REENTRY_MASK ) {  /* B7 = normal or reentry */
    UCP_TRACE_END( 1 );  /* reentry */
  }
  else {
    UCP_TRACE_END( 0 );  /* normal */
  }
}


/*
 *&N& ROUTINE NAME: RentryCk()
 *&A& ARGUMENTS:
 *&A&   NAME           TYPE                DESCRIPTION
 *&A& ------------------------------------------------------------------
 *&A&  pcSifFirstData  char *              ���U�� 
 *&A&  plTctBtchSeqNo  long *              �Ӳ׺ݾ��b TCT ������e�Ǹ�
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ��e�Ǹ�������
 *&R&    -1     : ��e�Ǹ�����
 *&R&
 *&D& DESCRIPTION:
 *&D&    �ˬd��e�Ǹ��O�_����
 *&D&
 *&D&    ��e�׺ݾ��e�Ӫ� SIF �榡:
 *&D&    
 *&D&     0            50 51       52 53
 *&D&    +---------------+-----------+-----------------+---------
 *&D&    |   SIF header  | data1 len |     data 1      | ...
 *&D&    +---------------+-----------+-----------------+---------
 *&D&                     ^
 *&D&                     |
 *&D&                     +--  pcSifFirstData
 *&D&  
 *&D&            53           57
 *&D&           +---------------+
 *&D&    data 1 | batch seq no. |
 *&D&           +---------------+
 *&D&           |<------------->|
 *&D&                5
 *&D&           ^
 *&D&           |
 *&D&           +-- pcSifBtchSqNoPos 
 *&D&  
 */

int
RentryCk(pcSifFirstData, plTctBtchSeqNo)
char *pcSifFirstData;
long *plTctBtchSeqNo;
{
  int iBtchSeqNoLen;
  char caTemp[50];
  int iSifBtchSeqNo;
  char *pcSifBtchSqNoPos;

  UCP_TRACE( P_RentryCk );

  iBtchSeqNoLen = (int) ( ((unsigned char)(*pcSifFirstData)) * 256 +
                  (unsigned char) *(pcSifFirstData+1) );
  sprintf(g_caMsg,"RentryCk: iBtchSeqNoLen=%d",iBtchSeqNoLen);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
                           
  pcSifBtchSqNoPos = pcSifFirstData + 2 + g_iBrhCodeLen + g_iTmCodeLen;
  memcpy(caTemp, pcSifBtchSqNoPos, iBtchSeqNoLen-g_iBrhCodeLen-g_iTmCodeLen);
  caTemp[ iBtchSeqNoLen-g_iBrhCodeLen-g_iTmCodeLen ] = '\0';
  iSifBtchSeqNo = atoi( caTemp );
  sprintf(g_caMsg,"RentryCk: iSifBtchSeqNo=%d",iSifBtchSeqNo);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  /* modify by WuChihLiang 19950513 for CenterHost reentry to BranchHost */
  /* if (iSifBtchSeqNo <= *plTctBtchSeqNo) { */
  if (iSifBtchSeqNo != *plTctBtchSeqNo) {
    sprintf( g_caMsg,
             "RentryCk: Client Reentry-Seq-No=%d, Server Reentry-Seq-No=%d",
             iSifBtchSeqNo,*plTctBtchSeqNo );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( RENTRY_CK_ERR, g_caMsg );
    UCP_TRACE_END( RENTRY_CK_ERR );
  }

  /* added by chi-fusong, 1995/03/26 */
  /* modify by WuChihLiang 19950513 for CenterHost reentry to BranchHost */
  /* *plTctBtchSeqNo)= (long) iSifBtchSeqNo; */
  (*plTctBtchSeqNo)++;
  sprintf(g_caMsg,"RentryCk: plTctBtchSeqNo=%ld",*plTctBtchSeqNo);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
  g_pstTma->stTSSA.lBtchTxnSeqNo=iSifBtchSeqNo;
  UCP_TRACE_END( 0 );
}

/* This function is modified massly by Willy 19970110 */
/*
 *&N& ROUTINE NAME: SetTime()
 *&A& ARGUMENTS:
 *&A&     NAME                TYPE                  DESCRIPTION
 *&A&   -------------------------------------------------------------
 *&A&    cTxTime              char                  ����ɶ�
 *&A&                                               (�X�k����: 
 *&A&                                                  TX_START,
 *&A&                                                  PRE_TX_END)
 *&A&
 *&R& RETURN VALUE(S):
 *&R&   �L
 *&R&
 *&D& DESCRIPTION:
 *&D&   �]�w����ɶ�
 */

int
SetTime( cTxTime )
char cTxTime;
{
  time_t stCurrTime;
  struct tm *pstTm;
  char caDate[9];  /* format=yyyymmdd\0 */
  char caTime[9];  /* format=HH:MM:SS\0 */
  struct tms buffer; 
  static clock_t BeginTime = 0;
  static clock_t EndTime = 0;

  UCP_TRACE( P_SetTime );

  memset( caDate, 0, 9 );
  memset( caTime, 0, 9 );

  stCurrTime = time( NULL );
  if ((pstTm = localtime(&stCurrTime)) == NULL) {
    sprintf(g_caMsg,"SetTime: localtime() errno=%d",errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END( -1 );
  }
  if (strftime(caTime,9,"%T",pstTm) == 0) {
    sprintf(g_caMsg,"SetTime: strftime(%%T) errno=%d",errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
  }

  switch( cTxTime ) {
    case TX_START:
         memcpy(g_pstTma->stTSSA.caStartTxnTime, caTime, 2);
         memcpy(g_pstTma->stTSSA.caStartTxnTime + 2, caTime + 3, 2);
         memcpy(g_pstTma->stTSSA.caStartTxnTime + 4, caTime + 6, 2);
         BeginTime = times(&buffer);
         break;
    case PRE_TX_END:
         memcpy(g_pstTma->stTSSA.caEndTxnTime, caTime, 2);
         memcpy(g_pstTma->stTSSA.caEndTxnTime + 2, caTime + 3, 2);
         memcpy(g_pstTma->stTSSA.caEndTxnTime + 4, caTime + 6, 2);
         EndTime = times(&buffer);

         if ( (BeginTime != 0 &&  BeginTime != -1) &&
              (EndTime != 0 && EndTime != -1) ) {
           if (strftime(caDate,9,"%Y",pstTm) == 0) {
             sprintf(g_caMsg,"SetTime: strftime(%%Y) errno=%d",errno);
             ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
           }
           if (strftime(caDate+4,5,"%m%d",pstTm) == 0) {
             sprintf(g_caMsg,"SetTime: strftime(%%m%%d) errno=%d",errno);
             ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
           }
           sprintf(g_caMsg,
            "<APD>%s,%.2s%.2s%.2s,BD%.*s,B%.*s,T%.*s,TX%.*s,P%d,RC%c,PT=%.2f\n",
              caDate,caTime,caTime+3,caTime+6,
              DATE_LEN,g_pstTma->stTSSA.caTxnDate,
              g_iBrhCodeLen,g_pstTma->stTSSA.caBrCode,
              g_iTmCodeLen,g_pstTma->stTSSA.caTmCode,
              g_iTxnCodeLen,g_pstTma->stTSSA.caTxnCode,
              getpid(),g_cApRtnCode,(EndTime-BeginTime)/100.0); 
           ErrLog(0,g_caMsg,RPT_TO_LOG,0,0);
	 }
         g_cApRtnCode='1';
  
         break;
  }

  UCP_TRACE_END( 0 );
}

/*
 *&N& ROUTINE NAME: ComputTime()
 *&A& ARGUMENTS:
 *&A&     NAME                TYPE                  DESCRIPTION
 *&A&   -------------------------------------------------------------
 *&A&
 *&R& RETURN VALUE(S):
 *&R&   �L
 *&R&
 *&D& DESCRIPTION:
 *&D&   �p�����B�z�ɶ�
 */
int
ComputTime()
{
  char caBuf[5];
  int  iStart,iEnd;

  UCP_TRACE(P_ComputTime);
/*
  sprintf(g_caMsg,"Txn Start Time= %.8s",g_pstTma->stTSSA.caStartTxnTime);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
  sprintf(g_caMsg,"Txn End Time= %.8s",g_pstTma->stTSSA.caEndTxnTime);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
*/
  memset(caBuf, 0, 5);
  memcpy(caBuf,g_pstTma->stTSSA.caStartTxnTime+4, 2);
  iStart = atoi(caBuf);
  memcpy(caBuf,g_pstTma->stTSSA.caEndTxnTime+4, 2);
  iEnd = atoi(caBuf);
  if( iEnd < iStart ) {
    iEnd += 60;
  }
/*
  sprintf(g_caMsg,"Txn Start Time= %d, End Time=%d",iStart,iEnd);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
*/
  sprintf(g_caMsg,"TXNCODE= %.4s, Txn Processing Time= %d",
          g_pstTma->stTSSA.caTxnCode,(iEnd-iStart)%60);
  ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
  UCP_TRACE_END( 0 );
}


/*
 *&N& ROUNTINE NAME : IsMultipleBegin()
 *&A& ARGUMENTS:
 *&A&   NAME           TYPE         DESCRIPTION
 *&A& ------------ ----------- -----------------------
 *&A&
 *&R& RETURN VALUE(I);
 *&R&   
 *&D& DESCRIPTION:
 *&D& 
 */
int
IsMultipleBegin()
{
  UCP_TRACE(P_IsMultipleBegin);
  UCP_TRACE_END( 1 );
}

/*
 *&N& ROUNTINE NAME : IsMultipleEnd()
 *&A& ARGUMENTS:
 *&A&   NAME           TYPE         DESCRIPTION
 *&A& ------------ ----------- -----------------------
 *&A&
 *&R& RETURN VALUE(I);
 *&R&   
 *&D& DESCRIPTION:
 *&D& 
 */
int 
IsMultipleEnd()
{
  UCP_TRACE(P_IsMultipleEnd);
  UCP_TRACE_END( 1 );
}

/*
 *&N& ROUNTINE NAME : IsListBegin()
 *&A& ARGUMENTS:
 *&A&   NAME           TYPE         DESCRIPTION
 *&A& ------------ ----------- -----------------------
 *&A&
 *&R& RETURN VALUE(I);
 *&R&   
 *&D& DESCRIPTION:
 *&D& 
 */
int
IsListBegin()
{
  UCP_TRACE(P_IsListBegin);
  UCP_TRACE_END( 1 );
}

/*
 *&N& ROUNTINE NAME : IsListEnd()
 *&A& ARGUMENTS:
 *&A&   NAME           TYPE         DESCRIPTION
 *&A& ------------ ----------- -----------------------
 *&A&
 *&R& RETURN VALUE(I);
 *&R&   
 *&D& DESCRIPTION:
 *&D& 
 */
int
IsListEnd()
{
  UCP_TRACE(P_IsListEnd);
  UCP_TRACE_END( 1 );
}

/*
 *&N& ROUNTINE NAME : IsMultipleDataEnd()
 *&A& ARGUMENTS:
 *&A&   NAME           TYPE         DESCRIPTION
 *&A& ------------ ----------- -----------------------
 *&A&
 *&R& RETURN VALUE(I);
 *&R&   
 *&D& DESCRIPTION:
 *&D& 
 */
int
IsMultipleDataEnd()
{
  UCP_TRACE(P_IsMultipleDataEnd);

  if ( sg_iMultEndFlag == YES ) {
    g_pstTma->stTCFA.cInDataType = GENERAL_TXN;
  }

  UCP_TRACE_END( 0 );
}


/*
 *&N& ROUNTINE NAME : IsListDataEnd()
 *&A& ARGUMENTS:
 *&A&   NAME           TYPE         DESCRIPTION
 *&A& ------------ ----------- -----------------------
 *&A&
 *&R& RETURN VALUE(I);
 *&R&   
 *&D& DESCRIPTION:
 *&D& 
 */
int
IsListDataEnd()
{
  UCP_TRACE(P_IsListDataEnd);

  if ( sg_iListEndFlag == YES ) {
    g_pstTma->stTCFA.cInDataType = GENERAL_TXN;
  }

  UCP_TRACE_END( 0 );
}

/*
 *&N& ROUTINE NAME: InputCnv()
 *&A& ARGUMENTS:
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&   ����ƱN��J��ư��зǮ榡�ഫ,
 *&D&   ����ƥD�n�\��O�� SIF ������N�X,Ū���зǮ榡�ഫ��������J��
 *&D&   ���{��,�ñҰʤ�
 *&D&
 *&D&   �U�C���Τ��@,�|�Ϧ���ư��楢��
 *&D&       1. ��J�ഫ�{���L�k���`�Ұ�
 *&D&
 */

int
InputCnv()
{
  int iRc;
  char caDataFmt[ DATA_FMT_LEN + 1 ];
  char caCnvInBuff[MAX_SIF_LEN];
  int (* pfConvInPgm)();

  UCP_TRACE( P_InputCnv );
  GetFmtCode(caDataFmt);
  /* memcpy( caDataFmt , g_pstTba->caSif , DATA_FMT_LEN );
  caDataFmt[ DATA_FMT_LEN ] = '\0';*/

  pfConvInPgm = GetConvPgm( caDataFmt, CONV_IN );

  if ( pfConvInPgm != NULL ) {
    iRc = (* pfConvInPgm)(g_pstTba->caSif, caCnvInBuff, g_iSifLen);
    if (iRc < 0) {
      if (iRc==INPUTCNV_SIF_LEN_OVERFLOW_ERR) {
        sprintf ( g_caMsg,
        "###<tmstxin.c>SIF length(after decompressed) > MAX_SIF_LEN=520 error");
        ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
        DetErrRpt( INPUTCNV_SIF_LEN_OVERFLOW_ERR, g_caMsg );
        UCP_TRACE_END( INPUTCNV_SIF_LEN_OVERFLOW_ERR );
      }
      else {
        sprintf( g_caMsg, "InputCnv: Input convert error!" );
        ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
        DetErrRpt( INPUTCNV_ERR, g_caMsg );
        UCP_TRACE_END( INPUTCNV_ERR );
      }
    }
    /* 1997/05/14 marked for DES code
    memcpy(g_pstTba->caSif, caCnvInBuff, iRc);
    */
    g_iSifLen = iRc;
  }

  UCP_TRACE_END( 0 );
}

GetFmtCode(char *pcFmtCode)
{

  memcpy( pcFmtCode , g_pstTba->caSif , DATA_FMT_LEN );
  pcFmtCode[ DATA_FMT_LEN ] = '\0';

}

/* To avoid duplication of txn seq. no of the same terminal -- BEGIN */ 
int
ChkTrmAvailable( pcBrCode, pcTmCode )
char *pcBrCode;
char *pcTmCode;
{
  int iRc;
  struct CwaCtl stCwaCtl;
  char *pcDummy;
  char *pcTerm;

  stCwaCtl.cFunCode = CWA_SEG_LOCK;
  stCwaCtl.cSegCode = CWA_SEG_BIT_BRH;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcDummy);

  if (iRc != CWA_NORMAL) {
    ErrLog(1000,"ChkTrmAvailable: CwaCtlFac lock TCT fail!",RPT_TO_LOG,0,0);
    return( CHKTERML_LOCK_TCT_ERR );
  }

  stCwaCtl.cFunCode = CWA_GET_TERM_PTR;
  memcpy(stCwaCtl.caBrhId, pcBrCode, g_iBrhCodeLen);
  memcpy(stCwaCtl.caTermId, pcTmCode, g_iTmCodeLen);
  iRc = CwaLowCtlFac(&stCwaCtl, &pcTerm);
  if ( iRc < 0 ) {
    /* the terminal has not been registered in BIT */
    sprintf( g_caMsg, "ChkTrmAvailable: Terminal not registered in BIT" );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);

   /*begin:add by pjw for TU995002                1999 6 10*/
    stCwaCtl.cFunCode = CWA_SEG_UNLOCK;
    stCwaCtl.cSegCode = CWA_SEG_BIT_BRH;
    iRc = CwaLowCtlFac(&stCwaCtl,&pcDummy);

    if (iRc != CWA_NORMAL) {
       ErrLog(1000,
          "ChkTrmAvailable: unlock TCT fail,tpu abnormal exit",RPT_TO_LOG,0,0);
       exit(-1);
    }
   /*end:add by pjw for TU995002                1999 6 10*/

    return( CHK_TERML_ERR );
  }

  if ((((struct TermArea *)(pcTerm))->cTermStatus & IS_ON_TXN)) {

    sprintf(g_caMsg,
        "ChkTrmAvailable: previous txn on Brh[%.*s] Trm[%.*s] is still processing, try again later.",
        g_iBrhCodeLen,pcBrCode,g_iTmCodeLen,pcTmCode );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);

    stCwaCtl.cFunCode = CWA_SEG_UNLOCK;
    stCwaCtl.cSegCode = CWA_SEG_BIT_BRH;
    iRc = CwaLowCtlFac(&stCwaCtl,&pcDummy);

    if (iRc != CWA_NORMAL) {
      ErrLog(1000,
        "ChkTrmAvailable: CwaCtlFac unlock TCT fail (1)!",RPT_TO_LOG,0,0);
      return( CHKTERML_UNLOCK_TCT_ERR );
    }

    return( TERMINAL_IS_ON_USE_ERR );
  }
  else { /* the terminal is available to do txn */
    ((struct TermArea *)(pcTerm))->cTermStatus |= IS_ON_TXN;
    g_cNeedRelseTrm = 'y';
  }

  stCwaCtl.cFunCode = CWA_SEG_UNLOCK;
  stCwaCtl.cSegCode = CWA_SEG_BIT_BRH;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcDummy);

  if (iRc != CWA_NORMAL) {
    ErrLog(1000,
      "ChkTrmAvailable: CwaCtlFac unlock TCT fail (2)!",RPT_TO_LOG,0,0);
    return( CHKTERML_UNLOCK_TCT_ERR );
  }

  return (0);
}
/* To avoid duplication of txn seq. no of the same terminal -- END */ 
