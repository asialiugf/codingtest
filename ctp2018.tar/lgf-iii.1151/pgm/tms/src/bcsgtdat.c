char* GetBatBrCode()
{
  static char s_caBuf[80];
  memset(s_caBuf,0,80);
  sprintf(s_caBuf,"%s",getenv("BBRH_CODE"));
  return ( s_caBuf );
}

char* GetBatTmCode()
{
  static char s_caBuf[80];
  memset(s_caBuf,0,80);
  sprintf(s_caBuf,"%s",getenv("BTM_CODE"));
  return ( s_caBuf );
}

char* GetBatTellCode()
{
  static char s_caBuf[80];
  memset(s_caBuf,0,80);
  sprintf(s_caBuf,"%s",getenv("BTL_CODE"));
  return ( s_caBuf );
}
