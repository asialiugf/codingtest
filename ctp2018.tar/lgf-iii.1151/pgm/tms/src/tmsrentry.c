#include "cwa.h"
#include "tms.h"
#include "errlog.h"
#include "tmcpgdef.h"

#define OFFLINE_FLAG  0xef
#define ONLINE_FLAG   0x10

extern int g_iBrhCodeLen;

int
SetBrhLine(char cFunCode,char *pcaBrhCode)
{
  int iRc;
  struct CwaCtl stCwaCtl;
  struct BrhArea *pstBrh;

  UCP_TRACE(P_SetBrhLine);
  stCwaCtl.cFunCode = CWA_GET_BRH_PTR;
  memcpy(stCwaCtl.caBrhId, pcaBrhCode, g_iBrhCodeLen);
  iRc = CwaLowCtlFac(&stCwaCtl, &pstBrh);
  if ( iRc < 0 ) {
    sprintf( g_caMsg, "SetBrhLine: Branch not registered in BIT" );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( -1 );
  }

  switch ( cFunCode ) {
    case '0':
      pstBrh->cBrhStatus &= OFFLINE_FLAG;
      break;
    case '1':
      pstBrh->cBrhStatus |= ONLINE_FLAG;
      break;
    default:
      UCP_TRACE_END( -1 );
  }

  UCP_TRACE_END( 0 );
}


int
RdWtReentrySeq(char cFunCode,char *pcBrhCode,char *pcTmCode,long *plBtchSeqNo,
               char cReentryStatus)
{
  int iRc;
  char *pcTerm=NULL;
  struct TermArea *pstTerm;
  
  UCP_TRACE(P_RdWtReentrySeq);

  iRc = ChkTerml(pcBrhCode,pcTmCode,&pcTerm, cReentryStatus);
  if (iRc < 0 ) {
    sprintf( g_caMsg, "RdWtReentrySeq: ChkTerml() fails! ");
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( iRc );
  }

  pstTerm = (struct TermArea *) pcTerm;

  switch( cFunCode ) {
    case RD_REENTRY_SEQ_NO:
      *plBtchSeqNo = pstTerm->lBtchTxnNo;
      break;
    case WT_REENTRY_SEQ_NO:
      pstTerm->lBtchTxnNo = *plBtchSeqNo;
      break;
    default:
      UCP_TRACE_END( -1 );
  }

  UCP_TRACE_END( 0 );
}
