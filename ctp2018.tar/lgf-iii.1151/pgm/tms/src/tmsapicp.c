
/*
 *&D&             UCP   API           ��ƷJ�`
 *&D&------------------------------------------------------------------------
 *&D& 1  void     UCPDBS              ����DBS���ɭ����z�L���@�I�s
 *&D& 2  void     UCPFCS              ����FCS���ɭ����z�L���@�I�s
 *&D& 3  void     UCPDCS              ����DCS���ɭ����z�L���@�I�s
 *&D& 4  void     UCPWRITE            �NAP�e�X�����,�Ȧs���ɭ�
 *&D& 5  void     UCPPRINT            �NAP�e�X�����,���W�e�X���ɭ�
 *&D& 6  void  *  NACINT              AP�z�L���ɭ������Q�v�p��(���)
 *&D& 7  void  *  NBCINT              AP�z�L���ɭ������Q�v�p��
 *&D& 8  void  *  NARINT              AP�z�L���ɭ������Q�v�p��
 *&D& 9 void  *  UCPTXLOG            AP�z�L���ɭ��gLOG
 *&N& 10 void  *  UCPIO               AP�z�L���ɭ��gLOG
 *&D& 11 void     UCPLOG              AP�z�L���ɭ��gLOG          
 *&D& 12 void     DKRBLSTS
 *&D& 13 void     SYSCAL
 *&D& 14 void     UCPLOG              AP�z�L���ɭ��gLOG          
 *&D&                                
*/

#include "twa.h"
#include "oldapa.h"
#include "errlog.h"
#include "tms.h"
#include "dcs.h"
#include "ucp.h"
#include "tmcpgdef.h"	/* TMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */
#include "fcstwa.h"

#define MSGP_DATA         'm'
#define POST_DATA         'p'
#define PRNT_DATA         'r'
#define SIF_DATA          's'
#define APRQT_DATA_LEN     4
#define SbDbs              sbdbs
#define SbFcs              sbfcs

#ifdef MF_COBOL
#define  swapshort(X)              X=((X>>8)&0x00FF)|((X<<8)&0xFF00)
#else
#define  swapshort(X)              X=X
#endif
/* -------------------- DATA STRUCTURE for OLD AP ------------------ */
struct ApToTpuMsgSt {
   char  cMsgType;
   char  caMsgCode[3];
   short sLength ;
   char  cOutDevType;
   char  caOutMsg[MAX_MSG_LEN];
} ;

/* DKRBLSTS */
struct CkcpSt {
   char fun_code[1] ;
   char bill_st_no[7];
   char bill_cnt[3];
   char upd_data[1] ;
   char st_bill_ord[2] ;
   char end_bill_ord[2] ;
   char rtn_code[1] ;
   char rtn_area[100] ;
} ;
struct CkcSt {
  char filler[70] ;
} ;

/* ------------------- global variable ------------------------------ */
extern struct TMA *g_pstTma;
extern struct TBA *g_pstTba;
extern struct ApaSt *g_pstApa;


UCPDBS(char *pcArg1,char *pcArg2)
{

  struct ApaSt *pstApa;

  UCP_TRACE(P_UCPDBS);
  pstApa = (struct ApaSt *) pcArg1;
  TPFDBS(g_pstApa,pstApa->caDbsFileId,pcArg2);
  UCP_TRACE_END(0);
}



UCPFCS(char *pcArg1,char *pcArg2)
{
  UCP_TRACE(P_UCPFCS);
  TPFFCS(g_pstApa,pcArg1,pcArg2);
  UCP_TRACE_END(0);
}

#ifdef OLD_TPEDCS
UCPDCS(char *pcArg1,char *pcArg2)
{
  UCP_TRACE(P_UCPDCS);
  TPEDCS(g_pstApa,pcArg1,pcArg2);
  UCP_TRACE_END(0);
}
#else
UCPDCS(char *pcArg1,char *pcArg2)
{
  struct DcsOldApi *pstDcsOldApi;
  struct DcsApi    stDcsApi;
  
  UCP_TRACE(P_UCPDCS);

  pstDcsOldApi = (struct DcsOldApi *)pcArg1;
  memset(stDcsApi.caDesAddr	,'0',10);
  memcpy(stDcsApi.caDesAddr	,pstDcsOldApi->caDesAddr,3);
  memset(stDcsApi.caTermCode	,'0',4);
  memcpy(stDcsApi.caTermCode	,pstDcsOldApi->caDesAddr+3,2);
  memcpy(stDcsApi.caPrgId	,pstDcsOldApi->caPrgId  ,4);
  memcpy(stDcsApi.caDataLen	,pstDcsOldApi->caDataLen,4);
  stDcsApi.cFunCode	=	 pstDcsOldApi->cFunCode;
  stDcsApi.cRtnCode	= 	 pstDcsOldApi->cRtnCode;
  memcpy(stDcsApi.caErrCode	,pstDcsOldApi->caErrCode,2);
  stDcsApi.cDataFmt	= 	 '9';
  memset(stDcsApi.caTxnCode 	,'0',6);
  memcpy(stDcsApi.caTxnCode	,pcArg2,4);
  memcpy(stDcsApi.caTimeOut	,"00060",5);
  TPEDCS(g_pstApa,&stDcsApi,pcArg2);
  memcpy(pstDcsOldApi->caPrgId   ,stDcsApi.caPrgId	,4);
  memcpy(pstDcsOldApi->caDataLen ,stDcsApi.caDataLen	,4);
  pstDcsOldApi->cRtnCode = 	 stDcsApi.cRtnCode;
  memcpy(pstDcsOldApi->caErrCode ,stDcsApi.caErrCode	,2);

  UCP_TRACE_END(0);
}
#endif


UCPWRITE(char *pcArg1, char *pcArg2)
{
  struct ApaSt *pstApa;
  struct WriteSt stWrite;
  struct ApToTpuMsgSt *pstApMsg;
  char caDataLen[4];

  UCP_TRACE(P_UCPWRITE);
  pstApa = (struct ApaSt *) pcArg1;
  pstApMsg = (struct ApToTpuMsgSt *) pcArg2;

  stWrite.stWriteData.cMsgType = pstApMsg->cMsgType;  
  memcpy(stWrite.stWriteData.caMsgCode ,pstApMsg->caMsgCode, 3);
  sprintf(caDataLen, "%.4d", swapshort(pstApMsg->sLength));
  memcpy(stWrite.stWriteData.caDataLen ,caDataLen, 4);
  stWrite.stWriteData.cOutDevType = pstApMsg->cOutDevType;  
  memcpy(stWrite.stWriteData.caOutMsg,pstApMsg->caOutMsg,pstApMsg->sLength);

  TPEWRITE(pstApa,&stWrite);
  pstApa->cMsgqReturnCode = stWrite.cWriteRtnCode;
  UCP_TRACE_END(0);
}


UCPPRINT(char *pcArg1, char *pcArg2)
{
  struct ApaSt *pstApa;
  struct SdoutSt stSdout;
  struct ApToTpuMsgSt *pstApMsg;
  char caDataLen[4];

  UCP_TRACE(P_UCPPRINT);
  pstApa = (struct ApaSt *) pcArg1;
  pstApMsg = (struct ApToTpuMsgSt *) pcArg2;

  stSdout.stSdoutData.cMsgType = pstApMsg->cMsgType;  
  memcpy(stSdout.stSdoutData.caMsgCode ,pstApMsg->caMsgCode, 3);
  sprintf(caDataLen, "%.4d", swapshort(pstApMsg->sLength));
  memcpy(stSdout.stSdoutData.caDataLen ,caDataLen, 4);
  stSdout.stSdoutData.cOutDevType = pstApMsg->cOutDevType;  
  memcpy(stSdout.stSdoutData.caOutMsg,pstApMsg->caOutMsg,pstApMsg->sLength);

  TPESDOUT(pstApa,&stSdout);
  pstApa->cMsgqReturnCode = stSdout.cSdoutRtnCode;
  UCP_TRACE_END(0);
}


UCPTXLOG(char *pcArg0,char *pcArg1)
/*  pcArg0 -->  APA                 */
/*  pcArg1 -->  log data 400 bytes  */
{
  UCP_TRACE(P_UCPTXLOG);
  TPETXLOG(pcArg0,pcArg1);
  UCP_TRACE_END(0);
}

UCPLOG(char *pcArg0,char *pcArg1)
/*  pcArg0 -->  APA                 */
/*  pcArg1 -->  log data 400 bytes  */
{
  UCP_TRACE(P_UCPLOG);
  TPETXLOG(pcArg0,pcArg1);
  UCP_TRACE_END(0);
}
/*
DKRBLSTS(char pcArg1,char *pcArg2)
{
  int iPargc;
  char *pcaPargv[5];
  struct CkcSt *pstCkc;
  struct CkcpSt *pstCkcp;

  pstCkc  = (struct CkcSt *) pcArg1;
  pstCkcp = (struct CkcpSt *) pcArg2;
  iPargc = 3;
  pcaPargv[1] = (char *) pstCkc;
  pcaPargv[2] = (char *) pstCkcp;
  setbill(iPargc,pcaPargv);

}
*/
SYSCAL(caLen,caCmdString)
char *caLen;
char *caCmdString;
{
   char caCmdBuf[1024];
   char caLenBuf[4];

   memcpy(caLenBuf,caLen,3);
   caLenBuf[3] = '\0';
   memcpy(caCmdBuf,caCmdString,atoi(caLenBuf));
   caCmdBuf[atoi(caLenBuf)] = '\0';
   system(caCmdBuf);
}

UBCDBS(pcArg1,pcArg2)
char *pcArg1;
char *pcArg2;
{
  TPFDBS(g_pstApa,pcArg1,pcArg2);
}


UCPSDCLT(char *pcArg1,char *pcArg2)
/* pcArg1 pointer to control part "SdcltCtlSt"
   pcArg2 pointer to data part                 */
{
  int   iLen;
  int iRc;
  struct SdcltCtlSt stSdcltCtl;

  UCP_TRACE(P_UCPSDCLT);
  memcpy(stSdcltCtl.caSdcltLen, pcArg1, 5);/* COBOL AP data len is 9(5) */
  TPESDCLT(g_pstApa,&stSdcltCtl,pcArg2);
  UCP_TRACE_END(0);

}
