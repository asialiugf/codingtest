/* ------------------------- INCLUDE FILES ---------------------------- */
#include "dcs.h"
#include "errlog.h"

#define QUEUE_DCS               'Q'
#define CENTER_HOST             "0000000ibs"
#define DEST_NAME_LEN           10

#define P_SendToIbs           10003
#define P_RecFromIbs          10004
#define P_DisConnect          10005

/* ------------------------- ERROR MSG ---------------------- */
#define SEND_TO_IBS_ERR       -1
#define RCV_IBS_ERR           -2
#define DISCONNECT_ERR        -3

/* ------------------------- VARIABLE DECLARATION --------------------- */
static int sg_iIbrqtSessId;
static char g_cProtocoltype = '\0';

/*
 *&N& ROUTINE NAME:3.SendToIbs()
 *&A& ARGUMENTS:
 *&A&    NAME         TYPE            DESCRIPTION
 *&A& -------------  ------  -------------------------------
 *&A&
 *&R& RETURN VALUE(S):
 *&R&  0 : ������J��Ʀ��\
 *&R& SEND_SOF_ERR : ������J��ƥ���
 *&R&
 *&D& DESCRIPTION
 *&D&
 */

int
SendToIbs( int iLen, char *pcaData, char cFirst)
{
  static struct DcsBuf stDcsBuf;
  static struct DcsSiof stDcsSiof;

  UCP_TRACE(P_SendToIbs);

  g_cProtocoltype=QUEUE_DCS ;
  memcpy(McaDesCode(stDcsBuf),CENTER_HOST,DEST_NAME_LEN);
  if ( cFirst == '1') {
     McRqstCode(stDcsBuf) = DCSCONNECTWRITE;  
  }
  else {
     McRqstCode(stDcsBuf) = DCSWRITE;
  };

  MiDataLen(stDcsBuf) = 8 + iLen;
  sprintf(stDcsSiof.caDataLen,"%.5d",MiDataLen(stDcsBuf));
  MpstDcsSiof(stDcsBuf) = &stDcsSiof;
  memcpy(McaData(stDcsBuf),pcaData,iLen);
  MlWaiTime(stDcsBuf) = DCS_BLOCK;
  McProto(stDcsBuf) =  g_cProtocoltype ;

  DcsDispatch( &stDcsBuf );

  if(MiReply(stDcsBuf) != DCS_NORMAL) {
    sprintf( g_caMsg, "SendToIbs: DcsDispatch() fails! reply=%d",
             MiReply(stDcsBuf) );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( SEND_TO_IBS_ERR );
  }

  sg_iIbrqtSessId = MiSesIdx(stDcsBuf);

  UCP_TRACE_END( 0 );

}

/*
 *&N& ROUTINE NAME:4.RecFromIbs()
 *&A& ARGUMENTS:
 *&A&    NAME         TYPE            DESCRIPTION
 *&A& -------------  ------  -------------------------------
 *&A&
 *&R& RETURN VALUE(S):
 *&R&  0 : ������J��Ʀ��\
 *&R& SEND_SOF_ERR : ������J��ƥ���
 *&R&
 *&D& DESCRIPTION
 *&D&
 */

int
RecFromIbs(paInputData)
char *paInputData;
{
  struct DcsBuf stDcsBuf;
  struct DcsSiof stDcsSiof;

  UCP_TRACE( P_RecFromIbs );

  g_cProtocoltype = QUEUE_DCS;
  MpstDcsSiof(stDcsBuf) = &stDcsSiof;
  memcpy(McaDesCode(stDcsBuf), CENTER_HOST, DEST_NAME_LEN);
  McRqstCode(stDcsBuf) = DCSREAD;
  MlWaiTime(stDcsBuf) = DCS_BLOCK;
  MiDataLen(stDcsBuf) = DCS_MAX_DATA_LEN;
  McProto(stDcsBuf) = g_cProtocoltype;
  MiSesIdx(stDcsBuf) = sg_iIbrqtSessId;

  DcsDispatch( &stDcsBuf );

  if (MiReply(stDcsBuf) != DCS_NORMAL) {
   sprintf( g_caMsg, "RecFromIbs: DcsDispatch() fails! reply=%d",
             MiReply(stDcsBuf) );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( RCV_IBS_ERR );
  }


  memcpy(paInputData, McaData(stDcsBuf), MiDataLen(stDcsBuf)-8);

  UCP_TRACE_END( MiDataLen(stDcsBuf) - 8 );
}



int
DisConnect()
{
  struct DcsBuf stDcsBuf;
  struct DcsSiof stDcsSiof;

  UCP_TRACE( P_DisConnect );

  g_cProtocoltype = QUEUE_DCS;
  MpstDcsSiof(stDcsBuf) = &stDcsSiof;
  memcpy(McaDesCode(stDcsBuf), CENTER_HOST, DEST_NAME_LEN);
  McRqstCode(stDcsBuf) = DCSDISCONNECT;
  MlWaiTime(stDcsBuf) = DCS_BLOCK;
  MiDataLen(stDcsBuf) = DCS_MAX_DATA_LEN;
  McProto(stDcsBuf) = g_cProtocoltype;
  MiSesIdx(stDcsBuf) = sg_iIbrqtSessId;

  DcsDispatch( &stDcsBuf );

  if (MiReply(stDcsBuf) != DCS_NORMAL) {
    sprintf( g_caMsg, "DisConnect: DcsDispatch() fails! reply=%d",
             MiReply(stDcsBuf) );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( DISCONNECT_ERR );
  }

  UCP_TRACE_END( 0 );
}


