/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "errlog.h"     /* �O�����~�T���ɨϥΨ쪺�`�Ƥθ�Ƶ��c */
#include "twa.h"
#include "tms.h"
#include "tmcoutpt.h"
#include "tmcpgdef.h"	/* TMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */
#include "ucp.h"

/* -------------------- CONST DEFINE -------------------------------- */
/*
#define P_OutptSel	  28001
#define P_UnixClientSof   28002
#define P_WriteToOutptShm 28003
#define P_TxEndInform	  28004
#define P_SendToIO	  28005
#define P_IsMore	  28006
#define P_AddSofHeadToSif 28007
*/

#define MSG_FORM_TYPE	  'T'
#define MSG_WARN_TYPE	  'W'
#define MSGP_DATA	  'm'
#define POST_DATA	  'p'
#define PRNT_DATA	  'r'
#define SIF_DATA	  's'

#define OUTPT_PREFIX	    "iii/log/output"
#define MSGP_PREFIX	    "iii/log/msgp"
#define NORMAL_MSG_STATUS   "\x00\x00"
#define ERROR_MSG_STATUS    "\x88\x00"
#define PRINT_MSG_STATUS    "\x90\x00"
#define REINPUT_MSG_STATUS  "\xA0\x00"
#define POST_MSG_STATUS     "\x00\x00"
#define LAST_MSG_STATUS     "\x80\x00"
#define REENTRY_TXN_OK      "\xc0\x00"  /* added by chi-fusong, 1995/03/26 */
#define REENTRY_TXN_ERR     "\xc8\x00"  /* added by chi-fusong, 1995/03/26 */

#define RE_1_NR_1 	    "\x22\x00"
#define RE_1_NR_0           "\x20\x00"
#define RE_0_NR_1           "\x82\x00"
#define RE_0_NR_0           "\x80\x00"

#define LAST_MSG_MASK       0x80
#define REINPUT_MSG_MASK    0x20
#define PRINT_MSG_MASK      0x10
#define ERROR_MSG_MASK      0x08
#define TPEO_MSG_MASK       0x02

#define CONV_OUT	   1

#define METHOD_1	  '1'
#define METHOD_2	  '2'
#define NO	           0
#define YES	           1
#define OFF	          '0'
#define ON	          '1'

#define MAX_MSGP_BUFFER   1024 * 20
#define MAX_MSGP_DATA	  (MAX_MSGP_BUFFER - sizeof(struct MsgBufCtlSt))

#define AP_MSG_DATA_LEN_SIZE     4

#define TPEWRITE_EJ             '1'

struct SofDescSt {
  int iTotalLen;		/* caConvData ��ڪ��� */
  char caSofData[MAX_MSG_LEN];	 /* */
};

struct MsgBufCtlSt {
  int iErrMsgCnt;
  int iMsgCnt;
  int iNextOffset;
};
static int sg_iLastSofOffset;

/* ****************************************************************** */
/* message structure form AP througth call TPEWRITE & TPESDOUT.	      */
/* ****************************************************************** */
struct ApToTpuMsgSt {
   char  cMsgType;
   char  caMsgCode[3];
   char  caDataLen[4];
   char  cOutDevType;
   char  caOutMsg[MAX_MSG_LEN];
} ;

extern struct TMA *g_pstTma;
extern struct TBA *g_pstTba;
extern int g_iTxnCodeLen;    /* real Txn    Code length  */
extern int g_iBrhCodeLen;    /* real Branch Code length  */
extern int g_iTmCodeLen;     /* real Term Code length    */
extern int g_iMaxPacketSize; /* real packet max size     */
extern int g_iPiggyBackSize; /* real piggyback size      */
extern char g_cLastQryFlag;
extern int g_iMsgpFileFd;
extern int g_iMemFileFd;
extern char g_cFlushMemToFileFlag;
extern char g_caReinputBuffer[MAX_SIF_LEN + SOF_HEAD_LEN_PLUS_2];

/* TCC: For compatiability with Tandem */
int (*GetConvPgm(char *,int))();
int (*pfConvOutPgm)();

/*
 *&N& ROUNTINE NAME : OutptSel()
 *&A& ARGUMENTS:
 *&A&	NAME	       TYPE	    DESCRIPTION
 *&A& ------------ ----------- -------------------------
 *&A& pcaConvFun    char *	��X��Ʈ榡�ഫ�{���W��
 *&A& cDataKind;    char	��X��ƺ���(MSGP,POST,PRNT)
 *&A& pcaApData;    char *	��X���
 *&A&
 *&R& RETURN VALUE(I);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D& �N��X��ƮھڶǤJ����X��Ʈ榡�ഫ�{���W��,�ഫ������w���зǿ�X�榡,
 *&D& �è̸�ƺ����g�J����ݼзǿ�X�榡��ƿ�X�Ȧs��,�Ϊ�����X(PRNT_DATA).
 *&D&
 *&D& 1.�M�����w����X��Ʈ榡�ഫ�{��.
 *&D& 2.�̸�ƺ����ǳƩI�s��X��Ʈ榡�ഫ�{�����Ѽ�.
 *&D& 3.�I�s��X��Ʈ榡�ഫ�{��,�N��X��ƽs�覨���w���зǿ�X�榡.
 *&D& 4.�N�зǮ榡�T�����(MSGP_DATA)�I�sWriteToShm()�g�J�T����ƿ�X�Ȧs��.
 *&D& 5.�N�зǮ榡��m���(POST_DATA)�I�sWriteToShm()�g�J��m��ƿ�X�Ȧs��.
 *&D& 6.�N�зǮ榡�L�X���(PRNT_DATA)�I�sSendToIO()�ߧY��X.
 *&D&
 *&D&  �I�s���禡���禡 :
 *&D&	 ucplink.c : UCPWRITE(),UCPSDCTL(),UCPREINP(),UCPPRITE()
 *&D&
 *&D&
 *&D&
 */

OutptSel(cDataKind,pcaApData,pcaBrCode,pcaTmCode)
char cDataKind;
char *pcaApData;
char *pcaBrCode;
char *pcaTmCode;
{
  char *pcaConvCtl[5];
  char caDataFmt[SIF_FMT_LEN+1];
  int  iConvFunArgCnt;
  struct SofDescSt stConvDesc;
  int iRc;
  int iDcsRtnCode;
  struct ApToTpuMsgSt *pstMsgp;
  int iCurEjOff;

  UCP_TRACE(P_OutptSel);
  iConvFunArgCnt = 0;

  if ( cDataKind == POST_DATA || cDataKind == MSGP_DATA ||
       cDataKind == PRNT_DATA ) {
    pcaConvCtl[iConvFunArgCnt++] = &cDataKind;
    pcaConvCtl[iConvFunArgCnt++] = pcaBrCode;
    pcaConvCtl[iConvFunArgCnt++] = pcaTmCode;
  }

  pcaConvCtl[iConvFunArgCnt++] = pcaApData;
  /* Add one line below to initialize stConvDesc by Willy */
  memset(&stConvDesc, 0x0, sizeof(stConvDesc));
  pcaConvCtl[iConvFunArgCnt++] = (char *) &stConvDesc;
  /* Add By Chi Fu-Song 1994/7/15
   * Because every data must be packed to  SOF
   */
  UnixClientSof(iConvFunArgCnt,pcaConvCtl);


 /*  Add By Chi Fu-Song 1994/07/15
  *  Mark these portion for Integration Testing
  memset(caDataFmt,0,SIF_FMT_LEN+1);
  memcpy(caDataFmt,g_pstTba->caSif,SIF_FMT_LEN);
  pfConvOutPgm = GetConvPgm(caDataFmt,CONV_OUT);
  if ( pfConvOutPgm == NULL ) {
    ErrLog(1000,"search_conv_fun not found",RPT_TO_LOG,0,0);
    UCP_TRACE_END (-2);
  }
  iRc =(int) (*pfConvOutPgm)();
  if ( iRc < 0 ) {
    sprintf(g_caMsg,"Call converse function error = %d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END (-3);
  }
  *  Mark these portion for Integration Testing
  */

  switch ( cDataKind ) {
    case PRNT_DATA:
      iRc = TmsDataSend(stConvDesc.iTotalLen,stConvDesc.caSofData,'1',&iDcsRtnCode);
      if ( iRc < 0 ) {
        ErrLog(1000,"Call TmsDataSend()  error",RPT_TO_LOG,0,0);
        UCP_TRACE_END ( TMS_DATA_SEND_ERR );
      }
      break;
    case POST_DATA:
      memcpy(g_pstTba->caPost, stConvDesc.caSofData,stConvDesc.iTotalLen);
      break;
    case MSGP_DATA:
      /* --- For TPEWRITE to write EJ , 1994/12/11----- */
      pstMsgp = (struct ApToTpuMsgSt *) pcaApData;
      if ( pstMsgp->cOutDevType == TPEWRITE_EJ ) {
        g_pstTma->stTCFA.iApEjCnt++;
        if ( g_pstTma->stTCFA.iApEjCnt == 1 ) {
          g_pstTma->stTCFA.iApEjLen = 256*(unsigned char) stConvDesc.caSofData[SOF_DATA_LEN_OFFSET]+ (unsigned char) stConvDesc.caSofData[SOF_DATA_LEN_OFFSET+1];
          memcpy(g_pstTba->caPost, stConvDesc.caSofData,stConvDesc.iTotalLen);
          sprintf(g_caMsg,"OutptSel: 1POST len=%d",g_pstTma->stTCFA.iApEjLen);
          ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
          ErrLog(100,"1EJ data=",RPT_TO_LOG,g_pstTba->caPost,29+g_pstTma->stTCFA.iApEjLen);
        }
        else {
          iCurEjOff = SOF_HEAD_LEN_PLUS_2+
                     (g_pstTma->stTCFA.iApEjLen*(g_pstTma->stTCFA.iApEjCnt-1));
          memcpy(&g_pstTba->caPost[iCurEjOff],
         &stConvDesc.caSofData[SOF_HEAD_LEN_PLUS_2],g_pstTma->stTCFA.iApEjLen); 
          sprintf(g_caMsg,"OutptSel: 2POST len=%d",g_pstTma->stTCFA.iApEjLen);
          ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
          ErrLog(100,"2EJ data=",RPT_TO_LOG,&g_pstTba->caPost[iCurEjOff],g_pstTma->stTCFA.iApEjLen);
        }
      }
      else {
        iRc = WriteToOutptShm(&stConvDesc);
        if (iRc < 0) {
          if (iRc == -77) { /* issue normal msg after MXXX */
            UCP_TRACE_END (-77);
          }
          ErrLog(1000,"Call WriteToOutpShm() error",RPT_TO_LOG,0,0);
          UCP_TRACE_END (-4);
        }
      }
      break;
    default:
      sprintf(g_caMsg,"OutptSel cDataKind error! %c",cDataKind);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END (-5);
  }

  UCP_TRACE_END( 0 );
}


/*
 *&N& ROUNTINE NAME : UnixClientSof()
 *&A& ARGUMENTS:
 *&A&	NAME	       TYPE	    DESCRIPTION
 *&A& ------------ ----------- -----------------------------
 *&A&  argc	    int 	�Ѽƫ��а}�C�ҧt�ѼƭӼ�
 *&A&  argv	    char *	�Ѽƫ��а}�C
 *&A&
 *&A&
 *&R& RETURN VALUE(I);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D&  �̾����ε{���ǤJ��ƺ���,�g�J����Ȧs��(TBA)����M���Ȧs�� :
 *&D&  1.�s������Ȧs��(TBA,pstTba)�Y�w�s���h�������Ψ�ҩl��}.
 *&D&  2.�̾����ε{���ǤJ��ƺ���(cDataKind),�]�w�g�J�Ȧs�Ϧ�}:
 *&D&	   �T�����(MSGP_DATA),��m���(POST_DATA):pstTba->caPara.
 *&D&	   �����s�ʸ��(SIF_DATA): pstTba->caPara.
 *&D&  3.�̸�ƪ���(iDataLen)�N�ǤJ��Ƽg�J�Ȧs��.
 *&D&
 *&D&  �I�s���禡���禡 :
 *&D&	 ucpaplink.c : UCPWRITE(),UCPSDCTL(),UCPREINP(),UCPPRINT().
 *&D&
 *&D&
 */


int
UnixClientSof(argc,argv)
int argc;
char *argv[];
{
  struct SofDescSt *pstConvDesc;
  char cDataKind;
  char *pcaBrCode;
  char *pcaTmCode;
  char *pcaBeConvData;
  char *pcaSofData;
  struct ApToTpuMsgSt *pstMsgp;
  char cDeviceCode;
  short sDataLen;
  int	iDataLen;
  char	caMsgCode[SOF_MSG_CODE_SIZE+1];
  char	caCntlByte[2];
  char  caApMsgLen[10];

  UCP_TRACE(P_UnixClientSof);

  if (argc != 5) {
    sprintf(g_caMsg,"UnixClientSof argument number not enought =%d",argc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END( -1 );
  } /* if(argc != 5) */

  /* --------------------------------------------------------------- */
  /*                argv[0] -->  cDataKind                           */
  /*                argv[1] -->  Branch Code                         */
  /*                argv[2] -->  Term Code                           */ 
  /*                argv[3] -->  ApToTpuMsgSt                        */
  /*                argv[4] -->  stSofDesc                           */
  /* --------------------------------------------------------------- */
  cDataKind = *argv[0];
  pcaBrCode = argv[1];
  pcaTmCode = argv[2];
  pcaBeConvData = argv[3];
  pstConvDesc = (struct SofDescSt *) (argv[4]);

  pcaSofData = (char *) (pstConvDesc->caSofData);
  pcaSofData += SOF_DCS_CODE_SIZE;
  memcpy(pcaSofData,pcaBrCode,g_iBrhCodeLen);
  pcaSofData += SOF_BR_CODE_LEN;
  memcpy(pcaSofData,pcaTmCode,g_iTmCodeLen);
  pcaSofData += SOF_TM_CODE_LEN;

  switch(cDataKind) {
    /*
     * Add By Chi Fu-Song 1994/07/13
     * < case  PRNT_DATA : >
     */
    case  PRNT_DATA :
    case  MSGP_DATA :
      pstMsgp = (struct ApToTpuMsgSt *) pcaBeConvData;
      memcpy(pcaSofData,&pstMsgp->cOutDevType,SOF_OUT_DEV_SIZE);
      pcaSofData += SOF_OUT_DEV_LEN;
/*  Modified by WuChihLiang 19950510 for 7 bytes message  code */
      if (g_pstTma->stTSSA.cSystemRole == CENTER_HOST){
        *pcaSofData = 'H';
      }else{
        *pcaSofData = 'B'; 
      }
      *(pcaSofData+1) = toupper(g_pstTma->stTSSA.caBussDir[0]); 
      *(pcaSofData+2) = toupper(g_pstTma->stTSSA.caBussDir[1]); 
      memcpy(pcaSofData+3,pstMsgp,SOF_MSG_CODE_SIZE);
/*
      memcpy(pcaSofData,pstMsgp,SOF_MSG_CODE_SIZE);
*/
      memcpy(caMsgCode,pstMsgp,SOF_MSG_CODE_SIZE);
      pcaSofData += SOF_MSG_CODE_LEN;

      if ( cDataKind == MSGP_DATA ) {
	if (caMsgCode[0] == MSG_FORM_TYPE || caMsgCode[0] == MSG_WARN_TYPE) {
	  memcpy( caCntlByte , NORMAL_MSG_STATUS, SOF_CTL_CODE_SIZE);
	}
	else {
          memcpy( caCntlByte , ERROR_MSG_STATUS, SOF_CTL_CODE_SIZE);
          /* move TMS_RCV_AP_MXXX_MSG to WriteToOutptShm() */
          /* g_pstTma->stTCFA.cTpeWriteMsgKind = TMS_RCV_AP_MXXX_MSG; */
	}
      }
      else {
	  memcpy( caCntlByte , PRINT_MSG_STATUS, SOF_CTL_CODE_SIZE);
      }

      memcpy( pcaSofData, caCntlByte, SOF_CTL_CODE_SIZE);
      pcaSofData += SOF_CTL_CODE_LEN;
      pcaBeConvData+=(SOF_MSG_CODE_SIZE+AP_MSG_DATA_LEN_SIZE+SOF_OUT_DEV_SIZE);
      memset(caApMsgLen, 0, 10 );
      memcpy(caApMsgLen, pstMsgp->caDataLen, AP_MSG_DATA_LEN_SIZE);
      sDataLen = atoi(caApMsgLen);
/*
      sprintf(g_caMsg,"UnixClientSof:MSGP,PRNT aDataLen=%d",sDataLen);
      ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
*/
/* 1994/10/01 WuChihLiang 
      memcpy(pcaSofData,&sDataLen,SOF_DATA_LEN_SIZE);*/
      *pcaSofData = sDataLen / 256;
      (*(pcaSofData+1)) = sDataLen % 256;
      pcaSofData += SOF_DATA_LEN;
      memcpy(pcaSofData,pcaBeConvData,sDataLen);
      break;
    case  POST_DATA :
      pcaSofData += SOF_OUT_DEV_LEN;
      memset(pcaSofData,'\0',SOF_MSG_CODE_SIZE);
      pcaSofData += SOF_MSG_CODE_LEN;
      memcpy( caCntlByte , POST_MSG_STATUS, SOF_CTL_CODE_SIZE);
      memcpy( pcaSofData, caCntlByte, SOF_CTL_CODE_SIZE);
      pcaSofData += SOF_CTL_CODE_LEN;
      memcpy(&iDataLen,pcaBeConvData,sizeof(int));
      sDataLen = (short) iDataLen;
      pcaBeConvData += sizeof(int);
/* 1994/10/01 WuChihLiang 
      memcpy(pcaSofData,&sDataLen,SOF_DATA_LEN_SIZE);*/
      *pcaSofData = sDataLen / 256;
      (*(pcaSofData+1)) = sDataLen % 256;
      pcaSofData += SOF_DATA_LEN;
      memcpy(pcaSofData,pcaBeConvData,sDataLen);
      break;
    default :
      sprintf(g_caMsg,"Call UnixClientSof data kind =%c error",cDataKind);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END( -1 );

  } /* switch(cDataKind) */

  pstConvDesc->iTotalLen = SOF_HEAD_LEN_PLUS_2 + sDataLen;
/*
  sprintf(g_caMsg,"Dump SOF Data : ");
  ErrLog(100,g_caMsg,RPT_TO_LOG,(char *) (pstConvDesc->caSofData),
					   pstConvDesc->iTotalLen);
*/
  UCP_TRACE_END( 0 );
} /* UinxClientSof(argc,argv) */

/*
 *&N& ROUNTINE NAME : WriteToOutptShm()
 *&A& ARGUMENTS:
 *&A&	NAME		    TYPE		 DESCRIPTION
 *&A& --------------  ---------------------  -------------------------------
 *&A&  pstSofDesc      struct SofDescSt *    �зǿ�X�榡��ƴy�z
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D&  �N�ǿ�X�榡��Ʈھڱ���줸(Control Byte)�g�J�U��ƺ�����M����X�Ȧs��.
 *&D&  1.�T����Ƽg�J�T����X�Ȧs�� :
 *&D&	 �D���~�T�� : �֥[��X����,�վ�U����X��Ƽg�J�۹��},�̧Ǽg�J�Ȧs��.
 *&D&	 ���~�T��   : �]�w��X���Ƭ� 1,��X��Ƽg�J��ƶ��Ȧs�Ϥ��ҩl��}.
 *&D&  2.��m��Ƽg�J��m��X�Ȧs�� :
 *&D&
 *&D&  �I�s���禡���禡 :
 *&D&	 tmsoutpt.c : OutptSel()
 *&D&  �зǿ�X�榡�Ȧs�Ϯ榡 :
 *&D&
 *&D&  �z�w�w�w�w�w�w�w�w�w�w�w�w�w�{<-- pstBufCtl
 *&D&  �x�зǿ�X�榡�Ȧs�ϱ���� {�x
 *&D&  �x�U�@����X�T���g�J�۹��}�x
 *&D&  �x     ��X�T���֭p���� }   �x
 *&D&  �xstruct MsgBufCtlSt {	   �x
 *&D&  �x   short sMsgcnt }	   �x
 *&D&  �x   short sNextOffSet	   �x
 *&D&  �u�w�w�w�w�w�w�w�w�w�w�w�w�w�t<-- pcaMsgBuf
 *&D&  �x     ��X�T����� :	   �x
 *&D&  �x�T������(SOF HEAD���� + ��x
 *&D&  �x��X��ƪ���)+�T�����e ...�x
 *&D&  �x.... (20 K -  sizeof(	   �x
 *&D&  �x struct sof_buf_ctl_st)   �x
 *&D&  �|�w�w�w�w�w�w�w�w�w�w�w�w�w�}
 *&D&
 */
int
WriteToOutptShm(pstSofDesc)
struct SofDescSt *pstSofDesc;
{
 int iRc;
 char *pcaMsgBuf;
 struct MsgBufCtlSt *pstBufCtl;
 struct TwaCtl stTwaCtl;
 static char cFirstLinkFlag = '\0';
 static struct TBA *pstTba;
 char  cSofCtlData1;
 struct MsgBufCtlSt stBufCtl;
#define MULTI_ERROR_MSG_LENGTH 2000
 char caResultMsgBuf[MULTI_ERROR_MSG_LENGTH+100]; /* for SOF header */

 UCP_TRACE(P_WriteToOutptShm);

 if (cFirstLinkFlag == '\0') {
   stTwaCtl.cFunCode = TWA_GET_SEG_PTR;
   stTwaCtl.cSegCode = TWA_SEG_TBA;
   iRc =  TwaLowCtlFac(&stTwaCtl,&pstTba);
   if (iRc < 0) {
     ErrLog(1000,"Get TWA address Error",RPT_TO_LOG,0,0);
     UCP_TRACE_END(-1);
   } /* if (iRc < 0) */
   cFirstLinkFlag = 'n';
  }  /* if (cFirstLinkFlag == NULL) */

  cSofCtlData1 = pstSofDesc->caSofData[SOF_CTL_CODE_OFFSET] ;

  if ( !( cSofCtlData1 & ERROR_MSG_MASK ) ) {
    /* ----------  NORMAL   MESSAGE   -------------------- */

    /* if already issue error message, then error */
    if ( g_pstTma->stTCFA.cTpeWriteMsgKind == TMS_RCV_AP_MXXX_MSG ) {
      ErrLog(1000,"WriteToOutPtShm:ILLEGAL to issue NORMAL msg after MXXX.",RPT_TO_LOG,0,0);
      UCP_TRACE_END( -77 );
    }

    if(g_iMsgpFileFd > 0) {
      iRc=ReadFile(g_iMsgpFileFd,0,&stBufCtl,sizeof(stBufCtl));
      if(iRc < 0) {
        close(g_iMsgpFileFd);
        g_iMsgpFileFd=-1;
        ErrLog(1000,"WriteToOutPtShm:ReadFile() Error",RPT_TO_LOG,0,0);
        UCP_TRACE_END(-4);
      } 
      stBufCtl.iMsgCnt += 1;
      sg_iLastSofOffset = stBufCtl.iNextOffset;
      stBufCtl.iNextOffset += pstSofDesc->iTotalLen;
      iRc=WriteFile(g_iMsgpFileFd,0,&stBufCtl,sizeof(stBufCtl));
      if(iRc < 0) {
        close(g_iMsgpFileFd);
        g_iMsgpFileFd=-1;
        ErrLog(1000,"WriteToOutPtShm:WriteFile() Error",RPT_TO_LOG,0,0);
        UCP_TRACE_END(-3);
      } 
    }
    else {
      pcaMsgBuf = (char *) (pstTba->caMsgp) + sizeof(struct MsgBufCtlSt);
      pstBufCtl = (struct MsgBufCtlSt *) (pstTba->caMsgp);
      pstBufCtl->iMsgCnt += 1;
      pcaMsgBuf += pstBufCtl->iNextOffset;
      sg_iLastSofOffset = pstBufCtl->iNextOffset;
      pstBufCtl->iNextOffset += pstSofDesc->iTotalLen;
      iRc=MAX_MSGP_DATA-pstBufCtl->iNextOffset;
      if (iRc < 0) {
        sprintf(g_caMsg, "WriteToOutptShm:write data length=%d plus (iNextOffset=%d & sizeof(struct MsgBufCtlSt)=%d) over sizeof(TWA.TBA.caMsgp)=%d",pstSofDesc->iTotalLen,sg_iLastSofOffset,sizeof(struct MsgBufCtlSt),sizeof(pstTba->caMsgp));
        ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
        iRc=FlushMsgpToFile(sg_iLastSofOffset+sizeof(struct MsgBufCtlSt));
        if(iRc < 0) {
          sprintf(g_caMsg,"WriteToOutptShm:FlushMsgpToFile() error!");
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          UCP_TRACE_END(-2);
        }
        g_iMsgpFileFd=iRc;
      }
    }
  }
  else {
    /* ----------  ERROR   MESSAGE   ---------------------- */
    pcaMsgBuf = (char *) (pstTba->caMsgp) + sizeof(struct MsgBufCtlSt);
    pstBufCtl = (struct MsgBufCtlSt *) (pstTba->caMsgp);
    if(g_iMsgpFileFd > 0) {
      iRc=close(g_iMsgpFileFd);
      g_iMsgpFileFd=-1;
      if(iRc < 0) {
        sprintf(g_caMsg,"WriteToOutPtShm:close MsgpFile error! errno=%d",errno);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END(-99);
      }
    }

    /* if already issue ERROR msg, then process the
       MULTIPLE ERROR msg
     */
    if ( pstBufCtl->iErrMsgCnt >= 1 ) {

      int iOriginalDataLen, iNewDataLen, iResultDataLen;
      char caOriginalLenBuf[2], caNewLenBuf[2];
      char caTotalLenBuf[2];
      char caOriginalFormBuf[4], caNewFormBuf[4];
      char *pstBuf;

      memcpy(caOriginalLenBuf, (char *)pcaMsgBuf+SOF_DATA_LEN_OFFSET, 2);
      memcpy(caNewLenBuf, (char *)pstSofDesc->caSofData+SOF_DATA_LEN_OFFSET, 2);
      memcpy(caOriginalFormBuf, (char *)pcaMsgBuf+SOF_MSG_CODE_OFFSET+3, 4);
      memcpy(caNewFormBuf, (char *)pstSofDesc->caSofData+SOF_MSG_CODE_OFFSET+3, 4);

      iOriginalDataLen=256*(unsigned char)caOriginalLenBuf[0]+
                          (unsigned char)caOriginalLenBuf[1];
      iNewDataLen=256*(unsigned char)caNewLenBuf[0]+
                          (unsigned char)caNewLenBuf[1];

      memcpy(caResultMsgBuf, pcaMsgBuf, SOF_HEAD_LEN);

      if (memcmp(caOriginalFormBuf, "MXXX", 4) != 0) { /* never concate */
        
        memcpy((char *)caResultMsgBuf+SOF_MSG_CODE_OFFSET+3, "MXXX", 4);
#ifdef ONLY_MULTIPLE_FORMID
        iResultDataLen =  4       /* form buf for original msg */
                          + iOriginalDataLen
                          + 4       /* form buf for new msg */
                          + iNewDataLen;
#else
        iResultDataLen =    2       /* len buf for original msg */
                          + 4       /* form buf for original msg */
                          + iOriginalDataLen
                          + 2       /* len buf for new msg */
                          + 4       /* form buf for new msg */
                          + iNewDataLen;
#endif

        if ( iResultDataLen > MULTI_ERROR_MSG_LENGTH ) {
          sprintf(g_caMsg,"WriteToOutPtShm:Total error msg over %d(length=%d)",
                          MULTI_ERROR_MSG_LENGTH,
			  iResultDataLen+SOF_HEAD_LEN_PLUS_2);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          UCP_TRACE_END(-7);
        } else {
          pstBuf=(char *)caResultMsgBuf+SOF_HEAD_LEN;
          *pstBuf = iResultDataLen / 256;
          *(pstBuf+1) = iResultDataLen % 256;
          pstBuf += 2;

#ifdef ONLY_MULTIPLE_FORMID

#else
          *pstBuf = (iOriginalDataLen+4) / 256;
          *(pstBuf+1) = (iOriginalDataLen+4) % 256;
          pstBuf += 2;
#endif

          memcpy(pstBuf, caOriginalFormBuf, 4);
          pstBuf += 4;

          if (iOriginalDataLen) {
            memcpy(pstBuf, pcaMsgBuf+SOF_HEAD_LEN_PLUS_2, iOriginalDataLen);
            pstBuf += iOriginalDataLen;
          }

#ifdef ONLY_MULTIPLE_FORMID

#else
          *pstBuf = (iNewDataLen+4) / 256;
          *(pstBuf+1) = (iNewDataLen+4) % 256;
          pstBuf += 2;
#endif

          memcpy(pstBuf, caNewFormBuf, 4);
          pstBuf += 4;

          if (iNewDataLen) {
            memcpy(pstBuf, pstSofDesc->caSofData+SOF_HEAD_LEN_PLUS_2, iNewDataLen);
            pstBuf += iNewDataLen;
          }
        }

      } else { /* ever concate */

#ifdef ONLY_MULTIPLE_FORMID
        iResultDataLen =  iOriginalDataLen
                          + 4       /* form buf for new msg */
                          + iNewDataLen;
#else
        iResultDataLen =  iOriginalDataLen
                          + 2       /* len buf for new msg */
                          + 4       /* form buf for new msg */
                          + iNewDataLen;
#endif

        if ( iResultDataLen > MULTI_ERROR_MSG_LENGTH ) {
          sprintf(g_caMsg,"WriteToOutPtShm:Total error msg over %d(length=%d)",
                          MULTI_ERROR_MSG_LENGTH,
			  iResultDataLen+SOF_HEAD_LEN_PLUS_2);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          UCP_TRACE_END(-7);
        } else {
          pstBuf=(char *)caResultMsgBuf+SOF_HEAD_LEN;
          memcpy(pstBuf, pcaMsgBuf+SOF_HEAD_LEN, iOriginalDataLen+2);
          *pstBuf = iResultDataLen / 256;
          *(pstBuf+1) = iResultDataLen % 256;
          pstBuf += (2+iOriginalDataLen);


#ifdef ONLY_MULTIPLE_FORMID

#else
          *pstBuf = (iNewDataLen+4) / 256;
          *(pstBuf+1) = (iNewDataLen+4) % 256;
          pstBuf += 2;
#endif

          memcpy(pstBuf, caNewFormBuf, 4);
          pstBuf += 4;

          if (iNewDataLen) {
            memcpy(pstBuf, pstSofDesc->caSofData+SOF_HEAD_LEN_PLUS_2, iNewDataLen);
            pstBuf += iNewDataLen;
          }
        }
      }

      pstBufCtl->iNextOffset = iResultDataLen + SOF_HEAD_LEN_PLUS_2;
      pstBufCtl->iErrMsgCnt ++;

    } else { /* issue first ERROR msg */

      pstBufCtl->iErrMsgCnt = 1;
      pstBufCtl->iMsgCnt = 1;
      pstBufCtl->iNextOffset = pstSofDesc->iTotalLen;

    }

    g_pstTma->stTCFA.cTpeWriteMsgKind = TMS_RCV_AP_MXXX_MSG;

  }

  if( g_iMsgpFileFd > 0) {
    iRc=WriteFile(g_iMsgpFileFd,
          sg_iLastSofOffset+sizeof(struct MsgBufCtlSt),
          pstSofDesc->caSofData,pstSofDesc->iTotalLen);
    if(iRc < 0) {
      close(g_iMsgpFileFd);
      g_iMsgpFileFd=-1;
      sprintf(g_caMsg,"WriteToOutptShm() :WriteFile() error!");
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(-3);
    }
  }
  else if (pstBufCtl->iErrMsgCnt <= 1) { /* normal or first issue error msg */
    memcpy(pcaMsgBuf,pstSofDesc->caSofData,pstSofDesc->iTotalLen);
  } else { /* issue 2nd error msg */
    memcpy(pcaMsgBuf,caResultMsgBuf,pstBufCtl->iNextOffset);
  }
/*
  sprintf(g_caMsg,"WriteToShm() MsgBuf ->");
  ErrLog(100,g_caMsg,RPT_TO_LOG,pcaMsgBuf,pstSofDesc->iTotalLen);
*/
  UCP_TRACE_END ( 0 );

} /* WriteToOutptBuf() */


/*
 *&N& ROUNTINE NAME : TxEndInform()
 *&A& ARGUMENTS:
 *&A&	NAME	       TYPE	    DESCRIPTION
 *&A& --------------- ----------- ----------------------------
 *&A&  cApReturnCode   char	   AP�B�z�ᵲ�G('0','2'�����`)
 *&A&  cTxnReinput     char	   �U�@����O�_�������s�ʥ��
 *&A&  pcaTmCode       char *	   ������X��Ƥ��׺ݾ��N�X
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D&  �N����Ȧs��(TBA)���T�����(MSGP),��m���(RENDO)�g�J��X��.
 *&D&  1.�̾ڲ׺ݾ��N�X(pcaTmCode)�}�ҿ�X�ɮ�(OUTPT_FILE).
 *&D&  2.�s������Ȧs��(TBA,pstTba)�Y�w�s���h �������Ψ�ҩl��}.
 *&D&  3.�YAP�B�z�ᵲ�G(cApReturnCode)�����`('0','2') �h :
 *&D&	   3.1 �g�J��m���:
 *&D&	       �N��m���(pstTba->caPost),�H�Ӹ���`����(iPostLen)�g�J.
 *&D&	   3.2 �g�J�T�����(pstTba->caMsgp):
 *&D&	       �N�T�����(pcaMsgpData),�H�Ӹ���`����(pstMsgpCtl->iNextOffset)
 *&D&	       �g�J.
 *&D&	   3.3 �Y�U�@����������s�ʥ��(cTxnReinput == '1') �h :
 *&D&	       �g�J�зǿ�J�榡���(pstTba->caRendo)�H�Ӹ���`����(iPostLen)�g�J
 *&D&	 �_�h :
 *&D&	   3.2 �g�J�T�����(pstTba->caMsgp):
 *&D&	       �N�T�����(pcaMsgpData),�H�Ӹ���`����(pstMsgpCtl->iNextOffset)
 *&D&	       �g�J.
 *&D&
 *&D&  �I�s���禡���禡 :
 *&D&	  tmmain.c : TxOutput().
 *&D&
 *&D&
 */

int
TxEndInform(cApReturnCode,cTxnReinput,pcaTmCode, pcaBrCode)
char cApReturnCode;
char cTxnReinput;
char *pcaTmCode;
char *pcaBrCode;
{
  static char cFirstLinkFlag = '\0';
  static struct TBA *pstTba;
  int iRc;
  struct MsgBufCtlSt *pstMsgpCtl;
  char caOutptFile[80];
  int OutptFp;
  int iBufLen;
  short sSofDataLen;
  struct TwaCtl stTwaCtl;
  char cSofCtlData1;
  char  caSofCtlHead[SOF_HEAD_LEN_PLUS_2];
  int   iHaveReinput;
  int   iHaveMsgp;
  char  caCntlByte[2];
/* Added by Ellen for packing ths SOF data  */
  char  caPackHeader[SOF_HEAD_LEN_PLUS_2];
  int   iSofCnt=0;
  int   iSofPackLen=0;
  int   iSofLenPt=0;
  int   iSofPackPt=0;
  int   iSofLen=0;
  int   iPackSofNum;
  int   PACK_SOF_SIZE;


  UCP_TRACE(P_TxEndInform);

  sprintf(g_caMsg,
      "<APD>AP STATUS: TXNCODE=%.*s , Ap return code=%c , AP rendo request=%c"
      ,g_iTxnCodeLen,g_pstTma->stTSSA.caTxnCode,cApReturnCode
      ,g_pstTma->stTCFA.cRendoRequest);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);

/*
  if ( g_pstTma->stTCFA.cReentryStatus == TMS_TXN_NOT_REENTRY ) {
    sprintf(g_caMsg,"### TxEndInform: This txn is not REENTRY-TXN");
    ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
  }
  else {
    sprintf(g_caMsg,"### TxEndInform: This txn is REENTRY-TXN");
    ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
  }
*/

  if (cApReturnCode == TMS_AP_ACC_NORMAL || 
                               cApReturnCode == TMS_AP_NON_ACC_NORMAL ) {
    if ( g_pstTma->stTCFA.cTpeWriteMsgKind == TMS_RCV_AP_MXXX_MSG) {
      memset(g_pstTba->caMsgp,'\0',sizeof(struct MsgBufCtlSt));
      UCP_TRACE_END(AP_NORMAL_END_BUT_SND_MXXX_MSG );
    }
  }

  memset(caOutptFile,'\0',80);
  sprintf(caOutptFile,"%s/%s%.*s.%.*s",getenv("III_DIR"),OUTPT_PREFIX,
          g_iTmCodeLen, pcaTmCode, g_iBrhCodeLen, pcaBrCode);

  if ((OutptFp = open(caOutptFile,O_WRONLY|O_CREAT|O_TRUNC,0666)) == -1) {
      sprintf(g_caMsg,"TxEndInform() :open(OutpFp) error = %d",errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END ( OPEN_OUTPUT_FILE_ERR );
  } /* if ((OutptFp = open(caOutptFile,O_WRONLY|O_CREAT) == -1) */

  if (cFirstLinkFlag == '\0') {
     stTwaCtl.cFunCode = TWA_GET_SEG_PTR;
     stTwaCtl.cSegCode = TWA_SEG_TBA;
     iRc =  TwaLowCtlFac(&stTwaCtl,&pstTba);
     if (iRc < 0) {
       ErrLog(1000,"Get TWA address Error",RPT_TO_LOG,0,0);
       close(OutptFp);
       UCP_TRACE_END( GET_TBA_PTR_ERR );
     } /* if (iRc < 0) */
     cFirstLinkFlag = 'n';
  }  /* if (cFirstLinkFlag == NULL) */

  iHaveReinput = NO;
  iHaveMsgp = NO;

  if (cApReturnCode == TMS_AP_ACC_NORMAL || 
                              cApReturnCode == TMS_AP_NON_ACC_NORMAL ) {

    if ( g_pstTma->stTCFA.cReentryStatus == TMS_TXN_NOT_REENTRY ) {
      /* --------------------------------------------------------- */
      /* prepare Control SOF HEAD by Share memory's content        */
      /* --------------------------------------------------------- */
      if ( g_pstTma->stTCFA.cTxnReinput == TMS_TXN_REINPUT_ON ||
           g_pstTma->stTCFA.cTxnReinput == TMS_TXN_REINPUT_ON_API ) {
        iHaveReinput = YES;
      }

      pstMsgpCtl = (struct MsgBufCtlSt *) (pstTba->caMsgp);
      if ( pstMsgpCtl->iMsgCnt >= 1 ) {
        iHaveMsgp = YES;
      }

      if ( iHaveReinput == YES && iHaveMsgp == YES ) {
	  memcpy( caCntlByte , RE_1_NR_1, SOF_CTL_CODE_SIZE);
      }
      else {
        if ( iHaveReinput == YES && iHaveMsgp == NO ) {
	  memcpy( caCntlByte , RE_1_NR_0, SOF_CTL_CODE_SIZE);
        }
        else {
          if ( iHaveReinput == NO && iHaveMsgp == YES ) {
	    memcpy( caCntlByte , RE_0_NR_1, SOF_CTL_CODE_SIZE);
          }
          else {
            if ( iHaveReinput == NO && iHaveMsgp == NO ) {
	      memcpy( caCntlByte , RE_0_NR_0, SOF_CTL_CODE_SIZE);
            }
          }      
        }
      }

      memset( caSofCtlHead , 0, SOF_HEAD_LEN_PLUS_2 );
      memcpy( &caSofCtlHead[ SOF_CTL_CODE_OFFSET ], caCntlByte,
              SOF_CTL_CODE_SIZE);
      /* ------------------------------------------------------------ */
      /* write SOF Control HEAD for Communication Protocol with DBP   */
      /* ------------------------------------------------------------ */
      if ((write(OutptFp,caSofCtlHead,SOF_HEAD_LEN_PLUS_2)) != 
                                                   SOF_HEAD_LEN_PLUS_2) {
        sprintf(g_caMsg,"TxEndInform() :write(OutpFp,SOF_CNTL_HEAD) error = %d",
                errno);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        close(OutptFp);
        UCP_TRACE_END ( WRITE_TO_FILE_ERR );
      } 
  
      /* --------------------------------------------------------- */
      /* Write postprocess data to buffer file if has postprocess  */
      /* --------------------------------------------------------- */
/* replace by WuChihLiang for Sof length is (first byte)*256+second byte ) 
      memcpy( &sSofDataLen, pstTba->caPost[ SOF_DATA_LEN_OFFSET ],
              SOF_DATA_LEN_SIZE); */
      sSofDataLen=(unsigned char)pstTba->caPost[SOF_DATA_LEN_OFFSET]*256 +
                  (unsigned char)pstTba->caPost[SOF_DATA_LEN_OFFSET+1];

      if ( sSofDataLen > 0 ) {
        /* ------ Rewind file pointer to 27th position -------- */
        if ( (lseek(OutptFp,27L,0)) < 0 )  {
	  sprintf(g_caMsg,"TxEndInform() :lseek(OutpFp,POST) error = %d",errno);
	  ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          close(OutptFp);
	  UCP_TRACE_END ( WRITE_TO_FILE_ERR );
        }
        pstTba->caPost[SOF_DATA_LEN_OFFSET] = (unsigned char) ((sSofDataLen*g_pstTma->stTCFA.iApEjCnt)/256);
        pstTba->caPost[SOF_DATA_LEN_OFFSET+1] = (unsigned char) ((sSofDataLen*g_pstTma->stTCFA.iApEjCnt)%256);

        iBufLen = SOF_DATA_LEN + 
                  sSofDataLen*(g_pstTma->stTCFA.iApEjCnt);
        sprintf(g_caMsg,"caPost iBufLen=%d",iBufLen);
        ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
        ErrLog(100,"TxEndInform: POST=",RPT_TO_LOG,g_pstTba->caPost,27+iBufLen);
        if ((write(OutptFp,&pstTba->caPost[SOF_DATA_LEN_OFFSET],iBufLen)) != 
                                                                 iBufLen) {
	  sprintf(g_caMsg,"TxEndInform() :write(OutpFp,POST) error = %d",errno);
	  ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
           close(OutptFp);
	  UCP_TRACE_END ( WRITE_TO_FILE_ERR );
        } 
        /*
         * Clear TBA.caPost AREA when txn ends
         */
        /* mark by chi-fu-song 1994/12/11
         * memset(pstTba->caPost,'\0',iBufLen);
         */
        memset(pstTba->caPost,'\0',SOF_DATA_LEN_OFFSET+iBufLen);
      } /* if (iSofDataLen > 0) */

      /* ------------------------------------------------------------ */
      /* Write reinput txn data to buffer file if has reinput requist */
      /* ------------------------------------------------------------ */

      if ( cTxnReinput == TMS_TXN_REINPUT_ON || 
                      cTxnReinput == TMS_TXN_REINPUT_ON_API ) {

/*
        ErrLog(100,"TxEndInform() : REINPUT DATA DUMP=",
               RPT_TO_LOG,pstTba->caRendo, MAX_SIF_LEN);
*/

/*
        memcpy( &sSofCtlData, &pstTba->caRendo[SOF_CTL_CODE_OFFSET],
              SOF_CTL_CODE_SIZE );
 */
        cSofCtlData1 = pstTba->caRendo[SOF_CTL_CODE_OFFSET];

        if ( cSofCtlData1 & REINPUT_MSG_MASK ) {

/* replace by WuChihLiang for Sof length is (first byte)*256+second byte ) 
	  memcpy(&sSofDataLen, &pstTba->caRendo[SOF_DATA_LEN_OFFSET],
	         SOF_DATA_LEN_SIZE);*/
          sSofDataLen=(unsigned char)pstTba->caRendo[SOF_DATA_LEN_OFFSET]*256 +
                      (unsigned char)pstTba->caRendo[SOF_DATA_LEN_OFFSET+1];

	  if ( sSofDataLen > 0 ) {
	    iBufLen = SOF_HEAD_LEN_PLUS_2 + sSofDataLen;

	    if ((write(OutptFp,pstTba->caRendo,iBufLen)) != iBufLen) {
	      sprintf(g_caMsg,"TxEndInform() :write(OutpFp,REINPUT) error = %d",
		      errno);
	      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
              close(OutptFp);
	      UCP_TRACE_END ( WRITE_TO_FILE_ERR );
	    } 
	   /*
	    * Clear TBA.caRendo AREA when txn ends
	    */
	    memset(pstTba->caRendo,'\0',iBufLen);
	  }  /* if (iSofDataLen > 0) */
          else {
	      sprintf(g_caMsg,"TxEndInform():TPESCRQT data length=%d error!",
                      sSofDataLen);
	      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
              close(OutptFp);
	      UCP_TRACE_END ( TPESCRQT_DATA_LEN_ERR );
          }  /* if (iSofDataLen <= 0) */

        } /* (pstTba->caRendo[SOF_CTL_CODE_OFFSET] == REINPUT_MSG_STATUS) */

      }  /* if ( cTxnReinput == TMS_TXN_REINPUT_ON || ..... )   */

      /* -------------------------------------------------------- */
      /* Write msgp data to buffer file if has msgp data          */
      /* -------------------------------------------------------- */
      pstMsgpCtl = (struct MsgBufCtlSt *) (pstTba->caMsgp);


/* -------- modified by Ellen for packing ths SOF data ---------- start -- */
      PACK_SOF_SIZE=g_iMaxPacketSize-SOF_HEAD_LEN_PLUS_2;
      sprintf(g_caMsg,"@@@ TPEO SOF cnt num=%d, offset=%d",pstMsgpCtl->iMsgCnt,
              pstMsgpCtl->iNextOffset);
      ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
      ErrLog(10,"DUMP MSGP=",RPT_TO_LOG,g_pstTba->caMsgp+sizeof(struct MsgBufCtlSt),pstMsgpCtl->iNextOffset);

      if ( (pstMsgpCtl->iNextOffset) > 0 ) {
       memcpy(caPackHeader,"                 @@@@@@@@  ",SOF_HEAD_LEN);
       for (iSofCnt = 0; iSofCnt < (int)pstMsgpCtl->iMsgCnt ;) {
        for (iBufLen = 0,iPackSofNum=0; iBufLen < PACK_SOF_SIZE &&
             iSofCnt < (int)pstMsgpCtl->iMsgCnt ;iPackSofNum++) {
          iSofLen=(unsigned char)pstTba->caMsgp[sizeof(struct MsgBufCtlSt)+
                   SOF_DATA_LEN_OFFSET+iSofLenPt]*256 +
                  (unsigned char)pstTba->caMsgp[sizeof(struct MsgBufCtlSt)+
                   SOF_DATA_LEN_OFFSET+iSofLenPt+1];
          iBufLen=iBufLen + iSofLen + SOF_HEAD_LEN_PLUS_2;
          iSofCnt++;
          iSofLenPt=iSofLenPt + iSofLen + SOF_HEAD_LEN_PLUS_2;
          sprintf(g_caMsg,
                 "iSofLen=%d,iBufLen=%d,iSofCnt=%d,iSofLenPt=%d,iPackSofNum=%d",
                 iSofLen,iBufLen,iSofCnt,iSofLenPt,iPackSofNum);
          ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
        }
        
        if ( (iSofCnt < (int)pstMsgpCtl->iMsgCnt  || iBufLen > PACK_SOF_SIZE) &&             (iPackSofNum > 1) ) {
         iPackSofNum--;
         iSofCnt--;
         iSofLenPt=iSofLenPt - (iSofLen + SOF_HEAD_LEN_PLUS_2);
         iBufLen=iBufLen - (iSofLen + SOF_HEAD_LEN_PLUS_2);
         sprintf(g_caMsg,"----uuuuuuuu----iSofLenPt=%d, iSofCnt=%d, iBufLen=%d",
                 iSofLenPt, iSofCnt, iBufLen);
         ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
        }
        else
         ErrLog(10,"@@@ last packed",RPT_TO_LOG,0,0);
         
        iSofPackLen = iSofPackLen + iBufLen;

        if ( iPackSofNum > 1 ) { /* pack SOF */
         if ( (pstMsgpCtl->iNextOffset) - iSofPackLen > 0 ) {
          memcpy(caPackHeader+SOF_CTL_CODE_OFFSET,"\x00\x00",2);
         }
         else {
          memcpy(caPackHeader+SOF_CTL_CODE_OFFSET,"\x80\x00",2);
         }
         *(caPackHeader+SOF_DATA_LEN_OFFSET)=(unsigned char)(iBufLen/256);
         *(caPackHeader+SOF_DATA_LEN_OFFSET+1)=(unsigned char)(iBufLen%256);

         write(OutptFp,caPackHeader,SOF_HEAD_LEN_PLUS_2);
        }

        if((write(OutptFp,&pstTba->caMsgp[sizeof(struct MsgBufCtlSt)+
            iSofPackPt], iBufLen)) != iBufLen) {
         sprintf(g_caMsg,"TxEndInform() :write(OutpFp,MSGP error = %d",errno);
         ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
         close(OutptFp);
         UCP_TRACE_END ( WRITE_TO_FILE_ERR );
        } /*if (write(OutptFp,((char *)(pstTba->caMsgp)...)*/
        iSofPackPt=iSofPackPt+iBufLen;
       } /* for */
      } /* if ((pstMsgpCtl->iNextOffset) > 0 ) */
/* --------------------------------------------------------------- end --- */
    } /* g_pstTma->stTCFA.cReentryStatus == TMS_TXN_NOT_REENTRY */
    else {
      /* modify by chi-fusong, 1995/03/26 */
      memset( caSofCtlHead , 0, SOF_HEAD_LEN_PLUS_2 );
      memcpy( &caSofCtlHead[ SOF_CTL_CODE_OFFSET ], REENTRY_TXN_OK,
              SOF_CTL_CODE_SIZE);
      /* ------------------------------------------------------------ */
      /* write SOF Control HEAD for Communication Protocol with DBP   */
      /* ------------------------------------------------------------ */
      if ((write(OutptFp,caSofCtlHead,SOF_HEAD_LEN_PLUS_2)) != 
                                                   SOF_HEAD_LEN_PLUS_2) {
        sprintf(g_caMsg,"TxEndInform() :write(OutpFp,SOF_CNTL_HEAD) error = %d",
                errno);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        close(OutptFp);
        UCP_TRACE_END ( WRITE_TO_FILE_ERR );
      } 
    } /* g_pstTma->stTCFA.cReentryStatus == TMS_TXN_REENTRY */

  } /* if (cApReturnCode == '0' || cApReturnCode == '2') */
  else { 
    if ( g_pstTma->stTCFA.cReentryStatus == TMS_TXN_NOT_REENTRY ) {
      /* -------------------------------------------------------- */
      /* Write error msg data to buffer file                      */
      /* -------------------------------------------------------- */
      pstMsgpCtl = (struct MsgBufCtlSt *) (pstTba->caMsgp);
      if ( (pstMsgpCtl->iMsgCnt) == 1 ) {
        iBufLen = pstMsgpCtl->iNextOffset;
        if((write(OutptFp,((char *)(pstTba->caMsgp)+sizeof(struct MsgBufCtlSt)),
             iBufLen)) != iBufLen) {
          sprintf(g_caMsg,"TxEndInform():write(OutpFp,ERRMSG error = %d",errno);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          close(OutptFp);
          UCP_TRACE_END ( WRITE_TO_FILE_ERR );
        } /*if (write(OutptFp,((char *)(pstTba->caMsgp)...)*/
      } /* if ((pstMsgpCtl->iNextOffset) > 0 ) */
      else {
        sprintf(g_caMsg,"TxEndInform() :ERRMSG count error ! %d"
                ,pstMsgpCtl->iNextOffset);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        close(OutptFp);
        UCP_TRACE_END ( INVALID_MSG_CNT_ERR );
      }
    } /* (g_pstTma->stTCFA.cReentryStatus == TMS_TXN_NOT_REENTRY ) */
    else {
      /* modify by chi-fusong, 1995/03/26 */
      pstMsgpCtl = (struct MsgBufCtlSt *) (pstTba->caMsgp);
      if ( (pstMsgpCtl->iMsgCnt) == 1 ) {
        iBufLen = pstMsgpCtl->iNextOffset;
        memcpy( ( (char *)(pstTba->caMsgp) + sizeof(struct MsgBufCtlSt) +
                  SOF_CTL_CODE_OFFSET ), REENTRY_TXN_ERR, SOF_CTL_CODE_SIZE );
        if((write(OutptFp,((char *)(pstTba->caMsgp)+sizeof(struct MsgBufCtlSt)),
             iBufLen)) != iBufLen) {
          sprintf(g_caMsg,"TxEndInform():write(OutpFp,ERRMSG error = %d",errno);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          close(OutptFp);
          UCP_TRACE_END ( WRITE_TO_FILE_ERR );
        } /*if (write(OutptFp,((char *)(pstTba->caMsgp)...)*/
      } /* if ((pstMsgpCtl->iNextOffset) > 0 ) */
      else {
        sprintf(g_caMsg,"TxEndInform() :ERRMSG count error ! %d"
                ,pstMsgpCtl->iNextOffset);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        close(OutptFp);
        UCP_TRACE_END ( INVALID_MSG_CNT_ERR );
      }
    } /* (g_pstTma->stTCFA.cReentryStatus == TMS_TXN_REENTRY ) */
  } /* if (cApReturnCode != '0' && cApReturnCode != '2') */

  iRc = close(OutptFp);
  if (iRc != 0) {
      sprintf(g_caMsg,"TxEndInform() :close(OutpFp) error = %d",errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END ( CLOSE_OUTPUT_FILE_ERR );
  } /* if (iRc == 0) */

  UCP_TRACE_END ( 0 );
} /* TxEndInform() */


/*
 *&N& ROUNTINE NAME : SendToIO()
 *&A& ARGUMENTS:
 *&A&	NAME	       TYPE	    DESCRIPTION
 *&A& --------------- ----------- ----------------------------
 *&A&	pcaTmCode      char *	   �׺ݾ��N�X
 *&A&
 *&A&
 *&A&
 *&A&
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D&  �N��X�ɸ�ƮھڼзǮ榡�N�X�̨���ݶǰe��k�ǰe��Ʀܺݥ�.
 *&D&  1.�̾ڲ׺ݾ��N�X(pcaTmCode)�}�ҿ�X�ɮ�(OUTPT_FILE).
 *&D&  2.Ū���ө��ݩ��ݶǰe��k�ΨC���ǰe����.
 *&D&  3.�̶ǰe��k�ΨC���ǰe���שI�sDCS�����N��ƶǥX.
 *&D&
 *&D&
 *&D&  �I�s���禡���禡 :
 *&D&	  tmmain.c : TxOutput().
 *&D&
 *&D&
 */


int
SendToIO(pcaTmCode,pcaBrCode)
char *pcaTmCode;
char *pcaBrCode;
{
  int iRc;
  char caInputFile[80];
  int iInputFp;
  char cMethod;
  int iMsgSize;
  int iReadSize;
  int iFileSize;
  char cMoreData;
  char cLoopFlag = 'y';
  struct stat stStat;
  int iCtlFlowFlag; 
  char caAckBuf[MAX_SIF_LEN];
  char cFirstAck;
  char cSofCtlData1;
  int iDcsRtnCode;

  UCP_TRACE(P_SendToIO);

  memset(caInputFile,'\0',80);
  sprintf(caInputFile,"%s/%s%.*s.%.*s",getenv("III_DIR"),OUTPT_PREFIX,
          g_iTmCodeLen, pcaTmCode, g_iBrhCodeLen, pcaBrCode);

  if ((iInputFp = open(caInputFile,O_RDONLY)) == -1) {
      sprintf(g_caMsg,"SendToIO() :open(InputFp) error = %d",errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END ( OPEN_INPUT_FILE_ERR );
  } /* if ((iInputFp = open(caInputFile,O_RDONLY)) == -1) */

/*
  sprintf(g_caMsg,"SendToIO() :open(InputFp) iInputFp = %d",iInputFp);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
*/

  iRc = GetSndMethod(&cMethod,&iMsgSize);
  if (iRc < 0) {
    sprintf(g_caMsg,"Call GetSndMethod() error = %d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    close(iInputFp);
    UCP_TRACE_END ( GET_SEND_METHOD_ERR );
  } /* if (iRc < 0) */

  iRc = fstat(iInputFp,&stStat);
  if (iRc != 0) {
    sprintf(g_caMsg,"call fstat() error errno = %d",errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    close(iInputFp);
    UCP_TRACE_END ( GET_FILE_STATUS_ERR );
  } /* if (iRc != 0) */

  iFileSize = stStat.st_size;
/*
  sprintf(g_caMsg,"SendToIO() :iFileSize=%d",iFileSize);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
*/

  if (iFileSize <= 0) {
    sprintf(g_caMsg,"Output file size = %d",iFileSize);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    close(iInputFp);
    UCP_TRACE_END ( OUTPUT_FILE_EMPTY_ERR );
  }  /* if (iFileSize <= 0) */

  if (cMethod == METHOD_1) {
    if (iMsgSize <= 0 || iMsgSize > (MAX_MSGP_BUFFER)) {
      sprintf(g_caMsg,"Overflow MsgSize = %d",iMsgSize);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      close(iInputFp);
      UCP_TRACE_END ( SEND_SIZE_OVERFLOW_ERR );
    }  /* if (iMsgSize <= 0) */
  }

  cFirstAck = YES;
  iCtlFlowFlag = ON;

  while(cLoopFlag == 'y') {

    switch(cMethod) {
      case  METHOD_1 :
	if (iFileSize > iMsgSize) {
	  cMoreData = '1';
	}
	else {
	  cMoreData = '0';
	  cLoopFlag = 'n';
	} /* if (iFileSize > iMsgSize) */

	if ((iReadSize = read(iInputFp,g_pstTba->caMsgp,iMsgSize)) > 0) {
	  iRc = TmsDataSend(iReadSize,g_pstTba->caMsgp,cMoreData,&iDcsRtnCode);
	  if (iRc < 0) {
	    sprintf(g_caMsg,"call TmsDataSend() error = %d",iRc);
	    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
	    close(iInputFp);
	    UCP_TRACE_END ( TMS_DATA_SEND_ERR );
	  } /* if (iRc < 0)*/
	  iFileSize -= iReadSize;
	}
	else {
	  sprintf(g_caMsg,"read(iInputFp=%d) no data error= %d",iInputFp,errno);
	  ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          close(iInputFp);
	  UCP_TRACE_END ( READ_INPUT_FILE_ERR );
	} /* if ((iReadSize = read(iInputFp,g_pstTba->caMsgp,iMsgSize)) > 0) */
	break;
      case  METHOD_2 :
	iRc = IsMore(iInputFp,&iReadSize);
/*
	sprintf(g_caMsg,"SendToIO() :iReadSize=%d",iReadSize);
	ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
	ErrLog(100,"SendToTO (METHOD 2)=",
               RPT_TO_LOG,g_pstTba->caMsgp,iReadSize);
*/
	switch(iRc) {
	  case	0  :
	   cMoreData = '0';
	   cLoopFlag = 'n';
	   break;
	  case	1  :
	   cMoreData = '1';
	   break;
	  default  :
	   sprintf(g_caMsg,"IsMore Error = %d iRc = %d",errno,iRc);
	   ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
	   close(iInputFp);
	   UCP_TRACE_END ( IS_MORE_ERR );
	} /* switch(iRc) */

        if ( iCtlFlowFlag == ON ) { 
/*
          memcpy( &sSofCtlData , &g_pstTba->caMsgp[SOF_CTL_CODE_OFFSET],
                  SOF_CTL_CODE_SIZE );
 */
          cSofCtlData1 = g_pstTba->caMsgp[SOF_CTL_CODE_OFFSET] ;
          if ( cSofCtlData1 & LAST_MSG_MASK ) {
            iCtlFlowFlag = OFF;
          }

          iRc = TmsDataSend(iReadSize,g_pstTba->caMsgp,cMoreData,&iDcsRtnCode);
	  if (iRc < 0) {
	    sprintf(g_caMsg,"TmsDataSend() error iRc = %d",iRc);
	    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
	    close(iInputFp);
	    UCP_TRACE_END ( TMS_DATA_SEND_ERR );
	  }  /* if (iRc < 0)*/
        }
        else {
          iRc = GetAck(caAckBuf, &iDcsRtnCode,sizeof(caAckBuf));
	  if (iRc < 0) {
	    sprintf(g_caMsg,"TmsDataSend() error iRc = %d",iRc);
	    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
	    close(iInputFp);
	    UCP_TRACE_END ( GET_ACK_ERR );
	  }  /* if (iRc < 0)*/

          if ( cFirstAck == YES ) {
            if ( memcmp(caAckBuf, "TPEO", 4) != 0 ) {
	      sprintf(g_caMsg,"TmsDataSend() error iRc = %d",iRc);
	      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
	      close(iInputFp);
	      UCP_TRACE_END ( FIRST_ACK_ERR );
            }
            cFirstAck = NO;
          } 
          else {
            if ( caAckBuf[0] != '\0') {
	      sprintf(g_caMsg,"TmsDataSend() error iRc = %d",iRc);
	      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
	      close(iInputFp);
	      UCP_TRACE_END ( OTHER_ACK_ERR );
            }
          }

          if ( cMoreData == '0' ) { /* this is the last data */
            memcpy(&g_pstTba->caMsgp[SOF_CTL_CODE_OFFSET],LAST_MSG_STATUS,
                   SOF_CTL_CODE_SIZE);
          }

          iRc = TmsDataSend(iReadSize,g_pstTba->caMsgp,cMoreData,&iDcsRtnCode);
	  if (iRc < 0) {
	    sprintf(g_caMsg,"TmsDataSend() error iRc = %d",iRc);
	    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
	    close(iInputFp);
	    UCP_TRACE_END ( TMS_DATA_SEND_ERR );
	  }  /* if (iRc < 0)*/
        }

	break;
      default	     :
	sprintf(g_caMsg,"Send Method Error = %c",cMethod);
	ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
	close(iInputFp);
	UCP_TRACE_END ( SEND_METHOD_ERR );
    } /* switch(cMethod) */

  } /* while(cLoopFlag == 'y') */

  close(iInputFp);

  /*
   * Clear TBA.caMsgp AREA when txn ends
   */
  memset(g_pstTba->caMsgp,'\0',sizeof(struct MsgBufCtlSt));

  UCP_TRACE_END ( 0 );

}  /* SendToIO() */


/*
 *&N& ROUNTINE NAME : IsMore(iInputFp,piDataLen)
 *&A& ARGUMENTS:
 *&A&	NAME	       TYPE	    DESCRIPTION
 *&A& --------------- ----------- ----------------------------
 *&A&	iInputFp       int	   ��Ū���ɮ״y�z
 *&A&	piDataLen      int*	   Ū������ƪ���
 *&A&
 *&R& RETURN VALUE(i);
 *&R&	  1 : �|���U�@��
 *&R&	  0 : �L�U�@�����
 *&R&	 -1 : �ɮ׵L���
 *&D&	 -2 :  Read SOF Head Fail
 *&D&	 -3 :  Read SOF Data Fail
 *&R&  ��L : Ū���ɮצ��~
 *&R&
 *&R&
 *&D& DESCRIPTION:
 *&D&  �̼зǿ�X�榡Ū�X�ǰe�����(iInputFp)���.
 *&D&  1.�HŪ�����L�U�@����Ƥ覡(iRc),�M�w�ǰe���MoreData�X��.
 *&D&  2.iRc -> 1  :  ���U�@��,�^�� 1.
 *&D&		0  :  �L�������
 *&D&	       -1  :  File Empty!
 *&D&	       -2  :  Read SOF Head Fail
 *&D&	       -3  :  Read SOF Data Fail
 *&D&  �I�s���禡���禡 :
 *&D&	  tmsoutpt.c : SendToIO().
 *&D&
 *&D&
 */

int
IsMore(iInputFp,piDataLen)
int iInputFp;
int *piDataLen;
{
  int iRc;
  int iRdSize;
  static char caSofHeadBuf[ SOF_HEAD_LEN_PLUS_2 ];
  static char caSofDataBuf[ MAX_TBA_PARA_LEN ];
  static char cFirstLinkFlag = '\0';
  static short sDataLen = 0;

  UCP_TRACE(P_IsMore);

/*
*/
  ErrLog(100,"IsMore() sDataLen: ",RPT_TO_LOG,&sDataLen,sizeof(short));

  if ( cFirstLinkFlag == '\0' ) {
    if ((iRdSize = read(iInputFp,caSofHeadBuf,SOF_HEAD_LEN_PLUS_2)) 
                                                 == SOF_HEAD_LEN_PLUS_2) {
/* replace by WuChihLiang for Sof length is (first byte)*256+second byte ) 
      memcpy(&sDataLen,&caSofHeadBuf[SOF_DATA_LEN_OFFSET],SOF_DATA_LEN_SIZE);*/
      sDataLen=(unsigned char)caSofHeadBuf[SOF_DATA_LEN_OFFSET]*256 +
               (unsigned char)caSofHeadBuf[SOF_DATA_LEN_OFFSET+1];
/*
*/
      sprintf(g_caMsg,"IsMore():caSofHeadBuf[%d]=0x%.2x%.2x",
              SOF_DATA_LEN_OFFSET,
              caSofHeadBuf[SOF_DATA_LEN_OFFSET],
              caSofHeadBuf[SOF_DATA_LEN_OFFSET+1]);
      sprintf(g_caMsg,"IsMore():first SOF,dump Sof Header!,sDataLen=%d",
              sDataLen);
      ErrLog(100,g_caMsg,RPT_TO_LOG,caSofHeadBuf,SOF_HEAD_LEN_PLUS_2);
      ErrLog(100,"IsMore:first SOF,sDataLen=",RPT_TO_LOG,&sDataLen,sizeof(short));
    }
    else {
      cFirstLinkFlag = '\0';
      sDataLen = 0;
      memset(caSofHeadBuf, 0, SOF_HEAD_LEN_PLUS_2);
      memset(caSofDataBuf, 0, MAX_TBA_PARA_LEN);
      sprintf(g_caMsg,"IsMore(): file is empty!");
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END( -1 );
    }
    cFirstLinkFlag = 'n';
  }

  if ((iRdSize = read(iInputFp,caSofDataBuf,sDataLen)) == (int) sDataLen) {
/*
*/
    ErrLog(100,"IsMore() caSofDataBuf: ",RPT_TO_LOG,caSofDataBuf,iRdSize);

    memcpy(g_pstTba->caMsgp,caSofHeadBuf,SOF_HEAD_LEN_PLUS_2);
    memcpy(&g_pstTba->caMsgp[SOF_HEAD_LEN_PLUS_2],caSofDataBuf,sDataLen);
    *piDataLen = sDataLen + SOF_HEAD_LEN_PLUS_2 ;
/*
*/
    ErrLog(100,"IsMore() piDataLen: ",RPT_TO_LOG,piDataLen,sizeof(int));
    if ( (iRdSize = read(iInputFp,caSofHeadBuf,SOF_HEAD_LEN_PLUS_2))
                                               == SOF_HEAD_LEN_PLUS_2) {
/* replace by WuChihLiang for Sof length is (first byte)*256+second byte ) 
      memcpy(&sDataLen,&caSofHeadBuf[SOF_DATA_LEN_OFFSET],SOF_DATA_LEN_SIZE);*/
      sDataLen=(unsigned char)caSofHeadBuf[SOF_DATA_LEN_OFFSET]*256 +
               (unsigned char)caSofHeadBuf[SOF_DATA_LEN_OFFSET+1];
/*
*/
      sprintf(g_caMsg,"IsMore():caSofHeadBuf[%d]=0x%.2x%.2x",
              SOF_DATA_LEN_OFFSET,
              caSofHeadBuf[SOF_DATA_LEN_OFFSET],
              caSofHeadBuf[SOF_DATA_LEN_OFFSET+1]);
      ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
      sprintf(g_caMsg,"IsMore():dump Sof Header!,sDataLen=%d", sDataLen);
      ErrLog(100,g_caMsg,RPT_TO_LOG,caSofHeadBuf,SOF_HEAD_LEN_PLUS_2);
      ErrLog(100,"HEAD: sDataLen=",RPT_TO_LOG,&sDataLen,sizeof(short));

      UCP_TRACE_END( 1 );
    }
    else {
      if ( iRdSize == 0 ) {
      /*
       *  �ɮפ��w�g�S����ơC
       *  Reset flag: cFirstLinkFlag = '\0'
       */
	cFirstLinkFlag = '\0';
	sDataLen = 0;
	memset(caSofHeadBuf, 0, SOF_HEAD_LEN_PLUS_2);
	memset(caSofDataBuf, 0, MAX_TBA_PARA_LEN);
	UCP_TRACE_END( 0 );
      }
      else {
	cFirstLinkFlag = '\0';
	sDataLen = 0;
	memset(caSofHeadBuf, 0, SOF_HEAD_LEN_PLUS_2);
	memset(caSofDataBuf, 0, MAX_TBA_PARA_LEN);
	sprintf(g_caMsg,"IsMore(): Read SOF Head Fail! iRdSize=%d",sDataLen);
	ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
	UCP_TRACE_END( -2 );
      }
    }
  }
  else {
/*
*/
    cFirstLinkFlag = '\0';
    sDataLen = 0;
    memset(caSofHeadBuf, 0, SOF_HEAD_LEN_PLUS_2);
    memset(caSofDataBuf, 0, MAX_TBA_PARA_LEN);
    sprintf(g_caMsg,"IsMore(): Read SOF Data Fail! iRdSize=%d",(int) sDataLen);
    ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
    ErrLog(100,"iRdSize=",RPT_TO_LOG,&iRdSize,sizeof(int));
    ErrLog(100,"sDataLen=",RPT_TO_LOG,&sDataLen,sizeof(short));
    UCP_TRACE_END( -3 );
  }

 }  /* IsMore() */


/*
 *&N& ROUNTINE NAME : AddSofHeadToSif()
 *&A& ARGUMENTS:
 *&A&	NAME	       TYPE	    DESCRIPTION
 *&A& --------------- ----------- ----------------------------
 *&A&
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D&
 */
int
AddSofHeadToSif(char *pcaRendo,char *pcaBrCode,char *pcaTmCode,int iSifLen)
{
  int iRc;
  char caSofData[MAX_SIF_LEN + SOF_HEAD_LEN + 2];
  char *pcaSofData;
  char caCntlByte[2];

  UCP_TRACE(P_AddSofHeadToSif);
  pcaSofData = caSofData;
  pcaSofData += SOF_DCS_CODE_LEN;
  memcpy(pcaSofData,pcaBrCode,g_iBrhCodeLen);
  pcaSofData += SOF_BR_CODE_LEN;
  memcpy(pcaSofData,pcaTmCode,g_iTmCodeLen);
  pcaSofData += SOF_TM_CODE_LEN;
  pcaSofData += SOF_OUT_DEV_LEN;
  memset(pcaSofData,'\0',SOF_MSG_CODE_SIZE);
  pcaSofData += SOF_MSG_CODE_LEN;
  memcpy( caCntlByte , REINPUT_MSG_STATUS, SOF_CTL_CODE_SIZE);
  memcpy( pcaSofData, caCntlByte, SOF_CTL_CODE_SIZE);
  pcaSofData += SOF_CTL_CODE_LEN;

/*
  sprintf(g_caMsg,"AddSofHeadToSif: SIF length=%d",iSifLen);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
*/

  if ( iSifLen > MAX_SIF_LEN ) {
    sprintf(g_caMsg, "AddSofHeadToSif: SIF length = %d > MAX_SIF_LEN = 520 error",iSifLen);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  }

  *pcaSofData = iSifLen/256;
  *(pcaSofData+1) = (char) (iSifLen%256);

/*
  ErrLog(100,"AddSofHeadToSif: SIF length HIGH_BYTE=",
         RPT_TO_LOG,pcaSofData,1);
  ErrLog(100,"AddSofHeadToSif: SIF length LOW_BYTE=",
         RPT_TO_LOG,pcaSofData+1,1);
*/

  pcaSofData += SOF_DATA_LEN;
  memcpy(pcaSofData,pcaRendo,iSifLen);
  memcpy(pcaRendo, caSofData, SOF_HEAD_LEN_PLUS_2+iSifLen);
/*
  ErrLog(100,"AddSofHeadToSif: DUMP REINPUT=",RPT_TO_LOG,pcaRendo,
	 SOF_HEAD_LEN_PLUS_2+iSifLen);
*/
  UCP_TRACE_END( 0 );
}




/*
 *&N& ROUNTINE NAME : GetSndMethod()
 *&A& ARGUMENTS:
 *&A&	NAME	       TYPE	    DESCRIPTION
 *&A& --------------- ----------- ----------------------------
 *&A&
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D&
 */

int
GetSndMethod(pcMethod,piMsgSize)
char *pcMethod;
int *piMsgSize;
{
   *pcMethod = '2';
   *piMsgSize = 20;
    return 0;
}

/* *********************************************************** */
/* g_caMemBuf contain MemBufCtl MSGP + REINPUT SIF + remote reverse txn SIF + 
   POST + SOF_HEAD_LEN_PLUS_2*2 (for control) + g_stHostToBrhInfo(100 bytes) */
char g_caMemBuf[MAX_MSGP_LEN * 2];
struct  MemBufCtlSt{
  int iMsgCnt;
  int iNextOffset;
}g_stMemBufCtl;


#define P_SaveOutputToFile       28009
#define P_MemWrite               28010

/*
 *&N& ROUNTINE NAME : NewTxEndInform()
 *&A& ARGUMENTS:
 *&A&	NAME	       TYPE	    DESCRIPTION
 *&A& --------------- ----------- ----------------------------
 *&A&  cApReturnCode   char	   AP�B�z�ᵲ�G('0','2'�����`)
 *&A&  cTxnReinput     char	   �U�@����O�_�������s�ʥ��
 *&A&  pcaTmCode       char *	   ������X��Ƥ��׺ݾ��N�X
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D&  �N����Ȧs��(TBA)���T�����(MSGP),��m���(RENDO)�g�J��X��.
 *&D&  1.�̾ڲ׺ݾ��N�X(pcaTmCode)�}�ҿ�X�ɮ�(OUTPT_FILE).
 *&D&  2.�s������Ȧs��(TBA,pstTba)�Y�w�s���h �������Ψ�ҩl��}.
 *&D&  3.�YAP�B�z�ᵲ�G(cApReturnCode)�����`('0','2') �h :
 *&D&	   3.1 �g�J��m���:
 *&D&	       �N��m���(pstTba->caPost),�H�Ӹ���`����(iPostLen)�g�J.
 *&D&	   3.2 �g�J�T�����(pstTba->caMsgp):
 *&D&	       �N�T�����(pcaMsgpData),�H�Ӹ���`����(pstMsgpCtl->iNextOffset)
 *&D&	       �g�J.
 *&D&	   3.3 �Y�U�@����������s�ʥ��(cTxnReinput == '1') �h :
 *&D&	       �g�J�зǿ�J�榡���(pstTba->caRendo)�H�Ӹ���`����(iPostLen)�g�J
 *&D&	 �_�h :
 *&D&	   3.2 �g�J�T�����(pstTba->caMsgp):
 *&D&	       �N�T�����(pcaMsgpData),�H�Ӹ���`����(pstMsgpCtl->iNextOffset)
 *&D&	       �g�J.
 *&D&
 *&D&  �I�s���禡���禡 :
 *&D&	  tmmain.c : TxOutput().
 *&D&
 *&D&
 */

int
NewTxEndInform(cApReturnCode,cTxnReinput,pcaTmCode, pcaBrCode)
char cApReturnCode;
char cTxnReinput;
char *pcaTmCode;
char *pcaBrCode;
{
  static char cFirstLinkFlag = '\0';
  static struct TBA *pstTba;
  int iRc;
  struct MsgBufCtlSt *pstMsgpCtl;
  char caOutptFile[80];
  int iBufLen;
  short sSofDataLen;
  struct TwaCtl stTwaCtl;
  char cSofCtlData1;
  char  caSofCtlHead[SOF_HEAD_LEN_PLUS_2];
  int   iHaveReinput;
  int   iHaveMsgp;
  char  caCntlByte[2];
/* Added by Ellen for packing ths SOF data  */
  char  caPackHeader[SOF_HEAD_LEN_PLUS_2];
  int   iSofCnt=0;
  int   iSofPackLen=0;
  int   iSofLenPt=0;
  int   iSofPackPt=0;
  int   iSofLen=0;
  int   iPackSofNum;
  int   PACK_SOF_SIZE;

  struct  MemBufCtlSt *pstMemBufCtl;
  struct  MsgBufCtlSt stMsgBufCtl;

  UCP_TRACE(P_TxEndInform);

  sprintf(g_caMsg,
      "<APD>AP STATUS: TXNCODE=%.*s , Ap return code=%c , AP rendo request=%c"
      ,g_iTxnCodeLen,g_pstTma->stTSSA.caTxnCode,cApReturnCode
      ,g_pstTma->stTCFA.cRendoRequest);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);


  if (cApReturnCode == TMS_AP_ACC_NORMAL || 
                               cApReturnCode == TMS_AP_NON_ACC_NORMAL ) {
    if ( g_pstTma->stTCFA.cTpeWriteMsgKind == TMS_RCV_AP_MXXX_MSG) {
      memset(g_pstTba->caMsgp,'\0',sizeof(struct MsgBufCtlSt));
      UCP_TRACE_END(AP_NORMAL_END_BUT_SND_MXXX_MSG );
    }
  }

  memset(caOutptFile,'\0',80);
  sprintf(caOutptFile,"%s/%s%.*s.%.*s",getenv("III_DIR"),OUTPT_PREFIX,
          g_iTmCodeLen, pcaTmCode, g_iBrhCodeLen, pcaBrCode);

  /* Clear  g_caMemBuf */
  memset(g_caMemBuf, '\0', sizeof(g_caMemBuf));
  pstMemBufCtl = (struct MemBufCtlSt *)&g_stMemBufCtl ;
  pstMemBufCtl->iNextOffset = sizeof(struct MemBufCtlSt);
  pstMemBufCtl->iMsgCnt     = 0;

  /*
   * reset g_cFlushMemToFile to 'n' when TPECOPTX active it
   * close the output file when TPECOPTX generate it
   */
  if(g_iMemFileFd > 0) {
    g_cFlushMemToFileFlag='n';
    iRc=close(g_iMemFileFd);
    g_iMemFileFd=-1;
    if(iRc < 0) {
      sprintf(g_caMsg,"MemClose:close MemFile error! errno=%d",errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      return(-99);
    }
  }

  if (cFirstLinkFlag == '\0') {
     stTwaCtl.cFunCode = TWA_GET_SEG_PTR;
     stTwaCtl.cSegCode = TWA_SEG_TBA;
     iRc =  TwaLowCtlFac(&stTwaCtl,&pstTba);
     if (iRc < 0) {
       ErrLog(1000,"Get TWA address Error",RPT_TO_LOG,0,0);
       UCP_TRACE_END( GET_TBA_PTR_ERR );
     } /* if (iRc < 0) */
     cFirstLinkFlag = 'n';
  }  /* if (cFirstLinkFlag == NULL) */

  iHaveReinput = NO;
  iHaveMsgp = NO;

  if (cApReturnCode == TMS_AP_ACC_NORMAL || 
                              cApReturnCode == TMS_AP_NON_ACC_NORMAL ) {

    if ( g_pstTma->stTCFA.cReentryStatus == TMS_TXN_NOT_REENTRY ) {
      /* --------------------------------------------------------- */
      /* prepare Control SOF HEAD by Share memory's content        */
      /* --------------------------------------------------------- */
      if ( g_pstTma->stTCFA.cTxnReinput == TMS_TXN_REINPUT_ON ||
           g_pstTma->stTCFA.cTxnReinput == TMS_TXN_REINPUT_ON_API ) {
        iHaveReinput = YES;
      }

      pstMsgpCtl = (struct MsgBufCtlSt *) (pstTba->caMsgp);
      if ( pstMsgpCtl->iMsgCnt >= 1 ) {
        iHaveMsgp = YES;
      }

      if ( iHaveReinput == YES && iHaveMsgp == YES ) {
	  memcpy( caCntlByte , RE_1_NR_1, SOF_CTL_CODE_SIZE);
      }
      else {
        if ( iHaveReinput == YES && iHaveMsgp == NO ) {
	  memcpy( caCntlByte , RE_1_NR_0, SOF_CTL_CODE_SIZE);
        }
        else {
          if ( iHaveReinput == NO && iHaveMsgp == YES ) {
	    memcpy( caCntlByte , RE_0_NR_1, SOF_CTL_CODE_SIZE);
          }
          else {
            if ( iHaveReinput == NO && iHaveMsgp == NO ) {
	      memcpy( caCntlByte , RE_0_NR_0, SOF_CTL_CODE_SIZE);
            }
          }      
        }
      }

      memset( caSofCtlHead , 0, SOF_HEAD_LEN_PLUS_2 );
      memcpy( &caSofCtlHead[ SOF_CTL_CODE_OFFSET ], caCntlByte,
              SOF_CTL_CODE_SIZE);
      sSofDataLen=(unsigned char)pstTba->caPost[SOF_DATA_LEN_OFFSET]*256 +
                  (unsigned char)pstTba->caPost[SOF_DATA_LEN_OFFSET+1];
      caSofCtlHead[SOF_DATA_LEN_OFFSET] = (unsigned char) ((sSofDataLen*g_pstTma->stTCFA.iApEjCnt)/256);
      caSofCtlHead[SOF_DATA_LEN_OFFSET+1] = (unsigned char) ((sSofDataLen*g_pstTma->stTCFA.iApEjCnt)%256);
      /* ------------------------------------------------------------ */
      /* write SOF Control HEAD for Communication Protocol with DBP   */
      /* ------------------------------------------------------------ */
      if ((MemWrite(caSofCtlHead,SOF_HEAD_LEN_PLUS_2, 1)) != 
                                                   SOF_HEAD_LEN_PLUS_2) {
        sprintf(g_caMsg,"NewTxEndInform() :write(OutpFp,SOF_CNTL_HEAD) error = %d",
                errno);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END ( WRITE_TO_FILE_ERR );
      } 
  
      /* --------------------------------------------------------- */
      /* Write postprocess data to buffer file if has postprocess  */
      /* --------------------------------------------------------- */
      sSofDataLen=(unsigned char)pstTba->caPost[SOF_DATA_LEN_OFFSET]*256 +
                  (unsigned char)pstTba->caPost[SOF_DATA_LEN_OFFSET+1];

      if ( sSofDataLen > 0 ) {
        iBufLen = sSofDataLen*(g_pstTma->stTCFA.iApEjCnt);
        sprintf(g_caMsg,"caPost iBufLen=%d",iBufLen);
        ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
        ErrLog(100,"NewTxEndInform: POST=",RPT_TO_LOG,g_pstTba->caPost,SOF_HEAD_LEN_PLUS_2+iBufLen);
        if ((MemWrite(&pstTba->caPost[SOF_HEAD_LEN_PLUS_2],iBufLen, 0)) != 
                                                                 iBufLen) {
	  sprintf(g_caMsg,"NewTxEndInform() :write(OutpFp,POST) error = %d",errno);
	  ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
	  UCP_TRACE_END ( WRITE_TO_FILE_ERR );
        } 
        /*
         * Clear TBA.caPost AREA when txn ends
         */
        memset(pstTba->caPost,'\0',SOF_DATA_LEN_OFFSET+iBufLen);
      } /* if (iSofDataLen > 0) */

      /* ------------------------------------------------------------ */
      /* Write reinput txn data to buffer file if has reinput requist */
      /* ------------------------------------------------------------ */

      if ( cTxnReinput == TMS_TXN_REINPUT_ON || 
                      cTxnReinput == TMS_TXN_REINPUT_ON_API ) {

        cSofCtlData1 = g_caReinputBuffer[SOF_CTL_CODE_OFFSET];

        if ( cSofCtlData1 & REINPUT_MSG_MASK ) {

          sSofDataLen=(unsigned char)g_caReinputBuffer[SOF_DATA_LEN_OFFSET]*256 +
                      (unsigned char)g_caReinputBuffer[SOF_DATA_LEN_OFFSET+1];

	  if ( sSofDataLen > 0 ) {
	    iBufLen = SOF_HEAD_LEN_PLUS_2 + sSofDataLen;

	    if ((MemWrite(g_caReinputBuffer,iBufLen, 1)) != iBufLen) {
	      sprintf(g_caMsg,"NewTxEndInform() :write(OutpFp,REINPUT) error = %d",
		      errno);
	      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
	      UCP_TRACE_END ( WRITE_TO_FILE_ERR );
	    } 
	   /*
	    * Clear TBA.caRendo AREA when txn ends
	    */
	    memset(g_caReinputBuffer,'\0',iBufLen);
	  }  /* if (iSofDataLen > 0) */
          else {
	      sprintf(g_caMsg,"NewTxEndInform():TPESCRQT data length=%d error!",
                      sSofDataLen);
	      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
	      UCP_TRACE_END ( TPESCRQT_DATA_LEN_ERR );
          }  /* if (iSofDataLen <= 0) */

        } /* (g_caReinputBuffer[SOF_CTL_CODE_OFFSET] == REINPUT_MSG_STATUS) */

      }  /* if ( cTxnReinput == TMS_TXN_REINPUT_ON || ..... )   */

      /* -------------------------------------------------------- */
      /* Write msgp data to buffer file if has msgp data          */
      /* -------------------------------------------------------- */
      if(g_iMsgpFileFd > 0) {
        iRc=ReadFile(g_iMsgpFileFd,0,&stMsgBufCtl,sizeof(stMsgBufCtl));
        if(iRc < 0) {
          ErrLog(1000,"NewTxEndInform:read stMsgBufCtl from MsgpFile error",
                 RPT_TO_LOG,0,0);
          UCP_TRACE_END ( -99 );
        }
        pstMsgpCtl = (struct MsgBufCtlSt *) (&stMsgBufCtl);
      }
      else {
        pstMsgpCtl = (struct MsgBufCtlSt *) (pstTba->caMsgp);
      }

/* -------- modified by Ellen for packing ths SOF data ---------- start -- */
      PACK_SOF_SIZE=g_iMaxPacketSize-SOF_HEAD_LEN_PLUS_2;
      /* if PACK_SOF_SIZE<=0 , it will loop infinitely */
      if(PACK_SOF_SIZE <= 0 ) PACK_SOF_SIZE = 1;
      sprintf(g_caMsg,"@@@ TPEO SOF cnt num=%d, offset=%d",pstMsgpCtl->iMsgCnt,
              pstMsgpCtl->iNextOffset);
      ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
      if(g_iMsgpFileFd > 0) {
        sprintf(g_caMsg,"MSGP is flushed to file. SOF cnt=%d,offset=%d",
                pstMsgpCtl->iMsgCnt,pstMsgpCtl->iNextOffset);
        ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
      }
      else {
        ErrLog(10,"DUMP MSGP=",RPT_TO_LOG,
        g_pstTba->caMsgp+sizeof(struct MsgBufCtlSt),pstMsgpCtl->iNextOffset);
      }

      if ( (pstMsgpCtl->iNextOffset) > 0 ) {
       if(g_iMsgpFileFd > 0) {
         iRc=ReadFile(g_iMsgpFileFd,
               sg_iLastSofOffset+sizeof(struct MsgBufCtlSt),
               pstTba->caMsgp+sizeof(struct MsgBufCtlSt),SOF_HEAD_LEN_PLUS_2);
         if(iRc < 0) {
           ErrLog(1000,"NewTxEndInform:read last SOF from MsgpFile error!",
                 RPT_TO_LOG,0,0);
           UCP_TRACE_END ( -99 );
         }
         pstTba->caMsgp[SOF_CTL_CODE_OFFSET+
                     sizeof(struct MsgBufCtlSt)] |=LAST_MSG_MASK;
         iRc=WriteFile(g_iMsgpFileFd,
               sg_iLastSofOffset+sizeof(struct MsgBufCtlSt),
               pstTba->caMsgp+sizeof(struct MsgBufCtlSt),SOF_HEAD_LEN_PLUS_2);
         if(iRc < 0) {
           ErrLog(1000,"NewTxEndInform:write last SOF to MsgpFile error!",
                 RPT_TO_LOG,0,0);
           UCP_TRACE_END ( -99 );
         }
       }
       else {
         pstTba->caMsgp[sg_iLastSofOffset+SOF_CTL_CODE_OFFSET+
                     sizeof(struct MsgBufCtlSt)] |=LAST_MSG_MASK;
       }
       memcpy(caPackHeader,"                 @@@@@@@@  ",SOF_HEAD_LEN);
       for (iSofCnt = 0; iSofCnt < (int)pstMsgpCtl->iMsgCnt ;) {
        for (iBufLen = 0,iPackSofNum=0; iBufLen < PACK_SOF_SIZE &&
             iSofCnt < (int)pstMsgpCtl->iMsgCnt ;iPackSofNum++) {
          if(g_iMsgpFileFd > 0) {
            iRc=ReadFile(g_iMsgpFileFd,
                 sizeof(struct MsgBufCtlSt)+iSofLenPt,
                 pstTba->caMsgp+sizeof(struct MsgBufCtlSt),SOF_HEAD_LEN_PLUS_2);
            if(iRc < 0) {
              ErrLog(1000,"NewTxEndInform:read SOF-Header from MsgpFile error",
                     RPT_TO_LOG,0,0);
              UCP_TRACE_END ( -99 );
            }
            iSofLen=(unsigned char)pstTba->caMsgp[sizeof(struct MsgBufCtlSt)+
                    SOF_DATA_LEN_OFFSET]*256 +
                   (unsigned char)pstTba->caMsgp[sizeof(struct MsgBufCtlSt)+
                    SOF_DATA_LEN_OFFSET+1];
          }
          else {
            iSofLen=(unsigned char)pstTba->caMsgp[sizeof(struct MsgBufCtlSt)+
                    SOF_DATA_LEN_OFFSET+iSofLenPt]*256 +
                   (unsigned char)pstTba->caMsgp[sizeof(struct MsgBufCtlSt)+
                    SOF_DATA_LEN_OFFSET+iSofLenPt+1];
          }
          iBufLen=iBufLen + iSofLen + SOF_HEAD_LEN_PLUS_2;
          iSofCnt++;
          iSofLenPt=iSofLenPt + iSofLen + SOF_HEAD_LEN_PLUS_2;
          sprintf(g_caMsg,
                 "iSofLen=%d,iBufLen=%d,iSofCnt=%d,iSofLenPt=%d,iPackSofNum=%d",
                 iSofLen,iBufLen,iSofCnt,iSofLenPt,iPackSofNum);
          ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
        }
        
        if ( (iSofCnt < (int)pstMsgpCtl->iMsgCnt  || iBufLen > PACK_SOF_SIZE) &&             (iPackSofNum > 1) ) {
         iPackSofNum--;
         iSofCnt--;
         iSofLenPt=iSofLenPt - (iSofLen + SOF_HEAD_LEN_PLUS_2);
         iBufLen=iBufLen - (iSofLen + SOF_HEAD_LEN_PLUS_2);
         sprintf(g_caMsg,"----uuuuuuuu----iSofLenPt=%d, iSofCnt=%d, iBufLen=%d",
                 iSofLenPt, iSofCnt, iBufLen);
         ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
        }
        else
         ErrLog(10,"@@@ last packed",RPT_TO_LOG,0,0);
         
        iSofPackLen = iSofPackLen + iBufLen;

        if ( iPackSofNum > 1 ) { /* pack SOF */
         if ( (pstMsgpCtl->iNextOffset) - iSofPackLen > 0 ) {
          memcpy(caPackHeader+SOF_CTL_CODE_OFFSET,"\x00\x00",2);
         }
         else {
          memcpy(caPackHeader+SOF_CTL_CODE_OFFSET,"\x80\x00",2);
         }
         *(caPackHeader+SOF_DATA_LEN_OFFSET)=(unsigned char)(iBufLen/256);
         *(caPackHeader+SOF_DATA_LEN_OFFSET+1)=(unsigned char)(iBufLen%256);

         if((MemWrite(caPackHeader,SOF_HEAD_LEN_PLUS_2, 0)) != 
                                                 SOF_HEAD_LEN_PLUS_2) {
           sprintf(g_caMsg,"NewTxEndInform():write pack header error! errno=%d",
                   errno);
           ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
           UCP_TRACE_END ( WRITE_TO_FILE_ERR );
         }
        }

        if(g_iMsgpFileFd > 0) {
          iRc=ReadFile(g_iMsgpFileFd,
                sizeof(struct MsgBufCtlSt)+iSofPackPt,
                pstTba->caMsgp+sizeof(struct MsgBufCtlSt),iBufLen);
          if(iRc < 0) {
            ErrLog(1000,"NewTxEndInform:read SOF from MsgpFile error!",
                   RPT_TO_LOG,0,0);
            UCP_TRACE_END ( -99 );
          }
          if((MemWrite(&pstTba->caMsgp[sizeof(struct MsgBufCtlSt)],
              iBufLen, 1)) != iBufLen) {
           sprintf(g_caMsg,"NewTxEndInform() :write(OutpFp,MSGP error = %d",errno);
           ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
           UCP_TRACE_END ( WRITE_TO_FILE_ERR );
          } /*if (write(OutptFp,((char *)(pstTba->caMsgp)...)*/
        }
        else {
          if((MemWrite(&pstTba->caMsgp[sizeof(struct MsgBufCtlSt)+
              iSofPackPt], iBufLen, 1)) != iBufLen) {
           sprintf(g_caMsg,"NewTxEndInform() :write(OutpFp,MSGP error = %d",errno);
           ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
           UCP_TRACE_END ( WRITE_TO_FILE_ERR );
          } /*if (write(OutptFp,((char *)(pstTba->caMsgp)...)*/
        }
        iSofPackPt=iSofPackPt+iBufLen;
       } /* for */
      } /* if ((pstMsgpCtl->iNextOffset) > 0 ) */
/* --------------------------------------------------------------- end --- */
    } /* g_pstTma->stTCFA.cReentryStatus == TMS_TXN_NOT_REENTRY */
    else {
      /* modify by chi-fusong, 1995/03/26 */
      memset( caSofCtlHead , 0, SOF_HEAD_LEN_PLUS_2 );
      memcpy( &caSofCtlHead[ SOF_CTL_CODE_OFFSET ], REENTRY_TXN_OK,
              SOF_CTL_CODE_SIZE);
      /* -----------begin----------put Post Data Len to control SOF */
      sSofDataLen=(unsigned char)pstTba->caPost[SOF_DATA_LEN_OFFSET]*256 +
                  (unsigned char)pstTba->caPost[SOF_DATA_LEN_OFFSET+1];
      caSofCtlHead[SOF_DATA_LEN_OFFSET] = (unsigned char) ((sSofDataLen*g_pstTma->stTCFA.iApEjCnt)/256);
      caSofCtlHead[SOF_DATA_LEN_OFFSET+1] = (unsigned char) ((sSofDataLen*g_pstTma->stTCFA.iApEjCnt)%256);
      /* -----------end  ----------put Post Data Len to control SOF */
      /* ------------------------------------------------------------ */
      /* write SOF Control HEAD for Communication Protocol with DBP   */
      /* ------------------------------------------------------------ */
      if ((MemWrite(caSofCtlHead,SOF_HEAD_LEN_PLUS_2,1)) != 
                                                   SOF_HEAD_LEN_PLUS_2) {
        sprintf(g_caMsg,"NewTxEndInform() :write(OutpFp,SOF_CNTL_HEAD) error = %d",
                errno);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END ( WRITE_TO_FILE_ERR );
      } 

      /* -----------begin----------put Post Data to control SOF's tail */
      if ( sSofDataLen > 0 ) {
        iBufLen = sSofDataLen*(g_pstTma->stTCFA.iApEjCnt);
        ErrLog(100,"NewTxEndInform: POST=",RPT_TO_LOG,g_pstTba->caPost,SOF_HEAD_LEN_PLUS_2+iBufLen);
        if ((MemWrite(&pstTba->caPost[SOF_HEAD_LEN_PLUS_2],iBufLen, 0)) != 
                                                                 iBufLen) {
	  sprintf(g_caMsg,"NewTxEndInform() :write(OutpFp,POST) error = %d",errno);
	  ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
	  UCP_TRACE_END ( WRITE_TO_FILE_ERR );
        } 
        /*
         * Clear TBA.caPost AREA when txn ends
         */
        memset(pstTba->caPost,'\0',SOF_DATA_LEN_OFFSET+iBufLen);
      } /* if (iSofDataLen > 0) */
      /* -----------end  ----------put Post Data to control SOF's tail */

    } /* g_pstTma->stTCFA.cReentryStatus == TMS_TXN_REENTRY */

  } /* if (cApReturnCode == '0' || cApReturnCode == '2') */
  else { 
    if ( g_pstTma->stTCFA.cReentryStatus == TMS_TXN_NOT_REENTRY ) {
      /* -------------------------------------------------------- */
      /* Write error msg data to buffer file                      */
      /* -------------------------------------------------------- */
      pstMsgpCtl = (struct MsgBufCtlSt *) (pstTba->caMsgp);
      if ( (pstMsgpCtl->iMsgCnt) == 1 ) {
        iBufLen = pstMsgpCtl->iNextOffset;
  /* added by WuChihLiang 19950323 for AP Abnormal end but send TXXX -- Begin */
        if(((char *) (pstTba->caMsgp))[sizeof(struct MsgBufCtlSt)+
                                             SOF_MSG_CODE_OFFSET+3] == 'T' ||
           ((char *) (pstTba->caMsgp))[sizeof(struct MsgBufCtlSt)+
                                             SOF_MSG_CODE_OFFSET+3] == 'W' ){
          sprintf(g_caMsg,"NewTxEndInform():AP Abnormal end but send TXXX");
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          UCP_TRACE_END ( AP_ABNORMAL_END_BUT_SND_TXXX    );
        }
  /* added by WuChihLiang 19950323 for AP Abnormal end but send TXXX -- End   */
        if((MemWrite(((char *)(pstTba->caMsgp)+sizeof(struct MsgBufCtlSt)),
             iBufLen, 1)) != iBufLen) {
          sprintf(g_caMsg,"NewTxEndInform():write(OutpFp,ERRMSG error = %d",errno);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          UCP_TRACE_END ( WRITE_TO_FILE_ERR );
        } /*if (write(OutptFp,((char *)(pstTba->caMsgp)...)*/
      } /* if ((pstMsgpCtl->iNextOffset) > 0 ) */
/* Modified by Willy 19960920 for cooperative txn -- begin */
      else if (g_pstTma->stTCFA.cTxnPattern != COOPERATIVE_TXN) {
/*    else { */ /* This line is original */
/* Modified by Willy 19960920 for cooperative txn -- end */
        sprintf(g_caMsg,"NewTxEndInform() :ERRMSG count error ! %d"
                ,pstMsgpCtl->iNextOffset);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END ( INVALID_MSG_CNT_ERR );
      }
    } /* (g_pstTma->stTCFA.cReentryStatus == TMS_TXN_NOT_REENTRY ) */
    else {
      /* modify by chi-fusong, 1995/03/26 */
      pstMsgpCtl = (struct MsgBufCtlSt *) (pstTba->caMsgp);
      if ( (pstMsgpCtl->iMsgCnt) == 1 ) {
        iBufLen = pstMsgpCtl->iNextOffset;
        memcpy( ( (char *)(pstTba->caMsgp) + sizeof(struct MsgBufCtlSt) +
                  SOF_CTL_CODE_OFFSET ), REENTRY_TXN_ERR, SOF_CTL_CODE_SIZE );
  /* added by WuChihLiang 19950323 for AP Abnormal end but send TXXX -- Begin */
        if(((char *) (pstTba->caMsgp))[sizeof(struct MsgBufCtlSt)+
                                             SOF_MSG_CODE_OFFSET+3] == 'T' ||
           ((char *) (pstTba->caMsgp))[sizeof(struct MsgBufCtlSt)+
                                             SOF_MSG_CODE_OFFSET+3] == 'W' ){
          sprintf(g_caMsg,"NewTxEndInform():AP Abnormal end but send TXXX");
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          UCP_TRACE_END ( AP_ABNORMAL_END_BUT_SND_TXXX    );
        }
  /* added by WuChihLiang 19950323 for AP Abnormal end but send TXXX -- End   */
        if((MemWrite(((char *)(pstTba->caMsgp)+sizeof(struct MsgBufCtlSt)),
             iBufLen, 1)) != iBufLen) {
          sprintf(g_caMsg,"NewTxEndInform():write(OutpFp,ERRMSG error = %d",errno);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          UCP_TRACE_END ( WRITE_TO_FILE_ERR );
        } /*if (write(OutptFp,((char *)(pstTba->caMsgp)...)*/
      } /* if ((pstMsgpCtl->iNextOffset) > 0 ) */
      else {
        sprintf(g_caMsg,"NewTxEndInform() :ERRMSG count error ! %d"
                ,pstMsgpCtl->iNextOffset);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END ( INVALID_MSG_CNT_ERR );
      }
    } /* (g_pstTma->stTCFA.cReentryStatus == TMS_TXN_REENTRY ) */
  } /* if (cApReturnCode != '0' && cApReturnCode != '2') */

  if(g_iMsgpFileFd > 0) {
    iRc=close(g_iMsgpFileFd);
    g_iMsgpFileFd=-1;
    if(iRc < 0) {
      sprintf(g_caMsg,"NewTxEndInform:close MsgpFile error! errno=%d",errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(-99);
    }
  }

  iRc=MemClose();
  if(iRc < 0) {
    UCP_TRACE_END ( iRc );
  }

  if(g_cFlushMemToFileFlag == 'n' && g_cLastQryFlag == LAST_QRY_OFF) {
    memcpy(g_caMemBuf,&g_stMemBufCtl,sizeof(struct MemBufCtlSt));
    iRc = SaveOutputToFile(caOutptFile,g_caMemBuf,pstMemBufCtl->iNextOffset);
    if (iRc != 0){
      UCP_TRACE_END ( iRc );
    }
  }

  UCP_TRACE_END ( 0 );
} /* NewTxEndInform() */

/*
 *&N& ROUNTINE NAME : SaveOutputToFile()
 *&A& ARGUMENTS:
 *&A&	NAME	       TYPE	    DESCRIPTION
 *&A& --------------- ----------- ----------------------------
 *&A&  pcFileName     char *	   ��X��Ƥ��ɮצW��.
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D&  �N�����X��ƼȦs�ϼg�J��X��.
 *&D&
 */
SaveOutputToFile(char *pcFileName,char *pcBuffer, int iBufferLen)
{
  int OutptFp;
  int iRc;

  UCP_TRACE(P_SaveOutputToFile);

  if ((OutptFp = open(pcFileName,O_WRONLY|O_CREAT|O_TRUNC,0666)) == -1) {
      sprintf(g_caMsg,"SaveOutputToFile:open(%s) error,errno=%d",pcFileName,
              errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END ( OPEN_OUTPUT_FILE_ERR );
  } /* if ((OutptFp = open(pcFileName,O_WRONLY|O_CREAT|O_TRUNC,06666)) == -1) */

  /* ------------------------------------------------------------ */
  /* write SOF Control HEAD for Communication Protocol with DBP   */
  /* ------------------------------------------------------------ */
  if ((write(OutptFp,pcBuffer,iBufferLen)) != iBufferLen) {
    sprintf(g_caMsg,"SaveOutputToFile:write Fd=%d error,errno=%d",
            OutptFp,errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    close(OutptFp);
    UCP_TRACE_END ( WRITE_TO_FILE_ERR );
  } 

  iRc = close(OutptFp);
  if (iRc != 0) {
      sprintf(g_caMsg,"SaveOutputToFile:close Fd=%d error,errno=%d",OutptFp,
              errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END ( CLOSE_OUTPUT_FILE_ERR );
  } /* if (iRc == 0) */

  UCP_TRACE_END ( 0 );

}

/*
 *&N& ROUNTINE NAME : NewSendToIO()
 *&A& ARGUMENTS:
 *&A&	NAME	       TYPE	    DESCRIPTION
 *&A& --------------- ----------- ----------------------------
 *&A&	pcaTmCode      char *	   �׺ݾ��N�X
 *&A&
 *&A&
 *&A&
 *&A&
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D&  �N��X�ɸ�ƮھڼзǮ榡�N�X�̨���ݶǰe��k�ǰe��Ʀܺݥ�.
 *&D&  1.�̾ڲ׺ݾ��N�X(pcaTmCode)�}�ҿ�X�ɮ�(OUTPT_FILE).
 *&D&  2.Ū���ө��ݩ��ݶǰe��k�ΨC���ǰe����.
 *&D&  3.�̶ǰe��k�ΨC���ǰe���שI�sDCS�����N��ƶǥX.
 *&D&
 *&D&
 *&D&  �I�s���禡���禡 :
 *&D&	  tmmain.c : TxOutput().
 *&D&
 *&D&
 */
/* ----------------------------------------------------------------- */

int
NewSendToIO(pcaTmCode,pcaBrCode)
char *pcaTmCode;
char *pcaBrCode;
{
  int   iDcsRtnCode;
  char  cMoreData;
  int   iCtlFlowFlag; 
  char  caAckBuf[MAX_SIF_LEN];
  char  caSofCtlData[SOF_CTL_CODE_LEN      ];
  int   iSofCnt = 0;
  char  cFirstCtlDataFlag = '1';
  char  caFirstSofCtlData[SOF_CTL_CODE_LEN      ];
  int   iRc;
  struct  MemBufCtlSt *pstMemBufCtl;
  char  *pcMemBufPt;
  int   iSofDataLen;
  int   iMemBufOffset;

  char  caCnvOutBuff[3072];
  int   iSofLen=0;
  char  caDataFmt[10];
  int   (* pfConvOutPgm)();

  int iAllSofLen;
  unsigned char  caPiggyHeader[SOF_HEAD_LEN_PLUS_2];
  char caMemFileName[256];

  UCP_TRACE(P_SendToIO);

  GetFmtCode(caDataFmt);
  pfConvOutPgm = GetConvPgm( caDataFmt, CONV_OUT );

  pstMemBufCtl = (struct MemBufCtlSt *)&g_stMemBufCtl ;
  iCtlFlowFlag = '1';
  iMemBufOffset= sizeof(struct MemBufCtlSt);
  cMoreData = '1';
  iSofDataLen= 0;

  if ( g_iPiggyBackSize >= (pstMemBufCtl->iNextOffset-iMemBufOffset) &&
       (pstMemBufCtl->iMsgCnt > 1) ) {
    iAllSofLen=(pstMemBufCtl->iNextOffset)-iMemBufOffset;
    cMoreData = '0';
    pcMemBufPt = g_caMemBuf + iMemBufOffset;
    memset(caPiggyHeader,0x0,SOF_HEAD_LEN_PLUS_2);
    memcpy(&caPiggyHeader[SOF_BR_CODE_OFFSET],pcaBrCode,g_iBrhCodeLen);
    memcpy(&caPiggyHeader[SOF_TM_CODE_OFFSET],pcaTmCode,g_iTmCodeLen);
    memcpy(&caPiggyHeader[SOF_OUT_DEV_OFFSET],"@@@@@@@@",8);
    caPiggyHeader[SOF_CTL_CODE_OFFSET]=0x80;
    caPiggyHeader[SOF_DATA_LEN_OFFSET]=(unsigned char) (iAllSofLen/256);
    caPiggyHeader[SOF_DATA_LEN_OFFSET+1]=(unsigned char) (iAllSofLen%256);
    memcpy(g_caMemBuf+pstMemBufCtl->iNextOffset,caPiggyHeader, SOF_HEAD_LEN_PLUS_2);
    memcpy(g_caMemBuf+(pstMemBufCtl->iNextOffset)+SOF_HEAD_LEN_PLUS_2,g_caMemBuf+iMemBufOffset,iAllSofLen);
    memcpy(g_caMemBuf+iMemBufOffset,g_caMemBuf+(pstMemBufCtl->iNextOffset),iAllSofLen+SOF_HEAD_LEN_PLUS_2);
    pstMemBufCtl->iNextOffset += SOF_HEAD_LEN_PLUS_2;
   
/* --------------------------------------------------------------------- */
        if ( pfConvOutPgm != NULL ) {
          iRc=(*pfConvOutPgm)(pcMemBufPt,caCnvOutBuff,iAllSofLen+SOF_HEAD_LEN_PLUS_2);
          if (iRc < 0) {
            sprintf( g_caMsg, "NewSendToIO: Output convert error!" );
            ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
            UCP_TRACE_END( CONVERT_OUT_ERR );
          }
          /* send TPU Sof to DBP */
          iRc=TmsDataSend(iRc, caCnvOutBuff,cMoreData,&iDcsRtnCode);
        }
        else {
          /* send TPU Sof to DBP */
          iRc=TmsDataSend(iAllSofLen+SOF_HEAD_LEN_PLUS_2,
                        pcMemBufPt,cMoreData,&iDcsRtnCode);
        }
/* --------------------------------------------------------------------- */
        if (iRc < 0) {
          sprintf(g_caMsg,"NewSendToIO:TmsDataSend() error iRc = %d",iRc);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          UCP_TRACE_END ( TMS_DATA_SEND_ERR );
        }  /* if (iRc < 0)*/
    
  }  /* PIGGY-BACK transmit protocol(i.e. just 1 time of communication */ 
  else {
    if(g_cFlushMemToFileFlag == 'y') {
      memset(caMemFileName,'\0',256);
      sprintf(caMemFileName,"%s/%s%.*s.%.*s",getenv("III_DIR"),OUTPT_PREFIX,
              g_iTmCodeLen, g_pstTma->stTSSA.caTmCode,g_iBrhCodeLen, 
              g_pstTma->stTSSA.caBrCode);

      if ((g_iMemFileFd = open(caMemFileName,O_RDONLY)) == -1) {
        sprintf(g_caMsg,"NewSendToIO() :open %s error! errno=%d",
                caMemFileName,errno);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END ( -99 );
      }
    }

    for (iSofCnt=0; iSofCnt < pstMemBufCtl->iMsgCnt; iSofCnt++) {
    
      if ( iSofCnt == (pstMemBufCtl->iMsgCnt - 1) ) {
        cMoreData = '0'; /* set last message */
      }

      pcMemBufPt = g_caMemBuf + iMemBufOffset;
      if(g_iMemFileFd > 0) {
        iRc=ReadFile(g_iMemFileFd,iMemBufOffset,g_caMemBuf,SOF_HEAD_LEN_PLUS_2);
        if(iRc < 0) {
          ErrLog(1000,"NewSendToIO:read SOF-header from MemFile error!",
                 RPT_TO_LOG,0,0);
          UCP_TRACE_END(-99);
        }
        iSofDataLen=(unsigned char)g_caMemBuf[SOF_DATA_LEN_OFFSET]*256 +
                    (unsigned char)g_caMemBuf[SOF_DATA_LEN_OFFSET+1];
        iRc=ReadFile(g_iMemFileFd,iMemBufOffset,g_caMemBuf,
                     SOF_HEAD_LEN_PLUS_2+iSofDataLen);
        if(iRc < 0) {
          ErrLog(1000,"NewSendToIO:read SOF from MemFile error!",
                 RPT_TO_LOG,0,0);
          UCP_TRACE_END(-99);
        }
        pcMemBufPt=(char *)g_caMemBuf;
      }
      else {
        iSofDataLen=(unsigned char)pcMemBufPt[SOF_DATA_LEN_OFFSET]*256 +
                    (unsigned char)pcMemBufPt[SOF_DATA_LEN_OFFSET+1];
      }

      /* access control byte from SOF header */
      memcpy(caSofCtlData,&pcMemBufPt[SOF_CTL_CODE_OFFSET],SOF_CTL_CODE_SIZE);

      if ( iCtlFlowFlag == '1' ) {

        if ( cFirstCtlDataFlag == '1'){
          memcpy(caFirstSofCtlData, caSofCtlData, SOF_CTL_CODE_SIZE );
          cFirstCtlDataFlag = '0';
        }

/* --------------------------------------------------------------------- */
        if ( pfConvOutPgm != NULL ) {
          iRc=(*pfConvOutPgm)(pcMemBufPt,caCnvOutBuff,iSofDataLen+SOF_HEAD_LEN_PLUS_2);
          if (iRc < 0) {
            sprintf( g_caMsg, "NewSendToIO: Output convert error!" );
            ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
            UCP_TRACE_END( CONVERT_OUT_ERR );
          }
          /* send TPU Sof to DBP */
          iRc=TmsDataSend(iRc, caCnvOutBuff,cMoreData,&iDcsRtnCode);
        }
        else {
          /* send TPU Sof to DBP */
          iRc=TmsDataSend(iSofDataLen+SOF_HEAD_LEN_PLUS_2,
                        pcMemBufPt,cMoreData,&iDcsRtnCode);
        }
/* --------------------------------------------------------------------- */
        if (iRc < 0) {
          sprintf(g_caMsg,"NewSendToIO:TmsDataSend() error iRc = %d",iRc);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          UCP_TRACE_END ( TMS_DATA_SEND_ERR );
        }  /* if (iRc < 0)*/

        if ( caSofCtlData[0] & LAST_MSG_MASK ) {

          iCtlFlowFlag = '0';
          if ( !(caFirstSofCtlData[0] & TPEO_MSG_MASK) ){
            break; /* exit while loop */
          }

          /* receive TPEO From DBP */
          iRc = GetAck(caAckBuf, &iDcsRtnCode,sizeof(caAckBuf));
          if (iRc < 0) {
	    sprintf(g_caMsg,"NewSendToIO:Get First Ack error iRc = %d",iRc);
            ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
	    UCP_TRACE_END ( GET_ACK_ERR );
 	  }  /* if (iRc < 0)*/

          if ( memcmp(caAckBuf, "TPEO", 4) != 0 ) {
	    sprintf(g_caMsg,"NewSendIoIO:First ACK=[%.4s] error!",caAckBuf);
	    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
	    UCP_TRACE_END ( FIRST_ACK_ERR );
          }

        }/* end of "if ( caSofCtlData & LAST_MSG_MASK ) " */

        iMemBufOffset = iMemBufOffset + iSofDataLen + SOF_HEAD_LEN_PLUS_2;

      }
      else {

/* --------------------------------------------------------------------- */
        if ( pfConvOutPgm != NULL ) {
          iRc=(*pfConvOutPgm)(pcMemBufPt,caCnvOutBuff,iSofDataLen+SOF_HEAD_LEN_PLUS_2);
          if (iRc < 0) {
            sprintf( g_caMsg, "NewSendToIO: Output convert error!" );
            ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
            UCP_TRACE_END( CONVERT_OUT_ERR );
          }
          /* send TPU Sof to DBP */
          iRc=TmsDataSend(iRc, caCnvOutBuff,cMoreData,&iDcsRtnCode);
        }
        else {
          /* send TPU Sof to DBP */
          iRc=TmsDataSend(iSofDataLen+SOF_HEAD_LEN_PLUS_2,
                        pcMemBufPt,cMoreData,&iDcsRtnCode);
        }
/* --------------------------------------------------------------------- */
        if (iRc < 0) {
          sprintf(g_caMsg,"NewSendToIO:TmsDataSend() error, iRc = %d",iRc);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          UCP_TRACE_END ( TMS_DATA_SEND_ERR );
        }  /* if (iRc < 0)*/

        if ( caSofCtlData[0] & LAST_MSG_MASK ){
          break; /* exit while loop */
        }

        /* receive ACK From DBP */
        iRc = GetAck(caAckBuf, &iDcsRtnCode,sizeof(caAckBuf));
        if (iRc < 0) {
          sprintf(g_caMsg,"NewSendToIO:Get Other Ack error, iRc = %d",iRc);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          UCP_TRACE_END ( GET_ACK_ERR );
        }  /* if (iRc < 0)*/

        if ( caAckBuf[0] != '\0') {
          sprintf(g_caMsg,"NewSendToIO:Other ACK error=[%2x]",caAckBuf[0]);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          UCP_TRACE_END ( OTHER_ACK_ERR );
        }

        iMemBufOffset = iMemBufOffset + iSofDataLen + SOF_HEAD_LEN_PLUS_2;

     }

    } /* while(cLoopFlag == 'y') */
  } /* TPEI/TPEO transmit protocol */

  /*
   * Clear TBA.caMsgp AREA when txn ends
   */
  memset(g_pstTba->caMsgp,'\0',sizeof(struct MsgBufCtlSt));

  
  if( g_iMemFileFd > 0) {
    iRc=close(g_iMemFileFd);
    g_iMemFileFd=-1;
    if(iRc < 0) {
      sprintf(g_caMsg,"NewSendToIO:close file(g_iMemFileFd) error=%d",errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END ( -99 );
    }
  }

  UCP_TRACE_END ( 0 );

}  /* NewSendToIO() */

int
FlushMsgpToFile(int iFlushSize)
{
  int iFd,iRc;
  char caMsgpFileName[80];

  memset(caMsgpFileName,'\0',80);
  sprintf(caMsgpFileName,"%s/%s%.*s.%.*s",getenv("III_DIR"),MSGP_PREFIX,
          g_iTmCodeLen, g_pstTma->stTSSA.caTmCode,g_iBrhCodeLen, 
          g_pstTma->stTSSA.caBrCode);

  if ((iFd = open(caMsgpFileName,O_RDWR|O_CREAT|O_TRUNC,0666)) == -1) {
    sprintf(g_caMsg,"FlushMsgpToFile() :open %s error! errno=%d",caMsgpFileName,errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    return ( -1 );
  }
  
  /*begin: added by pjw for tu990513       1999 6 10*/
  if (iFd == 0){
    if ((iFd = open(caMsgpFileName,O_RDWR|O_CREAT|O_TRUNC,0666)) == -1) {
      sprintf(g_caMsg,"FlushMsgpToFile() :open %s error! errno=%d",caMsgpFileName,errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      return ( -1 );
    }
     close(0);
  } 
  /*end: added by pjw for tu990513       1999 6 10*/

  iRc=WriteFile(iFd,0,g_pstTba->caMsgp,iFlushSize);
  if(iRc < 0) {
    sprintf(g_caMsg,"FlushMsgpToFile() :WriteFile() error!");
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    close(iFd);
    return ( -2 );
  }

  return ( iFd );
}

MemWrite(char *pcBuf, int iBufLen, int iMsgCnt)
{
  int iRc;
  struct  MemBufCtlSt *pstMemBufCtl;
  
  UCP_TRACE(P_MemWrite);
  pstMemBufCtl = (struct MemBufCtlSt *)&g_stMemBufCtl ;

  if( g_iMemFileFd < 0 ) {
    if ( ( (pstMemBufCtl->iNextOffset)+iBufLen ) > sizeof(g_caMemBuf) ){
      sprintf(g_caMsg, "MemWrite:write data length=%d plus iNextOffset=%d over sizeof(g_caMemBuf)=%d", iBufLen, pstMemBufCtl->iNextOffset, sizeof(g_caMemBuf) );
      ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
      iRc=FlushMemToFile(pstMemBufCtl->iNextOffset);
      if(iRc < 0) {
        sprintf(g_caMsg,"MemWrite() :FlushMemToFile() error!");
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END(-1);
      }
      g_iMemFileFd=iRc;
    }
  }
  
  if(g_iMemFileFd > 0) {
    iRc=WriteFile(g_iMemFileFd,pstMemBufCtl->iNextOffset,pcBuf,iBufLen);
    if(iRc < 0) {
      sprintf(g_caMsg,"MemWrite() :WriteFile() error!");
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(-2);
    }
  }
  else {
    memcpy(g_caMemBuf+(pstMemBufCtl->iNextOffset), pcBuf, iBufLen);
  }
    
  pstMemBufCtl->iNextOffset += iBufLen;
  pstMemBufCtl->iMsgCnt += iMsgCnt;

  UCP_TRACE_END(iBufLen);
  
}

int
MemClose()
{
  int iRc;

  if(g_iMemFileFd > 0) {
    iRc=WriteFile(g_iMemFileFd,0,&g_stMemBufCtl,sizeof(struct MemBufCtlSt));
    if(iRc < 0) {
      ErrLog(1000,"MemClose:write stMsgBufCtl to MemFile error!",
      RPT_TO_LOG,0,0);
      return(-99);
    }
    iRc=close(g_iMemFileFd);
    g_iMemFileFd=-1;
    if(iRc < 0) {
      sprintf(g_caMsg,"MemClose:close MemFile error! errno=%d",errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      return(-99);
    }
    g_cFlushMemToFileFlag='y';
  }
  return(0);
}


int
FlushMemToFile(int iFlushSize)
{
  int iFd,iRc;
  char caMemFileName[256];

  memset(caMemFileName,'\0',256);
  sprintf(caMemFileName,"%s/%s%.*s.%.*s",getenv("III_DIR"),OUTPT_PREFIX,
          g_iTmCodeLen, g_pstTma->stTSSA.caTmCode,g_iBrhCodeLen, 
          g_pstTma->stTSSA.caBrCode);

  if ((iFd = open(caMemFileName,O_RDWR|O_CREAT|O_TRUNC,0666)) == -1) {
    sprintf(g_caMsg,"FlushMemToFile() :open %s error! errno=%d",caMemFileName,errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    return ( -1 );
  }
  
  iRc=WriteFile(iFd,0,g_caMemBuf,iFlushSize);
  if(iRc < 0) {
    sprintf(g_caMsg,"FlushMemToFile() :WriteFile() error!");
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    close(iFd);
    return ( -2 );
  }

  return ( iFd );
}

int
WriteFile(int iFd,int iFileOffset,char *pcData,int iSize)
{
  int iRc;

  if ((lseek(iFd,iFileOffset,0)) < 0) {
    sprintf(g_caMsg,"WriteFile() :lseek to Offset=%d error!, errno=%d",
            iFileOffset,errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    return(-1);
  }

  if ((iRc=write(iFd,pcData,iSize)) != iSize) {
    sprintf(g_caMsg,"WriteFile() :write size=%d,actual write size=%d!errno=%d",
            iSize,iRc,errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    return(-2);
  } 

  return(0);
}

int
ReadFile(int iFd,int iFileOffset,char *pcData,int iSize)
{
  int iRc;

  if ((lseek(iFd,iFileOffset,0)) < 0) {
    sprintf(g_caMsg,"ReadFile() :lseek to Offset=%d error!, errno=%d",
            iFileOffset,errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    return(-1);
  }

  if ((iRc=read(iFd,pcData,iSize)) != iSize) {
    sprintf(g_caMsg,"ReadFile() :read size=%d,actual read size=%d,errno=%d",
            iSize,iRc,errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    return(-2);
  } 

  return(0);
}

PrepareHostToBrhInfo()
{
}

int
OpenOutputFile()
{
  int iFd;
  char caMemFileName[256];

  memset(caMemFileName,'\0',256);
  sprintf(caMemFileName,"%s/%s%.*s.%.*s",getenv("III_DIR"),OUTPT_PREFIX,
          g_iTmCodeLen, g_pstTma->stTSSA.caTmCode,g_iBrhCodeLen, 
          g_pstTma->stTSSA.caBrCode);

  if ((iFd = open(caMemFileName,O_RDONLY)) == -1) {
    sprintf(g_caMsg,"OpenOutputFile() :open %s error! errno=%d",caMemFileName,errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    return ( -1 );
  }

  return ( iFd );
}
/* ****************** End of tpu.c Program ******************* */
