
/*
 *&N&
 *&N&                     �D�y�{�ҲդQ��<�������>��ƩI�s���Y��
 *&N&
 *&N& -----------------------------------------------------------------------
 *&N&
 *&N&                                ����B�z
 *&N&                          �z�w�w�w�w�w�w�w�w�w�{
 *&N&                       12.�x    TxEnd()       �x
 *&N&                          �|�w�w�w�w�s�w�w�w�w�}
 *&N&                                    �x
 *&N&                                    �x
 *&N&      �z�w�w�w�w�w�w�w�w�w�w�s�w�w�w�q�w�w�w�s�w�w�w�s�w�w�w�w�{
 *&N&      �x  13.          14.  �x      �x  15. �x      �x   16.  �x
 *&N&  �z�w�r�w�w�w�w�w�w�{�z�w�w�r�w�w�{�x�z�w�w�r�w�w�{�x  �z�w�w�r�w�w�{
 *&N&  �xSetTmaByApaOut()�x�xReinput() �x�x�xTxRollBk()�x�x  �xInLgRlBk()�x
 *&N&  �|�w�w�w�w�w�w�w�w�}�|�w�w�s�w�w�}�x�|�w�w�w�w�w�}�x  �|�w�w�w�w�w�}
 *&N&                            �x      �x      �z�w�w�w�r�w�w�w�w�{
 *&N&                      �z�w�w�r�w�w�{�x   26.�xSetRevFlagOff() �x
 *&N&                     #�xCtfToSif  �x�x      �|�w�w�w�w�w�w�w�w�}
 *&N&                      �|�w�w�w�w�w�}�x
 *&N&                                    �x
 *&N&                                    �x
 *&N&      �z�w�w�w�w�w�w�w�w�w�w�s�w�w�w�r�w�w�w�{
 *&N&      �x 17.            18. �x          19. �x
 *&N&  �z�w�r�w�w�w�{      �z�w�w�r�w�w�{  �z�w�w�r�w�w�w�{
 *&N&  �xDbsTxEnd()�x      �xTxSeqMtn()�x  �x TxOutput() �x
 *&N&  �|�w�w�w�w�w�}      �|�w�w�w�w�w�}  �|�w�w�w�w�w�w�}
 *&N&
*/

/*
 *&N& File : tmsend.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE      NAME                 DESCRIPTION
 *&N& --------- ---------- ----------------------------------------
 *&N&    int      TxEnd           ����������
 *&N&    int      Reinput         �e���s�ʨ��
 *&N&    int      IsTxnEnd        �P�_�O�_���������
 *&N&    int      TxSeqMtn        ����y���������@���
 *&N&    int      TxOutput        ������G��X���
 *&N&    int      SetRevFlagOff   �N�R���X�г]�w��OFF�C
 */

/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include "cwa.h"        /* �w�q CWA �ҨϥΨ쪺��Ƶ��c�α`�� */
#include "twa.h"        /* �w�q TWA �ҨϥΨ쪺��Ƶ��c�α`�� */
#include "tms.h"        /* �w�q tms �t�ΨϥΨ쪺��Ƶ��c�α`�� */
#include "errlog.h"     /* �O�����~�T���ɨϥΨ쪺�`�Ƥθ�Ƶ��c */
#include "tmcend.h"     /* �O�����~�T���ɨϥΨ쪺�`�� */
#include "ucp.h"
#include "tmcpgdef.h"	/* TMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */

/* -------------------- CONSTANT DEFINE  --------------------------- */
/*
#define P_TxEnd                 27001
#define P_Reinput               27002
#define P_TxSeqMtn              27003
#define P_TxOutput              27004
#define P_IsTxnEnd              27005
#define P_SetRevFlagOff         27006
*/

#define RCV_ERR                 '0'
#define RCV_OK                  '1' 

#define COMMIT_FLAG             '0' 
#define ROLLBACK_FLAG           '1'

#define  REENTRY_TM             '9'
/* To avoid duplication of txn seq. no of the same terminal -- BEGIN */ 
extern char g_cNeedRelseTrm;
/* To avoid duplication of txn seq. no of the same terminal -- END */ 

/* PTM TPEUNIX980510 : add 1 line by Hu Chunlin, June 1st, 1998 */
extern int g_iTmaTermno;

/* -------------------- STATIC GLOBAL DECLARATION ------------------ */
extern struct TMA *g_pstTma;    /* point TWA.TMA��ưϪ������ܼ� */
extern struct TBA *g_pstTba;    /* point TWA.TBA��ưϪ������ܼ� */
extern struct APA *g_pstApa;
extern char g_cErrActFlag;
extern int g_iBrhCodeLen;
extern int g_iTmCodeLen ;
extern int g_iTxnCodeLen;       /* Txn code real length          */
extern char g_cRcvRmtDataFlag;  /* indicate rcv rmt data OK or not? */
extern int  g_iTotLogCntPerTxn;
extern char g_cOnBthTxn;  /* 1995/03/31 */
extern char g_cApRtnCode;       /* record the return code of AP       */
extern char g_caReinputBuffer[MAX_SIF_LEN + SOF_HEAD_LEN_PLUS_2];

/* ------ CALL FUNCTION & SUBROUTINE PROTOTYPE DECLARATIONS -------- */
int TxEnd();
int SetRevFlagOff();
int Reinput();
int IsTxnEnd();
int TxSeqMtn();
int TxOutput();

extern int SetTmaByApaOut();
extern int DbsTxEnd();
extern int CtfToSif();             
extern int IsMultipleEnd();    
extern int IsListEnd();      
extern int NewTxEndInform();
extern int NewSendToIO();
extern int AddSofHeadToSif();
extern int TrmRelease();

/*
 *&N& ROUTINE NAME: TxEnd()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                 DESCRIPTION
 *&A& ---------  ---------------------    -------------------------
 *&A& pcErrStep    char *           
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&    < 0      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& ���槹AP��,���NAP�Ҳ��ͪ����G,�i��B�z�C
 *&D& �@�B�ھ�TWA.APA,�]�wTWA.TMA���ȡC
 *&D& �G�B�ˬdAP���G�O�_�����`�����C
 *&D& �T�B�pAP�������`����,�h�i�����^�_�B�z�MLOG���_��B�z�C
 *&D& �|�B�P�_AP�O�_�i���J�e���s�ʡC
 *&D& ���B�pAP�n�D�i���J�e���s��,�h�i��e���s�ʸ�ƷǳơC
 *&D& ���B�P�_��AP���槹, �O�_����w�����C
 *&D& �C�B�p���������, �h�]�w��������I�C
 *&D& �K�B�p������w����, �h�i�����Ǹ����@�C
 *&D& �E�B�p������w����, �h�]�w�R���X��OFF�C
 *&D& #�Q�B�p������w����, �h�e�X����T��,�q���Ұʥ���̡C
 *&D& #�Q�@�B�p������w����, �h�����X��ƷǳơC
 *&D& #�Q�G�B�p������w����, �h��X��ƶǰe�C
 */

int
TxEnd(char *pcErrStep)
{
  int iRc;
  int iTxnStatus;

  UCP_TRACE(P_TxEnd);
  *pcErrStep = '0';
  PrepareHostToBrhInfo();
  iRc = SetTmaByApaOut();
  /* added by WuChihLiang 19950317 for JCL -- BEGIN */
  if (g_pstTma->stTSSA.cSysMode != ONLINE_MODE ) {
    g_pstTma->stTCFA.cBatApRtnCode = g_pstTma->stTCFA.cApReturnCode;
  }
  /* added by WuChihLiang 19950317 for JCL -- END   */

  /*
   * �Ѩt�ΨӦ۰ʱ���R���y�{
   */
  if ( g_pstTma->stTCFA.cRevTxn == TMS_TXN_REVERSE && 
       g_pstTma->stTCFA.cRevContinue == TMS_REV_CONTINUE_ON ) {
    g_pstTma->stTCFA.cRendoRequest = TMS_TXN_RENDO;
  }

/**
  iRc = SysWrtLogForAp();
  if ( iRc < 0 ) {
    *pcErrStep = '2';
    ErrLog(1000,"TxEnd: SysWrtLogForAp() fail!",RPT_TO_LOG,0,0);
    UCP_TRACE_END(SYS_WRT_LOG_ERR);
  }
**/

  iRc = IsTxnEnd();
  iTxnStatus = iRc ;
  switch(iRc) {
    case TXN_ERROR_ROLLBK:

      if ( g_cRcvRmtDataFlag == RCV_ERR ) {
        g_cApRtnCode=g_pstTma->stTCFA.cApReturnCode;
        iRc = NewTxEndInform( g_pstTma->stTCFA.cApReturnCode , 
              g_pstTma->stTCFA.cTxnReinput, g_pstTma->stTSSA.caTmCode 
              , g_pstTma->stTSSA.caBrCode);

        /*
         * Reset the cTpeWriteMsgKind flag to TMS_RCV_AP_NORMAL_MSG
         */
        g_pstTma->stTCFA.cTpeWriteMsgKind  = TMS_RCV_AP_NORMAL_MSG;
        /*
         * Reset the cReentryStatus flag to TMS_TXN_NOT_REENTRY
         */
        g_pstTma->stTSSA.cReentryStatus  = TMS_TXN_NOT_REENTRY;

        if (iRc < 0) {
          *pcErrStep = '2';
          ErrLog(1000,"TxEnd: NewTxEndInform fail!",RPT_TO_LOG,0,0);
          UCP_TRACE_END(iRc);
        }
      }

      iRc = DbsTxEnd( ROLLBACK_FLAG );

      if (iRc < 0) {
        *pcErrStep = '3';
        ErrLog(1000,"TxEnd: DbsTxEnd(ROLLBACK_FLAG) fail!",RPT_TO_LOG,0,0);
        UCP_TRACE_END( END_TXN_ERR );
      }

      /*
       * cBitCtlFalg is set to OFF (i.e.  already ends txn )
       */
       g_cErrActFlag &= (~DO_ROLLBACK_FLAG);

      /* �p�󪾹D�O�ݩ�@�������~LOG��MARK�B�ΨR��AP�s�ʪ�AP�o�Ϳ��~TPU */
      /* �t�d�NLOG UNMARK�B�Τ@�s��s��AP��LOG��MARK�����p�C              */
      iRc = InLgRlBk();

      if (iRc < 0) {
        *pcErrStep = '4';
        ErrLog(1000,"TxEnd: InLgRlBk fail!",RPT_TO_LOG,0,0);
        UCP_TRACE_END(iRc);
      }

/* To avoid duplication of txn seq. no of the same terminal -- BEGIN */ 
      iRc = TrmRelease();
      if (iRc < 0) {
        *pcErrStep = '5';
        ErrLog(1000,"TxEnd: TrmRelease fail!",RPT_TO_LOG,0,0);
        UCP_TRACE_END(iRc);
      }
      g_cNeedRelseTrm = 'n';
/* To avoid duplication of txn seq. no of the same terminal -- END */ 
      break;

    case TXN_ERROR_COMMIT:
    case TXN_OVER:
      if ( (g_pstTma->stTCFA.cApReturnCode == TMS_AP_ACC_NORMAL ||
            g_pstTma->stTCFA.cApReturnCode == TMS_AP_NON_ACC_NORMAL) &&
           (g_pstTma->stTCFA.cTxnReinput == TMS_TXN_REINPUT_ON ) ) {
        iRc = Reinput();

        if (iRc < 0) {
          *pcErrStep = '7';
          ErrLog(1000,"TxEnd: Reinput fail!",RPT_TO_LOG,0,0);
          UCP_TRACE_END(iRc);
        }

      }  /* AP�n�D��J�e���s�� */

      if ( g_cRcvRmtDataFlag == RCV_ERR ) {
        g_cApRtnCode=g_pstTma->stTCFA.cApReturnCode;
        iRc = NewTxEndInform( g_pstTma->stTCFA.cApReturnCode , 
              g_pstTma->stTCFA.cTxnReinput, g_pstTma->stTSSA.caTmCode 
              , g_pstTma->stTSSA.caBrCode);

        /*
         * Reset the cTpeWriteMsgKind flag to TMS_RCV_AP_NORMAL_MSG
         */
        g_pstTma->stTCFA.cTpeWriteMsgKind  = TMS_RCV_AP_NORMAL_MSG;
        /*
         * Reset the cReentryStatus flag to TMS_TXN_NOT_REENTRY
         */
        g_pstTma->stTSSA.cReentryStatus  = TMS_TXN_NOT_REENTRY;

        if (iRc < 0) {
          *pcErrStep = '2';
          ErrLog(1000,"TxEnd: NewTxEndInform fail!",RPT_TO_LOG,0,0);
          UCP_TRACE_END(iRc);
        }
      }

      iRc = DbsTxEnd( COMMIT_FLAG );

      if (iRc < 0) {
        *pcErrStep = '5';
        ErrLog(1000,"TxEnd: DbsTxEnd(COMMIT_FLAG) fail!",RPT_TO_LOG,0,0);
        UCP_TRACE_END(iRc);
      }

      /*
       * cBitCtlFalg is set to OFF (i.e.  already ends txn )
       */
      g_cErrActFlag &= (~DO_ROLLBACK_FLAG);

      if (g_pstTma->stTSSA.cSysMode == ONLINE_MODE ) {

        iRc = TxSeqMtn();
        if (iRc < 0) {
          *pcErrStep = '6';
          ErrLog(1000,"TxEnd: TxSeqMtn fail!",RPT_TO_LOG,0,0);
          UCP_TRACE_END(iRc);
        }
      }

/* To avoid duplication of txn seq. no of the same terminal -- BEGIN */ 
      iRc = TrmRelease();
      if (iRc < 0) {
        *pcErrStep = '7';
        ErrLog(1000,"TxEnd: TrmRelease fail!",RPT_TO_LOG,0,0);
        UCP_TRACE_END(iRc);
      }
      g_cNeedRelseTrm = 'n';
/* To avoid duplication of txn seq. no of the same terminal -- END */ 
      break;

    case TXN_NOT_OVER:
      /* PTM TPEUNIX980510 : add 1 line by Hu Chunlin, June 1st, 1998 */
      g_iTmaTermno = 1;
      UCP_TRACE_END(0);

    default:
      *pcErrStep = '1';
      ErrLog(1000,"TxEnd: IsTxnEnd rtn code error!",RPT_TO_LOG,0,0);
      UCP_TRACE_END( iRc );

  }  /* end switch */

  /* �N�R��FLAG�]�wOFF */
  iRc = SetRevFlagOff();

  UCP_TRACE_END( iTxnStatus );
}


/*
 *&N& ROUTINE NAME: SetRevFlagOff()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                 DESCRIPTION
 *&A&   ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& �N�R���X�г]�w��OFF�C
 *&D&
 */

int
SetRevFlagOff()
{
  UCP_TRACE(P_SetRevFlagOff);
  g_pstTma->stTCFA.cRevTxn = TMS_TXN_NOT_REVERSE;
  UCP_TRACE_END(0);
}

/*
 *&N& ROUTINE NAME: Reinput()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                 DESCRIPTION
 *&A&   ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&    < 0    : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& �I�sCtfToSif()��ƥH�K�NCTF�ഫ��SIF�C
 *&D&
 */

int
Reinput()
{
  int iRc;
  char caTxnCode[ MAX_TXN_LEN + 1];

  UCP_TRACE(P_Reinput);
  memcpy(caTxnCode, g_pstTba->caCtf, g_iTxnCodeLen);
  memset(g_pstTba->caRendo, 0, MAX_SIF_LEN);
  iRc = CtfToSif(CTF_TYPE,caTxnCode, g_pstTba->caCtf, g_pstTba->caRendo);
/*
  ErrLog(100,"Reinput: TBA.caRendo=",RPT_TO_LOG,g_pstTba->caRendo,MAX_SIF_LEN);
*/

  if (iRc < 0) {
    ErrLog(1000,"Reinput: CtfToSif() fail!",RPT_TO_LOG,0,0);
    UCP_TRACE_END(iRc);
  }

  memcpy(g_caReinputBuffer,g_pstTba->caRendo,MAX_SIF_LEN);
  memset(g_pstTba->caRendo,'\0',MAX_SIF_LEN);
  iRc = AddSofHeadToSif(g_caReinputBuffer,g_pstTma->stTSSA.caBrCode,
                        g_pstTma->stTSSA.caTmCode, iRc);
  if (iRc < 0) {
    ErrLog(1000,"Reinput: AddSofHeadToSif() fail!",RPT_TO_LOG,0,0);
    UCP_TRACE_END(iRc);
  }

  memcpy(&g_pstTba->caRendo[SOF_HEAD_LEN_PLUS_2], SIF_FMT_1, SIF_FMT_LEN);

  UCP_TRACE_END(0);
}



/*
 *&N& ROUTINE NAME: IsTxnEnd()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                 DESCRIPTION
 *&A&   ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ���������(�]AP�n�D�s��)
 *&R&    1      : ����w����
 *&R&    2      : ������~�B���@ROLLBK���n�UCOMMIT
 *&R&    3      : ������~�B�@ROLLBACK
 *&R&  RENDO_REQUEST_ERR    :  No Such RendoRequest 
 *&R&  INPUT_TXN_TYPE_ERR   :  No Such InDataType 
 *&R&  AP_ABEND_NO_RLBK_ERR :  No Such ApAbendNoRlbk 
 *&R&
 *&D& DESCRIPTION:
 *&D& �̾�TMA.cApReturnCode�BTMA.cApAbendNoRlbk�B
 *&D& TMA.cInDataType�BTMA.cRendoRequest�P�_����O�_�UCOMMIT�Χ@ROLLBK�C
 *&D&
 */

int
IsTxnEnd()
{
  int iRc;

  UCP_TRACE(P_IsTxnEnd);

  switch(g_pstTma->stTCFA.cApReturnCode) {

    case TMS_AP_NON_ACC_NORMAL:
    case TMS_AP_ACC_NORMAL:

      switch (g_pstTma->stTCFA.cRendoRequest) {

        case TMS_TXN_NOT_RENDO:

          switch(g_pstTma->stTCFA.cInDataType) {

            case LIST_TXN:
              UCP_TRACE_END(IsListEnd());

            case MULTIPLE_TXN:
              UCP_TRACE_END(IsMultipleEnd());

            case GENERAL_TXN:
            case COOPERATIVE_TXN:
              UCP_TRACE_END(TXN_OVER);

            default:
              sprintf(g_caMsg,"IsTxnEnd: no such cInDataType !");
              ErrLog(INPUT_TXN_TYPE_ERR,g_caMsg,RPT_TO_LOG,0,0);
              DetErrRpt(INPUT_TXN_TYPE_ERR,"IsTxnEnd: no such cInDataType!");
              UCP_TRACE_END(INPUT_TXN_TYPE_ERR);

          }

          break;

        case TMS_TXN_RENDO:     
          UCP_TRACE_END(TXN_NOT_OVER);

        default:
          sprintf(g_caMsg,"IsTxnEnd: no such cRendoRequest !");
          ErrLog(RENDO_REQUEST_ERR,g_caMsg,RPT_TO_LOG,0,0);
          DetErrRpt(RENDO_REQUEST_ERR,"IsTxnEnd: no such cRendoRequest !");
          UCP_TRACE_END(RENDO_REQUEST_ERR);

      }

      break;

    /* another AP return code  is treated as <case TMS_AP_ABEND>    */
    default:

      switch(g_pstTma->stTCFA.cApAbendNoRlbk) {

        case TMS_TXN_ABEND_NORLBK_ON:
          UCP_TRACE_END( TXN_ERROR_COMMIT );

        default:
          UCP_TRACE_END( TXN_ERROR_ROLLBK );

/* ----- Mark 1994/09/24 , default values is ABEND_NORLBK_OFF -----------
        default:
          sprintf(g_caMsg,"IsTxnEnd: no such cApAbendNoRlbk code!");
          ErrLog(AP_ABEND_NO_RLBK_ERR ,g_caMsg,RPT_TO_LOG,0,0);
          DetErrRpt(AP_ABEND_NO_RLBK_ERR ,
                    "IsTxnEnd: no such cApAbendNoRlbk code!");
          UCP_TRACE_END( AP_ABEND_NO_RLBK_ERR );
*/
      }  

  }

}


/*
 *&N& ROUTINE NAME: TxSeqMtn()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                 DESCRIPTION
 *&A&   ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   < 0     : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& �ھ�TMA.caNonAccSeqNo�BTMA.caAccSeqNo�ӳ]�wCWA.SSA��caTotalTxnCnt
 *&D& �MCWA.TCT��caAccTxnCnt�BcaNonAccTxnCnt�C
 */

int
TxSeqMtn()
{
  int iRc;
  int iTotalTxnCnt;
  struct CwaCtl stCwaCtl;
  char *pcTerm;
  struct TermArea *pstTct;
  struct SSA    *pstSsa;
  char          *pcDummy;

  UCP_TRACE(P_TxSeqMtn);
  stCwaCtl.cFunCode = CWA_SEG_LOCK;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcDummy);

  if (iRc != CWA_NORMAL) {
    ErrLog(1000,"TxSeqMtn: CwaCtlFac lock SSA fail!",RPT_TO_LOG,0,0);
    UCP_TRACE_END( LOCK_SSA_ERR );
  }

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);

  if (iRc != CWA_NORMAL) {
    ErrLog(1000,"TxSeqMtn: CwaCtlFac get SSA ptr fail!",RPT_TO_LOG,0,0);

/*begin:add by pjw for TU995002                 1999 6 10 */
    stCwaCtl.cFunCode = CWA_SEG_UNLOCK;
    stCwaCtl.cSegCode = CWA_SEG_SSA;
    iRc = CwaLowCtlFac(&stCwaCtl,&pcDummy);

    if (iRc != CWA_NORMAL) {
        ErrLog(1000,"TxSeqMtn: CwaCtlFac unlock SSA fail!",RPT_TO_LOG,0,0);
        UCP_TRACE_END( UNLOCK_SSA_ERR );
    }
/*end: add by pjw for TU995002                 1999 6 10 */

    UCP_TRACE_END( GET_SSA_PTR_ERR );
  }

  /* ---------------------------------------------------------------------- */
  /*                �t�Ϊ� Total Txn Count �[ 1                             */
  /* ---------------------------------------------------------------------- */
  pstSsa->lTotalTxnCnt++;

  stCwaCtl.cFunCode = CWA_SEG_UNLOCK;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcDummy);

  if (iRc != CWA_NORMAL) {
    ErrLog(1000,"TxSeqMtn: CwaCtlFac unlock SSA fail!",RPT_TO_LOG,0,0);
    UCP_TRACE_END( UNLOCK_SSA_ERR );
  }

  stCwaCtl.cFunCode = CWA_SEG_LOCK;
  stCwaCtl.cSegCode = CWA_SEG_BIT_BRH;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcDummy);

  if (iRc != CWA_NORMAL) {
    ErrLog(1000,"TxSeqMtn: CwaCtlFac lock TCT fail!",RPT_TO_LOG,0,0);

/*begin:add by pjw for TU995002                 1999 6 10 */
    stCwaCtl.cFunCode = CWA_SEG_UNLOCK;
    stCwaCtl.cSegCode = CWA_SEG_BIT_BRH;
    iRc = CwaLowCtlFac(&stCwaCtl,&pcDummy);

    if (iRc != CWA_NORMAL) {
        ErrLog(1000,"TxSeqMtn: CwaCtlFac unlock TCT fail!",RPT_TO_LOG,0,0);
        UCP_TRACE_END( UNLOCK_TCT_ERR );
    }
/*end:add by pjw for TU995002                 1999 6 10 */

    UCP_TRACE_END( LOCK_TCT_ERR );
  }

  stCwaCtl.cFunCode = CWA_GET_TERM_PTR;
  memcpy(stCwaCtl.caBrhId, g_pstTma->stTSSA.caBrCode, g_iBrhCodeLen);
  memcpy(stCwaCtl.caTermId,g_pstTma->stTSSA.caTmCode, g_iTmCodeLen);
  iRc = CwaLowCtlFac(&stCwaCtl,&pcTerm);

  if (iRc != CWA_NORMAL) {
    ErrLog(1000,"TxSeqMtn: CwaCtlFac get TCT ptr fail!",RPT_TO_LOG,0,0);
    UCP_TRACE_END( GET_TCT_PTR_ERR );
  }

  pstTct = (struct TermArea *) pcTerm;

  sprintf(g_caMsg,"<APD>TXN END: TX=%.*s BR=%.*s TM=%.*s AC=%.5d NAC=%.5d,OFFLN=%.5d",g_iTxnCodeLen,g_pstTma->stTSSA.caTxnCode,g_iBrhCodeLen,g_pstTma->stTSSA.caBrCode,g_iTmCodeLen,g_pstTma->stTSSA.caTmCode,g_pstTma->stTSSA.lAccTxnSeqNo,g_pstTma->stTSSA.lNonAccTxnSeqNo,g_pstTma->stTSSA.lBtchTxnSeqNo);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  /* ---------------------------------------------------------------------- */
  /*             ��s CWA.TCT���b�ȩʡB�D�b�ȩʬy����                       */
  /* ---------------------------------------------------------------------- */

  /* --- background txn , system don't update following SeqNo. ---- */
  if ( g_cOnBthTxn != 'y' ) {
    pstTct->lNonAccTxnNo = g_pstTma->stTSSA.lNonAccTxnSeqNo;
    pstTct->lAccTxnNo = g_pstTma->stTSSA.lAccTxnSeqNo;
    if (g_pstTma->stTSSA.cTmType != REENTRY_TM){
      pstTct->lBtchTxnNo = g_pstTma->stTSSA.lBtchTxnSeqNo;
    }
  }

/*
  sprintf(g_caMsg,"@@@ A: TX=%.4s BR=%.7s TM=%.2s AC=%.5d NAC=%.5d OFFLN=%.5d",
          g_pstTma->stTSSA.caTxnCode,g_pstTma->stTSSA.caBrCode,
          g_pstTma->stTSSA.caTmCode,
          pstTct->lAccTxnNo,pstTct->lNonAccTxnNo,pstTct->lBtchTxnNo);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
*/

  stCwaCtl.cFunCode = CWA_SEG_UNLOCK;
  stCwaCtl.cSegCode = CWA_SEG_BIT_BRH;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcDummy);

  if (iRc != CWA_NORMAL) {
    ErrLog(1000,"TxSeqMtn: CwaCtlFac unlock TCT fail!",RPT_TO_LOG,0,0);
    UCP_TRACE_END( UNLOCK_TCT_ERR );
  }

  UCP_TRACE_END( 0 );
}


/*
 *&N& ROUTINE NAME: TxOutput()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                 DESCRIPTION
 *&A&   ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&    < 0    : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& �H�׺ݾ��N�X���Ѽ�,�I�sNewSendToIO()���N����X����ưe��ݥ��C
 *&D&
 */
int
TxOutput( char *pcErrStep )
{
  int iRc;

  UCP_TRACE(P_TxOutput);
  *pcErrStep = '0';
  if ((g_cOnBthTxn != 'y')&&(g_pstTma->stTCFA.cTxnPattern != COOPERATIVE_TXN)){
    iRc = NewSendToIO(g_pstTma->stTSSA.caTmCode ,g_pstTma->stTSSA.caBrCode);

    if (iRc < 0) {
      *pcErrStep = '1';
      ErrLog(1000,"TxOutput: NewSendToIO fail !",RPT_TO_LOG,0,0); 
      UCP_TRACE_END(iRc);
    }
  }
  else {
    /*
     * Clear TBA.caMsgp AREA when onbth txn ends, prevent from onbth AP
     * to call TPEWRITE. added by chi-fusong ,1995/04/07
     */
    memset(g_pstTba->caMsgp,'\0',100);
  }

  /*
   * g_cErrActFlag is set to OFF (i.e.  SIF is set OFF )
   */
   g_cErrActFlag &= (~INFORM_DBP_FLAG);

  UCP_TRACE_END(0);
}


/*
 *&N& ROUTINE NAME: SysWrtLogForAp()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                 DESCRIPTION
 *&A&   ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&    < 0    : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& �p�GAP���`�����B�S�gLOG, �h�t�η|����AP�g�@��LOG.
 *&D&
 */
int
SysWrtLogForAp()
{
  int iRc;
  char caRtnRrn[10];

  UCP_TRACE(P_SysWrtLogForAp);

  /* TPE_WRT_LOG = '2' define in <lgcopewa.h>
   * AP_WRT_LOG =  '1' define in <lgcopewa.h>
   *
   * it means AP never write any LOG
   */ 
  if ( (g_pstTma->stTCFA.cApReturnCode == TMS_AP_ACC_NORMAL) ||
       (g_pstTma->stTCFA.cApReturnCode == TMS_AP_NON_ACC_NORMAL) ) {

    if ( g_pstTma->stTCFA.cApWriteLogFlag == TMS_AP_HAS_NOT_BEEN_WRT_LOG ) {
      iRc=UcpTxnLg('2',g_pstApa,caRtnRrn,NULL,g_pstTba->caSif);
      if ( iRc < 0 ) {
        sprintf(g_caMsg,
               "SysWrtLogForAp: UcpTxnLg(TPE_WRT_LOG) error rtn code=%d",iRc);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END( -1 );
      }
      g_iTotLogCntPerTxn++;
    }

  }

  UCP_TRACE_END( 0 );
}
