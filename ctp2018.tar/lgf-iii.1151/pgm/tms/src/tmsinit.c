/*
 *&N& File : tmsinit.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int       TxInit()               ��@����_�l���ҳ]�w
 *&N&    int       InitSysEnv()           �t�����Ҥ���l��
 */

/* ------------------------- INCLUDE FILES ---------------------------- */
#include "errlog.h"
#include "tmcinit.h"
#include "tmcpgdef.h"	/* TMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */

/* ------------------------- CONSTANT DEFINITION ---------------------- */
/* tmsinit.c 
#define P_TxInit 		23001
#define P_InitSysEnv 		23002
*/
/* ------------------------- STATIC GLOBAL VARIABLE-------------------- */
extern int g_iApPid ;

/*
 *&N& ROUTINE NAME: TxInit()
 *&A& ARGUMENTS:
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&   ����ƥΥH�]�w��@������t�θ�Ƥ����, �Τ����Ҳժ�l��
 */

int
TxInit( cErrStep )
char *cErrStep;
{
  int iRc;


  UCP_TRACE( P_TxInit );

  *cErrStep = '0';
  iRc = InitSysEnv();
  if (iRc < 0) {
    *cErrStep = '1';
    ErrLog(1000, "TxInit: InitSysEnv() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( iRc );
  }

  iRc = InitTWA();
  if (iRc < 0) {
    *cErrStep = '2';
    ErrLog(1000, "TxInit: InitTWA() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( iRc );
  }

  iRc = IniIfEnv();
  if (iRc < 0) {
    *cErrStep = '3';
    ErrLog(1000, "TxInit: IniIfEnv() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( INIT_IF_ENV_ERR );
  }

  UCP_TRACE_END( 0 ); 
}

/*
 *&N& ROUTINE NAME: InitSysEnv()
 *&A& ARGUMENTS:
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&   �t�����Ҥ���l��
 *&D&   --------------------
 *&D&      UNIX: Semaphore
 *&D&      OS400:
 *&D&      CICS:
 *&D&      OS2:
 *&D&      �䥦����:
 *&D&
 */

int
InitSysEnv()
{
  int iRc ;

  UCP_TRACE( P_InitSysEnv );
  /*
  ** Reset AP Process Id in order to decide whether TPU system needs
  ** to kill AP Process in <tmsrelse.c> EnvRelse() 
   */
  g_iApPid = -1 ;
  iRc = ResetSync();

  if ( iRc < 0 ) {
    ErrLog(1000, "TxInit: ResetSync() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( RESET_SYNC_ERR );
  }

  UCP_TRACE_END( 0 ); 
}
