/*
 *&N& File : tmsflgen.c
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&                 main()               ����TMS�ѷӪ��w�q��
 */

/* ------------------------- INCLUDE FILES ---------------------------- */
#include <stdio.h>
#include <errno.h>
#include "errlog.h"

/* ------------------------- CONSTANT DEFINITION  --------------------- */

#define  MAX_EXEC_PATH_LEN     80
#define  FILE_NAME_LEN         80
#define  MAX_IFMOD_NUM         10
#define  PROG_FORK_ERR         -1
#define  PROG_EXEC_ERR         -2
#define  PROG_REMOVE_ERR       -3
#define  IFMOD_CNFG_ERR	       -4
#define  OPEN_FILE_ERR	       -5
#define  EMS_IFMOD_FILE	 "iii/etc/tbl/emdifmod.dat"
#define  TMS_IFMOD_DEF	 "iii/bin/lib/tmdifmod.def"
#define  TMS_IFMOD_H	 "iii/bin/lib/tmgifmod.h"

static
struct if_st {
  char pcaModuleName[10];      /* module name     */
  char pcaVersionName[20];      /* version name    */
  char pcaLoadPgmName[20];     /* load program name */
  char pcaAttFunName[20];      /* attach program  */
  char pcaIniFunName[20];      /* initial program */
  char pcaBgnFunName[20];      /* begin program   */
  char pcaEndFunName[20];      /* end program     */
  char pcaRelFunName[20];      /* release program */
  char pcaDetFunName[20];      /* detach program  */
  char pcaRlsePgmName[20];     /* release program name */
} sg_staIfModTbl[MAX_IFMOD_NUM] ;

extern int  errno;

main()
{
  int i;
  int iRc;
  int iTblSize;
  int iChiPid;
  int iWaitCode;
  char caExePath[MAX_EXEC_PATH_LEN];    /* buf for keep exec path str */
  char caFlName[FILE_NAME_LEN];
  int  iStatus;
  int  iHadLoadNum;
  FILE *zIfMod;
  FILE *zTmsDef;
  FILE *zTmsh;


     /* -------------------- */
     /* get open file name   */
     /* -------------------- */
   memset(caFlName,'\0',FILE_NAME_LEN);
   strcpy(caFlName,(char *) getenv("III_DIR"));
   strcat(caFlName,(char *) "/");
   strcat(caFlName,EMS_IFMOD_FILE);

  /* open ifmod file name */
  if((zIfMod=fopen(caFlName,"r")) == NULL){
    printf("tmsflgen:open ems ifmod file errno=%d",errno);
    exit(OPEN_FILE_ERR);
  } /* FOR if((zIfMod=fopen(caFlname,"r")) == NULL) */

   memset(caFlName,'\0',FILE_NAME_LEN);
   strcpy(caFlName,(char *) getenv("III_DIR"));
   strcat(caFlName,(char *) "/");
   strcat(caFlName,TMS_IFMOD_DEF);

  /* open ifmod file name */
  if((zTmsDef=fopen(caFlName,"w")) == NULL){
    printf("tmsflgen:open tms def file errno=%d",errno);
    exit(OPEN_FILE_ERR);
  } /* FOR if((zIfMod=fopen(caFlname,"r")) == NULL) */

   memset(caFlName,'\0',FILE_NAME_LEN);
   strcpy(caFlName,(char *) getenv("III_DIR"));
   strcat(caFlName,(char *) "/");
   strcat(caFlName,TMS_IFMOD_H);

  /* open ifmod file name */
  if((zTmsh=fopen(caFlName,"w")) == NULL){
    printf("tmsflgen:open tms header file errno=%d",errno);
    exit(OPEN_FILE_ERR);
  } /* FOR if((zIfMod=fopen(caFlname,"r")) == NULL) */

   i=0;
   while((iRc=fscanf(zIfMod,"%s %s %s %s %s %s %s %s %s %s\n",
                     sg_staIfModTbl[i].pcaModuleName,
                     sg_staIfModTbl[i].pcaVersionName,
                     sg_staIfModTbl[i].pcaLoadPgmName,
                     sg_staIfModTbl[i].pcaAttFunName,
                     sg_staIfModTbl[i].pcaIniFunName,
                     sg_staIfModTbl[i].pcaBgnFunName,
                     sg_staIfModTbl[i].pcaEndFunName,
                     sg_staIfModTbl[i].pcaRelFunName,
                     sg_staIfModTbl[i].pcaDetFunName,
                     sg_staIfModTbl[i].pcaRlsePgmName)) != EOF){
     if(iRc < 10){
       printf("tmsflgen: fscanf input %d iterm < 10",iRc);
       exit(IFMOD_CNFG_ERR);
     }
     i++;
   } /* FOR while((iRc=fscanf(....))  */

  iTblSize = i;

  for (i = 0; i < iTblSize; i ++)  {
    fprintf(zTmsDef,"\x22%s\x22, %s, %s, %s, %s, %s, %s,\n",
            sg_staIfModTbl[i].pcaModuleName,
            sg_staIfModTbl[i].pcaAttFunName,
            sg_staIfModTbl[i].pcaIniFunName,
            sg_staIfModTbl[i].pcaBgnFunName,
            sg_staIfModTbl[i].pcaEndFunName,
            sg_staIfModTbl[i].pcaRelFunName,
            sg_staIfModTbl[i].pcaDetFunName);
  }  /* FOR for(i...)   */
 
  
  fprintf(zTmsh,"#ifndef H_TMGIFMOD\n");
  fprintf(zTmsh,"#define H_TMGIFMOD\n");
  fprintf(zTmsh,"\n");

  for (i = 0; i < iTblSize; i ++)  {
    fprintf(zTmsh,"\x2f\x2a FOR %s \x2a\x2f\n",sg_staIfModTbl[i].pcaModuleName);
    if ( strncmp(sg_staIfModTbl[ i ].pcaAttFunName,"NULL",4) !=0 ) {
      fprintf(zTmsh,"extern int %s();\n",sg_staIfModTbl[i].pcaAttFunName);
    }
    if ( strncmp(sg_staIfModTbl[ i ].pcaIniFunName,"NULL",4) !=0 ) {
      fprintf(zTmsh,"extern int %s();\n",sg_staIfModTbl[i].pcaIniFunName);
    }
    if ( strncmp(sg_staIfModTbl[ i ].pcaBgnFunName,"NULL",4) !=0 ) {
      fprintf(zTmsh,"extern int %s();\n",sg_staIfModTbl[i].pcaBgnFunName);
    }
    if ( strncmp(sg_staIfModTbl[ i ].pcaEndFunName,"NULL",4) !=0 ) {
      fprintf(zTmsh,"extern int %s();\n",sg_staIfModTbl[i].pcaEndFunName);
    }
    if ( strncmp(sg_staIfModTbl[ i ].pcaRelFunName,"NULL",4) !=0 ) {
      fprintf(zTmsh,"extern int %s();\n",sg_staIfModTbl[i].pcaRelFunName);
    }
    if ( strncmp(sg_staIfModTbl[ i ].pcaDetFunName,"NULL",4) !=0 ) {
      fprintf(zTmsh,"extern int %s();\n",sg_staIfModTbl[i].pcaDetFunName);
    }
    fprintf(zTmsh,"\n");
  }  /* FOR for(i...)   */
 
  fprintf(zTmsh,"#endif\n");
  fclose(zTmsh);
  fclose(zTmsDef);
  fclose(zIfMod);
    
  printf("Generate tmdifmod.def, tmgifmod.h OK!!\n");
  exit(0);
}




