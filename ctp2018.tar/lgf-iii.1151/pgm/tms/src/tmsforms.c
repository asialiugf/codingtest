/*  $Header:   C:\ui\fas2\iom\src\omsforms.c_v   1.0   15 Dec 1993 11:41:42   OLTPDBP  $  */
/*  $Log:   C:\ui\fas2\iom\src\omsforms.c_v  $
 *
 *    Rev 1.0   15 Dec 1993 11:41:42   OLTPDBP
 * Initial revision.
 *
 */
#include    <stdio.h>
#include    <ctype.h>
/* #include    <conio.h>  */
#include    <fcntl.h>
#include    "errlog.h"
/* omsforms.c */
#define P_apfmt_out 		51101
#define P_d_write 		51102
#define P_dfmt_parse 		51103
#define P_fmctl_get 		51104
#define P_fmt_pre 		51105
#define P_form_feed 		51106
#define P_form_getc 		51107
#define P_form_proc 		51108
#define P_get_c_token 		51109
#define P_get_ctl_para 		51110
#define P_get_dleng 		51111
#define P_get_n_token 		51112
#define P_get_number 		51113
#define P_ld_to_pd 		51114
#define P_set_chinese_flag      51115
#define P_token_par 		51116
#define P_ucpfmt_out 		51117
#define P_unfmt_out 		51118
#define P_get_1char 		51119
#define P_counter_add 		51120
#define P_unget_1char 		51121
extern      int errno;

#define     MAX_LINE_LEN      800
#define     MAX_FILE_OPEN     10
#define     MAX_TOKEN_LEN      20
#define     FORM_ID_LEN         4
#define     F_CTL_ERR          -1     /* form control information error */
#define     F_IPOS_ERR         -2     /* invalid initial position declared */
#define     F_IVDEL_ERR        -3     /* invalid delimiter */
#define     F_PARSER_ERR       -4     /* parser form file error */
#define     D_LENGTH_ERR       -5     /* define form len error */
#define     D_NUMBER_ERR       -6     /* define form number error */
#define     UN_PRINTABLE_CHAR  '?'    /* stand for the unprintable character */
#define     NORMAL              0     /* write processing normal end.        */
#define     WRITE_ERR           1     /* write processing has error .        */
#define     OPEN_ERR            2     /* open file error                     */
#define     CLOSE_ERR           3     /* close file error                    */
/* #define     OPEN_FORM_ERR    4     /x open form file error             */
/* Add by fu-song chi, 1994/10/5 */
#define     OPEN_FORM_ERR      -5     /* open form file error                */

#define     FORM_PATH          "/iii/etc/bfrm/"
    /* copy from omsoutpr.c  */
    /* logical output device definition */
#define     D_MSG_BAR                '~'    /* message output device */
#define     D_JOURNAL                '1'
#define     D_DISPLAY                '2'
#define     D_PASSBOOK               '3'
#define     D_MSR                    '4'
#define     D_DOCUMENT               '5'
#define     D_DOCUMENT_LG            '6'
#define     D_SLIP                   '7'
#define     D_DCUM_LGST              '8'
#define     D_DCUM_SLIP              '9'
#define     D_DCUM_SLIP1             'y'
#define     D_DCUM_SLIP2             '&'
#define     D_TM_USE                 'A'
#define     D_TM_USE_REV             'B'
#define     D_TM_USE_TR              'C'
#define     D_3278_USE               'E'
#define     D_PASSBOOK_LN            'H'
#define     D_DCUM_SLIP_LN           'I'
#define     D_DOCUMENT_EXIT          'K'
#define     D_MSROUT                 'M'
#define     D_NETWORK                'N'
#define     D_PGUPDN                 'Y'
#define     D_REPORT                 'Z'
#define     D_FILE                   '*'
#define     D_BTFILE                 'T'
       /* copy from omsoutpr.c end   */
       /* copy from imsout.c begin */
#define     PSCRN_DEV                '1'
#define     PLINE_DEV                '2'
#define     PJOUR_DEV                '3'
#define     PPASS_DEV                '4'
#define     PMSR_DEV                 '5'
#define     PFILE_DEV                '6'
#define     BTFILE_DEV               '7'
#define     SPACE                    ' '
#define     FF                      0x0c  
#define     LF                      0x0a  
#define     SP                      0x20  

       /* copy from imsout.c end   */
/*-------------- structure declaration for this program only ---------------*/
struct fmt_cvt {
      char  data_type;   /* the data type of the input data to be convert   */
                         /* 'c' -> char, 'b' -> binary, 'f' -> real num.    */
                         /* 'p' -> packed decimal, 'C' -> constant output   */
                         /* 'N' -> newline char                             */
      short in_len;      /* number of bytes retrieves from the output data  */
      short out_len;     /* the length of the data after converting         */
      short dig_pos;     /* the digital position of the output data         */
      char  cdata[MAX_LINE_LEN]; /* constant char. defined in form file     */
};
struct ctl_data {        /* this struct describes the ctl info. of a form   */
     int  init_x;        /* initial x corrdinate of a form file             */
     int  init_y;        /* initial y corrdinate of a form file             */
     char filler[20];    /* reserved control data                           */
};

/*---------------------- global declaration --------------------------------*/
static FILE *form_fp;    /* open form file by fmctl_get() */
int  X_pos,Y_pos;
int  X_abs,Y_abs;
int  init_x,init_y;
static char PGM[30];     /* record the DOS utility name to be invoked */
static char fst_chinese=0;
static char sec_chinese=0;
/* TCC: For compatibility with Tandem */
/*
int  Cur_fd;
*/
char *Cur_dtype;  
int  digit_1;
static int  ft_idx = 0;
char  nch;
int   fflag;            /*  used for form feed flag, 0=no ff ; 1=F+ ; 2=F-   */
int   addflag;          /*  used for addr coordination definition,   */
			/*  0 = relative ; 1 = absolute			*/

/*& *************************************************************************/
/*& ROUTINE-NAME:fmctl_get(form_id,dev_type,chg_dev)                        */
/*& form_id(char *): the form-id of the output to be applied                */
/*& dev_type(char *):the device type of the output to be used               */
/*& chg_dev(char *): the device type for one form output                    */
/*& RETURN-CODE: 0 -> normal output complete                                */
/*&             <0 -> output error                                          */
/*& This routine will get the control information of the form file          */
/*& *************************************************************************/
fmctl_get(form_id,dev_type,chg_dev)
char *form_id;
char *dev_type;
char chg_dev;
{
 static struct fmt_cvt  fmt_token;
 int    rc;
 char   form_name[100];

  UCP_TRACE(P_fmctl_get);
  /* Add 1 line below to reset 2 static vars in form_getc, by Willy 19970108 */
  form_getc(9999);
  PGM[0]='\0';    /* reset the DOS utility name to be invoked */
  if ( chg_dev == 0 ) {  /* change device flag is off, read form file */
     memset(form_name,0,100);
     strcpy(form_name , getenv("III_DIR"));
     strcat(form_name,FORM_PATH);
     strcat(form_name,form_id);
     if ( (form_fp = fopen(form_name,"r"))  == NULL ) {
        sprintf(g_caMsg,"open FORMFILE %s error,errno=%d",form_name,errno);
        /* Change ErrLog flag from 200 to 1000, by Willy 19970108 */
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0); 
        /* Modify by fu-song chi, 1994/10/5 */
        UCP_TRACE_END(OPEN_FORM_ERR);
     }
     else {
         rc=token_par(&fmt_token,chg_dev);
         if (rc != 0) {
           if (rc != 9){/* get control parameters end add by Jess*/
/* WUHAN : modify by zheng for ptm960098 97/05/21 begin */
            UCP_TRACE_END(F_CTL_ERR);
/* WUHAN : modify by zheng for ptm960098 97/05/21 end   */
           }
         }
         /*sprintf(g_caMsg,"fmctl_get:fmt_token.data_type=%c,0x%2x",
                 fmt_token.data_type, fmt_token.data_type);
         ErrLog(200,g_caMsg,RPT_TO_LOG,0,0);*/
         while ((fmt_token.data_type == 'C') && ((fmt_token.cdata[0] == ' ')
                || (fmt_token.cdata[0] == '\n'))) {
         /* bypass space & space line if '{' isn't located at the first line */
            rc=token_par(&fmt_token,chg_dev);
            if (rc != 0) {
              if (rc == 9){
                 break; /* get control parameters end add by Jess*/
              } else {
/* WUHAN : modify by zheng for ptm960098 97/05/21 begin */
                 UCP_TRACE_END(F_CTL_ERR);
/* WUHAN : modify by zheng for ptm960098 97/05/21 end   */
              }
            }
         }
         if (fmt_token.data_type == 'B') {
           if (addflag == 0)  {
               init_x=((struct ctl_data *)(fmt_token.cdata))->init_x;
               init_y=((struct ctl_data *)(fmt_token.cdata))->init_y;
           }
	   else {
	       Y_abs=((struct ctl_data *)(fmt_token.cdata))->init_y; 
	       X_abs=((struct ctl_data *)(fmt_token.cdata))->init_x; 
           }
           if ( ((struct ctl_data *)(fmt_token.cdata))->filler[0] != ' ' ) {
              *dev_type=((struct ctl_data *)(fmt_token.cdata))->filler[0];
           }
         }
         else {
           UCP_TRACE_END(F_CTL_ERR);
         }  /* for if (fmt_token.data_type == 'B') */
         UCP_TRACE_END(NORMAL);
     }
  }   /*   end if (chg_dev == 0)  */
  if ( chg_dev == 1 ) {
     /* reset change device flag  chg_dev = 0 is moved to ucpfmt_out()  */
/*
      init_x=((struct ctl_data *)(fmt_token.cdata))->init_x;
      init_y=((struct ctl_data *)(fmt_token.cdata))->init_y;
      if ( ((struct ctl_data *)(fmt_token.cdata))->filler[0] != ' ' ) {
         *dev_type=((struct ctl_data *)(fmt_token.cdata))->filler[0];
      }
*/
      UCP_TRACE_END(NORMAL);
  }
}

/*& *************************************************************************/
/*& ROUTINE-NAME:form_proc(dev_type,form_id,msg,dev_fp)                            */
/*& dev_type(char *) : the output device to be used                         */
/*& form_id(char *): the form-id of the output to be applied                */
/*& msg(char *)    : the output data                                        */
/*& dev_fp(int )   : the output device fp                                   */
/*& RETURN-CODE: 0 -> normal output complete                                */
/*&             <0 -> output error                                          */
/*& This procedure will process 3 kinds of output processing:               */
/*& form_id=T???  -> 47 format interpreater                                 */
/*& form_id=TXXX  -> CI format interpreater (format is arranged by AP)      */
/*& otherwise     -> format interpreated according form_id                  */
/*& *************************************************************************/
form_proc(dev_type,form_id,msg,chg_dev,dev_fp)
char *dev_type;
char *form_id,*msg;
char chg_dev;
int  dev_fp;
{
  int rc;

  UCP_TRACE(P_form_proc);

  rc=-1;
  if ( strcmp(form_id,"TXXX") == 0 ) {
      rc=unfmt_out(dev_type,msg,chg_dev,dev_fp);       /* such 47 format */
  }
  else {
     if ( strcmp(form_id,"T???") == 0 ) {
         rc=apfmt_out(dev_type,msg,chg_dev,dev_fp);    /* format is arranged by AP such CI*/
     }
     else {
         rc=ucpfmt_out(dev_type,msg,chg_dev,dev_fp);   /* UCP statndard output format */
         if ( (rc == 0) && (PGM[0] != '\0') ) {
            system(PGM); /* invoke the DOS utility */
         }
     }
  }
  UCP_TRACE_END(rc);
}

/*& *************************************************************************/
/*& ROUTINE-NAME:apfmt_out(dev_type,msg)                                    */
/*& dev_type(char *) : the output device to be used                         */
/*& msg(char *)    : the output data                                        */
/*& RETURN-CODE: 0 -> normal output complete                                */
/*&             <0 -> output error                                          */
/*& This routine will output data according to the text from the AP and     */
/*& explain the control code.                                               */
/*& *************************************************************************/
apfmt_out(dev_type,msg,chg_dev,dev_fp)
char *dev_type;
char *msg;
char chg_dev;
int  dev_fp;
{
 int   count,i,j;
 unsigned char  ch,pattern,got_digit[5+1];
 int   dataleng_used,dataleng;
 int   got_ctl_flag;
 char  out_buff[MAX_LINE_LEN];
 int   out_idx;
 int   rc;
 
 UCP_TRACE(P_apfmt_out);
 dataleng_used = 0;
 dataleng      = strlen(msg);

 memset(out_buff,'\0',MAX_LINE_LEN);
 out_idx=0;
  while(dataleng_used < dataleng){
    ch = get_1char(msg,dataleng,&dataleng_used);
    switch(ch){
      case '\\':
        count = 0;
        got_ctl_flag = 0;
        j=0;
        ch = get_1char(msg,dataleng,&dataleng_used);
        while( ((isdigit(ch)) != 0) && ( j<5) ){
          counter_add(&count,ch);
          got_digit[j] = ch;
	  j++;
          got_ctl_flag = 1;
          ch = get_1char(msg,dataleng,&dataleng_used);
        } /* while( (isdigit(ch)) != 0) */
        got_digit[j] = '\0';
        if(got_ctl_flag == 1){
          switch(ch){
            case 'P':
              pattern = FF;
              break;
            case 'N':
              pattern = LF;
              break;
            case ' ':
              pattern = SP;
              break;
            default:   /* presenting that's not ctrl code */
	      got_ctl_flag = 0;
              pattern = ch;
              break;
          } /* switch(ch) */
          while( (count != 0) && (got_ctl_flag == 1) ){
            if( pattern == FF){
              out_buff[out_idx] = '\0';
	      rc = d_write(*dev_type,out_buff,dev_fp);
              memset(out_buff,'\0',MAX_LINE_LEN);
              out_idx=0;
              form_feed(*dev_type,dev_fp);
            }
            else if( pattern == LF){
              out_buff[out_idx] = '\n';
	      out_idx++;
              out_buff[out_idx] = '\0';
	      rc = d_write(*dev_type,out_buff,dev_fp);
              memset(out_buff,'\0',MAX_LINE_LEN);
              out_idx=0;
            }
            else if( pattern == SP){
              out_buff[out_idx] = ' ';
	      out_idx++;
            }
/*
            else{
              out_buff[out_idx] = pattern;
	      out_idx++;
            }
*/
            count--;
          }
          if ( got_ctl_flag == 0) {
              out_buff[out_idx] = '\\';
	      out_idx++;
	      memcpy(&out_buff[out_idx],got_digit,j);
	      out_idx += j;
              out_buff[out_idx] = pattern;
	      out_idx++;
	      count = 0;
	  }

        } /* (got_ctl_flag != 1) */
        else{
          out_buff[out_idx] = '\\';
	  out_idx++;
          unget_1char(&dataleng_used);
        }
        break; /* case \\ */
      default:
          out_buff[out_idx] = ch;
	  out_idx++;
          break;
    } /* switch */
  } /* while(dataleng */
  out_buff[out_idx] = '\0';
  rc = d_write(*dev_type,out_buff,dev_fp);
  memset(out_buff,'\0',MAX_LINE_LEN);
  out_idx=0;
  UCP_TRACE_END(0);
}
/*& *************************************************************************/
/*& ROUTINE-NAME:ucpfmt_out(dev_type,msg)                                   */
/*& dev_type(char *) : the output device to be used                         */
/*& msg(char *)    : the output data                                        */
/*& RETURN-CODE: 0 -> normal output complete                                */
/*&             <0 -> output error                                          */
/*& This routine will output data according to the format that form-id      */
/*& specified.                                                              */
/*& *************************************************************************/
ucpfmt_out(dev_type,msg,chg_dev,dev_fp)
char *dev_type;
char *msg;
char chg_dev;
int  dev_fp;
{
 struct fmt_cvt  fmt_token;
 char out_buff[MAX_LINE_LEN];
 int  i,j;
 int  out_idx;
/* static int  msg_idx=0;   /x point to the current output char in out-buff */
 int  msg_idx=0;   /* point to the current output char in out-buff */
 int  rc;

 UCP_TRACE(P_ucpfmt_out);

 if ( chg_dev == 1 ) {
    chg_dev=0;   /* reset change device flag */
 }
 else {
    msg_idx=0;   /* reset pointer of the output data buffer */
 }
 memset(out_buff,'\0',MAX_LINE_LEN);
     /* initial position adjust, initial coordinate is (init_x,init_y) */
 if ( (init_x < 0) || (init_y < 0) ) {
      UCP_TRACE_END(-1);
 }
 if ( (init_x > 0) || (init_y > 0) ) {
    j=0;
    if (addflag == 0) {
        for (i=1;i<init_y;i++) {
            out_buff[j++]='\n';
        }
        for (i=1;i<init_x;i++) {
           out_buff[j++]=' ';
        }
    }
    else {
        if ((Y_abs < Y_pos) )   UCP_TRACE_END(-1);
        for (i=Y_pos;i<Y_abs;i++) {
            out_buff[j++]='\n';
        }
        for (i=1;i<X_abs;i++) {
           out_buff[j++]=' ';
        }
    }
    out_buff[j]='\0';
    if (fflag == 2) {
       form_feed(*dev_type,dev_fp); /* form feed  before print */ 	
       fflag = 0;
    }
    rc=d_write(*dev_type,out_buff,dev_fp);/* output buffer data to the device */
 }
     /* begin to parse the form file and prepare the output data */
 memset(out_buff,'\0',MAX_LINE_LEN);
 out_idx=0;
 while (1) {
    if ( (rc=token_par(&fmt_token,chg_dev)) == 0 ) {
/*       sprintf(g_caMsg,"ucpfmt_out:out_idx=%d,msg_idx=%d",out_idx,msg_idx);
       ErrLog(200,g_caMsg,RPT_TO_LOG,0,0);
*/
      for (i=0;i<digit_1;i++) {
         if ( (rc=fmt_pre(out_buff,msg,&fmt_token,&out_idx,&msg_idx)) != 0 ) {
            sprintf(g_caMsg,"ucpfmt_out:format convert error rc=%d",rc);
            ErrLog(200,g_caMsg,RPT_TO_LOG,0,0);
            fclose(form_fp);
            UCP_TRACE_END(-1);
         }
      }
         /* format control token is newline or formfeed or end of form file */
       if ( (fmt_token.data_type == 'N') || (fmt_token.data_type == 'F')
            || (fmt_token.data_type == 'E') || (fmt_token.data_type == 'D') ) {
          rc=d_write(*dev_type,out_buff,dev_fp); /* output buffer data to the device */
          if ( rc == -1 ) {
             UCP_TRACE_END(WRITE_ERR);
          }
          if ( (fmt_token.data_type != 'E') && (fmt_token.data_type != 'D') ) {
            /* clear the output buffer and ready to output next one */
            out_idx=0;/* clear the output buffer and ready to output next one */
             memset(out_buff,'\0',MAX_LINE_LEN);
                if  (fmt_token.data_type == 'N')  {
                     j=0;
                     for (i=1;i<init_x;i++)  {
                        out_buff[j++]=' ';
                     }
                     out_idx = (init_x >=1) ? init_x-1 : 0  ;
                }
          }
          else {
             if (fmt_token.data_type == 'E') {  /* close form file */
                if (fflag == 1)  {
                    form_feed(*dev_type,dev_fp); 
                    fflag = 0 ;      /* form feed  after print */ 	
                }
                fclose(form_fp);
             }
             else {
                init_x=((struct ctl_data *)(fmt_token.cdata))->init_x;
                init_y=((struct ctl_data *)(fmt_token.cdata))->init_y;
                if ( ((struct ctl_data *)(fmt_token.cdata))->filler[0] != ' ' ) {
                    *dev_type=((struct ctl_data *)(fmt_token.cdata))->filler[0];
                 }
             }
             UCP_TRACE_END(0);
          }
       }
    }
    else {
       if ( rc == -1 ) {   /* form file is end of file */
         fclose(form_fp);
   ErrLog(1000,"there is no '}' at the end of TXXX error",RPT_TO_LOG,0,0);
         UCP_TRACE_END(-1);
/* marked by zheng for no '}' at end of TXXX then return -1  1997/4/19
         if ( strlen(out_buff) != 0 ) {
             rc=d_write(*dev_type,out_buff,dev_fp); 
             if ( rc != 0 ) {
                sprintf(g_caMsg,"ucpfmt_out:d_write error,dev=%c rc=%d",
                        *dev_type,rc);
                ErrLog(200,g_caMsg,RPT_TO_LOG,0,0);
                UCP_TRACE_END(-1);
             }
          }
          else {
             UCP_TRACE_END(0);
          }   
marked end 1997/4/19  
*/
       }
       else {
          sprintf(g_caMsg,"token parser error rc=%d",rc);
          ErrLog(200,g_caMsg,RPT_TO_LOG,0,0);
          UCP_TRACE_END(rc);
       }
    } /* for if ( (rc=get_token(&fmt_token)) == 0 ) */
 }  /* for while (1) */
}

/*& *************************************************************************/
/*& ROUTINE-NAME:token_par(fmt_token,chg_dev)                               */
/*& fmt_token:                                                              */
/*& RETURN-CODE: 0 -> normal                                                */
/*&             -1 -> format file is ended                                  */
/*&             -2 -> format file read error                                */
/*& *************************************************************************/
token_par(fmt_token,chg_dev)
struct fmt_cvt *fmt_token;
char chg_dev;
{
 unsigned char   ch;
 int    rc;
 int    dlen;

 UCP_TRACE(P_token_par);
    /* the next step is going to get a token and parser it */
    /* the following program is a temporsry solution, can replaced it */
    ch=form_getc(1);
    /*sprintf(g_caMsg,"token_par:ch=form_get(1)=%c,0x%2x",ch, ch);
    ErrLog(200,g_caMsg,RPT_TO_LOG,0,0);*/
    if ( sec_chinese == 1 ) {  /* the 2nd byte of a Chinese code */
        fmt_token->data_type='C';
        fmt_token->in_len=0;
        fmt_token->out_len=1;
        fmt_token->dig_pos=0;
        fmt_token->cdata[0]=ch;
    }
    else {
        switch (ch) {
           case '\n':fmt_token->data_type='N';
                     digit_1 = 1;
                     break;
           case '[' :
                     rc = dfmt_parse();
                     if (rc != 0)   UCP_TRACE_END(rc);
                         fmt_token->data_type='c';
                         fmt_token->in_len=1;
                         fmt_token->out_len=1;
                     break;
           case '{' :fmt_token->data_type='B';
                     digit_1 = 1;
                     /*UCP_TRACE_END(rc);*/
                     rc=get_ctl_para(fmt_token);
                     if (rc == 0) {
                       UCP_TRACE_END(9);
                     }
                     else {
                       UCP_TRACE_END(rc);
                     }
           case '@' :fmt_token->data_type='D';
                     digit_1 = 1;
                     rc=get_ctl_para(fmt_token);
                     chg_dev=1; /* set change device type flag on */
                     UCP_TRACE_END(rc);
           case '}' :fmt_token->data_type='E';
                     digit_1 = 1;
                     form_getc(9999);  /* reset token buffer */
                     break;
/*  add by zheng for TXXX no '}' at end 1997/4/19  */
           case (unsigned char)(-1):
                     UCP_TRACE_END(-1);
/*  add end  1997/4/19  */
           default  :fmt_token->data_type='C';
                     fmt_token->in_len=0;
                     fmt_token->out_len=1;
                     fmt_token->dig_pos=0;
                     digit_1 = 1;

/*0x0c -> formfeed*/ if ( (ch < 0x20) && (ch != 0x0a) && (ch != 0x0d) &&
/*0x11 -> enlarge */      (ch != 0x0c) && (ch != 0x11) && (ch !=0x12) ) {
/* 4times for 4702*/    fmt_token->cdata[0]=UN_PRINTABLE_CHAR;
/*0x12 -> reset   */ }
/*enlarge for 4702*/ else {
                        fmt_token->cdata[0]=ch;
                     }
                     break;
        }
    }
    UCP_TRACE_END(0);
}

/*& *************************************************************************/
/*& ROUTINE-NAME:get_ctl_para(fmt_token)                                    */
/*& fmt_token(struct fmt_cvt *):convey the control information return to    */
/*&                             the calling routine                         */
/*& RETURN-CODE: 0 -> normal                                                */
/*&             F_CTL_ERR   -> control data format error                    */
/*&             F_IPOS_ERR  -> invalid initial position declared            */
/*&             F_IVDEL_ERR -> invalid delimiter                            */
/*& *************************************************************************/
get_ctl_para(fmt_token)
struct fmt_cvt *fmt_token;
{
  char ch;
  int  x,y;
  struct ctl_data fctlinfo;
  int  i;
  int  ffno;

  UCP_TRACE(P_get_ctl_para);

  x=y=0;
  fctlinfo.filler[0]=' ';  /* reset device type declared in the form */
  ffno = 100;
  while (1) {
     ch=get_c_token();
     /*sprintf(g_caMsg,"get_ctl_para:ch=%c,0x%2x",ch,ch);
     ErrLog(200,g_caMsg,RPT_TO_LOG,0,0);*/
     switch (ch) {
         case '(' :
                   if ( (y=get_n_token()) == -1 ) {
                      UCP_TRACE_END(F_IPOS_ERR); /* initial pos. error declaration */
                   }
                   ch=get_c_token();
		   switch(ch) {
                      case ',' :
                            addflag = 0; /* present it's relative addr mdoe */
			    break;
                      case ';' :
                            addflag = 1; /* present it's absolute addr mode */
			    break;
                      default:
                            addflag = -1;
                            UCP_TRACE_END(F_IVDEL_ERR);/* invalid delimiter symbol */
                   }
                   if ( (x=get_n_token()) == -1 ) {
                      UCP_TRACE_END(F_IPOS_ERR); /* initial pos. error declaration */
                   }
                   if ( (ch=get_c_token()) != ')' ) {
                      UCP_TRACE_END(F_IPOS_ERR); /* initial pos. error declaration */
                   }
                   break;
         case 'F' :
         case 'f' :
                     ch=get_c_token() ;
                     switch(ch){
                       case '-':
			 fflag = 2;
                         break;
                       case '+':
			 fflag = 1;
                         break;
                       default:
                         UCP_TRACE_END(F_CTL_ERR);
                     }
         /*            ch=get_c_token();      */
                   break;
         case 'P' :    /* parsing "PGM=... " */
                   if ( (ch=get_c_token()) != 'G' ) {
                      UCP_TRACE_END(F_CTL_ERR);
                   }
                   if ( (ch=get_c_token()) != 'M' ) {
                      UCP_TRACE_END(F_CTL_ERR);
                   }
                   if ( (ch=get_c_token()) != '=' ) {
                      UCP_TRACE_END(F_CTL_ERR);
                   }
                   i=0;
                   ch=get_c_token();
                   while ((ch != ' ') && (ch != '\n')) {
                     PGM[i++]=ch;
                     ch=get_c_token();
                   }
                   form_getc(-1);   /* unget the token character */
                   PGM[i]='\0';
                   break;
         case 'D' :    /* parsing DEV=...  */
                   if ( (ch=get_c_token()) != 'E' ) {
                      UCP_TRACE_END(F_CTL_ERR);
                   }
                   if ( (ch=get_c_token()) != 'V' ) {
                      UCP_TRACE_END(F_CTL_ERR);
                   }
                   if ( (ch=get_c_token()) != '=' ) {
                      UCP_TRACE_END(F_CTL_ERR);
                   }
                   i=0;
                   while(1) {
                     ch=get_c_token();
                     if ( ch == ' ' ) {
                        ch=get_c_token();
                     }
                     else {
                        if ( ch == '\n' ) {
                           form_getc(-1);   /* unget the token character */
                           break;
                        }
                        else {
                           fctlinfo.filler[0]=ch;
                           break;
                        }
                     }
                   }
                   break;
         case ' ' :break;
         case '\n':
                       fctlinfo.init_x=x;
                       fctlinfo.init_y=y;
                       memcpy((struct ctl_data *)(fmt_token->cdata),&fctlinfo,
                              sizeof(fctlinfo));
                   if ((fflag != 1) && (fflag !=2))   fflag=0;
                   UCP_TRACE_END(0);
         default  :
                   UCP_TRACE_END(F_CTL_ERR);
     }
  }   /* for  while (1) */
}

/*& *************************************************************************/
/*& ROUTINE-NAME:fmt_pre(out_buff,msg,fmt_token,out_idx,msg_idx)            */
/*& out_buff(char *):                                                       */
/*& msg(char *):                                                            */
/*& fmt_token(struct fmt_cvt):                                              */
/*& out_idx(int *):                                                         */
/*& msg_idx(int *):                                                         */
/*& RETURN-CODE: 0 -> normal                                                */
/*&              -1-> format preparation error                              */
/*& This routine will prepare the output buffer according output data &     */
/*& the format specified in the form file                                   */
/*& *************************************************************************/
fmt_pre(out_buff,msg,fmt_token,out_idx,msg_idx)
char *out_buff,*msg;
struct fmt_cvt *fmt_token;
int  *out_idx,*msg_idx;
{
   int i;

   UCP_TRACE(P_fmt_pre);

   switch(fmt_token->data_type) {
      case 'c':   /* in this case in_len = out_len */
               for (i=0;i < fmt_token->in_len; i++) {
                  if ( msg[*msg_idx] != 0 ) {
                     out_buff[*out_idx]=msg[*msg_idx];
                     (*out_idx) ++;
                     X_pos++;
                     X_abs++;
                  }
                  (*msg_idx) ++;
/*
                  if ( msg[*msg_idx] == 0 ) {
                     out_buff[*out_idx]=UN_PRINTABLE_CHAR;
                  }
                  else {
                     out_buff[*out_idx]=msg[*msg_idx];
                  }
                  (*out_idx) ++;
                  (*msg_idx) ++;
                  X_pos++;
                  X_abs++;
*/
               }
               break;
      case 'C':
               for (i=0;i < fmt_token->out_len; i++) {
                    out_buff[*out_idx]=fmt_token->cdata[i];
                    (*out_idx) ++;
                    X_pos++;
                    X_abs++;
               }
               break;
      case 'N':
               out_buff[*out_idx]='\n';
               (*out_idx) ++;
               Y_pos++;
               X_pos=0;
               break;
      case 'B': /* '{' form file beginning */
      case 'E': /* '}' form file ending */
      case 'D': /* the other form control information defined in form file */
               break;
      default :
               sprintf(g_caMsg,"fmt_pre:unsupported data type=%c",
                       fmt_token->data_type);
               ErrLog(200,g_caMsg,RPT_TO_LOG,0,0);
               UCP_TRACE_END(-1);
   }
   UCP_TRACE_END(0);
}


/*& *************************************************************************/
/*& ROUTINE-NAME:get_n_token()                                              */
/*& RETURN-CODE: integer -> the value of the token get from form file       */
/*&              -1 -> number get error                                     */
/*& This routine will get an integer from input file                        */
/*& *************************************************************************/
get_n_token()
{
  char n_buff[6];
  int  i;
  char ch;

  UCP_TRACE(P_get_n_token);
  ch=form_getc(1);
  if ( (ch > '9') || (ch < '0') ) {
     UCP_TRACE_END(-1);
  }
  i=0;
  while ( (ch <='9') && (ch >='0') ) {
     if ( i == 5 ) {
        UCP_TRACE_END(-1);
     }
     else {
        n_buff[i++]=ch;
     }
     ch=form_getc(1);
  }
  form_getc(-1);   /* unget the token character */
  n_buff[i]='\0';
  UCP_TRACE_END(atoi(n_buff));
}

/*& *************************************************************************/
/*& ROUTINE-NAME:get_c_token()                                              */
/*& RETURN-CODE: char -> the character get from input file                  */
/*&              -1 -> number character error                               */
/*& This routine will get a character from input file                       */
/*& *************************************************************************/
get_c_token()
{
  UCP_TRACE(P_get_c_token);
  UCP_TRACE_END(form_getc(1));
}

/*& *************************************************************************/
/*& ROUTINE-NAME:form_getc(offset)                                          */
/*& offset(int) :read character forward of backward                         */
/*&              offset = 9999 -> reset token buffer & token buffer index   */
/*& RETURN-CODE: char -> the character get from input file                  */
/*&              -1 -> number character error                               */
/*& This routine will get a character from input file                       */
/*& *************************************************************************/
form_getc(offset)
int offset;
{
 static char fmt_buff[MAX_LINE_LEN];
 static int  fmt_idx=-1;
 /*static char fst_chinese='0';*/

 UCP_TRACE(P_form_getc);

   /*sprintf(g_caMsg,"form_getc:fmt_idx=%d, offset=%d ",fmt_idx, offset);
   ErrLog(200,g_caMsg,RPT_TO_LOG,0,0); */

   if ( offset == 9999 ) {   /* reset token buffer and its index */
      fmt_idx=-1;
      memset(fmt_buff,'\0',MAX_LINE_LEN);
      UCP_TRACE_END(0);
   }
   /* the following if read a string into format buffer */
   if ( (fmt_idx <=0) && (offset == -1) ) {
      UCP_TRACE_END(-2);
   }
   fmt_idx+=offset;
/*  if read index had been in the end of the buffer OR in the initial */
/*  situation,(fmt_idx=-1 && offset = 1 ) , we get a new line from the form */
/*  file,if read backward to cause fmt_idx = 0, we don't read a new line  */
/*  i.e. when (fmt_idx = 1 , offset = -1 )				 */
   if ( (fmt_idx == strlen(fmt_buff)) || (fmt_idx == 0 && offset>=0) ) {
      if ( fgets(fmt_buff,MAX_LINE_LEN,form_fp) == NULL) {
         if ( feof(form_fp) ) {
            UCP_TRACE_END(-1);
         }
         else {
            UCP_TRACE_END(-2);
         }
      }
      else {
         /*sprintf(g_caMsg,"form_getc:dump fmt_buff");
         ErrLog(200,g_caMsg,RPT_TO_LOG,fmt_buff,strlen(fmt_buff)); 
         sprintf(g_caMsg,"form_getc:return fmt_buff[%d]=%c",
                 fmt_idx,fmt_buff[fmt_idx]);
         ErrLog(200,g_caMsg,RPT_TO_LOG,0,0); */
         fmt_idx=0;
         set_chinese_flag(fmt_buff,fmt_idx);
         UCP_TRACE_END(fmt_buff[fmt_idx]);
      }
   }
   else {
      /*sprintf(g_caMsg,"form_getc:return fmt_buff[%d]=%c",
              fmt_idx,fmt_buff[fmt_idx]);
      ErrLog(200,g_caMsg,RPT_TO_LOG,0,0); */
      set_chinese_flag(fmt_buff,fmt_idx);
      UCP_TRACE_END(fmt_buff[fmt_idx]);
   }
}

/*& *************************************************************************/
/*& ROUTINE-NAME:set_chinese_flag(buff,pos)                                 */
/*& buff(char *):the character buffer to be scaned                          */
/*& pos(int)    :the position of the input buffer to be determined if the   */
/*&              second byte of a Chinese code                              */
/*& RETURN-CODE: none                                                       */
/*& This routine will set a global variable sec_chinese, if the character   */
/*& specified by pos in buff is the 2nd byte of a Chinese code, set         */
/*& sec_chinese to 1 else set it to 0                                       */
/*& *************************************************************************/
set_chinese_flag(buff,pos)
char *buff;
int   pos;
{
 int i;
 /*char fst_chinese;*/

 fst_chinese=0;
 for (i=0;i<=pos;i++) {
   if ( fst_chinese == 0 ) {
      if (buff[i] & 0x80) {
        fst_chinese = 1;
        sec_chinese = 0;
      }
      else {
        sec_chinese = 0;
      }
   }
   else {
      fst_chinese = 0;
      sec_chinese = 1;
   }
 }
}

/****************************************************************************/
d_write(dev_type,out_buff,dev_fp)
char dev_type;
char *out_buff;
int  dev_fp;
{
  int i,j,rc;
  char out_temp[MAX_LINE_LEN];

  UCP_TRACE(P_d_write);

  switch(ld_to_pd(dev_type)) {
    case PSCRN_DEV:
                   if ( i == 0 ) {
                      UCP_TRACE_END(0);
                   }
/*
                   raw_off();
                   t_puts(out_buff);
                   raw_on();
*/
                   break;
    case PLINE_DEV:
                   break;
    case PJOUR_DEV:
                   break;
    case PPASS_DEV:i=strlen(out_buff);
                   if ( i == 0 ) {
                      UCP_TRACE_END(0);
                   }
#ifdef IBM4748
                   j=0;
                   for ( i=0; i<strlen(out_buff); i++ ) {           /*insert 0x0d   */
                      if ( (out_temp[j++]=out_buff[i]) == 0x0a ) {  /*after encount */
                                                                    /*0x0a in output*/
                           out_temp[j++]=0x0d;                      /*data for 4748 */
                      }
                                     }
                   out_temp[j] = '\0' ;
/*
                   pptr_print(out_temp,strlen(out_temp));    
*/
#else
/*                 big_2_ns(out_buff);     /x for NCR 5025C chinese transfer x/
                   ErrLog(2000,"out_buff is",RPT_TO_LOG,out_buff,strlen(out_buff));
                   pptr_print(out_buff,strlen(out_buff));                     */
#endif
                   break;
    case PMSR_DEV :
                   break;
    case PFILE_DEV:
                   write(dev_fp,out_buff,strlen(out_buff));
                   break;
    case BTFILE_DEV:
                   rc=write(dev_fp,out_buff,strlen(out_buff));
	           UCP_TRACE_END(rc);
    default       :UCP_TRACE_END(-1);
  }
  UCP_TRACE_END(0);
}

/*& **************************************************************************/
/*& ROUTINE NAME:ld_to_pd(dev_type)                                          */
/*& dev_type(char):the logical device of the application program requested   */
/*& RETURN_CODE   :return the corresponding physical devicr to the calling   */
/*&                routine.                                                  */
/*&                -1 -> unmapped logical device                             */
/*& this routine map the logical device to the physical device               */
/*& **************************************************************************/
ld_to_pd(dev_type)
char dev_type;
{
  UCP_TRACE(P_ld_to_pd);

  switch(dev_type) {
           /* physical device is screen output */
      case D_DISPLAY       :        /* DISPLAY device */
      case D_PGUPDN        :        /* DISPLAY UP/DOWN device */
                            UCP_TRACE_END(PSCRN_DEV);
                 /* physical device is line printer */
/*
      case D_REPORT        :
                            UCP_TRACE_END(PLINE_DEV);
*/
                 /* physical device is journal device */
      case D_JOURNAL       :
                            UCP_TRACE_END(PJOUR_DEV);
                 /* physical device is passbook printer */
      case D_PASSBOOK      :
      case D_REPORT        :
      case D_DOCUMENT      :
      case D_DOCUMENT_LG   :
      case D_SLIP          :
      case D_DCUM_LGST     :
      case D_DCUM_SLIP     :
      case D_DCUM_SLIP1    :
      case D_DCUM_SLIP2    :
      case D_TM_USE        :
      case D_TM_USE_REV    :
      case D_TM_USE_TR     :
      case D_PASSBOOK_LN   :
      case D_DCUM_SLIP_LN  :
      case D_DOCUMENT_EXIT :
                            UCP_TRACE_END(PPASS_DEV);
                 /* physical device is megnestic strip reader */
      case D_MSR           :
      case D_MSROUT        :
                            UCP_TRACE_END(PMSR_DEV);
                 /* physical device is disk file */
      case D_FILE          :
                            UCP_TRACE_END(PFILE_DEV);
                 /* physical device is batch file output */
      case D_BTFILE          :
                            UCP_TRACE_END(BTFILE_DEV);
                 /* undefined physical device */
      default :
           sprintf(g_caMsg,"ld_to_pd:device type(%c) error",dev_type);
           ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
           UCP_TRACE_END(-1); /* device type error */
  }
}


unfmt_out(dev_type,msg,chg_dev,dev_fp)
char *dev_type;
char *msg;
char chg_dev;
int  dev_fp;
{
}

/* ----------------------------------------------------------------- */
/*         data format parsing                                       */
/* ----------------------------------------------------------------- */
dfmt_parse()
{

     UCP_TRACE(P_dfmt_parse);
           nch = form_getc(1) ; /* look ahead one token.                */
           switch(nch) {
               case 'c' :    /* a character data type.               */
               case 'C' :    /* a character data type.               */
                    digit_1 = get_dleng() ;
                    UCP_TRACE_END(0);
               case '[' :    /* single character data type.          */
               case ' ' :
               case '\n':
               case '}' :
                    digit_1 = 1 ;
                    form_getc(-1) ; /* look ahead one token.     */
                    UCP_TRACE_END(0);
               default  :           /* single character data type.   */
                    if((nch >= ' ' && nch <= '~') || (sec_chinese ==1)|| (fst_chinese ==1) ){
                      digit_1 = 1 ;
                      form_getc(-1) ; /* look ahead one token.     */
                      UCP_TRACE_END(0);
		    }
                    else
                      UCP_TRACE_END(-1);
           }
}

/* ----------------------------------------------------------------- */
/*         get data length                                           */
/* ----------------------------------------------------------------- x/
   sementic :
          1>. (n)]       eg. [C(6)]
          2>. ()]        eg. [C()]
          3>. ]          eg. [C]

                     __(()__(n)__())__
                    /                 \
           --------<                   >-----(])-----
                 \  \____(()___())____/  /
                  \_____________________/

        return_code: NOT OK-> D_NUMBER_ERR:(-6)  define number err
                           -> D_LENGTH_ERR:(-5)  define length err
                     OK    -> THE DEFINE LENGTH
/x ----------------------------------------------------------------- */
int get_dleng()
{
    
    UCP_TRACE(P_get_dleng);
       switch(nch = form_getc(1)) {
           case '(' :
                UCP_TRACE_END(get_number()) ;
           case ']' :
                UCP_TRACE_END(1) ;  /* default data length = 1.      */
           default  :
                if (nch >= '0' && nch <= '9'){
                    UCP_TRACE_END(get_number()) ;
                }
                else {
                    UCP_TRACE_END(D_LENGTH_ERR) ;
                }
       }
}
/* ----------------------------------------------------------------- */
/*         evaluate the value of numerical string.                   */
/* ----------------------------------------------------------------- x/
   sementic :
          1>. (n)]       eg. [C(6)]
          2>. ()]        eg. [C()]
                     _________________
                    /                 \
              -----<                   >-----
                    \__(()__(n)__())__/
        return_code: NOT OK-> D_NUMBER_ERR:(-6)  define number err
                     OK    -> THE DEFINE LENGTH
/x ----------------------------------------------------------------- */
int get_number()
{
       static
       char  num_string[4] ;
       char  i = 0 ;                   /* point to num_string.       */
    UCP_TRACE(P_get_number);

    if (nch == '(')   { 
       nch = form_getc(1) ;
       if (nch == ')'){
           UCP_TRACE_END(1) ;                  /* default data length = 1.   */
       }
       else {
           if (nch >= '0' && nch <='9'){
               do {
                   num_string[i++] = nch ;
               } while ((nch=form_getc(1)) >= '0' && nch <= '9' && i < 3);
           }
           num_string[i] = '\0' ;
           if ( (nch == ')') && (form_getc(1) == ']') ) {
               UCP_TRACE_END(atoi(num_string)) ;
           }
           else {
               UCP_TRACE_END(D_NUMBER_ERR) ;
           }
       }
    }
    else if (nch >= '0' && nch <='9') {
               do {
                   num_string[i++] = nch ;
               } while ((nch=form_getc(1)) >= '0' && nch <= '9' && i < 3);
              num_string[i] = '\0' ;
	      if ( nch == ' ')    {
                   do { 
                      nch = form_getc(1); 
                   }  while ( nch == ' ' );
              }
	      if ( nch == ']') {  UCP_TRACE_END(atoi(num_string)) ;  }
              else {
                  UCP_TRACE_END(D_NUMBER_ERR) ;
              }
    }
    else { UCP_TRACE_END(D_NUMBER_ERR) ; }
}


form_feed(dev_type,dev_fp)
char dev_type;
int  dev_fp;
{
  int  rc;
  
  UCP_TRACE(P_form_feed);

  switch(ld_to_pd(dev_type)) {
    case PSCRN_DEV:
/*
 		   b_msg_rtn("before form feed !!\n");
                   clr_scrn();
 		   b_msg_rtn("after form feed !!!\n");
                   break; 
*/
    case PLINE_DEV:
                   break;
    case PJOUR_DEV:
                   break;
    case PPASS_DEV:
/*
                   pptr_print("\f",strlen("\f"));                     
*/
                   break;
    case PMSR_DEV :
                   break;
    case PFILE_DEV:
/*
                   write(dev_fp,"\f",strlen("\f"));
*/
                   break;
    case BTFILE_DEV:
                   rc=write(dev_fp,"\f",strlen("\f"));
                   UCP_TRACE_END(rc);
    default       :UCP_TRACE_END(-1);
  }
  UCP_TRACE_END(0); 
}

get_1char(dataptr,dataleng,dataleng_used)
char *dataptr;
int  dataleng,*dataleng_used;
{
  unsigned char ch;

  UCP_TRACE(P_get_1char); 
  if( *dataleng_used < dataleng){
    ch = *(dataptr + *dataleng_used);
    *dataleng_used = *dataleng_used + 1;
  }
/*
  else{
  eof_exit();
  }
*/
  UCP_TRACE_END(ch);
}

counter_add(adder,ch)
int *adder;
char ch;
{
  UCP_TRACE(P_counter_add); 
  *adder = (*adder * 10) + (ch - '0');
  UCP_TRACE_END(0);
}

unget_1char(dataleng_used)
int  *dataleng_used;
{
  unsigned char ch;

  UCP_TRACE(P_unget_1char); 
  if( *dataleng_used > 0){
    *dataleng_used = *dataleng_used - 1;
  }
  else{
  UCP_TRACE_END(-1);
  }
  UCP_TRACE_END(0);
}
