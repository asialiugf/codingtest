/*
 *&N& File : tmstwast.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int       StSysVal()             �t�ΰѼƪ�ȳ]�w
 *&N&    int       SetServerId()          �N TPU ���Ĥ@�ӰѼƳ]�w�� pcServerId
 *&N&    int       SetSysMode()           �N TPU ���ĤG�ӰѼƳ]�w�� cSysMode
 *&N&    char *    GetServerId()          �Ǧ^ TPU ���Ĥ@�ӰѼ�
 *&N&    char      GetSysMode()           �Ǧ^ TPU ���ĤG�ӰѼ�
 *&N&    int       InitTWA()              �]�w TWA �����
 *&N&    int       SetTmaBySif()          ��SIF���Y�]�wTMA�����ܼƭ�  
 */

/* ------------------------- INCLUDE FILES ---------------------------- */
#include <string.h>
#include "errlog.h"
#include "ucp.h"
#include "twa.h"
#include "cwa.h"
#include "tms.h"
#include "tmcenv.h"
#include "tmcpgdef.h"	/* TMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */

/* ------------------------- CONSTANT DEFINITION ---------------------- */
/* tmstwast.c 
#define P_StSysVal 		21401
#define P_SetServerId 		21402
#define P_SetSysMode 		21403
#define P_GetServerId 		21404
#define P_GetSysMode 		21405
#define P_InitTWA 		21406
#define P_SetTmaBySif           21407 
#define P_SetTmaByApaOut        21408  
*/

#define RCV_ERR                 '0'
#define RCV_OK                  '1' 

/* ------------------ EXTERN VARIABLE DECLARATION --------------------- */
extern struct APA *g_pstApa;
extern struct TMA *g_pstTma;
extern struct TBA *g_pstTba;

/* ------------------ STATIC VARIABLE DECLARATION --------------------- */
static char *sg_pcServerId; /* sg_pcServerId ���ŧi�b�t TPU �D�{�����ɸ�  */
static char sg_cSysMode;    /* sg_cSysMode ���ŧi�b�t TPU �D�{�����ɸ�  */
extern int g_iDbtKey;
extern int g_iTxnCodeLen;   /* txn code real length    */
extern int g_iBrhCodeLen;   /* branch code real length */
extern int g_iTmCodeLen;    /* term code real length   */
extern char g_cRcvRmtDataFlag;
extern char g_cLastQryFlag;
extern int g_iErrLogSize;
extern char g_cRqtApiBeenCalled; /* Added by Willy 1996/10/18 */

/* PTM TPEUNIX980510 : Add 1 line by Hu Chunlin, June 1st, 1998 */
extern int	g_iTmaTermno;
/*--------- CALLED FUNCTION & SUBROUTINE PROTOTYPE DECLARATIONS ------*/
char *GetServerId();
char GetSysMode();

/*
 *&N& ROUTINE NAME: StSysVal()
 *&A& ARGUMENTS:
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&   ����ƥΥH�]�w TPU �������Ҥ��u�ݳ]�w�@�����t�ΰѼƭ�:
 *&D&           �t�ΰѼ�                      ��
 *&D&   -------------------------------------------------------------
 *&D&       stTSSA.caServerId          �� TPU �Ұʮɪ� argument1 �M�w
 *&D&       stTSSA.sSysStatus          pstSsa->sSysStatus
 *&D&       stTSSA.cSysMode            �� TPU �Ұʮɪ� argument2 �M�w
 *&D&       stTSSA.cSystemRole         pstSsa->cSystemRole
 *&D&       stTSSA.cSysOperatingMod    pstSsa->cSysOperatingMod
 *&D&       stTSSA.sNextDayCnt         pstSsa->sNextDayCnt
 *&D&       stTSSA.caTxnDate           pstSsa->caTxnDate
 *&D&       stTSSA.caNextTxnDate       pstSsa->caNextDate
 *&D&       stTSSA.caNext2Date         pstSsa->caNext2Date
 *&D&
 *&D&   �U�C���Τ��@,�|�Ϧ���ư��楢��
 *&D&     1. �ǵ� TPU �� argument1, ���׶W�L stTSSA.caServerId �}�C���j�p
 */

int
StSysVal()
{
  int iRc;
  char *pcId;
  struct SSA *pstSsa;
  struct CwaCtl stCwaCtl;

  UCP_TRACE( P_StSysVal );

  pcId = GetServerId();
  if (sizeof( *pcId ) <= sizeof( g_pstTma->stTSSA.caServerId )) {
    strcpy( g_pstTma->stTSSA.caServerId, pcId );
  }
  else {
    sprintf( g_caMsg, "StSysVal: Server Id (%s) size too long!", pcId );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( SET_SYS_VAL_ERR, g_caMsg );
    UCP_TRACE_END( SET_SYS_VAL_ERR );
  }

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac( &stCwaCtl, &pstSsa );

  if ( iRc != CWA_NORMAL ) {
    ErrLog( 1000, "StSysVal: Get SSA ptr Fail!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( GET_SSA_PTR_ERR );
  }

  g_pstTma->stTSSA.sSysStatus = pstSsa->sSysStatus ;
  g_pstTma->stTSSA.cSysMode           = GetSysMode();
  g_pstTma->stTSSA.cSystemRole        = pstSsa->cSystemRole;
  g_pstTma->stTSSA.sNextDayCnt        = pstSsa->sNextDayCnt;
/* ----- mark by chi-fu-song 1994/12/09 ------ 
  memcpy( g_pstTma->stTSSA.caTxnDate, pstSsa->caTxnDate     , DATE_LEN );
  memcpy( g_pstTma->stTSSA.caNextTxnDate, pstSsa->caNextDate, DATE_LEN );
  memcpy( g_pstTma->stTSSA.caNext2Date, pstSsa->caNext2Date , DATE_LEN );
---------- BY BRH_CODE to set 3 dates in SteTmaBySif() -------------- */

 /* 
  *  �������Ҥ��u���]�w�@�����t�ΰѼƭ� 
  */
  g_pstTma->stTSSA.cTmType         = TMS_36_47_TM;
  g_pstTma->stTSSA.cReentryStatus  = TMS_TXN_NOT_REENTRY;
  g_pstTma->stTCFA.cRevTxn         = TMS_TXN_NOT_REVERSE;
  g_pstTma->stTCFA.cApReturnCode   = TMS_AP_ACC_NORMAL;
  g_pstTma->stTCFA.cInDataType     = GENERAL_TXN;
  g_pstTma->stTCFA.cTxnReinput     = TMS_TXN_REINPUT_OFF;
  g_pstTma->stTCFA.cRendoRequest   = TMS_TXN_NOT_RENDO;
  g_pstTma->stTCFA.cTpeWriteMsgKind  = TMS_RCV_AP_NORMAL_MSG;
  g_pstTma->stTCFA.cRvsApRdLogFlag  = TMS_RVSAP_HAS_NOT_BEEN_RD_LOG;
  g_pstTma->stTCFA.cRevContinue = TMS_REV_CONTINUE_OFF;
  /* added by WuChihLiang 19950317 for JCL -- BEGIN */
  g_pstTma->stTCFA.cBatApRtnCode   = TMS_AP_ACC_NORMAL;
  /* added by WuChihLiang 19950317 for JCL -- END   */

  /* PTM TPEUNIX980510 : Add 1 line by Hu Chunlin, June 1st, 1998 */
  g_iTmaTermno = 0;

  memset(g_pstApa,' ', MAX_APA_LEN);
  memset(g_pstTba->caCtf, 0, MAX_CTF_LEN);
  memset(g_pstTba->caSif, 0, MAX_SIF_LEN);
  memset(g_pstTba->caRev, 0, MAX_REV_LEN);
  memset(g_pstTba->caRendo, 0, MAX_SIF_LEN);
  memset(g_pstTba->caPost, 0, MAX_TBA_POST_LEN);
  memset(g_pstTba->caMsgp, 0, MAX_MSGP_LEN);
  memset(g_pstTba->caPara, 0, MAX_TBA_PARA_LEN);

 /* 
  *  set DBT shm Key to TWA.TSSA.iDbtShmId
  */
  g_pstTma->stTSSA.iDbtShmId = g_iDbtKey;
  
  /* added by WuChihLiang 19960528 for setting tms_errlog size */
  g_pstTma->stTSSA.iErrLogSize = g_iErrLogSize;

  UCP_TRACE_END( 0 );
}

/*
 *&N& ROUTINE NAME: SetServerId()
 *&A& ARGUMENTS:
 *&A&     NAME                TYPE                  DESCRIPTION
 *&A&   ----------------------------------------------------------------
 *&A&    pcId                char *              TPU ���Ĥ@�ӰѼ�
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    �L
 *&R&
 *&D& DESCRIPTION:
 *&D&   ����ƱN TPU ���Ĥ@�ӰѼƳ]�w�� static global var: sg_pcServerId
 *&D&   ( sg_pcServerId �ŧi�b�t TPU �D�{�����ɸ� )
 */

int
SetServerId( pcId )
char *pcId;
{
  UCP_TRACE( P_SetServerId );

  sg_pcServerId = pcId;
 
  UCP_TRACE_END( 0 );
}

/*
 *&N& ROUTINE NAME: SetSysMode()
 *&A& ARGUMENTS:
 *&A&     NAME                TYPE                  DESCRIPTION
 *&A&   --------------------------------------------------------------
 *&A&     cMode                char               TPU ���Ĥ@�ӰѼ�
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    �L
 *&R&
 *&D& DESCRIPTION:
 *&D&   ����ƱN TPU ���ĤG�ӰѼƳ]�w�� static global var: sg_cSysMode
 *&D&   ( sg_cSysMode �ŧi�b�t TPU �D�{�����ɸ� )
 */
int
SetSysMode( cMode )
char cMode;
{
  UCP_TRACE( P_SetSysMode );
  sg_cSysMode = cMode;
  UCP_TRACE_END( 0 ); 
}

/*
 *&N& ROUTINE NAME: GetServerId()
 *&A& ARGUMENTS:
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&   ���� TPU ���Ĥ@�ӰѼƪ�����
 *&R&
 *&D& DESCRIPTION:
 *&D&   ����ƱN�Ǧ^ TPU ���Ĥ@�ӰѼ�
 */

char *
GetServerId()
{
  UCP_TRACE( P_GetServerId );
  UCP_TRACE_END( sg_pcServerId );
}

/*
 *&N& ROUTINE NAME: GetSysMode()
 *&A& ARGUMENTS:
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&   �@�Ӧr��
 *&R&
 *&D& DESCRIPTION:
 *&D&   ����ƱN�Ǧ^ TPU ���ĤG�ӰѼ�
 */
char
GetSysMode()
{
  UCP_TRACE( P_GetSysMode );
  UCP_TRACE_END( sg_cSysMode );
}

/*
 *&N& ROUTINE NAME: InitTWA()
 *&A& ARGUMENTS:
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&   �]�w TWA �����
 */

int
InitTWA()
{
  void InitCoptxFlag();
  UCP_TRACE( P_InitTWA );

/* marked for ��e��������ɥD���ݵL�k���T�a���@��e�Ǹ� */
/*  g_pstTma->stTSSA.cTmType         = TMS_36_47_TM;*/
/* marked for Reentry-Txn(Rendo type) by chi-fusong, 19950316 */
/*
  g_pstTma->stTSSA.cReentryStatus  = TMS_TXN_NOT_REENTRY;
*/
  g_pstTma->stTCFA.cApReturnCode   = TMS_AP_ACC_NORMAL;
  g_pstTma->stTCFA.cTxnReinput     = TMS_TXN_REINPUT_OFF;
  g_pstTma->stTCFA.cApAbendNoRlbk  = TMS_TXN_ABEND_NORLBK_OFF;
  g_pstTma->stTCFA.cApWriteLogFlag  = TMS_AP_HAS_NOT_BEEN_WRT_LOG;

  /* reset g_cRcvRmtDataFlag to RCV_ERR to approve Local Txn can output 
   * data normally.....
   */
  g_cRcvRmtDataFlag = RCV_ERR;
  g_cLastQryFlag = LAST_QRY_OFF;

/* To avoid calling APRQT or SCRQT twice in one AP flow 19961018 - Begin */
  g_cRqtApiBeenCalled = 0;
/* To avoid calling APRQT or SCRQT twice in one AP flow 19961018 - End */

  InitCoptxFlag();

  UCP_TRACE_END( 0 );
}


/*
 *&N& ROUTINE NAME: SetTmaBySif()
 *&A& ARGUMENTS:
 *&A& ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&
 *&D& DESCRIPTION:
 *&D& ����Ʀ�SIF��HEADER��,�N����N���B����N���B�ݥ��N���B�d���N���B
 *&D& ����r����,�]�w��TWA��TMA���۹諸�ܼơC
 *&D&  Sif��Header���c�p�U:
 *&D& �z�w�w�w�w�s�w�w�w�w�w�s�w�w�w�w�w�s�w�w�w�w�w�s�w�w�w�w�w�s�w�w�w�w�w�{
 *&D& �xTxnId[4]�xTxnCode[4]�xBrCode [3]�xTmCode[2] �xTellId[2] �xCtlData[1]�x
 *&D& �|�w�w�w�w�r�w�w�w�w�w�r�w�w�w�w�w�r�w�w�w�w�w�r�w�w�w�w�w�r�w�w�w�w�w�}
 */

int
SetTmaBySif()
{
  int iRc;
  struct BitBrhTermSt stBrhTerml;
  struct CwaCtl stCwaCtl;
  struct BrhArea *pstBrh;

  UCP_TRACE(P_SetTmaBySif);
  sprintf(g_caMsg,"<APD>BrhCodeLen=%d,TmCodeLen=%d,TxnCodeLen=%d",
          g_iBrhCodeLen,g_iTmCodeLen,g_iTxnCodeLen);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
  memcpy( g_pstTma->stTSSA.caTxnCode, g_pstTba->caSif + TXN_CODE_OFFSET,
          g_iTxnCodeLen );
  /* added for REVERSE-TXN seqno problem by chi fu-song, 1995/04/03 */
  if ( g_pstTma->stTCFA.cRevTxn != TMS_TXN_REVERSE &&
       g_pstTma->stTCFA.cRendoRequest != TMS_TXN_RENDO ) {
    memcpy( g_pstTma->stTSSA.caBrCode, g_pstTba->caSif + BR_CODE_OFFSET, 
            g_iBrhCodeLen );
    memcpy( g_pstTma->stTSSA.caTmCode, g_pstTba->caSif + TM_CODE_OFFSET,
            g_iTmCodeLen );
    memcpy( g_pstTma->stTSSA.caTellId, g_pstTba->caSif + TELLER_CODE_OFFSET, 
            TELLER_CODE_LEN );
    memcpy( &g_pstTma->stTSSA.sSifCtlData , &g_pstTba->caSif[ CTL_BYTE_OFFSET ],
          CTL_BYTE_LEN );
  }

  stCwaCtl.cFunCode = CWA_GET_BRH_PTR;
  memcpy(stCwaCtl.caBrhId, g_pstTma->stTSSA.caBrCode, g_iBrhCodeLen);
  memcpy(stCwaCtl.caTermId, g_pstTma->stTSSA.caTmCode, g_iTmCodeLen);
  iRc = CwaLowCtlFac(&stCwaCtl, &pstBrh);
  if ( iRc < 0 ) {
    /* the branch has not been registered in BIT */
    sprintf( g_caMsg, "SetTmaBySif: Branch not registered in BIT" );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( -1 );
  }
  memcpy( g_pstTma->stTSSA.caTxnDate, pstBrh->caTxnDate     , DATE_LEN );
  memcpy( g_pstTma->stTSSA.caNextTxnDate, pstBrh->caNxtTxnDate, DATE_LEN );
  memcpy( g_pstTma->stTSSA.caNext2Date, pstBrh->caNNxtTxnDate , DATE_LEN );
  sprintf(g_caMsg,
          "<APD>Date-1=%.*s ,Date-2=%.*s ,Date-3=%.*s",
          DATE_LEN,g_pstTma->stTSSA.caTxnDate,
          DATE_LEN,g_pstTma->stTSSA.caNextTxnDate,
          DATE_LEN,g_pstTma->stTSSA.caNext2Date);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

 /*  �{���q�|�� implement�C
  *  �p��q SIF �� control byte, �P�_ cRendoType �O�_���_���s�ʥ��
  *  g_pstTma->stTCFA.cTxnPattern     = LOCAL_TXN;
  */

  sprintf(g_caMsg,
          "### TXNCODE=%.*s BRCODE=%.*s TMCODE=%.*s TELLERCODE=%.*s ",
          g_iTxnCodeLen,g_pstTma->stTSSA.caTxnCode,
          g_iBrhCodeLen,g_pstTma->stTSSA.caBrCode,
          g_iTmCodeLen,g_pstTma->stTSSA.caTmCode,
          TELLER_CODE_LEN,g_pstTma->stTSSA.caTellId);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  UCP_TRACE_END(0);
}

