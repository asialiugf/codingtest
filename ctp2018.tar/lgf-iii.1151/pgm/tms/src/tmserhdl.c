
/*
 *&N& File: tmserhdl.c  ����޲z�l�t�ΥD�{��
 *&N&   
 *&N&    TYPE      NAME                 DESCRIPTION
 *&N& --------- ---------- ---------------------------------------- 
 *&N&    int       TmsErrHdl    ����޲z�l�t�ο��~�B�z�{��
 *&N&    int       ErrorMap     ����޲z�l�t�ο��~�X�ഫ�{��
 *&N&
 */


/* ---------------------- INCLUDE FILES DECLARATION ------------------- */
#include	"twa.h"
#include	"tms.h"
#include	"errlog.h"
#include "tmcpgdef.h"	/* TMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */
#include "tmcerror.h"	/* TMS ���~�T�� */


/* ------------------------- CONSTANT DEFINITION ---------------------- */
#define         PRG_ID_LEN                  5
#define         RET_CODE_LEN                2
#define         ROLLBACK_FLAG              '1'

#define         NO 			    0
#define         YES 			    1

/* ------------------------- GLOBAL & EXTERN VARIABLE ------------------ */
char g_caToDbpErrCode[10];
extern char g_cErrActFlag;
extern struct TMA *g_pstTma;
extern int g_iTmCodeLen;
extern int g_iBrhCodeLen;
extern int g_iMsgpFileFd;
extern int g_iMemFileFd;
extern char g_cFlushMemToFileFlag;
extern char g_cNeedRelseTrm;

/* ------------------------- FUNCTION PROTYPE -------------------------- */
void TmsErrHdl(char,int);
void ErrorMap(char,int);
void ErrorAction();
int IsMultipleDataEnd();
int IsListDataEnd();
extern int TrmRelease();

/*Added by baiyj on 1998/10/06 for W000086 begin*/
extern struct TBA *g_pstTba;
extern int  g_iTmaTermno;
/*Added by baiyj on 1998/10/06 for W000086 end*/

void
TmsErrHdl( char cL2Step , int iRc )
{
  if(g_iMsgpFileFd > 0) {
    close(g_iMsgpFileFd);
    g_iMsgpFileFd=-1;
  }

  if(g_iMemFileFd > 0) {
    close(g_iMemFileFd);
    g_iMemFileFd=-1;
    g_cFlushMemToFileFlag='n';
  }
  
  ErrorMap( cL2Step, iRc );
  ErrorAction();
}

void
ErrorMap( char cL2Step , int iRc )
{
  char *pcPrgIdStr;
  char caErrorCode[10];
  char caIrcBuf[10];
  int  iPrgIdVal;              /* iPrgIdVal = atoi(pcPrgIdStr) */
  int  iAbsIrc;                /* iAbsIrc = abs(iRc)           */

  memset( caErrorCode, 0, 10);
  memset( g_caToDbpErrCode, 0, 10);
  memset( caIrcBuf, 0, 10);
/*  Modified by WuChihLiang 19950510 for 7 bytes message  code */
  if (g_pstTma->stTSSA.cSystemRole == CENTER_HOST){
    g_caToDbpErrCode[0] = 'H'; 
  }else{
    g_caToDbpErrCode[0] = 'B'; 
  }
  memcpy( g_caToDbpErrCode+1, "UX", 2);
/*
  and
             memcpy(g_caToDbpErrCode,INIT_CNF_TBL_ERR_E,4); 
     --->    memcpy(g_caToDbpErrCode+3,INIT_CNF_TBL_ERR_E,4); 
*/
  if ( cL2Step == '0' ) {
    pcPrgIdStr = (char *) GetPrgId( 0 );
  }
  else {
    pcPrgIdStr = (char *) GetPrgId( 1 );
  }
  
  iPrgIdVal = atoi(pcPrgIdStr);
  iAbsIrc = abs(iRc);
  memcpy(caErrorCode , pcPrgIdStr, PRG_ID_LEN);
  sprintf(caIrcBuf,"%.2d", iAbsIrc );
  strncat(caErrorCode, caIrcBuf, RET_CODE_LEN);

  /*
  printf("ErrorMap-------iPrgIdStr------%s-------\n",caErrorCode);
  printf("ErrorMap-------iPrgIdVal------%d-------\n",iPrgIdVal);
  printf("ErrorMap-------iAbsIrc------%d-------\n",iAbsIrc);
  */

  switch ( iPrgIdVal ) {
    case P_GetConfg:
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode+3,INIT_CNF_TBL_ERR_E,4); 
             break; 
           case 2:
             memcpy(g_caToDbpErrCode+3,GET_CWAKEY_ERR_E,4); 
             break;
           case 3:
             memcpy(g_caToDbpErrCode+3,GET_CTFKEY_ERR_E,4);
             break;
           case 4:
             memcpy(g_caToDbpErrCode+3,GET_ICTKEY_ERR_E,4);
             break;
           case 5:
             memcpy(g_caToDbpErrCode+3,GET_IETKEY_ERR_E,4);
             break;
           case 6:
             memcpy(g_caToDbpErrCode+3,GET_DBTKEY_ERR_E,4);
             break;
           case 7:
             memcpy(g_caToDbpErrCode+3,GET_SYSOPMODE_ERR_E,4);
             break;
           case 8:
             memcpy(g_caToDbpErrCode+3,GET_TESTMODE_ERR_E,4);
             break;
           case 9:
             memcpy(g_caToDbpErrCode+3,GET_MAXPACKETSIZE_ERR_E,4);
             break;
           case 10:
             memcpy(g_caToDbpErrCode+3,GET_TMAX_ERR_E,4);
             break;
           case 11:
             memcpy(g_caToDbpErrCode+3,GET_TMIN_ERR_E,4);
             break;
           case 12:
             memcpy(g_caToDbpErrCode+3,GET_TOFFSET_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         g_cErrActFlag = g_cErrActFlag | INFORM_EMS_FLAG;
         break;

    case P_GetSysRs:
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode+3,COB_INIT_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode+3,SIGNAL_HDL_ERR_E,4);
             break;
           case 3:
             memcpy(g_caToDbpErrCode+3,GET_TWA_TWACTLFAC_ERR_E,4);
             break;
           case 4:
             memcpy(g_caToDbpErrCode+3,GETPTRFROMTWA_TMA_ERR_E,4);
             break;
           case 5:
             memcpy(g_caToDbpErrCode+3,GETPTRFROMTWA_COA_ERR_E,4);
             break;
           case 6:
             memcpy(g_caToDbpErrCode+3,GETPTRFROMTWA_APA_ERR_E,4);
             break;
           case 7:
             memcpy(g_caToDbpErrCode+3,GETPTRFROMTWA_TBA_ERR_E,4);
             break;
           case 8:
             memcpy(g_caToDbpErrCode+3,INIT_SYNC_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         g_cErrActFlag = g_cErrActFlag | INFORM_EMS_FLAG;
         break;

    case P_GetKernl:
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode+3,ACCESS_CWA_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode+3,GET_TCT_ERR_E,4);
             break;
           case 3:
             memcpy(g_caToDbpErrCode+3,ATTCH_CTF_ERR_E,4);
             break;
           case 4:
             memcpy(g_caToDbpErrCode+3,ATTCH_ICT_ERR_E,4);
             break;
           case 5:
             memcpy(g_caToDbpErrCode+3,ATTCH_IET_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         g_cErrActFlag = g_cErrActFlag | INFORM_EMS_FLAG;
         break;

    case P_AttIfEnv:
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode+3,ATT_IF_ENV_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         g_cErrActFlag = g_cErrActFlag | INFORM_EMS_FLAG;
         break;

    case P_StSysVal:
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode+3,SET_SYS_VAL_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode+3,GET_SSA_PTR_ERR_E23,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         g_cErrActFlag = g_cErrActFlag | INFORM_EMS_FLAG;
         break;

    case P_InitSysEnv:
         switch ( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode+3,RESET_SYNC_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         g_cErrActFlag = g_cErrActFlag | DO_ABEND_FLAG;
         g_cErrActFlag = g_cErrActFlag | INFORM_EMS_FLAG;
         break;

    case P_IniIfEnv:
         switch ( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode+3,INIT_IF_ENV_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         g_cErrActFlag = g_cErrActFlag | DO_ABEND_FLAG;
         g_cErrActFlag = g_cErrActFlag | INFORM_EMS_FLAG;
         break;

    case P_TxKind 		:
         switch ( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode+3,TXINPUT_TYPE_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         break;

    case P_SeqIntIn 		: 
         switch ( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode+3,GET_SEQINT_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         break;

    case P_TxInput              :  /* add for SIF too long error by zh */ 
         switch ( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode+3,INPUTCNV_SIF_LEN_OVERFLOW_ERR_E,4);
             break;
           case 3:
             memcpy(g_caToDbpErrCode+3,GET_SSA_PTR_ERR_E128,4);
             break;
           case 4:
             memcpy(g_caToDbpErrCode+3,TXN_ENABLE_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         g_cErrActFlag = g_cErrActFlag | INFORM_DBP_FLAG;
         break;

    case P_GetInput 		: 
         switch ( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode+3,GET_INPUT_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         g_cErrActFlag = g_cErrActFlag | DO_ABEND_FLAG;
         g_cErrActFlag = g_cErrActFlag | INFORM_EMS_FLAG;
         break;

    case P_InputCnv 		:
         switch ( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode+3,INPUT_CNV_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode+3,INPUTCNV_SIF_LEN_OVERFLOW_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         break;

    case P_InputChk 		: 
         switch ( iAbsIrc ) {
           case 1: 
             memcpy(g_caToDbpErrCode+3,CHK_TERML_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode+3,REENTRY_CHK_ERR_E,4);
             break;
           case 3: 
             memcpy(g_caToDbpErrCode+3,CHK_REENTRY_TM_E,4);
             break;
           case 4: 
             memcpy(g_caToDbpErrCode+3,CHK_ONLINE_TM_E,4);
             break;
           case 5: 
             memcpy(g_caToDbpErrCode+3,TERMINAL_IS_ON_USE_ERR_E,4);
             break;
           case 6:
             memcpy(g_caToDbpErrCode+3,LOCK_TCT_ERR_E,4);
             break;
           case 7:
             memcpy(g_caToDbpErrCode+3,UNLOCK_TCT_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         break;

    case P_InputEdt 		: 
         switch ( iAbsIrc ) {
           case 1: 
             memcpy(g_caToDbpErrCode+3,INPUT_EDT_BUSI_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode+3,INPUT_EDT_TXN_ERR_E,4);
             break;
           case 3:
             memcpy(g_caToDbpErrCode+3,INPUT_EDT_ITM1_ERR_E,4);
             break;
           case 4:
             memcpy(g_caToDbpErrCode+3,INPUT_EDT_ITMn_ERR_E,4);
             break;
           case 5:
             memcpy(g_caToDbpErrCode+3,GET_SIF_FMT_ERR_E,4);
             break;
           case 6:
             memcpy(g_caToDbpErrCode+3,GET_CTF_DESC_ERR_E,4);
             break;
           case 7:
             memcpy(g_caToDbpErrCode+3,EDIT_ITEM_LEN_ERR_E,4);
             break;
           case 8:
             memcpy(g_caToDbpErrCode+3,COMP3_CNV_ERR_E,4);
             break;
           case 9:
             memcpy(g_caToDbpErrCode+3,SHORT_CNV_ERR_E,4);
             break;
           case 10:
             memcpy(g_caToDbpErrCode+3,LONG_CNV_ERR_E,4);
             break;
           case 11:
             memcpy(g_caToDbpErrCode+3,ASI_CNV_ERR_E,4);
             break;
           case 12:
             memcpy(g_caToDbpErrCode+3,ASCII_CNV_ERR_E,4);
             break;
           case 13:
             memcpy(g_caToDbpErrCode+3,SASCII_CNV_ERR_E,4);
             break;
           case 14:
             memcpy(g_caToDbpErrCode+3,CTF_TO_SIF_BUSI_ERR_E,4);
             break;
           case 15:
             memcpy(g_caToDbpErrCode+3,CTF_TO_SIF_TXN_ERR_E,4);
             break;
           case 16:
             memcpy(g_caToDbpErrCode+3,CTF_TO_SIF_ITM1_ERR_E,4);
             break;
           case 17:
             memcpy(g_caToDbpErrCode+3,CTF_TO_SIF_ITMn_ERR_E,4);
             break;
           case 18:
             memcpy(g_caToDbpErrCode+3,CTF_TO_SIF_CNV_ITM1_ERR_E,4);
             break;
           case 19:
             memcpy(g_caToDbpErrCode+3,CTF_TO_SIF_CNV_ITMn_ERR_E,4);
             break;
           case 20:
             memcpy(g_caToDbpErrCode+3,DOT_NUMBER_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         break;

    case P_TxEnvPre		:
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode+3,CHK_BRH_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         break;

    case P_IsTxnBegin 		: 
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode+3,TXN_TYPE_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode+3,RENDO_REQUEST_ERR_E51,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         break;

    case P_DbsTxBegin 		:
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode+3,BEGIN_TXN_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         g_cErrActFlag = g_cErrActFlag | DO_ABEND_FLAG;
         g_cErrActFlag = g_cErrActFlag | INFORM_EMS_FLAG;
         break;

    case P_TxProces	:
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode+3,TXN_PATTERN_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ROLE_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         break;

    case P_ApDispth	:
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode+3,AP_NOT_EXIST_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode+3,AP_EXE_NOT_EXIST_ERR_E,4);
             break;
           case 3:
             memcpy(g_caToDbpErrCode+3,FORK_ERR_E,4);
             break;
           case 4:
             memcpy(g_caToDbpErrCode+3,WAKE_TPU_ERR_E,4);
             break;
           case 5:
             memcpy(g_caToDbpErrCode+3,SLEEP_TPU_ERR_E,4);
             break;
           case 6:
             memcpy(g_caToDbpErrCode+3,GET_ACIA_PTR_ERR_E,4);
             break;
           case 7:
             memcpy(g_caToDbpErrCode+3,AP_ABEND_EXIT_ERR_E,4);
             break;
           case 8:
             memcpy(g_caToDbpErrCode+3,WAKE_AP_ERR_E,4);
             break;
           case 9:
             memcpy(g_caToDbpErrCode+3,TPEWRITE_CALL_SEQ_ERR_E,4);
             ErrLog(100,"Set KILL_AP_FLAG on........",RPT_TO_LOG,0,0);
             g_cErrActFlag = g_cErrActFlag | KILL_AP_FLAG;
             break;
           /* case 10,11 are added by Willy for detecting Ap process */
           case 10:
             memcpy(g_caToDbpErrCode+3,AP_DISAPPEAR_ERR_E,4);
             break;
           case 11:
             memcpy(g_caToDbpErrCode+3,AP_TOO_LONG_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         break;

    case P_RemoteTxn	:
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode+3,LOAD_TXN_MAP_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode+3,PRE_PROCESS_NOT_FOUND_ERR_E,4);
             break;
           case 3:
             memcpy(g_caToDbpErrCode+3,AP_PRE_PROCESS_ERR_E,4);
             break;
           case 4:
             memcpy(g_caToDbpErrCode+3,SEND_SIF_TO_SERVER_ERR_E,4);
             break;
           case 5:
             memcpy(g_caToDbpErrCode+3,RCV_SOF_FROM_SERVER_ERR_E,4);
             break;
           case 6:
             memcpy(g_caToDbpErrCode+3,CONV_IN_ERR_E,4);
             break;
           case 7:
             memcpy(g_caToDbpErrCode+3,POST_PROCESS_NOT_FOUND_ERR_E,4);
             break;
           case 8:
             memcpy(g_caToDbpErrCode+3,AP_POST_PROCESS_ERR_E,4);
             break;
           case 9:
             memcpy(g_caToDbpErrCode+3,SRH_PRE_FUN_BY_TXN_CODE_ERR_E,4);
             break;
           case 10:
             memcpy(g_caToDbpErrCode+3,SRH_POST_FUN_BY_TXN_CODE_ERR_E,4);
             break;
           case 11:
             memcpy(g_caToDbpErrCode+3,PREPA_APA_TO_POST_AP_ERR_E,4);
             break;
           case 12:
             memcpy(g_caToDbpErrCode+3,GET_BRH_PTR_ERR_E,4);
             break;
           case 13:
             memcpy(g_caToDbpErrCode+3,FMT_CONV_ERR_E,4);
             break;
           case 14:
             memcpy(g_caToDbpErrCode+3,CODE_CONV_ERR_E,4);
             break;
           case 15:
             memcpy(g_caToDbpErrCode+3,GET_SERVER_NAME_ERR_E,4);
             break;
           case 16:
             memcpy(g_caToDbpErrCode+3,GET_SSA_PTR_ERR_E23,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         break;
    case P_IsTxnEnd              :
         switch ( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode+3,AP_ABEND_NO_RLBK_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode+3,INPUT_TXN_TYPE_ERR_E,4);
             break;
           case 3:
             memcpy(g_caToDbpErrCode+3,RENDO_REQUEST_ERR_E65,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         break;

    case P_DbsTxEnd 		:
         switch ( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode+3,END_TXN_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         g_cErrActFlag = g_cErrActFlag | DO_ABEND_FLAG;
         break;

    case P_SysWrtLogForAp 		:
         switch ( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode+3,SYS_WRT_LOG_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         break;

    case P_TxEndInform	  :
         switch ( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode+3,OPEN_OUTPT_FILE_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode+3,GET_TBA_PTR_ERR_E,4);
             break;
           case 3:
             memcpy(g_caToDbpErrCode+3,WRITE_TO_FILE_ERR_E,4);
             break;
           case 4:
             memcpy(g_caToDbpErrCode+3,CLOSE_OUTPUT_FILE_ERR_E,4);
             break;
           case 5:
             memcpy(g_caToDbpErrCode+3,INVALID_MSG_CNT_ERR_E,4);
             break;
           case 6:
             memcpy(g_caToDbpErrCode+3,TPESCRQT_DATA_LEN_ERR_E,4);
             break;
           case 7:
             memcpy(g_caToDbpErrCode+3,AP_NORMAL_END_BUT_SND_MXXX_MSG_E,4);
             break;
           case 8:
             memcpy(g_caToDbpErrCode+3,AP_ABNORMAL_END_BUT_SND_TXXX_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         break;

    case P_TxSeqMtn              :
    case P_TrmRelease            :
         switch ( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode+3,LOCK_SSA_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode+3,GET_SSA_PTR_ERR_E72,4);
             break;
           case 3:
             memcpy(g_caToDbpErrCode+3,UNLOCK_SSA_ERR_E,4);
             break;
           case 4:
             memcpy(g_caToDbpErrCode+3,LOCK_TCT_ERR_E,4);
             break;
           case 5:
             memcpy(g_caToDbpErrCode+3,GET_TCT_PTR_ERR_E,4);
             break;
           case 6:
             memcpy(g_caToDbpErrCode+3,UNLOCK_TCT_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         g_cErrActFlag = g_cErrActFlag | DO_ABEND_FLAG;
         g_cErrActFlag = g_cErrActFlag | INFORM_EMS_FLAG;
         break;

    case P_SendToIO	  :
         switch( iAbsIrc ) {
           case 1: 
             memcpy(g_caToDbpErrCode+3,OPEN_OUTPUT_FILE_FOR_READ_ERR_E,4);
             break;
           case 2: 
             memcpy(g_caToDbpErrCode+3,GET_SEND_METHOD_ERR_E,4);
             break;
           case 3: 
             memcpy(g_caToDbpErrCode+3,GET_FILE_STATUS_ERR_E,4);
             break;
           case 4: 
             memcpy(g_caToDbpErrCode+3,OUTFILE_EMPTY_ERR_E,4);
             break;
           case 5: 
             memcpy(g_caToDbpErrCode+3,SEND_SIZE_OVERFLOW_ERR_E,4);
             break;
           case 6: 
             memcpy(g_caToDbpErrCode+3,TMS_DATA_SEND_ERR_E,4);
             g_cErrActFlag = g_cErrActFlag | DO_ABEND_FLAG;
             break;
           case 7: 
             memcpy(g_caToDbpErrCode+3,READ_INPUT_FILE_ERR_E,4);
             break;
           case 8: 
             memcpy(g_caToDbpErrCode+3,IS_MORE_ERR_E,4);
             break;
           case 9:
             memcpy(g_caToDbpErrCode+3,SEND_METHOD_ERR_E,4);
             break;
           case 10:
             memcpy(g_caToDbpErrCode+3,GET_ACK_ERR_E,4);
             if( strncmp("QUEUE",(char *) getenv("III_PROTOCOL"),1) == 0 ) {
               g_cErrActFlag = g_cErrActFlag | ABORT_DCS_FLAG;
             }
             else {
               g_cErrActFlag = g_cErrActFlag | DO_ABEND_FLAG | ABORT_DCS_FLAG;
             }
             g_cErrActFlag &= (~INFORM_DBP_FLAG);
             /* BackupOutput(); */
             break;
           case 11:
             memcpy(g_caToDbpErrCode+3,FIRST_ACK_ERR_E,4);
             g_cErrActFlag = g_cErrActFlag | ABORT_DCS_FLAG;
             g_cErrActFlag &= (~INFORM_DBP_FLAG);
             break;
           case 12:
             memcpy(g_caToDbpErrCode+3,OTHER_ACK_ERR_E,4);
             g_cErrActFlag = g_cErrActFlag | ABORT_DCS_FLAG;
             g_cErrActFlag &= (~INFORM_DBP_FLAG);
             break;
           case 13:
             memcpy(g_caToDbpErrCode+3,CONVERT_OUT_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         break;

    case P_RelIfEnv 		:
         switch ( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode+3,REL_IF_ENV_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         g_cErrActFlag = g_cErrActFlag | DO_ABEND_FLAG;
         break;

/* added by WuChihLiang  19950322 for check Reinput data convert -- BEGIN */
    case P_Reinput 		:
         switch ( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode+3,SIF_LEN_OVERFLOW_E,4);
             break;
           case 14:
             memcpy(g_caToDbpErrCode+3,CTF_TO_SIF_BUSI_ERR_E,4);
             break;
           case 15:
             memcpy(g_caToDbpErrCode+3,CTF_TO_SIF_TXN_ERR_E,4);
             break;
           case 16:
             memcpy(g_caToDbpErrCode+3,CTF_TO_SIF_ITM1_ERR_E,4);
             break;
           case 17:
             memcpy(g_caToDbpErrCode+3,CTF_TO_SIF_ITMn_ERR_E,4);
             break;
           case 18:
             memcpy(g_caToDbpErrCode+3,CTF_TO_SIF_CNV_ITM1_ERR_E,4);
             break;
           case 19:
             memcpy(g_caToDbpErrCode+3,CTF_TO_SIF_CNV_ITMn_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
         }
         break;
/* added by WuChihLiang  19950322 for check Reinput data convert -- END   */

    default:
      sprintf(g_caMsg," ErrorMap(): No such function PRGID ! PrgID=%5d  iRc=%d"
              ,iPrgIdVal,iAbsIrc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      memcpy(g_caToDbpErrCode+3,SYSTEM_ERR_E,4);
  } /* end switch */

}



void 
ErrorAction()
{
  int iRc ;
  char cErrStep;

  sprintf(g_caMsg,"1111111g_cErrActFlag=%2x,KILL_AP_FLAG=%2x,KILL_AP_FLAG=%2x",
          g_cErrActFlag,KILL_AP_FLAG,KILL_AP_FLAG);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

/* To avoid duplication of txn seq. no of the same terminal -- BEGIN */ 
  if (g_cNeedRelseTrm == 'y') {
    iRc = TrmRelease();
    if (iRc < 0) {
      sprintf(g_caMsg,"TmsErrHdl: TrmRelease fail! iRc=%d",iRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    }
    g_cNeedRelseTrm = 'n';
  }
/* To avoid duplication of txn seq. no of the same terminal -- END */ 

  if ( (g_cErrActFlag & INFORM_DBP_FLAG) ) {
    IsMultipleDataEnd();
    IsListDataEnd();
    ErrLog(100,"enter SendErrToDbp().....",RPT_TO_LOG,0,0);

    /*Updated by baiyj on 1998/10/06 for W000086 begin*/
    if(g_iTmaTermno == 1) {
      SendErrToDbp( g_pstTma->stTSSA.caBrCode, g_pstTma->stTSSA.caTmCode,
                  g_caToDbpErrCode );
    }
    else {
      SendErrToDbp( &g_pstTba->caSif[BR_CODE_OFFSET],
                    &g_pstTba->caSif[TM_CODE_OFFSET],
                    g_caToDbpErrCode );
    }
    /*SendErrToDbp( g_pstTma->stTSSA.caBrCode, g_pstTma->stTSSA.caTmCode,
                  g_caToDbpErrCode );*/
    /*Updated by baiyj on 1998/10/06 for W000086 end*/

    g_cErrActFlag &= (~INFORM_DBP_FLAG);
    ErrLog(100,"exit SendErrToDbp().....",RPT_TO_LOG,0,0);
  }

  if ( g_cErrActFlag & ABORT_DCS_FLAG ) {
    ErrLog(100,"enter DoDcsAbort().....",RPT_TO_LOG,0,0);
    DoDcsAbort();
    g_cErrActFlag &= (~ABORT_DCS_FLAG);
    ErrLog(100,"exit DoDcsAbort().....",RPT_TO_LOG,0,0);
  }

  sprintf(g_caMsg,"2222222g_cErrActFlag=%2x,KILL_AP_FLAG=%2x,KILL_AP_FLAG=%2x",
          g_cErrActFlag,KILL_AP_FLAG,KILL_AP_FLAG);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  if ( (g_cErrActFlag & KILL_AP_FLAG) ) {
  ErrLog(100,"enter KillApProcess().....", RPT_TO_LOG,0,0);
    iRc = KillApProcess();
    if ( iRc < 0 ) {
      AbendRtn();
    }
    g_cErrActFlag &= (~KILL_AP_FLAG);
    ErrLog(100,"exit KillApProcess().....",RPT_TO_LOG,0,0);
  }

  sprintf(g_caMsg,"333222g_cErrActFlag=%2x,KILL_AP_FLAG=%2x,KILL_AP_FLAG=%2x",
          g_cErrActFlag,KILL_AP_FLAG,KILL_AP_FLAG);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  if ( (g_cErrActFlag & DO_ROLLBACK_FLAG) ) {
    IsMultipleDataEnd();
    IsListDataEnd();
    ErrLog(100,"enter DbsTxEnd().....",RPT_TO_LOG,0,0);
    iRc = DbsTxEnd( ROLLBACK_FLAG );
    if ( iRc < 0 ) {
      AbendRtn();
    } 
    g_cErrActFlag &= (~DO_ROLLBACK_FLAG);
    ErrLog(100,"exit DbsTxEnd().....",RPT_TO_LOG,0,0);
  }

  sprintf(g_caMsg,"444222g_cErrActFlag=%2x,KILL_AP_FLAG=%2x,KILL_AP_FLAG=%2x",
          g_cErrActFlag,KILL_AP_FLAG,KILL_AP_FLAG);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  if ( (g_cErrActFlag & INFORM_EMS_FLAG) == INFORM_EMS_FLAG ) {
    AbendRtn();
  }

  sprintf(g_caMsg,"555222g_cErrActFlag=%2x,KILL_AP_FLAG=%2x,KILL_AP_FLAG=%2x",

          g_cErrActFlag,KILL_AP_FLAG,KILL_AP_FLAG);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  if ( (g_cErrActFlag & DO_ABEND_FLAG) ) {
    AbendRtn();
  }

  ErrLog(100,"enter TxRelese().....",RPT_TO_LOG,0,0);
  iRc = TxRelese(&cErrStep);
  ErrLog(100,"exit TxRelese().....",RPT_TO_LOG,0,0);

  StSysVal();

}

int
BackupOutput()
{
  char caCmdBuf[256];
  char caFileName[100];
  char caBackup[100];

  sprintf(caFileName,"%s/iii/log/output%.*s.%.*s",getenv("III_DIR"),
          g_iTmCodeLen, g_pstTma->stTSSA.caTmCode,
          g_iBrhCodeLen, g_pstTma->stTSSA.caBrCode);
  sprintf(caBackup,"%s/iii/log/backup%.*s.%.*s",getenv("III_DIR"),
          g_iTmCodeLen, g_pstTma->stTSSA.caTmCode,
          g_iBrhCodeLen, g_pstTma->stTSSA.caBrCode);
  sprintf(caCmdBuf,"cp %s %s",caFileName,caBackup);
  ErrLog(10,"BackupOutput Cmd=",RPT_TO_LOG,caCmdBuf,256);
  system(caCmdBuf);
  return ( 0 );
}
