/*
 *&N& File : tmsonbh1.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int       OnBatch1()              ��bAPI������
 */

/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include "errlog.h"
#include "cwa.h"
#include "ucp.h"
#include "tms.h"
#include "dcs.h"
/* #include "tmcomtma.h"  for TPU send common information to client */

/* -------------------- CONSTANT DEFINE  --------------------------- */
#define P_OnBatch1            29901
#define P_IsWtReentrySeq      29902
#define P_GetSystemRole       29903
#define P_DcsErrToONBH1       29904
#define P_ApInDataToSif	      29905
/* -------------------- GLOBAL DECLARATION ------------------ */
extern int g_iBrhCodeLen;
extern int g_iTmCodeLen ;

/* ------ CALLED FUNCTION AND SUBROUTINE PROTOTYPE DECLARATIONS ------- */
char DcsErrToONBH1(char cDcsRtnCode);
int  IsWtReentrySeq(char cProtoType, char cSystemRole);
int  ApInDataToSif(char *pcApInData , char *pcSif     , char cInDataFmt, 
              int  iApInDataLen, char *pcBrCode  , char *pcTmCode, 
              char *pcTxnCode  , char *pcTelCode , char *pcReentrySeqNo);

/*
 *&N& ROUNTINE NAME : OnBatch1()
 *&A& ARGUMENTS: �L
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D&
 */
int
OnBatch1(struct OnBh1CtlSt *pstOnBh1Ctl,char *pcOnBh1Data)
{
  struct DcsApi  stDcsApi;
  char   caTmpBuf[5];
  char   caRcvBuf[DCS_MAX_DATA_LEN];
/*struct HostToBrhInfoSt *pstHostToBrhInfo;*/
  int    iPargc;
  char   *pcaArgv[5];
  char   caRcvFileName[256];
  int    iRc;
  int    iInputLen;
  long   lBtchSeqNo;
  char   caBuf[ MAX_SIF_LEN ];
  char   caReentrySeqNo[ 10 ];
  unsigned char ucaReentryLen[3];
  char   cProtoType;
  char   cSystemRole;

  UCP_TRACE(P_OnBatch1);

  sprintf(g_caMsg,"OnBatch1:Begin, dump pstOnBh1Ctl"); 
  ErrLog(100,g_caMsg,RPT_TO_LOG,pstOnBh1Ctl,sizeof(struct OnBh1CtlSt));
  memcpy(caTmpBuf,pstOnBh1Ctl->caDataLen,4);
  caTmpBuf[4] = '\0';
  iInputLen = atoi(caTmpBuf);
  sprintf(g_caMsg,"OnBatch1:Begin, dump pcOnBh1Data"); 
  ErrLog(100,g_caMsg,RPT_TO_LOG,pcOnBh1Data,iInputLen);

  pstOnBh1Ctl->cOnBh1RtnCode=TMS_ONBH1_NORMAL;
  memset(pstOnBh1Ctl->caOnBh1TxnRtnCode, '0', 7); 
  memset(pstOnBh1Ctl->caErrCode, '0', 5);

/*sprintf( g_caMsg, "OnBatch1:before call RdWtReentrySeq");
  ErrLog( 100, g_caMsg, RPT_TO_LOG, 0, 0 );*/

  /* Read REENTRY-SEQ number ...... */
  iRc=RdWtReentrySeq(RD_REENTRY_SEQ_NO,pstOnBh1Ctl->caBrhCode,
                     pstOnBh1Ctl->caReentryTmCode,&lBtchSeqNo,
                     TMS_TXN_REENTRY);
  if ( iRc < 0 ) {
    sprintf( g_caMsg, "OnBatch1:RdWtReentrySeq (Read) error, iRc=%d", iRc);
    ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
    pstOnBh1Ctl->cOnBh1RtnCode= TMS_ONBH1_SYS_ERR;
    switch (iRc){
      case -1:
        memcpy(pstOnBh1Ctl->caErrCode, ONBH1_NO_SUCH_BRH_TERM_DERR, 5);
        break;
      case -3:
        memcpy(pstOnBh1Ctl->caErrCode, ONBH1_NOT_REENTRY_TERM_DERR, 5);
        break;
      default:
        memcpy(pstOnBh1Ctl->caErrCode, ONBH1_OTHER_DERR, 5);
        break;
    }
    UCP_TRACE_END ( -1 );
  }

  sprintf( g_caMsg, "OnBatch1:after call RdWtReentrySeq lBtchSeqNo=[%ld]",
           lBtchSeqNo);
  ErrLog( 100, g_caMsg, RPT_TO_LOG, 0, 0 );

  memset(caReentrySeqNo,0,10);
  sprintf(caReentrySeqNo,"%.*ld",5,lBtchSeqNo);
  memset(caBuf,'0',sizeof(caBuf)); /* clear buffer */

  iInputLen = ApInDataToSif(pcOnBh1Data, caBuf, pstOnBh1Ctl->cFmtCode, 
               iInputLen, pstOnBh1Ctl->caBrhCode, pstOnBh1Ctl->caReentryTmCode, 
               pstOnBh1Ctl->caTxnCode,pstOnBh1Ctl->caTelCode, caReentrySeqNo);
  switch (iInputLen){
    case -1:
      pstOnBh1Ctl->cOnBh1RtnCode= TMS_ONBH1_PARA_ERR;
      memcpy(pstOnBh1Ctl->caErrCode, ONBH1_SIF_LEN_OVERFLOW_DERR, 5);
      UCP_TRACE_END(-1);
    case -2:
      pstOnBh1Ctl->cOnBh1RtnCode= TMS_ONBH1_PARA_ERR;
      memcpy(pstOnBh1Ctl->caErrCode, ONBH1_NO_SUCH_FORMAT_DERR, 5);
      UCP_TRACE_END(-1);
    default:
      break;
  }

  /* --------------------------------------------------------------- */
  /*      send data (SIF) to host.                                   */
  /* --------------------------------------------------------------- */
  stDcsApi.cFunCode = DCS_M_RMT_START_PGM;
  /*stDcsApi.cDataFmt = pstOnBh1Ctl->cFmtCode;*/
  stDcsApi.cDataFmt = '0'; /* SIF */
  memcpy(stDcsApi.caDesAddr,pstOnBh1Ctl->caDesCode,BR_CODE_LEN);
  memcpy(stDcsApi.caTermCode,pstOnBh1Ctl->caReentryTmCode,TM_CODE_LEN);
  memcpy(stDcsApi.caTxnCode,pstOnBh1Ctl->caTxnCode,MAX_TXN_CODE_LEN);
  sprintf(caTmpBuf, "%.4d", iInputLen); 
  memcpy(stDcsApi.caDataLen, caTmpBuf, 4);
  iPargc = 5;
  pcaArgv[1] = (char *)&stDcsApi;
  pcaArgv[2] = (char *)caBuf;
  pcaArgv[3] = "1"; /* */
  pcaArgv[4] = (char *)caRcvFileName;

  SbDcs(iPargc, pcaArgv);
  if(stDcsApi.cRtnCode != DCS_M_NORMAL){
    sprintf(g_caMsg,"OnBatch1:remote start program error,cRtnCode=[%c]",
            stDcsApi.cRtnCode); 
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstOnBh1Ctl->cOnBh1RtnCode=DcsErrToONBH1(stDcsApi.cRtnCode);
    pstOnBh1Ctl->caErrCode[0]=stDcsApi.cRtnCode;
    memcpy(&pstOnBh1Ctl->caErrCode[1], stDcsApi.caErrCode, 2);
    memcpy(&pstOnBh1Ctl->caErrCode[3], "  ", 2);
    stDcsApi.cFunCode = DCS_M_RMT_STOP_PGM;
    SbDcs(iPargc, pcaArgv);
    UCP_TRACE_END(-1);
  }

  /* --------------------------------------------------------------- */
  /*      receive output data from host.                             */
  /* --------------------------------------------------------------- */
/*sprintf(g_caMsg,"ObnBatch1:before call SbDcs--DCS_M_RECEIVE_ALL");
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);*/
  stDcsApi.cFunCode = DCS_M_RECEIVE_ALL;
  memcpy(stDcsApi.caTimeOut,"00060",5);  /* time out value */
  memcpy(stDcsApi.caDataLen,"9999",4);   /* max receive length */
  memset(caRcvBuf,'0', sizeof(caRcvBuf));/* clear caRcvBuf */
  pcaArgv[2] = (char *)caRcvBuf;
  SbDcs(iPargc, pcaArgv);
  if(stDcsApi.cRtnCode != DCS_M_NORMAL){
    sprintf(g_caMsg,"OnBatch1:receive data from DCS error,cRtnCode = %c",
                     stDcsApi.cRtnCode); 
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstOnBh1Ctl->cOnBh1RtnCode=DcsErrToONBH1(stDcsApi.cRtnCode);
    pstOnBh1Ctl->caErrCode[0]=stDcsApi.cRtnCode;
    memcpy(&pstOnBh1Ctl->caErrCode[1], stDcsApi.caErrCode, 2);
    memcpy(&pstOnBh1Ctl->caErrCode[3], "  ", 2);
    stDcsApi.cFunCode = DCS_M_RMT_STOP_PGM;
    SbDcs(iPargc, pcaArgv);
    UCP_TRACE_END(-1);
  }

  memcpy(caTmpBuf, stDcsApi.caDataLen, 4);
  caTmpBuf[4] = '\0';

  sprintf(g_caMsg,"ObnBatch1:after call SbDcs-DCS_M_RECEIVE_ALL,dump caRcvBuf");
  ErrLog(100,g_caMsg,RPT_TO_LOG, caRcvBuf, atoi(caTmpBuf));

/*pstHostToBrhInfo = (struct HostToBrhInfoSt *)(caRcvBuf+SOF_HEAD_LEN_PLUS_2);*/
/*memset(pstOnBh1Ctl->caOnBh1SeqNo, '0', 7);
  memcpy(pstOnBh1Ctl->caOnBh1SeqNo+2,pstHostToBrhInfo->caBthTxnSeqNo,5);*/

  /* Add BtchSeqNo by 1 */
  lBtchSeqNo++;

  /* Write REENTRY-SEQ number ...... */
  GetProtoByDes(stDcsApi.caDesAddr,&cProtoType);
  GetSystemRole(&cSystemRole);
  if (IsWtReentrySeq(cProtoType, cSystemRole)){
    iRc=RdWtReentrySeq(WT_REENTRY_SEQ_NO,pstOnBh1Ctl->caBrhCode,
                       pstOnBh1Ctl->caReentryTmCode,&lBtchSeqNo,
                       TMS_TXN_REENTRY);
    if ( iRc < 0 ) {
      sprintf( g_caMsg, "OnBatch1:RdWtReentrySeq (Write) error!");
      ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
      pstOnBh1Ctl->cOnBh1RtnCode= TMS_ONBH1_SYS_ERR;
      memcpy(pstOnBh1Ctl->caErrCode, ONBH1_WRITE_REENTRY_SEQ_DERR, 5);
      UCP_TRACE_END ( -1 );
    }
  }

  /* return Reentry BtchSeqNo to AP */
  memset(pstOnBh1Ctl->caOnBh1SeqNo, '0', 7);
  memcpy(pstOnBh1Ctl->caOnBh1SeqNo+2,caReentrySeqNo,5);

/*sprintf( g_caMsg, "OnBatch1:caRcvBuf[%d]=0x%2x",
           SOF_CTL_CODE_OFFSET, caRcvBuf[SOF_CTL_CODE_OFFSET]);
  ErrLog( 100, g_caMsg, RPT_TO_LOG, 0, 0 );*/

  if ( (unsigned char)caRcvBuf[SOF_CTL_CODE_OFFSET] == 0xc0) {
    /*memcpy(pstOnBh1Ctl->caOnBh1TxnRtnCode, caRcvBuf+SOF_MSG_CODE_OFFSET, 7);
    memcpy(&pstOnBh1Ctl->caOnBh1TxnRtnCode[3], "OK  ", 4);*/
    memset(pstOnBh1Ctl->caOnBh1TxnRtnCode, '0', 7);
  }
  else {
    if ( (unsigned char)caRcvBuf[SOF_CTL_CODE_OFFSET] == 0xc8 ) {
      memcpy(pstOnBh1Ctl->caOnBh1TxnRtnCode, caRcvBuf+SOF_MSG_CODE_OFFSET, 7); 
    } else {
      memcpy(pstOnBh1Ctl->caOnBh1TxnRtnCode, caRcvBuf+SOF_MSG_CODE_OFFSET, 7); 
      pstOnBh1Ctl->cOnBh1RtnCode= TMS_ONBH1_SERVER_ERR;
      memcpy(pstOnBh1Ctl->caErrCode, ONBH1_SOF_STATUS_DERR, 5);
    }
  }

  stDcsApi.cFunCode = DCS_M_RMT_STOP_PGM;
  SbDcs(iPargc, pcaArgv);

  UCP_TRACE_END(0);
}

/*
 *&N& ROUNTINE NAME : DcsErrToONBH1()
 *&A& ARGUMENTS: �L
 *&A&
 *&R& RETURN VALUE(char);
 *&R&   ����ƶǦ^ TPEONBH1 �� return code.
 *&R&
 *&D& DESCRIPTION:
 *&D&   ����Ʈھ� SbDcs �� return code �ӳ]�w TPEONBH1 �� return code.
 *&D&
 */
char DcsErrToONBH1(char cDcsRtnCode)
{
  char cRtnCode;

  UCP_TRACE(P_DcsErrToONBH1);

  switch(cDcsRtnCode){
      
    case DCS_M_NORMAL:
      cRtnCode = TMS_ONBH1_NORMAL;
      break;

    case DCS_M_COMMAND_ERROR:
    case DCS_M_DATA_ERROR:
    case DCS_M_LOCAL_ERROR:
    case DCS_M_REMOTE_ERROR:
    case DCS_M_NETWORK_ERROR:
    case DCS_M_PGM_ID_ERROR:
    case DCS_M_UCPS_ERROR:
    case DCS_M_CONVSOF_ERROR:
    case DCS_M_SYSTEM_ERROR:
      cRtnCode = TMS_ONBH1_DCS_ERR;
      break;

    case DCS_M_CONVSIF_ERROR:
      cRtnCode = TMS_ONBH1_PARA_ERR;
      break;

    case DCS_M_TIMEOUT_ERROR:
      cRtnCode = TMS_ONBH1_TIMEOUT_ERR;
      break;

    default:
      cRtnCode = TMS_ONBH1_DCS_ERR;
      break;
  }

  UCP_TRACE_END(cRtnCode);
}

IsWtReentrySeq(char cProtoType, char cSystemRole)
{
  int iYesNoFlag;

  UCP_TRACE(P_IsWtReentrySeq);

  sprintf(g_caMsg, "IsWtReentrySeq:begin,cProtoType=%c,cSystemRole=%c",
          cProtoType,cSystemRole);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  switch (cProtoType){
    case 'Q': /* QUEUE */
      iYesNoFlag = 0;
      break;
    case 'S': /* SOCKET */
      iYesNoFlag = 1;
      break;
    case 'T': /* TOPEND */
      if ( cSystemRole == '0'){ /* Center Host */
        iYesNoFlag = 0;
      }else{                    /* Branch Host */
        iYesNoFlag = 1;
      }
      break;
    default:
      iYesNoFlag = 1;
      break;
  }

  sprintf(g_caMsg, "IsWtReentrySeq:end,iYesNoFlag=%d", iYesNoFlag);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  UCP_TRACE_END(iYesNoFlag);
}

/*****************************************************************
 *&N& ROUTINE NAME: GetSystemRole()
 *&A& ARGUMENTS:
 *&A&           char * pcSystemRole:'0' --> Center Host
 *&A&                               '1' --> Branch Host
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&  
 *&D&
 */

int GetSystemRole(char *pcSystemRole)
{
  struct SSA *pstSsa;
  struct CwaCtl stCwaCtl;
  int iRc;

  UCP_TRACE(P_GetSystemRole);

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }

  *pcSystemRole = pstSsa->cSystemRole ;

  UCP_TRACE_END( 0 );
}

ApInDataToSif(char *pcApInData , char *pcSif     , char cInDataFmt, 
              int  iApInDataLen, char *pcBrCode  , char *pcTmCode, 
              char *pcTxnCode  , char *pcTelCode , char *pcReentrySeqNo)
{
  unsigned char ucaReentryLen[3];
  int   iSifLen;
  int   iCurApOffset;
  int   iSifOffset;
  char  *pcCurSifPtr;
  char  caDataLen[10];
  short sDataLen;

  UCP_TRACE(P_ApInDataToSif);

  switch (cInDataFmt){
    case '0': /* SIF */
    case '4': /* SIF */
    /*put BRH-CODE and REENTRY-TM-CODE and lBtchSeqNo to SIF's 1th data field*/
      ucaReentryLen[0]=(unsigned char) (g_iBrhCodeLen+g_iTmCodeLen+5)/256;
      ucaReentryLen[1]=(unsigned char) (g_iBrhCodeLen+g_iTmCodeLen+5)%256;
      ucaReentryLen[2]=0x00;
      memcpy(pcSif,pcApInData,SIF_HEAD_LEN);
      memcpy(pcSif+SIF_HEAD_LEN,ucaReentryLen,2);
      memcpy(&pcSif[SIF_HEAD_LEN+2], pcBrCode, g_iBrhCodeLen);
      memcpy(&pcSif[SIF_HEAD_LEN+2+g_iBrhCodeLen], pcTmCode, g_iTmCodeLen);

      memcpy(&pcSif[SIF_HEAD_LEN+2+g_iBrhCodeLen+g_iTmCodeLen],
             pcReentrySeqNo,5);
      memcpy(&pcSif[SIF_HEAD_LEN+2+g_iBrhCodeLen+g_iTmCodeLen+5]
             ,pcApInData+SIF_HEAD_LEN,iApInDataLen-SIF_HEAD_LEN);

      /* beacuse Add ReentrySeqNo to original SIF, 
         original SIF len should be added by (2+g_iBrhCodeLen+g_iTmCodeLen+5);*/
      iSifLen = iApInDataLen + (2+g_iBrhCodeLen+g_iTmCodeLen+5);
      break;

    case '1': /* len1(9(4))+data1[len1]+len2(9(4))+data2[len2]+ ... , 
                 where data is character type */
      memcpy(pcSif,SIF_FMT_3,SIF_FMT_LEN);  /* copy CICS txn-code to SIF*/
      memcpy(pcSif+TXN_CODE_OFFSET,pcTxnCode,MAX_TXN_CODE_LEN);/* copy txn-id */
      memcpy(pcSif+BR_CODE_OFFSET,pcBrCode,BR_CODE_LEN);
      memcpy(pcSif+TM_CODE_OFFSET,pcTmCode,TM_CODE_LEN);
      memcpy(pcSif+TELLER_CODE_OFFSET,pcTelCode,TELLER_CODE_LEN	);
      /*memcpy(pcSif+CTL_BYTE_OFFSET,pcCtlByte,CTL_BYTE_LEN);*/
      ucaReentryLen[0]=(unsigned char) (g_iBrhCodeLen+g_iTmCodeLen+5)/256;
      ucaReentryLen[1]=(unsigned char) (g_iBrhCodeLen+g_iTmCodeLen+5)%256;
      ucaReentryLen[2]=0x00;
      memcpy(pcSif+SIF_HEAD_LEN,ucaReentryLen,2);
      memcpy(&pcSif[SIF_HEAD_LEN+2],pcBrCode,g_iBrhCodeLen);
      memcpy(&pcSif[SIF_HEAD_LEN+2+g_iBrhCodeLen], pcTmCode,g_iTmCodeLen);
      memcpy(&pcSif[SIF_HEAD_LEN+2+g_iBrhCodeLen+g_iTmCodeLen], pcReentrySeqNo,
             5);
      iCurApOffset = 0;
      pcCurSifPtr = pcSif + SIF_HEAD_LEN + 2 + g_iBrhCodeLen + g_iTmCodeLen + 5;
      while ( iCurApOffset < iApInDataLen ) {
        memset(caDataLen, 0, 10);
        memcpy(caDataLen,(char *) (pcApInData+iCurApOffset), 4);
        sDataLen = (short) atoi( caDataLen );
        iCurApOffset += 4;
        if ( (iCurApOffset+sDataLen) > iApInDataLen ) {
          sprintf(g_caMsg,"ApInDataToSif:AP SIF total data length=%d error!",
                  iApInDataLen);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          UCP_TRACE_END( -1 );         
        }
        else {
          *(pcCurSifPtr) = (char) sDataLen/256;
          *(pcCurSifPtr+1) = (char) sDataLen%256;
          pcCurSifPtr +=  SIF_DATA_LEN_SIZE;
          memcpy(pcCurSifPtr, (char *) (pcApInData+iCurApOffset), sDataLen);
          pcCurSifPtr +=  sDataLen;
          iCurApOffset +=  sDataLen;
        }
      }
      iSifLen = ( pcCurSifPtr  - pcSif );
      break;

    case '2':/* data+data+... , where data is COBOL     type */
      memcpy(pcSif,SIF_FMT_3,SIF_FMT_LEN);  /* copy CICS txn-code to SIF*/
      memcpy(pcSif+TXN_CODE_OFFSET,pcTxnCode,MAX_TXN_CODE_LEN);/* copy txn-id */
      memcpy(pcSif+BR_CODE_OFFSET,pcBrCode,BR_CODE_LEN);
      memcpy(pcSif+TM_CODE_OFFSET,pcTmCode,TM_CODE_LEN);
      memcpy(pcSif+TELLER_CODE_OFFSET,pcTelCode,TELLER_CODE_LEN	);
      /*memcpy(pcSif+CTL_BYTE_OFFSET,pcCtlByte,CTL_BYTE_LEN);*/
      ucaReentryLen[0]=(unsigned char) (g_iBrhCodeLen+g_iTmCodeLen+5)/256;
      ucaReentryLen[1]=(unsigned char) (g_iBrhCodeLen+g_iTmCodeLen+5)%256;
      ucaReentryLen[2]=0x00;
      memcpy(pcSif+SIF_HEAD_LEN,ucaReentryLen,2);
      memcpy(&pcSif[SIF_HEAD_LEN+2],pcBrCode,g_iBrhCodeLen);
      memcpy(&pcSif[SIF_HEAD_LEN+2+g_iBrhCodeLen], pcTmCode,g_iTmCodeLen);
      memcpy(&pcSif[SIF_HEAD_LEN+2+g_iBrhCodeLen+g_iTmCodeLen], pcReentrySeqNo,
             5);
      memcpy(&pcSif[SIF_HEAD_LEN+2+g_iBrhCodeLen+g_iTmCodeLen+5], pcApInData,
             iApInDataLen);
      /* beacuse Add ReentrySeqNo to original DATA, original DATA len should be 
         added by (SIF_HEAD_LEN+2+g_iBrhCodeLen+g_iTmCodeLen+5)*/
      iSifLen = iApInDataLen + (SIF_HEAD_LEN+2+g_iBrhCodeLen+g_iTmCodeLen+5);
      break;

    case '9':/* txn_code(X(4))+data+data+... , where data is COBOL type */
      memcpy(pcSif,SIF_FMT_3,SIF_FMT_LEN);  /* copy CICS txn-code to SIF*/
      memcpy(pcSif+TXN_CODE_OFFSET,pcApInData,4);/* copy txn-id to SIF*/
      memcpy(pcSif+BR_CODE_OFFSET,pcBrCode,BR_CODE_LEN);
      memcpy(pcSif+TM_CODE_OFFSET,pcTmCode,TM_CODE_LEN);
      memcpy(pcSif+TELLER_CODE_OFFSET,pcTelCode,TELLER_CODE_LEN	);
      /*memcpy(pcSif+CTL_BYTE_OFFSET,pcCtlByte,CTL_BYTE_LEN);*/
      ucaReentryLen[0]=(unsigned char) (g_iBrhCodeLen+g_iTmCodeLen+5)/256;
      ucaReentryLen[1]=(unsigned char) (g_iBrhCodeLen+g_iTmCodeLen+5)%256;
      ucaReentryLen[2]=0x00;
      memcpy(pcSif+SIF_HEAD_LEN,ucaReentryLen,2);
      memcpy(&pcSif[SIF_HEAD_LEN+2],pcBrCode,g_iBrhCodeLen);
      memcpy(&pcSif[SIF_HEAD_LEN+2+g_iBrhCodeLen], pcTmCode, g_iTmCodeLen);
      memcpy(&pcSif[SIF_HEAD_LEN+2+g_iBrhCodeLen+g_iTmCodeLen], pcReentrySeqNo,
             5);
      memcpy(&pcSif[SIF_HEAD_LEN+2+g_iBrhCodeLen+g_iTmCodeLen+5], pcApInData+4,
             iApInDataLen-4);
      /* beacuse Add ReentrySeqNo to original DATA, original DATA len should be 
         added by (SIF_HEAD_LEN+2+g_iBrhCodeLen+g_iTmCodeLen+5)*/
      iSifLen = iApInDataLen + (SIF_HEAD_LEN+2+g_iBrhCodeLen+g_iTmCodeLen+5);
      break;

    default:
      UCP_TRACE_END(-2);
  }

  if (iSifLen > MAX_SIF_LEN){
    UCP_TRACE_END(-1);
  }

  UCP_TRACE_END(iSifLen);
}
