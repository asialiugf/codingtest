/* ------------------------- INCLUDE FILES ---------------------------- */
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <errno.h>
#include "errlog.h"
#include "tmcpgdef.h"	/* TMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */

/* ------------------------- CONSTANT DEFINITION ---------------------- */
/* tmsctf.c 
#define P_AttchCtf 		24401
#define P_AttchIct 		24402
#define P_AttchIet 		24403
#define P_CrtTblArea 		24404
*/
/* tmsctf.c error message code */
#define GET_SHM_ERR			-1
#define ATTCH_CTF_SHMGET_ERR 		-2
#define ATTCH_CTF_SHMAT_ERR 		-3
#define ATTCH_ICT_SHMGET_ERR 		-4
#define ATTCH_ICT_SHMAT_ERR 		-5
#define ATTCH_IET_SHMGET_ERR 		-6
#define ATTCH_IET_SHMAT_ERR 		-7


/* ---------------------------------- */
/*    create ctf item share memory    */
/* ---------------------------------- */
int CrtTblArea(kShmKey, uiShmSize, iShmMode, ppcShmAddr)
key_t kShmKey;
unsigned uiShmSize;
int  iShmMode;
char **ppcShmAddr;
{
  int iRc;

  UCP_TRACE( P_CrtTblArea );
  iRc = IpcShmCr( kShmKey, uiShmSize, iShmMode, ppcShmAddr);
  if ( iRc < 0 ) {
    ErrLog(1000,"CrtTblAre: Creat Shm Error!\n",RPT_TO_LOG,0,0);
    UCP_TRACE_END( GET_SHM_ERR );
  }
  
  UCP_TRACE_END(0);
}


/*
 *&N& ROUTINE NAME : AttchCtf()
 *&A& ARGUMENTS:
 *&A&   NAME             TYPE                 DESCRIPTION
 *&A& -------------------------------------------------------------------- 
 *&A&   iKey              int                 CTF �@�ΰO�аϪ� key
 *&A&  ppcCtf            char **              CTF �@�ΰO�аϪ��ҩl��}
 *&A&  
 *&R& RETURN VALUE(I);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&   
 *&D& DESCRIPTION:
 *&D&  �s���@�P����榡��(CTF_BOOK),��@�ΰO�а�(share memory)���ҩl��}
 *&D&  ��O�аϵ��c :
 *&D&
 *&D&  �z�w�w�w�w�w�w�w�w�w�w�w�w�{
 *&D&  �x��A���~�ȭӼ� (4 Byets)�x
 *&D&  �u�w�w�w�w�w�w�w�w�w�w�w�w�t
 *&D&  �x�@�Υ���榡�U�~�ȴy�z�Ϣx
 *&D&  �xbusi_ctf[��A���~�ȭӼ�]�x 
 *&D&  �x(sizeof(busi_ctf)*�~�ȭӼ�
 *&D&  �u�w�w�w�w�w�w�w�w�w�w�w�w�t
 *&D&  �x�U�~�ȩ��ݦ@�Υ���榡�ɢx
 *&D&  �x�U��ƶ��y�z,���e�Ѧ�   �x
 *&D&  �xtbl_item                �x
 *&D&  �x                        �x
 *&D&  �|�w�w�w�w�w�w�w�w�w�w�w�w�}
 *&D&     
 */

int
AttchCtf( iKey, ppcCtf )
int iKey;
char **ppcCtf;
{
    int iCtfBookShmId;

    UCP_TRACE( P_AttchCtf );

    iCtfBookShmId = shmget(iKey, 0, 0);
    if (iCtfBookShmId == -1) {
      sprintf(g_caMsg, "AttchCtf: shmget() fails! iKey=%d", iKey);
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      DetErrRpt( ATTCH_CTF_SHMGET_ERR, g_caMsg );
      UCP_TRACE_END( ATTCH_CTF_SHMGET_ERR );
    }

    *ppcCtf = (char *) shmat(iCtfBookShmId, 0, 0);
    if (*ppcCtf == (char *) -1) {
      sprintf(g_caMsg, "AttchCtf: shmat() fails! iCtfBookShmId=%d",
              iCtfBookShmId);
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      DetErrRpt( ATTCH_CTF_SHMAT_ERR, g_caMsg );
      UCP_TRACE_END( ATTCH_CTF_SHMAT_ERR );
    }

    UCP_TRACE_END(0);
}

/*
 *&N& ROUTINE NAME : AttchIct()
 *&A& ARGUMENTS:
 *&A&    NAME           TYPE                DESCRIPTION
 *&A&  ---------------------------------------------------------
 *&A&    iKey           int                 ICT �@�ΰO�аϪ� key
 *&A&  ppcIct           char **             ICT �@�ΰO�аϪ��ҩl��}
 *&A&  
 *&R& RETURN VALUE(I);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&   
 *&D& DESCRIPTION:
 *&D&  �s�� ICT �@�ΰO�а�(share memory)���ҩl��}
 *&D&     
 */

int
AttchIct( iKey, ppcIct )
int iKey;
char **ppcIct;
{
   int iIctShmId;

   UCP_TRACE( P_AttchIct );

   iIctShmId = shmget(iKey, 0, 0);
   if (iIctShmId == -1) {
     sprintf(g_caMsg, "AttchIct: shmget() fails! iKey=%d", iKey);
     ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
     DetErrRpt( ATTCH_ICT_SHMGET_ERR, g_caMsg );
     UCP_TRACE_END( ATTCH_ICT_SHMGET_ERR );
   }

   *ppcIct = (char *) shmat(iIctShmId, 0, 0);
   if (*ppcIct == (char *) -1) {
     sprintf(g_caMsg, "AttchIct: shmat() fails! iIctShmId=%d", iIctShmId);
     ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
     DetErrRpt( ATTCH_ICT_SHMAT_ERR, g_caMsg );
     UCP_TRACE_END( ATTCH_ICT_SHMAT_ERR );
   }

   UCP_TRACE_END( 0 );
}

/*
 *&N& ROUTINE NAME : AttchIet() 
 *&A& ARGUMENTS:
 *&A&    NAME           TYPE                DESCRIPTION
 *&A&  ----------------------------------------------------------
 *&A&    iKey           int                 IET �@�ΰO�аϪ� key
 *&A&  ppcIet           char **             IET �@�ΰO�аϪ��ҩl��}
 *&A&  
 *&R& RETURN VALUE(I);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&   
 *&D& DESCRIPTION:
 *&D&  �s�� IET �@�ΰO�а�(share memory)���ҩl��}
 *&D&  
 */

int
AttchIet( iKey, ppcIet )
int iKey;
char **ppcIet;
{
   int iIetShmId;

   UCP_TRACE( P_AttchIet );

   iIetShmId = shmget(iKey, 0, 0);
   if (iIetShmId == -1) {
     sprintf(g_caMsg, "AttchIet: shmget() fails! iKey=%d", iKey);
     ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
     DetErrRpt( ATTCH_IET_SHMGET_ERR, g_caMsg );
     UCP_TRACE_END( ATTCH_IET_SHMGET_ERR );
   }

   *ppcIet = (char *) shmat(iIetShmId, 0, 0);
   if (*ppcIet == (char *) -1) {
     sprintf(g_caMsg, "AttchIet: shmat() fails! iIetShmId=%d", iIetShmId);
     ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
     DetErrRpt( ATTCH_IET_SHMAT_ERR, g_caMsg );
     UCP_TRACE_END( ATTCH_IET_SHMAT_ERR );
   }

   UCP_TRACE_END( 0 );
}
