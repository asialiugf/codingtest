/*
 *&N& File : tmsremot.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int       LdTxMapFunName()
 *&N&    int       SrhFunByTxnCode()
 *&N&    int       RemoteTxn()
 *&N&    int       UCPOFFLN()
 */

/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include <errno.h>
#include "cwa.h"	/* �w�q TWA �ҨϥΨ쪺��Ƶ��c�α`�� */
#include "twa.h"	/* �w�q TWA �ҨϥΨ쪺��Ƶ��c�α`�� */
#include "tms.h"	/* �w�q tm �t�ΨϥΨ쪺��Ƶ��c�α`�� */
#include "errlog.h"	/* �O�����~�T���ɨϥΨ쪺�`�Ƥθ�Ƶ��c */
#include "dcs.h"
#include "ucp.h"
#include "tmcpgdef.h"

/* -------------------- CONSTANT DEFINE  --------------------------- */
/* TCC 1995/11/24 Begin */
#define  IS_SSA_OFFLINE                  & 0x1000
/* TCC 1995/11/24 End */
#define  CTL_ON				 1
#define  CTL_OFF			 0
#define  PRE_PROCESS			'1'
#define  POST_PROCESS			'2'
#define  MAX_TXN_MAP_FUN		1000
#define  LAST_MSG_MASK              	0x80
#define  TPEO_MSG_MASK              	0x02
#define  IS_BRH_ONLINE              	& 0x10
#define  IS_AP_ABEND              	& 0x08
#define  RCV_OK 			'1'
#define  RCV_ERR			'0'
#define  OUTPT_PREFIX	    "iii/log/output"
#define  COMMIT_FLAG                    '0' 

#define  LOAD_TXN_MAP_ERR		-1
#define  PRE_PROCESS_NOT_FOUND_ERR	-2
#define  AP_PRE_PROCESS_ERR		-3
#define  START_PGM_ERR			-4
#define  RECEIVE_ALL_ERR		-5
#define  CONV_IN_ERR			-6
#define  POST_PROCESS_NOT_FOUND_ERR	-7
#define  AP_POST_PROCESS_ERR		-8
#define  SRH_PRE_FUN_BY_TXN_CODE_ERR	-9
#define  SRH_POST_FUN_BY_TXN_CODE_ERR	-10
#define  PREPA_APA_TO_POST_AP_ERR	-11
#define  GET_BRH_PTR_ERR		-12
#define  FMT_CONV_ERR			-13
#define  CODE_CONV_ERR			-14
#define  GET_SERVER_NAME_ERR		-15
#define  GET_SSA_PTR_ERR		-16

/* -------------------- STATIC GLOBAL DECLARATION ------------------ */
struct TxMapFunSt{
  char caTxnCode[10];
  char caPreProcessName[20];
  char caPostProcessName[20];
};
static struct TxMapFunSt sg_staTxMapFun[MAX_TXN_MAP_FUN];
static int sg_iTotalTxMapFun;

/* -------------------- extern GLOBAL DECLARATION ------------------ */
extern char       *g_pcCtf;
extern struct TMA *g_pstTma;
extern struct TBA *g_pstTba;
extern struct APA *g_pstApa;
extern int    g_iBrhCodeLen;
extern int    g_iTmCodeLen;

/* -------------------- GLOBAL DECLARATION ------------------ */
struct DcsBuf  g_stDcsBuf;
struct DcsSiof g_stDcsSiof;
char           g_cProtoType;
int            g_iActSess;   /* local host to remote host's Session Index */
char           g_cRcvRmtDataFlag; /* indicate rcv rmt data OK or not?     */

void (*SrhPrePostFunAddr(char *))();

/*
 *&N& ROUTINE NAME: RemoteTxn()
 *&A& ARGUMENTS:
 *&A& ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D&
 */
RemoteTxn(pcSif,iSifLen)
char *pcSif;
int  iSifLen;
{
  int    iRc;
  char   caTmpBuf[30];
  struct DcsApi stDcsApi;
  char   caCtfHeader[30];  
  static int s_iFirst=0;
  struct BitBrhTermSt stBrhTerml;
  struct CwaCtl stCwaCtl;
  char   *pcBrh;
  struct BrhArea *pstBrh;
  char   cRmtApFlag; /* indicate remote AP execution result       */
  char   cBrhOfflnFlag;
  struct SSA *pstSsa;

  UCP_TRACE(P_RemoteTxn);
  ErrLog(100,"<APD>Remote-Txn BEGIN",RPT_TO_LOG,0,0);

  g_cRcvRmtDataFlag = RCV_ERR;

  if (s_iFirst == 0) {
    if (( iRc = LdTxMapFunName()) == -1) {
      ErrLog(1000,"<RemoteTxn>:LdTxMapFunName error!",RPT_TO_LOG,0,0);
      UCP_TRACE_END( LOAD_TXN_MAP_ERR );
    }
    s_iFirst = 1;
  }

  memset(&stDcsApi,0,sizeof(struct DcsApi));
  /* ---------------------------------------------------------------- */
  /*   0. preprocess of AP                                            */
  /* ---------------------------------------------------------------- */
  iRc = SrhFunByTxnCode(PRE_PROCESS,pcSif+4,caTmpBuf);
/* marked by WuChihLiang 1994/11/02 
  if ( iRc < 0 ) {
    sprintf(g_caMsg,"<RemoteTxn>: No Such Txn Code=%.4s!",pcSif+4);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END( SRH_PRE_FUN_BY_TXN_CODE_ERR );
  }
*/
  if (SrhPrePostFunAddr(caTmpBuf) == NULL) {
/* marked by WuChihLiang 1994/11/02 
      sprintf(g_caMsg,"<RemoteTxn>: No Such AP Prev-Process Function");
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END( PRE_PROCESS_NOT_FOUND_ERR );
*/
  } 
  else {
      sprintf(g_caMsg,"<APD>PRE-PROCESS Prog_name=%.10s",caTmpBuf);
      ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE(P_PRE_AP);
      (*SrhPrePostFunAddr)(caTmpBuf)
         (g_pstApa, g_pstTba->caCtf, g_pstTba->caRev,g_pstTba->caPara);
      UCP_TRACE_OVER;
#if defined(MF_COBOL) || defined(MF_COBOL_WITH_COBINIT)
      cobcancel(caTmpBuf);      
#endif
      iRc = ChkPrePostApRtnCode();

      if( iRc < 0 ) {
        UCP_TRACE_END( 0 );
      }

/*
      if( iRc < 0 ) {
        UCP_TRACE_END( AP_PRE_PROCESS_ERR );
      }
*/
  }

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac( &stCwaCtl, &pstSsa );

  if ( iRc != CWA_NORMAL ) {
    ErrLog( 1000, "<RemoteTxn>: Get SSA ptr Fail!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( GET_SSA_PTR_ERR );
  }

  stCwaCtl.cFunCode = CWA_GET_BRH_PTR;
  memcpy(stCwaCtl.caBrhId, g_pstTma->stTSSA.caBrCode, g_iBrhCodeLen);
  memcpy(stCwaCtl.caTermId, g_pstTma->stTSSA.caTmCode, g_iTmCodeLen);
  iRc = CwaLowCtlFac(&stCwaCtl, &pcBrh);
  if ( iRc < 0 ) {
    sprintf( g_caMsg, "<RemoteTxn>: Branch not registered in BIT" );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( GET_BRH_PTR_ERR );
  }

  pstBrh = (struct BrhArea *) pcBrh;

  if (pstBrh->cBrhStatus IS_BRH_ONLINE && !(pstSsa->sSysStatus IS_SSA_OFFLINE)){
    sprintf(g_caMsg,"<APD>Branch %.*s status is ONLINE",g_iBrhCodeLen,
            g_pstTma->stTSSA.caBrCode);
    ErrLog(100, g_caMsg, RPT_TO_LOG,0,0); 
    cBrhOfflnFlag = TMS_TXN_ONLINE;
    cRmtApFlag = TMS_AP_ACC_NORMAL;
    iRc = RmtProc(pcSif,iSifLen,&cRmtApFlag);
    if ( iRc < 0 ) {
      sprintf( g_caMsg, "<RemoteTxn>: Remote Process error!" );
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      switch( iRc ) {
        case -1:
          UCP_TRACE_END( FMT_CONV_ERR );
        case -2:
          UCP_TRACE_END( CODE_CONV_ERR );
        case -3:
          UCP_TRACE_END( GET_SERVER_NAME_ERR );
        case -4:
          UCP_TRACE_END( START_PGM_ERR );
        case -5:
          UCP_TRACE_END( RECEIVE_ALL_ERR );
        default:
          UCP_TRACE_END( -99 );
      }
    }
    /*
     * when remote txn has more 40k data , MemWrite function will flush all 
     * data to output??.####### file.
     * So, call MemClose() to close MemFileFd and set g_cFlushMemToFileFlag='y'
     */
    iRc=MemClose();  /* defined in tmsoutpt.c */
    if(iRc < 0) {
      UCP_TRACE_END(iRc);
    }
  }
  else {
    sprintf(g_caMsg,"<APD>Branch %.*s status is OFFLINE",g_iBrhCodeLen,
            g_pstTma->stTSSA.caBrCode);
    ErrLog(100, g_caMsg, RPT_TO_LOG,0,0);
    cRmtApFlag = TMS_AP_ACC_NORMAL; /* for doing POST-AP,even OFFLINE */
    cBrhOfflnFlag = TMS_TXN_OFFLINE;
    UCPOFFLN(g_pstApa, iSifLen, pcSif);
  }
  /* --------------------------------------------------------------- */
  /* txn commit & txn start                                          */
  /* --------------------------------------------------------------- */
  iRc = DbsTxEnd( COMMIT_FLAG );
  iRc = DbsTxBegin();

  /* --------------------------------------------------------------- */
  /* if remote AP normal ends, then do POST processing, otherwise    */
  /* nothing to do.....                                              */
  /* --------------------------------------------------------------- */
  if (cRmtApFlag == TMS_AP_ACC_NORMAL) {
    iRc = PrepaApaToPostAp(&cBrhOfflnFlag);
    if ( iRc < 0 ) {
      UCP_TRACE_END( PREPA_APA_TO_POST_AP_ERR);
    }

    iRc = SrhFunByTxnCode(POST_PROCESS,pcSif+4,caTmpBuf);
    if ( iRc < 0 ) {
/* marked by WuChihLiang 1994/11/02 
      sprintf(g_caMsg,"<RemoteTxn>: No Such Txn Code=%.4s!",pcSif+4);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END( SRH_POST_FUN_BY_TXN_CODE_ERR );
*/
    }

    if (SrhPrePostFunAddr(caTmpBuf) == NULL) {
/* marked by WuChihLiang 1994/11/02 
      sprintf(g_caMsg,"<RemoteTxn>: No Such AP Post Function=%s",caTmpBuf);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END( POST_PROCESS_NOT_FOUND_ERR );
*/
    }
    else {
      sprintf(g_caMsg,"<APD>POST-PROCESS Prog_name=%.10s",caTmpBuf);
      ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
      /*sprintf(g_caMsg,"<RemoteTxn>: POST EJ data=");
      ErrLog(100,g_caMsg,RPT_TO_LOG,g_pstTba->caPara,200);*/
      UCP_TRACE(P_POST_AP);
      (*SrhPrePostFunAddr)(caTmpBuf)
         (g_pstApa, g_pstTba->caCtf, g_pstTba->caRev,g_pstTba->caPara);
      UCP_TRACE_OVER;
#if defined(MF_COBOL) || defined(MF_COBOL_WITH_COBINIT)
      cobcancel(caTmpBuf);      
#endif
     /* iRc = ChkPrePostApRtnCode();
      if( iRc < 0 ) {
          UCP_TRACE_END( AP_POST_PROCESS_ERR );
      }*/
    }
  }

  ErrLog(100,"<APD>Remote-Txn END",RPT_TO_LOG,0,0);
  UCP_TRACE_END(0);
} 



/*
 *&N& ROUTINE NAME: LdTxMapFunName()
 *&A& ARGUMENTS:
 *&A& ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& ����ƱqTMA��,�NAP�|�ϥΨ쪺��ƽƻs��APA��,�p:
 *&D&
 */
int
LdTxMapFunName()
{
    int i;
    FILE *pzFd;
    char caFileName[80];

    UCP_TRACE(P_LdTxMapFunName);
    sprintf(g_caMsg,"<LdTxMapFunName>: start");
    ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);

    strcpy((char *)caFileName, (char *)getenv("III_DIR"));
    strcat((char *)caFileName,"/iii/etc/tbl/txn2fun.dat");
    if((pzFd = fopen(caFileName,"r")) == (FILE *) 0){
       sprintf(g_caMsg,"<LdTxMapFunName>: open %s error=%d",caFileName,errno);
       ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
       UCP_TRACE_END(-1);
    }
    sprintf(g_caMsg,"<LdTxMapFunName>: open %s O.K.",caFileName);
    ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

    i = 0;
    while(fscanf(pzFd,"%s %s %s",sg_staTxMapFun[i].caTxnCode,
          sg_staTxMapFun[i].caPreProcessName,sg_staTxMapFun[i].caPostProcessName)!= EOF){
        if(i++ > MAX_TXN_MAP_FUN){
           sprintf(g_caMsg,"<LdTxMapFunName>: table array overflow");
           ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
           fclose(pzFd);
           UCP_TRACE_END(-2);
        }
    }
    
    sg_iTotalTxMapFun = i;
    fclose(pzFd);
    sprintf(g_caMsg,"<LdTxMapFunName>: end");
    ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(0);
}


/*
 *&N& ROUTINE NAME: SrhFunByTxnCode()
 *&A& ARGUMENTS:
 *&A& ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& ����ƱqTMA��,�NAP�|�ϥΨ쪺��ƽƻs��APA��,�p:
 *&D&
 */
int
SrhFunByTxnCode(cSrhFlag,pcTxnCode,pcFunName)
char cSrhFlag;
char *pcTxnCode;
char *pcFunName;
{
    int i;

    UCP_TRACE(P_SrhFunByTxnCode);

    for (i=0;i < sg_iTotalTxMapFun; i++) {
      if (strncmp(sg_staTxMapFun[i].caTxnCode,pcTxnCode,4) == 0){
        break;
      }
    }
    if (i == sg_iTotalTxMapFun) {
      i = -1;
    }
    else{
      switch(cSrhFlag){
        case PRE_PROCESS:
          strcpy(pcFunName,sg_staTxMapFun[i].caPreProcessName);
          break;
        case POST_PROCESS:
          strcpy(pcFunName,sg_staTxMapFun[i].caPostProcessName);
          break;
        default:
          i = -1;
      }
    }
    UCP_TRACE_END(i);
}



/*
 *&N& ROUTINE NAME: UCPOFFLN()
 *&A& ARGUMENTS:
 *&A& ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D&
 */
UCPOFFLN(pstApa, iSifLen, pcSif)
struct ApaSt *pstApa;
int iSifLen;
char *pcSif;
{
  ErrLog(100,"Enter UCPOFFLN.......",RPT_TO_LOG,0,0);
}
