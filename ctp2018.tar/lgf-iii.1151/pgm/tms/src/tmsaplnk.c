
/*
 *&D&                   API           ��ƷJ�`
 *&D&------------------------------------------------------------------------
 *&D& 1  void     TPEWRITE            �NAP�e�X�����,�Ȧs���ɭ�
 *&D& 2  void     TPESDOUT            �NAP�e�X�����,���W�e�X���ɭ�
 *&D& 3  void     TPETXLOG            AP�z�L���ɭ��gLOG
 *&D& 4  void     TPEAPRQT            AP�z�L���ɭ��I�s�`�ǳs�ʡB�_���s��
 *&D& 5  void     TPESCRQT            �e���s�� 
 *&D& 6  void     TPGIOHDL            �妸�B�z�e������ 
 *&D& 7  void     TPFRPT              �妸�B�z��ƿ�X
 *&D& 8  void     TPFDBS              ��ƮwDBS�ɭ� 
 *&D& 9  void     TPFFCS              ��ƮwFCS�ɭ� 
 *&D& 10 void     TPEDCS              �����A�Ȭɭ�
 *&D& 11 void     TPESDCLT            �NAP�e�X�����,�ǰe������D��
 *&D& 12 void     TPFLOGOP            AP�z�L���ɭ�Ū�gLOG          
 *&D& 13 void     TPFCWARW            AP�z�L���ɭ�Ū�gCWA          
 *&D& 14 void     TPERVSOP            AP�z�L���ɭ�Ū�gLOG          
 *&D& 15 void     TPEGPREV            AP�z�L���ɭ�Ū���e�@��LOG          
 *&D& 16 void     TPFGTSEQ          
 *&D& 17 void     TPFADSEQ         
 *&D& 18 void     TPFRKSEQ        
 *&D& 19 void     TPEONBTH        
 *&D& 20 void     TPFSETLN        
 *&D& 21 void     TPEGTSIF        
 *&D& 19 void     TPEONBH1
*/
 

/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include "twa.h"
#include "errlog.h"
#include "tms.h"
#include "dcs.h"
#include "fcstwa.h"      /* ---�Ȯɥ[�J for compile -------- */
#include "tmcpgdef.h"	/* TMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */
#include "ucp.h"
#include "lgcopewa.h"	

/* -------------------- CONSTANT DEFINE  --------------------------- */
#define MSGP_DATA               'm'
#define POST_DATA               'p'
#define PRNT_DATA               'r'
#define SIF_DATA                's'
#define APRQT_DATA_LEN_SIZE      4
#define AP_MSG_DATA_LEN_SIZE     4
#define ONBTH_DATA_LEN_SIZE      4
#define ONBH1_DATA_LEN_SIZE      4
#define AP_MSG_HEAD_LEN          10  /* conatin return code (1 byte) length  */

#define MAX_MSGP_BUFFER   1024 * 20
#define MAX_MSGP_DATA	  MAX_MSGP_BUFFER - sizeof(struct MsgBufCtlSt)
/* -------------------- STATIC GLOBAL DECLARATION ------------------ */

struct MsgBufCtlSt {
  int iMsgCnt;
  int iNextOffset;
};

extern struct TMA  *g_pstTma;
extern struct COA  *g_pstCoa;
extern struct TBA  *g_pstTba;


TPEWRITE(char *pcArg0, char *pcArg1)
/* pcArg0 ---> APA
   pcArg1 ---> WriteSt  */
{
  int    iRc;                               /* for ������ƶǦ^�� */
  struct WriteSt *pstWrite;
  struct MsgBufCtlSt *pstMsgBufCtl;
  int    iLen;
  int    iDataLen;
  char   caApMsgLen[10];

  UCP_TRACE(P_TPEWRITE_AP);
  pstMsgBufCtl = ( struct MsgBufCtlSt * ) g_pstTba->caMsgp;
  pstWrite = (struct WriteSt *) pcArg1;

  /* ----- check out device defined or undefined ---------------- */
  /* ----- Mark for hwa-chi 1994/10/21 
  if ( pstWrite->stWriteData.cOutDevType != '1' && 
       pstWrite->stWriteData.cOutDevType != '2' &&
       pstWrite->stWriteData.cOutDevType != '3' &&
       pstWrite->stWriteData.cOutDevType != '6' &&
       pstWrite->stWriteData.cOutDevType != 'M' &&
       pstWrite->stWriteData.cOutDevType != '*' &&
       pstWrite->stWriteData.cOutDevType != 'Y' )  {
    sprintf( g_caMsg,"<<<tmsaplnk>>> TPEWRITE invalid out device! %c",
             pstWrite->stWriteData.cOutDevType);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstWrite->cWriteRtnCode = TMS_MSGP_DEV_ERR;
    UCP_TRACE_END( -1 );
  } */

  /* ---------------------------------------------------------------- */
  /* new API-------> for new control structure                        */
  /* copy AP msg to TWA.PARA  && copy control information TWA.COA     */
  /* ---------------------------------------------------------------- */
  pstWrite->cWriteRtnCode = TMS_MSGP_NORMAL;
  memset( caApMsgLen, 0, 10 );
  memcpy( caApMsgLen, pstWrite->stWriteData.caDataLen, AP_MSG_DATA_LEN_SIZE );
  iDataLen = atoi( caApMsgLen );

  /* -----------------  check  output  msg.  length   -------------- */
  if ( iDataLen > 2000 ) {
    sprintf( g_caMsg,"<<<tmsaplnk>>> TPEWRITE data len overflow! %.4s --> %d",
             pstWrite->stWriteData.caDataLen, iDataLen);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstWrite->cWriteRtnCode = TMS_MSGP_LEN_ERR;
    UCP_TRACE_END( -1 );
  }

  iLen = AP_MSG_HEAD_LEN + iDataLen;
  ErrLog(100,"<<<tmsaplnk>>> enter TPEWRITE, dump MSGP=",
         RPT_TO_LOG,pstWrite,iLen+1);

  /* -----avoid AP's output data exceeds the limits of MSGP buffer ---*/
#ifdef LIMIT_20K
  if ( (pstMsgBufCtl->iNextOffset + iLen) > MAX_MSGP_DATA ) {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPEWRITE TBA.MSGP Full! iNextOffset=%d,iLen=%d",
            pstMsgBufCtl->iNextOffset, iLen);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstWrite->cWriteRtnCode = TMS_MSGP_LEN_ERR;
    UCP_TRACE_END( -1 );
  }
#endif

  iRc = WriteToTba(iLen, (char *) pstWrite , MSGP_DATA);

  if (iRc != 0) {
    sprintf(g_caMsg,"<<<tmsaplnk>>> TPEWRITE WriteToTba fail!");
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
  }      

  /* ---------------------------------------------------------------- */
  /*    prepare  information  for  service  function                  */
  /* ---------------------------------------------------------------- */
  g_pstTma->stTCFA.cProcSemNo  = '2';
  g_pstTma->stTCFA.cReqSrvCode = FUN_WRITE;

  /* ---------------------------------------------------------------- */
  /*   wake up TPU                                                    */
  /* ---------------------------------------------------------------- */
  iRc = WakeTpu();

  if ( iRc != 0 ) {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPEWRITE wake TPU faile errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
  }

  /* ---------------------------------------------------------------- */
  /*    decrement  A.P.  process's  semophare  identifier             */
  /* ---------------------------------------------------------------- */
  iRc = SleepAp();

  if ( iRc != 0 ) {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPEWRITE sleep AP fail errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0);
  }

  pstWrite->cWriteRtnCode = g_pstTba->caPara[0] ;
  ErrLog(100,"<<<tmsaplnk>>> exit TPEWRITE, dump MSGP-RETURN-CODE=",
         RPT_TO_LOG,pstWrite,1);

  UCP_TRACE_END(0);
}



TPESDOUT(char *pcArg0, char *pcArg1)
/* pcArg0 ---> APA
   pcArg1 ---> SdoutSt */
{
  int    iRc;                               /* for ������ƶǦ^�� */
  struct SdoutSt *pstSdout;
  int    iLen;
  int    iDataLen;
  char   caApMsgLen[10];

  UCP_TRACE(P_TPESDOUT_AP);
  pstSdout = (struct SdoutSt *) pcArg1;
  /* ----- check out device defined or undefined ---------------- */
  /* ----- Mark for hwa-chi 1994/10/21 
 */

/*if ( pstSdout->stSdoutData.cOutDevType != '1' && --> by TPEUNIX975005*/

  if ( pstSdout->stSdoutData.cOutDevType != '*' &&
       pstSdout->stSdoutData.cOutDevType != '2' &&
       pstSdout->stSdoutData.cOutDevType != '6' ) {
    sprintf( g_caMsg,"<<<tmsaplnk>>> TPESDOUT invalid out device! %c",
             pstSdout->stSdoutData.cOutDevType);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstSdout->cSdoutRtnCode = TMS_MSGP_DEV_ERR;
    UCP_TRACE_END( -1 );
  }

  /* ---------------------------------------------------------------- */
  /*  new API-------> for new control structure                       */
  /*  copy AP msg to TWA.PARA   &&                                    */
  /*  copy control information in APA to TWA.COA                      */
  /* ---------------------------------------------------------------- */
  pstSdout->cSdoutRtnCode = TMS_MSGP_NORMAL;
  memset( caApMsgLen, 0, 10 );
  memcpy( caApMsgLen, pstSdout->stSdoutData.caDataLen, AP_MSG_DATA_LEN_SIZE );
  iDataLen = atoi( caApMsgLen );

/* -----------------  check  output  msg.  length   -------------- */
/*  if ( iDataLen > 5000 ) {  ----> modified by TPEUNIX960103 */
  if ( iDataLen > 2000 ) {
    sprintf( g_caMsg,"<<<tmsaplnk>>> TPESDOUT data len overflow! %.4s --> %d",
             pstSdout->stSdoutData.caDataLen, iDataLen);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstSdout->cSdoutRtnCode = TMS_MSGP_LEN_ERR;
    UCP_TRACE_END( -1 );
  }

  iLen = AP_MSG_HEAD_LEN + iDataLen;
  ErrLog(100,"<<<tmsaplnk>>> enter TPESDOUT, dump MSGP=",
         RPT_TO_LOG,pstSdout,iLen+1);

  iRc = WriteToTba(iLen, (char *) pstSdout , PRNT_DATA);

  if (iRc != 0) {
    sprintf(g_caMsg,"<<<tmsaplnk>>> TPESDOUT WriteToTba fail!");
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
  }      

  /* ---------------------------------------------------------------- */
  /*    prepare  information  for  service  function                  */
  /* ---------------------------------------------------------------- */
  g_pstTma->stTCFA.cProcSemNo  = '2';
  g_pstTma->stTCFA.cReqSrvCode = FUN_PRINT;

  /* ---------------------------------------------------------------- */
  /*   wake up TPU                                                    */
  /* ---------------------------------------------------------------- */
  iRc = WakeTpu();

  if ( iRc != 0 ) {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPESDOUT wake TPU faile errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
  }

  /* ---------------------------------------------------------------- */
  /*    decrement  A.P.  process's  semophare  identifier             */
  /* ---------------------------------------------------------------- */
  iRc = SleepAp();

  if ( iRc != 0 ) {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPESDOUT sleep AP fail errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0);
  }

  pstSdout->cSdoutRtnCode = g_pstTba->caPara[0] ;
  ErrLog(100,"<<<tmsaplnk>>> exit TPESDOUT, dump MSGP-RETURN-CODE=",
         RPT_TO_LOG,pstSdout,1);

  UCP_TRACE_END(0);
}


TPETXLOG(char *pcArg0,char *pcArg1)
/*  pcArg0 -->  APA
    pcArg1 -->  log data structure  */
{
  int iRc;
  struct LogSt *pstLog;

  UCP_TRACE(P_TPETXLOG_AP);
  pstLog = (struct LogSt *)pcArg1;
  pstLog->cLogReturnCode = TMS_TXLOG_NORMAL;
  ErrLog(100,"<<<tmsaplnk>>> enter TPETXLOG, dump LOGP=",
         RPT_TO_LOG,pstLog,sizeof(struct LogSt));

  /* ---------------------------------------------------------------- */
  /*    copy  log  data  to  TWA.PARA                                 */
  /* ---------------------------------------------------------------- */
  memcpy(g_pstTba->caPara,(char *) pstLog, sizeof(struct LogSt));

  /* ---------------------------------------------------------------- */
  /*    prepare  information  for  service  function                  */
  /* ---------------------------------------------------------------- */
  g_pstTma->stTCFA.cProcSemNo  = '2';
  g_pstTma->stTCFA.cReqSrvCode = FUN_TXLOG;

  /* ---------------------------------------------------------------- */
  /*   wake up TPU                                                    */
  /* ---------------------------------------------------------------- */
  iRc = WakeTpu();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPETXLOG wake TPU faile errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
  }

  /* ---------------------------------------------------------------- */
  /*    decrement  A.P.  process's  semophare  identifier             */
  /* ---------------------------------------------------------------- */
  iRc = SleepAp();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPETXLOG sleep AP fail errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0);
  }

  pstLog->cLogReturnCode = g_pstTba->caPara[0];
  memcpy(pstLog->caLogReturnRrn,&g_pstTba->caPara[1],8);
  ErrLog(100,"<<<tmsaplnk>>> exit TPETXLOG, dump LOGP=",
         RPT_TO_LOG,pstLog,9);
  UCP_TRACE_END(0);
}


TPEAPRQT(char *pcArg0, char *pcArg1,char *pcArg2)
/* pcArg0 --->  APA
   pcArg1 --->  control part "ApRqtCtlSt"
   pcArg2 --->  data part                 */
{
  int iRc;
  char caDataLen[10];
  struct ApRqtCtlSt *pstApRqt;
  int iDataLen;

  UCP_TRACE(P_TPEAPRQT_AP);

  /* ---------------------------------------------------------------- */
  /*    prepare  information  for  service  function                  */
  /* ---------------------------------------------------------------- */
  g_pstTma->stTCFA.cProcSemNo  = '2';
  g_pstTma->stTCFA.cReqSrvCode = FUN_APRQT;

  /* ---------------------------------------------------------------- */
  /*  copy Control part to TWA.COA                                    */
  /*  copy AP msg to TWA.PARA                                         */
  /* ---------------------------------------------------------------- */
  pstApRqt = (struct ApRqtCtlSt *) pcArg1;
  pstApRqt->cReturnCode = TMS_APRQT_NORMAL;
  memcpy( g_pstCoa, pstApRqt, sizeof(struct ApRqtCtlSt) );

  ErrLog(100,"<<<tmsaplnk>>> enter TPEAPRQT, dump RQTP-CTL=",
         RPT_TO_LOG,pstApRqt,sizeof(struct ApRqtCtlSt));

  if ( pstApRqt->cFunCode != '1' && pstApRqt->cFunCode != '2' ) {
    sprintf( g_caMsg,"<<<tmsaplnk>>> TPEAPRQT: invalid cfuncode! %c",
             pstApRqt->cFunCode);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstApRqt->cReturnCode = TMS_APRQT_PARA_ERR;
    UCP_TRACE_END( -1 );
  }

  memset( caDataLen, 0, 10);
  memcpy( caDataLen, pstApRqt->caDataLen, APRQT_DATA_LEN_SIZE);
  iDataLen = atoi( caDataLen );

  if ( iDataLen > MAX_SIF_LEN ) {
    sprintf( g_caMsg,"<<<tmsaplnk>>> TPEAPRQT: invalid data length! %d",
             iDataLen);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstApRqt->cReturnCode = TMS_APRQT_PARA_ERR;
    UCP_TRACE_END( -1 );
  }

  switch ( pstApRqt->cFmtCode ) {
    case FMT_1:
    case FMT_2:
      memcpy( g_pstTba->caPara, pcArg2, iDataLen );
      break;
    case FMT_CTF:
      memcpy( g_pstTba->caPara, pcArg2, MAX_CTF_LEN );
      break;
    default:
      sprintf( g_caMsg,"<<<tmsaplnk>>> TPEAPRQT: invalid cfmtcode! %c",
               pstApRqt->cFmtCode);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstApRqt->cReturnCode = TMS_APRQT_PARA_ERR;
      UCP_TRACE_END( -1 );
  }

  ErrLog(100,"<<<tmsaplnk>>> enter TPEAPRQT, dump RQTP-DATA=",
         RPT_TO_LOG,pcArg2,iDataLen);
  /* ---------------------------------------------------------------- */
  /*   wake up TPU                                                    */
  /* ---------------------------------------------------------------- */
  iRc = WakeTpu();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPEAPRQT wake TPU faile errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
  }

  /* ---------------------------------------------------------------- */
  /*    decrement  A.P.  process's  semophare  identifier             */
  /* ---------------------------------------------------------------- */
  iRc = SleepAp();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPEAPRQT sleep AP fail errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0);
  }

  memcpy( pstApRqt, g_pstCoa, sizeof(struct ApRqtCtlSt) );
  ErrLog(100,"<<<tmsaplnk>>> exit TPEAPRQT, dump RQTP-CTL=",
         RPT_TO_LOG,pcArg1,sizeof(struct ApRqtCtlSt));
  UCP_TRACE_END(0);
}



TPESCRQT(char *pcArg0, char *pcArg1, char *pcArg2)
/* pcArg0 ---> APA
   pcArg1 ---> control part "ReinputCtlSt"
   pcArg2 ---> data part                 */
{
  int iRc;
  struct ReinputCtlSt *pstReinput;
  char caDataLen[10];
  int iDataLen;

  UCP_TRACE(P_TPESCRQT_AP);

  /* ---------------------------------------------------------------- */
  /*    prepare  information  for  service  function                  */
  /* ---------------------------------------------------------------- */
  g_pstTma->stTCFA.cProcSemNo  = '2';
  g_pstTma->stTCFA.cReqSrvCode = FUN_REINPUT;

  /* ---------------------------------------------------------------- */
  /*  copy Control part to TWA.COA                                    */
  /*  copy AP msg to TWA.PARA                                         */
  /* ---------------------------------------------------------------- */
  pstReinput = (struct ReinputCtlSt *) pcArg1;
  pstReinput->cReturnCode = TMS_REINPUT_NORMAL;
  memcpy( g_pstCoa, pstReinput, sizeof(struct ReinputCtlSt) );

  ErrLog(100,"<<<tmsaplnk>>> enter TPESCRQT, dump RQTP-CTL=",
         RPT_TO_LOG,pstReinput,sizeof(struct ReinputCtlSt));

  if( pstReinput->cFunCode != '1' ) {
    sprintf( g_caMsg,"<<<tmsaplnk>>> TPESCRQT invalid cfuncode! %c",
             pstReinput->cFunCode);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstReinput->cReturnCode = TMS_REINPUT_PARA_ERR;
    UCP_TRACE_END( -1 );
  }

  memset(caDataLen, 0, 10);
  memcpy(caDataLen, pstReinput->caDataLen, APRQT_DATA_LEN_SIZE);
  iDataLen = atoi ( caDataLen );

  if( iDataLen > MAX_SIF_LEN ) {
    sprintf( g_caMsg,"<<<tmsaplnk>>> TPESCRQT invalid data length! %d",
             iDataLen);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstReinput->cReturnCode = TMS_REINPUT_PARA_ERR;
    UCP_TRACE_END( -1 );
  }

  switch ( pstReinput->cFmtCode ) {
    case FMT_1:
    case FMT_2:
      memcpy( g_pstTba->caPara, pcArg2, iDataLen );
      break;
    case FMT_CTF:
      memcpy( g_pstTba->caPara, pcArg2, MAX_CTF_LEN );
      break;
    default:
      sprintf( g_caMsg,"<<<tmsaplnk>>> TPESCRQT invalid cfmtcode! %c",
               pstReinput->cFmtCode);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstReinput->cReturnCode = TMS_REINPUT_PARA_ERR;
      UCP_TRACE_END( -1 );
  }

  ErrLog(100,"<<<tmsaplnk>>> enter TPESCRQT, dump RQTP-DATA=",
         RPT_TO_LOG,pcArg2,iDataLen);
  /* ---------------------------------------------------------------- */
  /*   wake up TPU                                                    */
  /* ---------------------------------------------------------------- */
  iRc = WakeTpu();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPESCRQT wake TPU faile errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
  }

  /* ---------------------------------------------------------------- */
  /*    decrement  A.P.  process's  semophare  identifier             */
  /* ---------------------------------------------------------------- */
  iRc = SleepAp();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPESCRQT sleep AP fail errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0);
  }

  memcpy( pstReinput, g_pstCoa, sizeof(struct ReinputCtlSt) );
  ErrLog(100,"<<<tmsaplnk>>> exit TPESCRQT, dump RQTP-CTL=",
         RPT_TO_LOG,pcArg1,sizeof(struct ReinputCtlSt));
  UCP_TRACE_END(0);
}


TPGIOHDL(char *pcArg0,char *pcArg1)
/*  pcArg0 -->  APA
    pcArg1 -->  BIOP structure  */
{
  int iRc;
  struct JclIoSt *pstJclIo;

  UCP_TRACE(P_TPGIOHDL_AP);
  pstJclIo = (struct JclIoSt *) pcArg1;
  /* ---------------------------------------------------------------- */
  /*    copy  BIOP  data  to  TWA.PARA                                 */
  /* ---------------------------------------------------------------- */
  pstJclIo->cJclIoRtnCode = TMS_JCLIO_NORMAL;
  memcpy( g_pstTba->caPara, pstJclIo, sizeof(struct JclIoSt) );

  ErrLog(100,"<<<tmsaplnk>>> enter TPGIOHDL, dump BIOP=",
         RPT_TO_LOG, pstJclIo,sizeof(struct JclIoSt));

/*
*/
  if ( pstJclIo->cCmdNo > '5' ) {
    sprintf( g_caMsg,"<<<tmsaplnk>>> TPGIOHDL invalid cmd. number! %d",
             pstJclIo->cCmdNo);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstJclIo->cJclIoRtnCode = TMS_JCLIO_CMDNO_ERR;
    UCP_TRACE_END( -1 );
  }

  /* ---------------------------------------------------------------- */
  /*    prepare  information  for  service  function                  */
  /* ---------------------------------------------------------------- */
  g_pstTma->stTCFA.cProcSemNo  = '2';
  g_pstTma->stTCFA.cReqSrvCode = FUN_JCLIO;

  /* ---------------------------------------------------------------- */
  /*   wake up TPU                                                    */
  /* ---------------------------------------------------------------- */
  iRc = WakeTpu();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPGIOHDL wake TPU faile errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
  }

  /* ---------------------------------------------------------------- */
  /*    decrement  A.P.  process's  semophare  identifier             */
  /* ---------------------------------------------------------------- */
  iRc = SleepAp();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPGIOHDL sleep AP fail errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0);
  }

  memcpy( pstJclIo, g_pstTba->caPara, sizeof(struct JclIoSt) );
  ErrLog(100,"<<<tmsaplnk>>> exit TPGIOHDL, dump BIOP=",RPT_TO_LOG,
         pstJclIo,sizeof(struct JclIoSt));
  UCP_TRACE_END(0);
}



TPFRPT(char *pcArg0,char *pcArg1)
/*  pcArg0 -->  APA
    pcArg1 -->  FrptSt structure  */
{
  int iRc;
  struct FrptSt *pstFrpt;
  char caApMsgLen[10];
  int iDataLen;

  UCP_TRACE(P_TPFRPT_AP);

  /* ---------------------------------------------------------------- */
  /*    check input data                                              */
  /* ---------------------------------------------------------------- */
  pstFrpt = (struct FrptSt *) pcArg1;

  if ( pstFrpt->stFrptData.cOutDevType != '*' && 
                                  pstFrpt->stFrptCtl.cCmdCode == '1' ) {
    sprintf( g_caMsg,"<<<tmsaplnk>>> TPFRPT invalid out device! %c",
             pstFrpt->stFrptData.cOutDevType );
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstFrpt->stFrptCtl.cFrptRtnCode = TMS_TPFRPT_DEV_ERR;
    UCP_TRACE_END( -1 );
  }

  memset( caApMsgLen, 0, 10 );
  memcpy( caApMsgLen, pstFrpt->stFrptData.caDataLen, AP_MSG_DATA_LEN_SIZE );
  iDataLen = atoi( caApMsgLen );

  /* -----------------  check  output  msg.  length   -------------- */
  if ( iDataLen > 5000 ) {
    sprintf( g_caMsg,"<<<tmsaplnk>>> TPFRPT data len overflow! %.4s --> %d",
             pstFrpt->stFrptData.caDataLen, iDataLen);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstFrpt->stFrptCtl.cFrptRtnCode = TMS_TPFRPT_LEN_ERR;
    UCP_TRACE_END( -1 );
  }

  /* ---------------------------------------------------------------- */
  /*    copy  BIOP  data  to  TWA.PARA                                 */
  /* ---------------------------------------------------------------- */
  memset(g_pstTba->caPara,0,MAX_TBA_PARA_LEN);/*Add Miao 19981231 for tu980534*/
  pstFrpt->stFrptCtl.cFrptRtnCode = TMS_TPFRPT_NORMAL;
  memcpy(g_pstTba->caPara, pcArg1, sizeof(struct FrptCtlSt)+9+iDataLen);

  ErrLog(100,"<<<tmsaplnk>>> enter TPFRPT, dump MSGP-CTL-AREA=",
         RPT_TO_LOG,&pstFrpt->stFrptCtl,sizeof(struct FrptCtlSt) );

  ErrLog(100,"<<<tmsaplnk>>> enter TPFRPT, dump MSGP-DATA=",
         RPT_TO_LOG,&pstFrpt->stFrptData,iDataLen+9 );
  /* ---------------------------------------------------------------- */
  /*    prepare  information  for  service  function                  */
  /* ---------------------------------------------------------------- */
  g_pstTma->stTCFA.cProcSemNo  = '2';
  g_pstTma->stTCFA.cReqSrvCode = FUN_FRPT;

  /* ---------------------------------------------------------------- */
  /*   wake up TPU                                                    */
  /* ---------------------------------------------------------------- */
  iRc = WakeTpu();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPFRPT wake TPU faile errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
  }

  /* ---------------------------------------------------------------- */
  /*    decrement  A.P.  process's  semophare  identifier             */
  /* ---------------------------------------------------------------- */
  iRc = SleepAp();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,"<<<tmsaplnk>>> TPFRPT sleep AP fail errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0);
  }

  memcpy(&pstFrpt->stFrptCtl, g_pstTba->caPara, sizeof(struct FrptCtlSt));
  ErrLog(100,"<<<tmsaplnk>>> exit TPFRPT, dump MSGP-CTL-AREA=",
         RPT_TO_LOG,&pstFrpt->stFrptCtl,sizeof(struct FrptCtlSt) );
  UCP_TRACE_END(0);
}



TPFDBS(char *pcArg0,char *pcArg1,char *pcArg2)
{
  int  iRc ;                    /* for ������ƶǦ^�� */
  int  iSegSize;                /* segment size       */
  struct DbsSt *pstDbs;         /* ���V DBS control��Ƶ��c��pointer */

  UCP_TRACE(P_TPFDBS_AP);
  /* ---------------------------------------------------------------- */
  /* new API-------> for new control structure                        */
  /* pcArg1 pointer to a structure of TPFDBS's control part           */
  /* copy  AP �ǨӪ� TPFDBS control part to TWA.COA                   */
  /* ---------------------------------------------------------------- */

  pstDbs = (struct DbsSt *) pcArg1;
  memset(&pstDbs->cDbsReturnCode,'0',3);
  memcpy(g_pstCoa, pcArg1, sizeof(struct DbsSt));

  ErrLog(100,"<<<tmsaplnk>>> enter TPFDBS, dump DBS-CTL=",
         RPT_TO_LOG,pstDbs,sizeof(struct DbsSt));

  if ( ( pstDbs->cDbsFunCode != TMS_READ_UPDATE_NOIOA )
    && ( pstDbs->cDbsFunCode != TMS_OPEN )
    && ( pstDbs->cDbsFunCode != TMS_CLOSE ) ) {
     iSegSize = GetSegSize(pstDbs->caDbsSegName);
     sprintf(g_caMsg,"<<<tmsaplnk>>> TPFDBS seg_leng=%d seg_name=%.8s"
             ,iSegSize, pstDbs->caDbsSegName);
     ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

     if ( iSegSize == -1 ) {
        pstDbs->cDbsReturnCode = '5'; /* inform AP that segment not found ! */
        memcpy(pstDbs->caDbsErrCode,"07",2);
        ErrLog(1000,"<<<tmsaplnk>>> TPFDBS dbt segment get error",
               RPT_TO_LOG,0,0);
        UCP_TRACE_END(-1);
     }

     sprintf(g_caMsg,"<<<tmsaplnk>>> enter TPFDBS,SIZE=%d dump DBS-IO-AREA:",
             iSegSize);
     ErrLog(100,g_caMsg,RPT_TO_LOG,pcArg2,iSegSize);
     memcpy(g_pstTba->caPara,pcArg2,iSegSize);
  }

  /* ---------------------------------------------------------------- */
  /*   prepare  information  for  service  function                   */
  /* ---------------------------------------------------------------- */
  g_pstTma->stTCFA.cProcSemNo  = '2';
  g_pstTma->stTCFA.cReqSrvCode = FUN_DBS;

  /* ---------------------------------------------------------------- */
  /*   wake up TPU                                                    */
  /* ---------------------------------------------------------------- */
  iRc = WakeTpu();

  if ( iRc != 0 ) {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPFDBS wake TPU fail! errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
  }

  /* ---------------------------------------------------------------- */
  /*    decrement  A.P.  process's  semophare  identifier             */
  /* ---------------------------------------------------------------- */

  iRc = SleepAp();

  if ( iRc != 0 ) {
    sprintf(g_caMsg,"<<<tmsaplnk>>> TPFDBS sleep AP fail errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0);
  }

  /* ---------------------------------------------------------------- */
  /* copy  g_pstCoa  & g_pstTba->caPara back to                       */
  /* pcArg1's "dbs" part & pcArg2                                     */
  /* ---------------------------------------------------------------- */
  memcpy(pstDbs, g_pstCoa, sizeof(struct DbsSt));
  ErrLog(100,"<<<tmsaplnk>>> exit TPFDBS, dump DBS-CTL=",
         RPT_TO_LOG,pstDbs,sizeof(struct DbsSt));

  if ( ( pstDbs->cDbsFunCode != TMS_READ_UPDATE_NOIOA )
    && ( pstDbs->cDbsFunCode != TMS_OPEN )
    && ( pstDbs->cDbsFunCode != TMS_CLOSE) ) {
    memcpy(pcArg2, g_pstTba->caPara, iSegSize);
    ErrLog(100, "<<<tmsaplnk>>> exit TPFDBS, dump DBS-IO-AREA=",
           RPT_TO_LOG,pcArg2,iSegSize);
  }

  UCP_TRACE_END(0);
}



TPFFCS(char *pcArg0,char *pcArg1,char *pcArg2)
{
  int  iRc;                         /* for ������ƶǦ^�� */
  int  iRecSize;                        /* Rec Size  */
  struct FcsSt *pstFcs;                 /* pointer to FcsSt structure */

  UCP_TRACE(P_TPFFCS_AP);
  /* ---------------------------------------------------------------- */
  /* new API-------> for new control structure                        */
  /* copy  fcs  to  TWA.COA                                           */
  /* ---------------------------------------------------------------- */
  pstFcs = (struct FcsSt *) pcArg1;
  memset(pstFcs->caFcsRtnCode,'0',6);
  memcpy(g_pstCoa, pstFcs, sizeof(struct FcsSt));

  ErrLog(100,"<<<tmsaplnk>>> enter TPFFCS, dump FCSAP=",
         RPT_TO_LOG,pstFcs,sizeof(struct FcsSt));

  if ( ( strncmp(pstFcs->caFcsFunCode,FCS_M_OPEN,4) != 0 )
    && ( strncmp(pstFcs->caFcsFunCode,FCS_M_CLOSE,4) != 0 )
    && ( strncmp(pstFcs->caFcsFunCode,FCS_M_READ_UPDATE_NOIOA,4 ) != 0 ) ) {

    iRecSize = GetFcsSize(pstFcs->caFcsFileName);
/*
    sprintf(g_caMsg,"<<<tmsaplnk>>> TPFFCS rec_len=%d file_name=%.8s"
            ,iRecSize, pstFcs->caFcsFileName);
    ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
*/
    if ( iRecSize == -1 ) {
       memcpy(pstFcs->caFcsRtnCode,"07",2);
       sprintf(g_caMsg,"<<<tmsaplnk>>> TPFFCS no such filename=%.8s in FIT",
               pstFcs->caFcsFileName);
       ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
       UCP_TRACE_END(-1);
    }

    ErrLog(100,"<<<tmsaplnk>>> enter TPFFCS, dump I-O-AREA=",
           RPT_TO_LOG,pcArg2,iRecSize);
    memcpy(g_pstTba->caPara,pcArg2,iRecSize);
  }

  /* ---------------------------------------------------------------- */
  /*   prepare  information  for  service  function                   */
  /* ---------------------------------------------------------------- */
  g_pstTma->stTCFA.cProcSemNo  = '2';
  g_pstTma->stTCFA.cReqSrvCode = FUN_FCS;

  /* ---------------------------------------------------------------- */
  /*   wake up TPU                                                    */
  /* ---------------------------------------------------------------- */
  iRc = WakeTpu();

  if ( iRc != 0 ) {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPFFCS wake TPU faile errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
  }

  /* ---------------------------------------------------------------- */
  /*    decrement  A.P.  process's  semophare  identifier             */
  /* ---------------------------------------------------------------- */
  iRc = SleepAp();

  if ( iRc != 0 ) {
    sprintf(g_caMsg,"<<<tmsaplnk>>> TPFFCS sleep AP fail errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0);
  }

  /* ---------------------------------------------------------------- */
  /*    copy g_pstCoa            & g_pstTba->caPara                   */
  /*    back to  pcArg1 & pcArg2                                      */
  /* ---------------------------------------------------------------- */
  memcpy(pstFcs,g_pstCoa, sizeof(struct FcsSt));
  ErrLog(100,"<<<tmsaplnk>>> exit TPFFCS, dump FCSAP=",
         RPT_TO_LOG,pstFcs,sizeof(struct FcsSt));


  /* SOME TPFFCS COMMANDS do not need copy io area */
  if ( ( strncmp(pstFcs->caFcsFunCode,FCS_M_OPEN,4) != 0 )
    && ( strncmp(pstFcs->caFcsFunCode,FCS_M_CLOSE,4) != 0 )
    && ( strncmp(pstFcs->caFcsFunCode,FCS_M_READ_UPDATE_NOIOA,4 ) != 0 ) ) {
    memcpy(pcArg2,g_pstTba->caPara,iRecSize);
    ErrLog(100,"<<<tmsaplnk>>> exit TPFFCS, dump I-O-AREA=",
           RPT_TO_LOG,pcArg2,iRecSize);
  }

  UCP_TRACE_END(0);
}


TPEDCS(char *pcArg0,char *pcArg1,char *pcArg2)
{
  int iRc;                       /* for ������ƶǦ^�� */
  struct DcsApi *pstDcs;              /* pointer to DcsApi */
  char caLenBuf[20];                 /* temp buffer for storing length */
  int  iLen;                         /* length */

  UCP_TRACE(P_TPEDCS_AP);
  /* ---------------------------------------------------------------- */
  /* new API-------> for new control structure                        */
  /* copy  dcs  to  share  memory                                     */
  /* ---------------------------------------------------------------- */
  pstDcs = (struct DcsApi *)pcArg1;
  memset(&pstDcs->cRtnCode,'0',3);
  memcpy(g_pstCoa, pstDcs, sizeof(struct DcsApi));
  ErrLog(100,"<<<tmsaplnk>>> enter TPEDCS, dump DCS-AREA=",
         RPT_TO_LOG,pstDcs,sizeof(struct DcsApi));

  switch (pstDcs->cFunCode) {
 /*   case DCS_M_LRMT_START_PGM : */
    case DCS_M_RMT_START_PGM :
    case DCS_M_B_RMT_START_PGM :
 /*   case DCS_M_LSEND :          */
    case DCS_M_SEND :
      memcpy(caLenBuf,pstDcs->caDataLen,4);
      caLenBuf[4] = '\0';
      iLen = atoi(caLenBuf);
      ErrLog(100,"<<<tmsaplnk>>> enter TPEDCS, dump IO-AREA=",
             RPT_TO_LOG,pcArg2,iLen);
      memcpy(g_pstTba->caPara,pcArg2,iLen);
      break;
  /*   case DCS_M_LRECEIVE :      */
    case DCS_M_RECEIVE :
    case DCS_M_RMT_STOP_PGM :
      break;
    default :
      sprintf(g_caMsg,"<<<tmsaplnk>>> TPEDCS invalid DCS function code=%c",
              pstDcs->cFunCode);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstDcs->cRtnCode = DCS_M_COMMAND_ERROR;
      UCP_TRACE_END(0);
  }

  /* ---------------------------------------------------------------- */
  /*   prepare  information  for  service  function                   */
  /* ---------------------------------------------------------------- */
  g_pstTma->stTCFA.cProcSemNo  = '2';
  g_pstTma->stTCFA.cReqSrvCode = FUN_DCS;

  /* ---------------------------------------------------------------- */
  /*   wake up TPU                                                    */
  /* ---------------------------------------------------------------- */
  iRc = WakeTpu();

  if ( iRc != 0 ) {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPEDCS wake TPU faile errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
  }

  /* ---------------------------------------------------------------- */
  /*    decrement  A.P.  process's  semophare  identifier             */
  /* ---------------------------------------------------------------- */
  iRc = SleepAp();

  if ( iRc != 0 ) {
    sprintf(g_caMsg,"<<<tmsaplnk>>> TPEDCS sleep AP fail");
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0);
  }

  /* ---------------------------------------------------------------- */
  /*    copy g_pstCoa            & g_pstTba->caPara                   */
  /*    back to  pcArg1 & pcArg2                                      */
  /* ---------------------------------------------------------------- */
   memcpy(pstDcs, g_pstCoa, sizeof(struct DcsApi));
  ErrLog(100,"<<<tmsaplnk>>> exit TPEDCS, dump DCS-AREA=",
         RPT_TO_LOG,pstDcs,sizeof(struct DcsApi));

  switch ( pstDcs->cFunCode ) {
  /*  case DCS_M_LRMT_START_PGM :  */
    case DCS_M_RMT_START_PGM :
    case DCS_M_B_RMT_START_PGM :
  /*  case DCS_M_LSEND :  */
    case DCS_M_SEND :
    case DCS_M_RMT_STOP_PGM :
      break;
  /*  case DCS_M_LRECEIVE :  */
    case DCS_M_RECEIVE :
      memcpy(caLenBuf,pstDcs->caDataLen,4);
      caLenBuf[4] = '\0';
      iLen = atoi(caLenBuf);
      memcpy(pcArg2,g_pstTba->caPara,iLen);
      ErrLog(100,"<<<tmsaplnk>>> exit TPEDCS, dump IO-AREA=",
             RPT_TO_LOG,pcArg2,iLen);
      break;
    default :
      pstDcs->cRtnCode = DCS_M_COMMAND_ERROR;
      break;
  }

  UCP_TRACE_END(0);
}


TPFLOGOP(char *pcArg0,char *pcArg1,char *pcArg2)
{
  int  iRc;     
  struct LogApiSt *pstLogOpCtl;


  UCP_TRACE(P_TPFLOGOP_AP);
  pstLogOpCtl = (struct LogApiSt *) pcArg1;
  pstLogOpCtl->caReturnCd[0] = TMS_LOGOP_NORMAL;
  ErrLog(100,"<<<tmsaplnk>>> enter TPFLOGOP, dump LOGP-CTL=",
         RPT_TO_LOG,pstLogOpCtl, sizeof(struct LogApiSt));

  /* ---------------------------------------------------------------- */
  /*    check input data correctness                                  */
  /* ---------------------------------------------------------------- */
  if (  pstLogOpCtl->caOperKind[0] != LG_RANDOM_READ      &&
        pstLogOpCtl->caOperKind[0] != LG_RANDOM_READ_U    &&
	pstLogOpCtl->caOperKind[0] != LG_READ_NEXT        &&
	pstLogOpCtl->caOperKind[0] != LG_READ_NEXT_U      &&
	pstLogOpCtl->caOperKind[0] != LG_REWRITE          &&
	pstLogOpCtl->caOperKind[0] != LG_APPEND           &&
	pstLogOpCtl->caOperKind[0] != LG_READ_FIRST       &&
	pstLogOpCtl->caOperKind[0] != LG_READ_FIRST_U     &&
	pstLogOpCtl->caOperKind[0] != LG_READ_LAST        &&
	pstLogOpCtl->caOperKind[0] != LG_READ_LAST_U      &&
	pstLogOpCtl->caOperKind[0] != LG_DIRECT_UPDATE    &&
	pstLogOpCtl->caOperKind[0] != LG_OPEN             &&
	pstLogOpCtl->caOperKind[0] != LG_CLOSE                ) {
    sprintf( g_caMsg,"<<<tmsaplnk>>> TPFLOGOP invalid fun code! %c",
	     pstLogOpCtl->caOperKind[0]);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstLogOpCtl->caReturnCd[0] = LG_INVALID_FUN;
    UCP_TRACE_END( -1 );
  }

  /* ---------------------------------------------------------------- */
  /* copy ctl & IO data to share memory                               */
  /* ---------------------------------------------------------------- */
  memcpy(g_pstCoa, pstLogOpCtl, sizeof(struct LogApiSt));
  memcpy(g_pstTba->caPara, pcArg2, LG_REC_SIZE);
  if ( pstLogOpCtl->caOperKind[0] != LG_REWRITE          &&
       pstLogOpCtl->caOperKind[0] != LG_APPEND           &&
       pstLogOpCtl->caOperKind[0] != LG_DIRECT_UPDATE    ) {
    ErrLog(100,"<<<tmsaplnk>>> enter TPFLOGOP, dump IO-AREA=",
           RPT_TO_LOG,pcArg2,1000);
  }

  /* ---------------------------------------------------------------- */
  /*   prepare  information  for  service  function                   */
  /* ---------------------------------------------------------------- */
  g_pstTma->stTCFA.cProcSemNo  = '2';
  g_pstTma->stTCFA.cReqSrvCode = FUN_LOGOP;

  /* ---------------------------------------------------------------- */
  /*   wake up TPU                                                    */
  /* ---------------------------------------------------------------- */
  iRc = WakeTpu();

  if ( iRc != 0 ) {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPFLOGOP wake TPU faile errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
  }

  /* ---------------------------------------------------------------- */
  /*    decrement  A.P.  process's  semophare  identifier             */
  /* ---------------------------------------------------------------- */
  iRc = SleepAp();

  if ( iRc != 0 ) {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPFLOGOP sleep AP fail errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0);
  }

  /* ---------------------------------------------------------------- */
  /*    copy g_pstCoa            & g_pstTba->caPara                   */
  /*    back to  pcArg1 & pcArg2                                      */
  /* ---------------------------------------------------------------- */
  memcpy(pstLogOpCtl, g_pstCoa, sizeof(struct LogApiSt));
  ErrLog(100,"<<<tmsaplnk>>> exit TPFLOGOP, dump LOGP-CTL=",
         RPT_TO_LOG,pstLogOpCtl, sizeof(struct LogApiSt));

  if (  pstLogOpCtl->caOperKind[0] == LG_RANDOM_READ      ||
        pstLogOpCtl->caOperKind[0] == LG_RANDOM_READ_U    ||
	pstLogOpCtl->caOperKind[0] == LG_READ_NEXT        ||
	pstLogOpCtl->caOperKind[0] == LG_READ_NEXT_U      ||
	pstLogOpCtl->caOperKind[0] == LG_READ_FIRST       ||
	pstLogOpCtl->caOperKind[0] == LG_READ_FIRST_U     ||
	pstLogOpCtl->caOperKind[0] == LG_READ_LAST        ||
	pstLogOpCtl->caOperKind[0] == LG_READ_LAST_U          ) { 
    memcpy(pcArg2, g_pstTba->caPara, LG_REC_SIZE);
    ErrLog(100,"<<<tmsaplnk>>> exit TPFLOGOP, dump IO-AREA=",
           RPT_TO_LOG,pcArg2,1000);
  }

  UCP_TRACE_END(0);
}




TPFCWARW(char *pcArg0,char *pcArg1,char *pcArg2)
/*  pcArg0 -->  Apa     */
/*  pcArg1 -->  ShmFacCtlSt     */
/*  pcArg2 -->  struct ShmLogSt */
{

  int iRc;
  int iLen;
  char caLen[10];
  struct ShmFacCtlSt *pstShmCtl;

  UCP_TRACE(P_TPFCWARW_AP);
  /* ---------------------------------------------------------------- */
  /*  copy control part in TWA.APA to TWA.COA  &&                     */
  /*  copy IO-AREA to TWA.PARA                                        */
  /* ---------------------------------------------------------------- */
  pstShmCtl = (struct ShmFacCtlSt *) pcArg1;
  pstShmCtl->cShmReturnCode = TMS_SHM_NORMAL;
  memcpy(g_pstCoa,pstShmCtl,sizeof(struct ShmFacCtlSt));
  ErrLog(100,"<<<tmsaplnk>>> enter TPFCWARW, dump CTL-AREA=",
         RPT_TO_LOG,pstShmCtl,sizeof(struct ShmFacCtlSt));

  memset(caLen,0,10);
  memcpy(caLen,pstShmCtl->caDataLen,5);
  iLen = atoi(caLen);

  if ( pstShmCtl->cShmFunCode == TMS_SHM_WR_UNLOCK ||
       pstShmCtl->cShmFunCode == TMS_SHM_WR_ONLY ) {
    memcpy(g_pstTba->caPara,pcArg2,iLen);
    ErrLog(100,"<<<tmsaplnk>>> enter TPFCWARW, dump IO-AREA=",
           RPT_TO_LOG,pcArg2,iLen);
  }

  /* ---------------------------------------------------------------- */
  /*    prepare  information  for  service  function                  */
  /* ---------------------------------------------------------------- */
  g_pstTma->stTCFA.cProcSemNo  = '2';
  g_pstTma->stTCFA.cReqSrvCode = FUN_SHMFAC;

  /* ---------------------------------------------------------------- */
  /*   wake up TPU                                                    */
  /* ---------------------------------------------------------------- */
  iRc = WakeTpu();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPFCWARW wake TPU faile errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
  }

  /* ---------------------------------------------------------------- */
  /*    decrement  A.P.  process's  semophare  identifier             */
  /* ---------------------------------------------------------------- */
  iRc = SleepAp();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPFCWARW sleep AP fail errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0);
  }

  /* ---------------------------------------------------------------- */
  /*  copy TWA.COA to control part in TWA.APA                         */
  /*  copy TWA.PARA to IO-AREA                                        */
  /* ---------------------------------------------------------------- */
  memcpy(pstShmCtl,g_pstCoa,sizeof(struct ShmFacCtlSt));
  ErrLog(100,"<<<tmsaplnk>>> exit TPFCWARW, dump CTL-AREA=",
         RPT_TO_LOG,pstShmCtl,sizeof(struct ShmFacCtlSt));

  if ( pstShmCtl->cShmFunCode == TMS_SHM_RD_LOCK ||
       pstShmCtl->cShmFunCode == TMS_SHM_RD_ONLY ) {
    memcpy(pcArg2,g_pstTba->caPara,iLen);
    ErrLog(100,"<<<tmsaplnk>>> exit TPFCWARW, dump IO-AREA=",
           RPT_TO_LOG,pcArg2,iLen);
  }

  UCP_TRACE_END(0);
}

TPERVSOP(char *pcArg0,char *pcArg1,char *pcArg2)
{
  int  iRc;     
  struct LogApiSt *pstLogOpCtl;

  UCP_TRACE(P_TPERVSOP_AP);
  pstLogOpCtl = (struct LogApiSt *) pcArg1;
  pstLogOpCtl->caReturnCd[0] = TMS_LOGOP_NORMAL;

  ErrLog(100,"<<<tmsaplnk>>> enter TPERVSOP, dump REVP-CTL=",
         RPT_TO_LOG,pstLogOpCtl, sizeof(struct LogApiSt));

  if (  pstLogOpCtl->caOperKind[0] != LG_READ_LOG &&
        pstLogOpCtl->caOperKind[0] != LG_START_REVERSE ) {
    sprintf( g_caMsg,"<<<tmsaplnk>>> TPERVSOP invalid fun code! %c",
	     pstLogOpCtl->caOperKind[0]);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstLogOpCtl->caReturnCd[0] = LG_INVALID_FUN;
    UCP_TRACE_END( -1 );
  }

  /* ---------------------------------------------------------------- */
  /* copy ctl & IO data to share memory                               */
  /* ---------------------------------------------------------------- */
  memcpy(g_pstCoa, pstLogOpCtl, sizeof(struct LogApiSt));

  /* ---------------------------------------------------------------- */
  /*   prepare  information  for  service  function                   */
  /* ---------------------------------------------------------------- */
  g_pstTma->stTCFA.cProcSemNo  = '2';
  g_pstTma->stTCFA.cReqSrvCode = FUN_RVSOP;

  /* ---------------------------------------------------------------- */
  /*   wake up TPU                                                    */
  /* ---------------------------------------------------------------- */
  iRc = WakeTpu();

  if ( iRc != 0 ) {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPERVSOP wake TPU faile errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
  }

  /* ---------------------------------------------------------------- */
  /*    decrement  A.P.  process's  semophare  identifier             */
  /* ---------------------------------------------------------------- */
  iRc = SleepAp();

  if ( iRc != 0 ) {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPERVSOP sleep AP fail errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0);
  }

  /* ---------------------------------------------------------------- */
  /*    copy g_pstCoa            & g_pstTba->caPara                   */
  /*    back to  pcArg1 & pcArg2                                      */
  /* ---------------------------------------------------------------- */
  memcpy(pstLogOpCtl, g_pstCoa, sizeof(struct LogApiSt));
  ErrLog(100,"<<<tmsaplnk>>> exit TPERVSOP, dump REVP-CTL=",
         RPT_TO_LOG,pstLogOpCtl, sizeof(struct LogApiSt));

  if ( pstLogOpCtl->caOperKind[0] == LG_READ_LOG ) {
    memcpy(pcArg2,g_pstTba->caPara, LG_REC_SIZE);
    ErrLog(100,"<<<tmsaplnk>>> exit TPERVSOP, dump IO-AREA=",
           RPT_TO_LOG,pcArg2, 1000);

  }

  UCP_TRACE_END(0);
}

TPEGPREV(char *pcArg0,char *pcArg1,char *pcArg2)
{
  int  iRc;     
  struct GetPreCtlSt *pstGetPrev;

  UCP_TRACE(P_TPEGPREV_AP);
  pstGetPrev = (struct GetPreCtlSt *) pcArg1;
  pstGetPrev->cGetPreLogRtnCode = TMS_GPREV_NORMAL;
  ErrLog(100,"<<<tmsaplnk>>> enter TPEGPREV, dump CTL-AREA=",
         RPT_TO_LOG,pstGetPrev, sizeof(struct GetPreCtlSt));

  /* ---------------------------------------------------------------- */
  /* copy ctl & IO data to share memory                               */
  /* ---------------------------------------------------------------- */
  memcpy(g_pstCoa, pstGetPrev, sizeof(struct GetPreCtlSt));

  /* ---------------------------------------------------------------- */
  /*   prepare  information  for  service  function                   */
  /* ---------------------------------------------------------------- */
  g_pstTma->stTCFA.cProcSemNo  = '2';
  g_pstTma->stTCFA.cReqSrvCode = FUN_GPREV;

  /* ---------------------------------------------------------------- */
  /*   wake up TPU                                                    */
  /* ---------------------------------------------------------------- */
  iRc = WakeTpu();

  if ( iRc != 0 ) {
    sprintf(g_caMsg,"<<<tmsaplnk>>> TPEGPREV wake TPU faile errno=%d",
            g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
  }

  /* ---------------------------------------------------------------- */
  /*    decrement  A.P.  process's  semophare  identifier             */
  /* ---------------------------------------------------------------- */
  iRc = SleepAp();

  if ( iRc != 0 ) {
    sprintf(g_caMsg,"<<<tmsaplnk>>> TPEGPREV sleep AP fail errno=%d",
            g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0);
  }

  /* ---------------------------------------------------------------- */
  /*    copy g_pstCoa            & g_pstTba->caPara                   */
  /*    back to  pcArg1 & pcArg2                                      */
  /* ---------------------------------------------------------------- */
  memcpy(pstGetPrev, g_pstCoa, sizeof(struct GetPreCtlSt));
  ErrLog(100,"<<<tmsaplnk>>> exit TPEGPREV, dump CTL-AREA=",
         RPT_TO_LOG,pstGetPrev, sizeof(struct GetPreCtlSt));
  memcpy(pcArg2, g_pstTba->caPara, 450);
  ErrLog(100,"<<<tmsaplnk>>> exit TPEGPREV, dump IO-AREA=",
         RPT_TO_LOG,pcArg2, 450);
  UCP_TRACE_END(0);
}



TPESDCLT(char *pcArg0,char *pcArg1,char *pcArg2)
/* pcArg1 pointer to control part "SdcltCtlSt"
   pcArg2 pointer to data part                 */
{
  int iRc;
  int   iLen;
  char  caTmpBuf[10];
  struct SdcltCtlSt *pstSdcltCtl;

  UCP_TRACE(P_TPESDCLT_AP);

  pstSdcltCtl = (struct SdcltCtlSt *) pcArg1;
  pstSdcltCtl->cMsgOutReturnCode = TMS_MSGP_NORMAL;
  ErrLog(100,"<tmslnkcp> enter TPESDCLT, dump CTL-AREA=",
         RPT_TO_LOG,pstSdcltCtl,sizeof(struct SdcltCtlSt));

  memset( caTmpBuf, '\0', 10 );
  memcpy( caTmpBuf , pstSdcltCtl->caSdcltLen, 5 );
  iLen = atoi(caTmpBuf);
  ErrLog(100,"<tmslnkcp> enter TPESDCLT, dump IO-AREA=",
         RPT_TO_LOG,pcArg2,iLen);

  /* ---------------------------------------------------------------- */
  /*  copy Control part to TWA.COA                                    */
  /*  copy AP msg to TWA.PARA                                         */
  /* ---------------------------------------------------------------- */
  memcpy(g_pstCoa,pstSdcltCtl,sizeof(struct SdcltCtlSt));
  iRc = WriteToTba(iLen , pcArg2 , POST_DATA);

  if (iRc != 0) {
    sprintf(g_caMsg,"<tmslnkcp> TPESDCLT WriteToTba fail!");
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
  }      

  /* ---------------------------------------------------------------- */
  /*    prepare  information  for  service  function                  */
  /* ---------------------------------------------------------------- */
  g_pstTma->stTCFA.cProcSemNo  = '2';
  g_pstTma->stTCFA.cReqSrvCode = FUN_SDCLT;

  /* ---------------------------------------------------------------- */
  /*   wake up TPU                                                    */
  /* ---------------------------------------------------------------- */
  iRc = WakeTpu();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,"<tmslnkcp> TPESDCLT wake TPU faile errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
  }

  /* ---------------------------------------------------------------- */
  /*    decrement  A.P.  process's  semophare  identifier             */
  /* ---------------------------------------------------------------- */
  iRc = SleepAp();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,"<tmslnkcp> TPESDCLT sleep AP fail errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0);
  }

  memcpy(pstSdcltCtl,g_pstCoa,sizeof(struct SdcltCtlSt));
  ErrLog(100,"<tmslnkcp> exit TPESDCLT, dump CTL-AREA=",
         RPT_TO_LOG,pstSdcltCtl,sizeof(struct SdcltCtlSt));

  UCP_TRACE_END(0);
}



TPFGTSEQ(char *pcArg0,char *pcArg1)
{
  int  iRc;     
  struct GetSeqSt *pstGetSeq;

  UCP_TRACE(P_TPFGTSEQ_AP);
  pstGetSeq = (struct GetSeqSt *) pcArg1;
  pstGetSeq->cGetSeqRtnCode = TMS_GTSEQ_NORMAL;
  ErrLog(100,"<<<tmsaplnk>>> enter TPFGTSEQ, dump CTL-AREA=",
         RPT_TO_LOG,pstGetSeq, sizeof(struct GetSeqSt));

  /* ---------------------------------------------------------------- */
  /* copy ctl & IO data to share memory                               */
  /* ---------------------------------------------------------------- */
  memcpy(g_pstCoa, pstGetSeq, sizeof(struct GetSeqSt));

  /* ---------------------------------------------------------------- */
  /*   prepare  information  for  service  function                   */
  /* ---------------------------------------------------------------- */
  g_pstTma->stTCFA.cProcSemNo  = '2';
  g_pstTma->stTCFA.cReqSrvCode = FUN_GTSEQ;

  /* ---------------------------------------------------------------- */
  /*   wake up TPU                                                    */
  /* ---------------------------------------------------------------- */
  iRc = WakeTpu();

  if ( iRc != 0 ) {
    sprintf(g_caMsg,"<<<tmsaplnk>>> TPFGTSEQ wake TPU faile errno=%d",
            g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
  }

  /* ---------------------------------------------------------------- */
  /*    decrement  A.P.  process's  semophare  identifier             */
  /* ---------------------------------------------------------------- */
  iRc = SleepAp();

  if ( iRc != 0 ) {
    sprintf(g_caMsg,"<<<tmsaplnk>>> TPFGTSEQ sleep AP fail errno=%d",
            g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0);
  }

  /* ---------------------------------------------------------------- */
  /*    copy g_pstCoa            & g_pstTba->caPara                   */
  /*    back to  pcArg1 & pcArg2                                      */
  /* ---------------------------------------------------------------- */
  memcpy(pstGetSeq, g_pstCoa, sizeof(struct GetSeqSt));
  ErrLog(100,"<<<tmsaplnk>>> exit TPFGTSEQ, dump CTL-AREA=",
         RPT_TO_LOG,pstGetSeq, sizeof(struct GetSeqSt));
  UCP_TRACE_END(0);
}


TPFADSEQ(char *pcArg0,char *pcArg1)
{
  UCP_TRACE(P_TPFADSEQ_AP);
  UCP_TRACE_END(0);
}


TPFRKSEQ(char *pcArg0,char *pcArg1)
{
  UCP_TRACE(P_TPFRKSEQ_AP);
  UCP_TRACE_END(0);
}


TPEONBTH(char *pcArg0, char *pcArg1,char *pcArg2)
/* pcArg0 --->  APA
   pcArg1 --->  control part "OnBthCtlSt"
   pcArg2 --->  data part                 */
{
  int iRc;
  char caDataLen[10];
  struct OnBthCtlSt *pstOnBth;
  int iDataLen;

  UCP_TRACE(P_TPEONBTH_AP);

  /* ---------------------------------------------------------------- */
  /*    prepare  information  for  service  function                  */
  /* ---------------------------------------------------------------- */
  g_pstTma->stTCFA.cProcSemNo  = '2';
  g_pstTma->stTCFA.cReqSrvCode = FUN_ONBTH;

  /* ---------------------------------------------------------------- */
  /*  copy Control part to TWA.COA                                    */
  /*  copy AP msg to TWA.PARA                                         */
  /* ---------------------------------------------------------------- */
  pstOnBth = (struct OnBthCtlSt *) pcArg1;
  pstOnBth->cOnBthRtnCode = TMS_ONBTH_NORMAL;
  memcpy( g_pstCoa, pstOnBth, sizeof(struct OnBthCtlSt) );

  ErrLog(100,"<<<tmsaplnk>>> enter TPEONBTH, dump RQTP-CTL=",
         RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));

  memset( caDataLen, 0, 10);
  memcpy( caDataLen, pstOnBth->caDataLen, ONBTH_DATA_LEN_SIZE);
  iDataLen = atoi( caDataLen );

  if ( iDataLen > MAX_SIF_LEN ) {
    sprintf( g_caMsg,"<<<tmsaplnk>>> TPEONBTH: invalid data length! %d",
             iDataLen);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstOnBth->cOnBthRtnCode = TMS_ONBTH_PARA_ERR;
    UCP_TRACE_END( -1 );
  }

  switch ( pstOnBth->cFmtCode ) {
    case FMT_1:
    case FMT_2:
      memcpy( g_pstTba->caPara, pcArg2, iDataLen );
      break;
    case FMT_CTF:
      memcpy( g_pstTba->caPara, pcArg2, MAX_CTF_LEN );
    case FMT_SIF:
      memcpy( g_pstTba->caPara, pcArg2, iDataLen );
      break;
    default:
      sprintf( g_caMsg,"<<<tmsaplnk>>> TPEONBTH: invalid cfmtcode! %c",
               pstOnBth->cFmtCode);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstOnBth->cOnBthRtnCode = TMS_ONBTH_PARA_ERR;
      UCP_TRACE_END( -1 );
  }

  ErrLog(100,"<<<tmsaplnk>>> enter TPEONBTH, dump RQTP-DATA=",
         RPT_TO_LOG,pcArg2,iDataLen);
  /* ---------------------------------------------------------------- */
  /*   wake up TPU                                                    */
  /* ---------------------------------------------------------------- */
  iRc = WakeTpu();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPEONBTH wake TPU faile errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
  }

  /* ---------------------------------------------------------------- */
  /*    decrement  A.P.  process's  semophare  identifier             */
  /* ---------------------------------------------------------------- */
  iRc = SleepAp();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPEONBTH sleep AP fail errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0);
  }

  memcpy( pstOnBth, g_pstCoa, sizeof(struct OnBthCtlSt) );
  ErrLog(100,"<<<tmsaplnk>>> exit TPEONBTH, dump RQTP-CTL=",
         RPT_TO_LOG,pcArg1,sizeof(struct OnBthCtlSt));

  UCP_TRACE_END(0);
}


TPFSETLN(char *pcArg0, char *pcArg1)
/* pcArg0 --->  APA
   pcArg1 --->  control part "SetLnCtlSt" */
{
  int iRc;
  struct SetLnCtlSt *pstSetLn;

  UCP_TRACE(P_TPFSETLN_AP);

  /* ---------------------------------------------------------------- */
  /*    prepare  information  for  service  function                  */
  /* ---------------------------------------------------------------- */
  g_pstTma->stTCFA.cProcSemNo  = '2';
  g_pstTma->stTCFA.cReqSrvCode = FUN_SETLN;

  /* ---------------------------------------------------------------- */
  /*  copy Control part to TWA.COA                                    */
  /*  copy AP msg to TWA.PARA                                         */
  /* ---------------------------------------------------------------- */
  pstSetLn = (struct SetLnCtlSt *) pcArg1;
  pstSetLn->cSetLnRtnCode = TMS_SETLN_NORMAL;
  memcpy( g_pstCoa, pstSetLn, sizeof(struct SetLnCtlSt) );

  if ( pstSetLn->cFunCode != '0' && pstSetLn->cFunCode != '1' ) {
    pstSetLn->cSetLnRtnCode = TMS_SETLN_FUN_ERR;
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPFSETLN invalid cFunCode=%c",pstSetLn->cFunCode);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  }

  ErrLog(100,"<<<tmsaplnk>>> enter TPFSETLN, dump SETLN-CTL=",
         RPT_TO_LOG,pstSetLn,sizeof(struct SetLnCtlSt));

  /* ---------------------------------------------------------------- */
  /*   wake up TPU                                                    */
  /* ---------------------------------------------------------------- */
  iRc = WakeTpu();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPFSETLN wake TPU faile errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
  }

  /* ---------------------------------------------------------------- */
  /*    decrement  A.P.  process's  semophare  identifier             */
  /* ---------------------------------------------------------------- */
  iRc = SleepAp();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPFSETLN sleep AP fail errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0);
  }

  memcpy( pstSetLn, g_pstCoa, sizeof(struct SetLnCtlSt) );
  ErrLog(100,"<<<tmsaplnk>>> exit TPFSETLN, dump SETLN-CTL=",
         RPT_TO_LOG,pcArg1,sizeof(struct SetLnCtlSt));
  UCP_TRACE_END(0);
}


TPEGTSIF(char *pcArg0, char *pcArg1)
/* pcArg0 --->  APA
   pcArg1 --->  control part "GtSifCtlSt" */
{
  int iRc;
  struct GtSifCtlSt *pstGtSif;

  UCP_TRACE(P_TPEGTSIF_AP);

  /* ---------------------------------------------------------------- */
  /*    prepare  information  for  service  function                  */
  /* ---------------------------------------------------------------- */
  g_pstTma->stTCFA.cProcSemNo  = '2';
  g_pstTma->stTCFA.cReqSrvCode = FUN_GTSIF;

  /* ---------------------------------------------------------------- */
  /*  copy Control part to TWA.COA                                    */
  /*  copy AP msg to TWA.PARA                                         */
  /* ---------------------------------------------------------------- */
  pstGtSif = (struct GtSifCtlSt *) pcArg1;
  pstGtSif->cGtSifRtnCode = TMS_GTSIF_NORMAL;
  memcpy( g_pstCoa, pstGtSif, sizeof(struct GtSifCtlSt) );

  ErrLog(100,"<<<tmsaplnk>>> enter TPEGTSIF, dump GTSIF-CTL=",
         RPT_TO_LOG,pstGtSif,sizeof(struct GtSifCtlSt));

  /* ---------------------------------------------------------------- */
  /*   wake up TPU                                                    */
  /* ---------------------------------------------------------------- */
  iRc = WakeTpu();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPEGTSIF wake TPU faile errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
  }

  /* ---------------------------------------------------------------- */
  /*    decrement  A.P.  process's  semophare  identifier             */
  /* ---------------------------------------------------------------- */
  iRc = SleepAp();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPEGTSIF sleep AP fail errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0);
  }

  memcpy( pstGtSif, g_pstCoa, sizeof(struct GtSifCtlSt) );
  ErrLog(100,"<<<tmsaplnk>>> exit TPEGTSIF, dump GTSIF-CTL=",
         RPT_TO_LOG,pcArg1,sizeof(struct GtSifCtlSt));

  UCP_TRACE_END(0);
}

TPEONBH1(char *pcArg0, char *pcArg1,char *pcArg2)
/* pcArg0 --->  APA
   pcArg1 --->  control part "OnBh1CtlSt"
   pcArg2 --->  data part                 */
{
  int iRc;
  char caDataLen[10];
  struct OnBh1CtlSt *pstOnBh1;
  int iDataLen;

  UCP_TRACE(P_TPEONBH1_AP);

  /* ---------------------------------------------------------------- */
  /*    prepare  information  for  service  function                  */
  /* ---------------------------------------------------------------- */
  g_pstTma->stTCFA.cProcSemNo  = '2';
  g_pstTma->stTCFA.cReqSrvCode = FUN_ONBH1;

  /* ---------------------------------------------------------------- */
  /*  copy Control part to TWA.COA                                    */
  /*  copy AP msg to TWA.PARA                                         */
  /* ---------------------------------------------------------------- */
  pstOnBh1 = (struct OnBh1CtlSt *) pcArg1;
  pstOnBh1->cOnBh1RtnCode = TMS_ONBH1_NORMAL;
  memcpy( g_pstCoa, pstOnBh1, sizeof(struct OnBh1CtlSt) );

  ErrLog(100,"<<<tmsaplnk>>> enter TPEONBH1, dump RQTP-CTL=",
         RPT_TO_LOG,pstOnBh1,sizeof(struct OnBh1CtlSt));

  memset( caDataLen, 0, 10);
  memcpy( caDataLen, pstOnBh1->caDataLen, ONBH1_DATA_LEN_SIZE);
  iDataLen = atoi( caDataLen );

  if ( iDataLen > MAX_SIF_LEN ) {
    sprintf( g_caMsg,"<<<tmsaplnk>>> TPEONBH1: invalid data length! %d",
             iDataLen);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstOnBh1->cOnBh1RtnCode = TMS_ONBH1_PARA_ERR;
    UCP_TRACE_END( -1 );
  }

  switch ( pstOnBh1->cFmtCode ) {
    case FMT_1:
    case FMT_2:
      memcpy( g_pstTba->caPara, pcArg2, iDataLen );
      break;
/*  case FMT_CTF:
      memcpy( g_pstTba->caPara, pcArg2, MAX_CTF_LEN );*/
    case FMT_SIF:
      memcpy( g_pstTba->caPara, pcArg2, iDataLen );
      break;
    default:
      sprintf( g_caMsg,"<<<tmsaplnk>>> TPEONBH1: invalid cfmtcode! %c",
               pstOnBh1->cFmtCode);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstOnBh1->cOnBh1RtnCode = TMS_ONBH1_PARA_ERR;
      memcpy(pstOnBh1->caErrCode, ONBH1_NO_SUCH_FORMAT_DERR, 5);
      UCP_TRACE_END( -1 );
  }

  ErrLog(100,"<<<tmsaplnk>>> enter TPEONBH1, dump RQTP-DATA=",
         RPT_TO_LOG,pcArg2,iDataLen);
  /* ---------------------------------------------------------------- */
  /*   wake up TPU                                                    */
  /* ---------------------------------------------------------------- */
  iRc = WakeTpu();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPEONBH1 wake TPU faile errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
  }

  /* ---------------------------------------------------------------- */
  /*    decrement  A.P.  process's  semophare  identifier             */
  /* ---------------------------------------------------------------- */
  iRc = SleepAp();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPEONBH1 sleep AP fail errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0);
  }

  memcpy( pstOnBh1, g_pstCoa, sizeof(struct OnBh1CtlSt) );
  ErrLog(100,"<<<tmsaplnk>>> exit TPEONBH1, dump RQTP-CTL=",
         RPT_TO_LOG,pcArg1,sizeof(struct OnBh1CtlSt));

  UCP_TRACE_END(0);
}


TPEONBHE(char *pcArg0, char *pcArg1,char *pcArg2)
/* pcArg0 --->  APA
   pcArg1 --->  control part "OnBthCtlSt"
   pcArg2 --->  data part                 */
{
  struct OnBthCtlSt *pstOnBth;
  int  iDataLen;
  char caDataLen[ 10 ];

  UCP_TRACE(P_TPEONBHE_AP);
  pstOnBth = (struct OnBthCtlSt *) pcArg1;
  ErrLog(100,"<<<tmsaplnk>>> enter TPEONBHE ,dump ONBTH-CTL=",
         RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));

  TPEONBTH(pcArg0,pcArg1,pcArg2);
  ErrLog(100,"<<<tmsaplnk>>> exit TPEONBHE ,dump ONBTH-CTL=",
         RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
  memset( caDataLen, 0, 10);
  memcpy( caDataLen, pstOnBth->caDataLen, ONBTH_DATA_LEN_SIZE);
  iDataLen = atoi( caDataLen );
  if(iDataLen > 0) {
    memcpy(pcArg2,g_pstTba->caPara,iDataLen);
    ErrLog(100,"<<<tmsaplnk>>> exit TPEONBHE ,dump EJ=",
           RPT_TO_LOG,pcArg2,iDataLen);
  }
  UCP_TRACE_END(0);
}


TPEONBH2(char *pcArg0, char *pcArg1,char *pcArg2)
/* pcArg0 --->  APA
   pcArg1 --->  control part "OnBthCtlSt"
   pcArg2 --->  data part                 */
{
  int iRc;
  char caDataLen[10];
  struct OnBthCtlSt *pstOnBth;
  int iDataLen;

  UCP_TRACE(P_TPEONBH2_AP);

  /* ---------------------------------------------------------------- */
  /*    prepare  information  for  service  function                  */
  /* ---------------------------------------------------------------- */
  g_pstTma->stTCFA.cProcSemNo  = '2';
  g_pstTma->stTCFA.cReqSrvCode = FUN_ONBH2;

  /* ---------------------------------------------------------------- */
  /*  copy Control part to TWA.COA                                    */
  /*  copy AP msg to TWA.PARA                                         */
  /* ---------------------------------------------------------------- */
  pstOnBth = (struct OnBthCtlSt *) pcArg1;
  pstOnBth->cOnBthRtnCode = TMS_ONBTH_NORMAL;
  memcpy( g_pstCoa, pstOnBth, sizeof(struct OnBthCtlSt) );

  ErrLog(100,"<<<tmsaplnk>>> enter TPEONBH2, dump RQTP-CTL=",
         RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));

  memset( caDataLen, 0, 10);
  memcpy( caDataLen, pstOnBth->caDataLen, ONBTH_DATA_LEN_SIZE);
  iDataLen = atoi( caDataLen );

  if ( iDataLen > MAX_SIF_LEN ) {
    sprintf( g_caMsg,"<<<tmsaplnk>>> TPEONBH2: invalid data length! %d",
             iDataLen);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstOnBth->cOnBthRtnCode = TMS_ONBTH_PARA_ERR;
    UCP_TRACE_END( -1 );
  }

  switch ( pstOnBth->cFmtCode ) {
    case FMT_1:
    case FMT_2:
      memcpy( g_pstTba->caPara, pcArg2, iDataLen );
      break;
    case FMT_CTF:
      memcpy( g_pstTba->caPara, pcArg2, MAX_CTF_LEN );
    case FMT_SIF:
      memcpy( g_pstTba->caPara, pcArg2, iDataLen );
      break;
    default:
      sprintf( g_caMsg,"<<<tmsaplnk>>> TPEONBH2: invalid cfmtcode! %c",
               pstOnBth->cFmtCode);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstOnBth->cOnBthRtnCode = TMS_ONBTH_PARA_ERR;
      UCP_TRACE_END( -1 );
  }

  ErrLog(100,"<<<tmsaplnk>>> enter TPEONBH2, dump RQTP-DATA=",
         RPT_TO_LOG,pcArg2,iDataLen);
  /* ---------------------------------------------------------------- */
  /*   wake up TPU                                                    */
  /* ---------------------------------------------------------------- */
  iRc = WakeTpu();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPEONBH2 wake TPU faile errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
  }

  /* ---------------------------------------------------------------- */
  /*    decrement  A.P.  process's  semophare  identifier             */
  /* ---------------------------------------------------------------- */
  iRc = SleepAp();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPEONBH2 sleep AP fail errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0);
  }

  memcpy( pstOnBth, g_pstCoa, sizeof(struct OnBthCtlSt) );
  ErrLog(100,"<<<tmsaplnk>>> exit TPEONBH2, dump RQTP-CTL=",
         RPT_TO_LOG,pcArg1,sizeof(struct OnBthCtlSt));

  UCP_TRACE_END(0);
}



TPEREOUT(char *pcArg0, char *pcArg1)
/* pcArg0 --->  APA
   pcArg1 --->  control part "stReOutCtl" */
{
  int iRc;
  struct stReOutCtl *pstReOut;

  UCP_TRACE(P_TPEREOUT_AP);

  /* ---------------------------------------------------------------- */
  /*    prepare  information  for  service  function                  */
  /* ---------------------------------------------------------------- */
  g_pstTma->stTCFA.cProcSemNo  = '2';
  g_pstTma->stTCFA.cReqSrvCode = FUN_REOUT;

  /* ---------------------------------------------------------------- */
  /*  copy Control part to TWA.COA                                    */
  /*  copy AP msg to TWA.PARA                                         */
  /* ---------------------------------------------------------------- */
  pstReOut = (struct stReOutCtl *) pcArg1;
  pstReOut->caRtnCode[0] = TMS_REOUT_NORMAL;
  memcpy( g_pstCoa, pstReOut, sizeof(struct stReOutCtl) );

  ErrLog(100,"<<<tmsaplnk>>> enter TPEREOUT, dump REOUT-CTL=",
         RPT_TO_LOG,pstReOut,sizeof(struct stReOutCtl));

  /* ---------------------------------------------------------------- */
  /*   wake up TPU                                                    */
  /* ---------------------------------------------------------------- */
  iRc = WakeTpu();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPEREOUT wake TPU faile errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
  }

  /* ---------------------------------------------------------------- */
  /*    decrement  A.P.  process's  semophare  identifier             */
  /* ---------------------------------------------------------------- */
  iRc = SleepAp();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPEREOUT sleep AP fail errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0);
  }

  memcpy( pstReOut, g_pstCoa, sizeof(struct stReOutCtl) );
  ErrLog(100,"<<<tmsaplnk>>> exit TPEREOUT, dump REOUT-CTL=",
         RPT_TO_LOG,pcArg1,sizeof(struct stReOutCtl));

  UCP_TRACE_END(0);
}



TPELTINQ(char *pcArg0)
/* pcArg0 --->  APA */
{
  int iRc;

  UCP_TRACE(P_TPELTINQ_AP);

  /* ---------------------------------------------------------------- */
  /*    prepare  information  for  service  function                  */
  /* ---------------------------------------------------------------- */
  g_pstTma->stTCFA.cProcSemNo  = '2';
  g_pstTma->stTCFA.cReqSrvCode = FUN_LTINQ;

  /* ---------------------------------------------------------------- */
  /*  copy Control part to TWA.COA                                    */
  /*  copy AP msg to TWA.PARA                                         */
  /* ---------------------------------------------------------------- */

  /* ---------------------------------------------------------------- */
  /*   wake up TPU                                                    */
  /* ---------------------------------------------------------------- */
  iRc = WakeTpu();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPELTINQ wake TPU faile errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
  }

  /* ---------------------------------------------------------------- */
  /*    decrement  A.P.  process's  semophare  identifier             */
  /* ---------------------------------------------------------------- */
  iRc = SleepAp();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPELTINQ sleep AP fail errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0);
  }

  UCP_TRACE_END(0);
}



TPECOPTX(char *pcArg0, char *pcArg1,char *pcArg2)
/* pcArg0 --->  APA
   pcArg1 --->  control part "CoptxCtlSt"
   pcArg2 --->  data part                 */
{
  int i,iRc;
  char caDataLen[10];
  struct CoptxCtlSt *pstCoptx;
  int iDataLen;

  UCP_TRACE(P_TPECOPTX_AP);

  /* ---------------------------------------------------------------- */
  /*    prepare  information  for  service  function                  */
  /* ---------------------------------------------------------------- */
  g_pstTma->stTCFA.cProcSemNo  = '2';
  g_pstTma->stTCFA.cReqSrvCode = FUN_COPTX;

  /* ---------------------------------------------------------------- */
  /*  copy Control part to TWA.COA                                    */
  /*  copy AP msg to TWA.PARA                                         */
  /* ---------------------------------------------------------------- */
  pstCoptx = (struct CoptxCtlSt *) pcArg1;
  pstCoptx->cCoptxRtnCode = TMS_COPTX_NORMAL;
  memcpy( g_pstCoa, pstCoptx, sizeof(struct CoptxCtlSt) );

  ErrLog(100,"<<<tmsaplnk>>> enter TPECOPTX, dump COPTX-CTL=",
         RPT_TO_LOG,pstCoptx,sizeof(struct CoptxCtlSt));

  /* ----------   check coptx-fun-code       ------------------------- */
  if(pstCoptx->cFunCode != '1' && pstCoptx->cFunCode != '2') {
    sprintf( g_caMsg,"<<<tmsaplnk>>> TPECOPTX: invalid cFunCode=%c",
             pstCoptx->cFunCode);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstCoptx->cCoptxRtnCode = TMS_COPTX_PARA_ERR;
    UCP_TRACE_END( -1 );
  }

  /* ----------   check coptx-data-fmt       ------------------------- */
  if(pstCoptx->cFmtCode != '1' && pstCoptx->cFmtCode != '2' &&
     pstCoptx->cFmtCode != '3' && pstCoptx->cFmtCode != '4') {
    sprintf( g_caMsg,"<<<tmsaplnk>>> TPECOPTX: invalid cFmtCode=%c",
             pstCoptx->cFmtCode);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstCoptx->cCoptxRtnCode = TMS_COPTX_PARA_ERR;
    UCP_TRACE_END( -1 );
  }

  /* ----------   check datalen       ------------------------- */
  for(i=0;i<4;i++) {
    if(pstCoptx->caDataLen[i]<'0' || pstCoptx->caDataLen[i]>'9') break;
  }
  if(i<4) {
    sprintf( g_caMsg,"<<<tmsaplnk>>> TPECOPTX: invalid caDataLen=%.*s",
             4,pstCoptx->caDataLen);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstCoptx->cCoptxRtnCode = TMS_COPTX_PARA_ERR;
    UCP_TRACE_END( -1 );
  }

  if(pstCoptx->cFunCode == '1') {
    memset( caDataLen, 0, 10);
    memcpy( caDataLen, pstCoptx->caDataLen, 4);
    iDataLen = atoi( caDataLen );

    if ( iDataLen > MAX_SIF_LEN ) {
      sprintf( g_caMsg,"<<<tmsaplnk>>> TPECOPTX: invalid data length! %d",
               iDataLen);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstCoptx->cCoptxRtnCode = TMS_COPTX_PARA_ERR;
      UCP_TRACE_END( -1 );
    }

    switch ( pstCoptx->cFmtCode ) {
      case FMT_1:
      case FMT_2:
        memcpy( g_pstTba->caPara, pcArg2, iDataLen );
        break;
      case FMT_CTF:
        memcpy( g_pstTba->caPara, pcArg2, MAX_CTF_LEN );
      case FMT_SIF:
        memcpy( g_pstTba->caPara, pcArg2, iDataLen );
        break;
      default:
        sprintf( g_caMsg,"<<<tmsaplnk>>> TPECOPTX: invalid cfmtcode! %c",
                 pstCoptx->cFmtCode);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        pstCoptx->cCoptxRtnCode = TMS_COPTX_PARA_ERR;
        UCP_TRACE_END( -1 );
    }

    ErrLog(100,"<<<tmsaplnk>>> enter TPECOPTX, dump COPTX-DATA=",
           RPT_TO_LOG,pcArg2,iDataLen);
  }
  /* ---------------------------------------------------------------- */
  /*   wake up TPU                                                    */
  /* ---------------------------------------------------------------- */
  iRc = WakeTpu();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPECOPTX wake TPU faile errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
  }

  /* ---------------------------------------------------------------- */
  /*    decrement  A.P.  process's  semophare  identifier             */
  /* ---------------------------------------------------------------- */
  iRc = SleepAp();

  if ( iRc != 0 )
  {
    sprintf(g_caMsg,
            "<<<tmsaplnk>>> TPECOPTX sleep AP fail errno=%d",g_iRtnErrno);
    ErrLog(40000,g_caMsg,RPT_TO_LOG,0);
  }

  memcpy( pstCoptx, g_pstCoa, sizeof(struct CoptxCtlSt) );
  ErrLog(100,"<<<tmsaplnk>>> exit TPECOPTX, dump COPTX-CTL=",
         RPT_TO_LOG,pcArg1,sizeof(struct CoptxCtlSt));
  memset( caDataLen, 0, 10);
  memcpy( caDataLen, pstCoptx->caDataLen, 4);
  iDataLen = atoi( caDataLen );
  if(iDataLen > 0) {
    memcpy(pcArg2,g_pstTba->caPara,iDataLen);
    ErrLog(100,"<<<tmsaplnk>>> exit TPECOPTX, dump COPTX-DATA=",
         RPT_TO_LOG,pcArg2,iDataLen);
  }

  UCP_TRACE_END(0);
}
