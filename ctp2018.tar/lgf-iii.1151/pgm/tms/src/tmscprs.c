#include "twa.h"
#include "errlog.h"


#define SIF_DATA_OFFSET	51
#define SOF_DATA_OFFSET	27
#define SIF_CTL2_BYTE	50
#define SOF_CTL2_BYTE	26
#define CPRS_MASK	0x80
#define CPRS_ON		1
#define CPRS_OFF	0

#define MAX_SOF_LEN	3072
#define THRESHOLD_VALUE	50


static int sg_iCprsFlag=CPRS_ON;

int SifCprs(char *pcaSrc,char *pcaCnvOutBuff,int iSifLen);
int SifDecprs(char *pcaSrc,int *piSrcLen,char *pcaCnvInBuff);
int SofCprs(char *pcaSrc,char *pcaCnvOutBuff,int iSofLen);
int SofDecprs(char *pcaSrc,int *piSrcLen,char *pcaCnvInBuff);


/*
 *&N& ROUTINE NAME: SifCprs()
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : compress SIF error !!
 *&R&
 *&D& DESCRIPTION:
 *&D&
 */
int
SifCprs(char *pcaSrc,char *pcaCnvOutBuff,int iSifLen)
{
  int iRc;
  int iInputLen,iOutputLen;
  
  memcpy(pcaCnvOutBuff,pcaSrc,iSifLen);
  ErrLog(10,"SifCprs:before SIF compress, DUMP SIF=",
         RPT_TO_LOG,pcaCnvOutBuff,iSifLen);

  iInputLen=iSifLen-SIF_DATA_OFFSET;
  iOutputLen=MAX_SIF_LEN;
  if ( sg_iCprsFlag == CPRS_OFF ) {
    /* do not compress */
    ErrLog(10,"SifCprs:SIF form DBP is not compressed, so don't compress it !!!", RPT_TO_LOG,pcaCnvOutBuff,iSifLen);
    return (iSifLen);
  }

  iRc=LZW_encode(pcaSrc+SIF_DATA_OFFSET,iInputLen,
                 &pcaCnvOutBuff[SIF_DATA_OFFSET],&iOutputLen);
  if( iRc < 0 ) {
    ErrLog(10,"SifCprs:SIF compress error!!!",
           RPT_TO_LOG,pcaCnvOutBuff,iSifLen);
    return (iSifLen);
  }
  else {
    pcaCnvOutBuff[SIF_CTL2_BYTE]=0x80;
    iSifLen=SIF_DATA_OFFSET+iOutputLen;
    sprintf(g_caMsg,"SifCprs:SIF compress success, piRtnSifLen=%d,DUMP SIF=",
            iSifLen);
    ErrLog(10,g_caMsg,RPT_TO_LOG,pcaCnvOutBuff,iSifLen);
    return(iSifLen);
  }

}


/*
 *&N& ROUTINE NAME: SifDecprs()
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : decompress error!!
 *&R&
 *&D& DESCRIPTION:
 *&D& this function will decompress the SIF. when decompress SIF is done,
 *&D& set the CTL-BTYE-2 in SIF header to 0x00.
 */
int
SifDecprs(char *pcaSrc,int *piSrcLen,char *pcaCnvInBuff)
{
  int iRc;
  int iInputLen,iOutputLen;
  char caOutputBuf[MAX_SIF_LEN];

  iInputLen=(*piSrcLen)-SIF_DATA_OFFSET;
  iOutputLen=MAX_SIF_LEN - SIF_HEAD_LEN;

  /*sprintf(g_caMsg,"SifDecprs:before decode,*piSrcLen=%d,DUMP SIF=",*piSrcLen);
  ErrLog(10,g_caMsg, RPT_TO_LOG,pcaSrc,*piSrcLen);*/

  if ( pcaSrc[SIF_CTL2_BYTE] & CPRS_MASK ) {
    sg_iCprsFlag=CPRS_ON;
    iRc=LZW_decode(pcaSrc+SIF_DATA_OFFSET,iInputLen,caOutputBuf,&iOutputLen);
    if( iRc < 0 ) {
      ErrLog(10,"SifDecprs: SIF decompress error !!!",RPT_TO_LOG,0,0);
      return(-1);
    }
    else {
      memcpy(pcaCnvInBuff,pcaSrc,SIF_DATA_OFFSET);
      memcpy(pcaCnvInBuff+SIF_DATA_OFFSET,caOutputBuf,iOutputLen);
      pcaCnvInBuff[SIF_CTL2_BYTE]=0x00;
      *piSrcLen=SIF_DATA_OFFSET+iOutputLen;
      /*ErrLog(10,"SifDecprs: SIF decompress success,DUMP SIF=",
             RPT_TO_LOG,pcaCnvInBuff,*piSrcLen);*/
    }
  }
  else {
    sg_iCprsFlag=CPRS_OFF;
    memcpy(pcaCnvInBuff,pcaSrc,*piSrcLen);
  }
  return(0);
}


/*
 *&N& ROUTINE NAME: SofCprs()
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : compress SOF error !!
 *&R&
 *&D& DESCRIPTION:
 *&D&
 */
int
SofCprs(char *pcaSrc,char *pcaCnvOutBuff,int iSofLen)
{
  int iRc;
  int iInputLen,iOutputLen;
  
  memcpy(pcaCnvOutBuff,pcaSrc,iSofLen);
  ErrLog(10,"SofCprs:before SOF compress, DUMP SOF=",
         RPT_TO_LOG,pcaCnvOutBuff,iSofLen);

  iInputLen=iSofLen-SOF_DATA_OFFSET;
  iOutputLen=MAX_SOF_LEN;
  if ( iInputLen < THRESHOLD_VALUE || sg_iCprsFlag == CPRS_OFF ) {
    /* do not compress */
    ErrLog(10,"SofCprs:SOF is too short or SIF is not compressed, don't compress it !!!", RPT_TO_LOG,pcaCnvOutBuff,iSofLen);
    return (iSofLen);
  }

  iRc=LZW_encode(pcaSrc+SOF_DATA_OFFSET,iInputLen,
                 &pcaCnvOutBuff[SOF_DATA_OFFSET],&iOutputLen);
  if( iRc < 0 ) {
    ErrLog(10,"SofCprs:SOF compress error!!!",
           RPT_TO_LOG,pcaCnvOutBuff,iSofLen);
    return (iSofLen);
  }
  else {
    pcaCnvOutBuff[SOF_CTL2_BYTE]=0x80;
    iSofLen=SOF_DATA_OFFSET+iOutputLen;
    sprintf(g_caMsg,"SofCprs:SOF compress success, piRtnSofLen=%d,DUMP SOF=",
            iSofLen);
    ErrLog(10,g_caMsg,RPT_TO_LOG,pcaCnvOutBuff,iSofLen);
    return(iSofLen);
  }

}



/*
 *&N& ROUTINE NAME: SofDecprs()
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : decompress error!!
 *&R&
 *&D& DESCRIPTION:
 *&D& this function will decompress the SOF. when decompress SOF is done,
 *&D& set the CTL-BTYE-2 in SOF header to 0x00.
 */
int
SofDecprs(char *pcaSrc,int *piSofLen,char *pcaCnvInBuff)
{
  int iRc;
  int iInputLen,iOutputLen;
  char caOutputBuf[MAX_SOF_LEN];

  iInputLen=(*piSofLen)-SOF_DATA_OFFSET;
  iOutputLen=MAX_SOF_LEN;

  sprintf(g_caMsg,"SofDecprs:before decode,*piSofLen=%d,DUMP SOF=",*piSofLen);
  ErrLog(10,g_caMsg, RPT_TO_LOG,pcaSrc,*piSofLen);

  if ( pcaSrc[SOF_CTL2_BYTE] & CPRS_MASK ) {
    iRc=LZW_decode(pcaSrc+SOF_DATA_OFFSET,iInputLen,caOutputBuf,&iOutputLen);
    if( iRc < 0 ) {
      ErrLog(10,"SofDecprs: SOF decompress error !!!",RPT_TO_LOG,0,0);
      return(-1);
    }
    else {
      memcpy(pcaCnvInBuff,pcaSrc,SOF_DATA_OFFSET);
      memcpy(pcaCnvInBuff+SOF_DATA_OFFSET,caOutputBuf,iOutputLen);
      pcaCnvInBuff[SOF_CTL2_BYTE]=0x00;
      *piSofLen=SOF_DATA_OFFSET+iOutputLen;
      ErrLog(10,"SofDecprs: SOF decompress success,DUMP SOF=",
             RPT_TO_LOG,pcaCnvInBuff,*piSofLen);
    }
  }
  else {
    memcpy(pcaCnvInBuff,pcaSrc,*piSofLen);
  }

  return(0);
}
