
#include    <stdio.h>
#ifdef      DOS
#include    <conio.h>
#endif
#include    <fcntl.h>
#include    "errlog.h"
#include    "tmcrpt.h"

/*---------------------- global declaration --------------------------------*/
static FILE *form_fp;    /* open form file by fmctl_get() */
/* TCC: For compatibility with Tandem */
/*
int  X_pos,Y_pos;
*/
static int  init_x,init_y;
int  Cur_fd;
static char PGM[30];     /* record the DOS utility name to be invoked */
static char sec_chinese=0;
static int  ft_idx = 0;
struct file_table ftable[MAX_FILE_OPEN];/* MAX open output file number is 10 */
extern      int errno;  /* Added by Willy 19970108 */

int tpfrpt(op_info)
struct output_info *op_info;
{
  int    i;
  static struct fmt_cvt  fmt_token;
  int    rc,r_code;
  int    fd;
  short  msg_len;
  char   form_name[100];
  char   form_id[5];
  char   file_name[FILE_NAME_LEN+1];
  char   tmp[10];
  char   dev_type;
  char   outform_name[100];

/*sprintf(g_caMsg,"enter tpfrpt,dump op_info");
  ErrLog(200,g_caMsg,RPT_TO_LOG,op_info,
         sizeof(struct output_info)-MSG_MAX_LENG); */
     
  switch (op_info->func_code){
    case TPFRPT_OPEN:
         break;
    case TPFRPT_WRITE:
         break;
    case TPFRPT_CLOSE:
         break;
    case TPFRPT_CLOSE_ALL:
         if (ft_idx != 0 ){
           for (i=0;i<ft_idx;i++){
             rc=close(ftable[i].fd);
             if (rc == -1){
               op_info->r_code = CLOSE_ERR ;
               return(CLOSE_ERR);
             }
           }
	   ft_idx = 0;
         }
         op_info->r_code = F_NORMAL ;
         return(R_NORMAL);
    default:
         op_info->r_code = NOT_A_FCODE ;
         sprintf(g_caMsg,"TPFRPT:no such fun code=%c",op_info->func_code);
         ErrLog(2000,g_caMsg,RPT_TO_LOG,0,0);
         return(NOT_A_FCODE);
  }

  /*  parser meg_p to form_id,len,dev_type,out_msg  */
  if ( (op_info->func_code != TPFRPT_OPEN)  &&
       (op_info->func_code != TPFRPT_CLOSE) ) {
     memcpy(form_id,op_info->msg_type,FORM_ID_LEN);
     form_id[4] = '\0';
     memcpy(tmp,op_info->caLength,4);
     tmp[4] = '\0';
     msg_len = atoi(tmp);
     sprintf(g_caMsg,"form_id = %s,msg_len=%d,dump msg_p",form_id,msg_len);
     ErrLog(200,g_caMsg,RPT_TO_LOG,0,0);
/*   sprintf(g_caMsg,"dump msg_p",form_id,msg_len);
     ErrLog(200,g_caMsg,RPT_TO_LOG,op_info->msg_type,msg_len+7);*/
     if ( strncmp(form_id,"T???",4) != 0){
          rc= fmctl_get(form_id,&dev_type,0);
     }
     else { 
       rc = R_NORMAL ;
     }
/*   sprintf(g_caMsg,"tpfrpt:fmctl_get return code=%d",rc);
     ErrLog(200,g_caMsg,RPT_TO_LOG,0,0);*/
  }
  else {  
    rc = R_NORMAL; 
  }

  switch(rc) {
    case OPEN_FORM_ERR:
                  op_info->r_code = F_OPEN_ERR;
                  return(OPEN_FORM_ERR);
    case F_PARSER_ERR:
                  op_info->r_code = PARSER_ERR;
                  return(F_PARSER_ERR);
    case F_CTL_ERR:
                  op_info->r_code = CTL_ERR;
                  return(F_CTL_ERR);
    case R_NORMAL:
                  i = 0;
                  while ((op_info->filename[i] != SPACE) && 
                         (i < FILE_NAME_LEN ))  {
                      file_name[i] = op_info->filename[i] ;
                      i++;
                  }
                  file_name[i] = '\0' ;
                  rc = search_fname(op_info->filename);
                  sprintf(g_caMsg,"before open op_info->filename");
                  ErrLog(20,g_caMsg,RPT_TO_LOG,file_name,sizeof(file_name));
                  if (rc == -1)  {  /* not found such filename  */
			switch (op_info->func_code) {
			  case TPFRPT_OPEN : 
			   if (ft_idx == MAX_FILE_OPEN) {
                             op_info->r_code = OPEN_TOO_MANY ;
                             return(OPEN_TOO_MANY);
                           }
                           memset(outform_name,0,100);
			   if (file_name[0] != '/'){
                             strcpy(outform_name,getenv("III_DIR"));
                             strcat(outform_name,FORM_OUTPATH);
			   }
 			   strcat(outform_name,file_name);
                           if ( ( fd = open(outform_name,O_CREAT|O_RDWR|
                                             O_TRUNC,0666)) == -1 ) {
                             /* Added by Willy 19970108 -- begin */
                             sprintf(g_caMsg,
                                     "open output file %s error,errno=%d",
                                     outform_name,errno);
                             ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0); 
                             /* Added by Willy 19970108 -- end */
                             op_info->r_code = F_OPEN_ERR ;
                             return(F_OPEN_ERR);
                           }
                           else { /* new file open success */
                             memcpy(ftable[ft_idx].filename,op_info->filename,
                                    FILE_NAME_LEN);
                             ftable[ft_idx].filename[FILE_NAME_LEN] = '\0' ;
                             ftable[ft_idx].fd = fd ;
                             Cur_fd = fd;
                             ft_idx ++ ;
                           }  /* end if (fd = open(..... )) */
 		           op_info->r_code = F_NORMAL ;
			   return(R_NORMAL);
		         case TPFRPT_WRITE:
 				 op_info->r_code = F_NOT_OPEN ;
				 return(F_NOT_OPEN);
			 case TPFRPT_CLOSE:
 				 op_info->r_code = CLOSE_ERR ;
				 return(CLOSE_ERR);
			}  /* end switch(op_info->func_code)  */
                     }
                     else  {  /*  there's existed such a file */
			   switch (op_info->func_code) {
			     case  TPFRPT_OPEN:
			           op_info->r_code = F_REOPEN ;
				   return(F_REOPEN);
			     case  TPFRPT_WRITE :
                                   Cur_fd = ftable[rc].fd ;
				   break;
			     case  TPFRPT_CLOSE :
				   r_code = close(ftable[rc].fd); 
                                   if (r_code == -1) {
                                   op_info->r_code = CLOSE_ERR ;
                                   return(CLOSE_ERR);
                                   }
				   for ( i=rc;i<ft_idx;i++) {
					ftable[i].fd = ftable[i+1].fd ;
					strcpy(ftable[i].filename,ftable[i+1].filename);
				   }  /* end for  */
				   ft_idx--;
                                   op_info->r_code = F_NORMAL ;
				   return(R_NORMAL);
			  }  /* end switch  */
                     }   /*  end if (rc == -1)  */
                     dev_type = D_BTFILE ;
                     rc = form_proc(&dev_type,form_id,&op_info->out_msgs,0,Cur_fd);
                     if (rc == 1 ) {
                           op_info->r_code = F_WRT_ERR ;
                           return(F_WRT_ERR);
                     }
/*  add by zheng for TXXX no '}' at end  1997/4/19*/
                     else if(rc==-1){
                           op_info->r_code = PARSER_ERR;
                           return(F_PARSER_ERR);
                     }
/*   end 1997/4/19  */
                     else  {
                           op_info->r_code = F_NORMAL ;
                           return(R_NORMAL);
                     }
                     break;
  }  /*  end switch  */
}       /*  end TPFRPT  */

search_fname(filename)
char *filename;
{
   int i;

/* sprintf(g_caMsg,"search_fname:enter ft_idx=%d,dump filename", ft_idx);
   ErrLog(200,g_caMsg,RPT_TO_LOG,filename,FILE_NAME_LEN); */
   for (i=0;i < ft_idx ;i++) {
       if (strncmp(filename,ftable[i].filename,FILE_NAME_LEN) == 0){
/*        sprintf(g_caMsg,"search_fname:dump ftable[%d].filename",i);
          ErrLog(200,g_caMsg,RPT_TO_LOG,ftable[i].filename,FILE_NAME_LEN);*/
          return(i);
       }
   }
   return(-1);
}
