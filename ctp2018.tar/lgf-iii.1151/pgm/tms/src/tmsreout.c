/*
 *&N& File: tmsreout.c 
 *&N&   
 *&N&    TYPE      NAME                 DESCRIPTION
 *&N& --------- ---------- ---------------------------------------- 
 *&N&    int    RdOutToOutMemory(char *pcOutputFileName, char *pcMsgpOutCode)
 *&N&
 */

/* ---------------------- INCLUDE FILES DECLARATION ------------------- */
#include <errno.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "errlog.h"
#include "ucp.h"
#include "tms.h"
#include "twa.h"
/* -------------------------------------------------------------------- */

/* ------------------------- CONSTANT DEFINITION ---------------------- */
#define P_RdOutToTPEWRITE   29902
#define P_CnvSofToMsgp      29903
#define P_RdOutToOutMemory  29904

#define MSGP_MAX_LEN        2000

#define LAST_MSG_MASK       0x80
#define REINPUT_MSG_MASK    0x20
#define PRINT_MSG_MASK      0x10
#define ERROR_MSG_MASK      0x08
#define TPEO_MSG_MASK       0x02

#define  RCV_OK 			'1'
extern char g_cRcvRmtDataFlag;  /* indicate rcv rmt data OK or not? */
extern char g_caMemBuf[MAX_MSGP_LEN * 2];
struct  MemBufCtlSt{
  int iMsgCnt;
  int iNextOffset;
};
extern struct  MemBufCtlSt g_stMemBufCtl;
extern char    g_cFlushMemToFileFlag;
/* -------------------------------------------------------------------- */

/* ------ CALLED FUNCTION AND SUBROUTINE PROTOTYPE DECLARATIONS ------- */
int RdOutToTPEWRITE(char *pcOutputFileName, char *pcMsgpOutCode);
int CnvSofToMsgp(char *pcSof, struct WriteSt *pstMsgp);
int RdOutToOutMemory(char *pcOutputFileName, char *pcMsgpOutCode);
/* -------------------------------------------------------------------- */


/*
 *&N& ROUTINE NAME: RdOutToTPEWRITE  
 *&A& ARGUMENTS:
 *&A&  char *pcOutputFileName	: Reoutput file name. 
 *&A&  char *pcMsgpOutCode	: Output field, if previous txn is error then
 *&A&                             copy previou txn's error code to it. 
 *&A&           
 *&R& RETURN VALUES:
 *&R&    0 : Normal.
 *&R&   -1 : File not found.
 *&R&   -2 : Read SOF control part error.
 *&R&   -3 : Read SOF data part error.
 *&R&   -4 : Call CnvSofToMsgp error(msgp length is greater 2000). 
 *&R&   -5 : Call TPEWRITE error.
 *&R&   -6 : lseek error.
 *&R&   -9 : Output data in output data file is error message.
 *&R&           
 *&D& DESCRIPTION:           
 *&D&   This funtion is used by reoutput output data from prescribe file. If 
 *&D& output data is error message then return output message code by 
 *&D& pcMsgpOutCode.
 */
 
RdOutToTPEWRITE(char *pcOutputFileName, char *pcMsgpOutCode)
{
  int  iOutputFd;
  char caSofBuf[4096];
  int  iRc, iSofDataLen;
  int  i, iTotalPackSofLen;
  char cCtlFlowFlag = 'y';
  char *pcApa;
  short sPackSofDataLen;
  struct WriteSt stMsgp;

  UCP_TRACE(P_RdOutToTPEWRITE);

  sprintf(g_caMsg,"RdOutToTPEWRITE:Begin.File name=[%s]",pcOutputFileName);
  ErrLog(100, g_caMsg, RPT_TO_LOG, 0, 0);

  /* open reoutput file */
  iOutputFd = open(pcOutputFileName, O_RDONLY);
  if ( iOutputFd == -1 ){
    sprintf(g_caMsg,"RdOutToTPEWRITE:open %s error,errno=%d",pcOutputFileName,
            errno);
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END(-1);
  } 
  memcpy(pcMsgpOutCode, "0000", 4);/* clear output message code */
 
  for(i=0;;){
    
    iRc=lseek(iOutputFd,sizeof(struct MemBufCtlSt),0);
    if(iRc < 0) {
      sprintf(g_caMsg,"RdOutToTPEWRITE:lseek to %d error,errno=%d",
              sizeof(struct MemBufCtlSt),errno);
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      UCP_TRACE_END(-6);
    }

    /* read SOF control part from output file */
    iRc = read(iOutputFd, caSofBuf, SOF_HEAD_LEN_PLUS_2);

    if ( iRc == 0 ){ /* EOF(End Of File) */
      break;
    }

    if ( iRc != SOF_HEAD_LEN_PLUS_2 ){
      sprintf(g_caMsg,
   "RdOutToTPEWRITE:read %s error,read length=%d,actual read length=%d,errno=%d"
              , pcOutputFileName, SOF_HEAD_LEN_PLUS_2, iRc, errno);
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      UCP_TRACE_END(-2);
    }
    sprintf(g_caMsg, "RdOutToTPEWRITE:SOF index=%d,dump SOF head", i);
    ErrLog(100, g_caMsg, RPT_TO_LOG, caSofBuf, SOF_HEAD_LEN_PLUS_2);

    iSofDataLen = (unsigned char)caSofBuf[SOF_DATA_LEN_OFFSET]*256 +
               (unsigned char)caSofBuf[SOF_DATA_LEN_OFFSET+1];
    if ( iSofDataLen > 0 ){
      /* read SOF data part from output file */
      iRc = read(iOutputFd, &caSofBuf[SOF_HEAD_LEN_PLUS_2], iSofDataLen);
      if ( iSofDataLen != iRc ){
        sprintf(g_caMsg,
   "RdOutToTPEWRITE:read %s error,read length=%d,actual read length=%d,errno=%d"
                , pcOutputFileName, iSofDataLen, iRc, errno);
        ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
        UCP_TRACE_END(-3);
      }
      sprintf(g_caMsg, "RdOutToTPEWRITE:SOF index=%d,dump SOF data", i);
      ErrLog(100,g_caMsg,RPT_TO_LOG,&caSofBuf[SOF_HEAD_LEN_PLUS_2],iSofDataLen);
    }
    i++;
    
    if ( cCtlFlowFlag == 'y' ){
      /* bypass control flow SOF except error message */
      if(caSofBuf[SOF_CTL_CODE_OFFSET] & LAST_MSG_MASK ){
        cCtlFlowFlag = 'n';
      }
      if(caSofBuf[SOF_CTL_CODE_OFFSET] & ERROR_MSG_MASK ){
        iRc = CnvSofToMsgp(caSofBuf, &stMsgp);
        if ( iRc != 0){
          UCP_TRACE_END(-4);
        }
        TPEWRITE(pcApa, &stMsgp);
        if (stMsgp.cWriteRtnCode == TMS_MSGP_NORMAL){
          memcpy(pcMsgpOutCode, &stMsgp.stWriteData.cMsgType, 4);
          UCP_TRACE_END(-9);
        }else{
          sprintf(g_caMsg,"RdOutToTPEWRITE:TPEWRITE error,msgp_return_code=%c",
                  stMsgp.cWriteRtnCode);
          ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
          UCP_TRACE_END(-5);
        }
      }

    }else{
 
      /* --- test the SOF whether the SOF is PIGGYBACK SOF or not     ---- */
      if(strncmp(&caSofBuf[SOF_OUT_DEV_OFFSET],"@@@@@@@@",8)== 0){
        iTotalPackSofLen=SOF_HEAD_LEN_PLUS_2;
        while ( iTotalPackSofLen < iSofDataLen+SOF_HEAD_LEN_PLUS_2 ) {
          sPackSofDataLen=
           (unsigned char) caSofBuf[iTotalPackSofLen+SOF_DATA_LEN_OFFSET]*256
           +(unsigned char)caSofBuf[iTotalPackSofLen+SOF_DATA_LEN_OFFSET+1];
          sprintf(g_caMsg,"RdOutToTPEWRITE:SOF index=%d,dump SOF head&data",i);
          ErrLog(100, g_caMsg, RPT_TO_LOG, &caSofBuf[iTotalPackSofLen], 
                 sPackSofDataLen + SOF_HEAD_LEN_PLUS_2);
          iRc = CnvSofToMsgp(&caSofBuf[iTotalPackSofLen], &stMsgp);
          if ( iRc != 0){
            UCP_TRACE_END(-4);
          }
          TPEWRITE(pcApa, &stMsgp);
          if (stMsgp.cWriteRtnCode != TMS_MSGP_NORMAL){
            sprintf(g_caMsg,"RdOutToTPEWRITE:TPEWRITE error,msgp_rtn_code=%c",
                    stMsgp.cWriteRtnCode);
            ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
            UCP_TRACE_END(-5);
          }
          i++;
          iTotalPackSofLen=iTotalPackSofLen+sPackSofDataLen+SOF_HEAD_LEN_PLUS_2;
        } /* end while */
      } /* end of processing PIGGYBACK SOF */
      else{
        iRc = CnvSofToMsgp(caSofBuf, &stMsgp);
        if ( iRc != 0){
          UCP_TRACE_END(-4);
        }
        TPEWRITE(pcApa, &stMsgp);
        if (stMsgp.cWriteRtnCode != TMS_MSGP_NORMAL){
          sprintf(g_caMsg,"RdOutToTPEWRITE:TPEWRITE error,msgp_return_code=%c",
                  stMsgp.cWriteRtnCode);
          ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
          UCP_TRACE_END(-5);
        }
      }

    } /* end of if ( cCtlFlowFlag == 'y' ) else */

  }/* end of for loop */

  sprintf(g_caMsg,"RdOutToTPEWRITE:End");
  ErrLog(100, g_caMsg, RPT_TO_LOG, 0, 0);
  UCP_TRACE_END(0);
  
}

/*
 *&N& ROUTINE NAME: CnvSofTOMsgp  
 *&A& ARGUMENTS:
 *&A&  char *pcSof	: SOF. 
 *&A&  char *pcMsgp	: MSGP.
 *&A&           
 *&R& RETURN VALUES:
 *&R&    0 : Normal.
 *&R&   -1 : SOF data length is greater 2000. 
 *&R&           
 *&D& DESCRIPTION:           
 *&D&   This funtion is transform SOF to MSGP. 
 */
 
CnvSofToMsgp(char *pcSof, struct WriteSt *pstMsgp)
{
  int iSofLen;

  UCP_TRACE(P_CnvSofToMsgp);

  iSofLen = (unsigned char)pcSof[SOF_DATA_LEN_OFFSET]*256 +
            (unsigned char)pcSof[SOF_DATA_LEN_OFFSET+1];
  sprintf(g_caMsg,"CnvSofToMsgp:Begin.Dump SOF");
  ErrLog(100, g_caMsg, RPT_TO_LOG, pcSof, iSofLen+SOF_HEAD_LEN_PLUS_2);
  if ( iSofLen > MSGP_MAX_LEN ){
    sprintf(g_caMsg,"CnvSofToMsgp:SOF length=%d is greater %s", iSofLen,
            MSGP_MAX_LEN);
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END(-1);
  }
  sprintf(pstMsgp->stWriteData.caDataLen, "%.4d", iSofLen);
  memcpy(&pstMsgp->stWriteData.cOutDevType, pcSof+SOF_OUT_DEV_OFFSET, 1);
  memcpy(&pstMsgp->stWriteData.cMsgType, pcSof+SOF_MSG_CODE_OFFSET+3, 4);
  memcpy(pstMsgp->stWriteData.caOutMsg, pcSof+SOF_HEAD_LEN_PLUS_2, iSofLen);

  sprintf(g_caMsg,"CnvSofToMsgp:End.Dump MSGP");
  ErrLog(100, g_caMsg, RPT_TO_LOG, pstMsgp, iSofLen+10);

  UCP_TRACE_END(0);
}

/*
 *&N& ROUTINE NAME: RdOutToOutMemory  
 *&A& ARGUMENTS:
 *&A&  char *pcOutputFileName	: Reoutput file name. 
 *&A&  char *pcMsgpOutCode	: Output field, if previous txn is error then
 *&A&                             copy previou txn's error code to it. 
 *&A&           
 *&R& RETURN VALUES:
 *&R&    0 : Normal.
 *&R&   -1 : File not found.
 *&R&   -2 : Call fstat() error. 
 *&R&   -3 : File size is greater than sizeof(gcaMemBuf). 
 *&R&   -4 : Read output data from file error. 
 *&R&   -5 : Read control information from MemFile error
 *&R&   -9 : Output data in output data file is error message.
 *&R&           
 *&D& DESCRIPTION:           
 *&D&   This funtion is used by reoutput output data from prescribe file. If 
 *&D& output data is error message then return output message code by 
 *&D& pcMsgpOutCode.
 */
 
RdOutToOutMemory(char *pcOutputFileName, char *pcMsgpOutCode)
{
  int  iOutputFd;
  int  iRc, iSofDataLen;
  int  iTotalOutputLen;
  struct stat stStat;
  int iFileSize;
  struct  MemBufCtlSt stMemBufCtl;

  UCP_TRACE(P_RdOutToOutMemory);

  sprintf(g_caMsg,"RdOutToOutMemory:Begin.File name=[%s]",pcOutputFileName);
  ErrLog(100, g_caMsg, RPT_TO_LOG, 0, 0);

  /* open reoutput file */
  iOutputFd = open(pcOutputFileName, O_RDONLY);
  if ( iOutputFd == -1 ){
    sprintf(g_caMsg,"RdOutToOutMemory:open %s error,errno=%d",pcOutputFileName,
            errno);
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END(-1);
  } 
  memcpy(pcMsgpOutCode, "0000", 4);/* clear output message code */

  iRc = fstat(iOutputFd,&stStat);
  if (iRc != 0) {
    sprintf(g_caMsg,"RdOutToOutMemory:call fstat() error,errno = %d",errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    close(iOutputFd);
    UCP_TRACE_END ( -2 );
  } /* if (iRc != 0) */

  iFileSize = stStat.st_size;
  sprintf(g_caMsg,"RdOutToOutMemory:iFileSize=%d",iFileSize);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  iRc = read(iOutputFd,&stMemBufCtl,sizeof(struct MemBufCtlSt));
  if( iRc != sizeof(struct MemBufCtlSt) ) {
      sprintf(g_caMsg,
          "RdOutToOutMemory:read stMemBufCtlSt error! errno=%d",errno);
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      close(iOutputFd);
      UCP_TRACE_END(-5);
  }

  g_stMemBufCtl.iNextOffset = stMemBufCtl.iNextOffset;
  g_stMemBufCtl.iMsgCnt     = stMemBufCtl.iMsgCnt;

  if ( iFileSize > sizeof(g_caMemBuf) ){ 
    sprintf(g_caMsg,
        "RdOutToOutMemory:Output file size=[%d] is over sizeof(g_caMemBuf)=%d"
            , iFileSize, sizeof(g_caMemBuf) );
    ErrLog(100, g_caMsg, RPT_TO_LOG, 0, 0);
    g_cFlushMemToFileFlag = 'y';
    g_cRcvRmtDataFlag = RCV_OK;
    close(iOutputFd);
  }
  else {
    /* read SOF control part from output file */
    iRc = read(iOutputFd, &g_caMemBuf[sizeof(struct MemBufCtlSt)],
               iFileSize-sizeof(struct MemBufCtlSt));

    if ( iRc != (iFileSize-sizeof(struct MemBufCtlSt)) ){ 
        sprintf(g_caMsg,
  "RdOutToOutMemory:read %s error,read length=%d,actual read length=%d,errno=%d"
         , pcOutputFileName, iFileSize-sizeof(struct MemBufCtlSt), iRc, errno);
        ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
        close(iOutputFd);
        UCP_TRACE_END(-4);
    }
    sprintf(g_caMsg,"RdOutToOutMemory:dump g_caMemBuf");
    ErrLog(100,g_caMsg,RPT_TO_LOG,&g_caMemBuf[sizeof(struct MemBufCtlSt)],
           iFileSize-sizeof(struct MemBufCtlSt));

    close(iOutputFd);

    if(g_caMemBuf[sizeof(struct MemBufCtlSt)+SOF_CTL_CODE_OFFSET] 
       & ERROR_MSG_MASK ){
      memcpy(pcMsgpOutCode,
             &g_caMemBuf[sizeof(struct MemBufCtlSt)+SOF_MSG_CODE_OFFSET+3],4);
      UCP_TRACE_END(-9);
    }

    sprintf(g_caMsg,"RdOutToOutMemory:End,g_stMemBufCtl.iMsgCnt=%d",
            g_stMemBufCtl.iMsgCnt);
    ErrLog(100, g_caMsg, RPT_TO_LOG, 0, 0);
    g_cRcvRmtDataFlag = RCV_OK;
  }
  UCP_TRACE_END(0);
  
}
