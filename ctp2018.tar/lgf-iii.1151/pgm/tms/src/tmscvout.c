/* ------------------------- INCLUDE FILES ---------------------------- */
#include "errlog.h"
#include "tmcinedt.h"
#include "tmctxin.h"
#include "tmcpgdef.h"	/* TMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */
#include "twa.h"
#include "tms.h"

/* ------------------------- CONSTANT DEFINITION ---------------------- */
/* tmscvout.c 
#define P_ConvItem 		24601
#define P_CtfToSif 		24602
#define P_GetSifFromCtf 	24603
#define P_NumToStr 		24604
#define P_Remove0 		24605
#define P_Reverse 		24606
#define P_UnpackFun 		24607
#define P_SignNumToStr 		24608
#define P_ApDataToSif 		24609
*/
#define HIGH_NIBBLE_MASK        0xf0
#define LOW_NIBBLE_MASK         0x0f
#define DATA_ATTR_MASK          0x02

#ifdef LPI_COBOL 

#define PLUS_0			'{'
#define PLUS_1			'A'
#define PLUS_9			'I'
#define MINUS_0			'}'
#define MINUS_1			'J'
#define MINUS_9			'R'

#elif defined( MF_COBOL )

#define PLUS_0			'0'
#define PLUS_1			'1'
#define PLUS_9			'9'
#define MINUS_0			'p'
#define MINUS_1			'q'
#define MINUS_9			'y'

#else

#define PLUS_0			'0'
#define PLUS_1			'1'
#define PLUS_9			'9'
#define MINUS_0			'p'
#define MINUS_1			'q'
#define MINUS_9			'y'

#endif

/* ------------------ EXTERN VARIABLE DECLARATION --------------------- */
extern char *g_pcCtf;
extern struct TMA *g_pstTma;
extern int g_iTxnCodeLen;       /* Txn code real length          */
extern int g_iTmCodeLen;        /* Term code real length         */
extern int g_iBrhCodeLen;       /* Branch code real length       */
extern int g_iTellerCodeLen;       /* Branch code real length       */

/*--------- CALLED FUNCTION & SUBROUTINE PROTOTYPE DECLARATIONS ------*/
char *GetSifFromCtf();
char *UnpackFun();
char *NumToStr();
char *SignNumToStr();

int
CtfToSif( cDataType,pcTxnCode, pcData, pcSif )
char cDataType;
char *pcTxnCode;
char *pcData;
char *pcSif;
{
  int  i;
  int iRc;
  char caTxnCode[ MAX_TXN_LEN + 1 ];
  busi_head stBusiDesc; /* business name description               */
  txn_head stTxnDesc;   /* transaction characteristic description  */
  txn_item stItmDesc;   /* transcation input item description      */

  UCP_TRACE(P_CtfToSif);

  /* get txn code from the first parameter  */
  memcpy( caTxnCode, pcTxnCode, g_iTxnCodeLen );
  caTxnCode[ g_iTxnCodeLen ] = '\0';

  iRc = ReadIet( BUSI_DESC, RANDOM_READ, caTxnCode, (char *)&stBusiDesc );
  if (iRc < 0) {
    sprintf(g_caMsg, "CtfToSif: ReadIet() fails! (business node),caTxnCode=%s",
            caTxnCode);
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( CTFTOSIF_BUSI_ERR, g_caMsg );
    UCP_TRACE_END( CTFTOSIF_BUSI_ERR );
  }

  iRc = ReadIet( TXN_DESC, RANDOM_READ, caTxnCode, (char *)&stTxnDesc );
  if (iRc < 0) {
    sprintf(g_caMsg,"CtfToSif:ReadIet() fails!(transcation node),caTxnCode=%s",
            caTxnCode);
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( CTFTOSIF_TXN_ERR, g_caMsg );
    UCP_TRACE_END( CTFTOSIF_TXN_ERR );
  }

  /* copy txn code from "CTF" or "API" to SIF's txn code field  */
  memcpy( pcSif + 4, pcTxnCode, g_iTxnCodeLen );

  /* Add by Chi Fu-Song 1994/07/15. If Txn has not any input item , then
   * function does not need to call ReadIet() & ConvItem()
   */
  if ( stTxnDesc.sTotItem > 0 ) {

    /*
     * begin to convert the first item 
     */
    iRc = ReadIet( ITM_DESC, RANDOM_READ, caTxnCode, (char *)&stItmDesc );
    if (iRc < 0) {
      sprintf(g_caMsg, "CtfToSif: ReadIet() fails! (first item node)");
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      DetErrRpt( CTFTOSIF_ITM1_ERR, g_caMsg );
      UCP_TRACE_END( CTFTOSIF_ITM1_ERR );
    }

    iRc = ConvItem(cDataType,pcSif,pcData,&stBusiDesc,&stTxnDesc,&stItmDesc,0);
    if (iRc < 0) {
      sprintf(g_caMsg, "CtfToSif: ConvItem() fails! (first item node)");
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      DetErrRpt( CTFTOSIF_CNVITM1_ERR, g_caMsg );
      UCP_TRACE_END( CTFTOSIF_CNVITM1_ERR );
    }

    /*
     * to convert the other items
     */
    for ( i = 1; i < stTxnDesc.sTotItem; i ++ ) {

      iRc = ReadIet( ITM_DESC, READ_NEXT, caTxnCode, (char *)&stItmDesc );
      if (iRc < 0) {
        sprintf(g_caMsg, "CtfToSif: ReadIet() fails! (next item node=%d)",i);
        ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
        DetErrRpt( CTFTOSIF_ITMn_ERR, g_caMsg );
        UCP_TRACE_END( CTFTOSIF_ITMn_ERR );
      }

      iRc=ConvItem(cDataType,pcSif,pcData,&stBusiDesc,&stTxnDesc,&stItmDesc,i);
      if (iRc < 0) {
        sprintf(g_caMsg, "CtfToSif: ConvItem() fails! (next item node=%d)",i);
        ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
        DetErrRpt( CTFTOSIF_CNVITMn_ERR, g_caMsg );
        UCP_TRACE_END( CTFTOSIF_CNVITMn_ERR );
      }

    }  /* for ( i = 1; i < stTxnDesc.sTotItem; i ++ ) { */

  }  /* if ( stTxnDesc.sTotItem > 0 ) { */
  /* added by WuChihLiang 19951028 for SIF item no. is zero */
  else{
    iRc = SIF_HEAD_LEN;
  }

  UCP_TRACE_END( iRc );

}

int
ConvItem(cDataType, pcSif, pcData, pstBusiDesc, pstTxnDesc, pstItmDesc, iItemNo)
char cDataType;
char *pcSif;
char *pcData;
busi_head *pstBusiDesc; 
txn_head *pstTxnDesc;   
txn_item *pstItmDesc;  
int iItemNo;
{
  int iRc;
  char cNeedFmtCnv;
  short sSifLen;
  int iCtfRelatNo;       /* from 0 ... */
  static char *s_pcSifData;       /* pointer to the the first data in SIF */
  char *pcItmStart;      /* The first tbl_item starting address in CTF_BOOK */
  tbl_item  *pstCtfItem; /* transcation input item attribute description    */
  char caSifData[ MAX_CTF_LEN ];  /* buffer for one item data of CTF      */
  static char *s_pcData;
  char *pcTempData;
  int i;

  UCP_TRACE( P_ConvItem );

  if ( iItemNo == 0 ) {
    s_pcSifData = pcSif + SIF_HEAD_LEN;
    if ( cDataType == PART_CTF_TYPE ) {
      s_pcData = pcData;
    }
  } /* s_pcSifData needs to be set when the first Item to be convert */

  cNeedFmtCnv = pstItmDesc->cDatAttr & DATA_ATTR_MASK;
  if ( ! cNeedFmtCnv ) { /* for no data input field */
    UCP_TRACE_END( s_pcSifData - pcSif );
  }

  GetItmStartAddr( g_pcCtf, &pcItmStart );
  iCtfRelatNo = pstItmDesc->iCtfRelat - 1;
  pstCtfItem = (tbl_item *)(pcItmStart + iCtfRelatNo * sizeof(tbl_item));
  if ( cDataType == CTF_TYPE ) {
    s_pcData = pcData + pstCtfItem->iCtfOffs;
  }

  /* reset the content of the temporary storages */
  memset( caSifData, '\0', MAX_CTF_LEN );   
  pcTempData=GetSifFromCtf( pstCtfItem, s_pcData );
  sprintf(g_caMsg,"ConvItem:cDataType=%c,iCtfLen=%d,content=[%.*s]",
      pstCtfItem->cDataType,pstCtfItem->iCtfLen,pstCtfItem->iCtfLen,s_pcData);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
  if ( pcTempData == NULL ) {
    if (pstCtfItem->cDataType != 'x' && pstCtfItem->cDataType != 'y') {
      for(i=0;i<pstCtfItem->iCtfLen;i++) {
        if(s_pcData[i] != ' ') break;
      }
      if(i == pstCtfItem->iCtfLen) {
        caSifData[0]='\0';
      }
      else {
        UCP_TRACE_END(-1);
      }
    }
    else {
      UCP_TRACE_END(-1);
    }
  }
  else {
    strcpy( caSifData, pcTempData );
  }

  sSifLen = strlen( caSifData );
/* added by WuChihLiang(19950321) for check Sif length -- BEGIN */
  if ( s_pcSifData - pcSif > MAX_SIF_LEN - sSifLen - 2 ){
    sprintf(g_caMsg,"ConvItem: SIF length=%d > MAX_SIF_LEN=%d",
            s_pcSifData - pcSif + sSifLen + 2, MAX_SIF_LEN);
    ErrLog(1000, g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  }
/* added by WuChihLiang(19950321) for check Sif length -- END   */
/* mark for modify byte1x256 + byte2 , 1994/10/3 , Chi-Fu-Song
  memcpy( s_pcSifData, &sSifLen, 2 );
 */

  *(s_pcSifData) = (char) sSifLen/256; 
  *(s_pcSifData+1) = (char) sSifLen%256; 

  s_pcSifData += 2; /* forward 2 bytes ( data_len field ) for each data */
  memcpy( s_pcSifData, caSifData, sSifLen );

  s_pcSifData += sSifLen; /* forward one data with length sSifLen */

  if ( cDataType == PART_CTF_TYPE ) {
    s_pcData += pstCtfItem->iCtfLen;
  } /* forward one data with length pcCtfItem->iCtfLen */

  UCP_TRACE_END( s_pcSifData - pcSif );
}

/* ******************************************************************** */
/*	GetSifFromCtf() : retrieve data from CTF area(ctf)     		*/
/* ******************************************************************** */
char *
GetSifFromCtf( pstCtfItem, pcData )
tbl_item  *pstCtfItem;
char *pcData;
{
  int   i, j;
  short sDataLen;
  char  cFlag;
  char  *pcTempData;
  static char caDataBuf[ MAX_CTF_LEN ];

  UCP_TRACE(P_GetSifFromCtf);

/*
  sprintf(g_caMsg,"GetSifFromCtf: item len=%d",pstCtfItem->iCtfLen);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
  sprintf(g_caMsg,"GetSifFromCtf: item data=%s",caDataBuf);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
*/

  memset(caDataBuf,0,MAX_CTF_LEN);
  memcpy(caDataBuf, pcData, pstCtfItem->iCtfLen);
  switch (pstCtfItem->cDataType) {
    case 'p':
    case 'h':
         j = 0;
         sDataLen = pstCtfItem->iDataLen; 
         pcTempData = UnpackFun(caDataBuf, pstCtfItem->iDataLen);
         cFlag = 0;
         for (i = 0; i < sDataLen - 1; i++) {
           if (pcTempData[i] != '0' || cFlag == 1) {
             cFlag = 1;
             caDataBuf[j++] = pcTempData[i];
           }
         }

         if (cFlag == 0) {
           caDataBuf[j++] = '0';
           break;
         }

         caDataBuf[j] = '\0';
         if (pstCtfItem->iDotPos > 0) {
           j = 0;
           for (i = strlen(caDataBuf); j <= pstCtfItem->iDotPos; i--,j++) {
             caDataBuf[i+1] = caDataBuf[i];
           }
           caDataBuf[i+1] = '.'; 
         }
         break;
    case 'k':
    case 't':
         j = 0;
         if (pstCtfItem->iDotPos > 0 && pstCtfItem->iDataLen % 2) {
           sDataLen = pstCtfItem->iDataLen - 1;
         }
         else {
           sDataLen = pstCtfItem->iDataLen;
         }

         pcTempData = UnpackFun(caDataBuf, sDataLen);
         switch (pcTempData[ sDataLen - 1 ]) {
           case 0x3c:
                caDataBuf[j++] = '+';
                break;
           case 0x3d :
                caDataBuf[j++] = '-';
         }
         cFlag = 0;
         for (i = 0; i < sDataLen - 1; i++) {
           if (pcTempData[i] != '0' || cFlag == 1) {
             cFlag = 1;
             caDataBuf[j++] = pcTempData[i];
           }

           if (cFlag == 0) {
             caDataBuf[j++] = '0';
             break;
           }
           caDataBuf[j] = '\0';

           if (pstCtfItem->iDotPos > 0) {
             j = 0;
             for (i = strlen(caDataBuf); j <= pstCtfItem->iDotPos; i--,j++) {
               caDataBuf[i+1] = caDataBuf[i];
             }
             caDataBuf[i+1] = '.'; 
           }
         }
         break;
    case 'b':
    case 'j':
    case 'g':
    case 'r':
         caDataBuf[0] = '0';
         caDataBuf[1] = '\0';
         break;
    case 'x':
    case 'y':
         caDataBuf[pstCtfItem->iCtfLen] = '\0';
         break;
    case '9':
    case 'f':
         caDataBuf[pstCtfItem->iCtfLen] = '\0';
         pcTempData = NumToStr(pstCtfItem->iDotPos, caDataBuf);
         if(pcTempData == NULL) {
           UCP_TRACE_END( NULL );
         }
         strcpy(caDataBuf, pcTempData);
         break;
    case 'i':
    case 'q':
         caDataBuf[pstCtfItem->iCtfLen] = '\0';
         pcTempData = SignNumToStr(pstCtfItem->iDotPos, caDataBuf);
         if(pcTempData == NULL) {
           UCP_TRACE_END( NULL );
         }
         strcpy(caDataBuf, pcTempData);
         break;
  }

  UCP_TRACE_END( caDataBuf );
}

/* ******************************************************************** */
/*	UnpackFun() : unpacking data routine                            */
/*	The function convert pack-data to unpack-data			*/
/* ******************************************************************** */
char *
UnpackFun(pcPackData, iUnpkLen)
char *pcPackData;
int iUnpkLen;
{
    char i, j;
    static char caUnpkData[MAX_CTF_LEN];

    UCP_TRACE(P_UnpackFun);

    for (i = j = 0; j < iUnpkLen; i++) {
	if (j % 2) {
	  caUnpkData[j++] = (pcPackData[i/2] & LOW_NIBBLE_MASK) + '0';
        }
	else {
	  caUnpkData[j++] = ((pcPackData[i/2] >> 4) & LOW_NIBBLE_MASK) + '0';
        }
    }
    caUnpkData[j] = '\0';

    UCP_TRACE_END(caUnpkData);
}

/* ******************************************************************** */
/*	NumToStr() : process numberic to character string		*/
/* ******************************************************************** */
char *
NumToStr(iDotPos, pcNumData)
int iDotPos;
char *pcNumData;
{
  int   i, j;
  int   iNumLen;
  static char caNumStr[MAX_CTF_LEN];

  UCP_TRACE( P_NumToStr );

  iNumLen = strlen( pcNumData );
  if (iNumLen == 0) {
    UCP_TRACE_END( NULL );
  }

  for(i=0;i<iNumLen;i++) {
    if(pcNumData[i]<'0' || pcNumData[i]>'9') {
      UCP_TRACE_END( NULL );
    }
  }

  caNumStr[0]=' ';
  for (i = 0, j = 1; i < iNumLen; i++) {
    if (j == iNumLen - iDotPos + 1) { 
      caNumStr[j++] = '.';
    }
    caNumStr[j++] = pcNumData[i];
  }

  caNumStr[j] = '\0';
  Remove0( caNumStr );

  UCP_TRACE_END( caNumStr );
}

/* ******************************************************************** */
/*	SignNumToStr() : process sign numberic to character string      */
/* ******************************************************************** */
char *
SignNumToStr(iDotPos, pcNumData)
int iDotPos;
char *pcNumData;
{
  int   i, j;
  int   iNumLen;
  char  cLastDig, cSignDig;
  static char caNumStr[MAX_CTF_LEN];

  UCP_TRACE( P_SignNumToStr );

  iNumLen = strlen( pcNumData );
  if (iNumLen == 0) {
    UCP_TRACE_END( NULL );
  }

  for(i=0;i<iNumLen-1;i++) {
    if(pcNumData[i]<'0' || pcNumData[i]>'9') {
      UCP_TRACE_END( NULL );
    }
  }

  cLastDig = pcNumData[iNumLen - 1];

  if (((cLastDig >= MINUS_1) && (cLastDig <= MINUS_9)) || (cLastDig == MINUS_0))
  {
    cSignDig = '-';
  }
  else {
    if (((cLastDig >= PLUS_1) && (cLastDig <= PLUS_9)) || (cLastDig == PLUS_0)) 
    {
      cSignDig = '+';
    }
    else {
      cSignDig = ' ';
    }
  }

  if ((cLastDig == MINUS_0) || (cLastDig == PLUS_0)) {
    cLastDig = '0';
  }
  else {
    if (cSignDig == '-') {
      cLastDig = cLastDig - (MINUS_1 - '1');
    }
    else if ((cLastDig >= PLUS_1) && (cLastDig <= PLUS_9)) {
      cLastDig = cLastDig - (PLUS_1 - '1');
    }
  }

  caNumStr[0] = cLastDig;

  j = 1;
  for (i = iNumLen - 2; i >= 0; i--) {
    if (j == iDotPos) { 
      caNumStr[j++] = '.';
    }
    caNumStr[j++] = pcNumData[i];
  }

  caNumStr[j++] = cSignDig;
  caNumStr[j] = '\0';

  Reverse( caNumStr );
  Remove0( caNumStr );

  UCP_TRACE_END( caNumStr );
}

/* ******************************************************************** */
/*	Reverse() : reverse character string      			*/
/* ******************************************************************** */
int
Reverse( caStr )
char caStr[];
{
  int i, j;
  char cCh;

  UCP_TRACE(P_Reverse);

  for (i = 0, j = strlen(caStr)-1; i < j; i++, j--) {
    cCh = caStr[i];
    caStr[i] = caStr[j];
    caStr[j] = cCh;
  }

  UCP_TRACE_END(0);
}

/* ******************************************************************** */
/*   Remove0() :  remove '0'from character string    			*/
/* ******************************************************************** */
int
Remove0( caStr )
char caStr[];
{
  int i, j;

  UCP_TRACE(P_Remove0);

  for (i = 1; caStr[i] != '.' && caStr[i] != '\0'; i++);

  /* if integer part is 0 */
  if (i == 1){
    UCP_TRACE_END(0);
  }

  j = i - 2;
  for (i = 1; i <= j && caStr[i] == '0'; i++);

  for (j = 1; caStr[i] != '\0'; i++, j++) {
    caStr[j] = caStr[i];
  }
  caStr[j] = '\0';

  if ( caStr[0] == ' ' ) {
    for (j = 0, i = 1; caStr[i] != '\0'; i++, j++) {
      caStr[j] = caStr[i];
    }
    caStr[j] = '\0';
  }

  UCP_TRACE_END(0);
}


int 
ApDataToSif(struct ReinputCtlSt *pstReinput,char *pcApData, char *pcaRendo)
{
  char caDataLen[10];
  char *pcCurSifPtr;
  short sDataLen;
  int iApTotLen;
  int iCurApOffset;

  UCP_TRACE(P_ApDataToSif);
  /* ------------------------------------------------------------------ */
  /* prepare SIF HEAD DATA                                              */
  /* ------------------------------------------------------------------ */
  memset( pcaRendo, 0 , MAX_SIF_LEN );
  memcpy( &pcaRendo[TXN_CODE_OFFSET], pstReinput->caTxnCode, g_iTxnCodeLen);
  memcpy( &pcaRendo[BR_CODE_OFFSET], g_pstTma->stTSSA.caBrCode, g_iBrhCodeLen);
  memcpy( &pcaRendo[TM_CODE_OFFSET], g_pstTma->stTSSA.caTmCode, g_iTmCodeLen);
  memcpy( &pcaRendo[TELLER_CODE_OFFSET], g_pstTma->stTSSA.caTellId, 
          g_iTellerCodeLen);
  pcCurSifPtr = (char *) (pcaRendo + SIF_HEAD_LEN);

  /* ------------------------------------------------------------------ */
  /* Get AP's DATA Total Lenght                                         */
  /* ------------------------------------------------------------------ */
  memset(caDataLen, 0, 10);
  memcpy(caDataLen, pstReinput->caDataLen, 4);
  iApTotLen = atoi( caDataLen );

  iCurApOffset = 0;
  while ( iCurApOffset < iApTotLen ) {
    memset(caDataLen, 0, 10);
    memcpy(caDataLen,(char *) (pcApData+iCurApOffset), 4);
    sDataLen = (short) atoi( caDataLen );
    iCurApOffset += 4;
    if ( (iCurApOffset+sDataLen) > iApTotLen ) {
      sprintf(g_caMsg,"ApDataToSif: AP TPESCRQT total data length error! %d",
              iApTotLen);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END( -1 );         
    }
    else {
/* mark for modify byte1x256 + byte2 , 1994/10/3 , by Chi-Fu-Song
      memcpy(pcCurSifPtr, &sDataLen, SIF_DATA_LEN_SIZE);
 */
      if(((pcCurSifPtr-pcaRendo)+SIF_DATA_LEN_SIZE+sDataLen) > MAX_SIF_LEN) {
        UCP_TRACE_END( -2 );         
      }
      *(pcCurSifPtr) = (char) sDataLen/256;
      *(pcCurSifPtr+1) = (char) sDataLen%256;
      pcCurSifPtr +=  SIF_DATA_LEN_SIZE;
      memcpy(pcCurSifPtr, (char *) (pcApData+iCurApOffset), sDataLen);
      pcCurSifPtr +=  sDataLen;
      iCurApOffset +=  sDataLen;
    }
  }
  
  UCP_TRACE_END( pcCurSifPtr - pcaRendo );
}



int
CountTxnCtfLen(pcTxnCode)
char *pcTxnCode;
{
  int  i;
  int iRc;
  char caTxnCode[ MAX_TXN_LEN + 1 ];
  busi_head stBusiDesc; /* business name description               */
  txn_head stTxnDesc;   /* transaction characteristic description  */
  txn_item stItmDesc;   /* transcation input item description      */
  int iTxnCtfLen=0;

  memcpy( caTxnCode, pcTxnCode, g_iTxnCodeLen );
  caTxnCode[ g_iTxnCodeLen ] = '\0';

  iRc = ReadIet( BUSI_DESC, RANDOM_READ, caTxnCode, (char *)&stBusiDesc );
  if (iRc < 0) {
    sprintf(g_caMsg,"CountTxnCtfLen:ReadIet() fails!(business node),caTxnCode=%s", caTxnCode);
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    return( -1 );
  }

  iRc = ReadIet( TXN_DESC, RANDOM_READ, caTxnCode, (char *)&stTxnDesc );
  if (iRc < 0) {
    sprintf(g_caMsg,"CountTxnCtfLen:ReadIet() fails!(transcation node),caTxnCode=%s", caTxnCode);
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    return( -2 );
  }

  if ( stTxnDesc.sTotItem > 0 ) {
    iRc = ReadIet( ITM_DESC, RANDOM_READ, caTxnCode, (char *)&stItmDesc );
    if (iRc < 0) {
      sprintf(g_caMsg,"CountTxnCtfLen:ReadIet() fails! (first item node)");
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      return( -3 );
    }

    iRc=GetItemCtfLen(&stBusiDesc,&stTxnDesc,&stItmDesc);
    if (iRc < 0) {
      sprintf(g_caMsg,"CountTxnCtfLen:GetItemCtfLen() item ctf_len=%d",iRc);
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
      return( -4 );
    }
    iTxnCtfLen += iRc;

    for ( i = 1; i < stTxnDesc.sTotItem; i ++ ) {
      iRc = ReadIet( ITM_DESC, READ_NEXT, caTxnCode, (char *)&stItmDesc );
      if (iRc < 0) {
        sprintf(g_caMsg,"CountTxnCtfLen:ReadIet() fails! (item node=%d)",i);
        ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
        return( -3 );
      }

      iRc=GetItemCtfLen(&stBusiDesc,&stTxnDesc,&stItmDesc);
      if (iRc < 0) {
        sprintf(g_caMsg,"CountTxnCtfLen:GetItemCtfLen() item ctf_len=%d",iRc);
        ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
        return( -4 );
      }
      iTxnCtfLen += iRc;
    }  
  }

  return( iTxnCtfLen );
}



int
GetItemCtfLen(pstBusiDesc, pstTxnDesc, pstItmDesc)
busi_head *pstBusiDesc; 
txn_head *pstTxnDesc;   
txn_item *pstItmDesc;  
{
  char cNeedFmtCnv;
  char *pcItmStart;      /* The first tbl_item starting address in CTF_BOOK */
  int iCtfRelatNo;       /* from 0 ... */
  tbl_item  *pstCtfItem; /* transcation input item attribute description    */

  cNeedFmtCnv = pstItmDesc->cDatAttr & DATA_ATTR_MASK;
  if ( ! cNeedFmtCnv ) { /* for no data input field */
    return(0);
  }
  GetItmStartAddr( g_pcCtf, &pcItmStart );
  iCtfRelatNo = pstItmDesc->iCtfRelat - 1;
  pstCtfItem = (tbl_item *)(pcItmStart + iCtfRelatNo * sizeof(tbl_item));
  return(pstCtfItem->iCtfLen);
}
