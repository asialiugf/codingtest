#include "errlog.h"
#include "twa.h"
#include "tmcrelse.h"
#include "tmcpgdef.h"	/* TMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */
#include "tmcrpt.h"

/*
#define P_TxRelese		29001
#define P_EnvRelse		29002
*/

extern int g_iApPid;
extern char g_cNeedRelseTrm;
extern int TrmRelease();

int
TxRelese( char *pcErrStep )
{
  int iRc;
  struct output_info stTpfRptCtl;

  UCP_TRACE( P_TxRelese );

  *pcErrStep = '0';

  iRc = RelIfEnv();
  if (iRc < 0) {
    *pcErrStep = '1';
    ErrLog(1000, "TxRelese: RelIfEnv() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( REL_IF_ENV_ERR );
  }

  stTpfRptCtl.func_code = TPFRPT_CLOSE_ALL;
  tpfrpt(&stTpfRptCtl);

  UCP_TRACE_END( 0 );
}

EnvRelse()
{
  int iRc;
  struct TwaCtl stTwaCtl;
  char *pcDummy;

  UCP_TRACE( P_EnvRelse );

/* To avoid duplication of txn seq. no of the same terminal -- BEGIN */ 
  if (g_cNeedRelseTrm == 'y') {
    iRc = TrmRelease();
    if (iRc < 0) {
      sprintf(g_caMsg,"EnvRelse: TrmRelease fail! iRc=%d",iRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    }
    g_cNeedRelseTrm = 'n';
  }
/* To avoid duplication of txn seq. no of the same terminal -- END */ 

  /*
   * Remove Twa
   */
  stTwaCtl.cFunCode = TWA_REMOVE;
  iRc = TwaLowCtlFac(&stTwaCtl,pcDummy);
  if(iRc != TWA_NORMAL){
    sprintf(g_caMsg,"Remove Twa fail,iRc=%d", iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END( REMOVE_TWA_ERR );
  }
/*
  printf("---------- Remove TWA success.............\n");
*/

  /*
   * Kill Ap Process
   */
  iRc = KillApProcess();
  /*
  if(iRc < 0 ){
    sprintf(g_caMsg,"EnvRelese: Kill AP process ,iRc=%d", iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END( KILL_AP_ERR );
  }
  printf("---------- Kill AP success.............\n");
  */

  /*
   * Remove Synchronize Mechanism
   */
  iRc = RelsSync();
  if(iRc < 0 ){
    sprintf(g_caMsg,"Remove Sem fail,iRc=%d", iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END( REMOVE_SYNC_ERR );
  }
/*
  printf("---------- Remove SYNC success.............\n");
*/

  /*
   * Detach DBS 
   */
  iRc = DetIfEnv();
  if (iRc < 0) {
    ErrLog(1000, "EnvRelese: DetIfEnv() fails!", RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( DET_IF_ENV_ERR );
  }
/*
  printf("---------- DetIfEnv success.............\n");
*/

  UCP_TRACE_END( 0 );

}

int
KillApProcess()
{
  int iRc;
  char caCmdBuf[80];

  /* Kill Ap Process */

  UCP_TRACE(P_KillApProcess);

  if ( g_iApPid != -1 ) {
    iRc = kill(g_iApPid, 9);
/*
    sprintf(caCmdBuf,"kill -9 %d",g_iApPid);
    iRc = system( caCmdBuf );
*/
    if(iRc < 0 ){
      UCP_TRACE_END( -1 );
    }
  }

  UCP_TRACE_END( 0 );
}
