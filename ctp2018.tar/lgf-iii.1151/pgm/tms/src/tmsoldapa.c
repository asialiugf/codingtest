
/*
 *&N& File : tmsapa.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int       PrepaApa()           
 *&N&    int       SetTmaByApaOut         �����ε{����^��(�bAPA��),
 *&N&                                     �ӳ]�wTMA�������ܼƭȨ��
 *&N&    int       ChkPrePostApRtnCode
 *&N&    int       PrepaApaToPostAp
 */


/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include "twa.h"	/* �w�q TWA �ҨϥΨ쪺��Ƶ��c�α`�� */
#include "tms.h"	/* �w�q tm �t�ΨϥΨ쪺��Ƶ��c�α`�� */
#include "oldapa.h"	/* �w�q APA �ϥΨ쪺��Ƶ��c�α`�� */
#include "errlog.h"	/* �O�����~�T���ɨϥΨ쪺�`�Ƥθ�Ƶ��c */
#include "tmcpgdef.h"	/* TMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */
#include "ucp.h"
#include "upcomtwa.h"

/* -------------------- CONSTANT DEFINE  --------------------------- */
/*
#define P_PrepaApa 		25101
*/

/* -------------------- STATIC GLOBAL DECLARATION ------------------ */
extern struct TMA *g_pstTma;	/* point TWA.TMA��ưϪ������ܼ� */
extern struct ApaSt *g_pstApa;	/* point TWA.APA��ưϪ������ܼ� */
extern int g_iTxnCodeLen;       /* Txn code real length          */
extern int g_iTmCodeLen;        /* Term code real length         */
extern int g_iBrhCodeLen;       /* Branch code real length       */
extern struct HostToBrhInfoSt g_stHostToBrhInfo;

/* ------ CALL FUNCTION & SUBROUTINE PROTOTYPE DECLARATIONS -------- */
int PrepaApa();

/*
 *&N& ROUTINE NAME: PrepaApa()
 *&A& ARGUMENTS:
 *&A& ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& ����ƱqTMA��,�NAP�|�ϥΨ쪺��ƽƻs��APA��,�p:
 *&D& branch id�Bterminal id�Bterminal type�Boriginal branch status�B
 *&D& next txn date�Bnext business day count�Btotal txn seq. no�B
 *&D& acc txn seq no�Bnon-acc txn seq no�Bbatch txn seq no�Btxn start time�B
 *&D& txn code�Btxn date�Bsuperkey status�Bbook status�Breentry status�B
 *&D& teller id�Bfisc switch�Bfisc ap return code�Bover time �B
 *&D& cApAbendNoRlbk �BcTxnReinput�BcInterApProc(�s�ʺX��)�B
 *&D& cTxnReturnCode(�P TMA.cApReturnCode) �@24���C
 */

int
PrepaApa()
{
  int iRc;
  unsigned char ucaTemp[10];
  char *pcSifCtlData1;

  UCP_TRACE(P_PrepaApa);
  memcpy( g_pstApa->caBrCode, g_pstTma->stTSSA.caBrCode, g_iBrhCodeLen);
  memcpy( g_pstApa->caTmCode, g_pstTma->stTSSA.caTmCode, g_iTmCodeLen);
  g_pstApa->cTmType = g_pstTma->stTSSA.cTmType;
  g_pstApa->cOriginBrStatus = g_pstTma->stTSSA.cOriginBrStatus;
  memcpy(g_pstApa->caNextTxnDate,g_pstTma->stTSSA.caNextTxnDate,DATE_LEN);

  /* ------------------------------------------------------------------- */
  /* �NTWA��TMA.lAccTxnSeqNo�BTMA.lNonAccTxnSeqNo �ഫ�� COMP-3 �榡     */ 
  /* �s�JTWA��APA��,�H��AP�ϥΡC                                         */
  /* ------------------------------------------------------------------- */
  sprintf(ucaTemp,"%.*ld",5,g_pstTma->stTSSA.lAccTxnSeqNo);
  memcpy(g_pstApa->caAccTxnSeqNo,Comp3Conv(ucaTemp), TXN_SEQ_NO_LEN); 
  sprintf(ucaTemp,"%.*ld",5,g_pstTma->stTSSA.lNonAccTxnSeqNo);
  memcpy(g_pstApa->caNonAccTxnSeqNo,Comp3Conv(ucaTemp),TXN_SEQ_NO_LEN); 
  sprintf(g_caMsg,"PrepaApa: lAccTxnSeqNo=%d,lNonAccTxnSeqNo=%d",
          g_pstTma->stTSSA.lAccTxnSeqNo,g_pstTma->stTSSA.lNonAccTxnSeqNo);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
  sprintf(g_caMsg,"PrepaApa: APA.caAccTxnSeqNo=%02x%02x%02x",
          g_pstApa->caAccTxnSeqNo[0],g_pstApa->caAccTxnSeqNo[1],
          g_pstApa->caAccTxnSeqNo[2]);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
  sprintf(g_caMsg,"PrepaApa: APA.caNonAccTxnSeqNo=%02x%02x%02x",
          g_pstApa->caNonAccTxnSeqNo[0],g_pstApa->caNonAccTxnSeqNo[1],
          g_pstApa->caNonAccTxnSeqNo[2]);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  memcpy(g_pstApa->caTxnTime,g_pstTma->stTSSA.caStartTxnTime,TIME_LEN);
  memcpy(g_pstApa->caTxnCode,g_pstTma->stTSSA.caTxnCode,g_iTxnCodeLen);
  memcpy(g_pstApa->caTxnDate,g_pstTma->stTSSA.caTxnDate,DATE_LEN);
  memcpy(g_pstApa->caTellId,g_pstTma->stTSSA.caTellId,TELLER_CODE_LEN);

  pcSifCtlData1 = (char *) &g_pstTma->stTSSA.sSifCtlData;

  if ( (*pcSifCtlData1) & SUPER_MASK ) {
    g_pstApa->cSupKeyStatus = TMS_SUP_ON; /* �D�޼Ҧ� */
  }
  else {
    g_pstApa->cSupKeyStatus = TMS_SUP_OFF; /* �L�D�޼Ҧ� */
  }

  if ( (*pcSifCtlData1) & BOOK_MASK ) {
    g_pstApa->cBookStatus = TMS_WITH_PB; /* ���P */
  }
  else {
    g_pstApa->cBookStatus = TMS_NO_PB; /* �L�P */
  }

  if ( (*pcSifCtlData1) & REENTRY_MASK ) {
    g_pstApa->cReentryStatus = TMS_TXN_REENTRY;        /* ��e��� */
  }
  else {
    g_pstApa->cReentryStatus = TMS_TXN_NOT_REENTRY;        /* �@���� */
  }

#ifdef MF_COBOL
  if( g_pstTma->stTCFA.cRevTxn == TMS_TXN_NOT_REVERSE ) {
    g_pstApa->cTxnStatus = '1';         /* S9(1) 'q' -> -1 , '1' -> 1 */
  }
  else {
    g_pstApa->cTxnStatus = 'q';
  }
#endif
#ifdef LPI_COBOL
  if( g_pstTma->stTCFA.cRevTxn == TMS_TXN_NOT_REVERSE ) {
    g_pstApa->cTxnStatus = 'A';         /* S9(1) 'J' -> -1 , 'A' -> 1 */
  }
  else {
    g_pstApa->cTxnStatus = 'J';
  }
#endif
  ErrLog(100,"<PrepaApa> dump cTxnStatus=",RPT_TO_LOG,&g_pstApa->cTxnStatus,1);

  g_pstApa->cFiscSwitch = g_pstTma->stTCFA.cFiscSwitch;
  g_pstApa->cFiscApReturnCode = g_pstTma->stTCFA.cFiscApReturnCode;
  g_pstApa->cOverTime = g_pstTma->stTCFA.cOverTime;
  g_pstApa->cApAbendNoRlbk = g_pstTma->stTCFA.cApAbendNoRlbk;
  g_pstApa->cTxnReinput = g_pstTma->stTCFA.cTxnReinput;
  g_pstApa->cInterApProc = TMS_TXN_NOT_RENDO;
  g_pstApa->cTxnReturnCode = g_pstTma->stTCFA.cApReturnCode;

  /* ----------------------------------------------------------------- */
  /* ���ܦ�AP�O�Q�W��AP�s�ʪ�, �t�η|�bAPA���]�w�@�ܼ�,�H�i����AP      */
  /* �ثe���ϥ�APA����cApplStatus�ܼ�                                  */
  /* ----------------------------------------------------------------- */
  if ( g_pstTma->stTCFA.cRendoRequest == TMS_TXN_RENDO ) {
    g_pstApa->cApplStatus = '1';
  }

  ErrLog(10,"PrepaApa: DUMP APA=",RPT_TO_LOG,g_pstApa,sizeof(struct ApaSt));
  UCP_TRACE_END(0);
}




/*
 *&N& ROUTINE NAME: SetTmaByApaOut()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                 DESCRIPTION
 *&A&   ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& �ھ�AP���槹�����G, �NTWA.APA���Y�Ǹ�Ƴ]�w��TMA���C�@���U�C�ܼ�:
 *&D& caNonAccTxnSeqNo�BcaAccTxnSeqNo�BcTxnReturnCode�BcInterApProc�B
 *&D& cApAbendNoRlbk�BcRevTxn�BcTxnReinput�C
 */

int
SetTmaByApaOut()
{
  int iRc;
  char   caTmpBuf[10];
  char   *pcUnpackData;

  UCP_TRACE(P_SetTmaByApaOut);

  memset(caTmpBuf, 0, 10);
  memcpy(caTmpBuf, g_pstApa->caNonAccTxnSeqNo, TXN_SEQ_NO_LEN );
  g_pstTma->stTSSA.lNonAccTxnSeqNo = atol( UnpackData(caTmpBuf,5) );
/* for debug
  sprintf(g_caMsg,"NonAccTxnSeqNo = %ld\n",g_pstTma->stTSSA.lNonAccTxnSeqNo);
  ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
*/

  memset(caTmpBuf, 0, 10);
  memcpy(caTmpBuf, g_pstApa->caAccTxnSeqNo,TXN_SEQ_NO_LEN );
  g_pstTma->stTSSA.lAccTxnSeqNo = atol( UnpackData(caTmpBuf,5) );
/* for debug
  sprintf(g_caMsg,"AccTxnSeqNo = %ld\n",g_pstTma->stTSSA.lAccTxnSeqNo);
  ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
*/
  sprintf(g_caMsg,"SetTmaByApaOut: lAccTxnSeqNo=%d,lNonAccTxnSeqNo=%d",
          g_pstTma->stTSSA.lAccTxnSeqNo,g_pstTma->stTSSA.lNonAccTxnSeqNo);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  g_pstTma->stTCFA.cApReturnCode = g_pstApa->cTxnReturnCode;

  /*
   * If AP requests APRQT from APA flag, then we must set TWA.TMA.cRendoRequest
   * by APA's flag. Otherwise, Maybe TWA.TMA.cRendoRequest will set
   * by <tmsapi.c> REINPUT() or not.
   */
  if ( g_pstApa->cInterApProc == TMS_TXN_RENDO ) {
    g_pstTma->stTCFA.cRendoRequest = g_pstApa->cInterApProc;
  }

  g_pstTma->stTCFA.cApAbendNoRlbk = g_pstApa->cApAbendNoRlbk;

  ErrLog(100,"<SetTmaByApaOut> dump cTxnStatus=",
         RPT_TO_LOG,&g_pstApa->cTxnStatus,1);
#ifdef MF_COBOL
  if( g_pstApa->cTxnStatus == 'q') { /* S9(1) 'q' -> -1 , '1' -> 1 */
    g_pstTma->stTCFA.cRevTxn = TMS_TXN_REVERSE;
  }
#endif
#ifdef LPI_COBOL
  if( g_pstApa->cTxnStatus == 'J') { /* S9(1) 'J' -> -1 , 'A' -> 1 */
    g_pstTma->stTCFA.cRevTxn = TMS_TXN_REVERSE;     
  }
#endif

  /*
   * If AP requests REINPUT from APA flag, then we must set TWA.TMA
   * by APA's flag. Otherwise, Maybe TWA.TMA.cTxnReinput will set
   * by <tmsapi.c> REINPUT().
   */
  if ( g_pstApa->cTxnReinput == TMS_TXN_REINPUT_ON ) {
    g_pstTma->stTCFA.cTxnReinput = g_pstApa->cTxnReinput;
  }

  UCP_TRACE_END(0);
}

/*
 *&N& ROUNTINE NAME : ChkPrePostApRtnCode()
 *&A& ARGUMENTS: �L
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D& �ˬd�e�m�B�zAP�M��m�B�zAP���檺���G
 *&D&
 */
int
ChkPrePostApRtnCode() 
{
  int iRc;

  UCP_TRACE(P_ChkPrePostApRtnCode);
  g_pstTma->stTCFA.cApReturnCode = g_pstApa->cTxnReturnCode;

  if ( (g_pstApa->cTxnReturnCode == TMS_AP_ACC_NORMAL) ||
       (g_pstApa->cTxnReturnCode == TMS_AP_NON_ACC_NORMAL) ) {
    UCP_TRACE_END( 0 );
  }
  else {
    UCP_TRACE_END( -1 );
  }
}



/*
 *&N& ROUNTINE NAME : PrepaApaToPostAp()
 *&A& ARGUMENTS: �L
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D& �ھڻ��ݥD�����椧���G, �ǳ�APA����m�B�zAP
 *&D&
 */
int
PrepaApaToPostAp(char *pcBrhOfflnFlag)
{
  int iRc;
  UCP_TRACE(P_PrepaApaToPostAp)
  g_pstApa->cReentryStatus = (char) *pcBrhOfflnFlag;
  memcpy( g_pstApa->caTotalTxnSeqNo,
                       Comp3Conv(g_stHostToBrhInfo.caTotalTxnSeqNo),4);
  memcpy( g_pstApa->caAccTxnSeqNo,
                       Comp3Conv(g_stHostToBrhInfo.caAccTxnSeqNo),3);
  memcpy( g_pstApa->caNonAccTxnSeqNo,
                       Comp3Conv(g_stHostToBrhInfo.caNonAccTxnSeqNo),3);
  UCP_TRACE_END( 0 );
}
