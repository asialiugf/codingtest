
/*
 *&N& File : tmsrm.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int       DbsTxBegin()               ����ҩl
 *&N&    int       DbsTxEnd()                 �������
 */


/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include "errlog.h"	/* �O�����~�T���ɨϥΨ쪺�`�Ƥθ�Ƶ��c */
#include "tms.h"
#include "tmcifenv.h"
#include "tmcpgdef.h"	/* TMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */

/* -------------------- CONSTANT DEFINE  --------------------------- */
/*
#define P_DbsTxBegin 		27101
#define P_DbsTxEnd 		27102
*/

/* <tmsrm.c> DbsTxBegin() error message code */
#define  TXN_DBS_BEGIN_ERR       -1
#define  TXN_DBS_BEGIN_NULL_ERR  -2
#define  TXN_DBS_END_ERR         -3
#define  TXN_DBS_END_NULL_ERR    -4

/* -------------------- STATIC GLOBAL DECLARATION ------------------ */

/* ------ CALL FUNCTION & SUBROUTINE PROTOTYPE DECLARATIONS -------- */
int DbsTxBegin();
int DbsTxEnd( char );

extern int GetIfPgm();


/*
 *&N& ROUTINE NAME: DbsTxBegin()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                 DESCRIPTION
 *&A&   ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& �̾ڨt�����Ҫ���, �I�s����Ұʨ�ơC
 *&D&
 */

int
DbsTxBegin()
{
  int iRc;
  char cDontCare;
/*
  int (* pfDbsTxStart)();
*/
  UCP_TRACE(P_DbsTxBegin);

  cDontCare = 'x';
  iRc =  RunAllIfEnv( PGM_BEGIN , cDontCare );

  if ( iRc < 0 ) {
    ErrLog(1000,"DbsTxBegin: txn_begin fail!",RPT_TO_LOG,0,0);
    UCP_TRACE_END(TXN_DBS_BEGIN_ERR);
  }

/*
  if (pfDbsTxStart == NULL ) {
    ErrLog(1000,"DbsTxBegin: GetIfPgm fail!",RPT_TO_LOG,0,0);
    UCP_TRACE_END(TXN_DBS_BEGIN_NULL_ERR);
  }

  iRc = (x pfDbsTxStart)();
*/
  UCP_TRACE_END(0);
}

/*
 *&N& ROUTINE NAME: DbsTxEnd()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                 DESCRIPTION
 *&A&   ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& �̾ڨt�����Ҫ���, �I�s����Ұʨ�ơC
 *&D&
 */

int
DbsTxEnd( char cType )
{
  int iRc;
/*
  int (* pfDbsTxEnd)();
*/
  UCP_TRACE(P_DbsTxEnd);

  iRc =  RunAllIfEnv( PGM_END , cType );

  if ( iRc < 0 ) {
    ErrLog(1000,"DbsTxEnd: txn_end fail!",RPT_TO_LOG,0,0);
    UCP_TRACE_END(TXN_DBS_END_ERR);
  }

/*
  if (pfDbsTxEnd == NULL ) {
    ErrLog(1000,"DbsTxEnd: GetIfPgm fail!",RPT_TO_LOG,0,0);
    UCP_TRACE_END(TXN_DBS_END_NULL_ERR);
  }

  iRc = (x pfDbsTxEnd )( cType );
*/
  UCP_TRACE_END(0);
}
