/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include "errlog.h"
#include "tmcpgdef.h"	/* TMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */
#include "tmc.h"
#define DEBUG_MODE  '1'
/* -------------------- CONSTANT DEFINE ---------------------------- */
/*
#define	P_FlTxRlbk    22001
*/
/* -------------------- STATIC GLOBAL DECLARATION ------------------ */

/* ------ CALL FUNCTION & SUBROUTINE PROTOTYPE DECLARATIONS -------- */
extern char * GetServerId();
extern char g_cDebugFlag;

int   FlTxRlbk(char *pcErrStep)
{
  int iRc;
  char *pcServerId;

  UCP_TRACE(P_FlTxRlbk);

  pcServerId = GetServerId();

  iRc = 0 ;

  if ( g_cDebugFlag != DEBUG_MODE ) {
    iRc = SendAckToEms( pcServerId ,PRC_NORMAL );

    if ( iRc < 0 ) {
      *pcErrStep = '1';
      ErrLog(1000,"FlTxRlbk: SendAckToEms fail!",RPT_TO_LOG,0,0);
      UCP_TRACE_END( -1 );
    }

    /* iRc = GetEmsDisconnect(); */
    sprintf(g_caMsg,"FlTxRlbk(): Rcv Disconnect %d bytes data......",iRc);
    ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
    iRc = SendDisconnect();
  }

  UCP_TRACE_END ( 0 );

}
