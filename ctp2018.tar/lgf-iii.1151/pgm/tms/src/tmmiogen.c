/*
 *&N& File : tmmiogen.c
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&                 main()               ����TMS�ѷӪ��w�q��
 */

/* ------------------------- INCLUDE FILES ---------------------------- */
#include <stdio.h>
#include <errno.h>
#include "errlog.h"

/* ------------------------- CONSTANT DEFINITION  --------------------- */

#define  MAX_EXEC_PATH_LEN     80
#define  FILE_NAME_LEN         80
#define  MAX_CNVINOUT_NUM       3
#define  CNVINOUT_CNFG_ERR     -4
#define  OPEN_FILE_ERR	       -5
#define  CNVINOUT_FILE	 	"iii/etc/tbl/cnvinout.dat"
#define  TMS_CNVINOUT_DEF	"iii/bin/lib/tmdfmtcv.def"
#define  TMS_CNVINOUT_H	 	"iii/bin/lib/tmgfmtcv.h"
#define  CNVINOUT_H_TMP_FILE   	"iii/tmp/inout_h.tmp"
#define  CNVINOUT_DEF_TMP_FILE 	"iii/tmp/inout_def.tmp"

static
struct CnvInOutSt {
  char caFmtCode[10];       /* format code                  */
  char caCnvInName[20];     /* Convert in  function name    */
  char caCnvOutName[20];    /* Convert out function name    */
} sg_stCnvInOut;

extern int  errno;

main()
{
  int i;
  int iRc;
  int iTblSize;
  char caFlName[FILE_NAME_LEN];
  char caIoDefFlName[FILE_NAME_LEN];
  char caSortedFile[FILE_NAME_LEN];
  char caIoDefSortedFile[FILE_NAME_LEN];
  FILE *zIoFun;
  FILE *zTmsDef;
  FILE *zTmsh;


   memset(caSortedFile,'\0',FILE_NAME_LEN);
   strcpy(caSortedFile,(char *) getenv("III_DIR"));
   strcat(caSortedFile,(char *) "/");
   strcat(caSortedFile,TMS_CNVINOUT_H);

   memset(caIoDefSortedFile,'\0',FILE_NAME_LEN);
   strcpy(caIoDefSortedFile,(char *) getenv("III_DIR"));
   strcat(caIoDefSortedFile,(char *) "/");
   strcat(caIoDefSortedFile,TMS_CNVINOUT_DEF);

     /* -------------------- */
     /* get open file name   */
     /* -------------------- */
   memset(caFlName,'\0',FILE_NAME_LEN);
   strcpy(caFlName,(char *) getenv("III_DIR"));
   strcat(caFlName,(char *) "/");
   strcat(caFlName,CNVINOUT_FILE);

  /* open ifmod file name */
  if((zIoFun=fopen(caFlName,"r")) == NULL){
    printf("tmmiogen:open ems ifmod file=%s errno=%d\n",caFlName,errno);
    exit(OPEN_FILE_ERR);
  } /* FOR if((zIoFun=fopen(caFlname,"r")) == NULL) */

   memset(caIoDefFlName,'\0',FILE_NAME_LEN);
   strcpy(caIoDefFlName,(char *) getenv("III_DIR"));
   strcat(caIoDefFlName,(char *) "/");
   strcat(caIoDefFlName,CNVINOUT_DEF_TMP_FILE);

  /* open ifmod file name */
  if((zTmsDef=fopen(caIoDefFlName,"w")) == NULL){
    printf("tmmiogen:open tms def file=%s errno=%d\n",caIoDefFlName,errno);
    exit(OPEN_FILE_ERR);
  } /* FOR if((zIoFun=fopen(caFlname,"r")) == NULL) */

   memset(caFlName,'\0',FILE_NAME_LEN);
   strcpy(caFlName,(char *) getenv("III_DIR"));
   strcat(caFlName,(char *) "/");
   strcat(caFlName,CNVINOUT_H_TMP_FILE);

  /* open ifmod file name */
  if((zTmsh=fopen(caFlName,"w")) == NULL){
    printf("tmmiogen:open tms header file=%s errno=%d\n",caFlName,errno);
    exit(OPEN_FILE_ERR);
  } /* FOR if((zIoFun=fopen(caFlname,"r")) == NULL) */

   i=0;
   while((iRc=fscanf(zIoFun,"%s %s %s\n",
                     sg_stCnvInOut.caFmtCode,
                     sg_stCnvInOut.caCnvInName,
                     sg_stCnvInOut.caCnvOutName)) != EOF){
     if(iRc < MAX_CNVINOUT_NUM){
       printf("tmmiogen: fscanf input %d item < %d\n",iRc,MAX_CNVINOUT_NUM);
       exit(CNVINOUT_CNFG_ERR);
     }

    fprintf(zTmsDef,"\x22%s\x22, %s, %s,\n", sg_stCnvInOut.caFmtCode,
            sg_stCnvInOut.caCnvInName, sg_stCnvInOut.caCnvOutName);
    if ( strncmp(sg_stCnvInOut.caCnvInName,"NULL",4) !=0 ) {
      fprintf(zTmsh,"extern int %s();\n",sg_stCnvInOut.caCnvInName);
    }
    if ( strncmp(sg_stCnvInOut.caCnvOutName,"NULL",4) !=0 ) {
      fprintf(zTmsh,"extern int %s();\n",sg_stCnvInOut.caCnvOutName);
    }

   } /* FOR while((iRc=fscanf(....))  */
 
  fclose(zTmsh);
  fclose(zTmsDef);
  fclose(zIoFun);
    
  SortTmsIoH(caFlName,caSortedFile);
  SortTmsIoDef(caIoDefFlName,caIoDefSortedFile);
  printf("Generate tmdfmtcv.def, tmgfmtcv.h OK!!\n");
  exit(0);
}


SortTmsIoH(char *pcFileName,char *pcSortedFile)
{
  char caCmdBuf[250];
  sprintf(caCmdBuf,"sort +2 -3 -u < %s > %s",pcFileName,pcSortedFile);
  system(caCmdBuf);
}

SortTmsIoDef(char *pcFileName,char *pcSortedFile)
{
  char caCmdBuf[250];
  sprintf(caCmdBuf,"sort -u < %s > %s",pcFileName,pcSortedFile);
  system(caCmdBuf);
}
