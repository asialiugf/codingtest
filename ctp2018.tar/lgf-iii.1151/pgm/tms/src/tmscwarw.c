
/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include "tms.h"
#include "errlog.h"
#include "cwa.h"
#include "twa.h"
#include "tmcpgdef.h"	/* TMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */

/* -------------------- CONSTANT DEFINE  --------------------------- */
/*
#define   P_ShmFac          26401
#define   P_ReadLock        26402
#define   P_WriteUnlock     26403
#define   P_CheckSegName    26404
#define   P_ReadOnly        26405
#define   P_WriteOnly       26406
*/

/* define error message code */
#define   SHM_SEG_NAME_ERR    -1
#define   SHM_FUN_CODE_ERR    -2
#define   SHM_READ_LOCK_ERR   -3
#define   SHM_WR_UNLOCK_ERR   -4
#define   LOCK_SSA_ERR        -5
#define   GET_SSA_PTR_ERR     -6
#define   LOCK_TCT_ERR        -7
#define   GET_TCT_PTR_ERR     -8
#define   UNLOCK_SSA_ERR      -9
#define   UNLOCK_TCT_ERR      -10
#define   SHM_READ_ONLY_ERR   -11
#define   SHM_WR_ONLY_ERR     -12
#define   GET_ACIA_PTR_ERR    -13 
#define   GET_ACIA_LEN_ERR    -14

#define   CWA_SHM_LOG_SEG_VAL   0
#define   CWA_SHM_ACIA_SEG_VAL  1
/* -------------------- STATIC GLOBAL DECLARATION ------------------ */
extern struct TMA *g_pstTma;
extern int g_iBrhCodeLen;
extern int g_iTmCodeLen;
static struct CwaCtl stCwaCtl;
static struct SSA *sg_pstSsa;
static struct TermArea *sg_pstTct;
static struct AciaInt *sg_pstAcia;

/* ------ CALL FUNCTION & SUBROUTINE PROTOTYPE DECLARATIONS -------- */

/*
 *&N& ROUTINE NAME: ShmFac()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE       DESCRIPTION
 *&A&   ---------  -----------   ---------------------------------------
 *&A&   pcArg1     char *        ���VTWA.COA�}�l��}(�sShmCtlSt���c)
 *&A&   pcArg2     char *        ���VIO-AREA�}�l��}
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   SHM_SEG_NAME_ERR       : invalid segment name
 *&R&   SHM_FUN_CODE_ERR       : invalid shmfac function code
 *&R&   SHM_READ_LOCK_ERR      : CWA share memory read & lock error
 *&R&   SHM_WR_UNLOCK_ERR      : CWA share memory write & unlock error
 *&D& DESCRIPTION:
 *&D&  struct ShmCtlSt {
 *&D&    char cShmFunCode;
 *&D&    char caShmSegName[8];
 *&D&    char cShmReturnCode;
 *&D&  };
 *&D&  �̷�cShmFunCode�McShmSegName�i���CWA��ƪ��s���C�ñN���G��JpcArg2
 *&D&  �ҫ��w����}�C
 */
int
ShmFac(char *pcArg1,char *pcArg2)
{
  int iRc;
  struct ShmFacCtlSt *pstShmCtl;

  UCP_TRACE(P_ShmFac);
  sprintf(g_caMsg,"ShmFac:dump ShmFacCtlSt");
  ErrLog(100,g_caMsg,RPT_TO_LOG,pcArg1,sizeof(struct ShmFacCtlSt));
  pstShmCtl = (struct ShmFacCtlSt *)pcArg1;

 /*
  *  Check Segment Name �O�_���w�q   
  */
  iRc = CheckSegName(pstShmCtl->caShmSegName);
  sprintf(g_caMsg,"ShmFac:after CheckSegName segment name=%.8s",
          pstShmCtl->caShmSegName);
  ErrLog(100,g_caMsg,RPT_TO_LOG,pstShmCtl->caShmSegName,8);

  if (iRc < 0) {
     sprintf(g_caMsg,"ShmFac:invalid segment name=%.8s",
             pstShmCtl->caShmSegName);
     ErrLog(1000,g_caMsg,RPT_TO_LOG,pstShmCtl->caShmSegName,8);
     pstShmCtl->cShmReturnCode = TMS_SHM_ERR;
     UCP_TRACE_END(SHM_SEG_NAME_ERR);
  }

 /*
  *   Set Shm Return Code Status To TMS_SHM_NORMAL 
  */
  pstShmCtl->cShmReturnCode = TMS_SHM_NORMAL ;

  switch(pstShmCtl->cShmFunCode) {
  /* Mark Miao 19990609 for tu995012 begin
    case TMS_SHM_RD_LOCK :
         iRc = ReadLock(pcArg1,pcArg2);

         if (iRc < 0) {
           sprintf(g_caMsg,"ShmFac: ReadLock() error!");
           ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
           pstShmCtl->cShmReturnCode = TMS_SHM_ERR ;
           UCP_TRACE_END(SHM_READ_LOCK_ERR);
         }

         break;
   **** end Mark  ****/

    case TMS_SHM_RD_ONLY :
         iRc = ReadOnly(pcArg1,pcArg2);

         if (iRc < 0) {
           sprintf(g_caMsg,"ShmFac: ReadOnly() error!");
           ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
           pstShmCtl->cShmReturnCode = TMS_SHM_ERR ;
           UCP_TRACE_END(SHM_READ_ONLY_ERR);
         }

         break;

  /* Mark Miao 19990609 for tu995012 begin
    case TMS_SHM_WR_UNLOCK :
         iRc = WriteUnlock(pcArg1,pcArg2);

         if (iRc < 0) {
           sprintf(g_caMsg,"ShmFac: WriteUnlock() error!");
           ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
           pstShmCtl->cShmReturnCode = TMS_SHM_ERR ;
           UCP_TRACE_END(SHM_WR_UNLOCK_ERR);
         }

         break;

    case TMS_SHM_WR_ONLY :
         iRc = WriteOnly(pcArg1,pcArg2);

         if (iRc < 0) {
           sprintf(g_caMsg,"ShmFac: WriteOnly() error!");
           ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
           pstShmCtl->cShmReturnCode = TMS_SHM_ERR ;
           UCP_TRACE_END(SHM_WR_ONLY_ERR);
         }

         break;
   **** end Mark  ****/

    default :
      sprintf(g_caMsg,"ShmFac: invalid shmfac function code: %c!",
              pstShmCtl->cShmFunCode);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstShmCtl->cShmReturnCode = TMS_SHM_ERR ;
      UCP_TRACE_END(SHM_FUN_CODE_ERR);
  }

  UCP_TRACE_END(0);
}



/*
 *&N& ROUTINE NAME: CheckSegName()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                 DESCRIPTION
 *&A& ---------  ---------------------    -------------------------
 *&A&   pcArg1   char *                   ���VShmCtlSt.caSegName
 *&A&
 *&R& RETURN VALUE(S):
 *&R& CWA_SHM_ACIA_SEG_VAL: ��Segment Name�s�b, �B��CWA_ACIA_SEG
 *&R& CWA_SHM_LOG_SEG_VAL : ��Segment Name�s�b, �B��CWA_LOG_SEG
 *&R&   -1                : ��Segment Name���s�b
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& �P�_ Segment Name �O�_���w�q�C
 *&D&
 */
int
CheckSegName(char *pcArg1)
{
  int iRc;

  UCP_TRACE(P_CheckSegName);
  iRc = -1;

  if (0 == strncmp(pcArg1, CWA_SHM_LOG_SEG, 8)) {
     iRc = CWA_SHM_LOG_SEG_VAL;
  }
  else {
    if (0 == strncmp(pcArg1, CWA_SHM_ACIA_SEG, 8)) {
      iRc = CWA_SHM_ACIA_SEG_VAL;
    }
  }

  UCP_TRACE_END(iRc);
}

/*
 *&N& ROUTINE NAME: ReadLock()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE          DESCRIPTION
 *&A& ---------  ---------------    -------------------------
 *&A& pcArg1     char *             ���VTWA.COA�}�l��}(�sShmCtlSt���c)
 *&A& pcArg2     char *             ���VIO-AREA�}�l��}
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   LOCK_SSA_ERR      : lock CWA.SSA error
 *&R&   GET_SSA_PTR_ERR   : get CWA.SSA pointer error
 *&R&   LOCK_TCT_ERR      : lock CWA.TCT error
 *&R&   GET_TCT_PTR_ERR   : get CWA.TCT pointer error
 *&R&   UNLOCK_SSA_ERR    : unlock CWA.SSA error
 *&R&   SHM_SEG_NAME_ERR       : invalid segment name
 *&R&
 *&D& DESCRIPTION:
 *&D& struct ShmLogSt {
 *&D&   char caNextAvLogRrn[5] ;          PIC S9(8) COMP-3
 *&D&   char caTotalTxnCnt[4] ;           PIC S9(7) COMP-3
 *&D&   char caTctLastLogRecRrn[5] ;      PIC S9(8) COMP-3
 *&D& };
 *&D& Ū����ƨå[��C
 *&D&
 */
int
ReadLock(char *pcArg1,char *pcArg2)
{
  int iRc;
  struct ShmFacCtlSt *pstShmCtl;
  struct ShmLogSt    *pstShmLog;
  unsigned char   caTmpBuf[10];
  char *pcTerm;

  UCP_TRACE(P_ReadLock);
  pstShmCtl = (struct ShmFacCtlSt *)pcArg1;
  iRc = CheckSegName(pstShmCtl->caShmSegName);
  switch(iRc) {
    case CWA_SHM_LOG_SEG_VAL:
     /* 
      *  Lock & Attach CWA �� SSA
      */
      stCwaCtl.cFunCode = CWA_SEG_LOCK;
      stCwaCtl.cSegCode = CWA_SEG_SSA;
      iRc = CwaCtlFac( &stCwaCtl, &sg_pstSsa );

      if (iRc != CWA_NORMAL) {
        ErrLog(1000,"ShmFac: lock SSA fail!",RPT_TO_LOG,0,0);
        UCP_TRACE_END(LOCK_SSA_ERR);
      }

      stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
      stCwaCtl.cSegCode = CWA_SEG_SSA;
      iRc = CwaLowCtlFac( &stCwaCtl, &sg_pstSsa );

      if (iRc != CWA_NORMAL) {
        ErrLog(1000,"ShmFac: get SSA ptr fail!",RPT_TO_LOG,0,0);
        UCP_TRACE_END(GET_SSA_PTR_ERR);
      }

     /* 
      *  Lock & Attach CWA �� BIT
      */
      stCwaCtl.cFunCode = CWA_SEG_LOCK;
      stCwaCtl.cSegCode = CWA_SEG_BIT_BRH;
      iRc = CwaLowCtlFac( &stCwaCtl, &sg_pstTct );

      if (iRc != CWA_NORMAL) {
       /*
        * �ѩ� LOCK TCT ����, �]�������N���e�w�g LOCK �� SSA �� UNLOCK �ʧ@�C
        */
        stCwaCtl.cFunCode = CWA_SEG_UNLOCK;
        stCwaCtl.cSegCode = CWA_SEG_SSA;
        iRc = CwaCtlFac( &stCwaCtl, &sg_pstSsa );

        if (iRc != CWA_NORMAL) {
          ErrLog(1000,"ShmFac: unlock SSA fail!",RPT_TO_LOG,0,0);
          UCP_TRACE_END(UNLOCK_SSA_ERR);
        }

        ErrLog(1000,"ShmFac: lock TCT fail!",RPT_TO_LOG,0,0);
        UCP_TRACE_END(LOCK_TCT_ERR);
      }

      stCwaCtl.cFunCode = CWA_GET_TERM_PTR;
      memcpy(stCwaCtl.caBrhId, g_pstTma->stTSSA.caBrCode, g_iBrhCodeLen);
      memcpy(stCwaCtl.caTermId,g_pstTma->stTSSA.caTmCode, g_iTmCodeLen);
      iRc = CwaLowCtlFac( &stCwaCtl, &pcTerm );

      if (iRc != CWA_NORMAL) {
        ErrLog(1000,"ShmFac: get TCT ptr fail!",RPT_TO_LOG,0,0);
        UCP_TRACE_END(GET_TCT_PTR_ERR);
      }

      sg_pstTct = ( struct TermArea *) pcTerm;

      pstShmLog = (struct ShmLogSt *) pcArg2;
     /*
      *  Read NextAvLogRrn From CWA To AP
      */
      memset(caTmpBuf,0,10);
      sprintf(caTmpBuf,"%.*ld",8,sg_pstSsa->lNextAvLogRrn);
/*    modify by JessWu 95/03/02 */
/*
      memcpy(pstShmLog->caNextAvLogRrn,Comp3Conv(caTmpBuf),5);
*/
      memcpy(pstShmLog->caNextAvLogRrn,caTmpBuf,8);
      sprintf(g_caMsg,"ReadLock: SSA NextAvLogRrn=%s",caTmpBuf);
      ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

     /*
      *  Read LastLogRecRrn From CWA To AP
      */
      memset(caTmpBuf,0,10);
      sprintf(caTmpBuf,"%.*ld",8,sg_pstTct->lLastOnlnRrn);
/*    modify by JessWu 95/03/02 */
/*
      memcpy(pstShmLog->caTctLastLogRecRrn,Comp3Conv(caTmpBuf),4);
*/
      memcpy(pstShmLog->caTctLastLogRecRrn,caTmpBuf,8);
      sprintf(g_caMsg,"ReadLock: TCT LastLogRecRrn=%s",caTmpBuf);
      ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

     /*
      *  Read TotalTxnCnt From CWA To AP
      */
      memset(pstShmLog->caTctSeqNo,' ',2);
      break;

    default:
      sprintf(g_caMsg,"ShmFac: invalid segment name!");
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstShmCtl->cShmReturnCode = TMS_SHM_ERR;
      UCP_TRACE_END(SHM_SEG_NAME_ERR);
  }

  UCP_TRACE_END(0);
}

/*
 *&N& ROUTINE NAME: ReadOnly()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE          DESCRIPTION
 *&A& ---------  ---------------    -------------------------
 *&A& pcArg1     char *             ���VTWA.COA�}�l��}(�sShmCtlSt���c)
 *&A& pcArg2     char *             ���VIO-AREA�}�l��}
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   GET_SSA_PTR_ERR   : get CWA.SSA pointer error
 *&R&   GET_TCT_PTR_ERR   : get CWA.TCT pointer error
 *&R&   SHM_SEG_NAME_ERR       : invalid segment name
 *&R&
 *&D& DESCRIPTION:
 *&D& struct ShmLogSt {
 *&D&   char caNextAvLogRrn[5] ;          PIC S9(8) COMP-3
 *&D&   char caTotalTxnCnt[4] ;           PIC S9(7) COMP-3
 *&D&   char caTctLastLogRecRrn[5] ;      PIC S9(8) COMP-3
 *&D& };
 *&D& Ū����ơC
 *&D&
 */
int
ReadOnly(char *pcArg1,char *pcArg2)
{
  int iRc;
  struct ShmFacCtlSt *pstShmCtl;
  struct ShmLogSt    *pstShmLog;
  unsigned char   caTmpBuf[10];
  char *pcTerm;
  int  iLen;

  UCP_TRACE(P_ReadOnly);
  sprintf(g_caMsg,"ReadOnly:enter ReadOnly dump ShmFacCtlSt");
  ErrLog(100,g_caMsg,RPT_TO_LOG,pcArg1,sizeof(struct ShmFacCtlSt));
  pstShmCtl = (struct ShmFacCtlSt *)pcArg1;

  iRc = CheckSegName(pstShmCtl->caShmSegName);
  switch(iRc) {
    case CWA_SHM_LOG_SEG_VAL:
     /* 
      *  Attach CWA �� SSA
      */
      stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
      stCwaCtl.cSegCode = CWA_SEG_SSA;
      iRc = CwaLowCtlFac( &stCwaCtl, &sg_pstSsa );

      if (iRc != CWA_NORMAL) {
        ErrLog(1000,"ShmFac: get SSA ptr fail!",RPT_TO_LOG,0,0);
        UCP_TRACE_END(GET_SSA_PTR_ERR);
      }

     /* 
      *  Attach CWA �� TCT
      */
      stCwaCtl.cFunCode = CWA_GET_TERM_PTR;
      memcpy(stCwaCtl.caBrhId, g_pstTma->stTSSA.caBrCode, g_iBrhCodeLen);
      memcpy(stCwaCtl.caTermId,g_pstTma->stTSSA.caTmCode, g_iTmCodeLen);
      iRc = CwaLowCtlFac( &stCwaCtl, &pcTerm );

      if (iRc != CWA_NORMAL) {
        ErrLog(1000,"ShmFac: get TCT ptr fail!",RPT_TO_LOG,0,0);
        UCP_TRACE_END(GET_TCT_PTR_ERR);
      }

      sg_pstTct = ( struct TermArea *) pcTerm;

      pstShmLog = (struct ShmLogSt *) pcArg2;
     /*
      *  Read NextAvLogRrn From CWA To AP
      */
      memset(caTmpBuf,0,10);
      sprintf(caTmpBuf,"%.*ld",8,sg_pstSsa->lNextAvLogRrn);
/*    modify by JessWu 95/03/02 */
/*
      memcpy(pstShmLog->caNextAvLogRrn,Comp3Conv(caTmpBuf),4);
*/
      memcpy(pstShmLog->caNextAvLogRrn,caTmpBuf,8);
      sprintf(g_caMsg,"ReadLock: SSA NextAvLogRrn=%s",caTmpBuf);
      ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

     /*
      *  Read LastLogRecRrn From CWA To AP
      */
      memset(caTmpBuf,0,10);
      sprintf(caTmpBuf,"%.*ld",8,sg_pstTct->lLastOnlnRrn);
/*    modify by JessWu 95/03/02 */
/*
      memcpy(pstShmLog->caTctLastLogRecRrn,Comp3Conv(caTmpBuf),4);
*/
      memcpy(pstShmLog->caTctLastLogRecRrn,caTmpBuf,8);
      sprintf(g_caMsg,"ReadLock: TCT LastLogRecRrn=%s",caTmpBuf);
      ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

     /*
      *  Read TotalTxnCnt From CWA To AP
      */
      memset(pstShmLog->caTctSeqNo,' ',2);
      break;

    case CWA_SHM_ACIA_SEG_VAL:
     /* 
      *  Attach CWA �� ACIA
      */
      memset(caTmpBuf,0,10);
      memcpy(caTmpBuf,pstShmCtl->caDataLen,5);
      iLen = atoi(caTmpBuf);
      if ( iLen > MAX_ACIA_SIZE ) {
        UCP_TRACE_END( GET_ACIA_LEN_ERR );
      }

      sprintf(g_caMsg,"ReadOnly:enter case AciaSeg");
      ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
      stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
      stCwaCtl.cSegCode = CWA_SEG_ACI;
      iRc = CwaLowCtlFac( &stCwaCtl, &sg_pstAcia );

      if (iRc != CWA_NORMAL) {
        ErrLog(1000,"ShmFac: get ACIA ptr fail!",RPT_TO_LOG,0,0);
        UCP_TRACE_END(GET_ACIA_PTR_ERR);
      }

      /*memcpy( pcArg2, sg_pstAcia, sizeof(struct AciaInt) );*/
      memcpy( pcArg2, sg_pstAcia, iLen );
      sprintf(g_caMsg,"ReadOnly:exit case AciaSeg,dump sg_pstAcia");
      ErrLog(100,g_caMsg,RPT_TO_LOG,sg_pstAcia, iLen);
      break;

    default:
      sprintf(g_caMsg,"ShmFac: invalid segment name!");
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstShmCtl->cShmReturnCode = TMS_SHM_ERR;
      UCP_TRACE_END(SHM_SEG_NAME_ERR);
  }

  UCP_TRACE_END(0);
}








/*
 *&N& ROUTINE NAME: WriteUnlock()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE          DESCRIPTION
 *&A&   ---------  --------------   -------------------------
 *&A& pcArg1     char *             ���VTWA.COA�}�l��}(�sShmCtlSt���c)
 *&A& pcArg2     char *             ���VIO-AREA�}�l��}
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   UNLOCK_SSA_ERR      : unlock CWA.SSA error
 *&R&   UNLOCK_TCT_ERR      : unlock CWA.TCT error
 *&R&   SHM_SEG_NAME_ERR       : invalid segment name
 *&R&
 *&D& DESCRIPTION:
 *&D& struct ShmLogSt {
 *&D&   char caNextAvLogRrn[5] ;        PIC S9(7)  COMP-3
 *&D&   char caTotalTxnCnt[4] ;         PIC S9(7)  COMP-3
 *&D&   char caTctLastLogRecRrn[5] ;    PIC S9(7)  COMP-3
 *&D& };
 *&D& �g�^��ƨø���C
 *&D&
 */


int
WriteUnlock(char *pcArg1,char *pcArg2)
{
  int iRc;
  struct ShmFacCtlSt *pstShmCtl;
  struct ShmLogSt    *pstShmLog;
  char   *pcUnpackData;
  char   caTmpBuf[10];

  UCP_TRACE(P_WriteUnlock);
  pstShmCtl = (struct ShmFacCtlSt *)pcArg1;
  iRc = CheckSegName( pstShmCtl->caShmSegName );

  switch( iRc ) {
    case CWA_SHM_LOG_SEG_VAL:
     /*
      *  Write NextAvLogRrn From AP To CWA
      */
      pstShmLog = (struct ShmLogSt *) pcArg2;
/*    modify by JessWu 95/03/02 */
/*
      pcUnpackData = UnpackData( pstShmLog->caNextAvLogRrn, 9 );
      sprintf(caTmpBuf,"%.9s",pcUnpackData);
      sg_pstSsa->lNextAvLogRrn = atol( caTmpBuf );
      sprintf(g_caMsg,"WriteUnlock: SSA NextAvLogRrn(unpack)=%s",caTmpBuf);
      ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
*/
      memset(caTmpBuf, 0, 10);
      memcpy(caTmpBuf, pstShmLog->caNextAvLogRrn, 8);
      sg_pstSsa->lNextAvLogRrn = atol( caTmpBuf );

     /*
      *  Write TctLastLogRecRrn From AP To CWA
      */
/*    modify by JessWu 95/03/02 */
/*
      pcUnpackData = UnpackData( pstShmLog->caTctLastLogRecRrn, 9 );
      sprintf(caTmpBuf,"%.9s",pcUnpackData);
      sg_pstTct->lLastOnlnRrn = atol( caTmpBuf );
      sprintf(g_caMsg,"WriteUnlock: TCT LastLogRecRrn(unpack)=%s",caTmpBuf);
      ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
*/
      memset(caTmpBuf, 0, 10);
      memcpy(caTmpBuf, pstShmLog->caTctLastLogRecRrn, 8);
      sg_pstTct->lLastOnlnRrn = atol( caTmpBuf );

     /*
      *  Write TotalTxnCnt From AP To CWA
      */
/* mark by JessWu 1995/03/02 */
/*
      pcUnpackData = UnpackData( pstShmLog->caTotalTxnCnt, 7 );
      sprintf(caTmpBuf,"%.7s",pcUnpackData);
      sg_pstSsa->lTotalTxnCnt = atol( caTmpBuf );
      sprintf(g_caMsg,"WriteUnlock: SSA TotalTxnCnt (unpack)=%s",caTmpBuf);
      ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
*/

     /*
      *  Unlock CWA �� SSA
      */
      stCwaCtl.cFunCode = CWA_SEG_UNLOCK;
      stCwaCtl.cSegCode = CWA_SEG_SSA;
      iRc = CwaCtlFac( &stCwaCtl, &sg_pstSsa );

      if (iRc != CWA_NORMAL) {
        ErrLog(1000,"ShmFac: unlock SSA fail!",RPT_TO_LOG,0,0);
        UCP_TRACE_END(UNLOCK_SSA_ERR);
      }

     /*
      *  Unlock CWA �� TCT
      */
      stCwaCtl.cFunCode = CWA_SEG_UNLOCK;
      stCwaCtl.cSegCode = CWA_SEG_BIT_BRH;
      iRc = CwaLowCtlFac( &stCwaCtl, &sg_pstTct );

      if (iRc != CWA_NORMAL) {
        ErrLog(1000,"ShmFac: unlock TCT fail!",RPT_TO_LOG,0,0);
        UCP_TRACE_END(UNLOCK_TCT_ERR);
      }

      break;

    default:
      sprintf(g_caMsg,"ShmFac: invalid segment name!");
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstShmCtl->cShmReturnCode = TMS_SHM_ERR;
      UCP_TRACE_END(SHM_SEG_NAME_ERR);
  }

  UCP_TRACE_END(0);
}

/*
 *&N& ROUTINE NAME: WriteOnly()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE          DESCRIPTION
 *&A&   ---------  --------------   -------------------------
 *&A& pcArg1     char *             ���VTWA.COA�}�l��}(�sShmCtlSt���c)
 *&A& pcArg2     char *             ���VIO-AREA�}�l��}
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   SHM_SEG_NAME_ERR       : invalid segment name
 *&R&
 *&D& DESCRIPTION:
 *&D& struct ShmLogSt {
 *&D&   char caNextAvLogRrn[5] ;        PIC S9(7)  COMP-3
 *&D&   char caTotalTxnCnt[4] ;         PIC S9(7)  COMP-3
 *&D&   char caTctLastLogRecRrn[5] ;    PIC S9(7)  COMP-3
 *&D& };
 *&D& �g�^��ơC
 *&D&
 */
int
WriteOnly(char *pcArg1,char *pcArg2)
{
  int iRc;
  struct ShmFacCtlSt *pstShmCtl;
  struct ShmLogSt    *pstShmLog;
  char   *pcUnpackData;
  char   caTmpBuf[10];

  UCP_TRACE(P_WriteOnly);
  pstShmCtl = (struct ShmFacCtlSt *)pcArg1;
  iRc = CheckSegName( pstShmCtl->caShmSegName );

  switch( iRc ) {
    case CWA_SHM_LOG_SEG_VAL:
     /*
      *  Write NextAvLogRrn From AP To CWA
      */
      pstShmLog = (struct ShmLogSt *) pcArg2;
/*    modify by JessWu 95/03/02 */
/*
      pcUnpackData = UnpackData( pstShmLog->caNextAvLogRrn, 9 );
      sprintf(caTmpBuf,"%.9s",pcUnpackData);
      sg_pstSsa->lNextAvLogRrn = atol( caTmpBuf );
      sprintf(g_caMsg,"WriteUnlock: SSA NextAvLogRrn(unpack)=%s",caTmpBuf);
      ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
*/
      memset(caTmpBuf, 0, 10);
      memcpy(caTmpBuf, pstShmLog->caNextAvLogRrn, 8);
      sg_pstSsa->lNextAvLogRrn = atol( caTmpBuf );

     /*
      *  Write TctLastLogRecRrn From AP To CWA
      */
/*    modify by JessWu 95/03/02 */
/*
      pcUnpackData = UnpackData( pstShmLog->caTctLastLogRecRrn, 9 );
      sprintf(caTmpBuf,"%.9s",pcUnpackData);
      sg_pstTct->lLastOnlnRrn = atol( caTmpBuf );
      sprintf(g_caMsg,"WriteUnlock: TCT LastLogRecRrn(unpack)=%s",caTmpBuf);
      ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
*/
      memset(caTmpBuf, 0, 10);
      memcpy(caTmpBuf, pstShmLog->caTctLastLogRecRrn, 8);
      sg_pstTct->lLastOnlnRrn = atol( caTmpBuf );

     /*
      *  Write TotalTxnCnt From AP To CWA
      */
/* mark by JessWu 1995/03/02 */
/*
      pcUnpackData = UnpackData( pstShmLog->caTotalTxnCnt, 7 );
      sprintf(caTmpBuf,"%.7s",pcUnpackData);
      sg_pstSsa->lTotalTxnCnt = atol( caTmpBuf );
      sprintf(g_caMsg,"WriteUnlock: SSA TotalTxnCnt (unpack)=%s",caTmpBuf);
      ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
*/

    default:
      sprintf(g_caMsg,"ShmFac: invalid segment name!");
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstShmCtl->cShmReturnCode = TMS_SHM_ERR;
      UCP_TRACE_END(SHM_SEG_NAME_ERR);
  }

  UCP_TRACE_END(0);
}


/*
 *&N& ROUTINE NAME: GetEjRrn()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE       DESCRIPTION
 *&A&   ---------  -----------   ---------------------------------------
 *&A&   pcArg1     char *        APA
 *&A&   pcArg2     char *        pointer to struct GetSeqSt
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 */
#define		MAX_EJ_RRN_SIZE		7
int
GetEjRrn(struct GetSeqSt *pstGetSeq)
{
   int iRc;
   char caTmpBuf[10];

   UCP_TRACE(P_GetEjRrn);
  /* 
   *  Lock & Attach CWA �� SSA
   */
   stCwaCtl.cFunCode = CWA_SEG_LOCK;
   stCwaCtl.cSegCode = CWA_SEG_SSA;
   iRc = CwaCtlFac( &stCwaCtl, &sg_pstSsa );

   if (iRc != CWA_NORMAL) {
     ErrLog(1000,"GetEjRrn: lock SSA fail!",RPT_TO_LOG,0,0);
     pstGetSeq->cGetSeqRtnCode = TMS_GTSEQ_LOCK_SSA_ERROR;
     UCP_TRACE_END( -1 );
   }

   stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
   stCwaCtl.cSegCode = CWA_SEG_SSA;
   iRc = CwaLowCtlFac( &stCwaCtl, &sg_pstSsa );

   if (iRc != CWA_NORMAL) {
     ErrLog(1000,"GetEjRrn: get SSA ptr fail!",RPT_TO_LOG,0,0);

/*begin: add by pjw for TU995002          1999 6 10 begin*/
     stCwaCtl.cFunCode = CWA_SEG_UNLOCK;
     stCwaCtl.cSegCode = CWA_SEG_SSA;
     iRc = CwaCtlFac( &stCwaCtl, &sg_pstSsa );

     if (iRc != CWA_NORMAL) {
        ErrLog(1000,"ShmFac: unlock SSA fail!",RPT_TO_LOG,0,0);
        pstGetSeq->cGetSeqRtnCode = TMS_GTSEQ_UNLOCK_SSA_ERROR;
        UCP_TRACE_END( -1 );
     }
/*end: add by pjw for TU995002 unlock cwa on 1999 6 10 */

     pstGetSeq->cGetSeqRtnCode = TMS_GTSEQ_ERROR;
     UCP_TRACE_END( -1 );
   }

   memset(caTmpBuf,0,10);
   sprintf(caTmpBuf,"%.*ld",MAX_EJ_RRN_SIZE,sg_pstSsa->lNextAvLogRrn) ;
   memcpy(pstGetSeq->caEjRrn,caTmpBuf,MAX_EJ_RRN_SIZE);
   sg_pstSsa->lNextAvLogRrn++ ;

  /*
   *  Unlock CWA �� SSA
   */
   stCwaCtl.cFunCode = CWA_SEG_UNLOCK;
   stCwaCtl.cSegCode = CWA_SEG_SSA;
   iRc = CwaCtlFac( &stCwaCtl, &sg_pstSsa );

   if (iRc != CWA_NORMAL) {
     ErrLog(1000,"ShmFac: unlock SSA fail!",RPT_TO_LOG,0,0);
     pstGetSeq->cGetSeqRtnCode = TMS_GTSEQ_UNLOCK_SSA_ERROR;
     UCP_TRACE_END( -1 );
   }

   UCP_TRACE_END( 0 );
}
