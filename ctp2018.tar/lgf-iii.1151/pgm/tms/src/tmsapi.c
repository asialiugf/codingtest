
/*
 *&D&                   API           ��ƷJ�`
 *&D&------------------------------------------------------------------------
 *&D& 1  void     TPEWRITE            �NAP�e�X�����,�Ȧs���ɭ�
 *&D& 2  void     TPESDOUT            �NAP�e�X�����,���W�e�X���ɭ�
 *&D& 3  void     TPETXLOG            AP�z�L���ɭ��gLOG
 *&D& 4  void     TPEAPRQT            AP�z�L���ɭ��I�s�`�ǳs�ʡB�_���s��
 *&D& 5  void     TPESCRQT            �e���s�� 
 *&D& 6  void     TPGIOHDL            �妸�B�z�e������ 
 *&D& 7  void     TPFRPT              �妸�B�z��ƿ�X
 *&D& 8  void     TPFDBS              ��ƮwDBS�ɭ� 
 *&D& 9  void     TPFFCS              ��ƮwFCS�ɭ� 
 *&D& 10 void     TPEDCS              �����A�Ȭɭ�
 *&D& 11 void     TPESDCLT            �NAP�e�X�����,�ǰe������D��
 *&D& 12 void     TPFLOGOP            AP�z�L���ɭ�Ū�gLOG          
 *&D& 13 void     TPFCWARW            AP�z�L���ɭ�Ū�gCWA          
 *&D& 14 void     TPERVSOP            AP�z�L���ɭ�Ū�gLOG          
 *&D& 15 void     TPEGPREV            AP�z�L���ɭ�Ū���e�@��LOG          
 *&D& 16 void     TPFGTSEQ          
 *&D& 17 void     TPFADSEQ         
 *&D& 18 void     TPFRKSEQ        
 *&D& 19 void     TPEONBTH        
 *&D& 20 void     TPFSETLN        
 *&D& 21 void     TPEGTSIF        
*/

/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include "twa.h"
#include "errlog.h"
#include "tms.h"
#include "dcs.h"
#include "tmcinedt.h"
#include "ucp.h"
#include "tmcpgdef.h"	/* TMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */
#include "fcstwa.h"
#include "lgcopewa.h"	

#define MSGP_DATA		'm'
#define POST_DATA		'p'
#define PRNT_DATA		'r'
#define SIF_DATA		's'
#define APRQT_DATA_LEN    	 4
#define AP_MSG_DATA_LEN_SIZE   	 4
#define ONBTH_DATA_LEN_SIZE      4
#define AP_MSG_HEAD_LEN   	10
#define SbDbs              sbdbs
#define SbFcs              sbfcs

/* ------------------- global variable ------------------------------ */
extern struct TMA *g_pstTma;
extern struct TBA *g_pstTba;
extern int g_iTxnCodeLen;       /* Txn code real length          */
extern int g_iTmCodeLen;        /* Term code real length         */
extern int g_iBrhCodeLen;       /* Branch code real length       */
extern int g_iTotLogCntPerTxn;  /* tot log rec. cnt of per txn   */
extern int g_iSifLen;    /* record the length of SIF,modify by Jess 19950128*/
char       g_cLastQryFlag;
char       g_cRqtApiBeenCalled; /* Added by Willy 1996/10/18 */
int g_iSeqTxnSifLen;

/* *********************************************************** */
/* g_caMemBuf contain MemBufCtl MSGP + REINPUT SIF + remote reverse txn SIF + 
   POST + SOF_HEAD_LEN_PLUS_2*2 (for control) + g_stHostToBrhInfo(100 bytes) */
extern char g_caMemBuf[MAX_MSGP_LEN * 2];
extern char g_caReinputBuffer[MAX_SIF_LEN + SOF_HEAD_LEN_PLUS_2];
struct  MemBufCtlSt{
  int iMsgCnt;
  int iNextOffset;
};
extern struct  MemBufCtlSt g_stMemBufCtl;
/* TCC: For compatiability with Tandem */
int FetchNextSof(unsigned char *pcaSofBuf,int *piSofLen,char cFirstFlag);

TPEWRITE(char *pcArg0, char *pcArg1)
/* pcArg0 ---> APA
   pcArg1 ---> WriteSt   */
{
  int iRc;
  char caDataLen[10];
  int iDataLen;
  struct WriteSt *pstWrite;

  UCP_TRACE(P_TPEWRITE);

  pstWrite = (struct WriteSt *) pcArg1;

  memset(caDataLen, 0, 10);
  memcpy(caDataLen, pstWrite->stWriteData.caDataLen, AP_MSG_DATA_LEN_SIZE);
  iDataLen = atoi( caDataLen );

  /* -----------------  check  output  msg.  length   -------------- */
  if ( iDataLen > 2000 ) {
    sprintf( g_caMsg,"<tmsapi> TPEWRITE data len overflow! %.4s --> %d",
             pstWrite->stWriteData.caDataLen, iDataLen);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstWrite->cWriteRtnCode = TMS_MSGP_LEN_ERR;
    UCP_TRACE_END( -1 );
  }

  iDataLen += AP_MSG_HEAD_LEN;

  ErrLog(100,"<APD>###tmsapi### enter TPEWRITE, dump MSGP=",
         RPT_TO_LOG,pcArg1, iDataLen);

  /* marked to support multiple error messages
   */
  /*
  if ( g_pstTma->stTCFA.cTpeWriteMsgKind == TMS_RCV_AP_MXXX_MSG ) {
    pstWrite->cWriteRtnCode = TMS_MSGP_PARA_ERR;
    UCP_TRACE_END( -1 );
  }
  */

  /* only T-form type can be EJ data, other types be rejected */
  if(pstWrite->stWriteData.cOutDevType == '1'){
    if(pstWrite->stWriteData.cMsgType != 'T') {
      ErrLog(1000,"EJ need a TXXX to write",RPT_TO_LOG,0,0);
      pstWrite->cWriteRtnCode=TMS_MSGP_PARA_ERR;
      UCP_TRACE_END(0);
    }
  }

  iRc = OutptSel(MSGP_DATA,&pstWrite->stWriteData,g_pstTma->stTSSA.caBrCode,
                 g_pstTma->stTSSA.caTmCode);

  if ( iRc == 0 ) {
    pstWrite->cWriteRtnCode = TMS_MSGP_NORMAL;
  }
  else {
    if (iRc == -77) { /* issue normal msg after MXXX */
      pstWrite->cWriteRtnCode = TMS_MSGP_PARA_ERR;
      UCP_TRACE_END( -1 );
    }
    pstWrite->cWriteRtnCode = TMS_MSGP_SYS_ERR;
  }

  ErrLog(100,"<APD>###tmsapi### exit TPEWRITE, dump MSGP-RETURN-CODE=",
         RPT_TO_LOG,pstWrite,1);

  UCP_TRACE_END(0);
}


TPESDOUT(char *pcArg0, char *pcArg1)
/* pcArg0 ---> APA
   pcArg2 ---> SdoutSt    */
{
  int iRc;
  char caDataLen[10];
  int iDataLen;
  struct SdoutSt *pstSdout;

  UCP_TRACE(P_TPESDOUT);
  pstSdout = (struct SdoutSt *) pcArg1;
  /* ----- check out device defined or undefined ---------------- */
  /* ----- Mark for hwa-chi 1994/10/21 
 */
/*if ( pstSdout->stSdoutData.cOutDevType != '1' && --> by TPEUNIX975005*/

  if ( pstSdout->stSdoutData.cOutDevType != '*' &&
       pstSdout->stSdoutData.cOutDevType != '2' &&
       pstSdout->stSdoutData.cOutDevType != '6' ) {
    sprintf( g_caMsg,"<tmsapi> TPESDOUT invalid out device! %c",
             pstSdout->stSdoutData.cOutDevType);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstSdout->cSdoutRtnCode = TMS_MSGP_DEV_ERR;
    UCP_TRACE_END( -1 );
  }

  memset(caDataLen, 0, 10);
  memcpy(caDataLen, pstSdout->stSdoutData.caDataLen, AP_MSG_DATA_LEN_SIZE);
  iDataLen = atoi( caDataLen );

/* -----------------  check  output  msg.  length   -------------- */
/*  if ( iDataLen > 5000 ) {  ----> modified by TPEUNIX960103 */
  if ( iDataLen > 2000 ) {
    sprintf( g_caMsg,"<tmsapi> TPESDOUT data len overflow! %.4s --> %d",
             pstSdout->stSdoutData.caDataLen, iDataLen);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstSdout->cSdoutRtnCode = TMS_MSGP_LEN_ERR;
    UCP_TRACE_END( -1 );
  }

  iDataLen += AP_MSG_HEAD_LEN;

  ErrLog(100,"<APD>###tmsapi### enter TPESDOUT, dump MSGP=",
         RPT_TO_LOG,pcArg1, iDataLen);

  iRc = OutptSel(PRNT_DATA,&pstSdout->stSdoutData,g_pstTma->stTSSA.caBrCode,
                 g_pstTma->stTSSA.caTmCode);

  if ( iRc == 0 ) {
    pstSdout->cSdoutRtnCode = TMS_MSGP_NORMAL;
  }
  else {
    pstSdout->cSdoutRtnCode = TMS_MSGP_PARA_ERR;
  }

  ErrLog(100,"<APD>###tmsapi### exit TPESDOUT, dump MSGP-RETURN-CODE=",
         RPT_TO_LOG,pstSdout,1);

  UCP_TRACE_END(0);
}


TPETXLOG(char *pcArg0,char *pcArg1)
/*  pcArg0 -->  APA
    pcArg1 -->  log data structure  */
{
  struct LogSt *pstLog;
  char caLogRrnBuf[10];
  int iRc ;

  UCP_TRACE(P_TPETXLOG);

  pstLog = (struct LogSt *) pcArg1;

  ErrLog(100,"<APD>###tmsapi### enter TPETXLOG, dump LOGP=",
         RPT_TO_LOG,pcArg1,sizeof(struct LogSt));

  if ( g_iTotLogCntPerTxn > 10 ) {
    pstLog->cLogReturnCode = TMS_TXLOG_ERROR;
    UCP_TRACE_END(-1);
  }

  iRc=UcpTxnLg(AP_WRT_LOG,pcArg0,caLogRrnBuf,pstLog->caLogData,g_pstTba->caSif,
               g_iSifLen);

  memcpy(pstLog->caLogReturnRrn,caLogRrnBuf,LG_RRN_SIZE);
/*
  ErrLog(100,"<tmsapi> TPETXLOG LOG RRN=",RPT_TO_LOG,
         pstLog->caLogReturnRrn,LG_RRN_SIZE);
*/
  if ( iRc < 0 ) {
    pstLog->cLogReturnCode = TMS_TXLOG_ERROR;
  }
  else {
    pstLog->cLogReturnCode = TMS_TXLOG_NORMAL;
    g_pstTma->stTCFA.cApWriteLogFlag  = TMS_AP_HAS_BEEN_WRT_LOG;
  }

  if ( iRc == 0 ) {
    g_iTotLogCntPerTxn++;
  }
   
  ErrLog(100,"<APD>###tmsapi### exit TPETXLOG, dump LOGP=",
         RPT_TO_LOG,pstLog,9);

  UCP_TRACE_END(0);
}



TPEAPRQT(char *pcArg0, char *pcArg1, char *pcArg2)
/* pcArg0 ---> APA
   pcArg1 ---> control part "ApRqtCtlSt"
   pcArg2 ---> data part                 */
{
  int iRc;
  char caDataLen[ 10 ];
  int  iDataLen;
  char caSifHead[ SIF_HEAD_LEN ];
  struct ApRqtCtlSt *pstApRqt;
  char caTxnCode[10];
  txn_head stTxnDesc;   /* transaction characteristic description  */
  int iTxnCtfLen;

  UCP_TRACE(P_TPEAPRQT);

  ErrLog(100,"<APD>###tmsapi### enter TPEAPRQT, dump RQTP-CTL=",
         RPT_TO_LOG,pcArg1,sizeof(struct ApRqtCtlSt));

  pstApRqt = (struct ApRqtCtlSt *) pcArg1;

  if ( pstApRqt->cFunCode != '1' && pstApRqt->cFunCode != '2' ) {
    sprintf( g_caMsg,"<tmsapi> TPEAPRQT: invalid cfuncode! %c",
             pstApRqt->cFunCode);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstApRqt->cReturnCode = TMS_APRQT_PARA_ERR;
    UCP_TRACE_END( -1 );
  }

/* To avoid calling APRQT or SCRQT twice in one AP flow 19961018 - Begin */
  if (g_cRqtApiBeenCalled == FUN_APRQT)
  {
    pstApRqt->cReturnCode = TMS_APRQT_TWICE_ERR;
    sprintf(g_caMsg,
           "<tmsapi> TPEAPRQT: can't be called twice in single AP flow!");
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END( -1 );
  }
  else if (g_cRqtApiBeenCalled == FUN_REINPUT)
  {
    pstApRqt->cReturnCode = TMS_APRQT_EXCLUDE_ERR;
    sprintf(g_caMsg,
           "<tmsapi> TPEAPRQT: can't be called together with TPESCRQT in single AP flow!");
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END( -1 );
  }
/* To avoid calling APRQT or SCRQT twice in one AP flow 19961018 - End */

  if ( g_pstTma->stTCFA.cRevTxn == TMS_TXN_REVERSE ) {
    pstApRqt->cReturnCode = TMS_APRQT_CALL_SEQ_ERR;
    UCP_TRACE_END( -1 );
  }
  pstApRqt->cReturnCode = TMS_APRQT_NORMAL;

  memset(caTxnCode, 0, 10);
  memcpy(caTxnCode, pstApRqt->caTxnCode, g_iTxnCodeLen);
  iRc = ReadIet( TXN_DESC, RANDOM_READ, caTxnCode, (char *)&stTxnDesc );
  if ( iRc < 0 ) {
    sprintf( g_caMsg,"<tmsapi> TPEAPRQT: invalid txn. code! %.4s",
             pstApRqt->caTxnCode);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstApRqt->cReturnCode = TMS_APRQT_TXNCODE_ERR;
    UCP_TRACE_END( -1 );
  }

/* Avoid to rendo a remote txn when system role is branch 19960916 -begin */
  if (g_pstTma->stTSSA.cSystemRole == BRANCH_HOST) {
    if (stTxnDesc.charc == '3' || stTxnDesc.charc == '8') {
      sprintf( g_caMsg,"<tmsapi> TPEAPRQT: invalid rendoed txn! rendoed txn code=%.4s, type=%c, systemRole=%c", pstApRqt->caTxnCode, stTxnDesc.charc, g_pstTma->stTSSA.cSystemRole);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstApRqt->cReturnCode = TMS_APRQT_TXNTYPE_ERR;
      UCP_TRACE_END( -1 );
    }
  }
/* Avoid to rendo a remote txn when system role is branch 19960916 -end */

  memset( caDataLen, 0, 10);
  memcpy( caDataLen, pstApRqt->caDataLen, APRQT_DATA_LEN);
  iDataLen = atoi( caDataLen );

  ErrLog(100,"<APD>###tmsapi### enter TPEAPRQT, dump RQTP-DATA=",
         RPT_TO_LOG,pcArg2,iDataLen);

  if ( iDataLen > MAX_SIF_LEN ) {
    sprintf( g_caMsg,"<tmsapi> TPEAPRQT: invalid data length! %d",
             iDataLen);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstApRqt->cReturnCode = TMS_APRQT_PARA_ERR;
    UCP_TRACE_END( -1 );
  }

  if (pstApRqt->cFmtCode == FMT_2) {
    iTxnCtfLen=CountTxnCtfLen(pstApRqt->caTxnCode);
    if((iTxnCtfLen < 0) || (iDataLen < iTxnCtfLen)) {
      sprintf( g_caMsg,"<tmsapi> TPEAPRQT invalid data length=%d < txn ctf total len=%d", iDataLen,iTxnCtfLen);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstApRqt->cReturnCode = TMS_APRQT_PARA_ERR;
      ErrLog(100,"<APD>###tmsapi### exit TPEAPRQT, dump RQTP-CTL=",
             RPT_TO_LOG,pcArg1,sizeof(struct ApRqtCtlSt));
      UCP_TRACE_END( -1 );
    }
  }
  
  switch(pstApRqt->cFunCode) {

    case TMS_SEQ_RENDO:

      switch( pstApRqt->cFmtCode ) {
        case FMT_1:
          iRc = ApDataToSif(pstApRqt, pcArg2, g_pstTba->caRendo);
          if ( iRc < 0 ) {
            pstApRqt->cReturnCode = TMS_APRQT_PARA_ERR;
            sprintf( g_caMsg, "<tmsapi> TPEAPRQT: ApDataToSif() error! %d",iRc);
            ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
            ErrLog(100,"<APD>###tmsapi### exit TPEAPRQT, dump RQTP-CTL=",
                   RPT_TO_LOG,pcArg1,sizeof(struct ApRqtCtlSt));
            UCP_TRACE_END( -1 );
          }    
          break;

        case FMT_2:
          iRc = CtfToSif(PART_CTF_TYPE,pstApRqt->caTxnCode, 
                                                  pcArg2, g_pstTba->caRendo);
          if ( iRc < 0 ) {
            pstApRqt->cReturnCode = TMS_APRQT_CNV_ERR;
            sprintf( g_caMsg, "<tmsapi> TPEAPRQT CtfToSif error! %d",iRc);
            ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
            ErrLog(100,"<APD>###tmsapi### exit TPEAPRQT, dump RQTP-CTL=",
                   RPT_TO_LOG,pcArg1,sizeof(struct ApRqtCtlSt));
            UCP_TRACE_END( -1 );
          }
          break;

        case FMT_CTF:
          iRc = CtfToSif(CTF_TYPE,pstApRqt->caTxnCode,pcArg2,g_pstTba->caRendo);
          if ( iRc < 0 ) {
            sprintf( g_caMsg, "<tmsapi> TPEAPRQT CtfToSif error! %d",iRc);
            ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
            pstApRqt->cReturnCode = TMS_APRQT_CNV_ERR;
            UCP_TRACE_END( -1 );/*added by WuChihLiang 19960706 */
          }
          break;

        default:
          sprintf( g_caMsg, "<tmsapi> TPEAPRQT cFmtCode error! %c",
                   pstApRqt->cFmtCode );
          ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
          pstApRqt->cReturnCode = TMS_APRQT_PARA_ERR;
          ErrLog(100,"<APD>###tmsapi### exit TPEAPRQT, dump RQTP-CTL=",
                 RPT_TO_LOG,pcArg1,sizeof(struct ApRqtCtlSt));
          UCP_TRACE_END ( -1 );
      }

      /*g_iSifLen = iRc;*/ /* keep new SIF len */
      g_iSeqTxnSifLen = iRc;
      memcpy(&caSifHead[TXN_CODE_OFFSET], pstApRqt->caTxnCode, g_iTxnCodeLen);
      memcpy( &caSifHead[ BR_CODE_OFFSET ], g_pstTma->stTSSA.caBrCode, 
              g_iBrhCodeLen);
      memcpy( &caSifHead[ TM_CODE_OFFSET ], g_pstTma->stTSSA.caTmCode, 
              g_iTmCodeLen);
      memcpy( &caSifHead[ TELLER_CODE_OFFSET ], g_pstTma->stTSSA.caTellId, 
              TELLER_CODE_LEN);
      memcpy(&caSifHead[ CTL_BYTE_OFFSET ], "\x00\x00", CTL_BYTE_LEN);
      memcpy( g_pstTba->caRendo, caSifHead, SIF_HEAD_LEN );
      memcpy( g_pstTba->caRendo, SIF_FMT_1, SIF_FMT_LEN);
      g_pstTma->stTCFA.cRendoRequest = TMS_TXN_RENDO;
      break;

    case TMS_NEST_RENDO:

      pstApRqt->cReturnCode = TMS_APRQT_PARA_ERR;
      ErrLog(100,"<APD>###tmsapi### exit TPEAPRQT, dump RQTP-CTL=",
             RPT_TO_LOG,pcArg1,sizeof(struct ApRqtCtlSt));
      UCP_TRACE_END ( -1 );

    default:
      sprintf( g_caMsg, "<tmsapi> TPEAPRQT cFunCode error! %c",
               pstApRqt->cFunCode );
      ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
      pstApRqt->cReturnCode = TMS_APRQT_PARA_ERR;
      ErrLog(100,"<APD>###tmsapi### exit TPEAPRQT, dump RQTP-CTL=",
             RPT_TO_LOG,pcArg1,sizeof(struct ApRqtCtlSt));
      UCP_TRACE_END ( -1 );
  }
  
/* To avoid calling APRQT or SCRQT twice in one AP flow 19961018 - Begin */
      g_cRqtApiBeenCalled = FUN_APRQT;
/* To avoid calling APRQT or SCRQT twice in one AP flow 19961018 - End */

  ErrLog(100,"<APD>###tmsapi### exit TPEAPRQT, dump RQTP-CTL=",
         RPT_TO_LOG,pcArg1,sizeof(struct ApRqtCtlSt));

  UCP_TRACE_END ( 0 );
}



TPESCRQT(char *pcArg0, char *pcArg1, char *pcArg2)
/* pcArg0 ---> APA
   pcArg1 ---> control part "ReinputCtlSt"
   pcArg2 ---> data part                 */
{
  int iRc;
  char caDataLen[10];
  int iDataLen;
  struct ReinputCtlSt *pstReinput;
  char caTxnCode[10];
  txn_head stTxnDesc;   /* transaction characteristic description  */
  int iTxnCtfLen;

  UCP_TRACE(P_TPESCRQT);

  ErrLog(100,"<APD>###tmsapi### enter TPESCRQT, dump RQTP-CTL=",
         RPT_TO_LOG,pcArg1,sizeof(struct ReinputCtlSt));

  pstReinput = (struct ReinputCtlSt *) pcArg1;

/* To avoid calling APRQT or SCRQT twice in one AP flow 19961018 - Begin */
  if (g_cRqtApiBeenCalled == FUN_APRQT)
  {
    pstReinput->cReturnCode = TMS_REINPUT_EXCLUDE_ERR;
    sprintf(g_caMsg,"<tmsapi> TPESCRQT: can't be called together with TPEAPRQT in one AP flow!");
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END( -1 );
  }
  else if (g_cRqtApiBeenCalled == FUN_REINPUT)
  {
    pstReinput->cReturnCode = TMS_REINPUT_TWICE_ERR;
    sprintf(g_caMsg,
           "<tmsapi> TPESCRQT: can't be called twice in single AP flow!");
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END( -1 );
  }
/* To avoid calling APRQT or SCRQT twice in one AP flow 19961018 - End */

  pstReinput->cReturnCode = TMS_REINPUT_NORMAL;

  if( pstReinput->cFunCode != '1' ) {
    sprintf( g_caMsg,"<tmsapi> TPESCRQT invalid cfuncode! %c",
             pstReinput->cFunCode);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstReinput->cReturnCode = TMS_REINPUT_PARA_ERR;
    ErrLog(100,"<APD>###tmsapi### exit TPESCRQT, dump RQTP-CTL=",
           RPT_TO_LOG,pcArg1,sizeof(struct ReinputCtlSt));
    UCP_TRACE_END( -1 );
  }

  memset(caTxnCode, 0, 10);
  memcpy(caTxnCode, pstReinput->caTxnCode, g_iTxnCodeLen);
  iRc = ReadIet( TXN_DESC, RANDOM_READ, caTxnCode, (char *)&stTxnDesc );
  if ( iRc < 0 ) {
    sprintf( g_caMsg,"<tmsapi> TPESCRQT: invalid txn. code! %.4s",
             pstReinput->caTxnCode);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstReinput->cReturnCode = TMS_REINPUT_TXNCODE_ERR;
    UCP_TRACE_END( -1 );
  }

  memset( caDataLen, 0, 10);
  memcpy( caDataLen, pstReinput->caDataLen, APRQT_DATA_LEN);
  iDataLen = atoi( caDataLen );

  if( iDataLen > MAX_SIF_LEN ) {
    sprintf( g_caMsg,"<tmsapi> TPESCRQT invalid data length! %d",
             iDataLen);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstReinput->cReturnCode = TMS_REINPUT_PARA_ERR;
    UCP_TRACE_END( -1 );
  }

  ErrLog(100,"<APD>###tmsapi### enter TPESCRQT, dump RQTP-DATA=",
         RPT_TO_LOG,pcArg2,iDataLen);

  if (pstReinput->cFmtCode == FMT_2) {
    iTxnCtfLen=CountTxnCtfLen(pstReinput->caTxnCode);
    if((iTxnCtfLen < 0) || (iDataLen < iTxnCtfLen)) {
      sprintf( g_caMsg,"<tmsapi> TPESCRQT invalid data length=%d < txn ctf total len=%d", iDataLen,iTxnCtfLen);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstReinput->cReturnCode = TMS_REINPUT_PARA_ERR;
      ErrLog(100,"<APD>###tmsapi### exit TPESCRQT, dump RQTP-CTL=",
             RPT_TO_LOG,pcArg1,sizeof(struct ReinputCtlSt));
      UCP_TRACE_END( -1 );
    }
  }

  switch ( pstReinput->cFmtCode ) {
    case FMT_1:
      iRc = ApDataToSif(pstReinput, pcArg2, g_pstTba->caRendo);
      if ( iRc < 0 ) {
        pstReinput->cReturnCode = TMS_REINPUT_PARA_ERR;
        sprintf( g_caMsg, "<tmsapi> TPESCRQT: ApDataToSif() error! %d",iRc);
        ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
        ErrLog(100,"<APD>###tmsapi### exit TPESCRQT, dump RQTP-CTL=",
               RPT_TO_LOG,pcArg1,sizeof(struct ReinputCtlSt));
        UCP_TRACE_END( -1 );
      }
      break;

    case FMT_2:
      iRc = CtfToSif(PART_CTF_TYPE,pstReinput->caTxnCode, 
                                              pcArg2, g_pstTba->caRendo);
      if ( iRc < 0 ) {
        pstReinput->cReturnCode = TMS_REINPUT_CNV_ERR;
        sprintf( g_caMsg, "<tmsapi> TPESCRQT: CtfToSif() error! %d",iRc);
        ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
        ErrLog(100,"<APD>###tmsapi### exit TPESCRQT, dump RQTP-CTL=",
               RPT_TO_LOG,pcArg1,sizeof(struct ReinputCtlSt));
        UCP_TRACE_END( -1 );
      }
      break;
    case FMT_CTF:
      iRc = CtfToSif(CTF_TYPE,pstReinput->caTxnCode, pcArg2, g_pstTba->caRendo);

      if ( iRc < 0 ) {
        pstReinput->cReturnCode = TMS_REINPUT_CNV_ERR;
        sprintf( g_caMsg, "<tmsapi> TPESCRQT: CtfToSif() error! %d",iRc);
        ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
        ErrLog(100,"<APD>###tmsapi### exit TPESCRQT, dump RQTP-CTL=",
               RPT_TO_LOG,pcArg1,sizeof(struct ReinputCtlSt));
        UCP_TRACE_END( -1 );
      }

      break;
    default:
      sprintf( g_caMsg, "<tmsapi> TPESCRQT cFmtCode error! %c",
               pstReinput->cFmtCode );
      ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
      pstReinput->cReturnCode = TMS_REINPUT_PARA_ERR;
      ErrLog(100,"<APD>###tmsapi### exit TPESCRQT, dump RQTP-CTL=",
             RPT_TO_LOG,pcArg1,sizeof(struct ReinputCtlSt));
      UCP_TRACE_END ( -1 );
  }

/*ErrLog(100,"###tmsapi### TPESCRQT: SIF",RPT_TO_LOG,g_pstTba->caRendo,iRc);*/
/*  iRc = AddSofHeadToSif(g_pstTba->caRendo,g_pstTma->stTSSA.caBrCode,
                        g_pstTma->stTSSA.caTmCode); */
  memcpy ( g_caReinputBuffer,g_pstTba->caRendo,MAX_SIF_LEN);
  memset ( g_pstTba->caRendo,'\0',MAX_SIF_LEN);
  iRc = AddSofHeadToSif(g_caReinputBuffer,g_pstTma->stTSSA.caBrCode,
                        g_pstTma->stTSSA.caTmCode,iRc);
  if (iRc < 0) {
    pstReinput->cReturnCode = TMS_REINPUT_CNV_ERR;
    sprintf( g_caMsg, "<tmsapi> TPESCRQT: AddSofHeadToSif() error! %d"
             ,iRc );
    ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
    ErrLog(100,"<APD>###tmsapi### exit TPESCRQT, dump RQTP-CTL=",
           RPT_TO_LOG,pcArg1,sizeof(struct ReinputCtlSt));
    UCP_TRACE_END ( -1 );
  }

  memcpy(&g_pstTba->caRendo[SOF_HEAD_LEN_PLUS_2], SIF_FMT_1, SIF_FMT_LEN);
  g_pstTma->stTCFA.cTxnReinput   = TMS_TXN_REINPUT_ON_API;

/* To avoid calling APRQT or SCRQT twice in one AP flow 19961018 - Begin */
  g_cRqtApiBeenCalled = FUN_REINPUT;
/* To avoid calling APRQT or SCRQT twice in one AP flow 19961018 - End */

  ErrLog(100,"<APD>###tmsapi### exit TPESCRQT, dump RQTP-CTL=",
         RPT_TO_LOG,pcArg1,sizeof(struct ReinputCtlSt));
  UCP_TRACE_END ( 0 );
  
}



TPFDBS(char *pcArg0,char *pcArg1,char *pcArg2)
{
  int iRc;
  char cDbsFlag;

  UCP_TRACE(P_TPFDBS);

  ErrLog(100,"<APD>###tmsapi### enter TPFDBS, dump DBS-CTL=",
         RPT_TO_LOG,pcArg1,sizeof(struct DbsSt));

  if ( (g_pstTma->stTSSA.cSysMode == ONLINE_MODE) || 
       (g_pstTma->stTSSA.cSysMode == SPECIAL_MODE) )
    cDbsFlag = '0';     /* call dbs in online mode */
  else
    cDbsFlag = '1';     /* call dbs in batch  mode */

  iRc = SbDbs(pcArg1,pcArg2,cDbsFlag);

  ErrLog(100,"<APD>###tmsapi### exit TPFDBS, dump DBS-CTL=",
         RPT_TO_LOG,pcArg1,sizeof(struct DbsSt));

  UCP_TRACE_END(iRc);
}

TPFFCS(char *pcArg0,char *pcArg1,char *pcArg2)
{
  int iRc;
  int iPargc;
  char cFcsFlag;
  char *pacArgv[5];

  UCP_TRACE(P_TPFFCS);

  ErrLog(100,"<APD>###tmsapi### enter TPFFCS, dump FCSAP=",
         RPT_TO_LOG,pcArg1,sizeof(struct FcsSt));

  if ( (g_pstTma->stTSSA.cSysMode == ONLINE_MODE) || 
       (g_pstTma->stTSSA.cSysMode == SPECIAL_MODE) )
    cFcsFlag = '0';     /* call fcs in rollback mode */
  else
    cFcsFlag = '1';     /* call fcs in non-rollback mode */

  iPargc = 4;
  pacArgv[1] = (char *)pcArg1;
  pacArgv[2] = (char *)pcArg2;
  pacArgv[3] = &cFcsFlag;
  iRc = SbFcs(iPargc,pacArgv);

  ErrLog(100,"<APD>###tmsapi### exit TPFFCS, dump FCSAP=",
         RPT_TO_LOG,pcArg1,sizeof(struct FcsSt));

  UCP_TRACE_END(iRc);
}



TPEDCS(char *pcArg0,char *pcArg1,char *pcArg2)
{
  int iRc;
  int iPargc;
  char *pacArgv[5];

  UCP_TRACE(P_TPEDCS);

  ErrLog(100,"<APD>###tmsapi### enter TPEDCS, dump DCS-AREA=",
         RPT_TO_LOG,pcArg1,sizeof(struct DcsApi));

  iPargc = 4;
  pacArgv[1] = (char *)pcArg1;
  pacArgv[2] = (char *)pcArg2;
  pacArgv[3] = "0";
  iRc = SbDcs(iPargc,pacArgv);

  ErrLog(100,"<APD>###tmsapi### exit TPEDCS, dump DCS-AREA=",
         RPT_TO_LOG,pcArg1,sizeof(struct DcsApi));

  UCP_TRACE_END(iRc);
}



TPGIOHDL(char *pcArg0,char *pcArg1)
/*  pcArg0 -->  APA
    pcArg1 -->  BIOP structure  */
{
  int iRc;
  struct JclIoSt *pstJclIo;

  UCP_TRACE(P_TPGIOHDL);

  ErrLog(100,"<APD>###tmsapi### enter TPGIOHDL, dump BIOP=",
         RPT_TO_LOG, pcArg1,sizeof(struct JclIoSt));

  pstJclIo = (struct JclIoSt *) pcArg1;

  if ( pstJclIo->cCmdNo > '5' ) {
    sprintf( g_caMsg,"<tmsapi> TPGIOHDL invalid cmd. number! %d",
             pstJclIo->cCmdNo);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstJclIo->cJclIoRtnCode = TMS_JCLIO_CMDNO_ERR;
    UCP_TRACE_END( -1 );
  }

/* To prevent this API from running on ONLINE mode (not JCL)19960924 -- begin */
  if (g_pstTma->stTSSA.cSysMode == ONLINE_MODE) {
    sprintf( g_caMsg,
        "<tmsapi> TPGIOHDL: cannot call this API on online mode (not JCL)!");
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstJclIo->cJclIoRtnCode = TMS_JCLIO_MODE_ERR;
    UCP_TRACE_END( -1 );
  }
/* To prevent this API from running on ONLINE mode (not JCL)19960924 -- end */

  TPGIO(pstJclIo);

  ErrLog(100,"<APD>###tmsapi### exit TPGIOHDL, dump BIOP=",RPT_TO_LOG,
         pstJclIo,sizeof(struct JclIoSt));

  UCP_TRACE_END(0);
}



TPFRPT(char *pcArg0,char *pcArg1)
/*  pcArg0 -->  APA
    pcArg1 -->  FrptSt structure  */
{
  int iRc;
  struct FrptSt *pstFrpt;
  char caDataLen[10];
  int iDataLen;

  UCP_TRACE(P_TPFRPT);
   
  pstFrpt = (struct FrptSt *) pcArg1;

  if ( pstFrpt->stFrptData.cOutDevType != '*' && 
                                  pstFrpt->stFrptCtl.cCmdCode == '1' ) {
    sprintf( g_caMsg,"<tmsapi> TPFRPT invalid out device! %c",
             pstFrpt->stFrptData.cOutDevType );
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstFrpt->stFrptCtl.cFrptRtnCode = TMS_TPFRPT_DEV_ERR;
    UCP_TRACE_END( -1 );
  }

  memset( caDataLen, 0, 10 );
  memcpy( caDataLen, pstFrpt->stFrptData.caDataLen, AP_MSG_DATA_LEN_SIZE );
  iDataLen = atoi( caDataLen );

  /* -----------------  check  output  msg.  length   -------------- */
  if ( iDataLen > 5000 ) {
    sprintf( g_caMsg,"<tmsapi> TPFRPT data len overflow! %.4s --> %d",
             pstFrpt->stFrptData.caDataLen, iDataLen);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstFrpt->stFrptCtl.cFrptRtnCode = TMS_TPFRPT_LEN_ERR;
    UCP_TRACE_END( -1 );
  }

  iDataLen = atoi( caDataLen ) + 9;
  
  ErrLog(100,"<APD>###tmsapi### enter TPFRPT, dump MSGP-CTL-AREA=",
         RPT_TO_LOG,&pstFrpt->stFrptCtl,sizeof(struct FrptCtlSt) );
  ErrLog(100,"<APD>###tmsapi### enter TPFRPT, dump MSGP-DATA=",
         RPT_TO_LOG,&pstFrpt->stFrptData,iDataLen );

  tpfrpt(pstFrpt);

  ErrLog(100,"<APD>###tmsapi### exit TPFRPT, dump MSGP-CTL-AREA=",
         RPT_TO_LOG,&pstFrpt->stFrptCtl,sizeof(struct FrptCtlSt) );

  UCP_TRACE_END(0);
}


TPESDCLT(char *pcArg0,char *pcArg1,char *pcArg2)
/* pcArg1 pointer to control part "SdcltCtlSt"
   pcArg2 pointer to data part                 */
{
  int iRc;
  struct SdcltCtlSt *pstSdcltCtl;
  char caTmpLen[10];
  char caTmpBuf[1028];

  UCP_TRACE(P_TPESDCLT);
  pstSdcltCtl = (struct SdcltCtlSt *) pcArg1;
  ErrLog(100,"<tmsapi> TPESDCLT CTL=",
         RPT_TO_LOG,pcArg1,sizeof(struct SdcltCtlSt));
  memcpy(caTmpLen, pstSdcltCtl->caSdcltLen, 5);/* COBOL AP data len is 9(5) */
  caTmpLen[5] = 0x00;
  iRc = atoi(caTmpLen);
  ErrLog(100,"<tmsapi> TPESDCLT DATA=",RPT_TO_LOG,pcArg2,iRc);
  memcpy(caTmpBuf,&iRc,sizeof(int));
  memcpy(caTmpBuf+sizeof(int), pcArg2, iRc);
  iRc = OutptSel(POST_DATA,caTmpBuf,g_pstTma->stTSSA.caBrCode,
                      g_pstTma->stTSSA.caTmCode);

  if ( iRc == 0 ) {
    pstSdcltCtl->cMsgOutReturnCode = TMS_MSGP_NORMAL;
  }
  else {
    pstSdcltCtl->cMsgOutReturnCode = TMS_MSGP_PARA_ERR;
  }

  UCP_TRACE_END(0);
}


TPFCWARW(char *pcArg0,char *pcArg1,char *pcArg2)
{
  int iRc;
  int iLen;
  char caLen[10];
  struct ShmFacCtlSt *pstShmCtl;

  UCP_TRACE(P_TPFCWARW);

  ErrLog(100,"<APD>###tmsapi### enter TPFCWARW, dump CTL-AREA=",
         RPT_TO_LOG,pcArg1,sizeof(struct ShmFacCtlSt));

  pstShmCtl = (struct ShmFacCtlSt *) pcArg1;

  memset(caLen,0,10);
  memcpy(caLen,pstShmCtl->caDataLen,5);
  iLen = atoi(caLen);

  if ( pstShmCtl->cShmFunCode == TMS_SHM_WR_UNLOCK ||
       pstShmCtl->cShmFunCode == TMS_SHM_WR_ONLY ) {
    ErrLog(100,"<APD>###tmsapi### enter TPFCWARW, dump IO-AREA=",
           RPT_TO_LOG,pcArg2,iLen);
  }

  iRc = ShmFac(pcArg1,pcArg2);

  ErrLog(100,"<APD>###tmsapi### exit TPFCWARW, dump CTL-AREA=",
         RPT_TO_LOG,pcArg1,sizeof(struct ShmFacCtlSt));
  if ( pstShmCtl->cShmFunCode == TMS_SHM_WR_UNLOCK ||
       pstShmCtl->cShmFunCode == TMS_SHM_WR_ONLY ) {
    ErrLog(100,"<APD>###tmsapi### exit TPFCWARW, dump IO-AREA=",
           RPT_TO_LOG,pcArg2,iLen);
  }

  UCP_TRACE_END(0);
}



TPFLOGOP(char *pcArg0,char *pcArg1,char *pcArg2)
{
  int  iRc;     
  struct LogApiSt *pstLogOpCtl;

  UCP_TRACE(P_TPFLOGOP);

  ErrLog(100,"<APD>###tmsapi### enter TPFLOGOP, dump LOGP-CTL=",
         RPT_TO_LOG,pcArg1, sizeof(struct LogApiSt));

  pstLogOpCtl = (struct LogApiSt *) pcArg1;
  /* ---------------------------------------------------------------- */
  /*    check input data correctness                                  */
  /* ---------------------------------------------------------------- */
  if (  pstLogOpCtl->caOperKind[0] != LG_RANDOM_READ      &&
        pstLogOpCtl->caOperKind[0] != LG_RANDOM_READ_U    &&
	pstLogOpCtl->caOperKind[0] != LG_READ_NEXT        &&
	pstLogOpCtl->caOperKind[0] != LG_READ_NEXT_U      &&
	pstLogOpCtl->caOperKind[0] != LG_REWRITE          &&
	pstLogOpCtl->caOperKind[0] != LG_APPEND           &&
	pstLogOpCtl->caOperKind[0] != LG_READ_FIRST       &&
	pstLogOpCtl->caOperKind[0] != LG_READ_FIRST_U     &&
	pstLogOpCtl->caOperKind[0] != LG_READ_LAST        &&
	pstLogOpCtl->caOperKind[0] != LG_READ_LAST_U      &&
	pstLogOpCtl->caOperKind[0] != LG_DIRECT_UPDATE    &&
	pstLogOpCtl->caOperKind[0] != LG_OPEN             &&
	pstLogOpCtl->caOperKind[0] != LG_CLOSE                ) {
    sprintf( g_caMsg,"<tmsapi> TPFLOGOP invalid fun code! %c",
	     pstLogOpCtl->caOperKind[0]);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstLogOpCtl->caReturnCd[0] = LG_INVALID_FUN;
    ErrLog(100,"<APD>###tmsapi### exit TPFLOGOP, dump LOGP-CTL=",
           RPT_TO_LOG,pcArg1, sizeof(struct LogApiSt));
    UCP_TRACE_END( -1 );
  }

  if ( pstLogOpCtl->caOperKind[0] != LG_REWRITE          &&
       pstLogOpCtl->caOperKind[0] != LG_APPEND           &&
       pstLogOpCtl->caOperKind[0] != LG_DIRECT_UPDATE    ) {
    ErrLog(100,"<APD>###tmsapi### enter TPFLOGOP, dump IO-AREA=",
           RPT_TO_LOG,pcArg2,1000);
  }


  LOGOPERATION(pstLogOpCtl,pcArg2);

  ErrLog(100,"<APD>###tmsapi### exit TPFLOGOP, dump LOGP-CTL=",
         RPT_TO_LOG,pcArg1, sizeof(struct LogApiSt));

  if (  pstLogOpCtl->caOperKind[0] == LG_RANDOM_READ      ||
        pstLogOpCtl->caOperKind[0] == LG_RANDOM_READ_U    ||
	pstLogOpCtl->caOperKind[0] == LG_READ_NEXT        ||
	pstLogOpCtl->caOperKind[0] == LG_READ_NEXT_U      ||
	pstLogOpCtl->caOperKind[0] == LG_READ_FIRST       ||
	pstLogOpCtl->caOperKind[0] == LG_READ_FIRST_U     ||
	pstLogOpCtl->caOperKind[0] == LG_READ_LAST        ||
	pstLogOpCtl->caOperKind[0] == LG_READ_LAST_U          ) { 
    ErrLog(100,"<APD>###tmsapi### exit TPFLOGOP, dump IO-AREA=",
           RPT_TO_LOG,pcArg2,1000);
  }

  UCP_TRACE_END(0);
}



TPERVSOP(char *pcArg0,char *pcArg1,char *pcArg2)
{
  int  iRc;     
  struct LogApiSt *pstLogOpCtl;
  static char s_cBeenReadLogFlag='n';

  UCP_TRACE(P_TPERVSOP);


  ErrLog(100,"<APD>###tmsapi### enter TPERVSOP, dump REVP-CTL=",
         RPT_TO_LOG,pcArg1, sizeof(struct LogApiSt));

  pstLogOpCtl = (struct LogApiSt *) pcArg1;

  if ( g_pstTma->stTCFA.cRevTxn == TMS_TXN_REVERSE ) {
    pstLogOpCtl->caReturnCd[0] = 'A';
    UCP_TRACE_END( -1 );
  }

  switch (  pstLogOpCtl->caOperKind[0] ) {
    case LG_READ_LOG :
      iRc = RvsLogRd(pstLogOpCtl,pcArg2);
      if ( iRc < 0 ) {
        sprintf( g_caMsg,"<tmsapi> TPERVSOP RvsLogOp error rtn code! %d",iRc);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        ErrLog(100,"<APD>###tmsapi### exit TPERVSOP, dump REVP-CTL=",
               RPT_TO_LOG,pcArg1, sizeof(struct LogApiSt));
        UCP_TRACE_END( -1 );
      }
      g_pstTma->stTCFA.cRvsApRdLogFlag = TMS_RVSAP_HAS_BEEN_RD_LOG;
      s_cBeenReadLogFlag = 'y';
      ErrLog(100,"<APD>###tmsapi### exit TPERVSOP, dump IO-AREA=",
             RPT_TO_LOG,pcArg2, 1000);
      break;
    case LG_START_REVERSE :
      if ( s_cBeenReadLogFlag == 'y' ) {
        g_pstTma->stTCFA.cRendoRequest = TMS_TXN_RENDO; 
        g_pstTma->stTCFA.cRevTxn = TMS_TXN_REVERSE; 
        s_cBeenReadLogFlag = 'n';
      }
      else {
        sprintf( g_caMsg,"<tmsapi> TPERVSOP RvsLogOp sequence error");
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        pstLogOpCtl->caReturnCd[0] = LG_WRONG_CALL_SEQ;
        ErrLog(100,"<APD>###tmsapi### enter TPERVSOP, dump REVP-CTL=",
               RPT_TO_LOG,pcArg1, sizeof(struct LogApiSt));
        UCP_TRACE_END( -1 );
      }
      break;
    default:
        sprintf( g_caMsg,"<tmsapi> TPERVSOP invalid fun code! %d",
                 pstLogOpCtl->caOperKind[0]);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        pstLogOpCtl->caReturnCd[0] = LG_INVALID_FUN;
        ErrLog(100,"<APD>###tmsapi### enter TPERVSOP, dump REVP-CTL=",
               RPT_TO_LOG,pcArg1, sizeof(struct LogApiSt));
        UCP_TRACE_END( -1 );
  }

  ErrLog(100,"<APD>###tmsapi### exit TPERVSOP, dump REVP-CTL=",
         RPT_TO_LOG,pcArg1, sizeof(struct LogApiSt));
  UCP_TRACE_END(0);
}

TPEGPREV(char *pcArg0,char *pcArg1,char *pcArg2)
{
  int iRc;
  struct GetPreCtlSt *pstGetPrev;

  UCP_TRACE(P_TPEGPREV);

  ErrLog(100,"<APD>###tmsapi### enter TPEGPREV, dump CTL-AREA=",
         RPT_TO_LOG,pcArg1, sizeof(struct GetPreCtlSt));

  pstGetPrev = (struct GetPreCtlSt *) pcArg1;
  iRc = GetPrevLog(pcArg2);

  if ( iRc < 0 ) {
    pstGetPrev->cGetPreLogRtnCode = TMS_NO_MORE_ERROR;
  }
  else {
    pstGetPrev->cGetPreLogRtnCode = TMS_GPREV_NORMAL;
  }

  ErrLog(100,"<APD>###tmspai### exit TPEGPREV, dump CTL-AREA=",
         RPT_TO_LOG,pstGetPrev, sizeof(struct GetPreCtlSt));
  ErrLog(100,"<APD>###tmsapi### exit TPEGPREV, dump IO-AREA=",
         RPT_TO_LOG,pcArg2, 450);

  UCP_TRACE_END(0);

}


TPFGTSEQ(char *pcArg0,char *pcArg1)
{
  int  iRc;     
  struct GetSeqSt *pstGetSeq;

  UCP_TRACE(P_TPFGTSEQ);
  pstGetSeq = (struct GetSeqSt *) pcArg1;
  pstGetSeq->cGetSeqRtnCode = TMS_GTSEQ_NORMAL;
/*
  ErrLog(100,"<APD>###tmsapi### enter TPFGTSEQ, dump CTL-AREA=",
         RPT_TO_LOG,pstGetSeq, sizeof(struct GetSeqSt));
*/

  iRc = GetEjRrn(pstGetSeq);
  if (iRc < 0 ) {
    UCP_TRACE_END( -1 );
  }

/*
  ErrLog(100,"<APD>###tmsapi### exit TPFGTSEQ, dump CTL-AREA=",
         RPT_TO_LOG,pstGetSeq, sizeof(struct GetSeqSt));
*/

  UCP_TRACE_END(0);
}


TPFADSEQ(char *pcArg0,char *pcArg1)
{
  UCP_TRACE(P_TPFADSEQ);
  UCP_TRACE_END(0);
}


TPFRKSEQ(char *pcArg0,char *pcArg1)
{
  UCP_TRACE(P_TPFRKSEQ);
  UCP_TRACE_END(0);
}


TPEONBTH(char *pcArg0, char *pcArg1, char *pcArg2)
/* pcArg0 ---> APA
   pcArg1 ---> control part "OnBthCtlSt"
   pcArg2 ---> data part                 */
{
  int  iRc;
  int  iFd;
  int  iDataLen;
  int  iSifLen;
  long lBtchSeqNo;
  char cRmtApFlag;
  char caTxnCode[10];
  char caDataLen[ 10 ];
  char caReentrySeqNo[ 10 ];
  char caBuf[ MAX_SIF_LEN ];
  char caFileName[ 80 ];
  char caSofHeadBuf[ SOF_HEAD_LEN_PLUS_2 ];
  struct OnBthCtlSt *pstOnBth;
  txn_head stTxnDesc;   /* transaction characteristic description  */
  unsigned char ucaReentryLen[3];
  struct ReinputCtlSt stTmpBuf;

  UCP_TRACE(P_TPEONBTH);
  /* === for EditUnixItemToCics to skip (2+14) bytes  */
  g_pstTma->stTCFA.cReentryStatus = TMS_TXN_REENTRY;

  pstOnBth = (struct OnBthCtlSt *) pcArg1;
  pstOnBth->cOnBthRtnCode = TMS_ONBTH_NORMAL;
  ErrLog(100,"<APD>###tmsapi### enter TPEONBTH ,dump ONBTH-CTL=",
         RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
  
  if ( pstOnBth->cFmtCode != FMT_SIF ) {
    memset(caTxnCode, 0, 10);
    memcpy(caTxnCode, pstOnBth->caTxnCode, g_iTxnCodeLen);
    iRc = ReadIet( TXN_DESC, RANDOM_READ, caTxnCode, (char *)&stTxnDesc );
    if ( iRc < 0 ) {
      sprintf( g_caMsg,"<tmsapi> TPEONBTH: invalid txn. code! %.4s",
               pstOnBth->caTxnCode);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstOnBth->cOnBthRtnCode = TMS_ONBTH_CNV_ERR;
      ErrLog(100,"<APD>###tmsapi### exit TPEONBTH ,dump ONBTH-CTL=",
             RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
      UCP_TRACE_END( -1 );
    }
  }

  memset( caDataLen, 0, 10);
  memcpy( caDataLen, pstOnBth->caDataLen, ONBTH_DATA_LEN_SIZE);
  iDataLen = atoi( caDataLen );

  ErrLog(100,"<APD>###tmsapi### enter TPEONBTH ,dump ONBTH-DATA=",RPT_TO_LOG,pcArg2,iDataLen);


  if ( iDataLen > MAX_SIF_LEN ) {
    sprintf( g_caMsg,"<tmsapi> TPEONBTH: invalid data length! %d",
             iDataLen);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstOnBth->cOnBthRtnCode = TMS_ONBTH_PARA_ERR;
    ErrLog(100,"<APD>###tmsapi### exit TPEONBTH ,dump ONBTH-CTL=",
           RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
    UCP_TRACE_END( -1 );
  }
  
  switch( pstOnBth->cFmtCode ) {
    case FMT_1:
      memset(g_pstTba->caRendo,0,MAX_SIF_LEN);
      memset(&stTmpBuf,0,sizeof(struct ReinputCtlSt));
      memcpy(stTmpBuf.caDataLen,pstOnBth->caDataLen,4);
      memcpy(stTmpBuf.caTxnCode,pstOnBth->caTxnCode,4);
     
      iRc = ApDataToSif(&stTmpBuf, pcArg2, g_pstTba->caRendo);
      if ( iRc < 0 ) {
        pstOnBth->cOnBthRtnCode = TMS_ONBTH_PARA_ERR;
        sprintf( g_caMsg, "<tmsapi> TPEONBTH: ApDataToSif() error! %d",iRc);
        ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
        ErrLog(100,"<APD>###tmsapi### exit TPEONBTH ,dump ONBTH-CTL=",
               RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
        UCP_TRACE_END( -1 );
      }    
      iSifLen = iRc;
      break;

    case FMT_2:
      memset(g_pstTba->caRendo,0,MAX_SIF_LEN);
      iRc = CtfToSif(PART_CTF_TYPE,pstOnBth->caTxnCode, 
                                              pcArg2, g_pstTba->caRendo);
      if ( iRc < 0 ) {
        pstOnBth->cOnBthRtnCode = TMS_ONBTH_CNV_ERR;
        sprintf( g_caMsg, "<tmsapi> TPEONBTH: CtfToSif() error! %d",iRc);
        ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
        ErrLog(100,"<APD>###tmsapi### exit TPEONBTH ,dump ONBTH-CTL=",
               RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
        UCP_TRACE_END( -1 );
      }
      iSifLen = iRc;
      break;

    case FMT_CTF:
      memset(g_pstTba->caRendo,0,MAX_SIF_LEN);
      iRc = CtfToSif(CTF_TYPE,pstOnBth->caTxnCode,pcArg2,g_pstTba->caRendo);
      if ( iRc < 0 ) {
        sprintf( g_caMsg, "<tmsapi> TPEONBTH CtfToSif error! %d",iRc);
        ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
        pstOnBth->cOnBthRtnCode = TMS_ONBTH_CNV_ERR;
        ErrLog(100,"<APD>###tmsapi### exit TPEONBTH ,dump ONBTH-CTL=",
               RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
        UCP_TRACE_END( -1 );/*added 19960807*/
      }
      iSifLen = iRc;
      break;

    case FMT_SIF:
      memcpy(g_pstTba->caRendo,pcArg2,iDataLen);
      iSifLen = iDataLen;
      break;

    default:
      sprintf( g_caMsg, "<tmsapi> TPEONBTH cFmtCode error! %c",
               pstOnBth->cFmtCode );
      ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
      pstOnBth->cOnBthRtnCode = TMS_ONBTH_PARA_ERR;
      ErrLog(100,"<APD>###tmsapi### exit TPEONBTH ,dump ONBTH-CTL=",
             RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
      UCP_TRACE_END ( -1 );
  }
  sprintf(g_caMsg,"<tmsapi> TPEONBTH after data convert,iSifLen=%d !",iSifLen);
  ErrLog( 100, g_caMsg, RPT_TO_LOG, 0, 0 );

  if(iSifLen < SIF_HEAD_LEN) {
    sprintf(g_caMsg,"<tmsapi> TPEONBTH after data convert,iSifLen=%d < SIF_HEAD_LEN(51bytes) error!",iSifLen);
    ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
    pstOnBth->cOnBthRtnCode = TMS_ONBTH_PARA_ERR;
    ErrLog(100,"<APD>###tmsapi### exit TPEONBTH ,dump ONBTH-CTL=",
           RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
    UCP_TRACE_END ( -1 );
  }

  /* set TPEI */
  memcpy(g_pstTba->caRendo, SIF_FMT_1, SIF_FMT_LEN);
  if ( pstOnBth->cFmtCode != FMT_SIF ) {
    memcpy(&g_pstTba->caRendo[TXN_CODE_OFFSET],
           pstOnBth->caTxnCode,g_iTxnCodeLen);
  }
  memcpy(&g_pstTba->caRendo[ BR_CODE_OFFSET ], pstOnBth->caBrhCode, 
         g_iBrhCodeLen);
  memcpy(&g_pstTba->caRendo[ TM_CODE_OFFSET ], pstOnBth->caReentryTmCode, 
         g_iTmCodeLen);
  /* if cFmtCode is FMT_SIF, teller-code doesn't be changed;
   * otherwise teller-code is the code of teller who issues the txn.
   */
  if ( pstOnBth->cFmtCode != FMT_SIF ) {
    memcpy(&g_pstTba->caRendo[ TELLER_CODE_OFFSET ], g_pstTma->stTSSA.caTellId, 
           TELLER_CODE_LEN);
  } 

  /* 19951215 ---add for correcting SIF CONTROL-BYTE's supervisor bit */
  if( pstOnBth->cFmtCode != FMT_SIF ) {
    if ( pstOnBth->cFlag == '1' ) {
      /* set the reentry bit of CTL-byte in SIF to ON */ 
      memcpy(&g_pstTba->caRendo[ CTL_BYTE_OFFSET ], "\x01\x00", CTL_BYTE_LEN);
    }
    else {
      /* set CTL-byte in SIF to NORMAL */ 
      memcpy(&g_pstTba->caRendo[ CTL_BYTE_OFFSET ], "\x00\x00", CTL_BYTE_LEN);
    }
  }
  else {
    if ( pstOnBth->cFlag == '1' ) {
      g_pstTba->caRendo[CTL_BYTE_OFFSET] |= 0x01;
    }
  }

  sprintf( g_caMsg, "<tmsapi> TPEONBTH before RdWrReentrySeq !");
  ErrLog( 100, g_caMsg, RPT_TO_LOG, 0, 0 );

  /* Read REENTRY-SEQ number ...... */
  iRc=RdWtReentrySeq(RD_REENTRY_SEQ_NO,pstOnBth->caBrhCode,
                     pstOnBth->caReentryTmCode,&lBtchSeqNo,
                     g_pstTma->stTCFA.cReentryStatus);

  sprintf( g_caMsg,
           "<tmsapi> TPEONBTH after RdWrReentrySeq lBtchSeqNo=%ld!",lBtchSeqNo);
  ErrLog( 100, g_caMsg, RPT_TO_LOG, 0, 0 );

  if ( iRc < 0 ) {
    sprintf( g_caMsg, "<tmsapi> TPEONBTH RdWtReentrySeq (Read) error!");
    ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
    pstOnBth->cOnBthRtnCode = TMS_ONBTH_SYS_ERR;
    ErrLog(100,"<APD>###tmsapi### exit TPEONBTH ,dump ONBTH-CTL=",
           RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
    UCP_TRACE_END ( -1 );
  }
  memset(caReentrySeqNo,0,10);
  sprintf(caReentrySeqNo,"%.*ld",5,lBtchSeqNo);
  
  /* put BRH-CODE and REENTRY-TM-CODE and lBtchSeqNo to SIF's 1th data field */
  memcpy(caBuf,g_pstTba->caRendo+SIF_HEAD_LEN,iSifLen-SIF_HEAD_LEN);
  ucaReentryLen[0]=(unsigned char) (g_iBrhCodeLen+g_iTmCodeLen+5)/256;
  ucaReentryLen[1]=(unsigned char) (g_iBrhCodeLen+g_iTmCodeLen+5)%256;
  ucaReentryLen[2]=0x00;
  memcpy(&g_pstTba->caRendo[SIF_HEAD_LEN],ucaReentryLen,2);
  memcpy(&g_pstTba->caRendo[SIF_HEAD_LEN+2],pstOnBth->caBrhCode,g_iBrhCodeLen);
  memcpy(&g_pstTba->caRendo[SIF_HEAD_LEN+2+g_iBrhCodeLen],
         pstOnBth->caReentryTmCode,g_iTmCodeLen);
  memcpy(&g_pstTba->caRendo[SIF_HEAD_LEN+2+g_iBrhCodeLen+g_iTmCodeLen],
          caReentrySeqNo,5);
  memcpy(&g_pstTba->caRendo[SIF_HEAD_LEN+2+g_iBrhCodeLen+g_iTmCodeLen+5],
         caBuf,iSifLen-SIF_HEAD_LEN);

  /* beacuse Add ReentrySeqNo to original SIF, 
     original SIF len should be added by 7    */
  iSifLen += (2+g_iBrhCodeLen+g_iTmCodeLen+5);

  sprintf( g_caMsg, "<tmsapi> TPEONBTH before RmtProc iSifLen=%d !",iSifLen);
  ErrLog( 100, g_caMsg, RPT_TO_LOG, 0, 0 );

  iRc = RmtProc(g_pstTba->caRendo,iSifLen,&cRmtApFlag);
  if ( iRc < 0 ) {
    /* error occurs in Client, don't add Client Reentry-Terml's BtchSeqNo */
    if ( iRc <= -1 && iRc >= -4 ) { 
      if( iRc == -4 ) {
        sprintf( g_caMsg, "<tmsapi> TPEONBTH SndSifToServer error,iRc=%d!",iRc);
        ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
        pstOnBth->cOnBthRtnCode = TMS_ONBTH_DCS_ERR;
        ErrLog(100,"<APD>###tmsapi### exit TPEONBTH ,dump ONBTH-CTL=",
               RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
        UCP_TRACE_END ( -1 );
      }
      else {
        sprintf(g_caMsg,
                "<tmsapi> TPEONBTH before SndSifToServer error,iRc=%d",iRc);
        ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
        pstOnBth->cOnBthRtnCode = TMS_ONBTH_PARA_ERR;
        ErrLog(100,"<APD>###tmsapi### exit TPEONBTH ,dump ONBTH-CTL=",
               RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
        UCP_TRACE_END ( -1 );
      }
    }
    else {
      if ( iRc == -5 ) {
        sprintf(g_caMsg,"<tmsapi> TPEONBTH RcvHostDataToFile error,iRc=%d",iRc);
        ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
        pstOnBth->cOnBthRtnCode = TMS_ONBTH_DCS_ERR;
        ErrLog(100,"<APD>###tmsapi### exit TPEONBTH ,dump ONBTH-CTL=",
               RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
        UCP_TRACE_END ( -1 );
      }
      else {
        sprintf( g_caMsg, "<tmsapi> TPEONBTH system error,iRc=%d!",iRc);
        ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
        pstOnBth->cOnBthRtnCode = TMS_ONBTH_SYS_ERR;
        ErrLog(100,"<APD>###tmsapi### exit TPEONBTH ,dump ONBTH-CTL=",
               RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
        UCP_TRACE_END ( -1 );
      }
    }
  }

  /* Add BtchSeqNo by 1 */
  lBtchSeqNo++;

  /* Write REENTRY-SEQ number ...... */
  iRc=RdWtReentrySeq(WT_REENTRY_SEQ_NO,pstOnBth->caBrhCode,
                     pstOnBth->caReentryTmCode,&lBtchSeqNo,
                     g_pstTma->stTCFA.cReentryStatus);
  if ( iRc < 0 ) {
    sprintf( g_caMsg, "<tmsapi> TPEONBTH RdWtReentrySeq (Write) error!");
    ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
    pstOnBth->cOnBthRtnCode = TMS_ONBTH_SYS_ERR;
    ErrLog(100,"<APD>###tmsapi### exit TPEONBTH ,dump ONBTH-CTL=",
           RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
    UCP_TRACE_END ( -1 );
  }

  /* return Reentry BtchSeqNo to AP */
  memcpy(pstOnBth->caOnBthSeqNo,caReentrySeqNo,5);

#ifdef OMIT
  memset(caFileName,'\0',80);
  sprintf(caFileName,"%s/%s%.*s.%.*s",getenv("III_DIR"),"iii/log/output",
          g_iTmCodeLen, g_pstTma->stTSSA.caTmCode,
          g_iBrhCodeLen, g_pstTma->stTSSA.caBrCode);

  iFd = open(caFileName,O_RDONLY);
  if ( iFd < 0 ) {
    sprintf(g_caMsg,"<tmsapi.c> TPEONBTH open File=%s error!",caFileName);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstOnBth->cOnBthRtnCode = TMS_ONBTH_SYS_ERR;
    UCP_TRACE_END(-1);
  }

  if ((iRc = read(iFd,caSofHeadBuf,SOF_HEAD_LEN_PLUS_2)) 
                                               == SOF_HEAD_LEN_PLUS_2) {
    sprintf(g_caMsg,"<tmsapi.c> TPEONBTH read data bytes=%d",iRc);
    ErrLog(10,g_caMsg,RPT_TO_LOG,caSofHeadBuf,SOF_HEAD_LEN_PLUS_2);
#endif

    memcpy(caSofHeadBuf,&g_caMemBuf[sizeof(struct MemBufCtlSt)],SOF_HEAD_LEN_PLUS_2);

    iDataLen=(unsigned char)caSofHeadBuf[SOF_HEAD_LEN]*256+
             (unsigned char)caSofHeadBuf[SOF_HEAD_LEN+1];
    if ( iDataLen >= 0 ) {
      memset(caDataLen,0,10);
      sprintf(caDataLen,"%.4d",iDataLen);
      memcpy(pstOnBth->caDataLen,caDataLen,4);
    }
    else {
      sprintf(g_caMsg,"<tmsapi.c> TPEONBTH Ej len=%d < 0!",iDataLen);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstOnBth->cOnBthRtnCode = TMS_ONBTH_SYS_ERR;
      UCP_TRACE_END(-1);
    }

    if ( (unsigned char)caSofHeadBuf[SOF_CTL_CODE_OFFSET] == 0xc0 ) {
      memcpy(pstOnBth->caOnBthTxnRtnCode,"OK  ",4);
    }
    else {
      if ( (unsigned char)caSofHeadBuf[SOF_CTL_CODE_OFFSET] == 0xc8 ) {
        if ( (caSofHeadBuf[SOF_MSG_CODE_OFFSET] == 'H' ) ||
             (caSofHeadBuf[SOF_MSG_CODE_OFFSET] == 'B' ) ){
          /* ----------  to receive CICS/TPE's SOF data  -------------  */
          memcpy(pstOnBth->caOnBthTxnRtnCode,
                 &caSofHeadBuf[SOF_MSG_CODE_OFFSET+3],4);     
        }
        else {
          /* ----------  to receive UNIX/TPE's SOF data  -------------  */
          memcpy(pstOnBth->caOnBthTxnRtnCode,
                 &caSofHeadBuf[SOF_MSG_CODE_OFFSET],4);  
        }
      }
      else {
        if ( (caSofHeadBuf[SOF_MSG_CODE_OFFSET] == 'H' ) ||
             (caSofHeadBuf[SOF_MSG_CODE_OFFSET] == 'B' ) ){
          /* ----------  to receive CICS/TPE's SOF data  -------------  */
          memcpy(pstOnBth->caOnBthTxnRtnCode,
                 &caSofHeadBuf[SOF_MSG_CODE_OFFSET+3],4);
        }
        else {
          /* ----------  to receive UNIX/TPE's SOF data  -------------  */
          memcpy(pstOnBth->caOnBthTxnRtnCode,
                 &caSofHeadBuf[SOF_MSG_CODE_OFFSET],4);  
        }
        pstOnBth->cOnBthRtnCode = TMS_ONBTH_SERVER_ERR;
        ErrLog(100,"<APD>###tmsapi### exit TPEONBTH ,dump ONBTH-CTL=",
               RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
        UCP_TRACE_END(-1);
      }
    }

#ifdef OMIT
  }
  else {
    sprintf(g_caMsg,"<tmsapi.c> TPEONBTH read bytes=%d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstOnBth->cOnBthRtnCode = TMS_ONBTH_SYS_ERR;
    close(iFd);
    ErrLog(100,"<APD>###tmsapi### exit TPEONBTH ,dump ONBTH-CTL=",
           RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
    UCP_TRACE_END(-1);
  }

  close(iFd);
#endif

  ErrLog(100,"<APD>###tmsapi### exit TPEONBTH ,dump ONBTH-CTL=",
         RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
  UCP_TRACE_END( 0 );
}


TPFSETLN(char *pcArg0, char *pcArg1)
/* pcArg0 --->  APA
   pcArg1 --->  control part "SetLnCtlSt" */
{
  int iRc;
  struct SetLnCtlSt *pstSetLn;

  UCP_TRACE(P_TPFSETLN);

  pstSetLn = (struct SetLnCtlSt *) pcArg1;
  pstSetLn->cSetLnRtnCode = TMS_SETLN_NORMAL;

  if ( pstSetLn->cFunCode != '0' && pstSetLn->cFunCode != '1' ) {
    pstSetLn->cSetLnRtnCode = TMS_SETLN_FUN_ERR;
    sprintf(g_caMsg,
            "<<<tmsapi>>> TPFSETLN invalid cFunCode=%c",pstSetLn->cFunCode);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  }

  iRc = SetBrhLine(pstSetLn->cFunCode,pstSetLn->caSetLnBrhCode);
  if ( iRc < 0 ) {
    pstSetLn->cSetLnRtnCode = TMS_SETLN_BRH_ERR;
    sprintf(g_caMsg, "<<<tmsapi>>> TPFSETLN invalid BrhCode=%.*s",g_iBrhCodeLen,
            pstSetLn->caSetLnBrhCode);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  }

  UCP_TRACE_END(0);
}


TPEGTSIF(char *pcArg0, char *pcArg1)
/* pcArg0 --->  APA
   pcArg1 --->  control part "GtSifCtlSt" */
{
  int iRc;
  char caSifLen[10];
  struct GtSifCtlSt *pstGtSif;

  UCP_TRACE(P_TPEGTSIF);

  pstGtSif = (struct GtSifCtlSt *) pcArg1;
  pstGtSif->cGtSifRtnCode = TMS_GTSIF_NORMAL;
  memset(caSifLen,0,10);
  sprintf(caSifLen,"%.5d",g_iSifLen);
  memcpy(pstGtSif->caSifLen,caSifLen,5);
  memset(pstGtSif->caSifBuf,' ',MAX_SIF_LEN);
  memcpy(pstGtSif->caSifBuf,g_pstTba->caSif,g_iSifLen);

  UCP_TRACE_END(0);
}
int
TPEONBH1(char *pcApa, struct OnBh1CtlSt *pstOnBh1Ctl,char *pcOnBh1Data)
{
  char   caTmpBuf[5];
  int    iRc;

  UCP_TRACE(P_TPEONBH1);

  sprintf(g_caMsg,"<APD>###tmsapi### enter TPEONBH1 dump pstOnBh1Ctl="); 
  ErrLog(100,g_caMsg,RPT_TO_LOG,pstOnBh1Ctl,sizeof(struct OnBh1CtlSt));
  memcpy(caTmpBuf,pstOnBh1Ctl->caDataLen,4);
  caTmpBuf[4] = '\0';
  sprintf(g_caMsg,"<APD>###tmsapi### enter TPEONBH1 dump pcOnBh1Data="); 
  ErrLog(100,g_caMsg,RPT_TO_LOG,pcOnBh1Data,atoi(caTmpBuf));

  OnBatch1(pstOnBh1Ctl,pcOnBh1Data);

  sprintf(g_caMsg,"<APD>###tmsapi### exit TPEONBH1 dump pstOnBh1Ctl="); 
  ErrLog(100,g_caMsg,RPT_TO_LOG,pstOnBh1Ctl,sizeof(struct OnBh1CtlSt));

  UCP_TRACE_END(0);

}

TPEONBH2(char *pcArg0, char *pcArg1, char *pcArg2)
/* pcArg0 ---> APA
   pcArg1 ---> control part "OnBthCtlSt"
   pcArg2 ---> data part                 */
{
  int  iRc;
  int  iFd;
  int  iDataLen;
  int  iSifLen;
  long lBtchSeqNo;
  char cRmtApFlag;
  char caTxnCode[10];
  char caDataLen[ 10 ];
  char caReentrySeqNo[ 10 ];
  char caBuf[ MAX_SIF_LEN ];
  char caFileName[ 80 ];
  char caSofHeadBuf[ SOF_HEAD_LEN_PLUS_2 ];
  struct OnBthCtlSt *pstOnBth;
  txn_head stTxnDesc;   /* transaction characteristic description  */
  unsigned char ucaReentryLen[3];
  struct ReinputCtlSt stTmpBuf;

  UCP_TRACE(P_TPEONBH2);
  /* === for EditUnixItemToCics to skip (2+14) bytes  */
  g_pstTma->stTCFA.cReentryStatus = TMS_TXN_REENTRY;

  pstOnBth = (struct OnBthCtlSt *) pcArg1;
  pstOnBth->cOnBthRtnCode = TMS_ONBTH_NORMAL;
  ErrLog(100,"<APD>###tmsapi### enter TPEONBH2 ,dump ONBTH-CTL=",
         RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
  
  if ( pstOnBth->cFmtCode != FMT_SIF ) {
    memset(caTxnCode, 0, 10);
    memcpy(caTxnCode, pstOnBth->caTxnCode, g_iTxnCodeLen);
    iRc = ReadIet( TXN_DESC, RANDOM_READ, caTxnCode, (char *)&stTxnDesc );
    if ( iRc < 0 ) {
      sprintf( g_caMsg,"<tmsapi> TPEONBH2: invalid txn. code! %.4s",
               pstOnBth->caTxnCode);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstOnBth->cOnBthRtnCode = TMS_ONBTH_CNV_ERR;
      ErrLog(100,"<APD>###tmsapi### exit TPEONBH2 ,dump ONBTH-CTL=",
             RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
      UCP_TRACE_END( -1 );
    }
  }

  memset( caDataLen, 0, 10);
  memcpy( caDataLen, pstOnBth->caDataLen, ONBTH_DATA_LEN_SIZE);
  iDataLen = atoi( caDataLen );

  ErrLog(100,"<APD>###tmsapi### enter TPEONBH2 ,dump ONBTH-DATA=",RPT_TO_LOG,pcArg2,iDataLen);


  if ( iDataLen > MAX_SIF_LEN ) {
    sprintf( g_caMsg,"<tmsapi> TPEONBH2: invalid data length! %d",
             iDataLen);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstOnBth->cOnBthRtnCode = TMS_ONBTH_PARA_ERR;
    ErrLog(100,"<APD>###tmsapi### exit TPEONBH2 ,dump ONBTH-CTL=",
           RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
    UCP_TRACE_END( -1 );
  }
  
  switch( pstOnBth->cFmtCode ) {
    case FMT_1:
      memset(g_pstTba->caRendo,0,MAX_SIF_LEN);
      memset(&stTmpBuf,0,sizeof(struct ReinputCtlSt));
      memcpy(stTmpBuf.caDataLen,pstOnBth->caDataLen,4);
      memcpy(stTmpBuf.caTxnCode,pstOnBth->caTxnCode,4);
     
      iRc = ApDataToSif(&stTmpBuf, pcArg2, g_pstTba->caRendo);
      if ( iRc < 0 ) {
        pstOnBth->cOnBthRtnCode = TMS_ONBTH_PARA_ERR;
        sprintf( g_caMsg, "<tmsapi> TPEONBH2: ApDataToSif() error! %d",iRc);
        ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
        ErrLog(100,"<APD>###tmsapi### exit TPEONBH2 ,dump ONBTH-CTL=",
               RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
        UCP_TRACE_END( -1 );
      }    
      iSifLen = iRc;
      break;

    case FMT_2:
      memset(g_pstTba->caRendo,0,MAX_SIF_LEN);
      iRc = CtfToSif(PART_CTF_TYPE,pstOnBth->caTxnCode, 
                                              pcArg2, g_pstTba->caRendo);
      if ( iRc < 0 ) {
        pstOnBth->cOnBthRtnCode = TMS_ONBTH_CNV_ERR;
        sprintf( g_caMsg, "<tmsapi> TPEONBH2: CtfToSif() error! %d",iRc);
        ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
        ErrLog(100,"<APD>###tmsapi### exit TPEONBH2 ,dump ONBTH-CTL=",
               RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
        UCP_TRACE_END( -1 );
      }
      iSifLen = iRc;
      break;

    case FMT_CTF:
      memset(g_pstTba->caRendo,0,MAX_SIF_LEN);
      iRc = CtfToSif(CTF_TYPE,pstOnBth->caTxnCode,pcArg2,g_pstTba->caRendo);
      if ( iRc < 0 ) {
        sprintf( g_caMsg, "<tmsapi> TPEONBH2 CtfToSif error! %d",iRc);
        ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
        pstOnBth->cOnBthRtnCode = TMS_ONBTH_CNV_ERR;
        ErrLog(100,"<APD>###tmsapi### exit TPEONBH2 ,dump ONBTH-CTL=",
               RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
        UCP_TRACE_END( -1 );/*added 19960807*/
      }
      iSifLen = iRc;
      break;

    case FMT_SIF:
      memcpy(g_pstTba->caRendo,pcArg2,iDataLen);
      iSifLen = iDataLen;
      break;

    default:
      sprintf( g_caMsg, "<tmsapi> TPEONBH2 cFmtCode error! %c",
               pstOnBth->cFmtCode );
      ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
      pstOnBth->cOnBthRtnCode = TMS_ONBTH_PARA_ERR;
      ErrLog(100,"<APD>###tmsapi### exit TPEONBH2 ,dump ONBTH-CTL=",
             RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
      UCP_TRACE_END ( -1 );
  }
  sprintf(g_caMsg,"<tmsapi> TPEONBH2 after data convert,iSifLen=%d !",iSifLen);
  ErrLog( 100, g_caMsg, RPT_TO_LOG, 0, 0 );

  if(iSifLen < SIF_HEAD_LEN) {
    sprintf(g_caMsg,"<tmsapi> TPEONBH2 after data convert,iSifLen=%d < SIF_HEAD_LEN(51bytes) error!",iSifLen);
    ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
    pstOnBth->cOnBthRtnCode = TMS_ONBTH_PARA_ERR;
    ErrLog(100,"<APD>###tmsapi### exit TPEONBH2 ,dump ONBTH-CTL=",
           RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
    UCP_TRACE_END ( -1 );
  }

  /* set TPEI */
  memcpy(g_pstTba->caRendo, SIF_FMT_1, SIF_FMT_LEN);
  if ( pstOnBth->cFmtCode != FMT_SIF ) {
    memcpy(&g_pstTba->caRendo[TXN_CODE_OFFSET],
           pstOnBth->caTxnCode,g_iTxnCodeLen);
  }
  memcpy(&g_pstTba->caRendo[ BR_CODE_OFFSET ], pstOnBth->caBrhCode, 
         g_iBrhCodeLen);
  memcpy(&g_pstTba->caRendo[ TM_CODE_OFFSET ], pstOnBth->caReentryTmCode, 
         g_iTmCodeLen);
  /* if cFmtCode is FMT_SIF, teller-code doesn't be changed;
   * otherwise teller-code is the code of teller who issues the txn.
   */
  if ( pstOnBth->cFmtCode != FMT_SIF ) {
    memcpy(&g_pstTba->caRendo[ TELLER_CODE_OFFSET ], g_pstTma->stTSSA.caTellId, 
           TELLER_CODE_LEN);
  }

  /* 19951215 ---add for correcting SIF CONTROL-BYTE's supervisor bit */
  if( pstOnBth->cFmtCode != FMT_SIF ) {
    if ( pstOnBth->cFlag == '1' ) {
      /* set the reentry bit of CTL-byte in SIF to ON */ 
      memcpy(&g_pstTba->caRendo[ CTL_BYTE_OFFSET ], "\x01\x00", CTL_BYTE_LEN);
    }
    else {
      /* set CTL-byte in SIF to NORMAL */ 
      memcpy(&g_pstTba->caRendo[ CTL_BYTE_OFFSET ], "\x00\x00", CTL_BYTE_LEN);
    }
  }
  else {
    if ( pstOnBth->cFlag == '1' ) {
      g_pstTba->caRendo[CTL_BYTE_OFFSET] |= 0x01;
    }
  }

#ifdef TPE_PREPARE_REENTRY_SEQNO
  sprintf( g_caMsg, "<tmsapi> TPEONBH2 before RdWrReentrySeq !");
  ErrLog( 100, g_caMsg, RPT_TO_LOG, 0, 0 );

  /* Read REENTRY-SEQ number ...... */
  iRc=RdWtReentrySeq(RD_REENTRY_SEQ_NO,pstOnBth->caBrhCode,
                     pstOnBth->caReentryTmCode,&lBtchSeqNo,
                     g_pstTma->stTCFA.cReentryStatus);

  sprintf( g_caMsg,
           "<tmsapi> TPEONBH2 after RdWrReentrySeq lBtchSeqNo=%ld!",lBtchSeqNo);
  ErrLog( 100, g_caMsg, RPT_TO_LOG, 0, 0 );

  if ( iRc < 0 ) {
    sprintf( g_caMsg, "<tmsapi> TPEONBH2 RdWtReentrySeq (Read) error!");
    ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
    pstOnBth->cOnBthRtnCode = TMS_ONBTH_SYS_ERR;
    ErrLog(100,"<APD>###tmsapi### exit TPEONBH2 ,dump ONBTH-CTL=",
           RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
    UCP_TRACE_END ( -1 );
  }
  memset(caReentrySeqNo,0,10);
  sprintf(caReentrySeqNo,"%.*ld",5,lBtchSeqNo);
#endif 
  memset(caReentrySeqNo,0,10);
  memcpy(caReentrySeqNo,pstOnBth->caOnBthSeqNo,5);
  
  /* put BRH-CODE and REENTRY-TM-CODE and lBtchSeqNo to SIF's 1th data field */
  memcpy(caBuf,g_pstTba->caRendo+SIF_HEAD_LEN,iSifLen-SIF_HEAD_LEN);
  ucaReentryLen[0]=(unsigned char) (g_iBrhCodeLen+g_iTmCodeLen+5)/256;
  ucaReentryLen[1]=(unsigned char) (g_iBrhCodeLen+g_iTmCodeLen+5)%256;
  ucaReentryLen[2]=0x00;
  memcpy(&g_pstTba->caRendo[SIF_HEAD_LEN],ucaReentryLen,2);
  memcpy(&g_pstTba->caRendo[SIF_HEAD_LEN+2],pstOnBth->caBrhCode,g_iBrhCodeLen);
  memcpy(&g_pstTba->caRendo[SIF_HEAD_LEN+2+g_iBrhCodeLen],
         pstOnBth->caReentryTmCode,g_iTmCodeLen);
  memcpy(&g_pstTba->caRendo[SIF_HEAD_LEN+2+g_iBrhCodeLen+g_iTmCodeLen],
          caReentrySeqNo,5);
  memcpy(&g_pstTba->caRendo[SIF_HEAD_LEN+2+g_iBrhCodeLen+g_iTmCodeLen+5],
         caBuf,iSifLen-SIF_HEAD_LEN);

  /* beacuse Add ReentrySeqNo to original SIF, 
     original SIF len should be added by 7    */
  iSifLen += (2+g_iBrhCodeLen+g_iTmCodeLen+5);

  sprintf( g_caMsg, "<tmsapi> TPEONBH2 before RmtProc iSifLen=%d !",iSifLen);
  ErrLog( 100, g_caMsg, RPT_TO_LOG, 0, 0 );

  iRc = RmtProc(g_pstTba->caRendo,iSifLen,&cRmtApFlag);
  if ( iRc < 0 ) {
    /* error occurs in Client, don't add Client Reentry-Terml's BtchSeqNo */
    if ( iRc <= -1 && iRc >= -4 ) { 
      if( iRc == -4 ) {
        sprintf( g_caMsg, "<tmsapi> TPEONBH2 SndSifToServer error,iRc=%d!",iRc);
        ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
        pstOnBth->cOnBthRtnCode = TMS_ONBTH_DCS_ERR;
        ErrLog(100,"<APD>###tmsapi### exit TPEONBH2 ,dump ONBTH-CTL=",
               RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
        UCP_TRACE_END ( -1 );
      }
      else {
        sprintf(g_caMsg,
                "<tmsapi> TPEONBH2 before SndSifToServer error,iRc=%d",iRc);
        ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
        pstOnBth->cOnBthRtnCode = TMS_ONBTH_PARA_ERR;
        ErrLog(100,"<APD>###tmsapi### exit TPEONBH2 ,dump ONBTH-CTL=",
               RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
        UCP_TRACE_END ( -1 );
      }
    }
    else {
      if ( iRc == -5 ) {
        sprintf(g_caMsg,"<tmsapi> TPEONBH2 RcvHostDataToFile error,iRc=%d",iRc);
        ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
        pstOnBth->cOnBthRtnCode = TMS_ONBTH_DCS_ERR;
        ErrLog(100,"<APD>###tmsapi### exit TPEONBH2 ,dump ONBTH-CTL=",
               RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
        UCP_TRACE_END ( -1 );
      }
      else {
        sprintf( g_caMsg, "<tmsapi> TPEONBH2 system error,iRc=%d!",iRc);
        ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
        pstOnBth->cOnBthRtnCode = TMS_ONBTH_SYS_ERR;
        ErrLog(100,"<APD>###tmsapi### exit TPEONBH2 ,dump ONBTH-CTL=",
               RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
        UCP_TRACE_END ( -1 );
      }
    }
  }

#ifdef TPE_PREPARE_REENTRY_SEQNO
  /* Add BtchSeqNo by 1 */
  lBtchSeqNo++;

  /* Write REENTRY-SEQ number ...... */
  iRc=RdWtReentrySeq(WT_REENTRY_SEQ_NO,pstOnBth->caBrhCode,
                     pstOnBth->caReentryTmCode,&lBtchSeqNo,
                     g_pstTma->stTCFA.cReentryStatus);
  if ( iRc < 0 ) {
    sprintf( g_caMsg, "<tmsapi> TPEONBH2 RdWtReentrySeq (Write) error!");
    ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
    pstOnBth->cOnBthRtnCode = TMS_ONBTH_SYS_ERR;
    ErrLog(100,"<APD>###tmsapi### exit TPEONBH2 ,dump ONBTH-CTL=",
           RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
    UCP_TRACE_END ( -1 );
  }

  /* return Reentry BtchSeqNo to AP */
  memcpy(pstOnBth->caOnBthSeqNo,caReentrySeqNo,5);
#endif

#ifdef OMIT
  memset(caFileName,'\0',80);
  sprintf(caFileName,"%s/%s%.*s.%.*s",getenv("III_DIR"),"iii/log/output",
          g_iTmCodeLen, g_pstTma->stTSSA.caTmCode,
          g_iBrhCodeLen, g_pstTma->stTSSA.caBrCode);

  iFd = open(caFileName,O_RDONLY);
  if ( iFd < 0 ) {
    sprintf(g_caMsg,"<tmsapi.c> TPEONBH2 open File=%s error!",caFileName);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstOnBth->cOnBthRtnCode = TMS_ONBTH_SYS_ERR;
    UCP_TRACE_END(-1);
  }

  if ((iRc = read(iFd,caSofHeadBuf,SOF_HEAD_LEN_PLUS_2)) 
                                               == SOF_HEAD_LEN_PLUS_2) {
    sprintf(g_caMsg,"<tmsapi.c> TPEONBH2 read data bytes=%d",iRc);
    ErrLog(10,g_caMsg,RPT_TO_LOG,caSofHeadBuf,SOF_HEAD_LEN_PLUS_2);
#endif

    memcpy(caSofHeadBuf,&g_caMemBuf[sizeof(struct MemBufCtlSt)],SOF_HEAD_LEN_PLUS_2);

    iDataLen=(unsigned char)caSofHeadBuf[SOF_HEAD_LEN]*256+
             (unsigned char)caSofHeadBuf[SOF_HEAD_LEN+1];
    if ( iDataLen >= 0 ) {
      memset(caDataLen,0,10);
      sprintf(caDataLen,"%.4d",iDataLen);
      memcpy(pstOnBth->caDataLen,caDataLen,4);
    }
    else {
      sprintf(g_caMsg,"<tmsapi.c> TPEONBH2 Ej len=%d < 0!",iDataLen);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstOnBth->cOnBthRtnCode = TMS_ONBTH_SYS_ERR;
      UCP_TRACE_END(-1);
    }

    if ( (unsigned char)caSofHeadBuf[SOF_CTL_CODE_OFFSET] == 0xc0 ) {
      memcpy(pstOnBth->caOnBthTxnRtnCode,"OK  ",4);
    }
    else {
      if ( (unsigned char)caSofHeadBuf[SOF_CTL_CODE_OFFSET] == 0xc8 ) {
        if ( (caSofHeadBuf[SOF_MSG_CODE_OFFSET] == 'H' ) ||
             (caSofHeadBuf[SOF_MSG_CODE_OFFSET] == 'B' ) ){
          /* ----------  to receive CICS/TPE's SOF data  -------------  */
          memcpy(pstOnBth->caOnBthTxnRtnCode,
                 &caSofHeadBuf[SOF_MSG_CODE_OFFSET+3],4);     
        }
        else {
          /* ----------  to receive UNIX/TPE's SOF data  -------------  */
          memcpy(pstOnBth->caOnBthTxnRtnCode,
                 &caSofHeadBuf[SOF_MSG_CODE_OFFSET],4);  
        }
      }
      else {
        if ( (caSofHeadBuf[SOF_MSG_CODE_OFFSET] == 'H' ) ||
             (caSofHeadBuf[SOF_MSG_CODE_OFFSET] == 'B' ) ){
          /* ----------  to receive CICS/TPE's SOF data  -------------  */
          memcpy(pstOnBth->caOnBthTxnRtnCode,
                 &caSofHeadBuf[SOF_MSG_CODE_OFFSET+3],4);
        }
        else {
          /* ----------  to receive UNIX/TPE's SOF data  -------------  */
          memcpy(pstOnBth->caOnBthTxnRtnCode,
                 &caSofHeadBuf[SOF_MSG_CODE_OFFSET],4);  
        }
        pstOnBth->cOnBthRtnCode = TMS_ONBTH_SERVER_ERR;
        ErrLog(100,"<APD>###tmsapi### exit TPEONBH2 ,dump ONBTH-CTL=",
               RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
        UCP_TRACE_END(-1);
      }
    }

#ifdef OMIT
  }
  else {
    sprintf(g_caMsg,"<tmsapi.c> TPEONBH2 read bytes=%d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstOnBth->cOnBthRtnCode = TMS_ONBTH_SYS_ERR;
    close(iFd);
    ErrLog(100,"<APD>###tmsapi### exit TPEONBH2 ,dump ONBTH-CTL=",
           RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
    UCP_TRACE_END(-1);
  }

  close(iFd);
#endif

  ErrLog(100,"<APD>###tmsapi### exit TPEONBH2 ,dump ONBTH-CTL=",
         RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
  UCP_TRACE_END( 0 );
}

TPEONBHE(char *pcArg0, char *pcArg1, char *pcArg2)
/* pcArg0 ---> APA
   pcArg1 ---> control part "OnBthCtlSt"
   pcArg2 ---> data part                 */
{
  struct OnBthCtlSt *pstOnBth;
  int  iDataLen;
  char caDataLen[ 10 ];

  UCP_TRACE(P_TPEONBHE);
  pstOnBth = (struct OnBthCtlSt *) pcArg1;
  ErrLog(100,"<APD>###tmsapi### enter TPEONBHE ,dump ONBTH-CTL=",
         RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));

  TPEONBTH(pcArg0,pcArg1,pcArg2);
  ErrLog(100,"<APD>###tmsapi### exit TPEONBHE ,dump ONBTH-CTL=",
         RPT_TO_LOG,pstOnBth,sizeof(struct OnBthCtlSt));
  memset( caDataLen, 0, 10);
  memcpy( caDataLen, pstOnBth->caDataLen, ONBTH_DATA_LEN_SIZE);
  iDataLen = atoi( caDataLen );
  if(iDataLen > 0) {
    memcpy(pcArg2,g_pstTba->caPara,iDataLen);
    ErrLog(100,"<APD>###tmsapi### exit TPEONBHE ,dump EJ=",
           RPT_TO_LOG,pcArg2,iDataLen);
  }
  UCP_TRACE_END(0);
}


/*
 *&N& ROUTINE NAME: TPEREOUT  
 *&A& ARGUMENTS:
 *&A&  char pcApa			: Unused, only for compatiable TPE/CICS.
 *&A&  struct stReOutCtl *pstReOutCtl	: Control Area.
 *&A&                                     pstReOutCtl->caRtnCOde[0] is output
 *&A&                                     field and referenced by return code of
 *&A&                                     RdOutToOutMemory().
 *&A&           
 *&R& RETURN VALUES:
 *&R&  0 : Normal; 
 *&R&           
 *&D& DESCRIPTION:           
 *&D&   This funtion is used by reoutput previous transaction's output data from
 *&D& reoutput file. 
 */
 
TPEREOUT(char *pcApa, struct stReOutCtl *pstReOutCtl)
{
  char caFileName[256];
  int  iRc; 
   
  UCP_TRACE(P_TPEREOUT); 

  sprintf(g_caMsg,"<APD>###tmsapi### enter TPEREOUT, dump REOUT-CTL");
  ErrLog(100, g_caMsg, RPT_TO_LOG, pstReOutCtl, sizeof(struct stReOutCtl));

  sprintf(caFileName, "%s/iii/log/output%.*s.%.*s",(char *)getenv("III_DIR"), 
          g_iTmCodeLen ,g_pstTma->stTSSA.caTmCode,   
          g_iBrhCodeLen, g_pstTma->stTSSA.caBrCode);
  iRc = RdOutToOutMemory(caFileName, pstReOutCtl->caMsgpOutCode);
  pstReOutCtl->caRtnCode[0] = '0' + abs(iRc);
  
  sprintf(g_caMsg,"<APD>###tmsapi### exit TPEREOUT, dump REOUT-CTL");
  ErrLog(100, g_caMsg, RPT_TO_LOG, pstReOutCtl, sizeof(struct stReOutCtl));

  UCP_TRACE_END(0);
}



TPELTINQ(char *pcApa)
{
  int  iRc; 
   
  UCP_TRACE(P_TPELTINQ); 

  sprintf(g_caMsg,"<APD>###tmsapi### enter TPELTINQ");
  ErrLog(100, g_caMsg, RPT_TO_LOG, 0, 0);

  g_cLastQryFlag=LAST_QRY_ON; 
  
  sprintf(g_caMsg,"<APD>###tmsapi### exit TPELTINQ");
  ErrLog(100, g_caMsg, RPT_TO_LOG,0,0);

  UCP_TRACE_END(0);
}


static char s_cStartCoptxFlag='n';
extern int g_iMemFileFd;
extern char g_cFlushMemToFileFlag;

TPECOPTX(char *pcArg0, char *pcArg1, char *pcArg2)
/* pcArg0 ---> APA
   pcArg1 ---> control part "CoptxCtlSt"
   pcArg2 ---> data part                 */
{
  int  i,iRc;
  int  iDataLen;
  int  iSifLen;
  char cRmtApFlag;
  char caTxnCode[10];
  char caDataLen[ 10 ];
  unsigned char ucaSofBuf[ 2048 ];
  struct CoptxCtlSt *pstCoptx;
  txn_head stTxnDesc;   /* transaction characteristic description  */
  struct ReinputCtlSt stTmpBuf;
  struct WriteSt stMsgp;

  UCP_TRACE(P_TPECOPTX);

  pstCoptx = (struct CoptxCtlSt *) pcArg1;
  pstCoptx->cCoptxRtnCode = TMS_COPTX_NORMAL;
  ErrLog(100,"<APD>###tmsapi### enter TPECOPTX ,dump COPTX-CTL=",
         RPT_TO_LOG,pstCoptx,sizeof(struct CoptxCtlSt));

  if(pstCoptx->cFunCode == '1') {
    if(s_cStartCoptxFlag != 'n') {
      s_cStartCoptxFlag='n';
      sprintf( g_caMsg, "<tmsapi> TPECOPTX call sequence error!");
      ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
      pstCoptx->cCoptxRtnCode = TMS_COPTX_SEQ_ERR;
      ErrLog(100,"<APD>###tmsapi### exit TPECOPTX ,dump COPTX-CTL=",
             RPT_TO_LOG,pstCoptx,sizeof(struct CoptxCtlSt));
      UCP_TRACE_END ( -1 );
    }

    /* ----------   check datalen       ------------------------- */
    for(i=0;i<4;i++) {
      if(pstCoptx->caDataLen[i]<'0' || pstCoptx->caDataLen[i]>'9') break;
    }
    if(i<4) {
      sprintf( g_caMsg,"<tmsapi> TPECOPTX: invalid caDataLen=%.*s",
               4,pstCoptx->caDataLen);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstCoptx->cCoptxRtnCode = TMS_COPTX_PARA_ERR;
      UCP_TRACE_END( -1 );
    }
    /* ----------   check datalen       ------------------------- */
    
    if ( pstCoptx->cFmtCode != FMT_SIF ) {
      memset(caTxnCode, 0, 10);
      memcpy(caTxnCode, pstCoptx->caTxnCode, g_iTxnCodeLen);
      iRc = ReadIet( TXN_DESC, RANDOM_READ, caTxnCode, (char *)&stTxnDesc );
      if ( iRc < 0 ) {
        sprintf( g_caMsg,"<tmsapi> TPECOPTX: invalid txn. code! %.4s",
                 pstCoptx->caTxnCode);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        pstCoptx->cCoptxRtnCode = TMS_COPTX_CNV_ERR;
        ErrLog(100,"<APD>###tmsapi### exit TPECOPTX ,dump COPTX-CTL=",
               RPT_TO_LOG,pstCoptx,sizeof(struct CoptxCtlSt));
        UCP_TRACE_END( -1 );
      }
    }

    memset( caDataLen, 0, 10);
    memcpy( caDataLen, pstCoptx->caDataLen, 4);
    iDataLen = atoi( caDataLen );
  
    ErrLog(100,"<APD>###tmsapi### enter TPECOPTX ,dump COPTX-DATA=",
           RPT_TO_LOG,pcArg2,iDataLen);
  
  
    if ( iDataLen > MAX_SIF_LEN ) {
      sprintf( g_caMsg,"<tmsapi> TPECOPTX: invalid data length! %d",
               iDataLen);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstCoptx->cCoptxRtnCode = TMS_COPTX_PARA_ERR;
      ErrLog(100,"<APD>###tmsapi### exit TPECOPTX ,dump COPTX-CTL=",
             RPT_TO_LOG,pstCoptx,sizeof(struct CoptxCtlSt));
      UCP_TRACE_END( -1 );
    }
  
    switch( pstCoptx->cFmtCode ) {
      case FMT_1:
        memset(g_pstTba->caRendo,0,MAX_SIF_LEN);
        memset(&stTmpBuf,0,sizeof(struct ReinputCtlSt));
        memcpy(stTmpBuf.caDataLen,pstCoptx->caDataLen,4);
        memcpy(stTmpBuf.caTxnCode,pstCoptx->caTxnCode,4);
     
        iRc = ApDataToSif(&stTmpBuf, pcArg2, g_pstTba->caRendo);
        if ( iRc < 0 ) {
          pstCoptx->cCoptxRtnCode = TMS_COPTX_PARA_ERR;
          sprintf( g_caMsg, "<tmsapi> TPECOPTX: ApDataToSif() error! %d",iRc);
          ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
          ErrLog(100,"<APD>###tmsapi### exit TPECOPTX ,dump COPTX-CTL=",
                 RPT_TO_LOG,pstCoptx,sizeof(struct CoptxCtlSt));
          UCP_TRACE_END( -1 );
        }    
        iSifLen = iRc;
        break;

      case FMT_2:
        memset(g_pstTba->caRendo,0,MAX_SIF_LEN);
        iRc = CtfToSif(PART_CTF_TYPE,pstCoptx->caTxnCode, 
                                                pcArg2, g_pstTba->caRendo);
        if ( iRc < 0 ) {
          pstCoptx->cCoptxRtnCode = TMS_COPTX_CNV_ERR;
          sprintf( g_caMsg, "<tmsapi> TPECOPTX: CtfToSif() error! %d",iRc);
          ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
          ErrLog(100,"<APD>###tmsapi### exit TPECOPTX ,dump COPTX-CTL=",
                 RPT_TO_LOG,pstCoptx,sizeof(struct CoptxCtlSt));
          UCP_TRACE_END( -1 );
        }
        iSifLen = iRc;
        break;
  
      case FMT_CTF:
        memset(g_pstTba->caRendo,0,MAX_SIF_LEN);
        iRc = CtfToSif(CTF_TYPE,pstCoptx->caTxnCode,pcArg2,g_pstTba->caRendo);
        if ( iRc < 0 ) {
          sprintf( g_caMsg, "<tmsapi> TPECOPTX CtfToSif error! %d",iRc);
          ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
          pstCoptx->cCoptxRtnCode = TMS_COPTX_CNV_ERR;
          ErrLog(100,"<APD>###tmsapi### exit TPECOPTX ,dump COPTX-CTL=",
                 RPT_TO_LOG,pstCoptx,sizeof(struct CoptxCtlSt));
          UCP_TRACE_END( -1 );/*added 19960807*/
        }
        iSifLen = iRc;
        break;
  
      case FMT_SIF:
        memcpy(g_pstTba->caRendo,pcArg2,iDataLen);
        iSifLen = iDataLen;
        break;

      default:
        sprintf( g_caMsg, "<tmsapi> TPECOPTX cFmtCode error! %c",
                 pstCoptx->cFmtCode );
        ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
        pstCoptx->cCoptxRtnCode = TMS_COPTX_PARA_ERR;
        ErrLog(100,"<APD>###tmsapi### exit TPECOPTX ,dump COPTX-CTL=",
               RPT_TO_LOG,pstCoptx,sizeof(struct CoptxCtlSt));
        UCP_TRACE_END ( -1 );
    }
    sprintf(g_caMsg,"<tmsapi> TPECOPTX after data convert,iSifLen=%d !",
            iSifLen);
    ErrLog( 100, g_caMsg, RPT_TO_LOG, 0, 0 );

    if(iSifLen < SIF_HEAD_LEN) {
      sprintf(g_caMsg,"<tmsapi> TPECOPTX after data convert,iSifLen=%d < SIF_HEAD_LEN(51bytes) error!",iSifLen);
      ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
      pstCoptx->cCoptxRtnCode = TMS_COPTX_PARA_ERR;
      ErrLog(100,"<APD>###tmsapi### exit TPECOPTX ,dump COPTX-CTL=",
             RPT_TO_LOG,pstCoptx,sizeof(struct CoptxCtlSt));
      UCP_TRACE_END ( -1 );
    }

    /* set TPEI */
    memcpy(g_pstTba->caRendo, SIF_FMT_1, SIF_FMT_LEN);
    if ( pstCoptx->cFmtCode != FMT_SIF ) {
      memcpy(&g_pstTba->caRendo[TXN_CODE_OFFSET],
             pstCoptx->caTxnCode,g_iTxnCodeLen);
    }
    memcpy(&g_pstTba->caRendo[ BR_CODE_OFFSET ], pstCoptx->caBrhCode, 
           g_iBrhCodeLen);
    memcpy(&g_pstTba->caRendo[ TM_CODE_OFFSET ], pstCoptx->caTmCode, 
           g_iTmCodeLen);
    /* if cFmtCode is FMT_SIF, teller-code doesn't be changed;
     * otherwise teller-code is the code of teller who issues the txn.
     */
    if ( pstCoptx->cFmtCode != FMT_SIF ) {
      memcpy(&g_pstTba->caRendo[ TELLER_CODE_OFFSET ],
             g_pstTma->stTSSA.caTellId,TELLER_CODE_LEN);
    } 

    /* 19951215 ---add for correcting SIF CONTROL-BYTE's supervisor bit */
    if( pstCoptx->cFmtCode != FMT_SIF ) {
      /* set CTL-byte in SIF to NORMAL */ 
      memcpy(&g_pstTba->caRendo[ CTL_BYTE_OFFSET ], "\x00\x00", CTL_BYTE_LEN);
    }

    sprintf( g_caMsg, "<tmsapi> TPECOPTX before RmtProc iSifLen=%d !",iSifLen);
    ErrLog( 100, g_caMsg, RPT_TO_LOG, 0, 0 );

    iRc = RmtProc(g_pstTba->caRendo,iSifLen,&cRmtApFlag);
    if ( iRc < 0 ) {
      /* error occurs in Client, don't add Client Reentry-Terml's BtchSeqNo */
      if ( iRc <= -1 && iRc >= -4 ) { 
        if( iRc == -4 ) {
          sprintf(g_caMsg,"<tmsapi> TPECOPTX SndSifToServer error,iRc=%d!",iRc);
          ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
          pstCoptx->cCoptxRtnCode = TMS_COPTX_DCS_ERR;
          ErrLog(100,"<APD>###tmsapi### exit TPECOPTX ,dump COPTX-CTL=",
                 RPT_TO_LOG,pstCoptx,sizeof(struct CoptxCtlSt));
          UCP_TRACE_END ( -1 );
        }
        else {
          sprintf(g_caMsg,
                  "<tmsapi> TPECOPTX before SndSifToServer error,iRc=%d",iRc);
          ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
          pstCoptx->cCoptxRtnCode = TMS_COPTX_PARA_ERR;
          ErrLog(100,"<APD>###tmsapi### exit TPECOPTX ,dump COPTX-CTL=",
                 RPT_TO_LOG,pstCoptx,sizeof(struct CoptxCtlSt));
          UCP_TRACE_END ( -1 );
        }
      }
      else {
        if ( iRc == -5 ) {
          sprintf(g_caMsg,
                  "<tmsapi> TPECOPTX RcvHostDataToFile error,iRc=%d",iRc);
          ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
          pstCoptx->cCoptxRtnCode = TMS_COPTX_DCS_ERR;
          ErrLog(100,"<APD>###tmsapi### exit TPECOPTX ,dump COPTX-CTL=",
                 RPT_TO_LOG,pstCoptx,sizeof(struct CoptxCtlSt));
          UCP_TRACE_END ( -1 );
        }
        else {
          sprintf( g_caMsg, "<tmsapi> TPECOPTX system error,iRc=%d!",iRc);
          ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
          pstCoptx->cCoptxRtnCode = TMS_COPTX_SYS_ERR;
          ErrLog(100,"<APD>###tmsapi### exit TPECOPTX ,dump COPTX-CTL=",
                 RPT_TO_LOG,pstCoptx,sizeof(struct CoptxCtlSt));
          UCP_TRACE_END ( -1 );
        }
      }
    }

    /*
     * when remote txn has more 40k data , MemWrite function will flush all 
     * data to output??.####### file.
     * So, call MemClose() to close MemFileFd and set g_cFlushMemToFileFlag='y'
     */
    iRc=MemClose();  /* defined in tmsoutpt.c */
    if(iRc < 0) {
      sprintf( g_caMsg, "<tmsapi> TPECOPTX system error,iRc=%d!",iRc);
      ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
      pstCoptx->cCoptxRtnCode = TMS_COPTX_SYS_ERR;
      ErrLog(100,"<APD>###tmsapi### exit TPECOPTX ,dump COPTX-CTL=",
             RPT_TO_LOG,pstCoptx,sizeof(struct CoptxCtlSt));
      UCP_TRACE_END ( -1 );
    }

    iRc=FetchNextSof(ucaSofBuf,&iDataLen,'y');
    if(iRc == -99 || iRc == -1) {
      sprintf( g_caMsg, "<tmsapi> TPECOPTX system error,iRc=%d!",iRc);
      ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
      pstCoptx->cCoptxRtnCode = TMS_COPTX_SYS_ERR;
      ErrLog(100,"<APD>###tmsapi### exit TPECOPTX ,dump COPTX-CTL=",
             RPT_TO_LOG,pstCoptx,sizeof(struct CoptxCtlSt));
      UCP_TRACE_END ( -1 );
    }

    if(ucaSofBuf[SOF_CTL_CODE_OFFSET] & 0x08) {
       memcpy(pstCoptx->caCoptxTxnRtnCode,
              &ucaSofBuf[SOF_MSG_CODE_OFFSET+3],4);     
       pstCoptx->cMoreFlag='0';
       pstCoptx->cCoptxRtnCode=TMS_COPTX_NORMAL;
       memcpy(pstCoptx->caDataLen,"0000",4);
    }
    else {
       memcpy(pstCoptx->caCoptxTxnRtnCode,"OK  ",4);     
       pstCoptx->cCoptxRtnCode=TMS_COPTX_NORMAL;
       /* TPECOPTX doesn't transmit the EJ embeded in the control-SOF */
       memcpy(pstCoptx->caDataLen,"0000",4);
       if(ucaSofBuf[SOF_CTL_CODE_OFFSET] & 0x02) {
         pstCoptx->cMoreFlag='1';
         s_cStartCoptxFlag='y';
       }
       else {
         pstCoptx->cMoreFlag='0';
       }
       if( ucaSofBuf[SOF_CTL_CODE_OFFSET] & 0x20 ) {
         while( 1 ) {
           iRc=FetchNextSof(ucaSofBuf,&iDataLen,'n');
           if(iRc == -99 || iRc == -1) {
             sprintf( g_caMsg, "<tmsapi> TPECOPTX system error,iRc=%d!",iRc);
             ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
             pstCoptx->cCoptxRtnCode = TMS_COPTX_SYS_ERR;
             ErrLog(100,"<APD>###tmsapi### exit TPECOPTX ,dump COPTX-CTL=",
                    RPT_TO_LOG,pstCoptx,sizeof(struct CoptxCtlSt));
             UCP_TRACE_END ( -1 );
           }
           if(ucaSofBuf[SOF_CTL_CODE_OFFSET] & 0x80) break;
         }
       }
    }
  }
  else {
    if(pstCoptx->cFunCode == '2') {
      if(s_cStartCoptxFlag != 'y') {
        sprintf( g_caMsg, "<tmsapi> TPECOPTX call sequence error!");
        ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
        pstCoptx->cCoptxRtnCode = TMS_COPTX_SEQ_ERR;
        ErrLog(100,"<APD>###tmsapi### exit TPECOPTX ,dump COPTX-CTL=",
               RPT_TO_LOG,pstCoptx,sizeof(struct CoptxCtlSt));
        UCP_TRACE_END ( -1 );
      }

      iRc=FetchNextSof(ucaSofBuf,&iDataLen,'n');
      if(iRc == -99) {
        sprintf( g_caMsg, "<tmsapi> TPECOPTX system error,iRc=%d!",iRc);
        ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
        pstCoptx->cCoptxRtnCode = TMS_COPTX_SYS_ERR;
        ErrLog(100,"<APD>###tmsapi### exit TPECOPTX ,dump COPTX-CTL=",
               RPT_TO_LOG,pstCoptx,sizeof(struct CoptxCtlSt));
        UCP_TRACE_END ( -1 );
      }

      if(iRc < 0) {
        pstCoptx->cCoptxRtnCode=TMS_COPTX_NOMORE_ERR;
        pstCoptx->cMoreFlag='0';
        ErrLog(100,"<APD>###tmsapi### exit TPECOPTX ,dump COPTX-CTL=",
                 RPT_TO_LOG,pstCoptx,sizeof(struct CoptxCtlSt));
        UCP_TRACE_END ( -1 );
      }
      else { 
        pstCoptx->cCoptxRtnCode=TMS_COPTX_NORMAL;
        if(iRc > 0) {
          pstCoptx->cMoreFlag='1';
        }
        else {
          pstCoptx->cMoreFlag='0';
          s_cStartCoptxFlag = 'n';
        }

        iRc = CnvSofToMsgp(ucaSofBuf, &stMsgp);
        if(iRc < 0) {
          sprintf(g_caMsg, "<tmsapi> TPECOPTX SOF data_len=%d is over 2000",
                  iDataLen-SOF_HEAD_LEN_PLUS_2);
          ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0 );
          pstCoptx->cCoptxRtnCode = TMS_COPTX_CNVOUT_ERR;
          ErrLog(100,"<APD>###tmsapi### exit TPECOPTX ,dump COPTX-CTL=",
                 RPT_TO_LOG,pstCoptx,sizeof(struct CoptxCtlSt));
          UCP_TRACE_END ( -1 );
        }
        sprintf(caDataLen,"%.4d",10+iDataLen-SOF_HEAD_LEN_PLUS_2);
        memcpy(pstCoptx->caDataLen,caDataLen,4);
        memcpy(pcArg2,(char *) &stMsgp,10+iDataLen-SOF_HEAD_LEN_PLUS_2);
      }
    }
    else {
      sprintf( g_caMsg, "<tmsapi> TPECOPTX cFunCode=[%c] error!",
               pstCoptx->cFunCode);
      ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
      pstCoptx->cCoptxRtnCode = TMS_COPTX_PARA_ERR;
      ErrLog(100,"<APD>###tmsapi### exit TPECOPTX ,dump COPTX-CTL=",
             RPT_TO_LOG,pstCoptx,sizeof(struct CoptxCtlSt));
      UCP_TRACE_END ( -1 );
    }
  }

  ErrLog(100,"<APD>###tmsapi### exit TPECOPTX ,dump COPTX-CTL=",
         RPT_TO_LOG,pstCoptx,sizeof(struct CoptxCtlSt));
  UCP_TRACE_END( 0 );
}


/*
 *&N& ROUNTINE NAME : FetchNextSof()
 *&A& ARGUMENTS: �L
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ < 0 
 *&R&
 *&D& DESCRIPTION:
 *&D&   1: more SOF 
 *&D&   0: last SOF
 *&D&  -1: no SOF
 *&D&  -99: system error
 *&D&
 */
int
FetchNextSof(unsigned char *pcaSofBuf,int *piSofLen,char cFirstFlag)
{
  int iRc;
  struct  MemBufCtlSt *pstMemBufCtl;
  int iDataLen; 
  static int s_iCurOffset=0;
  char  caMemFileName[256];
  
  if(cFirstFlag == 'y') {
    s_iCurOffset = sizeof(struct MemBufCtlSt);
    if(g_cFlushMemToFileFlag == 'y') {
      g_iMemFileFd=OpenOutputFile();
      if (g_iMemFileFd < 0 ) {
        sprintf(g_caMsg,"FetchNextSof() :open error!");
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        return(-99);
      } 
    }
  }
  pstMemBufCtl = (struct MemBufCtlSt *)&g_stMemBufCtl ;

  if(g_cFlushMemToFileFlag != 'y') {
    if (s_iCurOffset >= pstMemBufCtl->iNextOffset) {
      *piSofLen=0;
      return( -1 ); 
    } 
    else {
      while((memcmp(&g_caMemBuf[s_iCurOffset+SOF_OUT_DEV_OFFSET],
                                                      "@@@@@@@@",8)==0)) {
        s_iCurOffset += SOF_HEAD_LEN_PLUS_2;  
      }
      iDataLen=(unsigned char)g_caMemBuf[s_iCurOffset+SOF_DATA_LEN_OFFSET]*256
              +(unsigned char)g_caMemBuf[s_iCurOffset+SOF_DATA_LEN_OFFSET+1];
      *piSofLen=iDataLen+SOF_HEAD_LEN_PLUS_2;
      memcpy(pcaSofBuf,&g_caMemBuf[s_iCurOffset],SOF_HEAD_LEN_PLUS_2+iDataLen);
      s_iCurOffset += (SOF_HEAD_LEN_PLUS_2+iDataLen);
      if (s_iCurOffset >= pstMemBufCtl->iNextOffset) {
        return( 0 ); 
      }
      else {
        return( 1 );
      }
    }
  }
  else {
    if (s_iCurOffset >= pstMemBufCtl->iNextOffset) {
      *piSofLen=0;
      return( -1 ); 
    }
    else {
      iRc=ReadFile(g_iMemFileFd,s_iCurOffset,
               &g_caMemBuf[sizeof(struct MemBufCtlSt)],SOF_HEAD_LEN_PLUS_2);
      if(iRc < 0) {
        sprintf(g_caMsg,"FetchNextSof() :g_iMemFileFd=%d",g_iMemFileFd);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        return(-99);
      }

      while((memcmp(&g_caMemBuf[sizeof(struct MemBufCtlSt)+SOF_OUT_DEV_OFFSET],
                                                      "@@@@@@@@",8)==0)) {
        s_iCurOffset += SOF_HEAD_LEN_PLUS_2;

        iRc=ReadFile(g_iMemFileFd,s_iCurOffset,
                 &g_caMemBuf[sizeof(struct MemBufCtlSt)],SOF_HEAD_LEN_PLUS_2);
        if(iRc < 0) {
          return(-99);
        }
      }

      iDataLen=(unsigned char)g_caMemBuf[sizeof(struct MemBufCtlSt)+SOF_DATA_LEN_OFFSET]*256+(unsigned char)g_caMemBuf[sizeof(struct MemBufCtlSt)+SOF_DATA_LEN_OFFSET+1];

      iRc=ReadFile(g_iMemFileFd,s_iCurOffset,
         &g_caMemBuf[sizeof(struct MemBufCtlSt)],iDataLen+SOF_HEAD_LEN_PLUS_2);
      if(iRc < 0) {
        return(-99);
      }

      *piSofLen=iDataLen+SOF_HEAD_LEN_PLUS_2;
      memcpy(pcaSofBuf,&g_caMemBuf[sizeof(struct MemBufCtlSt)],
                                              SOF_HEAD_LEN_PLUS_2+iDataLen);
      s_iCurOffset += (SOF_HEAD_LEN_PLUS_2+iDataLen);
      if (s_iCurOffset >= pstMemBufCtl->iNextOffset) {
        return( 0 ); 
      }
      else {
        return( 1 );
      }
    }
  }
}

void
InitCoptxFlag()
{
  s_cStartCoptxFlag = 'n';
}
