/*
 *&N& File: tmmain.c  ����޲z�l�t�ΥD�{��
 *&N&   
 *&N&    TYPE      NAME                 DESCRIPTION
 *&N& --------- ---------- ---------------------------------------- 
 *&N&    int       main    ����޲z�l�t�ΥD�{��
 *&N&
 */

/* ---------------------- INCLUDE FILES DECLARATION ------------------- */
#include	"errlog.h"
#include "tmcpgdef.h"	/* TMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */
#include "tms.h"
#include "ucp.h"
/* -------------------------------------------------------------------- */


/* ------------------------- CONSTANT DEFINITION ---------------------- */
/*
#define		P_Mtmmain                20000
*/

#define		UCP_SYSTEM                 'S'
#define		TMS_SUB_SYSTEM             '2'
#define		ENVSETUP_STEP              '1'
#define		FLTXRLBK_STEP              '2'
#define		TXINIT_STEP                '3'
#define		TXINPUT_STEP               '4'
#define		TXSTART_STEP               '5'
#define		TXPROCES_STEP              '6'
#define		TXEND_STEP                 '7'
#define		TXOUTPUT_STEP              '8'
#define		TXRELESE_STEP              '9'

/* -------------------------------------------------------------------- */


/* -----------------  GLOBAL VARIABLES DECLARATION -------------- */
int g_iTwaKey;
int g_iCwaKey;
int g_iCtfKey;
int g_iIctKey;
int g_iDbtKey;
int g_iIetKey;
int g_iSysOpMode;
int g_iTestMode;
int g_iMaxPacketSize;
int g_iTmax;
int g_iTmin;
int g_iToffset;
int g_iPiggyBackSize;
int g_iTcumTpuSleep;   /* the cumulative time of TPU sleep */
int g_iTapAlarm;       /* the amount of time used to detect ap each time */
int g_iTtxnTimeout;    /* the total amount of time elapsed in a transaction 
                          (perhaps including 2 or above AP processes),
                          excluding the time elapsed in TPE's API */

char *g_pcCtf;
char *g_pcIet;
char *g_pcIct;

struct TMA *g_pstTma;
struct COA *g_pstCoa;
struct TBA *g_pstTba;
struct APA *g_pstApa;
struct TCT *g_pstTctTbl;

int g_iBrhCodeLen;
int g_iTmCodeLen ;
int g_iTxnCodeLen ;
int g_iTellerCodeLen ;
int g_iSifLen ;   /* add by JessWu 19950127 */
char g_cDebugFlag;
char g_cOnBthTxn;
char g_caReinputBuffer[MAX_SIF_LEN + SOF_HEAD_LEN_PLUS_2];

int g_iMsgpFileFd=-1;
int g_iMemFileFd=-1;
char g_cFlushMemToFileFlag='n';
char g_cNeedRelseTrm='n';

/* BIT 1 :
 *        when TPE receives SIF , bit is set to ON.   
 *        when TPE sends data to AP over, bit is set to OFF.
 * BIT 2 :
 *        when TPE strats txn , bit is set to ON
 *        when TPE ends txn , bit is set to OFF
 *
 *   (ERROR ACTION: REFERENCE FLAG)
 *   00111111
 *     ^^^^^^
 *     ||||||-----> when TPE needs to report to teller, bit is set to ON.
 *     |||||------> when TPE needs to do rollback, bit is set to ON.
 *     ||||-------> when TPE needs to report TPE monitor, bit is set to ON.
 *     |||--------> when TPE needs to abend, bit is set to ON.
 *     || --------> when TPE needs to kill AP, bit is set to ON.
 *     |----------> when TPE needs to abort DCS session.
 */
char g_cErrActFlag = 0x00;
char g_cTmsForkedFail='1';
/* -------------------------------------------------------------------- */


/* ------ CALLED FUNCTION AND SUBROUTINE PROTOTYPE DECLARATIONS ------- */
int   SetServerId(char *); /* save Server Id to TWA   */
int   SetSysMode(char);    /* save System mode to TWA */
int   EnvSetup(char *);
int   FlTxRlbk(char *);
int   TxInit(char *);
int   TxInput(char *);
int   TxStart(char *);
int   TxProces(char *);
int   TxEnd(char *);
int   TxOutput(char *);
int   TxRelese(char *);
int   ErrorRpt(char, char, char, char, int);
/* -------------------------------------------------------------------- */

/*
 *&N& ROUTINE NAME: main  
 *&A& ARGUMENTS:
 *&A&     int iArgCnt;       �������޲z�l�t�ΥD�{���ҿ�J���ѼƭӼ�
 *&A&     char *pcaArgV[];   �������޲z�l�t�ΥD�{���ҿ�J���Ѽư}�C
 *&A&           pcaArgV[0]:  �������ɦW��
 *&A&           pcaArgV[1]:  Server Id (two bytes) ( '00' - '99' )
 *&A&           pcaArgV[2]:  Destination code defined in server.dat
 *&A&           pcaArgV[3]:  �����檺����Ҧ�
 *&A&                        '0' : ���� Online  mode
 *&A&                        '1' : ���� Batch   mode
 *&A&                        '2' : ���� Special mode
 *&A&           pcaArgV[4]:  ���O�_��debug mode
 *&A&                        '0' :����debug mode, �|�Pems���q�}���᪺���p       
 *&A&                        '1' :��debug mode,���|�Pems���q�}���᪺���p       
 *&A&           
 *&A&           
 *&R& RETURN VALUES:
 *&R&           
 *&R&           
 *&D& DESCRIPTION:           
 *&D&     ����Ƭ�����޲z�l�t�ΥD�{��, �t�d�إߥ���޲z�����ҤΥ���y
 *&D& �{���޲z, �æP�ɫO�������ƪ����T�ʻP�@�P�ʡC 
 *&D&           
 */
 
main(int iArgCnt, char *pcaArgV[])
{
  int iRc;          /* return code of function. */
  char cL2Step='0'; /* step of level 2; '1' is step 1, '2' is step 2, etc */ 
  char caLogName[256];

  /*
   * UCP_TRACE(P_Mtmmain);
   */

  /* check iArgCnt */
  if (iArgCnt != 5){
     printf("Usage:%s ServerId DestinationCode SysMode DebugMode\n",pcaArgV[0]);
     exit(1);
  }
  if ( strcmp("TOPEND", getenv("III_PROTOCOL") ) == 0 ){
    strcpy(caLogName, "tms_errlog");
  }else{
    sprintf(caLogName, "%s/iii/log/tms_errlog", getenv("III_DIR") );
  }
  ChgLog(LOG_CHG_MODE,"1");
  ChgLog(LOG_CHG_LOG,caLogName);

  /* save pcaArgV to TWA */
  SetServerId(pcaArgV[1]);    /* save Server Id to TWA   */

  if(pcaArgV[2] == NULL) {
     printf("DestinationCode=%s must be defined\n",pcaArgV[2]);
     printf("Usage:%s ServerId DestinationCode SysMode DebugMode\n",pcaArgV[0]);
     exit(1);
  }
  else {
    SetDestinationCode(pcaArgV[2]);
  }
 
  SetSysMode(pcaArgV[3][0]);  /* save System mode to TWA */
  if ( pcaArgV[3][0] != ONLINE_MODE ) {
     printf("Usage:%s ServerId DestinationCode SysMode DebugMode\n",pcaArgV[0]);
     printf("%s argument[3]:SysMode=%c error!\n", pcaArgV[0],pcaArgV[3][0]);
     printf("Please check argument[3]: SysMode must be ['0'->ONLINE_MODE]\n");
     exit(1);
  }
  g_cDebugFlag = pcaArgV[4][0];

  /* Environment Setup */
  iRc = EnvSetup(&cL2Step);
  if (iRc < 0){
    ErrorRpt(UCP_SYSTEM, TMS_SUB_SYSTEM, ENVSETUP_STEP, cL2Step, iRc); 
    sprintf(g_caMsg, "P_main:EnvSetup error, return code=%d.", iRc);
    ErrLog(40000, g_caMsg, RPT_TO_LOG|RPT_TO_TTY, 0, 0);
  }
  g_cTmsForkedFail = '0';
  g_cNeedRelseTrm = 'n';

  /* Flight Txn RollBack */
  iRc = FlTxRlbk(&cL2Step);
  if (iRc < 0){
    ErrorRpt(UCP_SYSTEM, TMS_SUB_SYSTEM, FLTXRLBK_STEP, cL2Step, iRc);
    sprintf(g_caMsg, "P_main:FlTxRlbk error, return code=%d.", iRc);
    ErrLog(40000, g_caMsg, RPT_TO_LOG|RPT_TO_TTY, 0, 0);
  }


  /* while(1) for replace <goto> function */
  while( 1 ) {

    /* while loop for serving client request. */
    while(1){

      /* Initialization of each Txn. */
      iRc = TxInit(&cL2Step);
      if (iRc < 0){
        ErrorRpt(UCP_SYSTEM, TMS_SUB_SYSTEM, TXINIT_STEP, cL2Step, iRc);
        sprintf(g_caMsg, "P_main:TxInit error, return code=%d.", iRc);
        ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
        break;
      }
    
      /* Process Txn Input data */ 
      iRc = TxInput(&cL2Step);
      if (iRc < 0){
        ErrorRpt(UCP_SYSTEM, TMS_SUB_SYSTEM, TXINPUT_STEP, cL2Step, iRc);
        sprintf(g_caMsg, "P_main:TxInput error, return code=%d.", iRc);
        ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
        break;
      }
 
      /* Process Txn Start */ 
      iRc = TxStart(&cL2Step);
      if (iRc < 0){
        ErrorRpt(UCP_SYSTEM, TMS_SUB_SYSTEM, TXSTART_STEP, cL2Step, iRc);
        sprintf(g_caMsg, "P_main:TxBegin error, return code=%d.", iRc);
        ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
        break;
      }
  
      /* Txn Process */
      iRc = TxProces(&cL2Step);
      if (iRc < 0){
        ErrorRpt(UCP_SYSTEM, TMS_SUB_SYSTEM, TXPROCES_STEP, cL2Step, iRc);
        sprintf(g_caMsg, "P_main:TxProces error, return code=%d.", iRc);
        ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
        break;
      }
  
      /* Process Txn End */
      iRc = TxEnd(&cL2Step);
      if (iRc < 0){
        ErrorRpt(UCP_SYSTEM, TMS_SUB_SYSTEM, TXEND_STEP, cL2Step, iRc);
        sprintf(g_caMsg, "P_main:TxEnd error, return code=%d.", iRc);
        ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
        break;
      }
      
      if ( iRc == TXN_OVER || iRc == TXN_ERROR_COMMIT ||
           iRc == TXN_ERROR_ROLLBK ) {
        /* Output Txn result to client */ 
        iRc = TxOutput(&cL2Step);
        if (iRc < 0){
          ErrorRpt(UCP_SYSTEM, TMS_SUB_SYSTEM, TXOUTPUT_STEP, cL2Step, iRc);
          sprintf(g_caMsg, "P_main:TxOutput error, return code=%d.", iRc);
          ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
          break;
        }
      }
/*   mark by WuChihLiang 19950330 for doing TxRelese per-AP   
      else {
        continue;
      } */
  
      /* Release resource for each Application Program */
      iRc = TxRelese(&cL2Step);
      if (iRc < 0){
        ErrorRpt(UCP_SYSTEM, TMS_SUB_SYSTEM, TXRELESE_STEP, cL2Step, iRc);
        sprintf(g_caMsg, "P_main:TxRelese error, return code=%d.", iRc);
        ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
        break;
      }

    } /* end of while(1) */

    iRc = TmsErrHdl(cL2Step,iRc);

  } /* end of while(1) for replace <goto> function */

}/* end of main */
