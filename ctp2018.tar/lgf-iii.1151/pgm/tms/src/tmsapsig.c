
/*
 *&N& File : tmsapsig.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int       ApSignalSet()            �T���]�w�P�B�z
 *&N&    int       ApSigHdl()               �T���B�z�`��
 *&N&    int       AbendRtn()               �T���B�z�`��
 */

/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include <signal.h>
#include <termio.h>
#include <fcntl.h>
#include "errlog.h"
#include "tmcpgdef.h"	/* TMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */

/* -------------------- CONSTANT DEFINE  --------------------------- */
/*
#define  P_ApSignalSet      25701
#define  P_ApSigHdl         25702
#define  P_AbendRtn         25703
*/

#define SIGNAL_NUM          28
#define AP_ABEND_END        '0'
/* -------------------- STATIC GLOBAL DECLARATION ------------------ */
int iaSignal[ SIGNAL_NUM ] = {
	           SIGHUP,
	           SIGINT,
	           SIGQUIT,
	           SIGILL,	
	           SIGTRAP,
                   SIGABRT,
	           SIGEMT,
	           SIGFPE,
	           SIGKILL,
	           SIGBUS,	
	           SIGSEGV,	
	           SIGSYS,
	           SIGPIPE,
	           SIGALRM,
	           SIGTERM,
	           SIGUSR1,
	           SIGUSR2,
	           SIGCLD,	
	           SIGPWR,	
                   SIGWINCH, 
/* mark for SCO Unix
                   SIGURG,	
*/
/* Mark for AIX Unix
                   SIGPOLL, 
*/
                   SIGSTOP,
                   SIGTSTP,
                   SIGCONT,
                   SIGTTIN,
                   SIGTTOU,
                   SIGVTALRM,
                   SIGPROF
                 };


/* ------ CALL FUNCTION & SUBROUTINE PROTOTYPE DECLARATIONS -------- */
extern int ApEnvRls();


/*
 *&N& ROUTINE NAME: ApSignalSet()
 *&A& ARGUMENTS:
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&   �T���]�w�P�B�z
 */

int
ApSignalSet()
{
  int i;
  int iSignalCnt;
  void ApSigHdl();

  UCP_TRACE(P_ApSignalSet);
  /*
   * set new signal handler routines
   */
  iSignalCnt = sizeof( iaSignal ) / sizeof( int );

  for (i = 0; i < iSignalCnt; i ++) {
    signal( iaSignal[ i ], ApSigHdl );
  }

  UCP_TRACE_END( 0 );
}

/*
 *&N& ROUTINE NAME: ApSigHdl()
 *&A& ARGUMENTS:
 *&A&     NAME          TYPE                        DESCRIPTION
 *&A&   ----------------------------------------------------------
 *&A&    iSigNo         int                         �T�����X
 *&A&
 *&R& RETURN VALUE(S):
 *&R&
 *&D& DESCRIPTION:
 *&D&   �T���B�z�`��:
 *&D&   1.�O������t�Ϊ����ӰT������~�O����.
 *&D&   2.�I�s���`�B�z�����}�{��.
 */

static void
ApSigHdl( int iSigNo )
{

  switch( iSigNo ) {
    case SIGHUP:
         ErrLog(99901,"signal SIGHUP occured",RPT_TO_LOG  ,0,0);
         break;
    case SIGINT:
         ErrLog(99902,"signal SIGINT occured",RPT_TO_LOG  ,0,0);
         break;
    case SIGQUIT:
         ErrLog(99903,"signal SIGQUIT occured",RPT_TO_LOG  ,0,0);
         break;
    case SIGILL:
         ErrLog(99904,"signal SIGILL occured",RPT_TO_LOG  ,0,0);
         break;
    case SIGTRAP:
         ErrLog(99905,"signal SIGTRAP occured",RPT_TO_LOG  ,0,0);
         break;
    case SIGABRT:
         ErrLog(99906,"signal SIGABRT occured",RPT_TO_LOG  ,0,0);
         break;
    case SIGEMT:
         ErrLog(99907,"signal SIGEMT occured",RPT_TO_LOG  ,0,0);
         break;
    case SIGFPE:
         ErrLog(99908,"signal SIGFPE occured",RPT_TO_LOG  ,0,0);
         break;
    case SIGKILL:
         ErrLog(99909,"signal SIGKILL occured",RPT_TO_LOG  ,0,0);
         break;
    case SIGBUS:
         ErrLog(99910,"signal SIGBUS occured",RPT_TO_LOG  ,0,0);
         break;
    case SIGSEGV:
         ErrLog(99911,"signal SIGSEGV occured",RPT_TO_LOG  ,0,0);
         break;
    case SIGSYS:
         ErrLog(99912,"signal SIGSYS occured",RPT_TO_LOG  ,0,0);
         break;
    case SIGPIPE:
         ErrLog(99913,"signal SIGPIPE occured",RPT_TO_LOG  ,0,0);
         break;
    case SIGALRM:
         ErrLog(99914,"signal SIGALRM occured",RPT_TO_LOG  ,0,0);
         break;
    case SIGTERM:
         ErrLog(99915,"signal SIGTERM occured",RPT_TO_LOG  ,0,0);
         break;
    case SIGUSR1:
         ErrLog(99916,"signal SIGUSR1 occured",RPT_TO_LOG  ,0,0);
         break;
    case SIGUSR2:
         ErrLog(99917,"signal SIGUSR2 occured",RPT_TO_LOG  ,0,0);
         break;
    case SIGCLD:
/*    modified by thw381 12/24
         ErrLog(99918,"signal SIGCLD occured",RPT_TO_LOG  ,0,0);
         break;
*/
         return ;
    case SIGPWR:
         ErrLog(99919,"signal SIGPWR occured",RPT_TO_LOG  ,0,0);
         break;
/* Mark for AIX Unix
    case SIGPOLL:
         ErrLog(99922,"signal SIGPOLL occured",RPT_TO_LOG  ,0,0);
         break;
*/
  }

  exit( iSigNo );
}



/*
 *&N& ROUTINE NAME:AbendRtn()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                 DESCRIPTION
 *&A& ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0	: ����ư��榨�\
 *&R&   -1	: ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&   1.restore the terminal control data.
 *&D&   2.��ܲ��`���~���T��, ���}�{��.
 *&D&
 */

void
AbendRtn()
{
  int iRc;

  ErrLog(100,"Enter AP AbendRtn() ...... ",RPT_TO_LOG,0,0);
  iRc = ApEnvRls(AP_ABEND_END);

  if ( iRc < 0 ) {
    exit( -1 );
  }

  exit( 1 );
}
