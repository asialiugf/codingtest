
/*
 *&N& File : tmssync.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int       InitSync()              Initilize Synchronize Mechanism
 *&N&    int       ResetSync()             Reset Semaphore Value
 *&N&    int       WakeTpu()               TPU��sleep mode -> run mode
 *&N&    int       SleepTpu()              TPU��run mode -> sleep mode
 *&N&    int       WakeAp()                AP��sleep mode -> run mode
 *&N&    int       SleepAp()               AP�� run mode -> sleep mode
 *&N&    int       RelsSync()              Release Synchronize Mechanism 
 */

/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include "errlog.h"
#include "twa.h"
#include "tmcpgdef.h"	/* TMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */

/* -------------------- CONSTANT DEFINE  --------------------------- */
/*
#define P_WakeTpu	26501
#define P_SleepTpu	26502
#define P_WakeAp	26503
#define P_SleepAp	26504
#define P_InitSync	26505
#define P_RelsSync	26506
#define P_ResetSync     26507
*/

/* <tmssync.c> error message code */
#define CREAT_SYNC_ERR     		-1
#define SET_SYNC_VAL_ERR     		-2
#define REMOVE_SYNC_ERR     		-3

#define SEM_NUM	            6
#define TPU_SEM_NO	    0
#define AP_SEM_NO	    2

/* -------------------- STATIC GLOBAL DECLARATION ------------------ */
static int sg_iSemId;
extern struct TMA *g_pstTma;

/* ------ CALL FUNCTION & SUBROUTINE PROTOTYPE DECLARATIONS -------- */
int WakeTpu();
int SleepTpu();
int WakeAp();
int SleepAp();
int InitSync();
int RelsSync();

/*
 *&N& ROUTINE NAME: InitSync()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                 DESCRIPTION
 *&A& ---------  ---------------------   -------------------------
 *&A&   �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&    < 0    : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D& Create Semaphore:
 *&D& �H Semaphore �ӹF�� processes �������P�B�@�ΡC
 */
int
InitSync()
{
  int iSemKey;
  int iSemInitVal;

  UCP_TRACE(P_InitSync);
  iSemKey = getpid();
  iSemInitVal = 0 ;
  sg_iSemId = IpcSemCr(iSemKey, SEM_NUM, sg_iSemId, iSemInitVal);
  g_pstTma->stTSSA.iIpcSemId = sg_iSemId;

  if ( sg_iSemId < 0 ) {
    sprintf(g_caMsg,"InitSync: IpcSemCr rtn code = %d", sg_iSemId);
    ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END( CREAT_SYNC_ERR );
  }

  UCP_TRACE_END( 0 );

}

/*
 *&N& ROUTINE NAME: RelsSync()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                 DESCRIPTION
 *&A& ---------  ---------------------   -------------------------
 *&A&   �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&    < 0    : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D& Release Semaphore:
 *&D& �H Semaphore �ӹF�� processes �������P�B�@�ΡC
 */
int
RelsSync()
{
  int iRc;

  UCP_TRACE(P_RelsSync);
  iRc = IpcSemRm(sg_iSemId, SEM_NUM);

  if ( iRc < 0 ) {
    sprintf(g_caMsg,"InitSync: IpcSemRm rtn code = %d", iRc);
    ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END( REMOVE_SYNC_ERR );
  }
/* modified by pjw for tu980525 
  UCP_TRACE( 0 );*/

  UCP_TRACE_END( 0 );
}

/*
 *&N& ROUTINE NAME: ResetSync()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                 DESCRIPTION
 *&A& ---------  ---------------------   -------------------------
 *&A&   �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&    < 0    : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& Reset Semaphore Value To 0�C
 *&D&
 */
int
ResetSync()
{
  int iRc;

  UCP_TRACE(P_ResetSync);

  iRc = IpcSemSet(sg_iSemId, TPU_SEM_NO, 0);

  if ( iRc < 0 ) {
    sprintf(g_caMsg,"ResetSync: IpcSemSet() rtn code = %d", iRc);
    ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END( SET_SYNC_VAL_ERR );
  }

  iRc = IpcSemSet(sg_iSemId, AP_SEM_NO, 0);

  if ( iRc < 0 ) {
    sprintf(g_caMsg,"ResetSync: IpcSemSet() rtn code = %d", iRc);
    ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END( SET_SYNC_VAL_ERR );
  }

  UCP_TRACE_END( 0 );
}
/*
 *&N& ROUTINE NAME: WakeTpu()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                 DESCRIPTION
 *&A& ---------  ---------------------   -------------------------
 *&A&   �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&    < 0    : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& �H Semaphore �ӹF�� processes �������P�B�@�ΡC
 *&D& TPU process �O�H semaphore no. 0 ���X�б���C
 */
int
WakeTpu()
{
  int iRc;

  UCP_TRACE(P_WakeTpu);
  iRc = IpcSemInc( g_pstTma->stTSSA.iIpcSemId, TPU_SEM_NO );
  UCP_TRACE_END(iRc);
}


/*
 *&N& ROUTINE NAME: SleepTpu()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                 DESCRIPTION
 *&A& ---------  ---------------------   -------------------------
 *&A&   �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&    < 0    : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& �H Semaphore �ӹF�� processes �������P�B�@�ΡC
 *&D& TPU process �O�H semaphore no. 0 ���X�б���C
 */
int
SleepTpu()
{
  int iRc;

  UCP_TRACE(P_SleepTpu);
  iRc = IpcSemDec( g_pstTma->stTSSA.iIpcSemId, TPU_SEM_NO );
  UCP_TRACE_END(iRc);
}


/*
 *&N& ROUTINE NAME: WakeAp()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                 DESCRIPTION
 *&A& ---------  ---------------------   -------------------------
 *&A&   �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&    < 0    : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& �H Semaphore �ӹF�� processes �������P�B�@�ΡC
 *&D& AP process �O�H semaphore no. 2 ���X�б���C
 */
int
WakeAp()
{
  int iRc;

  UCP_TRACE(P_WakeAp);
  iRc = IpcSemInc( g_pstTma->stTSSA.iIpcSemId, AP_SEM_NO );
  UCP_TRACE_END(iRc);
}


/*
 *&N& ROUTINE NAME: SleepAp()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                 DESCRIPTION
 *&A& ---------  ---------------------   -------------------------
 *&A&   �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&    < 0    : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& �H Semaphore �ӹF�� processes �������P�B�@�ΡC
 *&D& AP process �O�H semaphore no. 2 ���X�б���C
 */
int
SleepAp()
{
  int iRc;

  UCP_TRACE(P_SleepAp);
  iRc = IpcSemDec( g_pstTma->stTSSA.iIpcSemId, AP_SEM_NO );
  UCP_TRACE_END(iRc);
}
