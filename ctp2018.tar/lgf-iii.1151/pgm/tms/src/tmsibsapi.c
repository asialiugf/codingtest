
/* -------------------- INCLUDE FILES DECLARATION ------------------- */
#include <errno.h>
#include "errlog.h"
#include "dcs.h"
#include "tms.h"

/* ------ CALL FUNCTION & SUBROUTINE PROTOTYPE DECLARATIONS --------- */
int SendToIbs( int, char *, int );
int RecFromIbs( char * );
int DisConnect();

/* ------ GLOBL CONSTANT                                    --------- */
#define START                  '1'
#define END                    '2'
#define OTHER                  '3'
#define ONCE                   '4'

IBSIBRQT( pstData )
struct IbsrqtSt *pstData;
{
  int rc;
  char cMoreData;
  char cEndFlag='0';

  if ( pstData->cIbsDcsFlag == START ||
       pstData->cIbsDcsFlag == ONCE ) {
    cMoreData = '1';
  }
  else {
    cMoreData = pstData->cIbsDcsFlag;
  }

  if ( pstData->cIbsDcsFlag == END ||
       pstData->cIbsDcsFlag == ONCE ) {
     cEndFlag = '1';
  }

  rc = SendToIbs( sizeof(struct IbsrqtSt) , pstData, cMoreData);
  rc = RecFromIbs( pstData );

  if ( cEndFlag == '1' ) {
    rc = DisConnect( );
  }

}
