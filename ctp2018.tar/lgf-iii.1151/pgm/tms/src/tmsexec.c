/*
 *&N& File : tmsexec.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE      NAME                 DESCRIPTION
 *&N& --------- ---------- ----------------------------------------
 *&N&    int      ExecAp              �Ұ����ε{��
 *&N&    int      ServiceAp           �A�����ε{�������
 */

/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include <errno.h>
#include "cwa.h"       /* �w�q CWA �ҨϥΨ쪺��Ƶ��c�α`�� */
#include "twa.h"       /* �w�q TWA �ҨϥΨ쪺��Ƶ��c�α`�� */
#include "tms.h"       /* �w�q tms �t�ΨϥΨ쪺��Ƶ��c�α`�� */
#include "dcs.h"       /* �w�q tms �t�ΨϥΨ쪺 DCS ��Ƶ��c�α`�� */
#include "errlog.h"    /* �O�����~�T���ɨϥΨ쪺�`�Ƥθ�Ƶ��c */
#include "tmctxpro.h"  /* �O�����~�T���ɨϥΨ쪺�`�� */
#include "fcstwa.h"               /* �Ȯɥ[�J */ 
#include "tmcpgdef.h"	/* TMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */
#include "lgcopewa.h"
#include "tmcinit.h"
#include "tmcend.h"

/* -------------------- CONSTANT DEFINE  --------------------------- */
/*
#define   P_ExecAp	26101
#define   P_ServiceAp	26102
*/

#define  RCV_ERR	'0'	/* added by chi fu-song 1995/03/25 */
#define  ONBTH_TXN_BEEN_PROCESS  "F115" /* add by chi-fusong 1995/03/31 */
/* To avoid duplication of txn seq. no of the same terminal -- BEGIN */ 
#define IS_NOT_ON_TXN           0x7f
/* To avoid duplication of txn seq. no of the same terminal -- END */ 

/* -------------------- STATIC GLOBAL DECLARATION ------------------ */
int g_iApPid = -1 ;                           /* �s��fork()�Ǧ^�� */
extern struct TMA *g_pstTma;
extern struct TBA *g_pstTba;
extern struct COA *g_pstCoa;
extern struct APA *g_pstApa;
extern int g_iTwaKey;
extern int g_iTestMode;
extern char g_cRcvRmtDataFlag; /* added by chi fu-song 1995/03/25 */
extern char g_cOnBthTxn; /* added by chi fu-song 1995/03/31 */
extern int g_iTmin;
extern int g_iToffset;
extern int g_iTcumTpuSleep;
extern int g_iTapAlarm;
extern int g_iTtxnTimeout;
extern char g_cNeedRelseTrm;
extern int g_iBrhCodeLen;
extern int g_iTmCodeLen;
static char sg_cAlarmAp;

/* PTM TPEUNIX980510 : add 1 line by Hu Chunlin, June 1st, 1998 */
int	g_iTmaTermno;

/* ------ CALL FUNCTION & SUBROUTINE PROTOTYPE DECLARATIONS -------- */
int ExecAp();
int ServiceAp();
int SendErrToDbp();
void AlarmAp();
int TrmRelease();

/*
 *&N& ROUTINE NAME: ExecAp()
 *&A& ARGUMENTS:
 *&A&   NAME               TYPE                 DESCRIPTION
 *&A& ---------  ---------------------   -------------------------
 *&A&   �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R& EXE_NOT_EXIST_ERR  : �����椧�����ɤ��s�b
 *&R& FORK_ERR           : fork()����
 *&R& WAKE_TPU_ERR       : WakeTpu����
 *&R& SLEEP_TPU_ERR      : SleepTpu ����
 *&R& AP_ABEND_ERR       : AP ABEND EXIT
 *&R& WAKE_AP_ERR        : WakeAp AP ����
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& ExecAp()���FORK Process��, �I�s�t�Ψ��EXECL�H�K����ѼƩҹ�M��
 *&D& ������(????.x)�C
 */

int
ExecAp()
{

  int iRc;                              /* �s���ƶǦ^��   */
  char caAbsPath[MAX_ABS_PATH_LEN];     /* �s��COBOL AP������|�W�� */
  char caAbsPrg[MAX_ABS_PATH_LEN];      /* �s��COBOL AP������|�M�����ɦW�� */
  char caAbsShellPrg[MAX_ABS_PATH_LEN]; /* �s��COBOL AP������|�M�����ɦW�� */
  char caTwaShmKey[7];                  /* �s�� Share memory Key �ন���r��� */
  char caApDspFileName[MAX_ABS_PATH_LEN];
  char caDspBuf[30];
  char caTestMode[10];
  char caErrCode[10];


  UCP_TRACE(P_ExecAp);
  sprintf(caTwaShmKey,"%d",g_iTwaKey);
  signal(SIGCLD,SIG_IGN);

  strcpy((char *)caAbsPath, (char *)getenv("III_DIR"));
  strcat((char *)caAbsPath, (char *)"/");
  strcat((char *)caAbsPath, (char *)g_pstTma->stTSSA.caBussDir);

  strcpy((char *)caAbsPrg, (char *)getenv("III_DIR"));
  strcat((char *)caAbsPrg, (char *)"/");
  strcat((char *)caAbsPrg, (char *)g_pstTma->stTSSA.caBussDir);
  strcat((char *)caAbsPrg, (char *)"/");
  strcat((char *)caAbsPrg, (char *)"exe/");
  strcat((char *)caAbsPrg, (char *)g_pstTma->stTSSA.caPrgName);
  /* ---------------------------------------- */
  /*  check ������ �O�_�s�b                   */
  /* ---------------------------------------- */

  if ( (iRc = open(caAbsPrg,O_RDONLY)) == -1) {
    sprintf(g_caMsg,"ExecAp: AP does not exist! path:%s pgm:%s",
            caAbsPath,caAbsPrg);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    DetErrRpt(EXE_NOT_EXIST_ERR,g_caMsg);
    UCP_TRACE_END(EXE_NOT_EXIST_ERR);
  }

  close(iRc); 

  if ( ( g_iApPid = fork() ) == -1 ) {
    sprintf(g_caMsg,"ExecAp: fork AP process fail,errno=%d",errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    DetErrRpt( FORK_ERR, g_caMsg );
    UCP_TRACE_END( FORK_ERR );
  }

  if ( g_iApPid == 0 )  /* child process */
  {
     sprintf(caTestMode,"%d",g_iTestMode);

    if (g_pstTma->stTSSA.cSysMode != ONLINE_MODE) {
      iRc = execl(caAbsPrg,g_pstTma->stTSSA.caPrgName,caTwaShmKey,caTestMode,(char *) 0 );
    }
    else {
      /* modified by WuChihLiang 19960312 for chang AP display file directory */
      /*strcpy(caApDspFileName,caAbsPath);
      sprintf(caDspBuf,"/exe/%.4s_%.2s.dsp",g_pstTma->stTSSA.caTxnCode,
              g_pstTma->stTSSA.caTmCode);
      strcat(caApDspFileName,caDspBuf);*/
      sprintf(caApDspFileName,"%s/iii/tmp/%.4s_%.2s.dsp",
              (char *)getenv("III_DIR"), 
              g_pstTma->stTSSA.caTxnCode, g_pstTma->stTSSA.caTmCode);
      memset(caAbsShellPrg,0,MAX_ABS_PATH_LEN);
      strcpy((char *)caAbsShellPrg, (char *)getenv("III_DIR"));
      strcat((char *)caAbsShellPrg, (char *)"/iii/bin/bat/exec_ap.sh");
  
      iRc = execlp(caAbsShellPrg,caAbsShellPrg,caTwaShmKey,caTestMode,caAbsPrg,
                   caApDspFileName,(char *)0);
    }

    if ( iRc == -1 )
    {
      sprintf(g_caMsg,"ExecAp: AP exec fail! path:%s pgm:%s,errno=%d",
              g_pstTma->stTSSA.caBussDir,g_pstTma->stTSSA.caPrgName,errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      g_pstTma->stTCFA.cProcSemNo = '2';
      g_pstTma->stTCFA.cReqSrvCode = FUN_ABNDEXIT;
      iRc = WakeTpu(); 

      if ( iRc != 0  ) {
        sprintf(g_caMsg,"ExecAp: Wake TPU fail ");
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        DetErrRpt(WAKE_TPU_ERR,g_caMsg);
        UCP_TRACE_END(WAKE_TPU_ERR);
      }

      exit(0);                   /* child process exit */
    } /* if (execl(...) */
  }
  else {           /* Parent process */
    sprintf(g_caMsg,"<APD>ExecAp: AP FORKED pid=%d,path_name=%s,pg-name=%s",g_iApPid,g_pstTma->stTSSA.caBussDir,g_pstTma->stTSSA.caPrgName);
    ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
    /* --- Send a message to DBP to release the TERMINAL when the TERMINAL*/ 
    /* --- do a REENTRY txn. 1995/04/01 --------------------------------- */
    if ( g_cOnBthTxn == 'y' ) {

/* To avoid duplication of txn seq. no of the same terminal -- BEGIN */ 
      iRc = TrmRelease();
      if (iRc < 0) {
        ErrLog(1000,"ExecAp: TrmRelease fail!",RPT_TO_LOG,0,0);
        UCP_TRACE_END(iRc);
      }
      g_cNeedRelseTrm = 'n';
/* To avoid duplication of txn seq. no of the same terminal -- END */ 

      /*  Added by WuChihLiang 19950510 for 7 bytes message  code */
      if (g_pstTma->stTSSA.cSystemRole == CENTER_HOST){
        caErrCode[0] = 'H';
      }else{
        caErrCode[0] = 'B';
      }
      memcpy( caErrCode+1, "UX", 2); 
      memcpy( caErrCode+3, ONBTH_TXN_BEEN_PROCESS, 4);
      caErrCode[7] = '\0';
      SendErrToDbp( g_pstTma->stTSSA.caBrCode, g_pstTma->stTSSA.caTmCode,
                    caErrCode);
      /*
      SendErrToDbp( g_pstTma->stTSSA.caBrCode, g_pstTma->stTSSA.caTmCode,
                    ONBTH_TXN_BEEN_PROCESS );
      */
    }

  }

  iRc = ServiceAp();  
  UCP_TRACE_END(iRc);  

} /* end ExecAp() */

int ServiceAp()
{
  int iRc;
  char cRtnCode;               /* tmp return code */
  struct DbsSt *pstDbs;        /* dbs control struct part */
  struct FcsSt *pstFcs;        /* fcs control struct part */
  struct DcsApi *pstDcs;        /* dcs control struct part */
  struct DbsSt stTempDbsBuf;
  struct ShmFacCtlSt *pstShmCtl;
  struct SdcltCtlSt  *pstSdcltCtl;
  struct ApRqtCtlSt  *pstApRqt;
  struct ReinputCtlSt  *pstReinput;
  struct LogApiSt  *pstLogOpCtl;
  char cJclIoFlag;             /* �s��UCPIO ���X�� */
  struct CwaCtl stCwaCtl; 
  struct AciaInt *pstAciaInt;
  struct GetPreCtlSt *pstGetPre;
  struct GetSeqSt *pstGetSeq;
  struct OnBthCtlSt *pstOnBth;
  struct SetLnCtlSt *pstSetLn;
  struct GtSifCtlSt *pstGtSif;
  struct OnBh1CtlSt *pstOnBh1;
  struct stReOutCtl *pstReOut;
  struct CoptxCtlSt *pstCoptx;

  UCP_TRACE(P_ServiceAp);
  cJclIoFlag = '0';

  while(1) {
    /* Modified by Willy for detecting Ap process timeout */
    iRc = SleepTpuAndDetectAp();
    if ( iRc != 0 ) {
        UCP_TRACE_END( iRc );
    }

    switch(g_pstTma->stTCFA.cReqSrvCode) {
      case FUN_DBS:
        TPFDBS(g_pstApa,g_pstCoa,g_pstTba->caPara);
        pstDbs = (struct DbsSt *)g_pstCoa;
        if ( ( pstDbs->cDbsReturnCode != TMS_DBS_NORMAL )
          && ( pstDbs->cDbsReturnCode != TMS_NO_MORE )
          && ( pstDbs->cDbsReturnCode != TMS_DBS_NO_REC_FOUND ) )
        {
           sprintf(g_caMsg,"ExecAp: TPFDBS fun code=%c",pstDbs->cDbsReturnCode);
           ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
           sprintf(g_caMsg,"ExecAp: TPFDBS rtn code=%c seg=%.8s",
                     pstDbs->cDbsReturnCode,pstDbs->caDbsSegName);
           ErrLog(1000,g_caMsg,RPT_TO_LOG,pstDbs,sizeof(struct DbsSt));
        }
        break;

      case FUN_FCS:
        TPFFCS(g_pstApa,g_pstCoa,g_pstTba->caPara);
        pstFcs = (struct FcsSt *)g_pstCoa;
        if ( ( strncmp(pstFcs->caFcsRtnCode,FCS_M_NORMAL,2) != 0 )
          && ( strncmp(pstFcs->caFcsRtnCode,FCS_M_NO_MORE,2) != 0 )
          && ( strncmp(pstFcs->caFcsRtnCode,FCS_M_NO_REC_FOUND,2) != 0 )  )
        {
          sprintf(g_caMsg,"ExecAp: TPFFCS fun code=%.4s",pstFcs->caFcsFunCode);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          sprintf(g_caMsg,"ExecAp: TPFFCS rtncode=%.2s file=%.8s",
                                  pstFcs->caFcsRtnCode,pstFcs->caFcsFileName);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,pstFcs,sizeof(struct FcsSt));
        }
        break;

      case FUN_DCS:
        TPEDCS(g_pstApa,g_pstCoa,g_pstTba->caPara);
        pstDcs = (struct DcsApi *)g_pstCoa;
        if ( pstDcs->cRtnCode != DCS_M_NORMAL )
        {
          sprintf(g_caMsg,"ExecAp: TPEDCS fun code=%c",pstDcs->cFunCode);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          sprintf(g_caMsg,"ExecAp: TPEDCS rtncode=%c err_code=%.2s",
                  pstDcs->cRtnCode, pstDcs->caErrCode);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,pstDcs,sizeof(struct DcsApi));
        }
        break;

      case FUN_SHMFAC:
        TPFCWARW(g_pstApa,g_pstCoa,g_pstTba->caPara);
        pstShmCtl = (struct ShmFacCtlSt *) g_pstCoa;
        cRtnCode = pstShmCtl->cShmReturnCode;
        if ( cRtnCode != TMS_SHM_NORMAL )
        {
          sprintf(g_caMsg,"ExecAp: TPFCWARW rtn code = %c",cRtnCode);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        }
        break;

      case FUN_TXLOG:
        TPETXLOG(g_pstApa,g_pstTba->caPara);
        cRtnCode = g_pstTba->caPara[0];
        if ( cRtnCode != TMS_TXLOG_NORMAL )
        {
          sprintf(g_caMsg,"ExecAp: TPETXLOG rtn code = %c",cRtnCode);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0);
        }
        break;

      case FUN_WRITE:
        iRc = TPEWRITE(g_pstApa,g_pstTba->caPara);
        cRtnCode = g_pstTba->caPara[0];
        if ( cRtnCode != TMS_MSGP_NORMAL )
        {
          sprintf(g_caMsg,"ExecAp: TPEWRITE rtn code =%c",cRtnCode);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        }
        if ( iRc < 0 ) {
          sprintf(g_caMsg,
                  "ExecAp: TPEWRITE error! AP has already sent MXXX msg!");
          ErrLog( 1000, g_caMsg, RPT_TO_LOG, 0, 0 );
          UCP_TRACE_END(TPEWRITE_CALL_SEQ_ERR);
        }
        break;

      case FUN_PRINT:
        TPESDOUT(g_pstApa,g_pstTba->caPara);
        cRtnCode = g_pstTba->caPara[0];
        if ( cRtnCode != TMS_MSGP_NORMAL )
        {
           sprintf(g_caMsg,"ExecAp: TPESDOUT rtn code =%c",cRtnCode);
           ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        }
        break;

      case FUN_FRPT:
        TPFRPT(g_pstApa,g_pstTba->caPara);
        cRtnCode = g_pstTba->caPara[81];
        if ( cRtnCode != TMS_TPFRPT_NORMAL )
        {
           sprintf(g_caMsg,"ExecAp: TPFRPT rtn code =%c",cRtnCode);
           ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        }
        break;

      case FUN_SDCLT:
        TPESDCLT(g_pstApa,g_pstCoa,g_pstTba->caPara);
        pstSdcltCtl = (struct SdcltCtlSt  *) g_pstCoa;
        cRtnCode = pstSdcltCtl->cMsgOutReturnCode;
        if ( cRtnCode != TMS_MSGP_NORMAL )
        {
          sprintf(g_caMsg,"ExecAp: TPESDCLT rtn code =%c",cRtnCode);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        }
        break;

      case FUN_APRQT:
        TPEAPRQT(g_pstApa,g_pstCoa,g_pstTba->caPara);
        pstApRqt = (struct ApRqtCtlSt *) g_pstCoa;
        cRtnCode = pstApRqt->cReturnCode;
        if ( cRtnCode != TMS_APRQT_NORMAL )
        {
          sprintf(g_caMsg,"ExecAp: TPEAPRQT rtn code =%c",cRtnCode);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        }
        break;

      case FUN_REINPUT:
        TPESCRQT(g_pstApa,g_pstCoa,g_pstTba->caPara);
        pstReinput = (struct ReinputCtlSt *) g_pstCoa;
        cRtnCode = pstReinput->cReturnCode;
        if ( cRtnCode != TMS_REINPUT_NORMAL )
        {
          sprintf(g_caMsg,"ExecAp: TPESCRQT rtn code =%c",cRtnCode);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        }
        break;

      case FUN_NACINT:
/*
        memcpy(stTempDbsBuf.caDbsFileId,g_pstApa->caDbsFileId,2);
        stTempDbsBuf.cDbsReturnCode = g_pstApa->cDbsReturnCode;
*/
        NACINT(g_pstTba->caPara,g_pstApa);
/*
        memcpy(g_pstApa->caDbsFileId,stTempDbsBuf.caDbsFileId,2);
        g_pstApa->cDbsReturnCode = stTempDbsBuf.cDbsReturnCode ;
*/
        break;

/*
      case FUN_NARINT:
        memcpy(stTempDbsBuf.caDbsFileId,g_pstApa->caDbsFileId,2);
        stTempDbsBuf.cDbsReturnCode = g_pstApa->cDbsReturnCode;
        stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
        stCwaCtl.cSegCode = CWA_SEG_ACI;
        iRc = CwaLowCtlFac(&stCwaCtl,&pstAciaInt); 

        if (iRc != CWA_NORMAL) {
          ErrLog(1000,"ServiceAp: Get ACIA ptr fail!",RPT_TO_LOG,0,0); 
          UCP_TRACE_END(GET_ACIA_PTR_ERR);
        }
    
        NARINT(g_pstTba->caPara,g_pstApa,pstAciaInt);
        memcpy(g_pstApa->caDbsFileId,stTempDbsBuf.caDbsFileId,2);
        g_pstApa->cDbsReturnCode = stTempDbsBuf.cDbsReturnCode ;
        break;

      case FUN_NBCINT:
        memcpy(stTempDbsBuf.caDbsFileId,g_pstApa->caDbsFileId,2);
        stTempDbsBuf.cDbsReturnCode = g_pstApa->cDbsReturnCode;
        stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
        stCwaCtl.cSegCode = CWA_SEG_ACI;
        iRc = CwaLowCtlFac(&stCwaCtl,&pstAciaInt); 

        if (iRc != CWA_NORMAL) {
          ErrLog(1000,"ServiceAp: Get ACIA ptr fail!",RPT_TO_LOG,0,0); 
          UCP_TRACE_END(GET_ACIA_PTR_ERR);
        }

        NBCINT(g_pstTba->caPara,g_pstApa,pstAciaInt);
        memcpy(g_pstApa->caDbsFileId,stTempDbsBuf.caDbsFileId,2);
        g_pstApa->cDbsReturnCode = stTempDbsBuf.cDbsReturnCode ;
        break;
*/

      case FUN_JCLIO:
        if ( cJclIoFlag == '0' ) {
          StartUcpio();
        }
        cJclIoFlag = '1';
        TPGIOHDL(g_pstApa,g_pstTba->caPara);

/* Add to print return code 19960924 -- begin */
        cRtnCode = ((struct JclIoSt *)g_pstTba->caPara)->cJclIoRtnCode;
        if ( cRtnCode != TMS_JCLIO_NORMAL )
        {
          sprintf(g_caMsg,"ExecAp: TPGIOHDL rtn code =%c",cRtnCode);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        }
/* Add to print return code 19960924 -- end */  
        break;

      case FUN_LOGOP:
        TPFLOGOP(g_pstApa,g_pstCoa,g_pstTba->caPara);
        pstLogOpCtl = (struct LogApiSt *) g_pstCoa;
        cRtnCode = pstLogOpCtl->caReturnCd[0];
        if ( cRtnCode != TMS_LOGOP_NORMAL )
        {
          sprintf(g_caMsg,"ExecAp: TPFLOGOP rtn code =%c",cRtnCode);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        }
        break;

      case FUN_RVSOP:
        TPERVSOP(g_pstApa,g_pstCoa,g_pstTba->caPara);
        pstLogOpCtl = (struct LogApiSt *) g_pstCoa;
        cRtnCode = pstLogOpCtl->caReturnCd[0];
        if ( cRtnCode != TMS_LOGOP_NORMAL )
        {
          sprintf(g_caMsg,"ExecAp: TPERVSOP rtn code =%c",cRtnCode);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        }
        break;

      case FUN_GPREV:
        TPEGPREV(g_pstApa,g_pstCoa,g_pstTba->caPara);
        pstGetPre = (struct GetPreCtlSt *) g_pstCoa;
        cRtnCode = pstGetPre-> cGetPreLogRtnCode;
        if ( cRtnCode != TMS_GPREV_NORMAL )
        {
          sprintf(g_caMsg,"ExecAp: TPEGPREV rtn code =%c",cRtnCode);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        }
        break;

      case FUN_GTSEQ:
        TPFGTSEQ(g_pstApa,g_pstCoa);
        pstGetSeq = (struct GetSeqSt *) g_pstCoa;
        cRtnCode = pstGetSeq-> cGetSeqRtnCode;
        if ( cRtnCode != TMS_GTSEQ_NORMAL )
        {
          sprintf(g_caMsg,"ExecAp: TPFGTSEQ rtn code =%c",cRtnCode);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        }
        break;

      case FUN_ONBTH:
        TPEONBTH(g_pstApa,g_pstCoa,g_pstTba->caPara);
	/* added by chi fu-song 1995/03/25 */
        /* when AP ends TPEONBTH api, reset cReentryFlag and g_cRcvRmtDataFlag 
           for collecting Local Reentry AP's TPEWRITE data */
        g_pstTma->stTCFA.cReentryStatus = TMS_TXN_NOT_REENTRY;
        g_cRcvRmtDataFlag=RCV_ERR;

        pstOnBth = (struct OnBthCtlSt *) g_pstCoa;
        cRtnCode =  pstOnBth->cOnBthRtnCode;
        if ( cRtnCode != TMS_ONBTH_NORMAL )
        {
          sprintf(g_caMsg,"ExecAp: TPEONBTH rtn code =%c",cRtnCode);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        }
        break;

      case FUN_GTSIF:
        TPEGTSIF(g_pstApa,g_pstCoa);
        pstGtSif = (struct GtSifCtlSt *) g_pstCoa;
        cRtnCode =  pstGtSif->cGtSifRtnCode;
        if ( cRtnCode != TMS_GTSIF_NORMAL )
        {
          sprintf(g_caMsg,"ExecAp: TPEGTSIF rtn code =%c",cRtnCode);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        }
        break;

      case FUN_SETLN:
        TPFSETLN(g_pstApa,g_pstCoa);
        pstSetLn = (struct SetLnCtlSt *) g_pstCoa;
        cRtnCode =  pstSetLn->cSetLnRtnCode;
        if ( cRtnCode != TMS_SETLN_NORMAL )
        {
          sprintf(g_caMsg,"ExecAp: TPFSETLN rtn code =%c",cRtnCode);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        }
        break;

      case FUN_ONBH1:
        TPEONBH1(g_pstApa,g_pstCoa,g_pstTba->caPara);
	/* added by chi fu-song 1995/03/25 */
        /* when AP ends TPEONBTH api, reset cReentryFlag and g_cRcvRmtDataFlag 
           for collecting Local Reentry AP's TPEWRITE data */
        g_pstTma->stTCFA.cReentryStatus = TMS_TXN_NOT_REENTRY;
        /*g_cRcvRmtDataFlag=RCV_ERR;*/

        pstOnBh1 = (struct OnBh1CtlSt *) g_pstCoa;
        cRtnCode =  pstOnBh1->cOnBh1RtnCode;
        if ( cRtnCode != TMS_ONBH1_NORMAL )
        {
          sprintf(g_caMsg,"ExecAp: TPEONBH1 rtn code =%c",cRtnCode);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        }
        break;

      case FUN_ONBH2:
        TPEONBH2(g_pstApa,g_pstCoa,g_pstTba->caPara);
	/* added by chi fu-song 1995/03/25 */
        /* when AP ends TPEONBTH api, reset cReentryFlag and g_cRcvRmtDataFlag 
           for collecting Local Reentry AP's TPEWRITE data */
        g_pstTma->stTCFA.cReentryStatus = TMS_TXN_NOT_REENTRY;
        g_cRcvRmtDataFlag=RCV_ERR;

        pstOnBth = (struct OnBthCtlSt *) g_pstCoa;
        cRtnCode =  pstOnBth->cOnBthRtnCode;
        if ( cRtnCode != TMS_ONBTH_NORMAL )
        {
          sprintf(g_caMsg,"ExecAp: TPEONBH2 rtn code =%c",cRtnCode);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        }
        break;

      case FUN_REOUT:
        TPEREOUT(g_pstApa,g_pstCoa);
        pstReOut = (struct stReOutCtl *) g_pstCoa;
        cRtnCode =  pstReOut->caRtnCode[0];
        if ( cRtnCode != TMS_REOUT_NORMAL )
        {
          sprintf(g_caMsg,"ExecAp: TPEREOUT rtn code =%c",cRtnCode);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        }
        break;

      case FUN_LTINQ:
        TPELTINQ(g_pstApa);
        break;

      case FUN_COPTX:
        TPECOPTX(g_pstApa,g_pstCoa,g_pstTba->caPara);
        g_cRcvRmtDataFlag=RCV_ERR;

        pstCoptx = (struct CoptxCtlSt *) g_pstCoa;
        cRtnCode =  pstCoptx->cCoptxRtnCode;
        if ( cRtnCode != TMS_COPTX_NORMAL )
        {
          sprintf(g_caMsg,"ExecAp: TPECOPTX rtn code =%c",cRtnCode);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        }
        break;

      case FUN_APEXIT:
        if (cJclIoFlag == '1') {
          EndUcpio();
        }

        /* Added by Willy to reset alarm if ap process exits normally */
        alarm(0);

        UCP_TRACE_END(0);

      case FUN_ABNDEXIT:
        if (cJclIoFlag == '1') {
          EndUcpio();
        }

        /* Added by Willy to reset alarm if ap process abends normally */
        alarm(0);

        UCP_TRACE_END(AP_ABEND_EXIT_ERR);

      default:
        sprintf(g_caMsg,"ExecAp: invalid request fun = %c from AP",
                                       g_pstTma->stTCFA.cReqSrvCode);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);

    } /* end switch */

    iRc = WakeAp();   /* wake AP */
    if ( iRc != 0 ) {
      sprintf(g_caMsg,"ExecAp: wake up AP fail ");
      ErrLog( NORCVR_CHK_ERR, g_caMsg, RPT_TO_LOG, 0, 0 );
      DetErrRpt(WAKE_AP_ERR,g_caMsg);
      UCP_TRACE_END(WAKE_AP_ERR);
    }

  } /* end while */
}

int 
SleepTpuAndDetectAp()
{
  int iRc;
  int iTalarm;
  int iTsleepRemaining;
  /* ------------------------------------------------------------ */
  /* iTsleepRemaining is the amount of time (in seconds) remaining*/ 
  /* before the system is scheduled to generate the SIGALARM      */
  /* signal from the previous call to alarm                       */
  /* ------------------------------------------------------------ */
  int iTapRemaining;
  /* ------------------------------------------------------------ */
  /* iTapRemaining is the amount of time (in seconds) remaining   */ 
  /* before AP is finished or killed                              */
  /* ------------------------------------------------------------ */

  while(1) {

    if ((g_pstTma->stTSSA.cSysMode==ONLINE_MODE) && (g_cOnBthTxn=='n')) { 
      iTapRemaining = g_iTtxnTimeout - g_iTcumTpuSleep;
      if ((iTapRemaining > 0) && (iTapRemaining < g_iTapAlarm)) { 
        iTalarm = iTapRemaining;
      }
      else {
        iTalarm = g_iTapAlarm; 
        /* g_iTapAlarm is the default alarm time from config.dat */
      }
    }
    else {
      iTalarm = g_iTapAlarm; 
      /* g_iTapAlarm is the default alarm time from config.dat */
    }

    sg_cAlarmAp = 'n';
    signal( SIGALRM, AlarmAp );
    alarm( iTalarm ); /* iTalarm is the real alarm time */
    iTsleepRemaining = 0;

    iRc = SleepTpu();
    if ( iRc == IPC_SEMDEC_TIMEOUT || sg_cAlarmAp == 'y' ) { 
      g_iTcumTpuSleep += iTalarm;

      /* --------------------------------------- */
      /* To detect if Ap process is in existence */
      /* --------------------------------------- */
      iRc = kill( g_iApPid, 0 );
      if (iRc < 0) {            /* Not in existence */
        sprintf(g_caMsg,"SleepTpuAndDetectAp: AP(pid:%d,path:%s,pgm:%s) disappear abnormally, g_iTcumTpuSleep=%d sec!",
              g_iApPid,g_pstTma->stTSSA.caBussDir,
              g_pstTma->stTSSA.caPrgName,g_iTcumTpuSleep);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);

        iRc = ResetSync();
        if ( iRc < 0 ) {
          sprintf(g_caMsg,
                  "SleepTpuAndDetectAp: ResetSync() fails! iRc=%d", iRc);
          ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
          return( RESET_SYNC_ERR );
        }

        return( AP_DISAPPEAR_ERR );
      }
      else {  /* Ap process is still alive */
        if ( g_pstTma->stTSSA.cSysMode == ONLINE_MODE &&
             g_cOnBthTxn == 'n' ) { 
          /* --------------------------------------- */
          /* To test if Ap has processed too long    */
          /* and should be timeout                   */
          /* --------------------------------------- */
          if (g_iTcumTpuSleep < g_iTtxnTimeout) {
            sprintf(g_caMsg,
     "SleepTpuAndDetectAp: AP(pid:%d,path:%s,pgm:%s) is alarmed, g_iTcumTpuSleep=%d sec!",
                g_iApPid,g_pstTma->stTSSA.caBussDir,
                g_pstTma->stTSSA.caPrgName,g_iTcumTpuSleep);
            ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

            /* ----------------------------------- */
            /* To loop again (ie. sleep tpu again) */
            /* and alarm after some interval       */
            /* ----------------------------------- */
          }
          else {
            /* ------------------------------------------ */
            /* Ap has processed too long and to be killed */
            /* ------------------------------------------ */
            sprintf(g_caMsg,
     "SleepTpuAndDetectAp: AP(pid:%d,path:%s,pgm:%s) too long, killed, g_iTcumTpuSleep=%d sec!",
              g_iApPid,g_pstTma->stTSSA.caBussDir,
              g_pstTma->stTSSA.caPrgName,g_iTcumTpuSleep);
            ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);

            /* This kill() won't cause AP to enter AbendRtn */
            kill( g_iApPid, 9 );

            iRc = ResetSync();
            if ( iRc < 0 ) {
              sprintf(g_caMsg,
                    "SleepTpuAndDetectAp: ResetSync() fails! iRc=%d", iRc);
              ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
              return( RESET_SYNC_ERR );
            }

            return( AP_TOO_LONG_ERR );
          }
        } /* end of if ( g_pstTma->stTSSA.cSysMode == ONLINE_MODE ... */

        /* --------------------------------------------------- */
        /* If TPU is not ONLINE_MODE or TPU is ON BATCH,       */
        /* then no checking is needed and just to loop again   */
        /* (ie. sleep tpu again) and alarm after some interval */
        /* --------------------------------------------------- */

      } /* end if (iRc < 0) */
    }
    else if (iRc != 0) {
      sprintf(g_caMsg,"SleepTpuAndDetectAp: sleep TPU fail!");
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      DetErrRpt(iRc,g_caMsg);
      alarm(0);
      return( SLEEP_TPU_ERR );
    }
    else {
      /* --------------------------------------------------------- */
      /* TPU has been waken up by AP before timer expired.         */
      /* Just accumulate the sleep time of TPU and to avoid        */
      /* the remaining alarm to interrupt the following TPE's API. */
      /* --------------------------------------------------------- */

      iTsleepRemaining = alarm(0); 

      sprintf(g_caMsg,
          "SleepTpuAndDetectAp: TPU sleep %d seconds before waken up!",
          iTalarm - iTsleepRemaining);
      ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

      g_iTcumTpuSleep += (iTalarm - iTsleepRemaining);

      return(0); /* Return to execute TPE's API */
    }
  } /* end of while(1) */
}

void
AlarmAp()
{
  ErrLog(100,"signal SIGALRM occured to alarm AP process!",RPT_TO_LOG ,0,0);
  /* To return to the statement below interrupted statement,
     for detecting Ap process every T_APALARM seconds */ 
  sg_cAlarmAp = 'y';
  return;
}

/* To avoid duplication of txn seq. no of the same terminal -- BEGIN */ 
int
TrmRelease()
{
  int iRc;
  struct CwaCtl stCwaCtl;
  char *pcTerm;
  struct TermArea *pstTct;
  char *pcDummy;

  UCP_TRACE( P_TrmRelease );

  stCwaCtl.cFunCode = CWA_SEG_LOCK;
  stCwaCtl.cSegCode = CWA_SEG_BIT_BRH;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcDummy);

  if (iRc != CWA_NORMAL) {
    ErrLog(1000,"TrmRelease: CwaCtlFac lock TCT fail!",RPT_TO_LOG,0,0);
    UCP_TRACE_END( LOCK_TCT_ERR );
  }

  stCwaCtl.cFunCode = CWA_GET_TERM_PTR;
  /* PTM TPEUNIX980510 : Modified by Hu Chunlin, June 1st, 1998 - Begin */
  /*19980202-Replace 2-Lines by WuchiLiang for rendo-txn can*t release   
    terminal status */
  /* memcpy(stCwaCtl.caBrhId,&g_pstTba->caSif[BR_CODE_OFFSET],g_iBrhCodeLen);  
  memcpy(stCwaCtl.caTermId,&g_pstTba->caSif[TM_CODE_OFFSET],g_iTmCodeLen);  */
  /* memcpy(stCwaCtl.caBrhId,g_pstTma->stTSSA.caBrCode,g_iBrhCodeLen);
  memcpy(stCwaCtl.caTermId,g_pstTma-> stTSSA.caTmCode,g_iTmCodeLen);  */
  if(g_iTmaTermno == 1) {
    memcpy(stCwaCtl.caBrhId,g_pstTma->stTSSA.caBrCode,g_iBrhCodeLen);
    memcpy(stCwaCtl.caTermId,g_pstTma-> stTSSA.caTmCode,g_iTmCodeLen);
  }
  else {
    memcpy(stCwaCtl.caBrhId,&g_pstTba->caSif[BR_CODE_OFFSET],g_iBrhCodeLen);  
    memcpy(stCwaCtl.caTermId,&g_pstTba->caSif[TM_CODE_OFFSET],g_iTmCodeLen);
  }
  /* PTM TPEUNIX980510 : Modified by Hu Chunlin, June 1st, 1998 - End   */

  iRc = CwaLowCtlFac(&stCwaCtl,&pcTerm);

  if (iRc != CWA_NORMAL) {
    ErrLog(1000,"TrmRelease: CwaCtlFac get TCT ptr fail!",RPT_TO_LOG,0,0);

/*begin:  add by pjw for TU995002            1999 6 10*/
    stCwaCtl.cFunCode = CWA_SEG_UNLOCK;
    stCwaCtl.cSegCode = CWA_SEG_BIT_BRH;
    iRc = CwaLowCtlFac(&stCwaCtl,&pcDummy);

    if (iRc != CWA_NORMAL) {
       ErrLog(1000,"TrmRelease: unlock TCT fail,tpu abnormal exit!",RPT_TO_LOG,
0,0);
    exit(-1);
    }
/*end:  add by pjw for TU995002            1999 6 10*/

    UCP_TRACE_END( GET_TCT_PTR_ERR );
  }

  pstTct = (struct TermArea *) pcTerm;
  pstTct->cTermStatus &= IS_NOT_ON_TXN; /* To release this terminal */

  stCwaCtl.cFunCode = CWA_SEG_UNLOCK;
  stCwaCtl.cSegCode = CWA_SEG_BIT_BRH;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcDummy);

  if (iRc != CWA_NORMAL) {
    ErrLog(1000,"TrmRelease: CwaCtlFac unlock TCT fail!",RPT_TO_LOG,0,0);
    UCP_TRACE_END( UNLOCK_TCT_ERR );
  }

  UCP_TRACE_END( 0 );
}
/* To avoid duplication of txn seq. no of the same terminal -- END */ 
