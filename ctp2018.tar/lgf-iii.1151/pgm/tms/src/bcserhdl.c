
/*
 *&N& File: tmsberhdl.c  ����޲z�l�t�ΥD�{��
 *&N&
 *&N&    TYPE      NAME                 DESCRIPTION
 *&N& --------- ---------- ----------------------------------------
 *&N&    int       TmsErrHdl �妸����޲z�l�t�ο��~�B�z�{��
 *&N&    int       ErrorMap  �妸����޲z�l�t�ο��~�X�ഫ�{��
 *&N&
 */


/* ---------------------- INCLUDE FILES DECLARATION ------------------- */
#include "twa.h"
#include "tms.h"
#include "errlog.h"
#include "tmcpgdef.h"   /* TMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */
#include "bccerror.h"   /* TMS ���~�T�� */


/* ------------------------- CONSTANT DEFINITION ---------------------- */
#define         PRG_ID_LEN                  5
#define         RET_CODE_LEN                2
#define         ROLLBACK_FLAG              '1'

#define         NO                          0
#define         YES                         1

/* ------------------------- GLOBAL & EXTERN VARIABLE ------------------ */
char g_caToDbpErrCode[10];
extern char g_cErrActFlag;
extern struct TMA *g_pstTma;

/* ------------------------- FUNCTION PROTYPE -------------------------- */
void TmsErrHdl(char,int);
void ErrorMap(char,int);
void ErrorAction();
void PrintErrMsg(char *pcaMsg);


void
TmsErrHdl( char cL2Step , int iRc )
{
  ErrorMap( cL2Step, iRc );
  ErrorAction();
}

void
ErrorMap( char cL2Step , int iRc )
{
  char *pcPrgIdStr;
  char caErrorCode[10];
  char caIrcBuf[10];
  int  iPrgIdVal;              /* iPrgIdVal = atoi(pcPrgIdStr) */
  int  iAbsIrc;                /* iAbsIrc = abs(iRc)           */

  memset( caErrorCode, 0, 10);
  memset( g_caToDbpErrCode, 0, 10);
  memset( caIrcBuf, 0, 10);

  if ( cL2Step == '0' ) {
    pcPrgIdStr = GetPrgId( 0 );
  }
  else {
    pcPrgIdStr = GetPrgId( 1 );
  }

  iPrgIdVal = atoi(pcPrgIdStr);
  iAbsIrc = abs(iRc);
  memcpy(caErrorCode , pcPrgIdStr, PRG_ID_LEN);
  sprintf(caIrcBuf,"%.2d", iAbsIrc );
  strncat(caErrorCode, caIrcBuf, RET_CODE_LEN);

/*
  printf("ErrorMap-------iPrgIdStr------%s-------\n",caErrorCode);
  printf("ErrorMap-------iPrgIdVal------%d-------\n",iPrgIdVal);
  printf("ErrorMap-------iAbsIrc------%d-------\n",iAbsIrc);
*/

  switch ( iPrgIdVal ) {
    case P_CheckJclFile:
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,JCL_FILE_NOT_EXIST_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;
    case P_GetConfg:
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,INIT_CNF_TBL_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode,GET_CWAKEY_ERR_E,4);
             break;
           case 3:
             memcpy(g_caToDbpErrCode,GET_CTFKEY_ERR_E,4);
             break;
           case 4:
             memcpy(g_caToDbpErrCode,GET_ICTKEY_ERR_E,4);
             break;
           case 5:
             memcpy(g_caToDbpErrCode,GET_IETKEY_ERR_E,4);
             break;
           case 6:
             memcpy(g_caToDbpErrCode,GET_DBTKEY_ERR_E,4);
             break;
           case 7:
             memcpy(g_caToDbpErrCode,GET_SYSOPMODE_ERR_E,4);
             break;
           case 8:
             memcpy(g_caToDbpErrCode,GET_TESTMODE_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

    case P_GetSysRs:
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,COB_INIT_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode,SIGNAL_HDL_ERR_E,4);
             break;
           case 3:
             memcpy(g_caToDbpErrCode,GET_TWA_TWACTLFAC_ERR_E,4);
             break;
           case 4:
             memcpy(g_caToDbpErrCode,GETPTRFROMTWA_TMA_ERR_E,4);
             break;
           case 5:
             memcpy(g_caToDbpErrCode,GETPTRFROMTWA_COA_ERR_E,4);
             break;
           case 6:
             memcpy(g_caToDbpErrCode,GETPTRFROMTWA_APA_ERR_E,4);
             break;
           case 7:
             memcpy(g_caToDbpErrCode,GETPTRFROMTWA_TBA_ERR_E,4);
             break;
           case 8:
             memcpy(g_caToDbpErrCode,INIT_SYNC_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

    case P_GetKernl:
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,ACCESS_CWA_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode,GET_TCT_ERR_E,4);
             break;
           case 3:
             memcpy(g_caToDbpErrCode,ATTCH_CTF_ERR_E,4);
             break;
           case 4:
             memcpy(g_caToDbpErrCode,ATTCH_ICT_ERR_E,4);
             break;
           case 5:
             memcpy(g_caToDbpErrCode,ATTCH_IET_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

    case P_AttIfEnv:
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,ATT_IF_ENV_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

    case P_StSysVal:
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,SET_SYS_VAL_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode,GET_SSA_PTR_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

    case P_InitSysEnv:
         switch ( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,RESET_SYNC_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

    case P_IniIfEnv:
         switch ( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,INIT_IF_ENV_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;
    case P_JclInput             :
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,JCL_INIT_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode,JCL_SYNTAX_ERR_E,4);
             break;
           case 3:
             memcpy(g_caToDbpErrCode,JCL_UNIX_CMD_ERR_E,4);
             break;
           case 4:
             memcpy(g_caToDbpErrCode,OPEN_TMP_FILE_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

    case P_IsTxnBegin           :
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,TXN_TYPE_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode,RENDO_REQUEST_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

    case P_DbsTxBegin           :
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,BEGIN_TXN_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

    case P_TxProces     :
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,TXN_PATTERN_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode,SYSTEM_ROLE_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

    case P_ApDispth     :
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,AP_NOT_EXIST_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode,AP_EXE_NOT_EXIST_ERR_E,4);
             break;
           case 3:
             memcpy(g_caToDbpErrCode,FORK_ERR_E,4);
             break;
           case 4:
             memcpy(g_caToDbpErrCode,WAKE_TPU_ERR_E,4);
             break;
           case 5:
             memcpy(g_caToDbpErrCode,SLEEP_TPU_ERR_E,4);
             break;
           case 6:
             memcpy(g_caToDbpErrCode,GET_ACIA_PTR_ERR_E,4);
             break;
           case 7:
             memcpy(g_caToDbpErrCode,AP_ABEND_EXIT_ERR_E,4);
             break;
           case 8:
             memcpy(g_caToDbpErrCode,WAKE_AP_ERR_E,4);
             break;
           case 9:
             memcpy(g_caToDbpErrCode,TPEWRITE_CALL_SEQ_ERR_E,4);
             ErrLog(100,"Set KILL_AP_FLAG on........",RPT_TO_LOG,0,0);
             g_cErrActFlag = g_cErrActFlag | KILL_AP_FLAG;
             break;
           /* case 10,11 are added by Willy for detecting Ap process */
           case 10:
             memcpy(g_caToDbpErrCode,AP_DISAPPEAR_ERR_E,4);
             break;
           case 11:
             memcpy(g_caToDbpErrCode,AP_TOO_LONG_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

    case P_RemoteTxn    :
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,LOAD_TXN_MAP_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode,PRE_PROCESS_NOT_FOUND_ERR_E,4);
             break;
           case 3:
             memcpy(g_caToDbpErrCode,AP_PRE_PROCESS_ERR_E,4);
             break;
           case 4:
             memcpy(g_caToDbpErrCode,SEND_SIF_TO_SERVER_ERR_E,4);
             break;
           case 5:
             memcpy(g_caToDbpErrCode,RCV_SOF_FROM_SERVER_ERR_E,4);
             break;
           case 6:
             memcpy(g_caToDbpErrCode,CONV_IN_ERR_E,4);
             break;
           case 7:
             memcpy(g_caToDbpErrCode,POST_PROCESS_NOT_FOUND_ERR_E,4);
             break;
           case 8:
             memcpy(g_caToDbpErrCode,AP_POST_PROCESS_ERR_E,4);
             break;
           case 9:
             memcpy(g_caToDbpErrCode,SRH_PRE_FUN_BY_TXN_CODE_ERR_E,4);
             break;
           case 10:
             memcpy(g_caToDbpErrCode,SRH_POST_FUN_BY_TXN_CODE_ERR_E,4);
             break;
           case 11:
             memcpy(g_caToDbpErrCode,PREPA_APA_TO_POST_AP_ERR_E,4);
             break;
           case 12:
             memcpy(g_caToDbpErrCode,GET_BRH_PTR_ERR_E,4);
             break;
           case 13:
             memcpy(g_caToDbpErrCode,FMT_CONV_ERR_E,4);
             break;
           case 14:
             memcpy(g_caToDbpErrCode,CODE_CONV_ERR_E,4);
             break;
           case 15:
             memcpy(g_caToDbpErrCode,GET_SERVER_NAME_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;
    case P_IsTxnEnd              :
         switch ( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,AP_ABEND_NO_RLBK_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode,INPUT_TXN_TYPE_ERR_E,4);
             break;
           case 3:
             memcpy(g_caToDbpErrCode,RENDO_REQUEST_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

    case P_DbsTxEnd             :
         switch ( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,END_TXN_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

    case P_TxSeqMtn              :
         switch ( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,LOCK_SSA_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode,GET_SSA_PTR_ERR_E,4);
             break;
           case 3:
             memcpy(g_caToDbpErrCode,UNLOCK_SSA_ERR_E,4);
             break;
           case 4:
             memcpy(g_caToDbpErrCode,LOCK_TCT_ERR_E,4);
             break;
           case 5:
             memcpy(g_caToDbpErrCode,GET_TCT_PTR_ERR_E,4);
             break;
           case 6:
             memcpy(g_caToDbpErrCode,UNLOCK_TCT_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

    case P_RelIfEnv             :
         switch ( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,REL_IF_ENV_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

    default:
      sprintf(g_caMsg," ErrorMap(): No such function PRGID ! PrgID=%5d  iRc=%d"
              ,iPrgIdVal,iAbsIrc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
  } /* end switch */

}



void
ErrorAction()
{
  int iRc ;

  sprintf(g_caMsg,"[1]ErrorAction: g_cErrActFlag=%2x",g_cErrActFlag);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  sprintf(g_caMsg,"%s",g_caToDbpErrCode);
  PrintErrMsg(g_caMsg);

  if ( (g_cErrActFlag & KILL_AP_FLAG) ) {
    ErrLog(100,"ErrorAction: enter KillApProcess().....", RPT_TO_LOG,0,0);
    iRc = KillApProcess();
    sprintf(g_caMsg,"ErrorAction: Kill Ap Process.....");
    PrintErrMsg(g_caMsg);
    g_cErrActFlag &= (~KILL_AP_FLAG);
    ErrLog(100,"ErrorAction: exit KillApProcess().....",RPT_TO_LOG,0,0);
  }

  sprintf(g_caMsg,"[2]ErrorAction: g_cErrActFlag=%2x",g_cErrActFlag);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  if ( (g_cErrActFlag & DO_ROLLBACK_FLAG) ) {
    ErrLog(100,"enter DbsTxEnd().....",RPT_TO_LOG,0,0);
    iRc = DbsTxEnd( ROLLBACK_FLAG );
    sprintf(g_caMsg,"ErrorAction: DbsTxEnd().....");
    PrintErrMsg(g_caMsg);
    g_cErrActFlag &= (~DO_ROLLBACK_FLAG);
    ErrLog(100,"exit DbsTxEnd().....",RPT_TO_LOG,0,0);
  }

  sprintf(g_caMsg,"[3]ErrorAction: g_cErrActFlag=%2x",g_cErrActFlag);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  AbendRtn( -1 );

}
