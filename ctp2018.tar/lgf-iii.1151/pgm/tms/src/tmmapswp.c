#include <stdio.h>
#define FORWARD  'f'
#define BACKWARD 'b'
#define is_lowercase(x) ((x>='a' && x<='z') ? 1:0)
#define to_uppercase(x) ((is_lowercase(x)) ? x-'a'+'A':x)

main(argc,argv)
int argc;
char *argv[];
{
   FILE *fp,*fp1;
   char str[200];
   char *s;
   char name[100];
   char aplnk[100];
   char w_buf[200];
   char c;
   int i,j,idx1,idx2,k,ret,rec_len;
   int flag;

   if(argc < 2)
   { 
      printf("argument error !\n");
      exit(0);
   }
   s=argv[1];
   flag=0;
 
   
   sprintf(str,"cp %s/iii/bin/lib/tmmcalap.c ",(char *)getenv("III_DIR"));
/*
   printf("str=%s\n",str);  
*/
   strcpy(name,getenv("ucpaplnk"));
   strcpy(aplnk, name);
   strcat(aplnk,".bak");
   strcat(name,".c");
/*
   printf("name=%s\n",name);  
*/
   strcat(str,name);
   system(str);
/*
   strcat(str,name);
   strcpy(name,str);
   printf("name=%s\n",name);  
   printf("name=%s\n",name);  
*/


   if((fp=fopen(name,"r")) == NULL)
   {
       fprintf(stderr,"cant open file");
       return(-1);
   }
   if((fp1=fopen(aplnk,"w")) == NULL)
   {
       fprintf(stderr,"cant open file");
       return(-1);
   }

   for(i=0;i<80;i++)
   {
      str[i]='\0';
      w_buf[i]='\0';
   }
   while((rec_len=readln(fp,str,0)) != EOF)
   {
      if(flag==1)
      {
         w_buf[0]=' ';
         idx1=char_index(str,'(',FORWARD,0);
         idx2=char_index(str,' ',BACKWARD,idx1);
         for(i=0,j=1;i<=idx2;i++,j++) 
            w_buf[j]=str[i];
         for(i=0;s[i]!='\0';i++,j++)
            w_buf[j]=to_uppercase(s[i]);
         for(i=idx1;str[i]!='\0';i++,j++)
            w_buf[j]=str[i];
         w_buf[j]='\0';
         /*
         puts(w_buf);
         */
         writeln(fp1,w_buf);
         flag=0;
      }
      else
      {
         /*
         puts(str);
         */
         writeln(fp1,str);
      }
         
      if((ret=str_index(str,"$ucp_ap_link"))!=-1)
         flag=1;
     
   }
   fclose(fp);
   fclose(fp1);

   sprintf(str,"mv %s %s",aplnk, name);
   system(str);
/*
   printf("after mv name=%s\n",str);
*/

   if ( (char *)getenv("III_OS_CCFLAGS") != NULL )
     sprintf (str, "cc %s -c ", (char *)getenv("III_OS_CCFLAGS"));
   else
     strcpy (str, "cc -c ");

   /*
   strcpy(str,"cc -c ");
   */
   strcat(str,name);
/*
   printf("str=%s\n",str);  
*/
   system(str);

}

readln(fp,string,fun)
FILE *fp;
char string[];
int fun;
{
   int i;
   int c;

    i=0;
    while((c=fgetc(fp))!='\n')
    {
       if(c==EOF)
          return(EOF);
       string[i++]=c;
    }
    string[i]='\0';
    return(i);
}

str_index(string,substring)
char string[];
char substring[];
{
   int i,j,k,len;

   len=strlen(substring);
   for(i=0;string[i]!=NULL;i++)
     for(j=i,k=0;substring[k]==string[j];k++,j++)
        if(substring[k+1]==NULL)
           return(i+len);
   return(-1);
}

char_index(string,letter,fun,pos)
char string[];
char letter;
char fun;
int pos;
{
   int len;
   int index;
   
   switch(fun)
   {
      case(FORWARD):
        for(index=pos;string[index]!='\0';index++)
           if(string[index]==letter)
              return(index);
        return(-1);
      case(BACKWARD):
        for(index=pos;index>-1;index--)
           if(string[index]==letter)
              return(index);
        return(-1);
      default:
        return(-1);
   }
}
       
writeln(fp,string)
FILE *fp;
char string[];
{
   int i;
   
   i=0;
   while(string[i]!='\0')
      putc(string[i++],fp);
   putc('\n',fp);
}
