#ifndef H_UPCOMTWA
#define H_UPCOMTWA
#include "ucp.h"
struct HostToBrhInfoSt {
  char  cTxnStatus;
  char  caBrhCode[3];
  char  caTmCode[2];
  char  caTotalTxnSeqNo[7];
  char  caAccTxnSeqNo[5];
  char  caNonAccTxnSeqNo[5];
  char  caTxnCode[4];
  char  cSupKeyStatus;
  char  cBookStatus;
  char  caTellerCode[2];
  char  caSifLen[3];
  char  caFiller[66];
  char  caSifBuf[MAX_SIF_LEN];
} ;
#endif
