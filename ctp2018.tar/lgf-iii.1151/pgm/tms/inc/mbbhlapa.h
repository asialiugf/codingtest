#ifndef H_APA
#define H_APA 

/* ******************************************************************** */
/*              structure defined for AP Area (APA)                     */
/* ******************************************************************** */
struct ApaSt {
    char caTxnCode[6];                  /* txn code                     */
    char caBrCode[10];                  /* branch code                  */
    char caTmCode[4];                   /* teminal code                 */
    char caTellId[4];                   /* teller code                  */
    char caRevSupKey[4];                /* reverse supervisor key       */
    char cOriginBrStatus;               /* origin branch status         */
    char cTmType;                       /* teminal type                 */
    char cSupKeyStatus;                 /* supervisor key status(0/1)   */
    char cBookStatus;                   /* pass book status(0/1)        */
    char cTxnStatus;                    /* transaction status           */
    char cAprqt;                        /* required status(0/1)         */
    char cReentryStatus;                /* re-entry status(0/1)         */
    char cInterBankSource;              /* reserve for inter bank       */
    char cInterBankReturnCode;          /* reserve for inter bank       */
    char cOverTimeSwitch;               /* reservse for ATM             */
    char caTxnDate[8];                  /* txn date (yy/mm/dd)          */
    char caNextTxnDate[8];              /* next transaction state       */
    char caNnTxnDate[8];                /* reserved                     */
    char cNextBusiDayCnt;               /* next business day count      */
    char caTxnTime[6];                  /* txn time (hh:mm:ss)          */
    char caTotalTxnSeqNo[7];            /* total txn sequence number    */
    char caAccTxnSeqNo[5];              /* account txn sequence no      */
    char caNonAccTxnSeqNo[5];           /* non-account txn sequence no  */
    char caBtchTxnSeqNo[5];             /* batch txn sequence no        */
    char cApAbendNoRlbk;                /* ap abend not rollback        */
    char cTxnReturnCode;                /* txn return code(0 - 5)       */
    char caSystemFiller[207];           /* reserve for system           */
    char caApCommArea[400];             /* ap communication area        */
    char caMapApName[8];                /* main AP program ID           */
    char caSapApName[8];                /* sub AP program ID            */
    char cMsgqReturnCode;               /* return code for msgq access  */
    char cBifReturnCode;                /* BIF process return code      */
    char caDbsFileId[2];                /* file id for dbs call param.  */
    char caDbsSegName[8];               /* segment name for dbs call    */
    char caDbsSegKey[30];               /* segment key for dbs call     */
    char cDbsFileCall;                  /* dbs file call                */
    char cDbsFunCode;                   /* dbs function call            */
    char cDbsReturnCode;                /* dbs return call(0:normal)    */
    char caDbsErrCode[2];               /* dbs error code               */
    char cPbAdjIntFlag;
    char cCtAdjIntFlag;
    char cLnAdjIntFlag;
    char cTxnReinput;                   /* txn reinput status           */
    char caUserArea[233];
};
#endif
