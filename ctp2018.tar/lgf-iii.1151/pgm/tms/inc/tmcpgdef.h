/* tmmain.c */
#define P_Mtmmain 		20001

/* tmscwafn.c */
#define P_AttachCwa 		20101
#define P_CreatCwaSem 		20102
#define P_CreatCwaShm 		20103
#define P_CwaCtlFac 		20104
#define P_CwaLowCtlFac 		20105
#define P_DetachCwa 		20106
#define P_GetCwaId 		20107
#define P_GetCwaSegPtr 		20108
#define P_ReadCwa 		20109
#define P_RemoveCwa 		20110
#define P_SchTctIdx 		20111
#define P_UnOLockCwa 		20112
#define P_WriteCwa 		20113
#define P_GetBrhPtr 		20114

/* tmstwafn.c */
#define P_AttachTwa 		20201
#define P_CreatTwaSem 		20202
#define P_CreatTwaShm 		20203
#define P_DetachTwa 		20204
#define P_GetTwaId 		20205
#define P_GetTwaSegPtr 		20206
#define P_ReadTwa 		20207
#define P_RemoveTwa 		20208
#define P_TwaCtlFac 		20209
#define P_TwaLowCtlFac 		20210
#define P_UnOLockTwa 		20211
#define P_WriteTwa 		20212

/* tmsipcfn.c */
#define P_IpcSemCr 		20301
#define P_IpcSemDec 		20302
#define P_IpcSemInc 		20303
#define P_IpcSemRm 		20304
#define P_IpcSemSet 		20305
#define P_IpcSemVal 		20306
#define P_IpcShmCr 		20307
#define P_IpcShmRm 		20308
#define P_IpcShmat 		20309
#define P_IpcShmdt 		20310

/* tmserhdl.c */
#define P_ErrorAction 		20401
#define P_ErrorMap 		20402
#define P_TmsErrHdl 		20403

/* tmsenv.c */
#define P_AccessCwa 		21001
#define P_EnvSetup 		21002
#define P_GetConfg 		21003
#define P_GetKernl 		21004
#define P_GetPtrFromTwa 	21005
#define P_GetSysRs 		21006
#define P_GetTblAddr 		21007
#define P_GetTct 		21008
#define P_GetTwa 		21009
#define P_SignOn 		21010

/* tmsighdl.c */
#define P_AbendRtn 		21101
#define P_SigHandler 		21102
#define P_SignlHdl 		21103

/* tmscobit.c */
#define P_CobInit 		21201
#define P_CobExit 		21202

/* tmsifenv.c */
#define P_AttIfEnv 		21301
#define P_IniIfEnv 		21302
#define P_BgnIfEnv 		21303
#define P_EndIfEnv 		21304
#define P_RelIfEnv 		21305
#define P_DetIfEnv 		21306
#define P_GetIfPgm 		21307
#define P_ExeIfEnv 		21308
#define P_RunAllIfEnv 		21309

/* tmstwast.c */
#define P_StSysVal 		21401
#define P_SetServerId 		21402
#define P_SetSysMode 		21403
#define P_GetServerId 		21404
#define P_GetSysMode 		21405
#define P_InitTWA 		21406
#define P_SetTmaBySif           21407 
#define P_SetTmaByApaOut        21408  

/* tmsflrbk.c */
#define P_FlTxRlbk 		22001

/* tmsinit.c */
#define P_TxInit 		23001
#define P_InitSysEnv 		23002

/* tmstxin.c */
#define P_TxInput 		24001
#define P_TxKind 		24002
#define P_ListTxIn 		24003
#define P_SeqIntIn 		24004
#define P_InputChk 		24005
#define P_SetInDataType 	24006
#define P_GetInTypeFromSif 	24007
#define P_SetTime 		24008
#define P_ChkTerml 		24009
#define P_IsRentryTm 		24010
#define P_RentryCk 		24011
#define P_ComputTime 		24012
#define P_MultTxIn 		24013
#define P_IsMultipleBegin       24014
#define P_IsListBegin           24015
#define P_IsMultipleEnd         24016
#define P_IsListEnd             24017
#define P_IsMultipleDataEnd     24018
#define P_IsListDataEnd         24019

/* tmsdcsfn.c */
#define P_GetInput 		24101
#define P_TmsDataSend 		24102
#define P_SendErrToDbp 		24103
#define P_SendAckToEms 		24104
#define P_SendShutOkToEms	24105
#define P_GetAck        	24106
#define P_ReqEmsToRestart      	24107
#define P_RcvTmsRestartStus   	24108
#define P_GetEmsDisconnect 	24109
#define P_SendDisconnect 	24110
#define P_RcvTmsShutStus   	24111
#define P_DoDcsAbort		24112

/* tmsinedt.c */
#define P_EditItem 		24201
#define P_GetCitAddr 		24202
#define P_GetCtfDesc 		24203
#define P_GetItmStartAddr 	24204
#define P_GetSifFmt 		24205
#define P_GetTxnCode 		24206
#define P_InputEdt 		24207
#define P_ReadIet 		24208
#define P_SetTwaByIet 		24209

/* tmsfmtcv.c */
#define P_InputCnv 		24301
#define P_GetConvPgm 		24302
#define P_CheckDes 		24303

/* tmsctf.c */
#define P_AttchCtf 		24401
#define P_AttchIct 		24402
#define P_AttchIet 		24403
#define P_CrtTblArea 		24404

/* tmsdatcv.c */
#define P_AsciiCnv 		24501
#define P_AsiCnv 		24502
#define P_CharStuff 		24503
#define P_Comp3Cnv 		24504
#define P_DataCnv 		24505
#define P_FloatStuff 		24506
#define P_IntStuff 		24507
#define P_LongCnv 		24508
#define P_PackFunc 		24509
#define P_SasciiCnv 		24510
#define P_ShortCnv 		24511
#define P_SignStuff 		24512
#define P_StuffData 		24513

/* tmscvout.c */
#define P_ConvItem 		24601
#define P_CtfToSif 		24602
#define P_GetSifFromCtf		24603
#define P_NumToStr 		24604
#define P_Remove0 		24605
#define P_Reverse 		24606
#define P_ApDataToSif 		24607
#define P_UnpackFun 		24608
#define P_SignNumToStr 		24609

/* smsidxld.c */
#define P_get_gud 		24701
#define P_get_msg 		24702
#define P_get_mst 		24703
#define P_iet_srh 		24704
#define P_imfhlpld 		24705
#define P_imfhlpmk 		24706
#define P_imfmdtld 		24707
#define P_imfmstld 		24708
#define P_imftblrd 		24709
#define P_imftxnld 		24710
#define P_tbl_read 		24711

/* tmsstart.c */
#define P_TxStart 		25001
#define P_TxEnvPre 		25002
#define P_IsTxnBegin 		25003

/* tmsapa.c */
#define P_PrepaApa 		25101
#define P_ChkPrePostApRtnCode	25102
#define P_PrepaApaToPostAp	25103

/* tmscomp3.c */
#define P_PackData		25201
#define P_UnpackData       	25202
#define P_Comp3Conv        	25203

/* tmmcalap.c */
#define P_ApCode 		25301
#define P_Mtmmcalap 		25302

/* tmsapenv.c */
#define P_ApEnvSetup		25401
#define P_ApEnvRls		25402
#define P_ApMain		25403
#define P_GetInfoFromTwa	25404
#define P_RunApCode     	25405
#define P_WriteToTba            25406

/* tmsaplnk.c */
#define  P_UCPDBS_AP         25501
#define  P_UCPFCS_AP         25502
#define  P_UCPDCS_AP         25503
#define  P_UCPWRITE_AP       25504
#define  P_UCPPRINT_AP       25505
#define  P_NACINT_AP         25506
#define  P_NBCINT_AP         25507
#define  P_NARINT_AP         25508
#define  P_SBSHMFAC_AP       25509
#define  P_UCPTXLOG_AP       25510
#define  P_TPGIOHDL_AP       25511
#define  P_TPFDBS_AP         25512
#define  P_TPFFCS_AP         25513
#define  P_TPEDCS_AP         25514
#define  P_TPEWRITE_AP       25515
#define  P_TPESDOUT_AP       25516
#define  P_UCPSDCLT_AP       25517
#define  P_TPFCWARW_AP       25518
#define  P_TPETXLOG_AP       25519
#define  P_UCPLOG_AP         25520
#define  P_TPEAPRQT_AP       25521
#define  P_TPESCRQT_AP       25522
#define  P_TPFRPT_AP         25523
#define  P_TPFLOGOP_AP       25524
#define  P_TPERVSOP_AP       25525
#define  P_TPEGPREV_AP       25526
#define  P_TPESDCLT_AP       25527
#define  P_TPFGTSEQ_AP       25528
#define  P_TPFADSEQ_AP       25529
#define  P_TPFRKSEQ_AP       25530
#define  P_TPEONBTH_AP       25531
#define  P_TPEGTSIF_AP       25532
#define  P_TPFSETLN_AP       25533
#define  P_UBCINT_AP         25534
#define  P_TPEONBH1_AP       25535
#define  P_TPEONBH2_AP       25536
#define  P_TPEONBHE_AP       25537
#define  P_TPEREOUT_AP       25538
#define  P_TPELTINQ_AP       25539
#define  P_TPECOPTX_AP       25540

/* tmmapswp.c */
#define P_Mtmmapswp 		25601
#define P_char_index 		25602
#define P_is_lowercase 		25603
#define P_readln 		25604
#define P_str_index 		25605
#define P_to_uppercase 		25606
#define P_writeln 		25607

/* tmsapsig.c */
#define  P_ApSignalSet      25701
#define  P_ApSigHdl         25702

/* tmstxpro.c */
#define P_TxProces	26001
#define P_ApDispth	26002
#define P_CallTxnFunc	26003
#define P_ApFunc	26004

/* tmsexec.c */
#define P_ExecAp 		26101
#define P_ServiceAp 		26102

/* tmsremot.c */
#define    P_RemoteTxn 		26201
#define    P_LdTxMapFunName     26202
#define    P_SrhFunByTxnCode    26203
#define    P_PRE_AP             26204
#define    P_POST_AP            26205
#define    P_RcvHostDataToFile  26206
#define    P_SndSifToRmtHost    26207
#define    P_RmtProc            26208

/* tmsapi.c */
#define  P_UCPDBS         26301
#define  P_TPFDBS         26302
#define  P_UCPFCS         26303
#define  P_TPFFCS         26304
#define  P_UCPDCS         26305
#define  P_TPEDCS         26306
#define  P_UCPWRITE       26307
#define  P_TPEWRITE       26308
#define  P_UCPPRINT       26309
#define  P_TPESDOUT       26310
#define  P_SBSHMFAC       26311
#define  P_TPFCWARW       26312
#define  P_UCPTXLOG       26313
#define  P_TPETXLOG       26314
#define  P_UCPSDCLT       26315
#define  P_NACINT         26316
#define  P_NBCINT         26317
#define  P_NARINT         26318
#define  P_UCPLOG         26319
#define  P_TPEAPRQT       26320
#define  P_TPESCRQT       26321
#define  P_TPGIOHDL       26322
#define  P_TPFRPT         26323
#define  P_TPFLOGOP       26324
#define  P_TPERVSOP       26325
#define  P_TPEGPREV       26326
#define  P_TPESDCLT       26327
#define  P_TPFGTSEQ       26328
#define  P_TPFADSEQ       26329
#define  P_TPFRKSEQ       26330
#define  P_TPEONBTH       26331
#define  P_TPEGTSIF       26332
#define  P_TPFSETLN       26333
#define  P_TPEONBH1       26334
#define  P_TPEONBH2       26335
#define  P_TPEONBHE       26336
#define  P_TPEREOUT       26337
#define  P_TPELTINQ       26338
#define  P_TPECOPTX       26339

/* tmsrentry.c */
#define  P_RdWtReentrySeq 25598
#define  P_SetBrhLine     25599

/* tmscwarw.c */
#define   P_ShmFac          26401
#define   P_ReadLock        26402
#define   P_WriteUnlock     26403
#define   P_CheckSegName    26404
#define   P_ReadOnly        26405
#define   P_WriteOnly       26406
#define   P_GetEjRrn        26407

/* tmssync.c */
#define P_WakeTpu	26501
#define P_SleepTpu	26502
#define P_WakeAp	26503
#define P_SleepAp	26504
#define P_InitSync	26505
#define P_RelsSync	26506
#define P_ResetSync     26507

/* tmsfnsrh.c */
#define P_SearchApFuncAddr	26601

/* tmsend.c */
#define P_TxEnd                 27001
#define P_Reinput               27002
#define P_TxSeqMtn              27003
#define P_TxOutput              27004
#define P_IsTxnEnd              27005
#define P_SetRevFlagOff         27006
#define P_SysWrtLogForAp        27007
#define P_TrmRelease            27008

/* tmsrm.c */
#define P_DbsTxBegin 		27101
#define P_DbsTxEnd 		27102

/* tmslogrk.c */
#define P_InLgRlBk 		27201

/* tmsiofac.c */
#define P_EndUcpio 		27301
#define P_StartUcpio 		27302
#define P_UCPIO 		27303
#define P_c_string 		27304
#define P_ck_data_type 		27305
#define P_ck_io_parm 		27306
#define P_del_char 		27307
#define P_dsp_line 		27308
#define P_get_byte_cnt 		27309
#define P_ins_char 		27310
#define P_is_chinese_byte 	27311
#define P_is_chinese_code 	27312
#define P_rep_char 		27313
#define P_set_cusr 		27314
#define P_ucp_in 		27315
#define P_ucp_move 		27316
#define P_ucp_out 		27317
#define P_w_lprint 		27318
#define P_w_putc 		27319
#define P_w_puts 		27320

/* tmsoutpt.c */
#define P_OutptSel	  28001
#define P_UnixClientSof   28002
#define P_WriteToOutptShm 28003
#define P_TxEndInform	  28004
#define P_SendToIO	  28005
#define P_IsMore	  28006
#define P_AddSofHeadToSif 28007
#define P_GetSndMethod 	  28008

/* tmsrelse.c */
#define P_TxRelese		29001
#define P_EnvRelse		29002
#define P_KillApProcess		29003

/* tmbtxin.c */
#define  P_JclInput          54001
#define  P_SetTwaForBatch    54002
#define  P_MakPsuSif         54003
#define  P_CheckJclFile      54004

