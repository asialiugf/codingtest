#ifndef H_UCP
#define H_UCP

#define    MAX_BR_LEN   10   /* max len of branch code             */
#define    MAX_TM_LEN    5   /* max len of terminal code           */
#define    MAX_TEL_LEN  10   /* max len of teller code             */
#define    MAX_TXN_LEN  10   /* max len of txn code                */
#define    MAX_SIF_CTF_LEN  520   /* max len of SIF                */
#define    MAX_CTF_LEN  MAX_SIF_CTF_LEN /* max len of CTF          */
#define    MAX_SIF_LEN  MAX_SIF_CTF_LEN /* max len of SIF          */
#define    MAX_REV_LEN  400   /* max len of REV                    */

/* -------------------  SIF FORMAT DEFINE ----------------------- */
#define    SIF_FMT_1		"TPEI"
#define    SIF_FMT_2		"UCP2"
#define    SIF_FMT_3		"UCP3"
#define    FMT_1		'1'
#define    FMT_2		'2'
#define    FMT_3		'4'
#define    FMT_CTF		'3'
#define    FMT_SIF		'4'

/* -------------------  SIF CONSTANTS DEFINE --------------------- */
/* --  DEFINE CONSTANT for <The Length of every field in SIF> ---- */
#define    SIF_FMT_LEN		4 
#define    MAX_TXN_CODE_LEN		6
#define    BR_CODE_LEN		10 
#define    TM_CODE_LEN		4  
#define    TELLER_CODE_LEN	4  
#define    USER_DEFINE_LEN	20
#define    LINE_NO_LEN	        1
#define    CTL_BYTE_LEN		2  

/* --  DEFINE OFFSET for <The Length of every field in SIF> ---- */
#define    SIF_FMT_OFFSET	0 
#define    TXN_CODE_OFFSET      (SIF_FMT_OFFSET + SIF_FMT_LEN )
#define    BR_CODE_OFFSET	(TXN_CODE_OFFSET + MAX_TXN_CODE_LEN )
#define    TM_CODE_OFFSET	(BR_CODE_OFFSET + BR_CODE_LEN  )
#define    TELLER_CODE_OFFSET   (TM_CODE_OFFSET + TM_CODE_LEN	)
#define    USER_DEFINE_OFFSET   (TELLER_CODE_OFFSET + TELLER_CODE_LEN )
#define    LINE_NO_OFFSET       (USER_DEFINE_OFFSET + USER_DEFINE_LEN )
#define    CTL_BYTE_OFFSET	(LINE_NO_OFFSET + LINE_NO_LEN  )
#define    SIF_HEAD_LEN         (CTL_BYTE_OFFSET + CTL_BYTE_LEN  )
#define    SIF_DATA_LEN_SIZE	2  /* real <datalen field> length     */

/* -------------------  SOF CONSTANTS DEFINE --------------------- */
/* --  DEFINE CONSTANT for <The Length of every field in SOF> ---- */
#define    SOF_DCS_CODE_LEN      3
#define    SOF_BR_CODE_LEN      10 
#define    SOF_TM_CODE_LEN       4 
#define    SOF_OUT_DEV_LEN       1 
#define    SOF_MSG_CODE_LEN      7 
#define    SOF_CTL_CODE_LEN      2 
#define    SOF_DATA_LEN          2

/* --  DEFINE OFFSET for <The Length of every field in SOF> ---- */
#define    SOF_DCS_CODE_OFFSET   0
#define    SOF_BR_CODE_OFFSET    (SOF_DCS_CODE_OFFSET + SOF_DCS_CODE_LEN )
#define    SOF_TM_CODE_OFFSET    (SOF_BR_CODE_OFFSET + SOF_BR_CODE_LEN )
#define    SOF_OUT_DEV_OFFSET    (SOF_TM_CODE_OFFSET + SOF_TM_CODE_LEN )
#define    SOF_MSG_CODE_OFFSET   (SOF_OUT_DEV_OFFSET + SOF_OUT_DEV_LEN)
#define    SOF_CTL_CODE_OFFSET   (SOF_MSG_CODE_OFFSET + SOF_MSG_CODE_LEN)
#define    SOF_DATA_LEN_OFFSET   (SOF_CTL_CODE_OFFSET + SOF_CTL_CODE_LEN)

#define    SOF_HEAD_LEN          SOF_DATA_LEN_OFFSET
#define    SOF_HEAD_LEN_PLUS_2   (SOF_DATA_LEN_OFFSET + SOF_DATA_LEN)

#define    SOF_DCS_CODE_SIZE     3  /* real <dcs fun code> data length */
#define    SOF_OUT_DEV_SIZE      1  /* real <out device> length        */
#define    SOF_MSG_CODE_SIZE     4  /* real <msg code> length          */
#define    SOF_CTL_CODE_SIZE     2  /* real <cntl code> length         */
#define    SOF_DATA_LEN_SIZE     2  /* real <datalen field> length     */

/* -------------------  CONSTANTS DEFINE --------------------- */
#define    DATE_LEN              8
#define    TXN_SEQ_NO_LEN        3
#define    TXN_NEW_SEQ_NO_LEN    5
#define    TIME_LEN              6

#endif
