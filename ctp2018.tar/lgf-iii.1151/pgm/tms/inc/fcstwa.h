#ifndef H_UPCIOARA
#define H_UPCIOARA
struct fcs_twa {
	char fcs_filename[8];
	char fcs_key[50];
	char fcs_keylen[2];
	char fcs_funcode[4];
	char fcs_indexnum[2];
	char fcs_openmode[8];
	char fcs_rtncode[2];
	char fcs_errcode[4];
	} ;

/* fcs return code */
#define   FCS_M_NORMAL                    "00"
#define   FCS_M_NO_REC_FOUND              "01"
#define   FCS_M_DUPLICATE                 "02"
#define   FCS_M_WRONG_CALL_SEQ            "03"
#define   FCS_M_NO_MORE                   "04"
#define   FCS_M_INVALID_FUN               "05"
#define   FCS_M_IO_ERR                    "06"
#define   FCS_M_SERVICE_ERR               "07"
#define   FCS_M_LOCK_ERR                  "08"

/* fcs return code (integer) */
#define   FCS_M_NORMAL_INT                  0
#define   FCS_M_NO_REC_FOUND_INT            1
#define   FCS_M_DUPLICATE_INT               2
#define   FCS_M_WRONG_CALL_SEQ_INT          3
#define   FCS_M_NO_MORE_INT                 4
#define   FCS_M_INVALID_FUN_INT             5
#define   FCS_M_IO_ERR_INT                  6
#define   FCS_M_SERVICE_ERR_INT             7
#define   FCS_M_LOCK_ERR_INT                8

/*  FCS_M_DBS_FUN                        */
#define   FCS_M_RANDOM_READ              "1   "
#define   FCS_M_RANDOM_READ_UPDATE       "2   "
#define   FCS_M_READ_NEXT_S              "3   "
#define   FCS_M_READ_NEXT_UPDATE_S       "4   "
#define   FCS_M_WRITE_UPDATE             "5   "
#define   FCS_M_INSERT                   "6   "
#define   FCS_M_APPEND                   "7   "
#define   FCS_M_READ_F_SEG               "8   "
#define   FCS_M_READ_UPDATE_F_SEG        "9   "
#define   FCS_M_READ_L_SEG               "A   "
#define   FCS_M_READ_UPDATE_L_SEG        "B   "
#define   FCS_M_READ_NEXT                "C   "
#define   FCS_M_READ_NEXT_UPDATE         "D   "
#define   FCS_M_READ_UPDATE_NOIOA        "E   "
#define   FCS_M_UPDATE_WITH_READ         "F   "
#define   FCS_M_READ_F_GE_KEY            "G   "
#define   FCS_M_READ_UPDATE_F_GE_KEY     "H   "
#define   FCS_M_OPEN                     "O   "
#define   FCS_M_BIMF_CLOSE               "S   "
#define   FCS_M_BIMF_OPEN                "U   "
#define   FCS_M_DELETE                   "X   "
#define   FCS_M_CLOSE                    "Z   "
#define   FCS_M_SEQ_READ_F_SEG           "a   "
#define   FCS_M_SEQ_READ_NEXT            "b   "
#define   FCS_M_SEQ_READ_L_SEG           "c   "
#define   FCS_M_SEQ_READ_PREV            "d   "
#define   FCS_M_UNLOCK                   "e   "

#endif
