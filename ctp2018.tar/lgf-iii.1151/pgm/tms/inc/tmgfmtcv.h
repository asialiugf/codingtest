#ifndef H_APA
#define H_APA 

extern int CheckDes();

#endif
