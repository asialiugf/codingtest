
/* <tmsstart.c> error message code */
#define TXN_TYPE_ERR             -1
#define RENDO_REQUEST_ERR        -2

/* <tmsstart.c> DbsTxBegin() error message code */
#define BEGIN_TXN_ERR            -1
