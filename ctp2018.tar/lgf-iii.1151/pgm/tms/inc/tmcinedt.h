#ifndef H_TMCINEDT
#define H_TMCINEDT

#include "imctblld.def"
#include "itctblof.str"
#include "imctblld.str"
#include "itctxnld.def"
#include "ucp.h"

/* AT&T machine: MSB byte -> high address, LSB byte -> low address */
/* IBM machine : MSB byte -> low address, LSB byte -> high address */
#define HIGH_BYTE		0
#define LOW_BYTE		1

#define BUSI_DESC		'b'
#define TXN_DESC		't'
#define ITM_DESC		'i'
#define IET_KEY_LEN		9

/***********************************
 * Constants for coding convention *
 ***********************************/
#define ImfTblRd		imftblrd
#define caTxnPgm		txn_pgm
#define caBusiDir		busi_dir
#define cCharc			charc
#define cBusiType		busi_type
#define iCitOffs		cit_offs
#define iInitIdx		init_idx
#define iCtfRelat		ctf_relat
#define iDataLen		dat_len
#define iCtfLen			ctf_len
#define iCtfOffs		ctf_offs
#define cIniValue		ini_value
#define cDatAttr		dat_attr
#define sTotItem		tot_item
#define iDotPos			dot_pos
#define cDataType		dat_type

struct SIF {
  char caSifFmt[ SIF_FMT_LEN ];
  char caTxnCode[ TXN_CODE_LEN ];
  char caBrCode[ BR_CODE_LEN ];
  char caTmCode[ TM_CODE_LEN] ;
  char caTellerCode[ TELLER_CODE_LEN ];
  char caUserData[ USER_DEFINE_LEN ];
  char cLineNo; 
  char caCtlByte[ CTL_BYTE_LEN ];
  char caData[ MAX_SIF_LEN - SIF_FMT_LEN - TXN_CODE_LEN - 
               BR_CODE_LEN - TM_CODE_LEN - TELLER_CODE_LEN - USER_DEFINE_LEN -
               LINE_NO_LEN - CTL_BYTE_LEN ];
};

#endif
