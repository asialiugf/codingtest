#ifndef H_TMGIFMOD
#define H_TMGIFMOD

/* FOR DCS */
extern int DcsInitAll();
extern int DcsInitPrgId();
extern int DcsStopAllApi();
extern int DcsTermAll();

/* FOR FCS */
extern int FitAttch();
extern int begin_txn();
extern int end_txn();
extern int fcs_closeall();
extern int islogclose();

/* FOR FCS */
extern int LogBegin();
extern int LogEnd();

#endif
