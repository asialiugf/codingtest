
/* <tmsrelse.c> TxRelse() error message code */
#define  REL_IF_ENV_ERR        -1
#define  DET_IF_ENV_ERR        -2
/* <tmsrelse.c> EnvRelse() error message code */
#define  REMOVE_TWA_ERR        -3
#define  REMOVE_SYNC_ERR       -4
#define  KILL_AP_ERR           -5
