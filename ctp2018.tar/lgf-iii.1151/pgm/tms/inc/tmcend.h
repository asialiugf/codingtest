/* <tmsend.c> IsTxnCommit() error message code */
#define  AP_ABEND_NO_RLBK_ERR  -1 
#define  INPUT_TXN_TYPE_ERR    -2
#define  RENDO_REQUEST_ERR     -3

/* <tmsend.c> DbsTxEnd() error message code */
#define  END_TXN_ERR           -1

/* <tmsend.c> TxSeqMtn() error message code */
#define  LOCK_SSA_ERR          -1
#define  GET_SSA_PTR_ERR       -2
#define  UNLOCK_SSA_ERR        -3
#define  LOCK_TCT_ERR          -4
#define  GET_TCT_PTR_ERR       -5
#define  UNLOCK_TCT_ERR        -6

/* <tmsend.c> SysWrtLogForAp() error message code */
#define  SYS_WRT_LOG_ERR       -1

/* <tmsend.c> Reinput() error message code */
/* will reference function in <tmsoutpt.c> error message code 
#define SIF_LEN_OVERFLOW                -1 */
/* will reference function in <tmscvout.c> error message code 
#define CTFTOSIF_BUSI_ERR		-14
#define CTFTOSIF_TXN_ERR		-15
#define CTFTOSIF_ITM1_ERR		-16
#define CTFTOSIF_ITMn_ERR		-17
#define CTFTOSIF_CNVITM1_ERR		-18
#define CTFTOSIF_CNVITMn_ERR		-19*/

