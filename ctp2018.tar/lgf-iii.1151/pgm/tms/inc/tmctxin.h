#ifndef H_TMCTXIN
#define H_TMCTXIN

/* <tmstxin.c> error message code */
#define TXINPUT_TYPE_ERR		-1

/* <tmstxin.c> SIF_LEN_OVER error message code */
#define SIF_LEN_OVERFLOW                -1

/* <tmstxin.c> GetInput() error message code */
#define GET_INPUT_ERR			-1

/* <tmstxin.c> SeqIntIn() error message code */
#define GET_SEQINT_ERR			-1
#define GET_SSA_PTR_ERR                 -3
#define TXN_ENABLE_ERR                  -4

/* <tmstxin.c> InputCnv() error message code */
#define INPUTCNV_ERR			-1
#define INPUTCNV_SIF_LEN_OVERFLOW_ERR	-2

/* <tmstxin.c> InputChk() error message code */
#define CHK_TERML_ERR			-1
#define RENTRY_CK_ERR			-2
#define CHK_REENTRY_TM_ERR		-3
#define CHK_ONLINE_TM_ERR		-4
#define TERMINAL_IS_ON_USE_ERR		-5
#define CHKTERML_LOCK_TCT_ERR		-6
#define CHKTERML_UNLOCK_TCT_ERR		-7


/* <tmstxin.c> InputEdt() error message code */
#define INPUTEDT_BUSI_ERR		-1
#define INPUTEDT_TXN_ERR		-2
#define INPUTEDT_ITM1_ERR		-3
#define INPUTEDT_ITMn_ERR		-4
#define GETSIFFMT_ERR			-5
#define GETCTFDESC_ERR			-6
#define EDITITEM_LEN_ERR		-7

/* InputEdt() will reference function in <tmsdatcv.c> error message code */
#define COMP3CNV_ERR			-8
#define SHORTCNV_ERR			-9
#define LONGCNV_ERR			-10
#define ASICNV_ERR			-11
#define ASCIICNV_ERR			-12
#define SASCIICNV_ERR			-13
#define DOT_NUMBER_ERR			-20

/* InputEdt() will reference function in <tmscvout.c> error message code */
#define CTFTOSIF_BUSI_ERR		-14
#define CTFTOSIF_TXN_ERR		-15
#define CTFTOSIF_ITM1_ERR		-16
#define CTFTOSIF_ITMn_ERR		-17
#define CTFTOSIF_CNVITM1_ERR		-18
#define CTFTOSIF_CNVITMn_ERR		-19

/* <tmstxin.c> MultTxIn() error message code */
#define MULTTXIN_TXN_ERR                -1

#endif
