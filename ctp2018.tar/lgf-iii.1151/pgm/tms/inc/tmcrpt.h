#define     MSG_MAX_LENG     5000
#define     MAX_LINE_LEN      200
#define     MAX_FILE_OPEN      10
#define     FILE_NAME_LEN      80
#define     MAX_TOKEN_LEN      20
#define     FORM_ID_LEN         4
#define     TPFRPT_OPEN      '0'  /* open file */
#define     TPFRPT_WRITE     '1'  /* write data to prescribe file */
#define     TPFRPT_CLOSE     '2'  /* close file */
#define     TPFRPT_CLOSE_ALL '3'  /* close all files */
#define     R_NORMAL           0     /* write or close processing normal end*/
#define     F_CTL_ERR         -1     /* form control information error */
#define     F_IPOS_ERR        -2     /* invalid initial position declared */
#define     F_IVDEL_ERR       -3     /* invalid delimiter */
#define     F_PARSER_ERR      -4     /* parser form file error */
#define     OPEN_FORM_ERR     -5     /* open form file error                */
#define     UN_PRINTABLE_CHAR  '?'    /* stand for the unprintable character */
#define     F_NORMAL           '0'     /* write or close processing normal end*/
#define     F_OPEN_ERR         '4'     /* open form file error                */
#define     CLOSE_ERR          '5'     /* close file error                    */
#define     NOT_A_FCODE        '6'     /* not a defined function code */
#define     OPEN_TOO_MANY      '7'     /* not a defined function code */
#define     F_NOT_OPEN         '8'     /* write to file before open       */
#define     F_REOPEN           '9'     /* re open file error                  */
#define     F_WRT_ERR          'A'     /* write file error                    */
#define     PARSER_ERR         'B'     /* parser form file error */
#define     CTL_ERR            'C'     /* form control information error */
#define     FORM_OUTPATH       "/iii/dat/"     /* output file path  	      */
#define     SPACE                    ' '
#define     D_BTFILE                 'T'
       /* copy from imsout.c end   */
/*-------------- structure declaration for this program only ---------------*/
struct fmt_cvt {
      char  data_type;   /* the data type of the input data to be convert   */
                         /* 'c' -> char, 'b' -> binary, 'f' -> real num.    */
                         /* 'p' -> packed decimal, 'C' -> constant output   */
                         /* 'N' -> newline char                             */
      short in_len;      /* number of bytes retrieves from the output data  */
      short out_len;     /* the length of the data after converting         */
      short dig_pos;     /* the digital position of the output data         */
      char  cdata[MAX_LINE_LEN]; /* constant char. defined in form file     */
};
struct ctl_data {        /* this struct describes the ctl info. of a form   */
     int  init_x;        /* initial x corrdinate of a form file             */
     int  init_y;        /* initial y corrdinate of a form file             */
     char filler[20];    /* reserved control data                           */
};
struct file_table {
     char filename[FILE_NAME_LEN+1];  /* the filename will be opened        */
     int  fd;            /* the file descriper of the filename              */
};
struct output_info {
     char func_code;     /* the code to direct normal write or end write    */
     char filename[FILE_NAME_LEN]; /* the filename want to open             */
     char r_code;        /* thr return code. 0:normal;1:write err;2:open err*/
                         /*                  3:close err                    */
     char  msg_type[1] ;
     char  msg_code[3];
     char  caLength[4];
     char  out_type[1] ;
     char  out_msgs[MSG_MAX_LENG];
} ;  
