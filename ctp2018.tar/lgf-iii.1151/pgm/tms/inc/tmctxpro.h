
/* <tmstxpro.c> TxProces() error message code */
#define TXN_PATTERN_ERR      -1
#define SYSTEM_ROLE_ERR      -2

/* <tmstxpro.c> ApDispth() error message code */
#define AP_NOT_EXIST_ERR     -1
#define EXE_NOT_EXIST_ERR    -2
#define FORK_ERR             -3
#define WAKE_TPU_ERR         -4
#define SLEEP_TPU_ERR        -5
#define GET_ACIA_PTR_ERR     -6
#define AP_ABEND_EXIT_ERR    -7
#define WAKE_AP_ERR          -8
#define TPEWRITE_CALL_SEQ_ERR -9
#define AP_DISAPPEAR_ERR     -10
#define AP_TOO_LONG_ERR      -11
          
/* <cmsipcfn.c> IpcSemDec() error message code */
#define IPC_SEMDEC_TIMEOUT    -13
