
/* <tmsoutpt.c> TxEndInform()  error message code */
#define OPEN_OUTPUT_FILE_ERR	-1
#define GET_TBA_PTR_ERR 	-2
#define WRITE_TO_FILE_ERR	-3
#define CLOSE_OUTPUT_FILE_ERR 	-4
#define INVALID_MSG_CNT_ERR 	-5
#define TPESCRQT_DATA_LEN_ERR 	-6
#define AP_NORMAL_END_BUT_SND_MXXX_MSG	-7
#define AP_ABNORMAL_END_BUT_SND_TXXX    -8

/* <tmsoutpt.c> SendToIO()  error message code */
#define OPEN_INPUT_FILE_ERR	-1
#define GET_SEND_METHOD_ERR	-2
#define GET_FILE_STATUS_ERR	-3
#define OUTPUT_FILE_EMPTY_ERR	-4
#define SEND_SIZE_OVERFLOW_ERR	-5
#define TMS_DATA_SEND_ERR	-6
#define READ_INPUT_FILE_ERR	-7
#define IS_MORE_ERR		-8
#define SEND_METHOD_ERR 	-9
#define GET_ACK_ERR       	-10
#define FIRST_ACK_ERR       	-11
#define OTHER_ACK_ERR       	-12
#define CONVERT_OUT_ERR       	-13
