#define	MAX_CMD		5
struct	io_cmd
	{
	char	cmd_id;		/* command id             */
	char	data_type;	/* input data type        */
	char	data_len[2];	/* data length            */
	char	row[2];		/* row of I/O position    */
	char	col[2];		/* column of I/O position */
	};

struct	ioarea
	{
	char		retn_code;		/* return code      */
	char		cmd_no;			/* toatl command no */
	struct	io_cmd	cmd[MAX_CMD];		/* command content  */
	char		cmd_data[MAX_CMD * 99]; /* I/O data         */
	};
