#ifndef H_TMCIFENV
#define H_TMCIFENV

#define PGM_ATTACH		1
#define PGM_INITIAL		2
#define PGM_BEGIN		3
#define PGM_END		        4
#define PGM_RELEASE             5
#define PGM_DETACH		6

#endif
