struct HostToBrhInfoSt {
  char  cTxnStatus;
  char  caBrhCode[10];
  char  caTmCode[4];
  char  caTotalTxnSeqNo[8];
  char  caAccTxnSeqNo[5];
  char  caNonAccTxnSeqNo[5];
  char  caTxnCode[6];
  char  cSupKeyStatus;
  char  cBookStatus;
  char  caTellerCode[4];
  char  caSifLen[3];
  char  caBthTxnSeqNo[5];
  char  caPostLen[4];
  char  caEjLen[4];
  char  caFiller[39];
  char  caSifBuf[MAX_SIF_LEN];
} ;
