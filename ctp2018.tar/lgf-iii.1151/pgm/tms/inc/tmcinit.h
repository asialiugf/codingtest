/* <tmsinit.c> InitSysEnv() error message code */
#define RESET_SYNC_ERR        -1

/* <tmsinit.c> IniIfEnv() error message code */
#define INIT_IF_ENV_ERR       -1
