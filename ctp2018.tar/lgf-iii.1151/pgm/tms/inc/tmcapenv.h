/* <tmsapenv.c> ApMain() error message code */
#define AP_ENV_SETUP_ERR          -1
#define RUN_AP_CODE_ERR           -2
#define AP_ENV_RLS_ERR            -3

/* <tmsapenv.c> ApEnvSetup() error message code */
#define GET_INFO_FROM_TWA_ERR     -4
#define ATTACH_DBT_SHM_ERR        -5

/* <tmsapenv.c> ApEnvRls() error message code */
#define DETACH_DBT_SHM_ERR        -6
#define WAKE_TPU_ERR              -7
#define DETACH_TWA_ERR            -8

/* <tmsapenv.c> GetInfoFromTwa() error message code */
#define GET_TWA_ID_ERR            -9
#define ATTACH_TWA_ERR            -10
#define GET_TMA_PTR_ERR           -11
#define GET_COA_PTR_ERR           -12
#define GET_APA_PTR_ERR           -13
#define GET_TBA_PTR_ERR           -14
