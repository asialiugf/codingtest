#ifndef H_APA
#define H_APA 

/* ******************************************************************** */
/*              structure defined for AP Area (APA)                     */
/* ******************************************************************** */
struct ApaSt {
    char caBrCode[3];                   /* branch code                  */
    char caTmCode[2];                   /* teminal code                 */
    char cTmType;                       /* teminal type                 */
    char cOriginBrStatus;               /* origin branch status         */
    char caNextTxnDate[8];              /* next transaction state       */
    char cNextBusiDayCnt;               /* next business day count      */
    char caTotalTxnSeqNo[4];            /* total txn sequence number    */
    char caAccTxnSeqNo[3];              /* account txn sequence no      */
    char caNonAccTxnSeqNo[3];           /* non-account txn sequence no  */
    char caBtchTxnSeqNo[3];             /* batch txn sequence no        */
    char caTxnTime[6];                  /* txn time (hh:mm:ss)          */
    char caTxnCode[4];                  /* txn code                     */
    char caTxnDate[8];                  /* txn date (yy/mm/dd)          */
    char cSupKeyStatus;                 /* supervisor key status(0/1)   */
    char cBookStatus;                   /* pass book status(0/1)        */
    char cTxnStatus;                    /* transaction status           */
    char cReentryStatus;                /* re-entry status(0/1)         */
    char caTellId[2];                   /* teller code                  */
    char cTxnReturnCode;                /* txn return code(0 - 5)       */
/***    the following 2 items moved to here due to new UCP     ***/
    char cMsgqFunCode;                  /* func. code for msgq access   */
    char cMsgqReturnCode;               /* return code for msgq access  */
    char cBifReturnCode;                /* BIF process return code      */
    char caDbsFileId[2];                /* file id for dbs call param.  */
    char caDbsSegName[8];               /* segment name for dbs call    */
    char caDbsSegKey[30];               /* segment key for dbs call     */
    char cDbsFileCall;                  /* dbs file call                */
    char cDbsFunCode;                   /* dbs function call            */
    char cDbsReturnCode;                /* dbs return call(0:normal)    */
    char caDbsErrCode[2];               /* dbs error code               */
    char cInterApProc;                  /* indicater for inter-ap-proc  */
    char caMapApName[8];                /* main AP program ID           */
    char caSapApName[8];                /* sub AP program ID            */
    char cIscStatus;                    /* remote process indicator     */
    char cFiller1;
    char caApReturnCode[4];             /* ap return code               */
/***   the following item is moved here due to new UCP   ***/
    char caLogRrnSaved[5];              /* log rrn saved area   9(8) COMP-3 */
/***   the following items are added due to new UCP   ***/
    char cFiscSwitch;
    char cFiscApReturnCode;
    char cOverTime;
    char caFiller2[42];
    char cApAbendNoRlbk;
    char caApUseArea[20];
    char caRecordId[10];
    char cShmFunCode;                   /* twa ipc_shm function code    */
    char caShmSegName[8];               /* ipc_shm segment name         */
    char cShmReturnCode;                /* ipc_shm return code          */
    char cSyncPoint;                    /* sync point                   */
    char cRollReturnCode;               /* rollback return code         */
    char caSysTotalTxnCnt[4];           /* system total txn count       */
    char cDeviceIndicator;              /* device indicator             */
    char caRevSupKey[2];                /* reverse supervisor key       */
    char cApplStatus;                   /* application status           */
    char cTxnRtnCdSaved;                /* txn routine code saved       */
    char caNnTxnDate[8];                /* reserved                     */
    char cPrintFileStatus;              /* print file use lpr command   */
    char cTxnReinput;                   /* txn reinput status           */
};
#endif
