#ifndef H_TMCENV
#define H_TMCENV

/* <tmsenv.c> error message code */
#define INIT_CNF_TBL_ERR 		-1
#define GET_CWAKEY_ERR		        -2
#define GET_CTFKEY_ERR	                -3
#define GET_ICTKEY_ERR		        -4 
#define GET_DBTKEY_ERR		        -5
#define GET_IETKEY_ERR	                -6
#define GET_SYSOPMODE_ERR		-7
#define GET_TESTMODE_ERR		-8
#define GET_MAXPACKETSIZE_ERR		-9
#define GET_TMAX_ERR			-10 
#define GET_TMIN_ERR			-11 
#define GET_TOFFSET_ERR			-12 

/* <tmsenv.c> GetSysRs() error message code */
#define COB_INIT_ERR                    -1		
#define SIGNL_HDL_ERR                   -2		
#define GET_TWA_TWACTLFAC_ERR	        -3
#define GETPTRFROMTWA_TMA_ERR	        -4
#define GETPTRFROMTWA_COA_ERR	        -5
#define GETPTRFROMTWA_APA_ERR	        -6
#define GETPTRFROMTWA_TBA_ERR	        -7
#define INIT_SYNC_ERR                   -8    	

/* <tmsenv.c> GetKernl() error message code */
#define ACCESS_CWA_ERR		        -1
#define GET_TCT_ERR		        -2
#define ATTCH_CTF_ERR                   -3 	       
#define ATTCH_ICT_ERR 	                -4
#define ATTCH_IET_ERR 	                -5

/* <tmsifenv.c> AttIfEnv() error message code */
#define ATT_IF_ENV_ERR	                -1

/* <tmsenv.c> StSysVal() error message code */
#define SET_SYS_VAL_ERR	                -1
#define GET_SSA_PTR_ERR                 -2	


#endif
