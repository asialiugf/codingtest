
#ifndef H_TMS
#define H_TMS
/* --------------------------------------- */
/* define function code for AP to request  */
/* --------------------------------------- */
#include "ucp.h"
#define FUN_DBS             '0'
#define FUN_FCS             '1'
#define FUN_DCS             '2'
#define FUN_WRITE           '3'
#define FUN_PRINT           '4'
#define FUN_SDCLT           '5'
#define FUN_NACINT          '6'
#define FUN_NARINT          '7'
#define FUN_NBCINT          '8'
#define FUN_TXLOG           '9'
#define FUN_SHMFAC          'A'
#define FUN_APEXIT          'B'
#define FUN_ABNDEXIT        'C'
#define FUN_JCLIO           'D'
#define FUN_APRQT           'E'
#define FUN_REINPUT         'F'
#define FUN_FRPT            'G'
#define FUN_LOGOP           'H'
#define FUN_RVSOP           'I'
#define FUN_GPREV           'J'
#define FUN_GTSEQ           'K'
#define FUN_ONBTH           'M'
#define FUN_GTSIF           'N'
#define FUN_SETLN           'O'
#define FUN_ONBH1           'P'
#define FUN_ONBH2           'Q'
#define FUN_REOUT           'R'
#define FUN_LTINQ           'S'
#define FUN_COPTX           'T'

/* --------------------------------------- */
/* SIF Control Data MASK                   */
/* --------------------------------------- */
#define LIST_MASK      0x02
#define MULTIPLE_MASK  0x20
#define COOPERATIVE_MASK  0x02
#define SUPER_MASK     0x10
#define BOOK_MASK      0x08
#define REENTRY_MASK   0x01
#define REVERSE_MASK   0x04

/* --------------------------------------- */
/* SUPERVISORY status                      */
/* --------------------------------------- */
#define   TMS_SUP_OFF                '0'
#define   TMS_SUP_ON                 '1'

/* --------------------------------------- */
/* PBBOOK status                           */
/* --------------------------------------- */
#define   TMS_NO_PB                  '0'
#define   TMS_WITH_PB                '1'

/* --------------------------------------- */
/* define max absolute file name           */
/* --------------------------------------- */
#define MAX_ABS_PATH_LEN    80

/* --------------------------------------- */
/* define system mode                      */
/* --------------------------------------- */
#define ONLINE_MODE         '0'
#define BATCH_MODE          '1'
#define SPECIAL_MODE        '2'

/* --------------------------------------- */
/* define system role                      */
/* --------------------------------------- */
#define CENTER_HOST '0'
#define BRANCH_HOST '1'
#define REMOTE_TXN  'R'
#define LOCAL_TXN   'L'

/* --------------------------------------- */
/* define constatn of txn end or not       */
/* --------------------------------------- */
#define TXN_NOT_OVER        0
#define TXN_OVER            1
#define TXN_ERROR_COMMIT    2
#define TXN_ERROR_ROLLBK    3
#define TXN_NEW_START       1
#define TXN_NOT_NEW_START   0

/* --------------------------------------- */
/* define constant of DB action            */
/* --------------------------------------- */
#define TXN_BEGIN     1
#define TXN_ROLLBACK  2
#define TXN_END       3

/* --------------------------------------- */
/* define constant of cInDataType          */
/* --------------------------------------- */
#define LIST_TXN      'L'
#define MULTIPLE_TXN  'M'
#define GENERAL_TXN   'G'
#define COOPERATIVE_TXN   'C'

/* --------------------------------------- */
/* define constant of run method           */
/* --------------------------------------- */
#define FORK_TYPE    'F'
#define CALL_TYPE    'C'

/* --------------------------------------- */
/* define constant of cTxnReinput          */
/* --------------------------------------- */
#define  TMS_TXN_REINPUT_ON          '1'
#define  TMS_TXN_REINPUT_ON_API      '2'
#define  TMS_TXN_REINPUT_OFF         '0'

/* --------------------------------------- */
/* define constant of cApAbendNoRlbk       */
/* --------------------------------------- */
#define  TMS_TXN_ABEND_NORLBK_OFF     '0'
#define  TMS_TXN_ABEND_NORLBK_ON      '1'

/* --------------------------------------- */
/* define constant of cRendoRequest        */
/* --------------------------------------- */
#define TMS_TXN_NOT_RENDO     '0'
#define TMS_TXN_RENDO         '1'

/* --------------------------------------- */
/* define constant of cTpeWriteMsgKind     */
/* --------------------------------------- */
#define   TMS_RCV_AP_NORMAL_MSG        '0'
#define   TMS_RCV_AP_MXXX_MSG          '1'

/* --------------------------------------- */
/* define constant of cApWriteLogFlag      */
/* --------------------------------------- */
#define   TMS_AP_HAS_NOT_BEEN_WRT_LOG   '0'
#define   TMS_AP_HAS_BEEN_WRT_LOG       '1'

/* --------------------------------------- */
/* define constant of cRvsApRdLogFlag      */
/* --------------------------------------- */
#define   TMS_RVSAP_HAS_NOT_BEEN_RD_LOG   '0'
#define   TMS_RVSAP_HAS_BEEN_RD_LOG       '1'

/* --------------------------------------- */
/* define constant of cRevTxn              */
/* --------------------------------------- */
#define   TMS_TXN_NOT_REVERSE        '0'
#define   TMS_TXN_REVERSE            '1'

/* --------------------------------------- */
/* define constant of cRevContinue         */
/* --------------------------------------- */
#define   TMS_REV_CONTINUE_OFF        '0'
#define   TMS_REV_CONTINUE_ON         '1'

/* --------------------------------------- */
/* define constant of cTmType              */
/* --------------------------------------- */
#define   TMS_36_47_TM                1
#define   TMS_BATCH_TM                3

/* --------------------------------------- */
/* define constant of cReentryStatus       */
/* --------------------------------------- */
#define   TMS_TXN_NOT_REENTRY        '0'
#define   TMS_TXN_REENTRY            '1'

/* --------------------------------------- */
/* define constant of cReentryStatus       */
/* --------------------------------------- */
#define   TMS_TXN_ONLINE             '0'
#define   TMS_TXN_OFFLINE            '1'

/* --------------------------------------- */
/* define constant of cApReturnCode        */
/* --------------------------------------- */
#define TMS_AP_ACC_NORMAL     '0'
#define TMS_AP_REJECTED       '1'
#define TMS_AP_NON_ACC_NORMAL '2'
#define TMS_RR_REJECTED       '3'
#define TMS_CHANGE_TM         '4'
#define TMS_AP_ABEND          '5'
#define TMS_AP_REVERSED       '6'
#define TMS_UCP_ABEND         '9'

/* --------------------------------------- */
/* define constant of cFunCode of TPEAPRQT */
/* --------------------------------------- */
#define TMS_SEQ_RENDO         '1'
#define TMS_NEST_RENDO        '2'

/* ------------------------------------------ */
/* define constant of cReturnCode of TPEAPRQT */
/* ------------------------------------------ */
#define TMS_APRQT_NORMAL       '0'
#define TMS_APRQT_PARA_ERR     '1'
#define TMS_APRQT_CNV_ERR      '2'
#define TMS_APRQT_TXNCODE_ERR  '3'
#define TMS_APRQT_CALL_SEQ_ERR '4'
#define TMS_APRQT_TXNTYPE_ERR  '5'
#define TMS_APRQT_TWICE_ERR    '6'
#define TMS_APRQT_EXCLUDE_ERR  '7'
#define TMS_APRQT_SYS_ERR      '8'

/* ------------------------------------------ */
/* define constant of cReturnCode of TPESCRQT */
/* ------------------------------------------ */
#define TMS_REINPUT_NORMAL      '0'
#define TMS_REINPUT_PARA_ERR    '1'
#define TMS_REINPUT_CNV_ERR     '2'
#define TMS_REINPUT_TXNCODE_ERR '3'
#define TMS_REINPUT_TWICE_ERR   '4'
#define TMS_REINPUT_EXCLUDE_ERR '5'
#define TMS_REINPUT_ERR         '6'

/* ---------------------------------------- */
/* define constant of cReturnCode of TPFRPT */
/* ---------------------------------------- */
#define TMS_TPFRPT_NORMAL       '0'
#define TMS_TPFRPT_PARA_ERR     '1'
#define TMS_TPFRPT_LEN_ERR      '2'
#define TMS_TPFRPT_DEV_ERR      '3'

/* ------------------------------------------ */
/* define constant of cReturnCode of TPGIOHDL */
/* ------------------------------------------ */
#define TMS_JCLIO_NORMAL        '0'
#define TMS_JCLIO_CMDNO_ERR     '1'
#define TMS_JCLIO_CMDID_ERR     '2'
#define TMS_JCLIO_DATAFMT_ERR   '3'
#define TMS_JCLIO_LEN_ERR       '4'
#define TMS_JCLIO_POS_ERR       '5'
#define TMS_JCLIO_PARA_ERR      '6'
#define TMS_JCLIO_MODE_ERR      '7'

/* ----------------------------------------------------- */
/* define constant of cReturnCode of TPGWRTIE & TPESDOUT */
/* ----------------------------------------------------- */
#define   TMS_MSGP_NORMAL            '0'
#define   TMS_MSGP_PARA_ERR          '1'
#define   TMS_MSGP_LEN_ERR           '2'
#define   TMS_MSGP_DEV_ERR           '3'
#define   TMS_MSGP_SYS_ERR           '9'

/* ------------------------------------------------------ */
/* define constant of SHMFAC(Function & return & segment) */
/* ------------------------------------------------------ */
#define   TMS_SHM_RD_LOCK            '2'
#define   TMS_SHM_RD_ONLY            '3'
#define   TMS_SHM_WR_UNLOCK          '4'
#define   TMS_SHM_WR_ONLY            '5'
#define   TMS_SHM_NORMAL             '0'
#define   TMS_SHM_ERR                '1'
#define   CWA_SHM_LOG_SEG             "CWALOG  "
#define   CWA_SHM_ACIA_SEG            "INT     "

/* ------------------------------------------------------ */
/* define constant of TPETXLOG                            */
/* ------------------------------------------------------ */
#define   TMS_TXLOG_NORMAL            '0'
#define   TMS_TXLOG_ERROR             '1'

/* ------------------------------------------------------ */
/* define constant of TPFLOGOP & TPERVSOP                 */
/* other error code, define in pgm/log/inc/lgcopewa.h     */
/* ------------------------------------------------------ */
#define   TMS_LOGOP_NORMAL            '0'

/* ------------------------------------------------------ */
/* define constant of TPELOG                              */
/* ------------------------------------------------------ */
#define   TMS_GPREV_NORMAL            '0'
#define   TMS_NO_MORE_ERROR           '1'
#define   TMS_GPREV_ERROR             '9'

/* ------------------------------------------------------ */
/* define constant of TPFGTSEQ                            */
/* ------------------------------------------------------ */
#define   TMS_GTSEQ_NORMAL            '0'
#define   TMS_GTSEQ_LOCK_SSA_ERROR    '1'
#define   TMS_GTSEQ_ERROR             '2'
#define   TMS_GTSEQ_CALL_SEQ_ERROR    '3'
#define   TMS_GTSEQ_UNLOCK_SSA_ERROR  '4'
#define   TMS_GTSEQ_OTHER_ERROR       '9'

/* ------------------------------------------------------ */
/* define constant of TPEONBTH(Function & return)           */
/* ------------------------------------------------------ */
#define TMS_ONBTH_NORMAL        '0'
#define TMS_ONBTH_PARA_ERR      '1'
#define TMS_ONBTH_CNV_ERR       '2'
#define TMS_ONBTH_DCS_ERR       '3'
#define TMS_ONBTH_TIMEOUT_ERR   '4'
#define TMS_ONBTH_SERVER_ERR    '5'
#define TMS_ONBTH_SYS_ERR       '9'
#define RD_REENTRY_SEQ_NO       '1'
#define WT_REENTRY_SEQ_NO       '2'

/* ------------------------------------------------------ */
/* define constant of TPFSETLN(Function & return)           */
/* ------------------------------------------------------ */
#define   TMS_SETLN_NORMAL   '0'
#define   TMS_SETLN_FUN_ERR  '1'
#define   TMS_SETLN_BRH_ERR  '2'
#define   TMS_SETLN_SYS_ERR  '9'

/* ------------------------------------------------------ */
/* define constant of TPEGTSIF(Function & return)           */
/* ------------------------------------------------------ */
#define   TMS_GTSIF_NORMAL   '0'
#define   TMS_GTSIF_SYS_ERR  '1'

/* ------------------------------------------------------ */
/* define constant of TPEREOUT(Function & return)           */
/* ------------------------------------------------------ */
#define   TMS_REOUT_NORMAL   '0'
#define   TMS_REOUT_SYS_ERR  '1'

/* ------------------------------------------------------ */
/* define constant of TPFDBS(Function & return)           */
/* ------------------------------------------------------ */
#define   TMS_RANDOM_READ              '1'
#define   TMS_RANDOM_READ_UPDATE       '2'
#define   TMS_READ_NEXT_S              '3'
#define   TMS_READ_NEXT_UPDATE_S       '4'
#define   TMS_WRITE_UPDATE             '5'
#define   TMS_INSERT                   '6'
#define   TMS_APPEND                   '7'
#define   TMS_READ_F_SEG               '8'
#define   TMS_READ_UPDATE_F_SEG        '9'
#define   TMS_READ_L_SEG               'A'
#define   TMS_READ_UPDATE_L_SEG        'B'
#define   TMS_READ_NEXT                'C'
#define   TMS_READ_NEXT_UPDATE         'D'
#define   TMS_READ_UPDATE_NOIOA        'E'
#define   TMS_UPDATE_WITH_READ         'F'
#define   TMS_READ_F_GE_KEY            'G'
#define   TMS_READ_UPDATE_F_GE_KEY     'H'
#define   TMS_OPEN                     'O'
#define   TMS_BIMF_CLOSE               'S'
#define   TMS_BIMF_OPEN                'U'
#define   TMS_DELETE                   'X'
#define   TMS_CLOSE                    'Z'
#define   TMS_SEQ_READ_F_SEG           'a'
#define   TMS_SEQ_READ_NEXT            'b'
#define   TMS_SEQ_READ_L_SEG           'c'
#define   TMS_SEQ_READ_PREV            'd'
#define   TMS_UNLOCK                   'e'

#define   TMS_DBS_NORMAL               '0'
#define   TMS_DBS_NO_REC_FOUND         '1'
#define   TMS_DBS_DUPLICATE            '2'
#define   TMS_DBS_WRONG_CALL_SEQ       '3'
#define   TMS_NO_MORE                  '4'
#define   TMS_INVALID_FUN              '5'
#define   TMS_IO_ERR                   '6'
#define   TMS_DBS_SERVICE_ERR          '7'

/* ------------------------------------------------------ */
/* define constant of TPEONBH1(Function & return)         */
/* ------------------------------------------------------ */
#define TMS_ONBH1_NORMAL        '0'
#define TMS_ONBH1_PARA_ERR      '1'
#define TMS_ONBH1_CNV_ERR       '2'
#define TMS_ONBH1_DCS_ERR       '3'
#define TMS_ONBH1_TIMEOUT_ERR   '4'
#define TMS_ONBH1_SERVER_ERR    '5'
#define TMS_ONBH1_SYS_ERR       '9'
/*#define ONBH1_NORMAL          '0'
#define ONBH1_PARA_ERR        '1'
#define ONBH1_DATA_CNV_ERR    '2'
#define ONBH1_DCS_ERR         '3'
#define ONBH1_TIMEOUT_ERR     '4'
#define ONBH1_OTHER_ERR       '9'*/

/* for ONBH1_PARA_ERR        */
#define ONBH1_NO_SUCH_FORMAT_DERR          "00001"
#define ONBH1_SIF_LEN_OVERFLOW_DERR        "00002"

/* for ONBH1_OTHER_ERR       */
#define ONBH1_NO_SUCH_BRH_TERM_DERR        "01001"
#define ONBH1_NOT_REENTRY_TERM_DERR        "01002"
#define ONBH1_WRITE_REENTRY_SEQ_DERR       "02001"
#define ONBH1_SOF_STATUS_DERR              "03001"
#define ONBH1_OTHER_DERR                   "99999"

/* ------------------------------------------------------ */
/* define constant of TPECOPTX(Function & return)           */
/* ------------------------------------------------------ */
#define TMS_COPTX_NORMAL        '0'
#define TMS_COPTX_PARA_ERR      '1'
#define TMS_COPTX_CNV_ERR       '2'
#define TMS_COPTX_DCS_ERR       '3'
#define TMS_COPTX_TIMEOUT_ERR   '4'
#define TMS_COPTX_NOMORE_ERR    '5'
#define TMS_COPTX_SEQ_ERR       '6'
#define TMS_COPTX_CNVOUT_ERR    '7'
#define TMS_COPTX_SYS_ERR       '9'

/* ------------------------------------------------------ */
/* define constant of CtoToSif's Source Data Type         */
/* ------------------------------------------------------ */
#define  PART_CTF_TYPE    '0'
#define  CTF_TYPE         '1'

#define MAX_MSG_LEN           5000

struct WriteDataSt {
   char  cMsgType;
   char  caMsgCode[3];
   char  caDataLen[4];
   char  cOutDevType;
   char  caOutMsg[ 2000 ];
} ;

struct WriteSt {
  char cWriteRtnCode;
  struct WriteDataSt stWriteData;
};

struct SdoutDataSt {
   char  cMsgType;
   char  caMsgCode[3];
   char  caDataLen[4];
   char  cOutDevType;
   char  caOutMsg[ 5000 ];  /* define in tms.h, values = 5000 */
} ;

struct SdoutSt {
  char cSdoutRtnCode;
  struct SdoutDataSt stSdoutData;
};

struct DbsSt {
    char caDbsFileId[2];                /* file id for dbs call param.  */
    char caDbsSegName[8];               /* segment name for dbs call    */
    char caDbsSegKey[30];               /* segment key for dbs call     */
    char cDbsFileCall;                  /* dbs file call                */
    char cDbsFunCode;                   /* dbs function call            */
    char cDbsReturnCode;                /* dbs return call(0:normal)    */
    char caDbsErrCode[2];               /* dbs error code               */
};

struct FcsSt {
  char caFcsFileName[8];
  char caFcsKey[50];
  char caFcsKeyLen[2];
  char caFcsFunCode[4];
  char caFcsIndexNum[2];
  char caFcsOpenMode[8];
  char caFcsRtnCode[2];
  char caFcsErrCode[4];
};

struct NacSt {
   char caFiller[591] ;
} ;

struct ShmFacCtlSt {
   char cShmFunCode;
   char caShmSegName[8];
   char caDataLen[5];
   char cShmReturnCode;
} ;
struct ShmLogSt {
  char caNextAvLogRrn[8];
  char caTctLastLogRecRrn[8];
  char caTctSeqNo[2] ;
};

struct SdcltCtlSt {
   char cMsgOutReturnCode;
   char caSdcltLen[5];
};

struct LogSt {
  char cLogReturnCode;
  char caLogReturnRrn[8];
  char caLogData[450];
} ;

struct ApRqtCtlSt {
  char cFunCode;
  char cFmtCode;
  char cReturnCode;
  char caDataLen[4];
  char caTxnCode[4];
};

struct ReinputCtlSt {
  char cFunCode;
  char cFmtCode;
  char cReturnCode;
  char caDataLen[4];
  char caTxnCode[4];
};

struct OnBh1CtlSt {
  char cFlag;
  char cFmtCode;
  char caDataLen[4];
  char caBrhCode[10];
  char caReentryTmCode[4];
  char caTxnCode[6];
  char cOnBh1RtnCode;
  char caOnBh1SeqNo[7];
  char caOnBh1TxnRtnCode[7];
  char caErrCode[5];
  char caDesCode[10];
  char caTelCode[4];
  char caFiller[40];
};


#define MAX_CMD          5

struct	IoCmdSt {
  char	cCmdId;			/* command id             */
  char	cDataType;		/* input data type        */
  char	caDataLen[2];		/* data length            */
  char	caRow[2];		/* row of I/O position    */
  char	caCol[2];		/* column of I/O position */
};

struct	JclIoSt {
  char	cJclIoRtnCode;		 	/* return code      */
  char	cCmdNo;				/* toatl command no */
  struct IoCmdSt  staCmd[MAX_CMD];	/* command content  */
  char	caCmdData[MAX_CMD * 99]; 	/* I/O data         */
};


struct FrptCtlSt {
  char cCmdCode;
  char caFileName[80];
  char cFrptRtnCode;
};

struct FrptDataSt {
  char caMsgOutCode[4];
  char caDataLen[4];
  char cOutDevType;
  char caOutMsg[MAX_MSG_LEN];
};

struct FrptSt {
  struct FrptCtlSt  stFrptCtl;
  struct FrptDataSt stFrptData;
};

struct GetPreCtlSt {
  char   cGetPreLogRtnCode;
};

struct GetSeqSt {
  char   caEjRrn[7];
  char   cGetSeqRtnCode;
};

struct OnBthCtlSt {
  char cFlag;
  char cFmtCode;
  char caDataLen[4];
  char caBrhCode[10];
  char caReentryTmCode[4];
  char caTxnCode[6];
  char cOnBthRtnCode;
  char caOnBthSeqNo[7];
  char caOnBthTxnRtnCode[6];
};

struct SetLnCtlSt {
  char cFunCode;
  char caSetLnBrhCode[10];
  char cSetLnRtnCode;
};

struct GtSifCtlSt {
  char caSifLen[5];
  char cGtSifRtnCode;
  char caSifBuf[MAX_SIF_LEN];
};

struct stReOutCtl {
  char caRtnCode[1];    /* return code */
  char caMsgpOutCode[4];/* output message code */
};

struct CoptxCtlSt {
  char cFunCode;
  char cFmtCode;
  char caDataLen[4];
  char caBrhCode[10];
  char caTmCode[4];
  char caTxnCode[6];
  char cCoptxRtnCode;
  char caCoptxTxnRtnCode[6];
  char cMoreFlag;
};
/* --------------------------------------- */
/* define error handling                   */
/* --------------------------------------- */
#define         INFORM_DBP_FLAG           0x01 
#define         DO_ROLLBACK_FLAG          0x02 
#define         INFORM_EMS_FLAG           0x04 
#define         DO_ABEND_FLAG             0x08 
#define         KILL_AP_FLAG              0x10 
#define         ABORT_DCS_FLAG            0x20 

/* --------------------------------------- */
/* define LAST QUERY FLAG                  */
/* --------------------------------------- */
#define         LAST_QRY_ON           '1' 
#define         LAST_QRY_OFF          '0' 

#endif
