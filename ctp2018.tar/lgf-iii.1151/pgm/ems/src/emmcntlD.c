/*
 *&N& ROUTINE NAME: main  
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&           
 *&R& RETURN VALUES:
 *&R&           
 *&R&           
 *&D& DESCRIPTION:           
 *&D&     ���{�������Һ޲z�l�t�α���ʱ��D�{��, �t�d�ʱ��e������ܻP�R�O���ǰe
 *&D&     ( This program is RAW mode, i.e. using printf() as the output)        
 */

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/signal.h>
#include <fcntl.h>
#include <errno.h>

#include "errlog.h"
#include "dcs.h"
#include "cwa.h"

#define  DCS_ERR -1
#define  OPEN_FILE_ERR		        -1
#define  TOOLPROG_EXEC_ERR              -2
#define  FORK_TOOLPG_ERR                -3
#define  OPEN_MENUFILE_ERR		-4
#define  P_Memmcntl 88900
#define  P_D_String 88901
#define  PROTOCOL_TYPE		"III_PROTOCOL"
#define  QUEUE_DCS		'Q'
#define  MONITOR_HOST		"00Monitor1"
#define  DEST_NAME_LEN		10
#define  FILE_NAME_LEN		80
#define  MAX_EXEC_PATH_LEN      80
#define  MAX_LINE_LEN		100
#define  CHINESE_TYPE           '1'
#define  CWA_SHM_KEY    "CWA_SHM_KEY"
#define  CONFIG_FILE  "iii/etc/tbl/config.dat"
#define  CNTLSN_C      "iii/etc/cmg/emdcntl.scr"
#define  CNTLSN_E      "iii/etc/emg/emdcntl.scr"
#define  SERVSN_C      "iii/etc/cmg/emdserv.scr"
#define  SERVSN_E      "iii/etc/emg/emdserv.scr"
#define  TOOLSN_C      "iii/etc/cmg/emdtool.scr"
#define  TOOLSN_E      "iii/etc/emg/emdtool.scr"
#define  CWATOOL       "emxtcwa.x"
#define  BITTOOL       "emxtbit.x"
#define  GETTXNDATE              1  /* Get Txn Date      */
#define  GETOPMODE               2  /* Online or Batch   */
#define  GETSYSMODE              3  /* Normal or Restart */
#define  SYSTEM_RESTART 0x4000 /* 1:restarted ; 0:Normal Begin */
#define  ONLINE_CLOSE   0x0400 /* 1:Batch ; 0:On_line        */
#define  QUIT_MENU               'Z'

struct MonCmd stMonCmd;	/* monitor process rcv command struct globl */
struct FkdStat stFkdStat;	/* monitor process rtn status struct globl */
struct DcsBuf stDcsBuf;	/* call dcs module struct globl */
struct DcsSiof stDcsSiof;	/* call dcs module input/output struct globl */
struct MDA    *pstMda;
struct SSA    *pstSsa;
static char gs_caEnvStr[50];
int g_iShmid;
int g_iSessidx;
int g_iCwaKey;
char g_cTmMode;
/*    ----------------   Prototype Define --------------------------------*/
int ShowCfgScrn(char *caCmd,char cCmd);

main(argc,argv)
int  argc;
char **argv;
{
  int  iRtn;
  int  iIdx;
  char *getenv();
  char caIdx[5];
  char cPause;
  int  iRc;
  struct CwaCtl stCwaCtl;
  struct CwaCreatIobuf stCCBuf;
  char caFileName[ FILE_NAME_LEN + 1 ];
  short sStatus;

  SignlHdl();
  UCP_TRACE(P_Memmcntl);
  sprintf(g_caMsg,"emmcntl:start");
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  sprintf ((char *)caFileName, "%s/%s",
           (char *)getenv("III_DIR"), CONFIG_FILE);
  iRc = InitCnfTbl(caFileName);
  if ( iRc < 0 ){
    return( -1 );
  }

  g_iCwaKey = GetCnfValue( CWA_SHM_KEY );
  if (g_iCwaKey < 0){
    return( -2 );
  }

  stCwaCtl.cFunCode = CWA_GET_ID;
  stCCBuf.iShmKey = g_iCwaKey;
  stCCBuf.iSemKey = g_iCwaKey;
  
  iRc = CwaCtlFac(&stCwaCtl,&stCCBuf);
  if (iRc != CWA_NORMAL) {
    sprintf (g_caMsg, "<EMS> Failure to get CWA ID! (iRc:%d)", iRc);
    printf ("\n%s\n", g_caMsg);
    printf ("\nTPE is not started yet!\n");
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    exit(0);
  }

  stCwaCtl.cFunCode = CWA_ATTACH;
  stCCBuf.iShmKey = g_iCwaKey;
  stCCBuf.iSemKey = g_iCwaKey;
  
  iRc = CwaCtlFac(&stCwaCtl,&stCCBuf);
  if (iRc != CWA_NORMAL) {
    sprintf (g_caMsg, "<EMS> Failure to attach CWA! (iRc:%d)", iRc);
    printf ("\n%s\n", g_caMsg);
    ErrLog (40000, g_caMsg, RPT_TO_TTY|RPT_TO_LOG, 0, 0);
  }

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);

  if (iRc != 0) {
    sprintf (g_caMsg, "<EMS> Failure to get SSA pointer! (iRc:%d)", iRc);
    printf ("%s\n", g_caMsg);
    ErrLog (40000, g_caMsg, RPT_TO_TTY|RPT_TO_LOG, 0, 0);
    UCP_TRACE_END(iRc);
  }

  sStatus = pstSsa->sSysStatus;

  /* attach MDA share memory */
  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_MDA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstMda);

  if (iRc != 0) {
    sprintf (g_caMsg, "<EMS> Failure to get MDA pointer! (iRc:%d)", iRc);
    printf ("\n%s\n", g_caMsg);
    printf ("Check to see if EMS monitor is started!\n");
    ErrLog (40000, g_caMsg, RPT_TO_TTY|RPT_TO_LOG, 0, 0);
    UCP_TRACE_END(iRc);
  }

  if (argc == 1) {
      g_cTmMode = '1';
  }
  else if ( (argc == 2) && ( (argv[1][0]=='e') || (argv[1][0]=='E') ) ){
      g_cTmMode = '4';
  }
  else if ( argc > 2) {
    printf("WRONG USAGE: emxcntl.x [e\\E] \n");
    exit(-1);
  }
  else {
    printf("WRONG TERMINAL TYPE!!! Null for Chinese,(e/E) for English.\n");
    exit(-1);
  }

  /* a unlimit while to show command screen */
    sStatus = pstSsa->sSysStatus;
    stMonCmd.cCmd = '2';
    iRc = SendCmdToMon(&stMonCmd);
    if (iRc < 0) {
      Err_Hdl();
    }

    if (iRc != MON_SAVE_CWA_ERR)
       printf("TPE Emergency Shutdown Completed!!\n");

    Quit();
    UCP_TRACE_END(0);
}

/*--------------------------------------------------------------------------*/
/* end routing								    */
/*--------------------------------------------------------------------------*/
EndRtn(dcs_buf,iSessidx)
struct DcsBuf *dcs_buf;
int iSessidx;
{
  int i, iRc;
  int iRcvDataLen;
  int iStatus;
  struct FkdStat stFkdStat; /* monitor rtn the forked process's status  */
  char caPrcSta[20], caMonErr[25];

  /* a dummy receive */
  i=0;
  while((PcMoreByte(dcs_buf) == '1') && (i++ < 5)){
    PcRqstCode(dcs_buf) = DCSREAD;
    /* TCC
    PlWaiTime(dcs_buf) = 10;*/ /* emmcntl dummy receive time out is 10 sec */
    PlWaiTime(dcs_buf) = 60; /* emmcntl dummy receive time out is 10 sec */
    PiDataLen(dcs_buf) = 1024;
    PcProto(dcs_buf) = QUEUE_DCS;
    PiSesIdx(dcs_buf) = iSessidx;
    DcsDispatch(dcs_buf);
    if(PiReply(dcs_buf) != DCS_NORMAL){
       sprintf(g_caMsg,"emmcntl:i=%d EndRtn dummy DCSREAD error reply %d errno %d",i,PiReply(dcs_buf),PiErrno(dcs_buf));
       ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    }
    else {
      PcMoreByte(dcs_buf) == '0';
    }
  }  /* FOR while((PcMore..))  */

  iRcvDataLen= MiDataLen(stDcsBuf) - 8 ;
  if(iRcvDataLen > sizeof(struct FkdStat)){
    sprintf(g_caMsg,"EndRtn:rcv fkd data reply %d errno %d",
            MiReply(stDcsBuf),MiErrno(stDcsBuf));
    ErrLog(1000,g_caMsg,RPT_TO_LOG,McaData(stDcsBuf),iRcvDataLen);
    UCP_TRACE_END(MON_CMD_ERR);
  }
  ErrLog(100,"EndRtn:rcv Fkd data=",RPT_TO_LOG,McaData(stDcsBuf),iRcvDataLen);

  memcpy(stFkdStat.caTblidx,McaData(stDcsBuf),5);
  stFkdStat.cStatus = McaData(stDcsBuf)[5];

  iRc = 0;
  if (stFkdStat.cStatus == 0) {
    printf("\n EXECUTE COMMAND OK!!!\n");
    printf("\n Press Any Key To Continue!!!\n");
  }
  else  {
    iStatus = (int) stFkdStat.cStatus;
    CovStatStr('0',caPrcSta,iStatus,caMonErr);
    printf("\n EXECUTE COMMAND error!!! status = %s\n",caMonErr);
    if (iStatus == MON_SAVE_CWA_ERR)
    {
      printf ("\n Failure to save files sbcwa0.bin/sbcwa1.bin!\n");
      printf (" (1) Please check permission of files sbcwa0.bin/sbcwa1.bin!\n");
      printf (" (2) Please check if file system is full!\n");
      iRc = MON_SAVE_CWA_ERR;
    }

    printf("\n Press Any Key To Continue!!!\n");
    getchar ();
  }

  /* receive server response */
  PcRqstCode(dcs_buf) = DCSDISCONNECT;
  PcProto(dcs_buf) = QUEUE_DCS;
  PiSesIdx(dcs_buf) = g_iSessidx;
  PiDataLen(dcs_buf) = 0;
  DcsDispatch(dcs_buf);
  if(PiReply(dcs_buf) != DCS_NORMAL){
    sprintf(g_caMsg,"emmcntl:EndRtn DCSDISCONNECT error reply %d errno %d",
                                    PiReply(dcs_buf),PiErrno(dcs_buf));
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
  }

  return (iRc);
}


int
SendCmdToMon(struct MonCmd *stCmd)
{
  int  iLen, iRc;
  char caTmpBuf[20];

  /* initial dcs_buf & DcsSiof */
  memset(&stDcsSiof,0x00,sizeof(struct DcsSiof));
  memset(&stDcsBuf,0x00,sizeof(struct DcsBuf));
  memcpy(McaDesCode(stDcsBuf), MONITOR_HOST, DEST_NAME_LEN);
  memcpy(McaServCode(stDcsBuf),MON_TXN_CODE,4);
  MpstDcsSiof(stDcsBuf) = &stDcsSiof;
  iLen=sizeof(struct MonCmd);

  memcpy(McaData(stDcsBuf),stCmd,iLen);
  McRqstCode(stDcsBuf) = DCSCONNECTWRITE;
  /* TCC
  MlWaiTime(stDcsBuf) = 10;*/ /* rctst dummy receive time out is 10 sec */
  MlWaiTime(stDcsBuf) = 60; /* rctst dummy receive time out is 10 sec */
  McProto(stDcsBuf) = QUEUE_DCS;
  MiDataLen(stDcsBuf) = iLen+8;
  McKind(stDcsBuf) = 'A';
  itoa1(iLen,caTmpBuf,5);
  caTmpBuf[5] = '\0';
  memcpy(McaDataLen(stDcsBuf),caTmpBuf,5);
  DcsDispatch(&stDcsBuf);

  g_iSessidx = MiSesIdx(stDcsBuf);

  if(MiReply(stDcsBuf) != DCS_NORMAL){
     sprintf (g_caMsg,
              "<EMS> Failure to send cmd to EMS monitor! (iRc:%d errno:%d)",
              MiReply(stDcsBuf),MiErrno(stDcsBuf));
     ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
     return(-1);
  }

  McMoreByte(stDcsBuf) = '1';

  iRc = EndRtn(&stDcsBuf,g_iSessidx);

  return (iRc);
}

int Quit()
{
  /* terminate communication */
  McRqstCode(stDcsBuf) = DCSTERMINATE;
  McProto(stDcsBuf) = QUEUE_DCS;
  DcsDispatch(&stDcsBuf);
  if(MiReply(stDcsBuf) != DCS_NORMAL)
  {
     sprintf(g_caMsg,"P_env_setup:DCSTERMINATE error,rtn_code=%d,errno=%d",
             MiReply(stDcsBuf),MiErrno(stDcsBuf));
     ErrLog(1000, g_caMsg, RPT_TO_LOG,0,0);
  }
  ErrLog(100,"Rqt_Restar:DCSTERMINATE",RPT_TO_LOG,0,0);
  return(0); 
}

CovStatStr(cPrcSta, caPrcStat, iMonErr, caMonErr)
char cPrcSta;
char *caPrcStat;
int iMonErr;
char *caMonErr;
{
  sprintf(g_caMsg,"covStatSrt:cPrcSta=%c iMonErr=%d",cPrcSta,iMonErr);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
  /* forked process status */
  switch(cPrcSta){
    case PRC_NORMAL :
           strcpy(caPrcStat,"PRC_NORMAL        ");
           break;
    case PRC_FORK_OK :
           strcpy(caPrcStat,"PRC_FORK_OK       ");
           break;
    case PRC_FORK_ERR :
           strcpy(caPrcStat,"PRC_FORK_ERR      ");
           break;
    case PRC_EXEC_OK :
           strcpy(caPrcStat,"PRC_EXEC_OK       ");
           break;
    case PRC_EXEC_ERR :
           strcpy(caPrcStat,"PRC_EXEC_ERR      ");
           break;
    case PRC_KILL_OK :
           strcpy(caPrcStat,"PRC_KILL_OK       ");
           break;
    case PRC_KILL_ERR :
           strcpy(caPrcStat,"PRC_KILL_ERR      ");
           break;
    case PRC_SHUTDOWN_OK :
           strcpy(caPrcStat,"PRC_SHUTDOWN_OK   ");
           break;
    case PRC_SHUTDOWN_ERR :
           strcpy(caPrcStat,"PRC_SHUTDOWN_ERR  ");
           break;
    case PRC_RESTART_OK :
           strcpy(caPrcStat,"PRC_RESTART_OK    ");
           break;
    case PRC_RESTART_ERR :
           strcpy(caPrcStat,"PRC_RESTART_ERR   ");
           break;
    case PRC_DEAD :
           strcpy(caPrcStat,"PRC_DEAD          ");
           break;
    case PRC_UNFORK :
           strcpy(caPrcStat,"PRC_UNFORK        ");
           break;
    default:
           strcpy(caPrcStat,"ERROR MSG UNDEFINE");
           break;
  }

  /* monitor error code */
  switch(iMonErr){
    case MON_NORMAL :
           strcpy(caMonErr,"MON_NORMAL            ");
           break;
    case MON_READ_FILE_ERR :
           strcpy(caMonErr,"MON_READ_FILE_ERR     ");
           break;
    case MON_LOAD_OVERFLOW :
           strcpy(caMonErr,"MON_LOAD_OVERFLOW     ");
           break;
    case MON_FORK_ERR :
           strcpy(caMonErr,"MON_FORK_ERR          ");
           break;
    case MON_EXEC_ERR :
           strcpy(caMonErr,"MON_EXEC_ERR          ");
           break;
    case MON_RCV_STAT_ERR :
           strcpy(caMonErr,"MON_RCV_STAT_ERR      ");
           break;
    case MON_OPEN_Q_ERR :
           strcpy(caMonErr,"MON_OPEN_Q_ERR        ");
           break;
    case MON_READ_Q_ERR :
           strcpy(caMonErr,"MON_READ_Q_ERR        ");
           break;
    case MON_READ_Q_TIMEOUT_ERR :
           strcpy(caMonErr,"MON_READ_Q_TIMEOUT_ERR");
           break;
    case MON_WRITE_Q_ERR :
           strcpy(caMonErr,"MON_WRITE_Q_ERR       ");
           break;
    case MON_COMM_ERR :
           strcpy(caMonErr,"MON_COMM_ERR          ");
           break;
    case MON_KILL_ERR :
           strcpy(caMonErr,"MON_KILL_ERR          ");
           break;
    case MON_SHUTDOWN_ERR :
           strcpy(caMonErr,"MON_SHUTDOWN_ERR      ");
           break;
    case MON_DCS_ERR :
           strcpy(caMonErr,"MON_DCS_ERR           ");
           break;
    case MON_GETOKEN_ERR :
           strcpy(caMonErr,"MON_GETOKEN_ERR       ");
           break;
    case MON_CMD_ERR :
           strcpy(caMonErr,"MON_CMD_ERR           ");
           break;
    case MON_PROC_OVERFLOW :
           strcpy(caMonErr,"MON_PROC_OVERFLOW     ");
           break;
    case MON_PARA_OVERFLOW :
           strcpy(caMonErr,"MON_PARA_OVERFLOW     ");
           break;
    case MON_CNFG_ERR :
           strcpy(caMonErr,"MON_CNFG_ERR          ");
           break;
    case MON_PROC_OVERLIMIT :
           strcpy(caMonErr,"MON_PROC_OVERLIMIT    ");
           break;
    case MON_UNWK_OVERFLOW :
           strcpy(caMonErr,"MON_UNWK_OVERFLOW     ");
           break;
    case MON_RESTART_LIMIT_ERR :
           strcpy(caMonErr,"MON_RESTART_LIMIT_ERR ");
           break;
    case MON_HAS_NO_PROCESS_TO_SHUTDOWN :
           strcpy(caMonErr,"MON_HAS_NO_PROCESS_TO_SHUTDOWN ");
           break;
    case MON_HAS_NO_PROCESS_TO_KILL :
           strcpy(caMonErr,"MON_HAS_NO_PROCESS_TO_KILL ");
           break;
    case MON_SAVE_CWA_ERR:
           strcpy(caMonErr,"MON_SAVE_CWA_ERR ");
           break;
    default:
           strcpy(caMonErr,"ERROR MSG UNDEFINE    ");
           break;
  }
  sprintf(g_caMsg,"CovStatSrt:caPrcStat=%s caMonErr=%s",caPrcStat,caMonErr);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
}

Err_Hdl()
{
   system("clear");
   printf("Fatal error has cccured,Control Process can't connect with EMS\n");
   printf("Please execute <killallp> after these messages under Shell\n");
   printf("And restart EMS again or contact with the Platform Operator!!\n");
   exit(-1);
}

/****************AUXILIARY FUNCTIONS ******************************/

itoa(n,s)
char *s;
int n;
{
     int i;
     i=0;
     do  {
         *(s+i) = n % 10 + '0';
         i++;
     }   while ((n /= 10) >0);
     *(s+i) = '\0';
     reverse(s);
}

itoa1(n,s,len)
int n,len;
char *s;
{
 int i,j;

 itoa(n,s);
 i=strlen(s);
 if (i == len) {
   return(0);
 }
 else {
   for ( j=i; j >= 0; j-- )
     s[len-i+j]=s[j];
   while ( (len-i+j) >= 0 ) {
     s[len-i+j]='0';
     j--;
   }
 }
}

reverse(s)
char *s;
{
     int   i, j;
     char  c;

     for (i = 0, j = strlen(s) - 1 ; i < j ; i++, j--) {
          c = *(s+i);
          *(s+i) = *(s+j);
          *(s+j) = c;
     }
}
/****************AUXILIARY FUNCTIONS ******************************/
