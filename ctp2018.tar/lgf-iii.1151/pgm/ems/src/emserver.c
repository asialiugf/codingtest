/*
 *&N& File : emserver.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    void    ChkChronTbl() �w���ˬd�ҩI�s���禡,�ˬd�O�_�ŦX�w�ɱҰʪ�����  
 *&N&                                     
 *&N&    int     InitRestTime()  �N�Ѿl�ɶ��Ȥ��H��l�� 
 */
#include <stdio.h>
#include <signal.h>
#include <errno.h>
#include <time.h>
#include <sys/types.h>
#include "cwa.h"
#include "errlog.h"
#include "emcpgdef.h"
#include "emcenvhl.h"
#include "tmc.h"

#define  ATTYPE                  0
#define  PERIODTYPE              1
#define  NORMAL_SERVER           0
#define  CHRON_SERVER            1
#define  EMS_SHUTDOWN_OK         1
#define  EMS_DOBATCH_OK          2
#define  ONLINE_CLOSE            0x0400  /* 1:Batch   0:ONLINE */
/* 1000*10 seconds for saving CWA file at batch mode */
#define  CONFIG_FILE             "config.dat"
#define  TOTAL_TXN_OFFSET        100
#define  INIT_CNFTBL_ERR         -1
#define  GET_SSA_ERR             -2

#define  ONLINE_SAVECWA_TIME     3    /* 3*10 seconds */
#define  BATCH_SAVECWA_TIME      100  /* 100*10 seconds */

#define  TXN_ENABLE              0x0200

void        ChkChronTbl();

extern struct MDA *pstMda;
extern int  g_iMaxLoadCrn;  /* realy max table load in memory array (chron) */
extern int  g_iChronPid;    /* the chron process id */
extern int  errno;
extern char *sys_errlist[];

extern int  g_iBatch_SaveCwa_Time;
extern int  g_iTestMode;
extern int  g_iConsole;
extern int  gs_iMaxFork;

int   g_iDeadTpuCnt [MAX_FORK_PROC];
int   g_iConfigSaveCwaTime=BATCH_SAVECWA_TIME;  /* Default: 100*10 seconds */
int   g_iSaveCwaTime=0;
int   g_iBatchFlag=0;
long  g_lLastTotalTxnCnt=0;
long  g_lCurTotalTxnOff=0;

/* Added by Hu Chunlin 19980512 for ptm TPEUNIX980504 - begin */
static char	cPrevCmd=' ';
static char	cCurrentCmd=' ';
/* Added by Hu Chunlin 19980512 for ptm TPEUNIX980504 - end   */

/*
 *&N& ROUTINE NAME: MaServer()
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&           
 *&R& RETURN VALUES:
 *&R& 
 *&R&           
 *&R&           
 *&D& DESCRIPTION:           
 *&D&     ����Ƭ��n�D���޲z�\��B�z,�p�i������,�t�Ϊ��A���ܤΩw�ɱҰʤ��B�z
 *&D&   1.���ݺ޲z�\����O
 *&D&   2.�ˬd���_����O�_�P CronTable �ŦX
 *&D&   3.�޲z�\����O�����P����
 *&D&   4.�t�������B�z
 *&D&   5.�t�ζi�J Daemon ���A        
 *&D&           
 */

MaServer(char *pcErrStep)
{
  static int siFirst=0;
  int    iRc, iConsole;
  short  sStatus;
  struct MonCmd  stMonCmd;
  struct CwaCtl stCwaCtl;
  struct CwaCreatIobuf stCCBuf;
  struct SSA *pstSsa;
  char   caFileName [80];

  UCP_TRACE(P_MaServer);

  *pcErrStep = '0';

  memset (g_iDeadTpuCnt, 0, sizeof(g_iDeadTpuCnt));
      
  g_iConfigSaveCwaTime = g_iBatch_SaveCwa_Time;
  if (g_iConfigSaveCwaTime < 0){
     g_iConfigSaveCwaTime = 100;
     sprintf (g_caMsg, 
              "<EMS> Set SaveCwaTime on BATCH mode as %d seconds",
              g_iConfigSaveCwaTime*10);
     ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
     /* 
    UCP_TRACE_END( BATCH_SAVECWA_TIME_ERR );
     */
  }

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);
  if (iRc != 0) {
    sprintf (g_caMsg, 
             "<EMS> Failure to get SSA in chron operation. (errno:%d=>%s)",
             errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0); 
    UCP_TRACE_END( GET_SSA_ERR );
  }

  /* TCC: 19960905 */
  pstSsa->sSysStatus |= TXN_ENABLE;
  sStatus = pstSsa->sSysStatus;
  sprintf (g_caMsg, "<EMS> TPE System Status :[0x%0x]", sStatus&0x0FFFF);
  ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);

  if ( (sStatus & ONLINE_CLOSE) ) /* Batch Processing */
  {
    g_iBatchFlag = 1;
    if (siFirst == 0)
    {
      g_iSaveCwaTime = g_iConfigSaveCwaTime;
      siFirst = 1;
    }
    else
    if (g_iSaveCwaTime == 0)
    {
       g_iSaveCwaTime = g_iConfigSaveCwaTime;
    }
  }
  else
  {
    g_iBatchFlag = 0;
    g_iSaveCwaTime = ONLINE_SAVECWA_TIME;
  }

  g_iConsole = open (CONSOLE, O_WRONLY);
  if (g_iConsole >= 0)
  {
     printf ("\nCritical system error message will be displayed in console!\n");
     close (g_iConsole);
  }
  else
  {
     printf ("\n<Warning> Critical system error message will not be displayed in console!\n");
     printf ("You may add write permission of /dev/console! (eg. chmod 666 /dev/console)\n");
     close (g_iConsole);
  }

  /* flush all output data in screen to avoid call Daemon_Start() redisplay
     output data twice */
  fflush(stdout);

  /* excepting debugging mode, system become a daemon process */
  if ( pstSsa->cSysOperatingMode != 'D' ) { 
    Daemon_Start(1);       /* begin to become a daemon */
  }

  if ( (g_iChronPid = fork()) == 0 ) {  
    /* child for count time and check Cron Table */
    while(1) {
      /*
      if ( getppid() == 1)  /x If Parent has died then over x/ 
        exit(0); 
      */

      stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
      stCwaCtl.cSegCode = CWA_SEG_SSA;
      iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);
      if (iRc != 0) {
        sprintf (g_caMsg, "<EMS> Failure to get SSA pointer!");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        UCP_TRACE_END(GET_SSA_PTR_ERR);
      }

      if (pstSsa->cSysOperatingMode == '1') /* Production Mode */
      {
         if (g_iTestMode == 1)
         {
           ChgLog (LOG_CHG_MODE,"0");
           g_iTestMode = 0;
           ErrLog (1000, "<EMS> Switch to PRODUCT mode", RPT_TO_LOG, 0, 0);
         }
      }
      else
      if (pstSsa->cSysOperatingMode == '2') /* Test Mode */
      {
         if (g_iTestMode == 0)
         {
           ChgLog (LOG_CHG_MODE,"1");
           g_iTestMode = 1;
           ErrLog (1000, "<EMS> Switch to TEST mode", RPT_TO_LOG, 0, 0);
         }
      }

      alarm(0);
      if ( signal(SIGALRM,SIG_IGN) != SIG_IGN)
           signal(SIGALRM,ChkChronTbl);
      alarm(10);
      pause();
    }
  }
  else {                /* parent for wait command and do jobs       */ 
    /* Delete 1 line for TPEUNIX980504 by Hu Chunlin
    while(1){ */
      /* save CWA to sbcwa0.bin or sbcwa1.dat */
      iRc = SaveCwaToFile();
      if (iRc != 0){
        sprintf(g_caMsg,"<EMS> Failure to save CWA to file! (errno:%d=>%s", 
                errno, sys_errlist[errno]);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      }

    /* Add 1 line for TPEUNIX980504 by Hu Chunlin */
    while(1) {
      stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
      stCwaCtl.cSegCode = CWA_SEG_SSA;
      iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);
      if (iRc != 0) {
        sprintf (g_caMsg, "<EMS> Failure to get SSA pointer!");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        UCP_TRACE_END(GET_SSA_PTR_ERR);
      }

      if (pstSsa->cSysOperatingMode == '1') /* Production Mode */
      {
         if (g_iTestMode == 1)
         {
           ChgLog (LOG_CHG_MODE,"0");
           g_iTestMode = 0;
           ErrLog (1000, "<EMS> Switch to PRODUCT mode", RPT_TO_LOG, 0, 0);
         }
      }
      else
      if (pstSsa->cSysOperatingMode == '2') /* Test Mode */
      {
         if (g_iTestMode == 0)
         {
           ChgLog (LOG_CHG_MODE,"1");
           g_iTestMode = 1;
           ErrLog (1000, "<EMS> Switch to TEST mode", RPT_TO_LOG, 0, 0);
         }
      }

      iRc = WaitCmd(&stMonCmd);
  
      if (iRc != 0) {
        *pcErrStep = '1';
        UCP_TRACE_END(iRc);  
      }

      /* Add 1 line for TPEUNIX980504 by Hu Chunlin */
      cCurrentCmd = stMonCmd.cCmd;

      iRc = Dispatch(&stMonCmd);
      if (iRc == MON_SAVE_CWA_ERR)
         continue;

      if (iRc < 0) {
        *pcErrStep = '2';
        UCP_TRACE_END(iRc);  
      }
 
      switch(iRc) {
        case EMS_SHUTDOWN_OK:
                         UCP_TRACE_END(0);  
        case EMS_DOBATCH_OK:
		         break;
        default:
                         break;
      } /* for switch(iRc)  */

      /* Added for TPEUNIX980504 by Hu Chunlin - begin */
      if((cPrevCmd != cCurrentCmd) || (cPrevCmd != TPE_DUMPBIT)){
        /* save CWA to sbcwa0.bin or sbcwa1.dat */
        iRc = SaveCwaToFile();
        if (iRc != 0){
          sprintf(g_caMsg,"<EMS> Failure to save CWA to file! (errno:%d=>%s", 
                  errno, sys_errlist[errno]);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        }
      }
      cPrevCmd = cCurrentCmd;
      /* Added for TPEUNIX980504 by Hu Chunlin - end   */
    } /* FOR while(1) */
  }  /* FOR if (fork()...)  */
}
 
void
ChkChronTbl()
{
  int  i,j,k, iCfgIdx;
  int  iRc;
  int  iChiPid;
  struct SSA *pstSsa;
  struct CwaCtl stCwaCtl;
  struct CwaCreatIobuf stCCBuf;
  static int    siFirst=0;
  char *pcaArgv[MAX_PARAS];     /* point char array to pass to execv */
  char caForkBuf[MAX_PARA_LEN]; /* buf for keep parameters str */
  char caExePath[MAX_EXEC_PATH_LEN];    /* buf for keep exec path str */
  char caIdx[10];       /* buf fork conv table array index from int to char */
  short sStatus;

  UCP_TRACE (P_ChkChronTbl);

  /* TCC: 19960905 */
  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);
  if (iRc != 0) {
    sprintf (g_caMsg, 
             "<EMS> Failure to get SSA in chron operation.(errno:%d=>%s)", 
             errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0); 
    UCP_TRACE_OVER;
    return;
  }

  g_lCurTotalTxnOff = pstSsa->lTotalTxnCnt - g_lLastTotalTxnCnt;
  sStatus = pstSsa->sSysStatus;
  if ( (sStatus & ONLINE_CLOSE) ) /* Batch Processing */
  {
    g_iBatchFlag = 1;
    if (siFirst == 0)
    {
      g_iSaveCwaTime = g_iConfigSaveCwaTime;
      siFirst = 1;
    }
    else
    if (g_iSaveCwaTime == 0)
    {
       g_iSaveCwaTime = g_iConfigSaveCwaTime;
    }
  }
  else
  {
    g_iBatchFlag = 0;
    if (g_iSaveCwaTime > ONLINE_SAVECWA_TIME)
       g_iSaveCwaTime = ONLINE_SAVECWA_TIME;
  }
  
  if (g_iSaveCwaTime > 0)
     g_iSaveCwaTime--;

  if (g_iSaveCwaTime == 0 || g_lCurTotalTxnOff >= TOTAL_TXN_OFFSET)
  {
    if (g_iBatchFlag == 1)
       g_iSaveCwaTime = g_iConfigSaveCwaTime;
    else
       g_iSaveCwaTime = ONLINE_SAVECWA_TIME;
    /* Online mode: Save Cwa To File every 3*10 seconds */

    g_lLastTotalTxnCnt = pstSsa->lTotalTxnCnt;

    iRc = SaveCwaToFile();
    if (iRc != 0){
      sprintf(g_caMsg,"<EMS> Failure to save CWA to file! (errno:%d=>%s)", 
              errno, sys_errlist[errno]);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      /* ???
      UCP_TRACE_OVER;
      return;
      */
    }

    if (g_iBatchFlag == 0)
    {
      for (i=0; i<=gs_iMaxFork; i++)
      {
        if (MFok(i).iProcid > 0)
        {
          if (kill(MFok(i).iProcid, 0) == 0)
          {
            g_iDeadTpuCnt [i] = 0;
            /*
            sprintf (g_caMsg,
            "<EMS> TPU server %03d with process ID [%d] is still running!",
            i, MFok(i).iProcid);
            ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
            */
          }
          else
          {
            g_iDeadTpuCnt [i] ++;
            sprintf (g_caMsg,
            "<EMS> TPU server %03d with PID [%d] is disappeared! [%d]",
            i, MFok(i).iProcid, g_iDeadTpuCnt[i]);
            ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          }
        }
      }

      for (i=0; i<=gs_iMaxFork; i++)
      {
        if (g_iDeadTpuCnt [i] > 2)
        {
          RemoveShm (MFok(i).iProcid);
          RemoveSem (MFok(i).iProcid);
          MFok(i).iProcid = -2;
          iCfgIdx = MFok(i).iTblidx;
          UnWork_incr (iCfgIdx, i);
          MFok(i).cStatus = ' ';
          MFok(i).iMonerr = 0;
          MFok(i).iErrno = 0;
          sprintf (g_caMsg, "<EMS> Restarting dead TPU server %03d!", i);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);

          iRc = ForkOne (iCfgIdx);
          if (iRc == 0)
          {
            g_iDeadTpuCnt [i] = 0;
          }
        }
      }
    }
  }

  if (siFirst == 0) {
    iRc =  InitRestTime();

    if (iRc != 0) {
      sprintf(g_caMsg,"<EMS> Failure to reset chron timer! (errno:%d=>%s)",
              errno, sys_errlist[errno]);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_OVER;
      return;
    }

    siFirst = 1;
  }
  else  {
    for (i=0;i<g_iMaxLoadCrn;i++) {
      MCrn(i).iRestTime--  ;
    }
  }
    
  /* fork process loop */
  for (i=0; i<g_iMaxLoadCrn; i++)
  {
    if (MCrn(i).iRestTime == 0) {
      if ( (MCrn(i).iChronType) == PERIODTYPE )  {
        MCrn(i).iRestTime = MCrn(i).iPeriod;
      }
      j=0;
      while(j < MCrn(i).iFstFokNo){
        /* prepare execv path string */
        sprintf (caExePath, "%s/iii/bin/exe/%s",
                 (char *) getenv("III_DIR"), MCrn(i).caPrgname);

        /* prepare execv argv */
        pcaArgv[0]=MCrn(i).caPrgname;
        itoa1(i,caIdx,3);
        pcaArgv[1]=caIdx;
        memcpy(caForkBuf,MCrn(i).caPara,MAX_PARA_LEN);

        if(GetToken(caForkBuf,pcaArgv) != 0){
          sprintf (g_caMsg,
                   "<EMS> Failure to get token from [%s]! (errno:%d=>%s)", 
                   caForkBuf, errno, sys_errlist[errno]);
          printf ("\n%s\n", g_caMsg);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          /*
          exit(MON_GETOKEN_ERR);
          */
          UCP_TRACE_OVER;
          return;
        }

        /* TCC: 1996/08/26
        k=0;
        while(pcaArgv[k] != NULL){
          sprintf(g_caMsg,"pcaArgv[%d]=%s",k,pcaArgv[k++]);
          ErrLog(40,g_caMsg,RPT_TO_LOG,0,0);
          UCP_TRACE_OVER;
          return;
        }
        */

        signal(SIGCLD, SIG_IGN);
        if((iChiPid=fork()) == 0 ) {
          if(execvp(caExePath,pcaArgv) != 0) {
            sprintf(g_caMsg,
                    "<EMS> Failure to fork & execute [%s] (errno:%d=>%s)",
                    caExePath, errno, sys_errlist[errno]);
            ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
/*
            UCP_TRACE_OVER ;
            return;
*/
            exit(MON_EXEC_ERR);
          }
          sprintf (g_caMsg,
                   "<EMS> Fork & execute chron task [%s] (PID:%d PPID:%d)",
                   caExePath, iChiPid, getpid());
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        }
        else{
          if(iChiPid == -1) {
            sprintf(g_caMsg,"<EMS> Failure to fork chron [%s] (errno:%d=>%s)",
                    caExePath, errno, sys_errlist[errno]);
            ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
            printf ("\n%s\n", g_caMsg);
            UCP_TRACE_OVER ;
            return;
/*
            exit(MON_FORK_ERR);
*/
          }
        }/* else */

        MCrn(i).iForkprc++;
        j++; 
      }/* FOR whiel(j) loop */
    } /* FOR if(MCrn(i).iRestTime ==0)  */

  }/* for (;;) */

  if ( signal(SIGALRM,SIG_IGN) != SIG_IGN)
       signal(SIGALRM,ChkChronTbl);
  alarm(10);

  UCP_TRACE_OVER ;
  return;
}

int
InitRestTime()
{
  char   *pcaCurTime;
  long   lClock;
  char   caHhmm[4];
  char   caHh1[2],caHh2[2],caMin1[2],caMin2[2];
  int    iRestTime,iRestHr,iRestMin;
  int    i;

  UCP_TRACE(P_InitRestTime);

  i=0;
  while(i < g_iMaxLoadCrn){
    
    switch(MCrn(i).iChronType)  {
      case ATTYPE:
	  lClock     = time((long *) 0);
          pcaCurTime = ctime(&lClock);
          strncpy(caHh1,&pcaCurTime[11],2);
          strncpy(caMin1,&pcaCurTime[14],2);
          strncpy(caHh2,&(MCrn(i).caTime[0]),2);
          strncpy(caMin2,&(MCrn(i).caTime[2]),2);
          iRestHr  = atoi(caHh2) - atoi(caHh1) ;
          iRestMin = atoi(caMin2) - atoi(caMin1) ;

          if  (iRestHr < 0) {
            MCrn(i).iRestTime = -1 ;
          }
	  else if ( (iRestHr > 0) && (iRestMin < 0) ) {
	    MCrn(i).iRestTime = ((iRestHr-1)*3600)+((iRestMin+60)*60) / 10;
          }
	  else {
	    MCrn(i).iRestTime = (iRestHr*3600)+(iRestMin*60) / 10;
	  }

          MCrn(i).iRestTime--  ;
        break;
      case PERIODTYPE:
        MCrn(i).iRestTime = MCrn(i).iPeriod;
        MCrn(i).iRestTime--  ;
        break;
      default:
        sprintf(g_caMsg,"<EMS> Invalid chron type %d", MCrn(i).iChronType);
        ErrLog(4000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END(-1);   
    }    /*  for switch()   */
  
  i++;
  }    /*  for while()    */
  UCP_TRACE_END(0);
}

