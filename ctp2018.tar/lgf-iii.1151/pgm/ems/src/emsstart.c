/*
 *&N& File : emsstart.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    void      GetCkDat()    ��~�餧���o�P�ˬd(CURSES & printf ��)
 *&N&                                     
 *&N&    void      Get_Wdata()   �����~�餧��J���(CURSES & printf ��)
 *&N&                                     
 *&N&    void      DisplayHead() �����~�餧��J��Ƥ����Y�e��(for CURSES��)
 *&N&                                     
 *&N&    int       Date_Valid()  
 *&N&              �ˬd��~�餧��J��ƬO�_�ŦX������W�h(CURSES & printf��)
 *&N&                                     
 *&N&    int       Txn_Date_Check()  
 *&N&              �ˬd��~�餧��J��Ƥ����T��(CURSES & printf��)         
 *&N&                                     
 *&N&   char(*)()  D_String()       �ഫYYYYMMDD��YYYY/MM/DD���r��    
 *&N&                                     
 *&N&   char(*)()  C_String()       ��YYYYMMDD����ݭn�����r��    
 *&N&                                     
 *&N&   void       Beep()           ���~ĵ�ܩI�s
 *&N&                                     
 *&N&   int        FindBit()        ��Bit Table���̲׺ݾ��W�ٴM����������e
 *&N&                                     
 *&N&   int        GetHostName()    ������׺ݾ��W��
 *&N&                                     
 *&N&   int (*)()  TxLogIni()       ����y���ɪ�l��
 *&N&                                     
 *&N&   int (*)()  SyStuIni()       �t�Ϊ��A��l��
 *&N&                                     
 *&N&   int (*)()  ShowRestInfo()   �ھڨt�Τ�������ܪ����O
 *&N&                                     
 *&N&   int         RecoveryCwa()    �t�δ_��
 */

#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#ifdef   CURSES
#include <curses.h>
#endif
#include "errlog.h"
#include "emctldef.h"
#include "cwa.h"
#include "emcenvhl.h"
#include "emcstart.h"
#include "emcpgdef.h"
#include "asscal.h"

#ifndef H_TMCENV
#define H_TMCENV
#define  CWA_SHM_KEY    "CWA_SHM_KEY"
#define  CTF_SHM_KEY    "CTF_SHM_KEY"
#define  ICT_SHM_KEY    "ICT_SHM_KEY"
#define  DBT_SHM_KEY    "DBT_SHM_KEY"
#define  IET_SHM_KEY    "IET_SHM_KEY"
#define  SYS_MODE       "SYSMODE"
#define  BASE_YEAR      "BASE_YEAR"
#define  SYSTEM_ROLE    "SYSTEM_ROLE"
#define  NO_SIGNON      "NO_SIGNON"
#endif
#define  SYSTEM_STARTED 0x8000 /* 1:started ; 0:not started */
#define  SYSTEM_RESTART 0x4000 /* 1:restarted ; 0:Normal Begin */
#define  REQUEST_ABEND  0x2000
#define  OFFLINE_MODE   0x1000
#define  OVER_TIME      0x0800
#define  ONLINE_CLOSE   0x0400 /* 1:Batch ; 0:On_line        */
#define  DEBUG_MODE     0x0200
#define  FILE_NAME_LEN  80
#define  CHINESE_TYPE   '1'
#define  ONLINE          0 
#define  BATCH           1

/* Key Definition */
#define  CTL_P           16
#define  CTL_N           14
#define  CTL_L           12
#define  CTL_R           18
#define  CTL_I            9
#define  CTL_H            8
#define  CTL_D            4
#define  CTL_U           21
#define  CR              13
#define  ESC             27
#define  ENTER           0x0797  
#define  MAX_INPUT_TIMES 3

static char sg_caMmdd[5];

extern int g_iCwaKey;
extern int g_iCtfKey;
extern int g_iIctKey;
extern int g_iDbtKey;
extern int g_iIetKey;
extern int g_iSysOpMode;
extern int g_iTotTmNum;
extern int g_iBaseYear;
extern int g_iFirstRun;
extern int g_iSystemRole;
extern char g_caIfVerName[10][20];
extern char g_cByPassInput;

extern int  errno;
extern char *sys_errlist[];

/* Add by Hu chunlin BEGIN */
extern char g_cCenterSysStatus;
/* Add by Hu chunlin END   */

char   *C_String();
char   *D_String();

extern int gs_iMaxLoadCfg;
extern struct MDA *pstMda;

/*
 *&N& ROUTINE NAME: SysStart()
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&           
 *&R& RETURN VALUES:
 *&R& 
 *&R&           
 *&R&           
 *&D& DESCRIPTION:           
 *&D&     ����Ƭ��t�ζ}���B�z,�ھڨt�Ϊ��A�i��۹������}���B�z
 *&D&   1.��~����o�P�ˬd
 *&D&   2.�ˬd�t�ζ}�����A
 *&D&   3.����y���ɪ�l�B�z
 *&D&   4.�t�Ϊ��A��l��
 *&D&   5.�Ұʦ��A�{��
 *&D&           
 */


SysStart(char *pcErrStep)
{
  int    iRc, i;
  struct CwaCtl stCwaCtl;
  struct SSA *pstSsa;
  short  sStatus;       /* the system status  */
  int    iNoSignon;
  char   ch;
  struct BrhArea *pstBrh;
  struct TermArea  stTmArea;
  char   caOpt[128];

  /* add by Hu Chunlin BEGIN */
  char   caBuffer[20];
  /* add by Hu Chunlin END   */  

  UCP_TRACE(P_SysStart);

  *pcErrStep = '0';
  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);

  if (iRc != 0) {
    *pcErrStep = '1';
    UCP_TRACE_END(GET_SSA_PTR_ERR);
  }

  sStatus = pstSsa->sSysStatus;
  memcpy(sg_caMmdd,&pstSsa->caTxnDate[4],4);
  sg_caMmdd[4] = 0x0;

/* Get the system role before the TXN day check  */
  g_iSystemRole = GetCnfValue( SYSTEM_ROLE );
  if ( (g_iSystemRole != 0) && (g_iSystemRole != 1)){
    *pcErrStep = '1';
    UCP_TRACE_END( GET_SYSTEMROLE_ERR );
  }

  iNoSignon = GetCnfValue( NO_SIGNON );
  if ( (iNoSignon != 0) && (iNoSignon != 1)){
    *pcErrStep = '1';
    UCP_TRACE_END( GET_NOSIGNON_ERR );
  }
  
  /* Get the base year before the TXN day check  */
  g_iBaseYear = GetCnfValue( BASE_YEAR );

  /* added by WuChihLiang 19960207 for double-mechine switch */ 
if ( g_cByPassInput != 'y'){
  if (g_iSystemRole == 0 || iNoSignon == 1) { /* This is the center host */ 
    EmsShowData('0',"CALENDAR DATE CHECK\n");
    iRc = GetCalDate();
    if (iRc != 0) {
      *pcErrStep = '2';
      UCP_TRACE_END(iRc);  
    }

    EmsShowData('0',"Begin to update Branch Txndate from Calendar File..\n");
    iRc = CallUptGetRtn();
    if (iRc != 0) {
      UCP_TRACE_END(iRc);  
    }
  }
  else {                    /* This is the Branch host */
    iRc = FindBit(&stTmArea);
    if (iRc != 0) {
      UCP_TRACE_END(FIND_BIT_ERROR);
    }
    EmsShowData('0',"Begin to Signon to Center to Get Txndate....\n");
    iRc = SignonCenter();
    switch (iRc) {
      case 0:
        break;
      case -1:
        sprintf (g_caMsg,
                 "There's a branch code not existing in calendarfile\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"--------------------------------------------------\n");
        UCP_TRACE_END(NOSUCH_BRHID_ERR);
      case -2:
        sprintf (g_caMsg,
                 "The startdate of one of the branchs is illegal\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"--------------------------------------------------\n");
        UCP_TRACE_END(ILL_STARTDATE_ERR);
      case -3:
        sprintf (g_caMsg,
                 "The txndate is over the calendar file's definition\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"--------------------------------------------------\n");
        UCP_TRACE_END(TXNDATE_OVERFLOW_ERR);
      case -4:
        sprintf (g_caMsg,
                 "Calander File doesn't exist!!\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"--------------------------------------------------\n");
        UCP_TRACE_END(CALFILE_NOEXIST_ERR);
      case -5:
        sprintf (g_caMsg,
                 "Calander File read error!!\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"--------------------------------------------------\n");
        UCP_TRACE_END(READ_CALFILE_ERR);
      case -6:
        sprintf (g_caMsg,
                 "Other unknown error!!\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"--------------------------------------------------\n");
        UCP_TRACE_END(UNKNOWN_CAL_ERR);                 
      case -7:
        EmsShowData('0',"Execute Successfully! But the calendar file in one of");
        EmsShowData('0',"the Branchs will be not enough to use soon,please  "); 
        EmsShowData('0',"prodduce the next year's calendar file ASAP!!      ");
        EmsShowData('0',"--------------------------------------------------\n");
        EmsShowData('0',"Press Any Key to continue...      ");
        getchar();
        iRc = 0;
        break;
      case -8:
        sprintf (g_caMsg,
                 "Unknown return code,please check...\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"--------------------------------------------------\n");
        UCP_TRACE_END(UNKNOWN_RTNCODE_ERR);             
      case -9:
        sprintf (g_caMsg,
                 "Center's TPE has not opened yet !!!\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"Please check with the Center and restart again!!\n");
        EmsShowData('0',"--------------------------------------------------\n");
        EmsShowData('0',"Press Any Key to continue....\n");
        getchar();
        UCP_TRACE_END(CENTER_NOTOPEN_ERR);  
      case -10:
        sprintf (g_caMsg,
                 "This TTY is not defined in Center's Bit table!!!\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"Please check with the Center and restart again!!\n");
        EmsShowData('0',"--------------------------------------------------\n");
        EmsShowData('0',"Press Any Key to continue....\n");
        getchar();
        UCP_TRACE_END(TTY_NOTDEFINED_ERR);  

      /* TCC: 1995/11/23 Begin */
      case -701:
        sprintf (g_caMsg,
                 "F701 Network message length checked error !\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"--------------------------------------------------\n");
        UCP_TRACE_END (F701_ERR);

      case -702:
        sprintf (g_caMsg,
                 "F702 Failure to read Peer address !\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"--------------------------------------------------\n");
        UCP_TRACE_END (F702_ERR);

      case -703:
        sprintf (g_caMsg,
                 "F703 IP address not defined in /etc/hosts !\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"--------------------------------------------------\n");
        UCP_TRACE_END (F703_ERR);

      case -704:
        sprintf (g_caMsg,
                 "F704 Failure to get CWA key !\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"--------------------------------------------------\n");
        UCP_TRACE_END (F704_ERR);

      case -705:
        sprintf (g_caMsg,
                 "F705 Center's TPE has not opened yet !!!\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        do 
        {
          EmsShowData('0',"Do you want to change to OFFLINE mode(yes/no) : ");
          gets (caOpt);

          for (i=0; ((caOpt[i] != 0) && (i<sizeof(caOpt))); i++)
              caOpt[i] = toupper (caOpt[i]);

        } while ((strcmp(caOpt, "YES") != 0) && (strcmp(caOpt, "NO") != 0));

        if (strcmp(caOpt, "YES") == 0)
        {
          EmsShowData('0',"Please check with the Center !!\n");
          pstSsa->sSysStatus |= OFFLINE_MODE;
          EmsShowData('0',"\nTPE System is switched to OFFLINE mode !!\n");
          EmsShowData('0',"CALENDAR DATE CHECK\n");
          iRc = GetCalDate();
          if (iRc != 0) {
            *pcErrStep = '2';
            UCP_TRACE_END(iRc);
          }
      
          EmsShowData('0',
                      "Begin to update Branch Txndate from Calendar File..\n");
          iRc = CallUptGetRtn();
          if (iRc != 0) {
            UCP_TRACE_END(iRc);
          }
          break;
        }
        else
        {
          EmsShowData('0',"Please check with the Center and restart again!!\n");
          EmsShowData('0',"--------------------------------------------------\n");
          UCP_TRACE_END (F705_ERR);
        }

      case -706:
        sprintf (g_caMsg,
                 "F706 Failure to get length of branch and terminal !\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"--------------------------------------------------\n");
        UCP_TRACE_END (F706_ERR);
 
      case -707:
        sprintf (g_caMsg,
                 "F707 This TTY is not defined in Center's Bit table!!!\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"Please check with the Center and restart again!!\n");
        EmsShowData('0',"--------------------------------------------------\n");
        EmsShowData('0',"Press Any Key to continue....\n");
        getchar();
        UCP_TRACE_END (F707_ERR);

      case -708:
        sprintf (g_caMsg,
                 "F708 Failure to get TPE system status (Online/Batch) !\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"--------------------------------------------------\n");
        UCP_TRACE_END (F708_ERR);
 
      case -709:
        sprintf (g_caMsg,
                 "F709 TPE internal error: Illegal kind request !\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"--------------------------------------------------\n");
        UCP_TRACE_END (F709_ERR);
 
      case -710:
        sprintf (g_caMsg,
                 "F710 Failure to read/write from/to network !\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"--------------------------------------------------\n");
        UCP_TRACE_END (F710_ERR);
 
      case -711:
        sprintf (g_caMsg,
                 "F711 Failure to send SIF to TPE system ! (System busy, wait a moment)\n"); 
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"--------------------------------------------------\n");
        UCP_TRACE_END (F711_ERR);
 
      case -712:
        sprintf (g_caMsg,
                 "F712 Failure to read/write from/to TPE system !\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"--------------------------------------------------\n");
        UCP_TRACE_END (F712_ERR);
 
      case -713:
        sprintf (g_caMsg,
                 "F713 Failure to open tpumap.txt!\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"--------------------------------------------------\n");
        UCP_TRACE_END (F713_ERR);
       
      case -714:
        sprintf (g_caMsg,
                 "F714 Total lines of tpumap.dat exceeds 70!\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"--------------------------------------------------\n");
        UCP_TRACE_END (F714_ERR);
       
      case -715:
        sprintf (g_caMsg,
                 "F715 Get SSA beginning pointer error!\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"--------------------------------------------------\n");
        UCP_TRACE_END (F715_ERR);
       
      case -716:
        sprintf (g_caMsg,
                 "Central TPE is not started completely!\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"--------------------------------------------------\n");
        UCP_TRACE_END (F716_ERR);
       
      case -717:
        sprintf (g_caMsg,
                 "F717 Failure to write CWA file to central host system!\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"--------------------------------------------------\n");
        UCP_TRACE_END (F717_ERR);
       
      /* TCC: 1995/11/23 End */
      case -23:
        sprintf (g_caMsg,
                 "Get SSA beginning pointer error !!!\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"--------------------------------------------------\n");
        EmsShowData('0',"Press Any Key to continue....\n");
        UCP_TRACE_END (GET_SSA_PTR_ERR);
      case -24:
        sprintf (g_caMsg,
                 "Get BIT beginning pointer error !!!\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"--------------------------------------------------\n");
        EmsShowData('0',"Press Any Key to continue....\n");
        UCP_TRACE_END (GET_BIT_PTR_ERR);
      case -25:
        sprintf (g_caMsg,
                 "Network table defined error !!! (check socketbl, /etc/hosts and /etc/services)\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        EmsShowData('0',"--------------------------------------------------\n");
        UCP_TRACE_END (NETWORKTBL_ERR);

      case -26:
        sprintf (g_caMsg,
                 "Unable to send data to Center !!!\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        do 
        {
          EmsShowData('0',"Do you want to change to OFFLINE mode(yes/no) : ");
          gets (caOpt);

          for (i=0; ((caOpt[i] != 0) && (i<sizeof(caOpt))); i++)
              caOpt[i] = toupper (caOpt[i]);

        } while ((strcmp(caOpt, "YES") != 0) && (strcmp(caOpt, "NO") != 0));

        if (strcmp(caOpt, "YES") == 0)
        {
          EmsShowData('0',"Please check with the Center !!\n");
          pstSsa->sSysStatus |= OFFLINE_MODE;
          EmsShowData('0',"\nTPE System is switched to OFFLINE mode !!\n");
          EmsShowData('0',"CALENDAR DATE CHECK\n");
          iRc = GetCalDate();
          if (iRc != 0) {
            *pcErrStep = '2';
            UCP_TRACE_END(iRc);
          }
      
          EmsShowData('0',
                      "Begin to update Branch Txndate from Calendar File..\n");
          iRc = CallUptGetRtn();
          if (iRc != 0) {
            UCP_TRACE_END(iRc);
          }
          break;
        }
        else
        {
          EmsShowData('0',"Please check with the Center and restart again!!\n");
          EmsShowData('0',"--------------------------------------------------\n");
          UCP_TRACE_END (SEND_ERR);
        }

      case -27:
        sprintf (g_caMsg,
                 "Unable to receive data from Center !!!\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        do 
        {
          EmsShowData('0',"Do you want to change to OFFLINE mode(yes/no) : ");
          gets (caOpt);

          for (i=0; ((caOpt[i] != 0) && (i<sizeof(caOpt))); i++)
              caOpt[i] = toupper (caOpt[i]);

        } while ((strcmp(caOpt, "YES") != 0) && (strcmp(caOpt, "NO") != 0));

        if (strcmp(caOpt, "YES") == 0)
        {
          EmsShowData('0',"Please check with the Center !!\n");
          pstSsa->sSysStatus |= OFFLINE_MODE;
          EmsShowData('0',"\nTPE System is switched to OFFLINE mode !!\n");
          EmsShowData('0',"CALENDAR DATE CHECK\n");
          iRc = GetCalDate();
          if (iRc != 0) {
            *pcErrStep = '2';
            UCP_TRACE_END(iRc);
          }
      
          EmsShowData('0',
                      "Begin to update Branch Txndate from Calendar File..\n");
          iRc = CallUptGetRtn();
          if (iRc != 0) {
            UCP_TRACE_END(iRc);
          }
          break;
        }
        else
        {
          EmsShowData('0',"Please check with the Center and restart again!!\n");
          EmsShowData('0',"--------------------------------------------------\n");
          UCP_TRACE_END (READ_ERR);
        }

      case -28:
        sprintf (g_caMsg,
                 "Failure to receive DESKEY from Center !!!\n");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        EmsShowData('0', g_caMsg);
        do 
        {
          EmsShowData('0',"Do you want to change to OFFLINE mode(yes/no) : ");
          gets (caOpt);

          for (i=0; ((caOpt[i] != 0) && (i<sizeof(caOpt))); i++)
              caOpt[i] = toupper (caOpt[i]);

        } while ((strcmp(caOpt, "YES") != 0) && (strcmp(caOpt, "NO") != 0));

        if (strcmp(caOpt, "YES") == 0)
        {
          EmsShowData('0',"Please check with the Center !!\n");
          pstSsa->sSysStatus |= OFFLINE_MODE;
          EmsShowData('0',"\nTPE System is switched to OFFLINE mode !!\n");
          EmsShowData('0',"CALENDAR DATE CHECK\n");
          iRc = GetCalDate();
          if (iRc != 0) {
            *pcErrStep = '2';
            UCP_TRACE_END(iRc);
          }
      
          EmsShowData('0',
                      "Begin to update Branch Txndate from Calendar File..\n");
          iRc = CallUptGetRtn();
          if (iRc != 0) {
            UCP_TRACE_END(iRc);
          }
          break;
        }
        else
        {
          EmsShowData('0',"Please check with the Center and restart again!!\n");
          EmsShowData('0',
                      "--------------------------------------------------\n");
          UCP_TRACE_END (GET_CENTER_DESKEY_ERR);
        }
       
      default: /* Off-Line error... DCS communication error!! */
        UCP_TRACE_END (SYSTEM_ERR);
        break;
    } /* FOR switch (iRc) */
  }

  if (iRc !=0) { /* signon error, get the txndate from local's calendar file */
    EmsShowData('0',"Branch signon to Center failure!!!\n"); 
    EmsShowData('0',"Load calendar file from local.....\n");
    EmsShowData('0',"Press Any Key to continue....\n");
    getchar();
    iRc = CallUptGetRtn();
    if (iRc != 0) {
      *pcErrStep = '3';
      UCP_TRACE_END(iRc);  
    }
  }
}

  if ( (!(sStatus & SYSTEM_RESTART)) && (!(sStatus & ONLINE_CLOSE)) ) {
          /*real system-on, not accident abort */
    if ( !(sStatus & SYSTEM_STARTED) )  {
      iRc = TxLogIni();

        if (iRc != 0) {
          *pcErrStep = '3';
          UCP_TRACE_END(iRc);
        }

      iRc = SyStuIni();

        if (iRc != 0) {
          *pcErrStep = '4';
          UCP_TRACE_END(iRc);
        }
    }
    else {
      sStatus = sStatus | SYSTEM_RESTART ;
      pstSsa->sSysStatus = sStatus ;
    }

  }

  if (sStatus & SYSTEM_RESTART) {
    iRc = RecoveryCwa();
    if (iRc != 0) {
      UCP_TRACE_END(FORWARD_RV_CWA_ERR);
    }
  }

  EmsShowData('0',"Start to invoke the TPE servers.....\n");
  if ( !(sStatus & ONLINE_CLOSE) ) { 
    iRc = IsuSvPrs(ONLINE);    /* Online Processing */

    if (iRc != 0) {
      *pcErrStep = '6';
      UCP_TRACE_END(iRc);
    }
  }
  else {
    iRc = IsuSvPrs(BATCH);    /* Batch Processing */

    if (iRc != 0) {
      *pcErrStep = '7';
      UCP_TRACE_END(iRc);
    }
  }

  EmsShowData('0',"TPE servers have been invoked.\n");
  EmsShowData('1',"clear");
  EmsShowData('0',"The Current System Configuration are:\n");
/*
  EmsShowData('0',"TPE kernel version 1.1.3\n");
*/
  printf ("%s %s\n", UtlProdName(), UtlProdVerId());

  if ( !(sStatus & ONLINE_CLOSE) ) { 
    ShowRestInfo(ONLINE);
  }
  else {
    ShowRestInfo(BATCH);
  }

  /* added by Jess Wu 19950110 BEGIN */
  pstSsa->sSysStatus    = pstSsa->sSysStatus | SYSTEM_STARTED ;
  /* added by Jess Wu 19950110 END */

  EmsShowData('0',"TPE has been started up.\n");

  /* added by Hu Chunlin to show Center TPE System Status. BEGIN */
  if( g_iSystemRole != 0 ) {
    if(iNoSignon == 1) {
      printf("\nBranch not signon to center.\n\n");
    }
    else {
      memset(caBuffer, 0x0, 20);
      memcpy(caBuffer, pstSsa->caTxnDate, 8);
      switch(g_cCenterSysStatus) {
        case 'B' : printf("\nCenter TPE :    system status - [BATCH]\n");
                   printf("             transaction date - %s\n", caBuffer);
		   break;
	case 'O' : printf("\nCenter TPE :    system status - [ONLINE]\n");
                   printf("             transaction date - %s\n", caBuffer);
		   break;
	default  : printf("\nCenter TPE :    system status - Not Available\n");
		   break;
      }
      printf("\n");
    }
  }
  /* added by Hu Chunlin to show Center TPE System Status. END   */
  
  UCP_TRACE_END(0);  
}

#define  READ_DATA_ERR  -1
#define  OPEN_FILE_ERR  -2
#define  CLOSE_FILE_ERR  -3

int
TxLogIni()
{
  struct CwaCtl stCwaCtl;
  struct SSA *pstSsa;
  int  iRc;
  short sStatus;
  int  iLogFd;
  char caFlName[FILE_NAME_LEN];
  char caBkFlName[FILE_NAME_LEN];
  char caBkCmd[80];
  char caMmdd[5];

  UCP_TRACE(P_TxLogIni);

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);

  if (iRc != 0) {
    UCP_TRACE_END(GET_SSA_PTR_ERR);
  }

  sStatus = pstSsa->sSysStatus;
  
  if ( !(sStatus & ONLINE_CLOSE) && !(sStatus & SYSTEM_RESTART)) {
 
    memset (caBkFlName,'\0',FILE_NAME_LEN);
    sprintf (caBkFlName, "%s/%s.%s", 
             (char *)getenv("III_DIR"), SBBSLOG_F, sg_caMmdd);

    memset(caFlName,'\0',FILE_NAME_LEN);
    sprintf (caFlName, "%s/%s", 
             (char *)getenv("III_DIR"), SBBSLOG_F);

    if ( (iLogFd = open(caFlName, O_RDONLY)) > 0 ) { 
      sprintf(caBkCmd,"rm %s.????",caFlName);
      system(caBkCmd);
      sprintf(caBkCmd,"cp %s %s",caFlName,caBkFlName);
      system(caBkCmd);
      close(iLogFd);
    }

    iLogFd = open(caFlName, O_RDWR+O_CREAT+O_TRUNC+O_APPEND,00666);
    if (iLogFd < 0) {
      sprintf (g_caMsg, "<EMS> Failure to open [%s]! (errno:%d=>%s)",
               caFlName, errno, sys_errlist[errno]);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(OPEN_LOGFILE_ERR);
    }

    if ( close(iLogFd) != 0) {
      sprintf (g_caMsg, "<EMS> Failure to close [%s]! (errno:%d=>%s)",
               caFlName, errno, sys_errlist[errno]);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(CLOSE_LOGFILE_ERR);
    }
  }
    UCP_TRACE_END(0);
}

int
SyStuIni()
{
  struct CwaCtl stCwaCtl;
  struct SSA *pstSsa;
  int  iRc;
  char cStatus; 

  UCP_TRACE(P_SyStuIni);

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);

  if (iRc != 0) {
    UCP_TRACE_END(GET_SSA_PTR_ERR);
  }

  pstSsa->cFrontLineStatus = '0';
  memset(pstSsa->caPrevTxnLogRrn,'0',5); 
  memset(pstSsa->caPrevBtefRrn,'0',5); 
  memset(pstSsa->caLastRrnInBeft,'0',5); 
  pstSsa->lTotalTxnCnt = 0;
  pstSsa->lNextAvLogRrn = 1;
  UCP_TRACE_END(0);
}



/* ******************************************************************** */
/* ----------Following is the new function for business day input ----- */
#define  DATE_LEN      8
#define  DAYS_OFFSET   6  /* YYYYMMDD  */
#define  MNTH_OFFSET   4  /* YYYYMMDD  */
#define  YEAR_OFFSET   0  /* YYYYMMDD  */
#define  TRUE          1
#define  FALSE         0
#define  MAX_DATW      1
int      iaMax_Days[13] = {  0, 31, 28, 31, 30, 31, 30,
                                   31, 31, 30, 31, 30, 31} ;

#ifndef CURSES
int
GetCalDate()
{
  FILE   *zFp,*fopen();
  short  sStatus;
  int    iRc, iInput_Times, iDate_Chk_No, iDate_Win_No;
  char   caKey_Buf[81];
  char   caTmp_Buf[80];
  char   caFlName[FILE_NAME_LEN];
  struct SSA *pstSsa;
  struct CwaCtl stCwaCtl;
  struct TermArea  stTmArea;

  UCP_TRACE(P_GetCalDate);

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);

  if (iRc != 0) {
    UCP_TRACE_END(GET_SSA_PTR_ERR);
  }

  sStatus = pstSsa->sSysStatus;

  iRc = FindBit(&stTmArea);
  if (iRc != 0) {
    UCP_TRACE_END(FIND_BIT_ERR);
  }

  memset (caFlName, 0, sizeof(caFlName));
  strcpy(caFlName,(char *) getenv("III_DIR"));
  strcat(caFlName,(char *) "/");
  if (stTmArea.cTermType == CHINESE_TYPE) {
    strcat(caFlName,TXNDAT_C);
  }
  else  {
    strcat(caFlName,TXNDAT_E);
  }

  zFp = fopen(caFlName,"r");
  if (zFp == NULL) {
    sprintf (g_caMsg,
             "<EMS> Failure to open [%s]! (errno:%d=>%s)",
             caFlName, errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG|RPT_TO_TTY, 0, 0);
    DetErrRpt(OPEN_FILE_ERR,g_caMsg);
    UCP_TRACE_END(OPEN_TXNDATE_ERR);
  }
 
/*
  signal(SIGCLD, SIG_IGN);
*/
  EmsShowData('1',"clear");

  while ( fgets(caTmp_Buf,80,zFp) != NULL ){
    EmsShowData('0',caTmp_Buf);
    EmsShowData('0',"\n");
  }

  fclose(zFp);

  if ( !(sStatus & SYSTEM_RESTART) ) {  
    EmsShowData('0',"System Status: [NORMAL]\n");
    EmsShowData('0',"\n");
  }
  else  {
    EmsShowData('0',"System Status: [RESTART]\n");
    EmsShowData('0',"\n");
  }
    
  if ( !(sStatus & ONLINE_CLOSE) ) { 
    EmsShowData('0',"Operating Mode: [ONLINE]\n");
    EmsShowData('0',"\n");
  }
  else  {
    EmsShowData('0',"Operating Mode: [BATCH]\n");
    EmsShowData('0',"\n");
  }

  iInput_Times = 0;
  iDate_Chk_No = -1;
  iDate_Win_No = -1;

  do {
    iDate_Win_No ++;
    iInput_Times++;
    memset(caKey_Buf, 0, sizeof(caKey_Buf));
    Get_Wdata (0, DATE_LEN, caKey_Buf);
    if (strlen(caKey_Buf) == 0)
    {
      ErrLog (1000, "<EMS> Get_Wdata: Null input", RPT_TO_LOG, 0, 0);
      continue;
    }

    iRc = Filter_Wdata(caKey_Buf);
    if (iRc != 0)
    {
      sprintf (g_caMsg, "Invalid operation date [%s], Please input again!",
               caKey_Buf);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      printf ("%s\n", g_caMsg);
      iDate_Win_No --;
      if (iInput_Times >= MAX_INPUT_TIMES)
      {
         sprintf (g_caMsg,
                  "<EMS> Retry %d times to input operation date!",
                  iInput_Times);
         ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
         UCP_TRACE_END(TXNDATE_INPUT_ERR);
      }
    }
    else
    {
      EmsShowData('0',"\r");
      EmsShowData('0',D_String(caKey_Buf));
      EmsShowData('0',"\n");
      if (Date_Valid(caKey_Buf))  {
        iRc = Check_Busi_Date (caKey_Buf);
        if (iRc != 0)
        {
           sprintf (g_caMsg,
                    "<EMS> Non-business day/ASDAYIN2 error(iRc:%d)", iRc);
           ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
           UCP_TRACE_END (iRc);
        }

        iRc = Txn_Date_Check(&iDate_Chk_No,&iDate_Win_No,caKey_Buf);
        if (iRc != 0) {
          UCP_TRACE_END(iRc-4);
        }
        break;
      }
      else
        iDate_Win_No --;
    }
  }  while (iInput_Times <= MAX_INPUT_TIMES);
  /*
  }  while (iDate_Win_No < MAX_DATW -1 );
  */
  
  if (iDate_Win_No != iDate_Chk_No) {
    EmsShowData('0',"Invalid operation date!! \n");
    UCP_TRACE_END(TXNDATE_INPUT_ERR);
  }
  
  UCP_TRACE_END(0);
}
#else   /*  have to link emscurss.o */

#define NO_ITEM       1
#define NO_RECORD     1
#define MAX_DATA_LEN  20
struct stMenu {
	WINDOW *pwWin;
	int iNoRecord; /* the number of records shown at the same time */
	struct stMenu *pstNextMenu;
	struct stItem *pstItem;
	};
struct stItem {
	int iPage;
	int iRow;
	int iCol;
	int (*Routine1)();
	int (*Routine2)();
	char caData[ MAX_DATA_LEN ];
	char cType;
	int iLength;
	char cAttribute;
        } stRecord[ NO_ITEM * NO_RECORD ] = {
            {1, 16, 48, NULL, NULL, "        ", 'c', 8, 'e'},
        };
int
GetCalDate()
{
  FILE   *zFp,*fopen();
  short  sStatus;
  int    iRow, iCol, iChkNo;
  int    iRc, iDate_Chk_No, iDate_Win_No;
  char   caKey_Buf[81], caTmp_Buf[80], caShowBuf[80];
  char   caFlName[FILE_NAME_LEN];
  struct SSA *pstSsa;
  struct CwaCtl stCwaCtl;
  struct TermArea  stTmArea;
  struct stMenu *pstMenu;

  UCP_TRACE(P_GetCalDate);

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);

  if (iRc != 0) {
    UCP_TRACE_END(GET_SSA_PTR_ERR);
  }

  sStatus = pstSsa->sSysStatus;

  iRc = FindBit(&stTmArea);
  if (iRc != 0) {
    UCP_TRACE_END(FIND_BIT_ERR);
  }

  memset(caFlName,'\0',FILE_NAME_LEN);
  strcpy(caFlName,(char *) getenv("III_DIR"));
  strcat(caFlName,(char *) "/");
  if (stTmArea.cTermType == CHINESE_TYPE) {
    strcat(caFlName,TXNDAT_C);
  }
  else  {
    strcat(caFlName,TXNDAT_E);
  }

  zFp = fopen(caFlName,"r");
  if (zFp == NULL) {
    sprintf (g_caMsg,
             "<EMS> Failure to open [%s]! (errno:%d=>%s)",
             caFlName, errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt(OPEN_FILE_ERR,g_caMsg);
    UCP_TRACE_END(OPEN_TXNDATE_ERR);
  }

  pstMenu = (struct stMenu *) InitNullMenu1();
  pstMenu->pstItem = (struct stItem *) &stRecord;
/*
  signal(SIGCLD, SIG_IGN);
*/

  iRow = 0;
  while (  fgets(caTmp_Buf,80,zFp) != NULL ){
    ShowStr(pstMenu,iRow,0,caTmp_Buf,'d');
    iRow++;
  }

  fclose(zFp);

  if ( !(sStatus & SYSTEM_RESTART) ) {  
    ShowStr(pstMenu,10,0,"System Status: [NORMAL]",'r');
  }
  else  {
    ShowStr(pstMenu,10,0,"System Status: [RESTART]",'r');
  }
    
  iRow += 2;
  if ( !(sStatus & ONLINE_CLOSE) ) { 
    ShowStr(pstMenu,12,0,"Operating Mode: [ONLINE]",'r');
  }
  else  {
    ShowStr(pstMenu,12,0,"Operating Mode: [BATCH]",'r');
  }
  memset(caTmp_Buf, 0, sizeof(caTmp_Buf));
  memcpy(caTmp_Buf,&(pstSsa->caTxnDate[0]),8);

  iRow += 2;
  iRow += 2;
  iDate_Chk_No = -1;
  iDate_Win_No = -1;

  DisplayHead(pstMenu);
  DisplayData(pstMenu);

  do {
    iDate_Win_No ++;
    Get_Wdata(iDate_Win_No,caKey_Buf,pstMenu);
    iRc = Filter_Wdata(caKey_Buf);
    if (iRc != 0)
    {
      ShowMsg(pstMenu,23,20,"Invalid operation date! Please input again.");
      DisplayMenu(pstMenu);
      iDate_Win_No --;
      continue;
    }
    ShowStr(pstMenu,17+(iDate_Win_No*2),0,D_String(caKey_Buf),'r');
    if (Date_Valid(caKey_Buf,pstMenu)){
      iRc = Check_Busi_Date (caKey_Buf);
      if (iRc != 0)
      {
         sprintf (g_caMsg,
                  "<EMS> Non-business day/ASDAYIN2 error(iRc:%d)", iRc);
         ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
         EndTool(pstMenu);
         UCP_TRACE_END (iRc);
      }

      iChkNo = iDate_Chk_No;
      iRc = Txn_Date_Check(&iDate_Chk_No,&iDate_Win_No,caKey_Buf,pstMenu);
      if (iRc != 0) {
        ShowMsg(pstMenu,
                23,20,"There'a an error occured in getting business day!! ");
        DisplayMenu(pstMenu);
        wgetch(pstMenu->pwWin);
        EndTool(pstMenu);
        UCP_TRACE_END(iRc-4);
      }
      if (iDate_Chk_No != iChkNo) { /* compare both to know sucess or not */
        ShowMsg(pstMenu,23,20,"Operating date Input Success!!");
        DisplayMenu(pstMenu);
      }
    }
    else
      iDate_Win_No --;
  }  while (iDate_Win_No < MAX_DATW -1 );

  ShowMsg (pstMenu, 23, 20,
           "Operating date Input Success!! press any key to continue..");
  DisplayMenu(pstMenu);
  wgetch(pstMenu->pwWin);

  if (iDate_Win_No != iDate_Chk_No) {
    ShowMsg(pstMenu,23,20,"Operating date input error!! ");
    EndTool(pstMenu);
    UCP_TRACE_END(TXNDATE_INPUT_ERR);
  }

  EndTool(pstMenu);
  UCP_TRACE_END(0);
}
#endif

#ifndef CURSES
Get_Wdata(iWinno,iDatelen,pcaKey_Buf)
int  iWinno;
int  iDatelen;
char *pcaKey_Buf;
{
  char caTmpBuf[80];
  char caShowBuf[80];

     memset(caTmpBuf,'\0',80);

     switch(iWinno)  {
       case 0:
               strcpy(caTmpBuf,"Operating");
               break;
       case 1:
               strcpy(caTmpBuf,"Next Transaction");
               break;
       case 2:
               strcpy(caTmpBuf,"Next  Next Transaction");
               break;
     }

     EmsShowData('0',"\n");
     sprintf(caShowBuf,"please enter the %s Day:\n",caTmpBuf);
     EmsShowData('0',caShowBuf);
     scanf("%8s",pcaKey_Buf);
     pcaKey_Buf[8] = 0x0;
}
#else
DisplayHead(pstMenu)
struct stMenu *pstMenu;
{
  char caTmpBuf[80];
  char caShowBuf[80];
  int  i;

  for (i=0;i<NO_ITEM;i++){   
    switch(i){
      case 0:
              strcpy(caTmpBuf,"Operating");
              break;
      case 1:
              strcpy(caTmpBuf,"Next Transaction");
              break;
      case 2:
              strcpy(caTmpBuf,"Next  Next Transaction");
              break;
    }
    sprintf(caShowBuf,"Please enter the %s Day:",caTmpBuf);
    ShowStr(pstMenu,16+i*2,0,caShowBuf,'d');
  }
  sprintf(caShowBuf,"^D: Delete, ^U: Undo, Enter:Input Over.",caTmpBuf);
  ShowStr(pstMenu,22,0,caShowBuf,'d');
}

Get_Wdata(iWinno,pcaKey_Buf,pstMenu)
int  iWinno;
char *pcaKey_Buf;
struct stMenu *pstMenu;
{
  char caTmpBuf[80];
  char caShowBuf[80];
  int  i,j;
  char cChar;
  int  iKeyIn;
  int  iCurRow,iCurCol;

     memset(caTmpBuf,'\0',80);

     MvEdtItem(pstMenu,iWinno,A_UNDERLINE);
     keypad(pstMenu->pwWin,TRUE);

     while (1) {
       wrefresh( pstMenu->pwWin);
       iKeyIn = wgetch(pstMenu->pwWin);

       switch(iKeyIn)  {
         case 0x0797 :   /* ENTER */
         case CR :       /* ENTER */
           for(j=0;j<8;j++) {
              cChar = mvwinch(  pstMenu->pwWin,pstMenu->pstItem[ iWinno ].iRow,
                                pstMenu->pstItem[ iWinno ].iCol+j);
              pcaKey_Buf[j] = cChar;
           }
           pcaKey_Buf[8] = 0x0;
           return;
         case KEY_LEFT :
           getyx( pstMenu->pwWin, iCurRow, iCurCol );
           if ( iCurCol > pstMenu->pstItem[ iWinno ].iCol ) {
             wmove( pstMenu->pwWin, iCurRow, iCurCol - 1 );
           }
           else {
             Beep();
           }
           break;
         case KEY_RIGHT :
           getyx( pstMenu->pwWin, iCurRow, iCurCol );
           if ( iCurCol < pstMenu->pstItem[ iWinno ].iCol +
                          pstMenu->pstItem[ iWinno ].iLength - 1 ) {
             wmove( pstMenu->pwWin, iCurRow, iCurCol + 1 );
           }
           else {
             Beep();
           }
           break;
         case 0x04 :    /* Ctrl + d */
           DeleteCh( pstMenu, iWinno );
           break;
         case 0x15 :    /* Ctrl + u */
           Undo( pstMenu, iWinno );
           break;
         case '\x1b' :  /* ESC */
           Beep();
           break;
         default :
           AddCh( pstMenu, iWinno, iKeyIn, 0 );
           break;
       } /* FOR switch(iKeyIn) */
     } /* FOR while(1)  */
}
#endif
#ifndef CURSES
int
Txn_Date_Check(piChkno,piWinno,pcaKey_Buf)
int  *piChkno;
int  *piWinno;
char *pcaKey_Buf;
{
  int    iRc;
  struct CwaCtl stCwaCtl;
  struct SSA *pstSsa;
  short  sStatus;       /* the system status  */
  char   caTmp_Buf[80];
  char   caShowBuf[80];
  long   lDateInput,lDateCore;
  char   caDate[9];
  char   caNextBusi[8];

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);

  if (iRc != 0) {
    return(iRc);
  }

  if (g_iFirstRun == 1) {
    switch((*piWinno)) {
      case 0: /* first time enter */
        (*piChkno)++;
        memcpy(pstSsa->caTxnDate,pcaKey_Buf,DATE_LEN);
        memcpy(caDate,pcaKey_Buf,DATE_LEN);
        caDate[DATE_LEN] = '\0';
        iRc = GetNextBusiDate(caDate,caNextBusi) ;
        if (iRc !=0)  return(iRc);
        memcpy(pstSsa->caNextDate,caNextBusi,DATE_LEN);
        memcpy(caDate,caNextBusi,DATE_LEN);
        iRc = GetNextBusiDate(caDate,caNextBusi) ;
        if (iRc !=0)  return(iRc);
        memcpy(pstSsa->caNext2Date,caNextBusi,DATE_LEN);
        break;
/*--------------------- nonuseful following... ----------------------------*/
      /* nonuseful following... */
      case 1: /* second time enter */
        (*piChkno)++;
        memcpy(pstSsa->caNextDate,pcaKey_Buf,DATE_LEN);
        break;
      case 2: /* first time enter */
        (*piChkno)++;
        memcpy(pstSsa->caNext2Date,pcaKey_Buf,DATE_LEN);
        break;
/*--------------------- nonuseful end ........... -------------------------*/
    }
    return(0);
  }

  sStatus =  pstSsa->sSysStatus;

  if ( !(sStatus & ONLINE_CLOSE) && !(sStatus & SYSTEM_RESTART) ) {   
    /*  Normal & Online begin, Check the enter day with the yesterday */
    switch((*piWinno)) {
      case 0: /* first time enter */
        if ( !(sStatus & SYSTEM_STARTED) ) { /* real Normal&Online start */
            /*  Move to the next Txndate */
          memcpy(caDate,pstSsa->caTxnDate,DATE_LEN);
          caDate[DATE_LEN] = '\0';
          iRc = GetNextBusiDate(caDate,caNextBusi) ;
          if (iRc !=0)  return(iRc);
          memcpy(caDate,caNextBusi,DATE_LEN);
        }
        else {  /* use killallp in the previous stage */
          /* still compare the input as the same txndate */
          memcpy(caDate,pstSsa->caTxnDate,DATE_LEN);
        }

        iRc = strncmp(pcaKey_Buf,caDate,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
          memcpy(pstSsa->caTxnDate,pcaKey_Buf,DATE_LEN);
          iRc = GetNextBusiDate(caDate,caNextBusi) ;
          if (iRc !=0)  return(iRc);
          memcpy(pstSsa->caNextDate,caNextBusi,DATE_LEN);
          memcpy(caDate,caNextBusi,DATE_LEN);
          iRc = GetNextBusiDate(caDate,caNextBusi) ;
          if (iRc !=0)  return(iRc);
          memcpy(pstSsa->caNext2Date,caNextBusi,DATE_LEN);
          /* set the system-on bit ON  */
          pstSsa->sSysStatus    = pstSsa->sSysStatus | SYSTEM_STARTED ;
        }
	else {
          (*piWinno)--;
	  sprintf(caShowBuf,"calendar day check error!!%s\r"
                  ,D_String(caDate));
          EmsShowData('0',caShowBuf);
	  Beep();
        }
        break;
/*--------------------- nonuseful following... ----------------------------*/
      case 1: /* second time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caNextDate,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
          memcpy(pstSsa->caNextDate,pcaKey_Buf,DATE_LEN);
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
	  sprintf(caShowBuf,"business day check error!!%8s\r",D_String(caTmp_Buf));
          EmsShowData('0',caShowBuf);
	  Beep();
        }
        break;
      case 2: /* third  time enter */
        if ( (sStatus & ONLINE_CLOSE) ) {  /* Normal & Batch */ 
          iRc = strncmp(pcaKey_Buf,pstSsa->caNext2Date,DATE_LEN);
          if (iRc == 0) {
            (*piChkno)++;
            memcpy(pstSsa->caNext2Date,pcaKey_Buf,DATE_LEN);
          }
          else {      /* Normal & Online , Don't check Next2date */
            (*piWinno)--;
            memset(caTmp_Buf,'\0',80);
            memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
	    sprintf(caShowBuf,"business day check error!!%8s\r",D_String(caTmp_Buf));
            EmsShowData('0',caShowBuf);
	    Beep();
          }
        }
        else  {
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
          lDateCore  = atol(caTmp_Buf);
          lDateInput = atol(pcaKey_Buf);
          if (lDateInput > lDateCore) {
            memcpy(pstSsa->caNext2Date,pcaKey_Buf,DATE_LEN);
            (*piChkno)++;
          }
          else  {
            (*piWinno)--;
            memset(caTmp_Buf,'\0',80);
            memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
	    sprintf(caShowBuf,"next next business day should not small than %8s\r",D_String(caTmp_Buf));
            EmsShowData('0',caShowBuf);
	    Beep();
          }
        }
	break;
/* -------------------- nonuseful end ........... -----------------------*/
    }  /* FOR switch(...)  */
  }
  else {
    /* Abnormal Begin,Check business days in CWA */
    switch((*piWinno)) {
      case 0: /* first time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caTxnDate,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caTxnDate[0]),8);
	  sprintf(caShowBuf,"canlendar day check error!!%s\r"
                  ,D_String(caTmp_Buf));
          EmsShowData('0',caShowBuf);
	  Beep();
        }
        break;
/*--------------------- nonuseful following... ----------------------------*/
      case 1: /* second time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caNextDate,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
	  sprintf(caShowBuf,"business day check error!!%8s\r",D_String(caTmp_Buf));
          EmsShowData('0',caShowBuf);
	  Beep();
        }
        break;
      case 2: /* third  time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caNext2Date,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caNext2Date[0]),8);
	  sprintf(caShowBuf,"business day check error!!%8s\r",D_String(caTmp_Buf));
          EmsShowData('0',caShowBuf);
	  Beep();
        }
	break;
/*--------------------- nonuseful following... ----------------------------*/
    }  /* FOR switch(...)  */
  }  /* FOR if( !(cStatus.....))  */

  return(0);
}
#else
int
Txn_Date_Check(piChkno,piWinno,pcaKey_Buf,pstMenu)
int  *piChkno;
int  *piWinno;
char *pcaKey_Buf;
struct stMenu *pstMenu;
{
  int    iRc;
  struct CwaCtl stCwaCtl;
  struct SSA *pstSsa;
  short  sStatus;       /* the system status  */
  char   caTmp_Buf[80];
  char   caShowBuf[80];
  long   lDateInput,lDateCore;
  char   caDate[9];
  char   caNextBusi[8];

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);

  if (iRc != 0) {
    return(iRc);
  }

  if (g_iFirstRun == 1) {
    switch((*piWinno)) {
      case 0: /* first time enter */
        (*piChkno)++;
        memcpy(pstSsa->caTxnDate,pcaKey_Buf,DATE_LEN);
        memcpy(caDate,pcaKey_Buf,DATE_LEN);
        caDate[DATE_LEN] = '\0';
        iRc = GetNextBusiDate(caDate,caNextBusi) ;
        if (iRc !=0)  return(iRc);
        memcpy(pstSsa->caNextDate,caNextBusi,DATE_LEN);
        memcpy(caDate,caNextBusi,DATE_LEN);
        iRc = GetNextBusiDate(caDate,caNextBusi) ;
        if (iRc !=0)  return(iRc);
        memcpy(pstSsa->caNext2Date,caNextBusi,DATE_LEN);
        break;
/*--------------------- nonuseful following... ----------------------------*/
      case 1: /* second time enter */
        (*piChkno)++;
        memcpy(pstSsa->caNextDate,pcaKey_Buf,DATE_LEN);
        break;
      case 2: /* first time enter */
        (*piChkno)++;
        memcpy(pstSsa->caNext2Date,pcaKey_Buf,DATE_LEN);
        break;
/*--------------------- nonuseful following... ----------------------------*/
    }
    return(0);
  }

  sStatus =  pstSsa->sSysStatus;

  if ( !(sStatus & ONLINE_CLOSE) && !(sStatus & SYSTEM_RESTART) ) {   
    /* Normal & Online Begin,Can't Check next next day, if not load ACIF */
    switch((*piWinno)) {
      case 0: /* first time enter */
        if ( !(sStatus & SYSTEM_STARTED) ) { /* real Normal&Online start */
            /*  Move to the next Txndate */
          memcpy(caDate,pstSsa->caTxnDate,DATE_LEN);
          caDate[DATE_LEN] = '\0';
          iRc = GetNextBusiDate(caDate,caNextBusi) ;
          if (iRc !=0)  return(iRc);
          memcpy(caDate,caNextBusi,DATE_LEN);
        }
        else {  /* use killallp in the previous stage */
          /* still compare the input as the same txndate */
          memcpy(caDate,pstSsa->caTxnDate,DATE_LEN);
        }

        iRc = strncmp(pcaKey_Buf,caDate,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
          memcpy(pstSsa->caTxnDate,pcaKey_Buf,DATE_LEN);
          iRc = GetNextBusiDate(caDate,caNextBusi) ;
          if (iRc !=0)  return(iRc);
          memcpy(pstSsa->caNextDate,caNextBusi,DATE_LEN);
          memcpy(caDate,caNextBusi,DATE_LEN);
          iRc = GetNextBusiDate(caDate,caNextBusi) ;
          if (iRc !=0)  return(iRc);
          memcpy(pstSsa->caNext2Date,caNextBusi,DATE_LEN);
          /* set the system-on bit ON  */
          pstSsa->sSysStatus    = pstSsa->sSysStatus | SYSTEM_STARTED ;
        }
	else {
          (*piWinno)--;
	  sprintf(caShowBuf,"calendar day check error!!%s"
                  ,D_String(caDate));
          ShowMsg(pstMenu,23,20,caShowBuf);
	  Beep();
        }
        break;
/*--------------------- nonuseful following... ----------------------------*/
      case 1: /* second time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caNextDate,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
          memcpy(pstSsa->caNextDate,pcaKey_Buf,DATE_LEN);
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
	  sprintf(caShowBuf,"business day check error!!%8s",D_String(caTmp_Buf));
          ShowMsg(pstMenu,23,20,caShowBuf);
	  Beep();
        }
        break;
      case 2: /* third  time enter */
        if ( (sStatus & ONLINE_CLOSE) ) {  /* Normal & Batch */ 
          iRc = strncmp(pcaKey_Buf,pstSsa->caNext2Date,DATE_LEN);
          if (iRc == 0) {
            (*piChkno)++;
            memcpy(pstSsa->caNext2Date,pcaKey_Buf,DATE_LEN);
          }
          else {      /* Normal & Online , Don't check Next2date */
            (*piWinno)--;
            memset(caTmp_Buf,'\0',80);
            memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
	    sprintf(caShowBuf,"business day check error!!%8s",D_String(caTmp_Buf));
            ShowMsg(pstMenu,23,20,caShowBuf);
            EmsShowData('0',caShowBuf);
	    Beep();
          }
        }
        else  {
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
          lDateCore  = atol(caTmp_Buf);
          lDateInput = atol(pcaKey_Buf);
          if (lDateInput > lDateCore) {
            memcpy(pstSsa->caNext2Date,pcaKey_Buf,DATE_LEN);
            (*piChkno)++;
          }
          else  {
            (*piWinno)--;
            memset(caTmp_Buf,'\0',80);
            memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
	    sprintf(caShowBuf,"next next business day should not small than %8s",D_String(caTmp_Buf));
            ShowMsg(pstMenu,23,20,caShowBuf);
	    Beep();
          }
        }
	break;
/*--------------------- nonuseful following... ----------------------------*/
    }  /* FOR switch(...)  */
  }
  else {
    /* Abnormal Begin,Check business days in CWA */
    switch((*piWinno)) {
      case 0: /* first time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caTxnDate,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caTxnDate[0]),8);
	  sprintf(caShowBuf,"calendar day check error!!%s",D_String(caTmp_Buf));
          ShowMsg(pstMenu,23,20,caShowBuf);
	  Beep();
        }
        break;
/*--------------------- nonuseful following... ----------------------------*/
      case 1: /* second time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caNextDate,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
	  sprintf(caShowBuf,"business day check error!!%8s",D_String(caTmp_Buf));
          ShowMsg(pstMenu,23,20,caShowBuf);
	  Beep();
        }
        break;
      case 2: /* third  time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caNext2Date,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caNext2Date[0]),8);
	  sprintf(caShowBuf,"business day check error!!%8s",D_String(caTmp_Buf));
          ShowMsg(pstMenu,23,20,caShowBuf);
	  Beep();
        }
	break;
/*--------------------- nonuseful following... ----------------------------*/
    }  /* FOR switch(...)  */
  }  /* FOR if( !(cStatus.....))  */

  return(0);
}
#endif
/* ----------End for the new function for business day input -----      */
/* ******************************************************************** */

#ifndef CURSES
int
Date_Valid(pcaDate_List)
char  *pcaDate_List ;
{
   /*  this procedure perform a date validation.                     */
       char   caShowBuf[80];
       char   caBaseYear[5];
       char   caTmpYear[4];
       int  iDays  ,
            iMonth ,
            iYear  ;
       int  i;

       UCP_TRACE(P_Date_Valid);

       memcpy(caTmpYear,pcaDate_List,4); /* keep the original content */

       if (g_iBaseYear != 0) {   /* add the base year to the pcaDate_List */
         sprintf(caBaseYear,"%.4d",g_iBaseYear);
         for (i=0;i<MNTH_OFFSET;i++) {
           pcaDate_List[i] +=  (caBaseYear[i] - '0');
         }
       }
         
       iDays  = atoi(C_String(pcaDate_List + DAYS_OFFSET, 2)) ;
       iMonth = atoi(C_String(pcaDate_List + MNTH_OFFSET, 2)) ;
       iYear  = atoi(C_String(pcaDate_List + YEAR_OFFSET, 4)) ;

       if (iYear % 4 == 0 && iYear % 100 != 0 || iYear % 400 == 0)
         iaMax_Days[2]=29;       /* this iYear is leap iYear.             */

       if (strlen(pcaDate_List) == 8  &&
           iMonth >=1 && iMonth <= 12 &&
           iDays  >=1 && iDays  <= iaMax_Days[iMonth]) {
         memcpy(pcaDate_List,caTmpYear,4); /* keep the original content */
         UCP_TRACE_END(TRUE);
       }
       else {
         sprintf (caShowBuf,
                  "Invalid operation date: [%s]\n",
                  D_String(pcaDate_List) ) ;     
         ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
         EmsShowData('0',caShowBuf);
	 Beep();
         memcpy(pcaDate_List,caTmpYear,4); /* keep the original content */
         UCP_TRACE_END(FALSE);
       }

}
#else
int
Date_Valid(pcaDate_List,pstMenu)
char  *pcaDate_List ;
struct stMenu *pstMenu;
{
   /*  this procedure perform a date validation.                     */
       char   caShowBuf[80];
       char   caBaseYear[5];
       char   caTmpYear[4];
       int  iDays  ,
            iMonth ,
            iYear  ;
       int  i;

       UCP_TRACE(P_Date_Valid);

       memcpy(caTmpYear,pcaDate_List,4); /* keep the original content */

       if (g_iBaseYear != 0) {   /* add the base year to the pcaDate_List */
         sprintf(caBaseYear,"%.4d",g_iBaseYear);
         for (i=0;i<MNTH_OFFSET;i++) {
           pcaDate_List[i] +=  (caBaseYear[i] - '0');
         }
       }

       iDays  = atoi(C_String(pcaDate_List + DAYS_OFFSET, 2)) ;
       iMonth = atoi(C_String(pcaDate_List + MNTH_OFFSET, 2)) ;
       iYear  = atoi(C_String(pcaDate_List + YEAR_OFFSET, 4)) ;

       if (iYear % 4 == 0 && iYear % 100 != 0 || iYear % 400 == 0)
         iaMax_Days[2]=29;       /* this iYear is leap iYear.             */

       if (strlen(pcaDate_List) == 8  &&
           iMonth >=1 && iMonth <= 12 &&
           iDays  >=1 && iDays  <= iaMax_Days[iMonth]) {
         memcpy(pcaDate_List,caTmpYear,4); /* keep the original content */
         UCP_TRACE_END(TRUE);
       }
       else {
         sprintf (caShowBuf,
                  "Invalid operation date: [%s]\n",
                  D_String(pcaDate_List) );  
         ShowMsg(pstMenu,23,20,caShowBuf);
	 Beep();
         memcpy(pcaDate_List,caTmpYear,4); /* keep the original content */
         UCP_TRACE_END(FALSE);
       }

}
#endif

char 
*D_String(pcaDate_List)
char  *pcaDate_List ;
{
   /*  this procedure pack date string into date representation form */
    int    iZeroCnt,i;
    static char   caDate_String[11];

    UCP_TRACE(P_D_String);     

    iZeroCnt = 0;
    memset(&caDate_String,'/',10);
    caDate_String[10] = '\0';
    for (i=0;i<MNTH_OFFSET;i++) { /* check the year is west or east year */
      if (pcaDate_List[i] != '0') { /* break out the loop when meet the first */
        break;                      /* non-zero character */
      }
      else {
        iZeroCnt++;
      }
    }

    /* pcaDate_List is always the format YYYYMMDD    */
    strncpy(caDate_String,pcaDate_List+YEAR_OFFSET+iZeroCnt,4-iZeroCnt);
    strncpy(&caDate_String[5-iZeroCnt],pcaDate_List+MNTH_OFFSET,2);
    strncpy(&caDate_String[8-iZeroCnt],pcaDate_List+DAYS_OFFSET,2);
    caDate_String[10-iZeroCnt] = '\0';

    UCP_TRACE_END(caDate_String);
}

char
*C_String(pcaChar_List,iN_char)
char  *pcaChar_List ;
int   iN_char     ;                        
{
   /*  this procedure can pack character at most 12 chars.           */
   static char  scaChar_String[14] ;

   UCP_TRACE(P_C_String);

   if (iN_char <= 12) {
      strncpy(scaChar_String,pcaChar_List,iN_char) ;
      scaChar_String[iN_char] = '\0' ;
   }

   UCP_TRACE_END(scaChar_String) ;
}

Beep()
{
  EmsShowData('0',"\a\a\a");
}

#define  UNDEFINED_TERM  -4

int
FindBit(pstTmArea)
struct  TermArea  *pstTmArea;
{
  char   *pcaBitTbl;
  struct CwaCtl stCwaCtl;
  struct TermArea  stTermArea;
  struct BrhArea   stBrhArea;
  int    iTotBrhCnt,i;
  int    iOffset,iBrhOffset;
  int    iRc;
  char   caTtyStr[14];

  UCP_TRACE(P_FindBit);

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_BIT_START;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcaBitTbl);
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }

  iRc = GetDevHostName(caTtyStr);
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }
  if (caTtyStr[13] != '\0')  caTtyStr[13] = '\0';

  memcpy(&iTotBrhCnt,pcaBitTbl,4);
  iBrhOffset = 8;

  do  {
    memcpy(&stBrhArea,pcaBitTbl+iBrhOffset,sizeof(struct BrhArea));
    iOffset = stBrhArea.iTermOffset;
    /*
    sprintf (g_caMsg, "TCC: pcaBitTbl:%p  iBrhOffset:%d  iOffset:%d",
             pcaBitTbl, iBrhOffset, iOffset);
    ErrLog (10, g_caMsg, RPT_TO_LOG, 0, 0);
    */
    while (iOffset != -1)  {
      memcpy(&stTermArea,pcaBitTbl+iOffset,sizeof(struct TermArea));
      /*
      sprintf (g_caMsg, "TCC: caTtyStr:[%s]  caLogicId:[%s]  iOffset:%d", 
               caTtyStr, stTermArea.caLogicId, iOffset);
      ErrLog (10, g_caMsg, RPT_TO_LOG, 0, 0);
      */
      if (strcmp(caTtyStr,stTermArea.caLogicId)== 0) {
        memcpy(pstTmArea,&stTermArea,sizeof(struct TermArea));
        UCP_TRACE_END(0);
      }
      else  {
        iOffset = stTermArea.iNxtTmOffset;
      }
    }

    iBrhOffset = stBrhArea.iNxtBrhOffset;
  } while(iBrhOffset != -1);  
  
  if ((iOffset == -1)&&(iBrhOffset == -1))  {
    sprintf(g_caMsg,"FindBit:can't find terminal data [%s]",caTtyStr);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(FIND_BIT_ERR);
  }

}

ShowRestInfo(int iOpMode)
{
   int  i,iRc;
   char caShowBuf[80];
   int  iMDA_Size;
 
   i=0;
   while( strlen(g_caIfVerName[i]) != 0)  {
     EmsShowData('0',g_caIfVerName[i]);
     EmsShowData('0',"\n");
     i++;
   }

   sprintf (g_caMsg,
     "MDA Size:[%d]=CfgTbl Size:[%d]+ChronTbl Size:[%d]+FokTbl Size:[%d]",
     MDA_SHM_SIZE, CFGTBL_SIZE, CRNTBL_SIZE, FOKTBL_SIZE);
   ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);

   if (iOpMode == 0) {
     for (i=0; i<gs_iMaxLoadCfg; i++){
       sprintf (g_caMsg,
                "%d  %s  servers\n",
                MCfg(i).iFstFokNo, MCfg(i).caPrgname);
       if (MCfg(i).iFstFokNo >= MAX_FORK_PERTIME)
          return (-1);
       EmsShowData('0',g_caMsg);
     }
   } /* FOR if (iOpMode == 0) */
   return(0);

}

Filter_Wdata(pcaWdata)
char *pcaWdata;
{
  int  i,iSpaceCnt;
  char caTmpBuf[DATE_LEN];

  iSpaceCnt = 0;
  for (i=DATE_LEN-1;i>=0;i--) 
  {
    if ( (pcaWdata[i] == ' ') || (pcaWdata[i] == '\0') )
       iSpaceCnt++;
    else
    if (isdigit(pcaWdata[i]) == 0)
       return (-1);
  }
  
  if (iSpaceCnt != 0) {
    memcpy(caTmpBuf,pcaWdata,DATE_LEN-iSpaceCnt);
    memset(pcaWdata,'0',DATE_LEN);
    memcpy(&pcaWdata[iSpaceCnt],caTmpBuf,DATE_LEN-iSpaceCnt);
  } 

  return (0);
}

/* Update the Center Host's Branch TxnDate from the calendar file */
int
CallUptGetRtn()
{
  int iRc;

  UCP_TRACE(P_CallUptGetRtn);

    iRc = UptTxnDate();
    switch (iRc) {
      case 0:
        break;
      case -1:
        EmsShowData('0',"There's a branch code not existing in calendarfile\n");
        UCP_TRACE_END(NOSUCH_BRHID_ERR);  
      case -2:
        EmsShowData('0',"The startdate of one of the branchs is illegal\n");
        UCP_TRACE_END(ILL_STARTDATE_ERR);  
      case -3:
        EmsShowData('0',"The txndate is over the calendar file's definition\n");
        UCP_TRACE_END(TXNDATE_OVERFLOW_ERR);  
      case -4:
        EmsShowData('0',"Calander File doesn't exist!!\n");
        UCP_TRACE_END(CALFILE_NOEXIST_ERR);  
      case -5:
        EmsShowData('0',"Calander File read error!!\n");
        UCP_TRACE_END(READ_CALFILE_ERR);  
      case -6:
        EmsShowData('0',"Other unknown error!!\n");
        UCP_TRACE_END(UNKNOWN_CAL_ERR);  
      case -7:
        EmsShowData('0',"Execute Successfully!But the calendar file in \n");
        EmsShowData('0',"one of the Branchs will be not enough to use soon\n"); 
        EmsShowData('0',"please produce the next year's calendar file ASAP\n");
        EmsShowData('0',"Press Any Key to continue...     \n ");
        EmsShowData('0',"--------------------------------------------------\n");
        getchar();
        iRc = 0;
        break;
      case -8:
        EmsShowData('0',"Unknown return code,please check...\n");
        UCP_TRACE_END(UNKNOWN_RTNCODE_ERR);  
    } /* FOR switch (iRc) */

    UCP_TRACE_END(0);
}

#define  NO_SUCH_BRHCODE       -1
#define  STARTDATE_ILLIGAL     -2
#define  OVERFLOW_DATE         -3
#define  CALFILE_NOEXIST       -4
#define  CALFILE_READ_ERR      -5
#define  OTHER_ERR             -6
#define  LESS_30               -7
#define  RETURN_CODE_ERR       -8

/* Update the Center Host's or Branch's TxnDate from the calendar file */
int
UptTxnDate()
{
  int    iRc;
  int    iLess30 = 0;
  struct CwaCtl stCwaCtl;
  struct BrhArea   stBrhArea;
  struct SSA *pstSsa;
  struct parASDAYIN1 stPara;
  char   *pcaBitTbl;
  char   *pcaBrhBgAddr;
  char   cRc;
  short  sStatus;       /* the system status  */
  int    iBrhOffset;
  char   caTmpDate[8];
  int    iTmpDate;
 
  UCP_TRACE(P_UptTxnDate);

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);
  if (iRc != 0) {
    UCP_TRACE_END(GET_SSA_PTR_ERR);
  }

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_BIT_START;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcaBitTbl);
  if (iRc != 0) {
    UCP_TRACE_END(GET_BIT_PTR_ERR);
  }

  sStatus =  pstSsa->sSysStatus;
/*  4 bytes reserved for Branch Total Cnt    */
/*  4 bytes reserved for next available addr */  
  pcaBrhBgAddr = pcaBitTbl + 8; 
  memcpy(&stBrhArea,pcaBrhBgAddr,sizeof(struct BrhArea));

  do {
    memcpy(stPara.caBrCode,stBrhArea.caBrhId,10);
    /*  use the tpe open day as the start date  */
    /*  it's not necessary to be a business day */ 
    memcpy(caTmpDate,pstSsa->caTxnDate,4);
    caTmpDate[4] = '\0';
    iTmpDate = atoi(caTmpDate) + g_iBaseYear;
    sprintf(caTmpDate,"%.4d",iTmpDate);
    memcpy(caTmpDate+4,pstSsa->caTxnDate+4,4);
    memcpy(stPara.caStartDate,caTmpDate,8);

    /* call the interface to get the content of the calendar file */
    ASDAYIN1(&stPara);  
    cRc = stPara.cReturn;
    switch (cRc) {
      case '0': 
      case '7': 
        if (cRc == '7'){
          iLess30 = 1;
        }
        /* following is processing the chinese year or the centenary year */
        memcpy(caTmpDate,stPara.caStartDate,4);
        caTmpDate[4] = '\0';
        iTmpDate = atoi(caTmpDate) - g_iBaseYear;
        sprintf(caTmpDate,"%.4d",iTmpDate);
        memcpy(caTmpDate+4,stPara.caStartDate+4,4);
        memcpy(stBrhArea.caTxnDate,caTmpDate,8);

        memcpy(caTmpDate,stPara.caNextDate,4);
        caTmpDate[4] = '\0';
        iTmpDate = atoi(caTmpDate) - g_iBaseYear;
        sprintf(caTmpDate,"%.4d",iTmpDate);
        memcpy(caTmpDate+4,stPara.caNextDate+4,4);
        memcpy(stBrhArea.caNxtTxnDate,caTmpDate,8);

        memcpy(caTmpDate,stPara.caNNextDate,4);
        caTmpDate[4] = '\0';
        iTmpDate = atoi(caTmpDate) - g_iBaseYear;
        sprintf(caTmpDate,"%.4d",iTmpDate);
        memcpy(caTmpDate+4,stPara.caNNextDate+4,4);
        memcpy(stBrhArea.caNNxtTxnDate,caTmpDate,8);
        break;
      case '1': 
        ErrLog(100,"<EMS> Dump ASDAYIN1 stPara : ",RPT_TO_LOG,&stPara,
                                         sizeof(struct parASDAYIN1));
        UCP_TRACE_END(NO_SUCH_BRHCODE);
      case '2': 
        UCP_TRACE_END(STARTDATE_ILLIGAL);
      case '3': 
        UCP_TRACE_END(OVERFLOW_DATE);
      case '4': 
        UCP_TRACE_END(CALFILE_NOEXIST);
      case '5': 
        UCP_TRACE_END(CALFILE_READ_ERR);
      case '6': 
        UCP_TRACE_END(OTHER_ERR);
      default:
        UCP_TRACE_END(RETURN_CODE_ERR);
    }
    memcpy(pcaBrhBgAddr,&stBrhArea,sizeof(struct BrhArea));
    pcaBrhBgAddr = pcaBitTbl + stBrhArea.iNxtBrhOffset;
    iBrhOffset = stBrhArea.iNxtBrhOffset;
    memcpy(&stBrhArea,pcaBrhBgAddr,sizeof(struct BrhArea));
  } while (iBrhOffset != -1) ;  /* not the last Brance node */

  if (iLess30 == 0) {
    UCP_TRACE_END(0);
  }
  else {
    UCP_TRACE_END(LESS_30);
  }

}

int 
GetNextBusiDate(pcaDate,pcaNxtDate)
char  *pcaDate;
char  *pcaNxtDate;
{
  int    iRc;
  int    iLess30 = 0;
  struct CwaCtl stCwaCtl;
  struct BrhArea   stBrhArea;
  struct SSA *pstSsa;
  struct parASDAYIN1 stPara;
  char   *pcaBitTbl;
  char   *pcaBrhBgAddr;
  char   cRc;
  short  sStatus;       /* the system status  */
  int    iBrhOffset;
  char   caTmpDate[8];
  int    iTmpDate;
 
  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_BIT_START;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcaBitTbl);
  if (iRc != 0) {
    return(GET_BIT_PTR_ERR);
  }
/*  4 bytes reserved for Branch Total Cnt    */
/*  4 bytes reserved for next available addr */  
  pcaBrhBgAddr = pcaBitTbl + 8; 
  memcpy(&stBrhArea,pcaBrhBgAddr,sizeof(struct BrhArea));

  memcpy(stPara.caBrCode,stBrhArea.caBrhId,10);
  /*  use the input day as the start date  */
  memcpy(caTmpDate,pcaDate,4);
  caTmpDate[4] = '\0';
  iTmpDate = atoi(caTmpDate) + g_iBaseYear;
  sprintf(caTmpDate,"%.4d",iTmpDate);
  memcpy(caTmpDate+4,pcaDate+4,4);
  memcpy(stPara.caStartDate,caTmpDate,8);

  /* call the interface to get the content of the calendar file */
  ASDAYIN1(&stPara);  
  cRc = stPara.cReturn;
  switch (cRc) {
    case '0': 
    case '7': 
      if (cRc == '7'){
        iLess30 = 1;
      }
      memcpy(caTmpDate,stPara.caNextDate,4);
      caTmpDate[4] = '\0';
      iTmpDate = atoi(caTmpDate) - g_iBaseYear;
      sprintf(caTmpDate,"%.4d",iTmpDate);
      memcpy(caTmpDate+4,stPara.caNextDate+4,4);
      /*
      sprintf (g_caMsg,"<EMS> NextTxnDate [%.8s] for branch [%s]",
               caTmpDate, stPara.caBrCode);
      ErrLog (10, g_caMsg, RPT_TO_LOG, 0, 0);
      */
      memcpy(pcaNxtDate,caTmpDate,8);
      return(0);
    case '1': 
      return(NO_SUCH_BRHCODE);
    case '2': 
      return(STARTDATE_ILLIGAL);
    case '3': 
      return(OVERFLOW_DATE);
    case '4': 
      return(CALFILE_NOEXIST);
    case '5': 
      return(CALFILE_READ_ERR);
    case '6': 
      return(OTHER_ERR);
    default:
      return(RETURN_CODE_ERR);
  }

  if (iLess30 == 0) {
    return(0);
  }
  else {
    return(LESS_30);
  }


}


int Check_Busi_Date (caKey_Buf)
char *caKey_Buf;
{
  int    i, iRc, cRc;
  char   *pcaBitTbl, *pcaBrhBgAddr, caTmpDate[10], caBaseYear[5];
  struct CwaCtl   stCwaCtl;
  struct BrhArea  stBrhArea;
  struct parASDAYIN3  stPara;

  memset (caTmpDate, 0, sizeof(caTmpDate));
  memset (caBaseYear, 0, sizeof(caBaseYear));
  memcpy(caTmpDate, caKey_Buf, 8);

  if (g_iBaseYear != 0) {   /* add the base year to the pcaDate_List */
    sprintf(caBaseYear,"%.4d",g_iBaseYear);
    for (i=0;i<MNTH_OFFSET;i++) {
      caTmpDate[i] +=  (caBaseYear[i] - '0');
    }
  }

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_BIT_START;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcaBitTbl);
  if (iRc != 0) {
    return(GET_BIT_PTR_ERR);
  }
  pcaBrhBgAddr = pcaBitTbl + 8;
  memcpy (&stBrhArea,pcaBrhBgAddr,sizeof(struct BrhArea));
  memcpy (stPara.caBrCode,stBrhArea.caBrhId,10);
  memcpy (stPara.caStartDate, caTmpDate, 8);

  ASDAYIN3 (&stPara);
  cRc = stPara.cReturn;
  if (cRc == '0')
  {
     if (stPara.cIsBusDate == '0')
     {
        sprintf (g_caMsg,
                 "<EMS> The date[%s] is a business date", caKey_Buf);
        ErrLog (10, g_caMsg, RPT_TO_LOG, 0, 0);
        return (0);
     }
     else
     {
        sprintf (g_caMsg,
                 "<EMS> The date[%s] is a non-business date", caKey_Buf);
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        return (NONBUSI_DATE_ERR);
     }
  }
  else
  {
     sprintf (g_caMsg, "<EMS> Failure to get the calendar date [%s]",
              caKey_Buf);
     ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
  }

  return (NONBUSI_DATE_ERR);
}

