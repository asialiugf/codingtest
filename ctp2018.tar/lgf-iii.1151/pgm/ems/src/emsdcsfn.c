/* ���Ҳլ��ʷ��{���M��,�����Ӧ�Forked Server�Ǧ^�����A,�ζǰe���G������{�� */ 
/* �N�� Dcs �]�����K�����e�禡  					     */
/*                                          EmsGetInput()		     */
/*  [Control Process] <--------- [Monitor] <----------- [Forked Servers]     */
/* 		      EmsDataSend()					     */	
/* ------------------------- INCLUDE FILES ---------------------------- */
#include <curses.h>
#include "errlog.h"
#include "dcs.h"
#include "emcpgdef.h"
#include "cwa.h"
#include "emctool.h"
#include "emctcwa.h"
#include "emctbit.h"

/* ------------------------- CONSTANT DEFINITION ---------------------- */

/* define error message code */
#define  RECEIVE_CMD_ERR  -1
#define  SEND_CMD_ERR     -2
#define  DISCONNECT_ERR   -3
#define  SYSTEM_RESTART   0x4000 /* 1:restarted ; 0:Normal Begin */
#define  IS_OVER_TIME     0x0800 /* 1:Overtime  ; 0:NotOvertime  */
#define  ONLINE_CLOSE     0x0400 /* 1:Batch ; 0:On_line          */
#define  OPERATE_ERR      -1
#define  SEND_SIF_ERR     -2
#define  RCV_SOF_ERR      -3

#define  PROTOCOL_TYPE    "III_PROTOCOL"
#define  QUEUE_DCS        'Q'
#define  MONITOR_HOST     "00Monitor1"
#define  GET_FORK_STATUS  "00Monitor2"
#define  DEST_NAME_LEN    10

#define  SOF_HEAD_LEN     17
#define  BR_CODE_OFFSET   3
#define  TM_CODE_OFFSET   6 
#define  MSG_CODE_OFFSET  9
#define  CTL_CODE_OFFSET  14
#define  BR_CODE_LEN      3
#define  TM_CODE_LEN      2 
#define  MSG_CODE_LEN     4

/* ------------------------- VARIABLE DECLARATION --------------------- */

struct DcsBuf stDcsBuf;	/* call dcs module struct globl */
struct DcsSiof stDcsSiof;	/* call dcs module input/output struct globl */
char   g_cProtType = '\0';
int    g_iSessidx;
static char g_cProtocoltype = '\0';
int Disconnect(int iSessidx,char cProtocolType);

/*
 *&N& ROUTINE NAME:EmsGetInput()
 *&A& ARGUMENTS:
 *&A&    NAME         TYPE            DESCRIPTION
 *&A& -------------  ------  -------------------------------
 *&A&  pcInputData    char*   �����ѿ�X�J�Ҳհe�ӿ�J�����
 *&A&
 *&R& RETURN VALUE(S):
 *&R&  0 : ������J��ƪ�����
 *&R& -1 : ������J��ƥ���
 *&R&
 *&D& DESCRIPTION
 *&D& �ھڳq�T��w�����ܼ�( �t��_PROTOCOL ) 
 *&D& �I�s�����A�ȵ{�������� EMS FORK �_�Ӧ��A���Ǧ^�����A
 *&D&
 */

int
EmsGetInput(paInputData)
char *paInputData;
{
  char caProtoType[80];  /* enviroment variable buffer */
  struct DcsBuf stDcsBuf;
  struct DcsSiof stDcsSiof;
  int    iSessidx;
  int    iRc;
  static int entercnt=1;

  UCP_TRACE( P_EmsGetInput );

  if (g_cProtocoltype == '\0') {
    memset (caProtoType, '\0', 80);
    strcpy (caProtoType, (char *)getenv( PROTOCOL_TYPE ));
    if (caProtoType[0] != '\0') {
      g_cProtocoltype = caProtoType[0];
    }
    else {
      g_cProtocoltype = QUEUE_DCS;
    }
  }

  MpstDcsSiof(stDcsBuf) = &stDcsSiof;
  memcpy (McaDesCode(stDcsBuf), GET_FORK_STATUS, DEST_NAME_LEN);
  McRqstCode(stDcsBuf) = DCSACCEPTREAD;
/*
  MlWaiTime(stDcsBuf) = DCS_BLOCK;
*/
  MlWaiTime(stDcsBuf) = 35;
  MiDataLen(stDcsBuf) = DCS_MAX_DATA_LEN;
  McProto(stDcsBuf) = g_cProtocoltype;

  DcsDispatch( &stDcsBuf );

  if (MiReply(stDcsBuf) != DCS_NORMAL) {
    sprintf( g_caMsg, "<EMS> Failure to read data from TPU! reply=%d",
             MiReply(stDcsBuf) );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( RECEIVE_CMD_ERR, g_caMsg );
    UCP_TRACE_END( RECEIVE_CMD_ERR );
  }

  iSessidx = MiSesIdx(stDcsBuf);
  entercnt++;

  iRc = Disconnect(iSessidx,g_cProtocoltype);
  if (iRc < 0) {
    sprintf( g_caMsg, "<EMS> Failure to disconnect with TPU!");
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( DISCONNECT_ERR );
  }

  memcpy(paInputData, McaData(stDcsBuf), MiDataLen(stDcsBuf)-8);

  UCP_TRACE_END( MiDataLen(stDcsBuf) - 8 );
}


/*
 *&N& ROUTINE NAME:EmsDataSend()
 *&A& ARGUMENTS:
 *&A&    NAME         TYPE            DESCRIPTION
 *&A& -------------  ------  -------------------------------
 *&A&
 *&R& RETURN VALUE(S):
 *&R&  0 : ������J��Ʀ��\
 *&R& SEND_CMD_ERR : ������J��ƥ���
 *&R&
 *&D& DESCRIPTION
 *&D& �ھڳq�T��w�����ܼ�( �t��_PROTOCOL ) 
 *&D& �I�s�����A�ȵ{���e�X EMS ����R�O�����G
 *&D&
 */
int
EmsDataSend(iDataLen, caData, cMoreData,iSessIdx)
int iDataLen;
char *caData;
char cMoreData;
int  iSessIdx;
{
  char caProtoType[80];  /* enviroment variable buffer */
  static struct DcsBuf stDcsBuf;
  static struct DcsSiof stDcsSiof;

  UCP_TRACE( P_EmsDataSend );

  memset(&stDcsBuf,0,sizeof(struct DcsBuf));
  memset(&stDcsSiof,0,sizeof(struct DcsSiof));

  if (g_cProtocoltype == '\0') {
    memset(caProtoType, '\0', 80);
    strcpy(caProtoType, (char *)getenv( PROTOCOL_TYPE ));
    if (caProtoType[0] != '\0') {
      g_cProtocoltype = caProtoType[0];
    }
    else {
      g_cProtocoltype = QUEUE_DCS;
    }
  } 

  MpstDcsSiof(stDcsBuf) = &stDcsSiof;
  McMoreByte(stDcsBuf) = cMoreData;
  memcpy(McaDesCode(stDcsBuf), MONITOR_HOST, DEST_NAME_LEN);

  if (cMoreData != '1') {
    McRqstCode(stDcsBuf) = DCSWRDISCONECT;
  }
  else {
    McRqstCode(stDcsBuf) = DCSWRITE;
  }

  memcpy(McaData(stDcsBuf), caData, iDataLen);
  MlWaiTime(stDcsBuf) = DCS_BLOCK;
  sprintf(McaDataLen(stDcsBuf),"%.4d",iDataLen + 8);
  MiDataLen(stDcsBuf) = iDataLen + 8;
  McProto(stDcsBuf) = g_cProtocoltype;
  MiSesIdx(stDcsBuf) = iSessIdx ;

  DcsDispatch( &stDcsBuf );

  if (MiReply(stDcsBuf) != DCS_NORMAL) {
    sprintf (g_caMsg, "<EMS> Failure to send data to TPU! (iRc:%d)",
             MiReply(stDcsBuf));
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt (SEND_CMD_ERR, g_caMsg);
    UCP_TRACE_END (SEND_CMD_ERR);
  }
  
  UCP_TRACE_END( 0 );
}


int
Disconnect(int iSessidx,char cProtocolType)
{
  static struct DcsBuf stDcsBuf;
  static struct DcsSiof stDcsSiof;

  McRqstCode(stDcsBuf) = DCSDISCONNECT;
  McProto(stDcsBuf) = cProtocolType;
  MiSesIdx(stDcsBuf) = iSessidx;
  MiDataLen(stDcsBuf) = 0;
  DcsDispatch(&stDcsBuf);
  if(MiReply(stDcsBuf) != DCS_NORMAL){
    sprintf(g_caMsg,
            "<EMS> Failure to disconnect EMS! (reply:%d errno:%d)",
            MiReply(stDcsBuf), MiErrno(stDcsBuf));
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    return (-1);
  }
  
  return(0);
}

#define  DISPLAY   '0'
#define  COMMAND   '1'

/*
 *&N& ROUTINE NAME:EmsShowData()
 *&A& ARGUMENTS:
 *&A&    NAME         TYPE            DESCRIPTION
 *&A& -------------  ------  -------------------------------
 *&A&  pcaData       char *    ����ܪ��r��
 *&A&
 *&R& RETURN VALUE(S):
 *&R&  0 : ��ܶǤJ��Ʀ��\
 *&R&
 *&D& DESCRIPTION
 *&D& �ھڳq�T��w�����ܼ�( �t��_PROTOCOL ) 
 *&D& �I�s�����A�ȵ{���e�X EMS ����ܪ��r��
 *&D&
 */
int
EmsShowData(cOp,pcaData)
char  cOp;
char  *pcaData;
{
    switch(cOp) {
      case DISPLAY:
        printf("%s",pcaData);
        return(0);
      case COMMAND:
        system(pcaData);
        return(0);
    }
        
}


SendCmdToMon(struct MonCmd *stCmd,int iLevel)
{
  int  iLen;
  char caTmpBuf[20];

  /* initial dcs_buf & DcsSiof */
  memset(&stDcsSiof,0x00,sizeof(struct DcsSiof));
  memset(&stDcsBuf,0x00,sizeof(struct DcsBuf));
  memcpy(McaDesCode(stDcsBuf), MONITOR_HOST, DEST_NAME_LEN);
  memcpy(McaServCode(stDcsBuf),MON_TXN_CODE,4);
  MpstDcsSiof(stDcsBuf) = &stDcsSiof;
  iLen=sizeof(struct MonCmd);

  memcpy(McaData(stDcsBuf),stCmd,iLen);
  McRqstCode(stDcsBuf) = DCSCONNECTWRITE;
  McProto(stDcsBuf) = QUEUE_DCS;
  MiDataLen(stDcsBuf) = iLen+8;
  McKind(stDcsBuf) = 'A';
  sprintf(caTmpBuf,"%5d",iLen);
  caTmpBuf[5] = '\0';
  memcpy(McaDataLen(stDcsBuf),caTmpBuf,5);
  DcsDispatch(&stDcsBuf);
  g_iSessidx = MiSesIdx(stDcsBuf);
  if(MiReply(stDcsBuf) != DCS_NORMAL){
     sprintf(g_caMsg, 
             "<EMS> Failure to send data to EMS monitor! (reply:%d errno:%d)", 
             MiReply(stDcsBuf), MiErrno(stDcsBuf));
     ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
  }

  McMoreByte(stDcsBuf) = '1';
  EndRtn(&stDcsBuf,g_iSessidx,iLevel);
}

/*--------------------------------------------------------------------------*/
/* end routing                                                              */
/*--------------------------------------------------------------------------*/
EndRtn(dcs_buf,iSessidx,iLevel)
struct DcsBuf *dcs_buf;
int iSessidx;
int iLevel;
{
  int i;
  int iRcvDataLen;
  struct FkdStat stFkdStat; /* monitor rtn the forked process's status  */
  char caPrcSta[20], caMonErr[25];

  /* a dummy receive */
  i=0;
  while((PcMoreByte(dcs_buf) == '1') && (i++ < 5)){
    PcRqstCode(dcs_buf) = DCSREAD;
    /* TCC
    PlWaiTime(dcs_buf) = 10; *//* emmcntl dummy receive time out is 10 sec */
    PlWaiTime(dcs_buf) = 35; /* emmcntl dummy receive time out is 10 sec */
    PiDataLen(dcs_buf) = 1024;
    PcProto(dcs_buf) = QUEUE_DCS;
    PiSesIdx(dcs_buf) = iSessidx;
    DcsDispatch(dcs_buf);
    if(PiReply(dcs_buf) != DCS_NORMAL){
       sprintf(g_caMsg,"<EMS> i=%d DCSREAD error reply %d errno %d",
       i,PiReply(dcs_buf),PiErrno(dcs_buf));
       ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    }
    else {
      PcMoreByte(dcs_buf) == '0';
    }
  }  /* FOR while((PcMore..))  */

  iRcvDataLen= MiDataLen(stDcsBuf) - 8 ;
  if(iRcvDataLen > sizeof(struct FkdStat)){
    sprintf(g_caMsg,"<EMS> EndRtn:rcv fkd data reply %d errno %d",
            MiReply(stDcsBuf),MiErrno(stDcsBuf));
    ErrLog(1000,g_caMsg,RPT_TO_LOG,McaData(stDcsBuf),iRcvDataLen);
    return (MON_CMD_ERR);
  }

  memcpy(stFkdStat.caTblidx,McaData(stDcsBuf),5);
  stFkdStat.cStatus = McaData(stDcsBuf)[5];

   /* Show this message only when in the control menu */
   /* No show in the SSA or BIT maintain screen       */

  if (iLevel == 1) {
    if (stFkdStat.cStatus == 0) {
      printf("\n EXECUTE COMMAND OK!!!\n");
      printf("\n Press Any Key To Continue!!!\n");
      getchar();
    }
    else  {
      printf("\n EXECUTE COMMAND error!!! status = %s\n",caMonErr);
      printf("\n Press Any Key To Continue!!!\n");
      getchar();
      exit(-1);
    }
  }

  /* receive server response */
  PcRqstCode(dcs_buf) = DCSDISCONNECT;
  PcProto(dcs_buf) = QUEUE_DCS;
  PiSesIdx(dcs_buf) = g_iSessidx;
  PiDataLen(dcs_buf) = 0;
  DcsDispatch(dcs_buf);
  if(PiReply(dcs_buf) != DCS_NORMAL){
    sprintf(g_caMsg,"emmcntl:EndRtn DCSDISCONNECT error reply %d errno %d",
                                    PiReply(dcs_buf),PiErrno(dcs_buf));
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
  }
}

int 
GetInfoFmEms(cOp,cSeg,pcaData)
char cOp;
char cSeg;
char *pcaData;
{
  int  iRc; 
  struct  SSA      stSsaArea;
  struct  BrhArea  stBrhArea;
  struct  TermArea stTrmArea;
  char caStatus[2];
  short sStatus;

  switch(cSeg) {
    case  CWA_SSA:
      if (cOp == RETRIEVE) {
        iRc = PrepareSif(cSeg,cOp,&stSsaArea,caStatus);
        if (iRc < 0) {
          sprintf(g_caMsg,"GetInfoFmEms:prepare SIF err=%d",iRc);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          return(OPERATE_ERR);
        }
        memcpy(&sStatus,caStatus,2);
        if (sStatus == 0) {
          memcpy(pcaData,&stSsaArea,sizeof(struct SSA));
        }
        else  {
          sprintf(g_caMsg,"GetInfoFmEms:retrieve err=%d",sStatus);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          return(sStatus);
        }
      } /* FOR if (cOp == RETRIEVE) */
      else if (cOp == UPDATE) {
        memcpy(&stSsaArea,pcaData,sizeof(struct SSA));
        iRc = PrepareSif(cSeg,cOp,&stSsaArea,caStatus);
        if (iRc < 0) {
          sprintf(g_caMsg,"GetInfoFmEms:prepare SIF err=%d",iRc);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          return(OPERATE_ERR);
        }
        memcpy(&sStatus,caStatus,2);
        iRc = (int) sStatus;
        return(iRc);
      }
      break;
    case  BIT_BRH:
      switch(cOp) {
        case RETRIEVE:
          iRc = PrepareSif(cSeg,cOp,pcaData,caStatus);
          if (iRc < 0) {
            sprintf(g_caMsg,"GetInfoFmEms:prepare SIF err=%d",iRc);
            ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
            return(OPERATE_ERR);
          }
          memcpy(&sStatus,caStatus,2);
          if (sStatus == 0) {
          }
          else  {
            sprintf(g_caMsg,"GetInfoFmEms:retrieve err=%d",sStatus);
            ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
            return(sStatus);
          }
        break;
        case UPDATE:
          memcpy(&stBrhArea,pcaData,sizeof(struct BrhArea));
          iRc = PrepareSif(cSeg,cOp,&stBrhArea,caStatus);
          if (iRc < 0) {
            sprintf(g_caMsg,"GetInfoFmEms:prepare SIF err=%d",iRc);
            ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
            return(OPERATE_ERR);
          }
          memcpy(&sStatus,caStatus,2);
          iRc = (int) sStatus;
          return(iRc);
        break;
        case INSERT:
        break;
        case DELETE:
        break;
      }
      break;
    case  BIT_TRM:
      switch(cOp) {
        case RETRIEVE:
          iRc = PrepareSif(cSeg,cOp,pcaData,caStatus);
          if (iRc < 0) {
            sprintf(g_caMsg,"GetInfoFmEms:prepare SIF err=%d",iRc);
            ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
            return(OPERATE_ERR);
          }
          memcpy(&sStatus,caStatus,2);
          if (sStatus == 0) {
          }
          else  {
            sprintf(g_caMsg,"GetInfoFmEms:retrieve err=%d",sStatus);
            ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
            return(sStatus);
          }
        break;
        case UPDATE:
          memcpy(&stTrmArea,pcaData,sizeof(struct TermArea));
          iRc = PrepareSif(cSeg,cOp,&stTrmArea,caStatus);
          if (iRc < 0) {
            sprintf(g_caMsg,"GetInfoFmEms:prepare SIF err=%d",iRc);
            ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
            return(OPERATE_ERR);
          }
          memcpy(&sStatus,caStatus,2);
          iRc = (int) sStatus;
          return(iRc);
        break;
        case INSERT:
        break;
        case DELETE:
        break;
      }
      break;
    default:
      sprintf(g_caMsg,"GetInfoFmEms:the requesting Segment error!!!");
      ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
  }
  return(0);
}

int 
PrepareSif(cSeg,cOp,pcaSendStr,pcaStatus)
char  cSeg;
char  cOp;
char  *pcaSendStr;
char  *pcaStatus;
{
  struct  SifHeader  stSifHbuff;   
  struct  SofHeader  stSofHbuff;   
  short   sOffset,sOffsetBk;
  short   sLen;
  int     iLen;
  short   sStatus;
  int     iRc;
  int     iCnt, iBrhCnt, iTotBrhCnt, iStartBrh;
  char    caHdData[DCS_MAX_DATA_LEN];
  struct  TermArea  *pstTrmArea;
  
  memset (&stSifHbuff, 0, sizeof(stSifHbuff));
  memset (&stSofHbuff, 0, sizeof(stSofHbuff));
  memset (caHdData, 0, sizeof(caHdData));

  stSifHbuff.caTxnCode[0] = cOp;
  stSifHbuff.caTextId[0]  = cSeg;
  memcpy (&iStartBrh, pcaSendStr, sizeof(int));

  switch(cSeg) {
    case  CWA_SSA:
      if (cOp == RETRIEVE) {
        memcpy(caHdData,&stSifHbuff,sizeof(struct SifHeader));

        iRc = SifDataSdRv(sizeof(struct SifHeader),caHdData);
        if (iRc < 0) {
          sprintf(g_caMsg,"PrepareSif:SifDataSend err=%d",iRc);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          return(iRc);
        }  
        memcpy(&stSofHbuff,caHdData,sizeof(struct SofHeader));
        memcpy(&sLen,caHdData+sizeof(struct SofHeader),sizeof(short));
        memcpy(pcaSendStr,caHdData+sizeof(struct SofHeader)+2,sLen);
        memcpy(pcaStatus,stSofHbuff.caStatus,2);
      }
      else if (cOp == UPDATE) {
        sOffset = 0;
        memcpy(caHdData+sOffset,&stSifHbuff,sizeof(struct SifHeader));
        sOffset += sizeof(struct SifHeader);
        sLen    =  sizeof(struct SSA);
        memcpy(caHdData+sOffset,&sLen,sizeof(short));
        sOffset += sizeof(short);
        memcpy(caHdData+sOffset,pcaSendStr,sLen);
        sOffset += sizeof(struct SSA);
        iLen = (int) sOffset;
        iRc = SifDataSdRv(iLen,caHdData);
        if (iRc < 0) {
          sprintf(g_caMsg,"PrepareSif:SifDataSend err=%d",iRc);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          return(iRc);
        }  
        ErrLog(1000,"UPDATE SSA:dump caHdData",RPT_TO_LOG,caHdData,iLen);
        memcpy(&stSofHbuff,caHdData,sizeof(struct SofHeader));
        memcpy(pcaStatus,stSofHbuff.caStatus,2);
      }
      break;
    case  BIT_BRH:
      switch(cOp) {
        case RETRIEVE:
          memcpy (stSifHbuff.caFiller, &iStartBrh, sizeof(int));
          memcpy (caHdData,&stSifHbuff,sizeof(struct SifHeader));

          iRc = SifDataSdRv(sizeof(struct SifHeader),caHdData);
          if (iRc < 0) {
            sprintf(g_caMsg,"PrepareSif:SifDataSend err=%d",iRc);
            ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
            return(iRc);
          }  
          memcpy(&stSofHbuff,caHdData,sizeof(struct SofHeader));
          memcpy (&iTotBrhCnt, stSofHbuff.caBrhId, sizeof(int));
          memcpy (&iBrhCnt, stSofHbuff.caTermId, sizeof(int));
          memcpy(&sLen,caHdData+sizeof(struct SofHeader)+2,sizeof(short));

          sOffsetBk = sizeof(struct SofHeader) + 2 + 2;
          memcpy(pcaSendStr,&iTotBrhCnt,4);
          memcpy(pcaSendStr+4,&iBrhCnt,4);
          sOffset = 8;
          for (iCnt=iBrhCnt; iCnt>0; iCnt--) {
            memcpy(pcaSendStr+sOffset,caHdData+sOffsetBk,sLen);
            sOffset += sLen;
            sOffsetBk += sLen;
            memcpy(&sLen,caHdData+sOffsetBk,sizeof(short));
            sOffsetBk += 2;
          }

          memcpy(pcaStatus,stSofHbuff.caStatus,2);
          break;
        case UPDATE:
          sOffset = 0;
          memcpy(caHdData+sOffset,&stSifHbuff,sizeof(struct SifHeader));
          sOffset += sizeof(struct SifHeader);
          sLen    =  sizeof(struct BrhArea);
          memcpy(caHdData+sOffset,&sLen,sizeof(short));
          sOffset += sizeof(short);
          memcpy(caHdData+sOffset,pcaSendStr,sLen);
          sOffset += sizeof(struct BrhArea);
          iLen = (int) sOffset;
          iRc = SifDataSdRv(iLen,caHdData);
          if (iRc < 0) {
            sprintf(g_caMsg,"PrepareSif:SifDataSend err=%d",iRc);
            ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
            return(iRc);
          }  
/*
          ErrLog(1000,"UPT Branch err:dump caHdData",RPT_TO_LOG,caHdData,iLen);
*/
          memcpy(&stSofHbuff,caHdData,sizeof(struct SofHeader));
          memcpy(pcaStatus,stSofHbuff.caStatus,2);
        break;
      }
      break;
    case  BIT_TRM:
      switch(cOp) {
        case RETRIEVE:
          memcpy(stSifHbuff.caBrhId,pcaSendStr,MAX_BR_LEN);
          memcpy(caHdData,&stSifHbuff,sizeof(struct SifHeader));
          iRc = SifDataSdRv(sizeof(struct SifHeader),caHdData);
          if (iRc < 0) {
            sprintf(g_caMsg,"PrepareSif:SifDataSend err=%d",iRc);
            ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
            return(iRc);
          }  
          memcpy(&stSofHbuff,caHdData,sizeof(struct SofHeader));
/* After the sof header,there's a 2-bytes's short for total data length  */
          memcpy(&sLen,caHdData+sizeof(struct SofHeader)+2,sizeof(short));
/* the first 2 bytes is the total length, the second 2 bytes is the first */
/* Branch Area Length(it should be 64)                                    */
          sOffsetBk = sizeof(struct SofHeader) + 2 + 2;
          sOffset = 4;  /* reserverd 4 bytes for the total count */
          iCnt = 0;
          while(sLen != 99) {
            memcpy(pcaSendStr+sOffset,caHdData+sOffsetBk,sLen);
            iCnt++;
            sOffset += sLen;
            sOffsetBk += sLen;
            memcpy(&sLen,caHdData+sOffsetBk,sizeof(short));
            sOffsetBk += 2;
          }
          memcpy(pcaSendStr,&iCnt,4);
          memcpy(pcaStatus,stSofHbuff.caStatus,2);
          break;
        case UPDATE:
          pstTrmArea = (struct TermArea *) pcaSendStr;
          memcpy(stSifHbuff.caBrhId,pstTrmArea->filler,MAX_BR_LEN);
          sOffset = 0;
          memcpy(caHdData+sOffset,&stSifHbuff,sizeof(struct SifHeader));
          sOffset += sizeof(struct SifHeader);
          sLen    =  sizeof(struct TermArea);
          memcpy(caHdData+sOffset,&sLen,sizeof(short));
          sOffset += sizeof(short);
          memcpy(caHdData+sOffset,pcaSendStr,sLen);
          sOffset += sizeof(struct TermArea);
          iLen = (int) sOffset;
          iRc = SifDataSdRv(iLen,caHdData);
          if (iRc < 0) {
            sprintf(g_caMsg,"PrepareSif:SifDataSend err=%d",iRc);
            ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
            return(iRc);
          }  
          ErrLog(1000,"Update Terminal err:dump caHdData"
                 ,RPT_TO_LOG,caHdData,iLen);
          memcpy(&stSofHbuff,caHdData,sizeof(struct SofHeader));
          memcpy(pcaStatus,stSofHbuff.caStatus,2);
          break;
      }
      break;
    default:
      sprintf(g_caMsg,"PrepareSif:the requesting Segment error!!!");
      ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
  }
  return(0);
}

/*
 *&N& ROUTINE NAME:SifDataSdRv()
 *&A& ARGUMENTS:
 *&A&    NAME         TYPE            DESCRIPTION
 *&A& -------------  ------  -------------------------------
 *&A&
 *&R& RETURN VALUE(S):
 *&R&  0 : ������J��Ʀ��\
 *&R& SEND_CMD_ERR : ������J��ƥ���
 *&R&
 *&D& DESCRIPTION
 *&D&
 */
int
SifDataSdRv(iDataLen, pcaData)
int iDataLen;
char *pcaData;
{
  char caProtoType[80];  /* enviroment variable buffer */
  static struct DcsBuf stDcsBuf;
  static struct DcsSiof stDcsSiof;
  int  iSessidx;
  int  iRcvDataLen;

  memset (&stDcsBuf, 0, sizeof(struct DcsBuf));
  memset (&stDcsSiof, 0, sizeof(struct DcsSiof));

  if (g_cProtType == '\0') {
    memset(caProtoType, 0, sizeof(caProtoType));
    strcpy(caProtoType, (char *)getenv("III_PROTOCOL"));
    if (caProtoType[0] != '\0') {
      g_cProtType = caProtoType[0];
    }
    else {
      g_cProtType = QUEUE_DCS;
    }
  } 

  MpstDcsSiof(stDcsBuf) = &stDcsSiof;
  McMoreByte(stDcsBuf) = '0';
  memcpy(McaDesCode(stDcsBuf), "00000tools", DEST_NAME_LEN);
  McRqstCode(stDcsBuf) = DCSCONNECTWRITE;

  memcpy(McaData(stDcsBuf), pcaData, iDataLen);
  MlWaiTime(stDcsBuf) = DCS_BLOCK;
  MiDataLen(stDcsBuf) = iDataLen + 8;
  McProto(stDcsBuf) = g_cProtType;
  DcsDispatch( &stDcsBuf );

  if (MiReply(stDcsBuf) != DCS_NORMAL) {
    sprintf( g_caMsg,"SifDataSdRv: DcsDispatch() fails! reply=%d",
             MiReply(stDcsBuf) );
    ErrLog(4000, g_caMsg, RPT_TO_LOG, 0, 0);
    return( SEND_SIF_ERR );
  }

  iSessidx = MiSesIdx(stDcsBuf);

  McRqstCode(stDcsBuf) = DCSREAD;
    /* set the monitor rcv timeout, if mon doesn't ger ack before timeout */
    /* mon will kill the server   */
  /* TCC
  MlWaiTime(stDcsBuf) = 10;
  */
  MlWaiTime(stDcsBuf) = 35;
  MiDataLen(stDcsBuf) = DCS_MAX_DATA_LEN;
  McProto(stDcsBuf) = g_cProtType;
  MiSesIdx(stDcsBuf) = iSessidx;
  DcsDispatch(&stDcsBuf);

  if (MiReply(stDcsBuf) != DCS_NORMAL) {
    sprintf( g_caMsg,"SifDataSdRv: DcsDispatch() fails! reply=%d",
             MiReply(stDcsBuf) );
    ErrLog(4000, g_caMsg, RPT_TO_LOG, 0, 0);
    return( RCV_SOF_ERR );
  }
  iRcvDataLen= MiDataLen(stDcsBuf) - 8 ;
  if (iRcvDataLen <= sizeof(pcaData))
     memcpy(pcaData,McaData(stDcsBuf),iRcvDataLen);
  else
     memcpy(pcaData,McaData(stDcsBuf),DCS_MAX_DATA_LEN);

  /* receive server response */
  McRqstCode(stDcsBuf) = DCSDISCONNECT;
  McProto(stDcsBuf) = g_cProtType;
  MiSesIdx(stDcsBuf) = iSessidx;
  MiDataLen(stDcsBuf) = 0;
  DcsDispatch(&stDcsBuf);
  if(MiReply(stDcsBuf) != DCS_NORMAL){
    sprintf(g_caMsg,"SifDataSdRv:DCSDISCONNECT error reply %d errno %d",
                                    MiReply(stDcsBuf),MiErrno(stDcsBuf));
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
  }

  return( 0 );
}
