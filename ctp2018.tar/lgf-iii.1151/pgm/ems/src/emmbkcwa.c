
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>
#include "cwa.h"

#define  CWA_LOGFILE_NOEXIST    -1       
#define  READ_CWALOG_ERR        -2       
#define  CWA_MODNO               4       /* CWA save modulo no.            */
#define  FILE_NAME_LEN           80      /* CWA save modulo no.            */
#define  SYSTEM_STARTED 0x8000 /* 1:started ; 0:not started */
#define  SYSTEM_RESTART 0x4000 /* 1:restarted ; 0:Normal Begin */
#define  ONLINE_CLOSE   0x0400 /* 1:Batch ; 0:On_line        */
#define  SBCWA0_F     "iii/log/sbcwa0.bin"
#define  SBCWA1_F     "iii/log/sbcwa1.bin"
#define  CONFIG_FILE  "iii/etc/tbl/config.dat"
#define  CWA_SHM_KEY  "CWA_SHM_KEY"

int      g_iCwaKey;
/*
 *&N& PROGRAM NAME: emmrbcwa.c
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&           
 *&R& RETURN VALUES:
 *&R&     0  :  ���`
 *&R&           
 *&R&           
 *&D& DESCRIPTION:           
 *&D&   ���{������CWA�ɦL�����,�NCWA���t�Ϊ��A�ϸ��(SSA)��
 *&D&     �^ memory SSA ���^�_���P�_.
 *&D&   1.�}��CWA�ɦL�����(SBCWA0_F,�MSBCWA1_F),�èM�w�Ѩ��ӶɦL��Ū�J:
 *&D&     1.1 �ɦL�Ǹ���(0,1,2,3)�`��,���ɦL�Ǹ��t����Ȭ�1�h�����j�Ǹ��ɦL��.
 *&D&         ���ɦL�Ǹ��t����Ȥ���1,�h�����p�Ǹ��ɦL��.
 *&D&     1.2 ��Ū�J��ƪ��פ���  �J��ƪ�(iLoadSize)�h�H�t�@�ɦL��Ū�J,�Y���ɪ�
 *&D&         �׬Ҥ���  �J��ƪ�,�h�NCWA(InitCwa()),��BIT����(InitBit())��l��.
 *&D&   2.�I�sCwaLowCtlFac()���oCWA��SSA�ҩl��}(pstSsa),�Y���o�h���X���t�Τ���
 *&D&     ���u���A,�_�h�P�_�Y�P�W�����u���A�M�w�O�_���^�_.      
 */

main()
{
  struct CwaCtl stCwaCtl;
  struct CwaCreatIobuf stCCBuf;
  int iDumpSeqNo0,
      iDumpSeqNo1;

  int iDump0Fp,iDump1Fp,iFp;
  int iLoadSize;

  struct SSA stSsa;
  char   *pcaBitTbl;
  char caFileName[ FILE_NAME_LEN + 1 ];
  int iRc,i,iWriteFlag;
  short  sStatus;

/* Check the TPE is online or not,if TPE is online then abort. */
  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat((char *)caFileName, (char *)"/");
  strcat((char *)caFileName,  CONFIG_FILE);
  iRc = InitCnfTbl(caFileName);
  if ( iRc < 0 ){
    printf("Initial config table error!!\n");
    exit( -1 );
  }

  g_iCwaKey = GetCnfValue( CWA_SHM_KEY );
  if (g_iCwaKey < 0){
    printf("get CWA share memory key error!!\n");
    exit( -2 );
  }

  stCwaCtl.cFunCode = CWA_GET_ID;
  stCCBuf.iShmKey = g_iCwaKey;
  stCCBuf.iSemKey = g_iCwaKey;
  
  iRc = CwaCtlFac(&stCwaCtl,&stCCBuf);
  if (iRc == CWA_NORMAL) {
    printf("TPE is online !!\n");
    printf("Please run this utility in TPE offline status!!\n");
    exit(0); 
  }

  iLoadSize = sizeof(struct SSA); 

  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat((char *)caFileName, (char *)"/");
  strcat((char *)caFileName,  SBCWA0_F);
  iDump0Fp = open(caFileName,O_RDONLY);
  if (iDump0Fp != -1) {
    read(iDump0Fp,&iDumpSeqNo0,sizeof(stSsa.iDumpSeqNo));
    close(iDump0Fp);
    iDump0Fp = open(caFileName,O_RDONLY);
  }
  else {
    iDumpSeqNo0 = -CWA_MODNO;
  }

  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat((char *)caFileName, (char *)"/");
  strcat((char *)caFileName,  SBCWA1_F);
  iDump1Fp = open(caFileName,O_RDONLY);
  if (iDump1Fp != -1) {
    read(iDump1Fp,&iDumpSeqNo1,sizeof(stSsa.iDumpSeqNo));
    close(iDump1Fp);
    iDump1Fp = open(caFileName,O_RDONLY);
  }
  else {
    iDumpSeqNo1 = -CWA_MODNO;
  }

  if (iDumpSeqNo0 == iDumpSeqNo1 ||
      abs(iDumpSeqNo0 - iDumpSeqNo1) >= CWA_MODNO) {
    printf("sbcwa0.bin or sbcwa1.bin doesn't exist!! please check!!\n");
    exit(CWA_LOGFILE_NOEXIST);
  }

  if (abs(iDumpSeqNo0 - iDumpSeqNo1) == 1) {
    if (iDumpSeqNo0 > iDumpSeqNo1) {
      iRc = read(iDump0Fp,&stSsa,iLoadSize) ;
      if (iRc != iLoadSize){
        iRc = read(iDump1Fp,&stSsa,iLoadSize) ;
        if (iRc != iLoadSize){
          printf("read both sbcwa1.bin and sbcwa0.bin size error!!!\n");
          exit(READ_CWALOG_ERR);
        } /* if (iRc != iLoadSize) */
        else {
          iWriteFlag = 1;
        }
      }  /* if (iRc != iLoadSize) */
      else {
        iWriteFlag = 0;
      }
    }
    else{
      iRc = read(iDump1Fp,&stSsa,iLoadSize) ;
      if (iRc != iLoadSize){
        iRc = read(iDump0Fp,&stSsa,iLoadSize) ;
        if (iRc != iLoadSize){
          printf("read both sbcwa1.bin and sbcwa0.bin size error!!!\n");
          exit(READ_CWALOG_ERR);
        } /* if (iRc != iLoadSize) */
        else {
          iWriteFlag = 0;
        }
      } /* if (iRc != iLoadSize) */
      else {
        iWriteFlag = 1;
      }
    } /* if (iDumpSeqNo0 > iDumpSeqNo1) */
  }
  else {
    if (iDumpSeqNo1 > iDumpSeqNo0) {
      iRc = read(iDump0Fp,&stSsa,iLoadSize);
      if (iRc != iLoadSize) {
        iRc = read(iDump1Fp,&stSsa,iLoadSize);
        if (iRc != iLoadSize) {
          printf("read both sbcwa1.bin and sbcwa0.bin size error!!!\n");
          exit(READ_CWALOG_ERR);
        } /* if (iRc != iLoadSize)  */
        else {
          iWriteFlag = 1;
        }
      } /* if (iRc != iLoadSize) */
      else {
        iWriteFlag = 0;
      }
    } /* if (iDumpSeqNo1 > iDumpSeqNo0)  */
    else {
      if (iDumpSeqNo1 < iDumpSeqNo0) {
        iRc = read(iDump1Fp,&stSsa,iLoadSize) ;
        if (iRc != iLoadSize){
          iRc = read(iDump0Fp,&stSsa,iLoadSize) ;
          if (iRc != iLoadSize) {
            printf("read both sbcwa1.bin and sbcwa0.bin size error!!!\n");
            exit(READ_CWALOG_ERR);
          } /* if (iRc != iLoadSize) */ 
          else {
            iWriteFlag = 0;
          }
        } /* if (iRc != iLoadSize) */
        else {
          iWriteFlag = 1;
        }
      } /* if (iDumpSeqNo1 < iDumpSeqNo0) */
    } /* if (iDumpSeqNo1 > iDumpSeqNo0) */
  } /* if (abs(iDumpSeqNo0 - iDumpSeqNo1) == 1) */

  close(iDump0Fp);
  close(iDump1Fp);

  
  sStatus = stSsa.sSysStatus ;
  
  /* if the TPE system has opened, then it can't be rollbacked */
  if ( ( sStatus | SYSTEM_RESTART == 1) || ( sStatus | SYSTEM_STARTED) ==1 ) {
    printf("The system has been started or The system status is RESTART.\n");
    printf("The system can't be rollbacked right now...\n");
    printf("Try to use [CWA maintain tool] to rollback...\n");
    printf("press any key to continue...\n");
    getchar();
    exit(0);
  }

  /* rollback to yesterday as like abnormal shutdown  */
  stSsa.sSysStatus = stSsa.sSysStatus | SYSTEM_RESTART; 

  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat((char *)caFileName, (char *)"/");
  if (iWriteFlag == 0) {
    strcat((char *)caFileName,  SBCWA0_F);
  }
  else {
    strcat((char *)caFileName,  SBCWA1_F);
  }

  iFp = open(caFileName,O_WRONLY);

  write(iFp,&stSsa,iLoadSize);

  close(iFp);
  printf("rollback to yesterday successfully!!!\n");
  printf("press any key to continue...\n");
  getchar();

  exit(0);
}

