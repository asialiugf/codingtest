
/*
 *&N& ROUTINE NAME:main()
 *&A&
 *&R&
 *&D& DESCRIPTION
 *&D& ���{���Ω�إ߰������Һ޲z�l�t�Ψϥ��v�O���ϥΪ�
 *&D& �i�������楻�����ɩΥѱ���{���s�Τ�
*/
#define  PASSWORD_F   "iii/etc/tbl/emdpass.dat"

#include <stdio.h>
#include <errno.h>
#include <termio.h>
#include <time.h>
#include <fcntl.h>
extern   int errno;
main()
{
  int  i;
  int  iRc;
  char cCmd;
  char cPause;
  
  while(1) {
    ShowPassScrn(&cCmd);
    switch (cCmd){
      case '1':
        iRc = CrPassWord();
        if (iRc == 0) {
          printf("\nCreate New User successful!!\n");
        }
        else {
          printf("\nCreate New User Failure!!\n");
        }
        printf("Press Any Key to Continue...\n");
        scanf("%c",&cPause);
        scanf("%c",&cPause);
        break;
      case '2':
        iRc = UpPassWord();
        if (iRc == 0) {
          printf("\nUpdate User Password successful!!\n");
        }
        else {
          printf("\nUpdate User Password Failure!!\n");
        }
        printf("Press Any Key to Continue...\n");
        scanf("%c",&cPause);
        scanf("%c",&cPause);
        break;
      case '3':
        iRc = DelPassWord();
        if (iRc == 0) {
          printf("\nDelete User successful!!\n");
        }
        else {
          printf("\nDelete User Failure!!\n");
        }
        printf("Press Any Key to Continue...\n");
        scanf("%c",&cPause);
        scanf("%c",&cPause);
        break;
      case '4':
        exit(0);
      default:
        printf("\n!! Choise error !!\n");
        printf("\n Please press any key to continue.\n");
        scanf("%c",&cPause);
    } /* FOR switch (cCmd)*/
  } /* FOR while(1) */
}

ShowPassScrn(char *cCmd)
{
    int iCmd;
    char cDummy;

    system("clear");
    printf("\n\n EMS Password Maintain Main Menu:\n");
    printf("------------------------------------------\n");
    printf("\n1.Create New User.\n");
    printf("2.Update User.\n");
    printf("3.Delete User.\n");
    printf("4.Quit.\n");
    printf("\n------------------------------------------\n");
    printf("\n\n\nPlease enter a number of choise : ");
    scanf("%c%c",cCmd,&cDummy);
    return(0);
}

CrPassWord()
{
  char  caId[128];
  char  caUserName[128];
  char  caInPassWord[128];
  char  caConfirmPassWd[128];
  char  caEncrpPassWord[128];
  int   iRc;
  char  caFileName[256];
  FILE  *zPSfgid;
  int   iRand;
  int   iIdx;
  long  lNow;
  static int   s_iFileFstOpen=0;

  /* open password file name */
  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat((char *)caFileName, (char *)"/");
  strcat((char *)caFileName,  PASSWORD_F);
  if((zPSfgid=fopen(caFileName,"r")) == NULL){
    s_iFileFstOpen=1;
    zPSfgid=fopen(caFileName,"w");
    srand(time(&lNow) % 1000);
    iRand = rand() % 100;
    sprintf(caId,"%.2d",iRand);
    fprintf(zPSfgid,"%s \n",caId);
    fclose(zPSfgid);
  } 
  else  {
    s_iFileFstOpen=0;
    fscanf(zPSfgid,"%2s\n",caId);
    fclose(zPSfgid);
  }
  
  printf("username:");
  scanf("%s",caUserName);
  if (! s_iFileFstOpen) {
    SrhUsrName(&iIdx,caUserName);
    if (iIdx != -1)  { 
      printf("\nThis Username has been registered\n");
      printf("\nplease check!!! \n");
      return(-1) ;
    }
  }
  printf("password:");
  system("stty -echo");
  scanf("%s",caInPassWord);
  system("stty echo");
  printf("\nPlease retype once to confirm:");
  system("stty -echo");
  scanf("%s",caConfirmPassWd);
  system("stty echo");
  if ( strcmp(caInPassWord,caConfirmPassWd) != 0) {
    printf("\nconfirm password is different from the original one\n");
    printf("\nplease check!!! \n");
    return(-1) ;
  }
  printf("\nplease wait..");
  strcpy(caEncrpPassWord,crypt(caInPassWord,caId));

   
  /* open password file name */
  if((zPSfgid=fopen(caFileName,"a")) == NULL){
    printf("PassWord:open password file errno=%d",errno);
    return(-9);
  } /* FOR if((zPSfgid=fopen(cFilename,"r")) == NULL) */
 
  
  fprintf(zPSfgid,"%s %s\n",caUserName,caEncrpPassWord);
  fclose(zPSfgid);

  return(0) ;
}

UpPassWord()
{
  char  caId[128];
  char  caUname[128];
  char  caInPassWord[128];
  char  caConfirmPassWd[128];
  char  caEncrpPassWord[128];
  char  caPasswd[128];
  int   iRc,i;
  char  caFileName[256];
  FILE  *zPSfgid;
  int   iRand;
  int   iIdx;
  long  lNow;
  long  lCurPos;
  static int   s_iFileFstOpen=0;

  /* open password file name */
  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat((char *)caFileName, (char *)"/");
  strcat((char *)caFileName,  PASSWORD_F);
  if((zPSfgid=fopen(caFileName,"r")) == NULL){
    printf("There's no password file existed.\n");
    return(-1);
  } 
  else  {
    fscanf(zPSfgid,"%2s\n",caId);
    fclose(zPSfgid);
  }
  
  printf("username:");
  scanf("%s",caUname);
  SrhUsrName(&iIdx,caUname);
  if (iIdx == -1)  { 
    printf("This Username has not been registered\n");
    printf("\nplease check!!! \n");
    return(-1) ;
  }
  printf("Enter Old Password:");
  system("stty -echo");
  scanf("%s",caInPassWord);
  system("stty echo");
  iRc = ChkPassWord(caId,caUname,caInPassWord);
  if (iRc != 1) {
    printf("\nPassword Error!! Update Abort...\n");
    return(-1) ;
  }

  printf("\nEnter New Password:");
  system("stty -echo");
  scanf("%s",caInPassWord);
  system("stty echo");
  printf("\nPlease retype once to confirm:");
  system("stty -echo");
  scanf("%s",caConfirmPassWd);
  system("stty echo");
  if ( strcmp(caInPassWord,caConfirmPassWd) != 0) {
    printf("confirm password is different from the original one\n");
    printf("\nplease check!!! \n");
    return(-1) ;
  }
  printf("\nplease wait..");
  strcpy(caEncrpPassWord,crypt(caInPassWord,caId));

   
  /* open password file name */
  if((zPSfgid=fopen(caFileName,"r+")) == NULL){
    printf("PassWord:open password file errno!!");
    return(-9);
  } /* FOR if((zPSfgid=fopen(cFilename,"r")) == NULL) */
 
  fscanf(zPSfgid,"%2s\n",caId);

  for (i=0;i<=iIdx;i++) {
    lCurPos = ftell(zPSfgid);
    if(lCurPos == -1){
      printf("UpPassWd:ftell errno!!");
      return(-8);
    }/*  if(lCurPos == -1) */
    iRc=fscanf(zPSfgid,"%s %s\n",caUname,caPasswd);
  }

  fseek(zPSfgid,lCurPos,SEEK_SET);
  fprintf(zPSfgid,"%s %s\n",caUname,caEncrpPassWord);
  fclose(zPSfgid);

  return(0) ;
}

SrhUsrName(piIdx,pcaUserName)
int  *piIdx;
char *pcaUserName;
{
  FILE  *zPSfgid;
  char  caUname[128];
  char  caPasswd[128];
  char  caFileName[256];
  char  caId[128];
  int   iCnt=0;
  int   iRc;

  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat((char *)caFileName, (char *)"/");
  strcat((char *)caFileName,  PASSWORD_F);
  zPSfgid=fopen(caFileName,"r");

  fscanf(zPSfgid,"%s \n",caId);

  iRc=fscanf(zPSfgid,"%s %s\n",caUname,caPasswd);

  while(iRc != EOF) {
    if ( strcmp(pcaUserName,caUname) == 0) {
      *piIdx = iCnt;
      fclose(zPSfgid);
      return(0) ;
    }
    else {
      iRc=fscanf(zPSfgid,"%s %s\n",caUname,caPasswd);
      iCnt++;
    }
  }  /*  FOR while(iRc...)  */
  *piIdx = -1;
  fclose(zPSfgid);
  return(0) ;
}

int
ChkPassWord(pcaId,pcaUname,pcaPasswd)
char  *pcaId;
char  *pcaUname;
char  *pcaPasswd;
{
  char  caCrpPassWd[128];
  char  caUname[128];
  char  caPasswd[128];
  char  caFileName[256];
  char  caId[128];
  int   iRc;
  FILE *zPSfgid;

  /* open password file name */
  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat((char *)caFileName, (char *)"/");
  strcat((char *)caFileName,  PASSWORD_F);
  if((zPSfgid=fopen(caFileName,"r")) == NULL){
    printf("ChkPassWord:open password file err\n");
    return(-1);
  } /* FOR if((zPSfgid=fopen(cFilename,"r")) == NULL) */
  
  fscanf(zPSfgid,"%s \n",caId);

  iRc=fscanf(zPSfgid,"%s %s\n",caUname,caPasswd);

  strcpy(caCrpPassWd,crypt(pcaPasswd,pcaId));

  while(iRc != EOF) {

    if ( ( strcmp(caUname,pcaUname) == 0) &&
      ( strncmp(caCrpPassWd,caPasswd,13) == 0 ) ) {
      fclose(zPSfgid);
      return(1) ;
    }
    else {
      iRc=fscanf(zPSfgid,"%s %s\n",caUname,caPasswd);
    }

  }  /*  FOR while(iRc...)  */

  fclose(zPSfgid);
  return(0) ;
}

int
DelPassWord()
{
  char  caId[128];
  char  caUname[128];
  char  caInPassWord[128];
  char  caConfirmPassWd[128];
  char  caEncrpPassWord[128];
  char  caPasswd[128];
  int   iRc,i;
  char  caFileName[256];
  char  caTmpFile[256];
  char  caCmdBuf[256];
  FILE  *zPSfgid;
  int   iRand;
  int   iIdx;
  long  lNow;
  long  lCurPos;
  static int   s_iFileFstOpen=0;

  /* open password file name */
  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat((char *)caFileName, (char *)"/");
  strcat((char *)caFileName,  PASSWORD_F);
  if((zPSfgid=fopen(caFileName,"r")) == NULL){
    printf("There's no password file existed.\n");
    return(-1);
  } 
  else  {
    fscanf(zPSfgid,"%2s\n",caId);
    fclose(zPSfgid);
  }

  printf("username:");
  scanf("%s",caUname);
  SrhUsrName(&iIdx,caUname);
  if (iIdx == -1)  { 
    printf("This Username has not been registered\n");
    printf("\nplease check!!! \n");
    return(-1) ;
  }
  printf("Enter Old Password:");
  system("stty -echo");
  scanf("%s",caInPassWord);
  system("stty echo");
  iRc = ChkPassWord(caId,caUname,caInPassWord);
  if (iRc != 1) {
    printf("\nPassword Error!! Delete Abort...\n");
    return(-1) ;
  }

  strcpy((char *)caTmpFile, (char *)getenv("III_DIR"));
  strcat((char *)caTmpFile, (char *)"/");
  strcat((char *)caTmpFile,  "iii/tmp/pas.tmp");

  printf("\nBegin to Delete.... \n");
  sprintf(caCmdBuf,"deluser.sh %s;echo $? > %s",caUname,caTmpFile);
  system(caCmdBuf);
  return(PrnContMsg());
}

/* ---------------------------------------------------------------------- */
/* When error happened this routine return (-1) else return (0).          */
/* ---------------------------------------------------------------------- */
int
PrnContMsg()
{
  int  zFd123;
  char caBuf[256];
  char caTmpFile[256];

  strcpy((char *)caTmpFile, (char *)getenv("III_DIR"));
  strcat((char *)caTmpFile, (char *)"/");
  strcat((char *)caTmpFile,  "iii/tmp/pas.tmp");
  zFd123=open(caTmpFile,O_RDONLY);
  read(zFd123,caBuf,1);
  close(zFd123);

  if (caBuf[0] != '0'){
    return (-1);
  }
  else {
    return (0);
  }

}
