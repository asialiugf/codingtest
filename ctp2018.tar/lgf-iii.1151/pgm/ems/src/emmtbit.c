
/*
 *&N& ROUTINE NAME: main  
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&           
 *&R& RETURN VALUES:
 *&R&           
 *&R&           
 *&D& DESCRIPTION:           
 *&D&     ���{�������Һ޲z�l�t�α���ʱ��u��{��, �t�d��� BIT �����p�P���@
 *&D&     ���{���i����W����ά��ʱ��{���s��
 *&D&     ( This program is Curses mode, i.e. using Curses as the output)      
 */

#include <stdio.h>
#include <curses.h>
#include <signal.h>
#include <errno.h>
#include "errlog.h"
#include "dcs.h"
#include "cwa.h"
#include "emctbit.h"
#include "emctool.h"

/* tool specific constants */

#define EDIT_OPTIONS \
"    ^I=Ins/Rep ^D=Delete ^U=Undo ^H=Home ^E=End F6/F7=L/R Skip ^K=Backspace   "
#define EDIT_OPTIONS_BLANK \
"    F4=[Update]    F5=[Edit Trm]    ENTER=[Select]    Escape=[Exit]           "

#define  MAX_DATA_LEN	30
#define  BASE_YEAR      "BASE_YEAR"
#define  TEST_MODE      "TEST_MODE"
#define  MENU_FILE_BRH  "iii/etc/cmg/bitbrh.scr"
#define  MENU_FILE_TRM  "iii/etc/cmg/bittrm.scr"
#define  CONFIG_FILE    "iii/etc/tbl/config.dat"
#define  TOOL_NAME      "emxtbit.x"

/* the number of fields in BIT-BRH data structure */
#define NO_ITEM_BRH     8
/* the number of fields in BIT-TRM data structure */
#define  NO_ITEM_TRM    13+1 /* TCC */
#define  IN_MAIN        1
#define  IN_SUB         2

#define  ON_TXN         0x80
#define  NO_PAYUP       0x40
#define  BACK_SEND      0x20
#define  LINK_CENTER    0x10

#define  NEXT_TRM       1
#define  PREV_TRM       2
#define  LATE_VERIFY    0x80

#define  DATE_LEN       8
#define  DAYS_OFFSET    6  /* YYYYMMDD  */
#define  MNTH_OFFSET    4  /* YYYYMMDD  */
#define  YEAR_OFFSET    0  /* YYYYMMDD  */
#define  TRUE           1
#define  FALSE          0
#define  MAX_DATW       3

/* Key Definition */
#define  CTL_P          16
#define  CTL_N          14
#define  CTL_L          12
#define  CTL_R          18
#define  CTL_I          9
#define  CTL_H          8
#define  CTL_D          4
#define  CTL_U          21
#define  CTL_K          11
#define  CR             13
#define  ESC            27
#define  ENTER          0x0797  
#define  ESC_6          '6'
#define  ESC_7          '7'

/* Declare the Check Routine */
int      DateValid();
int      TermTypeChk();
int      RntySeqChk();
int      TermStatChk();

struct stItem {
        int iPage;
        int iRow;
        int iCol;
        int (*Routine1)();
        int (*Routine2)();
        char caData[ MAX_DATA_LEN ];
        char cType;
        int iLength;      /* '\0' not included */
        char cAttribute;  /* 'd': display only; 'e': editable; 'r': reserved */
        };

/* the first branch record's screen layout description */
struct stItem stBrhRecordDesc[ NO_ITEM_BRH ] = {
            {1, 5, 17, NULL, NULL, "", 'c', 24, 'd'},
            {1, 5,  6, NULL, NULL, "", 'c', 10, 'd'},
            {1, 0,  0, NULL, NULL, "", 'c',  6, 'r'},
            {1, 5, 49, NULL, DateValid, "", 'c',  8, 'e'},
            {1, 5, 59, NULL, DateValid, "", 'c',  8, 'e'},
            {1, 5, 69, NULL, DateValid, "", 'c',  8, 'e'},
            {1, 5, 43, NULL, NULL, "", 'c',  4, 'd'},
            {1, 0,  0, NULL, NULL, "", 'c',  4, 'r'},
         };

struct stItem stTrmRecord[ NO_ITEM_TRM ] = {
            {1, 14, 26, NULL, NULL, "", 'c', 10, 'd'},
            {1, 15, 26, NULL, NULL, "", 'c', 10, 'd'},
            {1, 16, 26, NULL, NULL, "", 'c', 10, 'd'},
            {1,  7, 26, NULL, NULL, "", 'c', 14, 'e'},
            {1,  6, 26, NULL, NULL, "", 'c',  4, 'd'},
            {1,  8, 26, NULL, TermTypeChk, "", 'c',  1, 'e'},
/* TCC
            {1, 10, 52, NULL, NULL, "", 'c', 24, 'd'},*/ /* Term Status */
            {1, 10, 52, NULL, TermStatChk, "", 'c', 1, 'e'}, /* Term Status */
            {1, 10, 55, NULL, NULL, "", 'c', 20, 'd'}, /* Term Status */
            {1, 18, 52, NULL, NULL, "", 'c', 24, 'd'}, /* Term Mode   */
            {1,  9, 26, NULL, NULL, "", 'c', 10, 'd'},
            {1, 10, 26, NULL, NULL, "", 'c',  4, 'd'},
            {1, 11, 26, NULL, NULL, "", 'c', 10, 'd'},
            {1, 12, 26, NULL, NULL, "", 'c', 10, 'd'},
            {1, 13, 26, NULL, RntySeqChk, "", 'c', 10, 'e'}, 
         };

struct stEditItem {
        int iRowCol;  /* iRow * 100 + iCol */
        int iIndex;
        };

int    iaMax_Days[13] = {  0, 31, 28, 31, 30, 31, 30,
                           31, 31, 30, 31, 30, 31} ;
static struct SSA      sg_stSsaArea;
static struct BrhArea  sg_stBrhArea;
static struct TermArea sg_stTrmArea;
static struct MonCmd   sg_stMonCmd;
int    g_iBaseYear;
int    g_iTestMode;
int    g_iTotBrhCnt=0, g_iTotBrhPage=0;
/* TCC: For compatibility with Tandem */
struct stBrhNode *MvBrhRecord();
struct stBrhNode *EditBrh();

main( argc, argv )
int argc;
char **argv;
{
  struct stMenuBit *pstMenu;
  struct stMenuBit *InitTool();
  int    i,iRc;
  char   caFileName[81];
  char   caLogName[128];

  if (argc == 1) {
    printf("Usage : emxtbit.x 11111C\n");
    exit(0);
  }
  else if (argc ==2) {
    if (argv[1][5] != 'C') {
      printf("Usage : emxtbit.x 11111C\n");
      exit(0);
    }
  }
  else if ( (argc == 3) && (argv[2][0] == 'E') ) {

    for (i=0;i<NO_ITEM_TRM;i++) {
      if ( stTrmRecord[i].iRow != 0){
        stTrmRecord[i].cAttribute = 'e';
      }
    }

    for (i=0;i<NO_ITEM_BRH;i++) {
      if ( stBrhRecordDesc[i].iRow != 0){
        stBrhRecordDesc[i].cAttribute = 'e';
      }
    }

  }
  else {
    printf("Usage : emxtbit.x 11111C\n");
    exit(0);
  }

  sprintf(caLogName, "%s/iii/log/ems_errlog", getenv("III_DIR") );
  ChgLog(LOG_CHG_LOG,caLogName);

  sprintf ((char *)caFileName, "%s/%s", 
           (char *)getenv("III_DIR"), CONFIG_FILE);
  iRc = InitCnfTbl(caFileName);
  if ( iRc < 0 ){
    printf("Initial Config Table Fail !!\n");
    exit( -1 );
  }

  g_iTestMode = GetCnfValue( TEST_MODE );
  if (g_iTestMode != 0 && g_iTestMode != 1){
    sprintf(g_caMsg, "<EMS> Failure to get TEST_MODE value in config.dat!");
    printf("%s\n", g_caMsg);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    exit( -3 );
  }

  g_iBaseYear = GetCnfValue( BASE_YEAR );
  if (g_iBaseYear < 0){
    sprintf(g_caMsg, "<EMS> Failure to get BASE_YEAR value in config.dat!");
    printf("%s\n", g_caMsg);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    exit( -2 );
  }

  if ( g_iTestMode == 1) {
    ChgLog(LOG_CHG_MODE,"1");
  }
  else {
    ChgLog(LOG_CHG_MODE,"0");
  }

  memcpy (sg_stMonCmd.caTblidx, argv[1], sizeof(struct MonCmd));
  SendCmdToMon (&sg_stMonCmd, IN_MAIN);
    
  pstMenu = (struct stMenuBit *) InitTool();
  iRc = RetrieveData( pstMenu );
  if (iRc != 0) {
    DisplayData( pstMenu );
    wgetch(pstMenu->pwWin);
    EndTool( pstMenu );
    exit(0);
  }
  DisplayData( pstMenu );
  Process( pstMenu,0 );
  EndTool( pstMenu );
}

struct stMenuBit *InitTool()
{
  struct stMenuBit *pstMenu;
  struct stMenuBit *InitMenu();
  int Interrupt();

  /* call Interrupt() if user hits BREAK or DELETE */
  signal( SIGINT, Interrupt );

  /* initially setup of curses */
  initscr();
  cbreak();
  raw();
  noecho();
  nonl();
/*  keypad( stdscr, TRUE );    /x to get arrow keys */

  /* to display menu and initialize menu data structure */
  pstMenu = (struct stMenuBit *) InitMenu();

  return( pstMenu );
}

/* this routine should be modified for each tool */
struct stMenuBit *InitMenu()
{
  WINDOW *pwWin;
  FILE *pfBrhMenuFile;
  FILE *pfTrmMenuFile;
  char caFileName [128];
  struct stMenuBit *pstMenu;
  int iCurRow;

  sprintf (caFileName, "%s/%s", getenv("III_DIR"), MENU_FILE_BRH);
  if (( pfBrhMenuFile = fopen( caFileName, "r" )) == NULL) {
    sprintf (g_caMsg, "<EMS> Failure to open file [%s]! (errno:%d)",
             MENU_FILE_BRH, errno);
    printf ("%s\n", g_caMsg);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    EndTool();
  }

  sprintf (caFileName, "%s/%s", getenv("III_DIR"), MENU_FILE_TRM);
  if (( pfTrmMenuFile = fopen( caFileName, "r" )) == NULL) {
    sprintf (g_caMsg, "<EMS> Failure to open file [%s]! (errno:%d)",
             MENU_FILE_TRM, errno);
    printf ("%s\n", g_caMsg);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    EndTool();
  }

  /* to allocate the BIT-BRH's menu data structure */
  pstMenu = (struct stMenuBit *) calloc( sizeof( struct stMenuBit ), 1 );
  pstMenu->pwWin = (WINDOW *) newwin( LINES, COLS, 0, 0 );
  pstMenu->iNoRecord = PAGE_SIZE;
  pstMenu->pstItem = stBrhRecordDesc;
  pstMenu->pcHead = NULL;

  /* to allocate the BIT-TRM's menu data structure as the next menu */
  pstMenu->pstNextMenu = 
          (struct stMenuBit *) calloc( sizeof( struct stMenuBit ), 1 );
  pstMenu->pstNextMenu->pwWin = (WINDOW *) newwin( LINES, COLS, 0, 0 );
  pstMenu->pstNextMenu->iNoRecord = 1;
  pstMenu->pstNextMenu->pstItem = stTrmRecord;
  pstMenu->pstNextMenu->pcHead = NULL;

  /* to get menu from the BIT-BRH's menu file */
  pwWin = pstMenu->pwWin;
  iCurRow = 0;
/*
  wattrset( pwWin, BCOLOR_BLACK | COLOR_WHITE );
*/
  wattrset( pwWin, A_NORMAL );
  while ((fgets( caFileName, COLS, pfBrhMenuFile )) != NULL) {
    if (strlen( caFileName ) != 0) {
      mvwaddstr( pwWin, iCurRow, 0, caFileName );
    }
    iCurRow = iCurRow + 1;
  }
  fclose( pfBrhMenuFile );

  /* to show BIT-BRH's menu onto the screen first */
  wrefresh( pwWin );

  /* to get menu from the BIT-TRM's menu file */
  pwWin = pstMenu->pstNextMenu->pwWin;
  iCurRow = 0;
/*
  wattrset( pwWin, BCOLOR_BLACK | COLOR_WHITE );
*/
  wattrset( pwWin, A_NORMAL );
  while ((fgets( caFileName, COLS, pfTrmMenuFile )) != NULL) {
    if (strlen( caFileName ) != 0) {
      mvwaddstr( pwWin, iCurRow, 0, caFileName );
    }
    iCurRow = iCurRow + 1;
  }
  fclose( pfTrmMenuFile );

  return( pstMenu );
}

/* to retrieve BIT-BRH data from EMS server */
int RetrieveData( pstMenu )
struct stMenuBit *pstMenu;
{
  struct stItem *pstItem;
  struct stBrhNode *pstCurBrhNode;      /* pointer to the current node */
  struct stBrhNode *pstTmpBrhNode;      /* temperary pointer */
  int    i, j;
  int    iBrhCnt=0, iAccBrhCnt=0, iStartBrh=0;
  char   caTmpBuf[20];
  char   caDateBuf[11]="//////////";
  char   caBitData[DCS_MAX_DATA_LEN];
  int    iRc;
  int    iOffset;
  char   caHeadData[8];
  char   caBodyData[3*10*13];

  iRc = GetInfoFmEms(RETRIEVE,CWA_SSA,&sg_stSsaArea);
  if (iRc !=0) {
    ShowMsg(pstMenu,23,25,"Failure to retrieve SSA!");
    return(-1);
  }
  strncpy( caTmpBuf, sg_stSsaArea.caTxnDate,8 );
  memcpy( caDateBuf,caTmpBuf,4);
  memcpy( caDateBuf+5,caTmpBuf+4,2);
  memcpy( caDateBuf+8,caTmpBuf+6,2);
  mvwaddstr( pstMenu->pwWin, 0, 65, caDateBuf);

  pstCurBrhNode = (struct stBrhNode *) pstMenu->pcHead;

  do {

    if (g_iTotBrhCnt > iAccBrhCnt)
    {
       sprintf (g_caMsg, "<EMS> Access the BIT page from the %d branch!",
                iAccBrhCnt);
       ErrLog (10, g_caMsg, RPT_TO_LOG, 0, 0);
    }

    SendCmdToMon(&sg_stMonCmd,IN_SUB);

    memset (caBitData, 0, sizeof(caBitData));
    memcpy (caBitData, &iAccBrhCnt, sizeof(int));

    iRc = GetInfoFmEms (RETRIEVE, BIT_BRH, caBitData);
    if (iRc !=0) {
      ShowMsg (pstMenu, 23, 25, "Failure to retrieve BIT!");
      return(-1);
    }
    memcpy (&g_iTotBrhCnt, caBitData, 4);
    memcpy (&iBrhCnt, caBitData+4, 4);

    pstMenu->iTotalNode = g_iTotBrhCnt;
    for (i=iAccBrhCnt, j=0; i < (iBrhCnt+iAccBrhCnt); i++,j++) {
      if ( pstCurBrhNode == NULL ) {
        /* to allocate the first branch node */
        pstCurBrhNode = (struct stBrhNode *)
                         calloc( sizeof( struct stBrhNode ), 1 );
        pstCurBrhNode->iNodeIdx = i + 1;
        pstCurBrhNode->next = NULL;
        pstCurBrhNode->prev = NULL;
        pstCurBrhNode->pstTrmHead = NULL;
        pstMenu->pcHead = (char *) pstCurBrhNode;
      }
      else {
        /* to allocate the rest branch nodes */
        pstTmpBrhNode = pstCurBrhNode;
        pstCurBrhNode = (struct stBrhNode *)
                         calloc( sizeof( struct stBrhNode ), 1 );
        pstCurBrhNode->iNodeIdx = i + 1;
        pstCurBrhNode->prev = pstTmpBrhNode;
        pstCurBrhNode->next = NULL;
        pstCurBrhNode->pstTrmHead = NULL;
        pstTmpBrhNode->next = pstCurBrhNode;
      }

      iOffset = 8 + j*sizeof(struct BrhArea);
      memcpy (pstCurBrhNode, &caBitData[iOffset], sizeof(struct BrhArea));
    }

    iAccBrhCnt += iBrhCnt;
  } while (g_iTotBrhCnt > iAccBrhCnt);

  g_iTotBrhPage =  (g_iTotBrhCnt / PAGE_SIZE) +
                  ((g_iTotBrhCnt % PAGE_SIZE) ? 1 : 0);

  return(0);
}

/* to update Branch data into EMS server */
int UpdateData( pstMenu )
struct stMenuBit *pstMenu;
{
  struct  stItem *pstItem;
  char    caTmpDateBuf[30],cChar;
  int     i,iRc ;
  int     iCnt;
  struct  stBrhNode *pstCurBrhNode;      /* pointer to the current node */
  char    caShowBuf[55];

  pstCurBrhNode = (struct stBrhNode *) pstMenu->pcHead;

  iCnt = 1;
  while (pstCurBrhNode != NULL)
  {
    memcpy (&sg_stBrhArea, &(pstCurBrhNode->stBrhRecord)
            ,sizeof(struct BrhArea));
    
    CpyBrhRec2Item( pstMenu, &sg_stBrhArea);
    for (i=0;i<NO_ITEM_BRH;i++) {
      pstItem = pstMenu->pstItem;
      switch(i) {
        case 0:
          break;
        case 1:
          strncpy( sg_stBrhArea.caBrhId, pstItem[ i ].caData, 
                 pstItem[ i ].iLength);
          break;
        case 2:
          strncpy( sg_stBrhArea.caBrchClsTime, pstItem[ i ].caData, 
                   pstItem[ i ].iLength);
          break;
        case 3:
          strncpy( sg_stBrhArea.caTxnDate, pstItem[ i ].caData, 
                   pstItem[ i ].iLength);
          break;
        case 4:
          strncpy( sg_stBrhArea.caNxtTxnDate, pstItem[ i ].caData, 
                   pstItem[ i ].iLength);
          break;
        case 5:
          strncpy( sg_stBrhArea.caNNxtTxnDate, pstItem[ i ].caData, 
                   pstItem[ i ].iLength);
          break;
        case 6:
          break;
        case 7:
          break;
      } /* FOR switch(i) */
    } /* FOR (i=0;i<NO_ITEM_BRH;i++) */

    SendCmdToMon(&sg_stMonCmd,IN_SUB);

    iRc = GetInfoFmEms(UPDATE,BIT_BRH,&sg_stBrhArea);
    if (iRc ==0) {
      sprintf(caShowBuf,"Update %d Branch Successfully!!",iCnt);
      ShowMsg(pstMenu,22,25,caShowBuf); 
    }
    else {
      sprintf(caShowBuf,"Update %d Branch Failure!!     ",iCnt);
      ShowMsg(pstMenu,22,25,caShowBuf);
    }
    pstCurBrhNode = pstCurBrhNode->next; 
    iCnt++;
    wrefresh( pstMenu->pwWin );
  } /* FOR while (pstCurBrhNode != NULL) */

  sprintf(caShowBuf,"Press Any Key to Continue..");
  ShowMsg(pstMenu,23,25,caShowBuf); 
  wrefresh( pstMenu->pwWin );
  wgetch( pstMenu->pwWin );
}

/* to update Terminal data into EMS server */
int UpdateTrmData( pstMenu, pstCurTrmNode, pstCurBrhNode )
struct stMenuBit *pstMenu;    
struct stTrmNode *pstCurTrmNode; /* pointer to the current terminal node */
struct stBrhNode *pstCurBrhNode; /* pointer to the current branch node */
{
  struct stItem *pstItem;
  char   caTmpDateBuf[30],cChar;
  int    i,j,iRc ;
  char   caShowBuf[55];

  memcpy(&sg_stTrmArea,&(pstCurTrmNode->stTrmRecord)
         ,sizeof(struct TermArea));
  pstItem = pstMenu->pstNextMenu->pstItem;
  for (i=0;i<NO_ITEM_TRM;i++) {
    switch(i) {
      case 0:
        sg_stTrmArea.lLastOnlnRrn = atol(pstItem[ i ].caData);
        pstCurTrmNode->stTrmRecord.lLastOnlnRrn = atol(pstItem[ i ].caData);
        break;
      case 1:
        sg_stTrmArea.lLastBtchRrn = atol(pstItem[ i ].caData);
        pstCurTrmNode->stTrmRecord.lLastBtchRrn = atol(pstItem[ i ].caData);
        break;
      case 2:
        sg_stTrmArea.lCurBtchErrRrn = atol(pstItem[ i ].caData);
        pstCurTrmNode->stTrmRecord.lCurBtchErrRrn = atol(pstItem[ i ].caData);
        break;
      case 3:
        strncpy( sg_stTrmArea.caLogicId, pstItem[ i ].caData, 
                 pstItem[ i ].iLength);
        sg_stTrmArea.caLogicId[pstItem[ i ].iLength] = 0x0;
        for (j=0;j<pstItem[ i ].iLength;j++) {
          if (sg_stTrmArea.caLogicId[ j ] == 0x20) {
            sg_stTrmArea.caLogicId[ j ] = 0x0;
            break;
          }
        }
        strncpy( pstCurTrmNode->stTrmRecord.caLogicId, pstItem[ i ].caData, 
                 pstItem[ i ].iLength);
        pstCurTrmNode->stTrmRecord.caLogicId[pstItem[ i ].iLength] = 0x0;
        for (j=0;j<pstItem[ i ].iLength;j++) {
          if (pstCurTrmNode->stTrmRecord.caLogicId[ j ] ==  0x20) {
            pstCurTrmNode->stTrmRecord.caLogicId[ j ] = 0x0;
            break;
          }
        }
        break;
      case 4:
        break;
      case 5:
        sg_stTrmArea.cTermType = pstItem[ i ].caData[0]; 
        pstCurTrmNode->stTrmRecord.cTermType = pstItem[ i ].caData[0]; 
        break;
      case 6:
        pstItem[i].caData[0] = toupper (pstItem[i].caData[0]);
        if (pstItem[i].caData[0] == 'Y')
        {
           sg_stTrmArea.cTermStatus |= ON_TXN;
           pstCurTrmNode->stTrmRecord.cTermStatus |= ON_TXN;
        }
        else
        {
           sg_stTrmArea.cTermStatus &= 0x0;
           pstCurTrmNode->stTrmRecord.cTermStatus &= 0x0;
        }
        break;
      case 7:
        break;
      case 8:
        break;
      case 9:
        strncpy( sg_stTrmArea.caBackBrhId, pstItem[ i ].caData, 
                 sizeof(sg_stTrmArea.caBackBrhId));
        strncpy( pstCurTrmNode->stTrmRecord.caBackBrhId, pstItem[ i ].caData, 
                 sizeof(pstCurTrmNode->stTrmRecord.caBackBrhId));
        break;
      case 10:
        strncpy( sg_stTrmArea.caBackTermId, pstItem[ i ].caData, 
                 pstItem[ i ].iLength);
        strncpy( pstCurTrmNode->stTrmRecord.caBackTermId, 
                 pstItem[ i ].caData, pstItem[ i ].iLength);
        break;
      case 11:
        sg_stTrmArea.lAccTxnNo = atol(pstItem[ i ].caData);
        pstCurTrmNode->stTrmRecord.lAccTxnNo = atol(pstItem[ i ].caData);
        break;
      case 12:
        sg_stTrmArea.lNonAccTxnNo = atol(pstItem[ i ].caData);
        pstCurTrmNode->stTrmRecord.lNonAccTxnNo = atol(pstItem[ i ].caData);
        break;
      case 13:
        sg_stTrmArea.lBtchTxnNo = atol(pstItem[ i ].caData);
        pstCurTrmNode->stTrmRecord.lBtchTxnNo = atol(pstItem[ i ].caData);
        break;
    } /* FOR switch(i) */
  } /* FOR (i=0;i<NO_ITEM_TRM;i++) */

  strncpy(sg_stTrmArea.filler,pstCurBrhNode->stBrhRecord.caBrhId,MAX_BR_LEN);
  SendCmdToMon(&sg_stMonCmd,IN_SUB);

  iRc = GetInfoFmEms(UPDATE,BIT_TRM,&sg_stTrmArea);
  if (iRc ==0) {
    ShowMsg(pstMenu->pstNextMenu,23,25, "Update Terminal Successfully!!");
  }
  else {
    ShowMsg(pstMenu->pstNextMenu,23,25, "Update  Terminal Failure!!");
  }
  wrefresh( pstMenu->pstNextMenu->pwWin );
}

int DisplayData( pstMenu )
struct stMenuBit *pstMenu;
{
  int i;  /* for counting the number of branch record's field */
  int iNodeIdx;
  int iLastNodeIdx; /* the last node's index shown in screen */
  int iMoreNode;
  int iRow;
  char cStatus;
  char cAttr;
  char caDataBuf[ MAX_DATA_LEN + 1 ]; /* add a space to contain '\0' */
  struct stBrhNode *pstCurBrhNode;
  struct stBIT_BRH *pstCurBrhRecord;
  WINDOW *pwWin;

  pwWin = pstMenu->pwWin;

  pstCurBrhNode = (struct stBrhNode *) (pstMenu->pcHead);
  while ( pstCurBrhNode != NULL ) {
    iNodeIdx = pstCurBrhNode->iNodeIdx;
    if ( iNodeIdx <= PAGE_SIZE ) {
      pstCurBrhRecord = &(pstCurBrhNode->stBrhRecord);
      CpyBrhRec2Item( pstMenu, pstCurBrhRecord );

      /* to show each record's index */
      mvwprintw( pwWin, 5 + iNodeIdx - 1, 0, "%4d", iNodeIdx );

      /* to show each record's content */
      for (i = 0; i < NO_ITEM_BRH; i ++) {
        /* to show each field in the branch record */
        cAttr = pstMenu->pstItem[ i ].cAttribute;

        /* for filling '\0' to end a string */
        memcpy( caDataBuf, pstMenu->pstItem[ i ].caData,
                pstMenu->pstItem[ i ].iLength );
        caDataBuf[ pstMenu->pstItem[ i ].iLength ] = '\0';

        if ( cAttr == 'd' || cAttr == 'e' ) {
          iRow = pstMenu->pstItem[ i ].iRow + iNodeIdx - 1;
          mvwaddstr( pwWin, iRow, pstMenu->pstItem[ i ].iCol, caDataBuf );
        }
      } /* end for loop */

      pstCurBrhNode = pstCurBrhNode->next;
    }
    else {
      iLastNodeIdx = iNodeIdx - 1;
      break; /* exit while loop */
    } /* end if */
  } /* end while loop */

  iMoreNode = pstMenu->iTotalNode - iLastNodeIdx;
  if ( ( iMoreNode != 0 )&&(pstMenu->iTotalNode > PAGE_SIZE) ){
    mvwprintw( pwWin, 5 + PAGE_SIZE, 6, "[ %d more ]   ", iMoreNode );
  }

  wrefresh( pwWin );
}

int EndTool( pstMenu )
struct stMenuBit *pstMenu;
{
  struct stMenuBit *ptr1, *ptr2;

  /* to release menu structure allocated */
/*
  ptr1 = pstMenu;
  while (ptr1 != NULL) {
    ptr2 = ptr1->pstNextMenu;
    free( ptr1 );
    ptr1 = ptr2;
  }

*/
  endwin();
  exit( 0 );
}

int Process( pstMenu )
struct stMenuBit *pstMenu;
{
  int iKeyIn;
  int iRc;
  int iCurRow,iCurCol;
  WINDOW *pwWin;
  struct stBrhNode *pstCurBrhNode;
  struct stEditItem stEditList[ NO_ITEM_BRH ];
  int iNoEditItem;
  struct stTrmNode *pstCurTrmNode;
  struct stTrmNode *pstNextTrmNode;

  pwWin = pstMenu->pwWin;
  pstCurBrhNode = (struct  stBrhNode *) pstMenu->pcHead;
  if ( pstCurBrhNode != NULL ) {
    ShowBrhRecord( pstMenu, pstCurBrhNode, A_STANDOUT );
  }
  BuildEdtList( pstMenu, stEditList, &iNoEditItem );
  keypad(pstMenu->pwWin,TRUE);

  while (1) {
    /* to refresh screen */
    wrefresh( pwWin );

    /* get key and process */
    iKeyIn = wgetch(pstMenu->pwWin);
    switch( iKeyIn ) {
      case KEY_UP :
/* ??? 
        ShowMsg(pstMenu,22,25, "                                            ");
        ShowMsg(pstMenu,23,25, "                                            ");
*/
        if (pstCurBrhNode->iNodeIdx == 1)
        {
           iCurRow = 5;
           iCurCol = 79;
           wmove( pwWin, iCurRow, iCurCol );
        }
        else
           pstCurBrhNode = MvBrhRecord( pstMenu, pstCurBrhNode, KEY_UP );
        break;
      case KEY_DOWN :
        if (pstCurBrhNode->iNodeIdx < g_iTotBrhCnt)
           pstCurBrhNode = MvBrhRecord( pstMenu, pstCurBrhNode, KEY_DOWN );
/* ???
        ShowMsg(pstMenu,22,25, "                                            ");
        ShowMsg(pstMenu,23,25, "                                            ");
*/
        break;
      case KEY_F(1) :
        CallHelp();
        break;
      case KEY_F(2) :
 /*        InsertData( pstMenu ); */
        break;
      case KEY_F(3) :
 /*        DeleteData( pstMenu ); */
        break;
      case KEY_F(4) :
        ShowMsg(pstMenu,22,25, "                                            ");
        ShowMsg(pstMenu,23,25, "                                            ");
        getyx( pstMenu->pwWin, iCurRow, iCurCol );
        UpdateData( pstMenu ); 
        ShowMsg(pstMenu,23,25, "                                            ");
        wmove( pstMenu->pwWin, iCurRow, iCurCol);
        break;
      case KEY_F(5) :
        ShowMsg(pstMenu,22,25, "                                   ");
        ShowMsg(pstMenu,23,25, "                                   ");
        CpyItem2BrhField( pstMenu, stEditList, iNoEditItem, pstCurBrhNode );
        ShowTrmMntMenu( pstMenu, pstCurBrhNode );
        iRc = RetrieveTrmData( pstCurBrhNode );
        if (iRc !=0) {
          ShowMsg(pstMenu,23,25,"Retrieve Terminal Failure!!");
        }
        pstCurTrmNode  = pstCurBrhNode->pstTrmHead ;
        pstNextTrmNode = pstCurBrhNode->pstTrmHead->next ;
        ShowTrmRecord( pstMenu->pstNextMenu, pstCurTrmNode );
        iRc = EditTrm( pstMenu, pstCurBrhNode, pstCurTrmNode );
        while (iRc != 0) {
          ShowMsg(pstMenu->pstNextMenu,22,25, 
                  "                                      ");
          ShowMsg(pstMenu->pstNextMenu,23,25, 
                  "                                      ");

          if (iRc == 1) {  /* show the next terminal */
            if (pstNextTrmNode != NULL) {
              pstCurTrmNode  = pstNextTrmNode;
              pstNextTrmNode = pstCurTrmNode->next ;
            }
            if (pstNextTrmNode == NULL) {
              ShowMsg(pstMenu->pstNextMenu,23,25,"There's No Next Terminal!!");
            }

            ShowTrmRecord( pstMenu->pstNextMenu, pstCurTrmNode );
            iRc = EditTrm( pstMenu, pstCurBrhNode, pstCurTrmNode );
          }
          else {  /* show the previous terminal */
            pstNextTrmNode = pstCurTrmNode;
            pstCurTrmNode  = pstCurTrmNode->prev ;
            if (pstCurTrmNode == NULL) {
              pstCurTrmNode  = pstNextTrmNode;
              pstNextTrmNode = pstCurTrmNode->next ;
              ShowMsg(pstMenu->pstNextMenu,23,25,
                      "There's No Previous Terminal!!");
            }

            ShowTrmRecord( pstMenu->pstNextMenu, pstCurTrmNode );
            iRc = EditTrm( pstMenu, pstCurBrhNode, pstCurTrmNode );
          } /* FOR if (iRc == 1) */
        } /* FOR while (iRc != 0) */
        break;
      case '\x1b' :  /* ESC */
        ProcessBrhEscCmd1( pstMenu, pstCurBrhNode, stEditList, iNoEditItem );
        break;
      case 0x0797 :   /* ENTER */
      case CR :   /* ENTER */
        CpyBrhRec2Item( pstMenu, pstCurBrhNode );
        ShowBrhEdtField( pstMenu, stEditList );
        pstCurBrhNode = EditBrh( pstMenu, pstCurBrhNode,
                                 stEditList, iNoEditItem );
        break;
      default:
        beep();
        break;
    }
  }
}

int AddCh( pstMenu, iIndex, iKeyIn, iInsert )
struct stMenuBit *pstMenu;
int iIndex;
int iKeyIn;
int iInsert;
{
  int i;
  int iMaxCol, iCurRow, iCurCol;
  char cCh;
  WINDOW *pwWin;

  pwWin = pstMenu->pwWin;
  iMaxCol = pstMenu->pstItem[ iIndex ].iCol +
            pstMenu->pstItem[ iIndex ].iLength;
  getyx( pwWin, iCurRow, iCurCol );
  if ( iCurCol < iMaxCol ) {
    wattron( pwWin, A_STANDOUT );
    if (iInsert) {
      for (i = iMaxCol - 2; i >= iCurCol; i --) {
        cCh = mvwinch( pwWin, iCurRow, i );
        mvwaddch( pwWin, iCurRow, i + 1, cCh );
      }
      mvwaddch( pwWin, iCurRow, iCurCol, iKeyIn );
      wmove( pwWin, iCurRow, iCurCol );
    }
    else {
      waddch( pwWin, iKeyIn );
    }

    if ( iCurCol == iMaxCol - 1 ) {
      wmove( pwWin, iCurRow, iCurCol );
      beep();
    }
    wattroff( pwWin, A_STANDOUT );
  }
}

int Interrupt()
{
  endwin();
  exit( 1 );
}



int CpyBrhRec2Item( pstMenu, pstBrhRecord )
struct stMenuBit *pstMenu;
struct BrhArea *pstBrhRecord;
{
  char  cStatus;
  char  caTmpBuf[24];

  memset(caTmpBuf,' ',24);
  cStatus = pstBrhRecord->cBrhStatus ;

  if ( (cStatus & ON_TXN) != 0  )  
    caTmpBuf[1] = 'Y';
  else
    caTmpBuf[1] = 'N';

  if ( (cStatus & NO_PAYUP) != 0  )  
    caTmpBuf[4] = 'Y';
  else
    caTmpBuf[4] = 'N';

  if ( (cStatus & BACK_SEND) != 0  )  
    caTmpBuf[7] = 'Y';
  else
    caTmpBuf[7] = 'N';

  if ( (cStatus & LINK_CENTER) != 0  )  
    caTmpBuf[10] = 'Y';
  else
    caTmpBuf[10] = 'N';

/*  following are reserverd for future use */
    caTmpBuf[13]  = '*';
    caTmpBuf[16] = '*';
    caTmpBuf[19] = '*';
    caTmpBuf[22] = '*';

  memcpy( pstMenu->pstItem[ BRH_STATUS ].caData, caTmpBuf,
          pstMenu->pstItem[ BRH_STATUS ].iLength );
  memcpy( pstMenu->pstItem[ BRH_ID ].caData, pstBrhRecord->caBrhId,
          pstMenu->pstItem[ BRH_ID ].iLength );
  memcpy( pstMenu->pstItem[ BRCH_CLS_TIME ].caData, pstBrhRecord->caBrchClsTime,
          pstMenu->pstItem[ BRCH_CLS_TIME ].iLength );
  memcpy( pstMenu->pstItem[ TXN_DATE ].caData, pstBrhRecord->caTxnDate,
          pstMenu->pstItem[ TXN_DATE ].iLength );
  memcpy( pstMenu->pstItem[ NXT_TXN_DATE ].caData, pstBrhRecord->caNxtTxnDate,
          pstMenu->pstItem[ NXT_TXN_DATE ].iLength );
  memcpy( pstMenu->pstItem[ NNXT_TXN_DATE ].caData, pstBrhRecord->caNNxtTxnDate,
          pstMenu->pstItem[ NNXT_TXN_DATE ].iLength );
  sprintf( pstMenu->pstItem[ NO_OF_TERM ].caData, "%*d",
           pstMenu->pstItem[ NO_OF_TERM ].iLength, pstBrhRecord->iNoOfTerm );
  sprintf( pstMenu->pstItem[ TERM_OFFSET ].caData, "%*d",
           pstMenu->pstItem[ TERM_OFFSET ].iLength, pstBrhRecord->iTermOffset );
}

int ShowBrhRecord( pstMenu, pstCurBrhNode, iAttr )
struct stMenuBit *pstMenu;
struct stBrhNode *pstCurBrhNode;
int iAttr;  /* terminal attribute */
{
  int i;
  int iCurRow=0, iCurNodeIdx=0, iMoreNode=0, iCurPage=0;
  WINDOW *pwWin;
  char cCh, cAttr;
  struct stItem *pstItem;
  static int iLowBound = 1;          /* low bound of node index */
  static int iUpBound = PAGE_SIZE;   /* up bounds of node index */
  char caDataBuf[ MAX_DATA_LEN + 1 ];

  pstItem = pstMenu->pstItem;
  pwWin = pstMenu->pwWin;

  iCurNodeIdx = pstCurBrhNode->iNodeIdx;
iMoreNode = pstMenu->iTotalNode - iUpBound;

  if ( iCurNodeIdx < iLowBound ) {
    ScrollBrhRec( pstMenu, pstCurBrhNode, KEY_UP );
    iLowBound --;
    iUpBound -- ;
    iMoreNode = pstMenu->iTotalNode - iUpBound;
    if ( iMoreNode != 0 ) {
      mvwprintw( pwWin, 5 + PAGE_SIZE, 6, "[ %d more ]   ", iMoreNode );
    }
    else {
      mvwprintw( pwWin, 5 + PAGE_SIZE, 6, "                 " );
    }
    iCurPage =  (iUpBound / PAGE_SIZE) +
               ((iUpBound % PAGE_SIZE) ? 1 : 0);
    mvwprintw( pwWin, 19, 65, "%4d/%4d", iCurPage, g_iTotBrhPage );
    wmove( pwWin, 5, COLS - 1 );
  }
  else if ( iCurNodeIdx > iUpBound ) {
    ScrollBrhRec( pstMenu, pstCurBrhNode, KEY_DOWN );
    iLowBound ++ ;
    iUpBound ++ ;
    iMoreNode = pstMenu->iTotalNode - iUpBound;
    if ( iMoreNode != 0 ) {
      mvwprintw( pwWin, 5 + PAGE_SIZE, 6, "[ %d more ]   ", iMoreNode );
    }
    else {
      mvwprintw( pwWin, 5 + PAGE_SIZE, 6, "                 " );
    }
    iCurPage =  (iUpBound / PAGE_SIZE) +
               ((iUpBound % PAGE_SIZE) ? 1 : 0);
    mvwprintw( pwWin, 19, 65, "%4d/%4d", iCurPage, g_iTotBrhPage );
    wmove( pwWin, 5 + PAGE_SIZE - 1, COLS - 1 );
  }
  else {
    iCurRow = pstItem->iRow + ( iCurNodeIdx - iLowBound );
    wattron( pwWin, iAttr );
    for (i = 0; i < COLS; i ++) {
      cCh = mvwinch( pwWin, iCurRow, i );
      mvwaddch( pwWin, iCurRow, i, cCh );
    }
    wattroff( pwWin, iAttr );
    iCurPage =  (iUpBound / PAGE_SIZE) +
               ((iUpBound % PAGE_SIZE) ? 1 : 0);
    mvwprintw( pwWin, 19, 65, "%4d/%4d", iCurPage, g_iTotBrhPage );
    wmove( pwWin, iCurRow, COLS - 1);
  }
}

int ProcessBrhEscCmd1( pstMenu, pstCurBrhNode, stEditList, iNoEditItem )
struct stMenuBit *pstMenu;
struct stBrhNode *pstCurBrhNode;
struct stEditItem stEditList[];
int iNoEditItem;
{
  int iKeyIn;
  int iRc;
  struct stTrmNode *pstCurTrmNode;
  struct stTrmNode *pstNextTrmNode;
  int    iCurRow,iCurCol;
  
  keypad(pstMenu->pwWin,TRUE);
  /* get key and process */
  iKeyIn = wgetch(pstMenu->pwWin);
  switch( iKeyIn ) {
    case '\x1b' :
      EndTool( pstMenu );
      break;
    case '1' :     /* has the same function as F1 key if F1 key is disable */
      CallHelp();
      break;
    case '2' :     /* has the same function as F2 key if F2 key is disable */
/*      InsertData( pstMenu );   */
      break;
    case '3' :     /* has the same function as F3 key if F3 key is disable */
/*      DeleteData( pstMenu );   */
      break;
    case '4' :     /* has the same function as F4 key if F4 key is disable */
      getyx( pstMenu->pwWin, iCurRow, iCurCol );
      UpdateData( pstMenu );   
      ShowMsg(pstMenu,23,25, "                                            ");
      wmove( pstMenu->pwWin, iCurRow, iCurCol);
      break;
    case '5' :     /* has the same function as F5 key if F5 key is disable */
      getyx( pstMenu->pwWin, iCurRow, iCurCol );
      ShowMsg(pstMenu,23,25, "                                            ");
      wmove( pstMenu->pwWin, iCurRow, iCurCol);

      CpyItem2BrhField( pstMenu, stEditList, iNoEditItem, pstCurBrhNode );
      ShowTrmMntMenu( pstMenu, pstCurBrhNode );
      iRc = RetrieveTrmData( pstCurBrhNode );
      if (iRc !=0) {
        ShowMsg(pstMenu,23,25, "Retrieve Terminal Failure!!");
      }
      pstCurTrmNode  = pstCurBrhNode->pstTrmHead ;
      pstNextTrmNode = pstCurBrhNode->pstTrmHead->next ;
      ShowTrmRecord( pstMenu->pstNextMenu, pstCurTrmNode );
      iRc = EditTrm( pstMenu, pstCurBrhNode, pstCurTrmNode );
      while (iRc != 0) {
        ShowMsg(pstMenu->pstNextMenu,23,25,
                "                                        ");
                 
        if (iRc == 1) {  /* show the next terminal */
          if (pstNextTrmNode != NULL) {
            pstCurTrmNode  = pstNextTrmNode;
            pstNextTrmNode = pstCurTrmNode->next ;
          }
          if (pstNextTrmNode == NULL) {
            ShowMsg(pstMenu->pstNextMenu,23,25,
                    "There's No Next Terminal!!");
          }

          CpyTrmRec2Item( pstMenu->pstNextMenu, &pstCurTrmNode->stTrmRecord );
          ShowTrmRecord( pstMenu->pstNextMenu, pstCurTrmNode );
          iRc = EditTrm( pstMenu, pstCurBrhNode, pstCurTrmNode );
        }
        else {  /* show the previous terminal */
          pstNextTrmNode = pstCurTrmNode;
          pstCurTrmNode  = pstCurTrmNode->prev ;
          if (pstCurTrmNode == NULL) {
            pstCurTrmNode  = pstNextTrmNode;
            pstNextTrmNode = pstCurTrmNode->next ;
            ShowMsg(pstMenu->pstNextMenu,23,25,
                    "There's No Previous Terminal!!");
                       
          }

          CpyTrmRec2Item( pstMenu->pstNextMenu, &pstCurTrmNode->stTrmRecord );
          ShowTrmRecord( pstMenu->pstNextMenu, pstCurTrmNode );
          iRc = EditTrm( pstMenu, pstCurBrhNode, pstCurTrmNode );
        } /* FOR if (iRc == 1) */
      } /* FOR while (iRc != 0) */
      ShowMsg(pstMenu->pstNextMenu,23,25,
              "                                        ");
      break;
    case '6' :     /* has the same function as F6 key if F6 key is disable */
      break;
    case '7' :     /* has the same function as F7 key if F7 key is disable */
      break;
  }
}

int ProcessBrhEscCmd2( pstMenu, pstCurBrhNode, stEditList, iNoEditItem, iIndex )
struct stMenuBit *pstMenu;
struct stBrhNode *pstCurBrhNode;
struct stEditItem stEditList[];
int iNoEditItem;
int iIndex;
{
  int iKeyIn;
  int iRc;
  struct stTrmNode *pstCurTrmNode;
  struct stTrmNode *pstNextTrmNode;
  int    iCurRow,iCurCol;
  int iIdx;
  
  keypad(pstMenu->pwWin,TRUE);
  /* get key and process */
  iKeyIn = wgetch(pstMenu->pwWin);
  switch( iKeyIn ) {
    case '\x1b' :
      EndTool( pstMenu );
      break;
    case '1' :     /* has the same function as F1 key if F1 key is disable */
      CallHelp();
      break;
    case '2' :     /* has the same function as F2 key if F2 key is disable */
/*      InsertData( pstMenu );   */
      break;
    case '3' :     /* has the same function as F3 key if F3 key is disable */
/*      DeleteData( pstMenu );   */
      break;
    case '4' :     /* has the same function as F4 key if F4 key is disable */
      break;
    case '5' :     /* has the same function as F5 key if F5 key is disable */
      getyx( pstMenu->pwWin, iCurRow, iCurCol );
      ShowMsg(pstMenu,23,25, "                                            ");
      wmove( pstMenu->pwWin, iCurRow, iCurCol);

      CpyItem2BrhField( pstMenu, stEditList, iNoEditItem, pstCurBrhNode );
      ShowTrmMntMenu( pstMenu, pstCurBrhNode );
      iRc = RetrieveTrmData( pstCurBrhNode );
      if (iRc !=0) {
        ShowMsg(pstMenu,23,25, "Retrieve Terminal Failure!!");
      }
      pstCurTrmNode  = pstCurBrhNode->pstTrmHead ;
      pstNextTrmNode = pstCurBrhNode->pstTrmHead->next ;
      ShowTrmRecord( pstMenu->pstNextMenu, pstCurTrmNode );
      iRc = EditTrm( pstMenu, pstCurBrhNode, pstCurTrmNode );
      while (iRc != 0) {
        ShowMsg(pstMenu->pstNextMenu,23,25,
                "                                        ");
                 
        if (iRc == 1) {  /* show the next terminal */
          if (pstNextTrmNode != NULL) {
            pstCurTrmNode  = pstNextTrmNode;
            pstNextTrmNode = pstCurTrmNode->next ;
          }
          if (pstNextTrmNode == NULL) {
            ShowMsg(pstMenu->pstNextMenu,23,25,
                    "There's No Next Terminal!!");
          }

          CpyTrmRec2Item( pstMenu->pstNextMenu, &pstCurTrmNode->stTrmRecord );
          ShowTrmRecord( pstMenu->pstNextMenu, pstCurTrmNode );
          iRc = EditTrm( pstMenu, pstCurBrhNode, pstCurTrmNode );
        }
        else {  /* show the previous terminal */
          pstNextTrmNode = pstCurTrmNode;
          pstCurTrmNode  = pstCurTrmNode->prev ;
          if (pstCurTrmNode == NULL) {
            pstCurTrmNode  = pstNextTrmNode;
            pstNextTrmNode = pstCurTrmNode->next ;
            ShowMsg(pstMenu->pstNextMenu,23,25,
                    "There's No Previous Terminal!!");
                       
          }

          CpyTrmRec2Item( pstMenu->pstNextMenu, &pstCurTrmNode->stTrmRecord );
          ShowTrmRecord( pstMenu->pstNextMenu, pstCurTrmNode );
          iRc = EditTrm( pstMenu, pstCurBrhNode, pstCurTrmNode );
        } /* FOR if (iRc == 1) */
      } /* FOR while (iRc != 0) */
      ShowMsg(pstMenu->pstNextMenu,23,25,
              "                                        ");
      break;
    case '6' :     /* has the same function as F6 key if F6 key is disable */
      return( ESC_6 );
    case '7' :     /* has the same function as F7 key if F7 key is disable */
      return( ESC_7 );
  }
  return( '0' );
}

int ProcessTrmEscCmd( pstMenu, pstCurBrhNode, pstCurTrmNode, iIndex )
struct stMenuBit *pstMenu;
struct stBrhNode *pstCurBrhNode;
struct stTrmNode *pstCurTrmNode;
int iIndex;
{
  int iKeyIn;
  int iRc;

  keypad(pstMenu->pwWin,TRUE);
  /* get key and process */
  iKeyIn = wgetch(pstMenu->pwWin);
  switch( iKeyIn ) {
    case '\x1b' :
      EndEditTrm( pstMenu, pstCurBrhNode );
      break;
    case '1' :     /* has the same function as F1 key if F1 key is disable */
      CallHelp();
      break;
    case '2' :     /* has the same function as F2 key if F2 key is disable */
/*      UpdateData( pstMenu );   */
      break;
    case '3' :     /* has the same function as F3 key if F3 key is disable */
      break;
    case '4' :     /* has the same function as F4 key if F4 key is disable */
      iRc = ChkRtn(pstMenu->pstNextMenu, iIndex);
      /* iRc == 1 represents check ok !! */
      if (iRc == 1) {
        UptTrmItmField(pstMenu->pstNextMenu);
        UpdateTrmData( pstMenu, pstCurTrmNode, pstCurBrhNode ); 
      }
      break;
  }
  return( iKeyIn );
}

struct stBrhNode *EditBrh( pstMenu, pstCurBrhNode, stEditList, iNoEditItem )
struct stBrhNode *pstCurBrhNode;
struct stMenuBit *pstMenu;
struct stEditItem stEditList[];
int iNoEditItem;
{
  int iKeyIn;
  int iCurRow, iCurCol, iMaxCol;
  int iInsert; /* insert / replace flag */
  int iIndex;  /* current editable item's index for stRecord */
  int iIdx;    /* current editable item's index for stEditList */
  int iRc;
  WINDOW *pwWin;
  char cEscCmd;

  iInsert = 0;
  iIdx = 0;
  iIndex = stEditList[ iIdx ].iIndex;
  pwWin = pstMenu->pwWin;
  getyx( pwWin, iCurRow, iCurCol );
/*
  wattron( pwWin, BCOLOR_BLACK | COLOR_WHITE );
*/
  wattron( pwWin, A_NORMAL );
  mvwaddstr( pwWin, 21, 0, EDIT_OPTIONS );
/*
  wattroff( pwWin, BCOLOR_BLACK | COLOR_WHITE );
*/
  wattroff( pwWin, A_NORMAL );
  wmove( pwWin, iCurRow, iCurCol );
  keypad(pstMenu->pwWin,TRUE);

  while (1) {
    /* to refresh screen */
    wrefresh( pwWin );

    /* get key and process */
    iKeyIn = wgetch(pstMenu->pwWin);
    switch( iKeyIn ) {
      case KEY_UP :
        iRc = ChkRtn(pstMenu, stEditList[ iIdx ].iIndex);
        /* iRc == 1 represents check ok !! */
        if (iRc == 1) {
          UptBrhItmField(pstMenu,pstCurBrhNode);
        } else {   /* still stay in the same field */
          iIndex = stEditList[ iIdx ].iIndex;
          iCurCol = pstMenu->pstItem[ iIndex ].iCol;
          wmove(pwWin, iCurRow, iCurCol);
          break;
        }

        if (iIdx > 0) {
          getyx( pwWin, iCurRow, iCurCol );
          iIdx--;
          iIndex = stEditList[ iIdx ].iIndex;
          iCurCol = pstMenu->pstItem[ iIndex ].iCol;
          wmove(pwWin, iCurRow, iCurCol);
        }
        else {
          CpyItem2BrhField( pstMenu, stEditList, iNoEditItem, pstCurBrhNode );
          if ( pstCurBrhNode->next != NULL ) {
            pstCurBrhNode = MvBrhRecord( pstMenu, pstCurBrhNode, KEY_UP );
          }
          else {
            ShowBrhRecord( pstMenu, pstCurBrhNode, A_STANDOUT );
            beep();
          }
          getyx( pwWin, iCurRow, iCurCol );
          wattron( pwWin, A_NORMAL );
          mvwaddstr( pwWin, 21, 0, EDIT_OPTIONS_BLANK );
          wattroff( pwWin, A_NORMAL );
          wmove( pwWin, iCurRow, iCurCol );
    /*      return( pstCurBrhNode ); */
        }
        break;
      case KEY_DOWN :
      case 0x0797 :   /* ENTER */
      case CR :   /* ENTER */
        iRc = ChkRtn(pstMenu, stEditList[ iIdx ].iIndex);
        /* iRc == 1 represents check ok !! */
        if (iRc == 1) {
          UptBrhItmField(pstMenu,pstCurBrhNode); 
        } else {   /* still stay in the same field */
          iIndex = stEditList[ iIdx ].iIndex;
          iCurCol = pstMenu->pstItem[ iIndex ].iCol;
          wmove(pwWin, iCurRow, iCurCol);
          break;
        }

        if (iIdx < iNoEditItem - 1) {
          getyx( pwWin, iCurRow, iCurCol );
          iIdx++;
          iIndex = stEditList[ iIdx ].iIndex;
          iCurCol = pstMenu->pstItem[ iIndex ].iCol;
          wmove(pwWin, iCurRow, iCurCol);
        }
        else {
          CpyItem2BrhField( pstMenu, stEditList, iNoEditItem, pstCurBrhNode );
          if ( pstCurBrhNode->next != NULL ) {
            pstCurBrhNode = MvBrhRecord( pstMenu, pstCurBrhNode, KEY_DOWN );
          }
          else {
            ShowBrhRecord( pstMenu, pstCurBrhNode, A_STANDOUT );
            beep();
          }
          getyx( pwWin, iCurRow, iCurCol );
          wattron( pwWin, A_NORMAL );
          mvwaddstr( pwWin, 21, 0, EDIT_OPTIONS_BLANK );
          wattroff( pwWin, A_NORMAL );
          wmove( pwWin, iCurRow, iCurCol );
          return( pstCurBrhNode );
        }
        break;
      case KEY_LEFT :
        iIdx = MvBrhField( pstMenu, stEditList, iIdx, iNoEditItem, KEY_LEFT );
        iIndex = stEditList[ iIdx ].iIndex;
        break;
      case KEY_RIGHT :
        iIdx=MvBrhField( pstMenu, stEditList, iIdx, iNoEditItem, KEY_RIGHT );
        iIndex=stEditList[ iIdx ].iIndex;
        break;
      case KEY_HOME :
      case CTL_H  :
        getyx( pstMenu->pwWin, iCurRow, iCurCol );
        if ( iCurCol > pstMenu->pstItem[ iIndex ].iCol ) {
          wmove( pstMenu->pwWin, iCurRow, pstMenu->pstItem[ iIndex ].iCol );
        }
        else {
          beep();
        }
        break;
      case CTL_I :    /* Ctrl + i */
        iInsert = ToggleInsMode( pwWin, iInsert );
        break;
      case CTL_D :    /* Ctrl + d */
        DeleteCh( pstMenu, iIndex );
        break;
      case CTL_U :    /* Ctrl + u */
        Undo( pstMenu, iIndex );
        break;
      case CTL_K  :
      case KEY_BACKSPACE :   
        Backspace( pstMenu, iIndex );
        break;
      case 0x05 :    /* Ctrl + e */
        getyx( pstMenu->pwWin, iCurRow, iCurCol );
        if ( iCurCol < pstMenu->pstItem[ iIndex ].iCol +
                       pstMenu->pstItem[ iIndex ].iLength - 1 ) {
          wmove( pstMenu->pwWin, iCurRow, 
                 pstMenu->pstItem[ iIndex ].iCol +
                 pstMenu->pstItem[ iIndex ].iLength - 1);
        }
        else {
          beep();
        }
        break;
      case '\x1b' :  /* ESC */
        cEscCmd = ProcessBrhEscCmd2( pstMenu, pstCurBrhNode, stEditList,
                          iNoEditItem, stEditList[ iIdx ].iIndex );
        switch (cEscCmd) {
          case ESC_6:
            iRc = ChkRtn(pstMenu, stEditList[ iIdx ].iIndex);
            /* iRc == 1 represents check ok !! */
            if (iRc == 1) {
              UptBrhItmField(pstMenu,pstCurBrhNode);
            } else {   /* still stay in the same field */
              iIndex = stEditList[ iIdx ].iIndex;
              iCurCol = pstMenu->pstItem[ iIndex ].iCol;
              wmove(pwWin, iCurRow, iCurCol);
              break;
            }

            if (iIdx > 0) {
              getyx( pwWin, iCurRow, iCurCol );
              iIdx--;
              iIndex = stEditList[ iIdx ].iIndex;
              iCurCol = pstMenu->pstItem[ iIndex ].iCol;
              wmove(pwWin, iCurRow, iCurCol);
            }
            else {
              CpyItem2BrhField( pstMenu, stEditList, iNoEditItem, pstCurBrhNode );
              if ( pstCurBrhNode->next != NULL ) {
                pstCurBrhNode = MvBrhRecord( pstMenu, pstCurBrhNode, KEY_DOWN );
              }
              else {
                ShowBrhRecord( pstMenu, pstCurBrhNode, A_STANDOUT );
                beep();
              }
              getyx( pwWin, iCurRow, iCurCol );
              wattron( pwWin, A_NORMAL );
              mvwaddstr( pwWin, 21, 0, EDIT_OPTIONS_BLANK );
              wattroff( pwWin, A_NORMAL );
              wmove( pwWin, iCurRow, iCurCol );
              return( pstCurBrhNode );
            }
            break;
          case ESC_7:
            iRc = ChkRtn(pstMenu, stEditList[ iIdx ].iIndex);
            /* iRc == 1 represents check ok !! */
            if (iRc == 1) {
              UptBrhItmField(pstMenu,pstCurBrhNode);
            } else {   /* still stay in the same field */
              iIndex = stEditList[ iIdx ].iIndex;
              iCurCol = pstMenu->pstItem[ iIndex ].iCol;
              wmove(pwWin, iCurRow, iCurCol);
              break;
            }

            if (iIdx < iNoEditItem - 1) {
              getyx( pwWin, iCurRow, iCurCol );
              iIdx++;
              iIndex = stEditList[ iIdx ].iIndex;
              iCurCol = pstMenu->pstItem[ iIndex ].iCol;
              wmove(pwWin, iCurRow, iCurCol);
            }
            else {
              CpyItem2BrhField( pstMenu, stEditList, iNoEditItem, pstCurBrhNode );
              if ( pstCurBrhNode->next != NULL ) {
                pstCurBrhNode = MvBrhRecord( pstMenu, pstCurBrhNode, KEY_DOWN );
              }
              else {
                ShowBrhRecord( pstMenu, pstCurBrhNode, A_STANDOUT );
                beep();
              }
              getyx( pwWin, iCurRow, iCurCol );
              wattron( pwWin, A_NORMAL );
              mvwaddstr( pwWin, 21, 0, EDIT_OPTIONS_BLANK );
              wattroff( pwWin, A_NORMAL );
              wmove( pwWin, iCurRow, iCurCol );
              return( pstCurBrhNode );
            }
        }
        break;
      default :
        AddCh( pstMenu, iIndex, iKeyIn, iInsert );
        break;
    }
  }
}

int ShowBrhEdtField( pstMenu, stEditList )
struct stMenuBit *pstMenu;
struct stEditItem stEditList[];
{
  int i, j;
  int iCurRow, iCurCol;
  char cAttr;
  char cCh;
  WINDOW *pwWin;

  pwWin = pstMenu->pwWin;
  getyx( pwWin, iCurRow, iCurCol );

/*
  wattron( pwWin, BCOLOR_BLACK | COLOR_WHITE );
*/
  wattron( pwWin, A_NORMAL );
  for ( i = 0; i < COLS; i ++ ) {
    cCh = mvwinch( pwWin, iCurRow, i );
    mvwaddch( pwWin, iCurRow, i, cCh );
  }
/*
  wattroff( pwWin, BCOLOR_BLACK | COLOR_WHITE );
*/
  wattroff( pwWin, A_NORMAL );

  wattron( pwWin, A_STANDOUT );
  for (i = 0; i < NO_ITEM_BRH; i ++) {
    /* to show each field in the branch record */
    cAttr = pstMenu->pstItem[ i ].cAttribute;
    iCurCol = pstMenu->pstItem[ i ].iCol;
    if ( cAttr == 'e' ) {
      for ( j = 0; j < pstMenu->pstItem[ i ].iLength; j ++ ) {
        cCh = mvwinch( pwWin, iCurRow, iCurCol + j );
        mvwaddch( pwWin, iCurRow, iCurCol + j, cCh );
      }
    }
  } /* end for loop */
  wattroff( pwWin, A_STANDOUT );

  wmove( pwWin, iCurRow, pstMenu->pstItem[ stEditList[ 0 ].iIndex ].iCol );
}

int CallHelp()
{
}

int MvBrhField( pstMenu, stEditList, iIdx, iNoEditItem, iDirection )
struct stMenuBit *pstMenu;
struct stEditItem stEditList[];
int iIdx;  /* current editable item's index for stEditList */
int iNoEditItem;
int iDirection;
{
  int iCurRow, iCurCol;
  int iIndex;  /* current editable item's index for stRecord */
  WINDOW *pwWin;
  int iRc;

  iIndex = stEditList[ iIdx ].iIndex;
  pwWin = pstMenu->pwWin;
  getyx( pwWin, iCurRow, iCurCol );
  switch ( iDirection ) {
    case KEY_LEFT :
      if ( iCurCol > pstMenu->pstItem[ iIndex ].iCol ) {
        iCurCol --;
      }
      else {
        iRc = ChkRtn(pstMenu, stEditList[ iIdx ].iIndex);
        /* iRc == 1 represents check ok !! */
        if (iRc == 1) {
          iIdx = (iIdx + iNoEditItem - 1) % iNoEditItem;
          iIndex = stEditList[ iIdx ].iIndex;
          iCurCol = pstMenu->pstItem[ iIndex ].iCol;
        }
        else {
          return( iIdx );
        }
      }
      break;
    case KEY_RIGHT :
      if ( iCurCol < pstMenu->pstItem[ iIndex ].iCol +
                     pstMenu->pstItem[ iIndex ].iLength - 1 ) {
        iCurCol ++;
      }
      else {
        iRc = ChkRtn(pstMenu, stEditList[ iIdx ].iIndex);
        /* iRc == 1 represents check ok !! */
        if (iRc == 1) {
          iIdx = (iIdx + 1) % iNoEditItem;
          iIndex = stEditList[ iIdx ].iIndex;
          iCurCol = pstMenu->pstItem[ iIndex ].iCol;
        }
        else {
          return( iIdx );
        }
      }
      break;
  }
  wmove( pwWin, iCurRow, iCurCol );
  return( iIdx );
}

int MvEdtItem( pstMenu, iIndex, iAttr )
struct stMenuBit *pstMenu;             /*  the Terminal Screen Menu  */
int iIndex;
int iAttr;  /* terminal attribute */
{
  int i;
  int iCurRow, iCurCol;
  int iLength;
  char cCh;
  WINDOW *pwWin;
  struct stItem *pstItem;

  pstItem = (struct stItem *)&(pstMenu->pstItem[ iIndex ]);
  iCurRow = pstItem->iRow;
  iCurCol = pstItem->iCol;
  iLength = pstItem->iLength;
  pwWin = pstMenu->pwWin;

  wattron( pwWin, iAttr );

  for (i = 0; i < iLength; i ++) {
    cCh = mvwinch( pwWin, iCurRow, iCurCol + i );
    mvwaddch( pwWin, iCurRow, iCurCol + i, cCh );
  }
  wmove( pwWin, iCurRow, iCurCol );

  wattroff( pwWin, iAttr );
}

int BuildEdtList( pstMenu, pstEditList, piNoEditItem )
struct stMenuBit *pstMenu;
struct stEditItem *pstEditList;
int *piNoEditItem;
{
  int Compare();
  int i, j;

  for (i = 0, j = 0; i < NO_ITEM_BRH; i ++) {
    if (pstMenu->pstItem[ i ].cAttribute == 'e') {
      pstEditList[ j ].iIndex = i;
      pstEditList[ j ].iRowCol = pstMenu->pstItem[ i ].iRow * 100 +
                                 pstMenu->pstItem[ i ].iCol;
      j ++;
    }
  }

  *piNoEditItem = j;

  qsort( (char *) pstEditList, *piNoEditItem,
         sizeof( struct stEditItem ), Compare );
}

int BuildEdtTrmList( pstMenu, pstEditList, piNoEditItem )
struct stMenuBit *pstMenu;
struct stEditItem *pstEditList;
int *piNoEditItem;
{
  int Compare();
  int i, j;

  for (i = 0, j = 0; i < NO_ITEM_TRM; i ++) {
    if (pstMenu->pstItem[ i ].cAttribute == 'e') {
      pstEditList[ j ].iIndex = i;
      pstEditList[ j ].iRowCol = pstMenu->pstItem[ i ].iRow * 100 +
                                 pstMenu->pstItem[ i ].iCol;
      j ++;
    }
  }

  *piNoEditItem = j;

  qsort( (char *) pstEditList, *piNoEditItem,
         sizeof( struct stEditItem ), Compare );
}

int Compare( pstEditItem1, pstEditItem2 )
struct stEditItem *pstEditItem1;
struct stEditItem *pstEditItem2;
{
  if ( pstEditItem1->iRowCol < pstEditItem2->iRowCol ) {
    return( -1 );
  }
  else if ( pstEditItem1->iRowCol == pstEditItem2->iRowCol ) {
    return( 0 );
  }
  else
    return( 1 );
}

struct stBrhNode *MvBrhRecord( pstMenu, pstCurBrhNode, iDirection )
struct stMenuBit *pstMenu;
struct stBrhNode *pstCurBrhNode;
int iDirection;
{
  struct stBrhNode *pstNextBrhNode;

  if ( pstCurBrhNode != NULL ) {
    switch ( iDirection ) {
      case KEY_UP :
        pstNextBrhNode = pstCurBrhNode->prev;
        break;
      case KEY_DOWN :
        pstNextBrhNode = pstCurBrhNode->next;
        break;
    }

    if ( pstNextBrhNode != NULL ) {
/*
      ShowBrhRecord( pstMenu, pstCurBrhNode, BCOLOR_BLACK | COLOR_WHITE );
*/
      ShowBrhRecord( pstMenu, pstCurBrhNode,  A_NORMAL );
      ShowBrhRecord( pstMenu, pstNextBrhNode, A_STANDOUT );
      return( pstNextBrhNode );
    }
    else {
      beep();
      return( pstCurBrhNode );
    }
  }
  else {
    beep();
    return( pstCurBrhNode );
  }
}

int ScrollBrhRec( pstMenu, pstCurBrhNode, iDirection )
struct stMenuBit *pstMenu;
struct stBrhNode *pstCurBrhNode;
int iDirection;
{
  int i, j;
  int iCurNodeIdx;
  int iCurRow, iRowOffset;
  char cAttr; /* data attribute */
  char cCh, caDataBuf[ MAX_DATA_LEN + 1 ];
  WINDOW *pwWin;
  int iCurPage=0;

  pwWin = pstMenu->pwWin;
/*
  wattrset( pwWin, BCOLOR_BLACK | COLOR_WHITE );
*/
  wattrset( pwWin, A_NORMAL );
  for (j = 0; j < PAGE_SIZE; j ++) {
    CpyBrhRec2Item( pstMenu, &(pstCurBrhNode->stBrhRecord) );
    iCurNodeIdx = pstCurBrhNode->iNodeIdx;

    /* to show each record's index */
    if ( iDirection == KEY_UP ) {
      iRowOffset = j;
      pstCurBrhNode = pstCurBrhNode->next;
    }
    else if ( iDirection == KEY_DOWN ) {
      iRowOffset = PAGE_SIZE - j - 1;
      pstCurBrhNode = pstCurBrhNode->prev;
    }

    mvwprintw( pwWin, 5 + iRowOffset, 0, "%4d", iCurNodeIdx );

    /* to show each record's content */
    for (i = 0; i < NO_ITEM_BRH; i ++) {
      /* to show each field in the branch record */
      cAttr = pstMenu->pstItem[ i ].cAttribute;

      /* for filling '\0' to end a string */
      memcpy( caDataBuf, pstMenu->pstItem[ i ].caData,
              pstMenu->pstItem[ i ].iLength );
      caDataBuf[ pstMenu->pstItem[ i ].iLength ] = '\0';

      if ( cAttr == 'd' || cAttr == 'e' ) {
        iCurRow = pstMenu->pstItem[ i ].iRow;
        mvwaddstr( pwWin, iCurRow + iRowOffset,
                   pstMenu->pstItem[ i ].iCol, caDataBuf );
      }
    } /* end for loop */

  }

  /* to standout the first record */
  if ( iDirection == KEY_UP ) {
    iRowOffset = 0;
  }
  else if ( iDirection == KEY_DOWN ) {
    iRowOffset = PAGE_SIZE - 1;
  }
  wattron( pwWin, A_STANDOUT );
  for (i = 0; i < COLS; i ++) {
    cCh = mvwinch( pwWin, 5 + iRowOffset, i );
    mvwaddch( pwWin, 5 + iRowOffset, i, cCh );
  }
  wattroff( pwWin, A_STANDOUT );
}

int DeleteCh( pstMenu, iIndex )
struct stMenuBit *pstMenu;
int iIndex;
{
  int i;
  int iMaxCol, iCurRow, iCurCol;
  char cCh;

  iMaxCol = pstMenu->pstItem[ iIndex ].iCol +
            pstMenu->pstItem[ iIndex ].iLength;
  getyx( pstMenu->pwWin, iCurRow, iCurCol );
  wattron( pstMenu->pwWin, A_STANDOUT );
  for (i = iCurCol + 1; i <= iMaxCol; i ++) {
    cCh = mvwinch( pstMenu->pwWin, iCurRow, i );
    mvwaddch( pstMenu->pwWin, iCurRow, i - 1, cCh );
  }
  wattroff( pstMenu->pwWin, A_STANDOUT );
  wmove( pstMenu->pwWin, iCurRow, iCurCol );
}

int Backspace( pstMenu, iIndex )
struct stMenuBit *pstMenu;
int iIndex;
{
  int i;
  int iMaxCol, iCurRow, iCurCol;
  char cCh;

  iMaxCol = pstMenu->pstItem[ iIndex ].iCol +
            pstMenu->pstItem[ iIndex ].iLength;
  getyx( pstMenu->pwWin, iCurRow, iCurCol );
  if ( iCurCol == pstMenu->pstItem[ iIndex ].iCol ) {
    beep();
  }
  else {
    wattron( pstMenu->pwWin, A_STANDOUT );
    for (i = iCurCol; i <= iMaxCol; i ++) {
      cCh = mvwinch( pstMenu->pwWin, iCurRow, i );
      mvwaddch( pstMenu->pwWin, iCurRow, i - 1, cCh );
    }
    wattroff( pstMenu->pwWin, A_STANDOUT );
    wmove( pstMenu->pwWin, iCurRow, iCurCol - 1 );
  }
}

int ToggleInsMode( pwWin, iInsert )
WINDOW *pwWin;
int iInsert;
{
  int iCurRow, iCurCol;

  iInsert = 1 - iInsert;
  getyx( pwWin, iCurRow, iCurCol );
/*
  wattron( pwWin, BCOLOR_BLACK | COLOR_WHITE );
*/
  wattron( pwWin, A_NORMAL );
  mvwaddstr( pwWin, 20, 41, (iInsert ? "INS" : "REP") );
/*
  wattroff( pwWin, BCOLOR_BLACK | COLOR_WHITE );
*/
  wattroff( pwWin, A_NORMAL );
  wmove( pwWin, iCurRow, iCurCol );

  return( iInsert );
}

int Undo( pstMenu, iIndex )
struct stMenuBit *pstMenu;
int iIndex;
{
  int i;
  int iCurRow, iCurCol, iMaxCol;
  char caData[ MAX_DATA_LEN + 1 ];
  struct stItem *pstItem;
  WINDOW *pwWin;

  pwWin = pstMenu->pwWin;
  pstItem = (struct stItem *)&(pstMenu->pstItem[ iIndex ]);
  getyx( pwWin, iCurRow, iCurCol );
  iCurCol = pstItem->iCol;
  iMaxCol = iCurCol + pstItem->iLength - 1;
  strncpy( caData, pstItem->caData, pstItem->iLength );
  caData[ pstItem->iLength ] = '\0';
  wattron( pwWin, A_STANDOUT );
  mvwaddstr( pwWin, iCurRow, iCurCol, caData );
  getyx( pwWin, iCurRow, iCurCol );
  if (iCurCol < iMaxCol) {
    for (i = iCurCol; i <= iMaxCol; i ++) {
      mvwaddch( pwWin, iCurRow, i, ' ' );
    }
  }
  wmove( pwWin, iCurRow, pstItem->iCol );
  wattroff( pwWin, A_STANDOUT );
}

int CpyItem2BrhField( pstMenu, stEditList, iNoEditItem, pstCurBrhNode )
struct stMenuBit *pstMenu;
struct stEditItem stEditList[];
int iNoEditItem;
struct stBrhNode *pstCurBrhNode;
{
  int i, j;
  int iCurRow, iCurCol;
  int iIndex, iLength;
  struct stItem *pstItem;
  struct stBIT_BRH *pstBrhRecord;
  WINDOW *pwWin;

  pwWin = pstMenu->pwWin;
  pstItem = pstMenu->pstItem;
  getyx( pwWin, iCurRow, iCurCol );
/*
  for (i = 0; i < iNoEditItem; i ++) {
    iIndex = stEditList[ i ].iIndex;
    iCurCol = pstItem[ iIndex ].iCol;
    iLength = pstItem[ iIndex ].iLength;
    /x copy screen's data to buffer x/
    for (j = 0; j < iLength; j ++) {
      pstItem[ iIndex ].caData[ j ] = mvwinch( pwWin, iCurRow, iCurCol + j );
    }
  } /x end for loop x/
*/
  for (i = 0; i < NO_ITEM_BRH; i ++) {
    iCurCol = pstItem[ i ].iCol;
    iLength = pstItem[ i ].iLength;
    for (j = 0; j < iLength; j ++) {
      pstItem[ i ].caData[ j ] = mvwinch( pwWin, iCurRow, iCurCol + j );
    }
  }


  /* copy buffer's data to the current branch node */
/*
  pstBrhRecord = &(pstCurBrhNode->stBrhRecord);
  memcpy( &(pstBrhRecord->cBrhStatus), pstItem[ BRH_STATUS ].caData,
          pstItem[ BRH_STATUS ].iLength );
  memcpy( pstBrhRecord->caBrhId, pstItem[ BRH_ID ].caData,
          pstItem[ BRH_ID ].iLength );
  memcpy( pstBrhRecord->caBrchClsTime, pstItem[ BRCH_CLS_TIME ].caData,
          pstItem[ BRCH_CLS_TIME ].iLength );
  memcpy( pstBrhRecord->caTxnDate, pstItem[ TXN_DATE ].caData,
          pstItem[ TXN_DATE ].iLength );
  memcpy( pstBrhRecord->caNxtTxnDate, pstItem[ NXT_TXN_DATE ].caData,
          pstItem[ NXT_TXN_DATE ].iLength );
  memcpy( pstBrhRecord->caNNxtTxnDate, pstItem[ NNXT_TXN_DATE ].caData,
          pstItem[ NNXT_TXN_DATE ].iLength );
  pstBrhRecord->iNoOfTerm = atoi( pstItem[ NO_OF_TERM ].caData );
  pstBrhRecord->iTermOffset = atoi( pstItem[ TERM_OFFSET ].caData );
*/
}

int ShowTrmMntMenu( pstMenu, pstCurBrhNode )
struct stMenuBit *pstMenu;
struct stBrhNode *pstCurBrhNode;
{
  int i;
  char cAttr;
  char caDataBuf[ MAX_DATA_LEN + 1 ]; /* add a space to contain '\0' */
  WINDOW *pwWin;
  char   caTmpBuf[20];
  char   caDateBuf[11]="//////////";

  pwWin = pstMenu->pstNextMenu->pwWin;
  /* to show the current branch data as title */
  /* to show each record's index */
  mvwprintw( pwWin, 4, 0, "%4d ", pstCurBrhNode->iNodeIdx );
  /* to show total number of terminals of this branch */
  mvwprintw( pwWin, 20, 70, "%2d", pstCurBrhNode->stBrhRecord.iNoOfTerm );

  strncpy( caTmpBuf, sg_stSsaArea.caTxnDate,8 );
  memcpy( caDateBuf,caTmpBuf,4);
  memcpy( caDateBuf+5,caTmpBuf+4,2);
  memcpy( caDateBuf+8,caTmpBuf+6,2);
  caDateBuf[10] = '\0';
  mvwaddstr( pwWin, 0, 65, caDateBuf);

  /* to show each record's content */
  for (i = 0; i < NO_ITEM_BRH; i ++) {
    /* to show each field in the branch record */
    cAttr = pstMenu->pstItem[ i ].cAttribute;

    memset( caDataBuf, 0, sizeof(caDataBuf));
    memcpy( caDataBuf, pstMenu->pstItem[ i ].caData,
            pstMenu->pstItem[ i ].iLength );
    caDataBuf[ pstMenu->pstItem[ i ].iLength ] = '\0';

    if ( cAttr == 'd' || cAttr == 'e' ) {
      mvwaddstr( pwWin, 4, pstMenu->pstItem[ i ].iCol, caDataBuf );
    }
  } /* end for loop */
  touchwin( pwWin );
  wrefresh( pwWin );
}

 
int EditTrm( pstBrhMenu, pstCurBrhNode, pstCurTrmNode )
struct stMenuBit *pstBrhMenu;
struct stBrhNode *pstCurBrhNode;
struct stTrmNode *pstCurTrmNode;
{
  int iKeyIn;
  int iCurRow, iCurCol, iMaxCol;
  int iInsert; /* insert / replace flag */
  int iIndex;  /* current editable item's index for stRecord */
  int iIdx;    /* current editable item's index for stEditList */
  int iNoEditItem;
  int iRc;
  struct stEditItem stEditList[ NO_ITEM_TRM ];
  struct stMenuBit *pstMenu;
  WINDOW *pwWin;

  iInsert = 0;
  pstMenu = pstBrhMenu->pstNextMenu;
  pwWin = pstMenu->pwWin;
  BuildEdtTrmList( pstMenu, stEditList, &iNoEditItem );
  iIdx = 0;
  iIndex = stEditList[ iIdx ].iIndex;

  mvwprintw( pwWin, 20, 57, "%2d", iIdx + 1 );
  MvEdtItem( pstMenu, iIndex, A_STANDOUT );
  keypad(pstMenu->pwWin,TRUE);

  while (1) {
    /* to refresh screen */
    wrefresh( pwWin );

    /* get key and process */
    iKeyIn = wgetch(pstMenu->pwWin);
    switch( iKeyIn ) {
      case KEY_UP :
        iRc = ChkRtn(pstMenu, stEditList[ iIdx ].iIndex);
        /* iRc == 1 represents check ok !! */
        if (iRc == 1) {
          UptTrmItmField(pstMenu);
          iIdx = (iIdx + iNoEditItem - 1) % iNoEditItem;
          mvwprintw( pwWin, 20, 57, "%2d", iIdx + 1 );
          iIndex = stEditList[ iIdx ].iIndex;
          MvEdtItem( pstMenu, iIndex, A_STANDOUT );
          break;
        } else {   /* still stay in the same field */
          iIndex = stEditList[ iIdx ].iIndex;
          iCurRow = pstMenu->pstItem[ iIndex ].iRow;
          iCurCol = pstMenu->pstItem[ iIndex ].iCol;
          wmove(pwWin, iCurRow, iCurCol);
          break;
        }
      case KEY_DOWN :
      case 0x0797 :   /* ENTER */
      case CR :   /* ENTER */
        iRc = ChkRtn(pstMenu, stEditList[ iIdx ].iIndex);
        /* iRc == 1 represents check ok !! */
        if (iRc != 1) {
          /* still stay in the same field */
          iIndex = stEditList[ iIdx ].iIndex;
          iCurRow = pstMenu->pstItem[ iIndex ].iRow;
          iCurCol = pstMenu->pstItem[ iIndex ].iCol;
          wmove(pwWin, iCurRow, iCurCol);
          break;
        }
        UptTrmItmField(pstMenu);
        iIdx = (iIdx + 1) % iNoEditItem;
        mvwprintw( pwWin, 20, 57, "%2d", iIdx + 1 );
        iIndex = stEditList[ iIdx ].iIndex;
        MvEdtItem( pstMenu, iIndex, A_STANDOUT );
        break;
      case KEY_LEFT :
        getyx( pwWin, iCurRow, iCurCol );
        if ( iCurCol > pstMenu->pstItem[ iIndex ].iCol ) {
          wmove( pwWin, iCurRow, iCurCol - 1 );
        }
        else {
          beep();
        }
        break;
      case KEY_RIGHT :
        getyx( pwWin, iCurRow, iCurCol );
        if ( iCurCol < pstMenu->pstItem[ iIndex ].iCol +
                       pstMenu->pstItem[ iIndex ].iLength - 1 ) {
          wmove( pwWin, iCurRow, iCurCol + 1 );
        }
        else {
          beep();
        }
        break;
      case CTL_N :
        return(NEXT_TRM);
      case CTL_P :
        return(PREV_TRM);
      case CTL_I :    /* Ctrl + i */
        iInsert = ToggleInsMode( pwWin, iInsert );
        break;
      case CTL_D :    /* Ctrl + d */
        DeleteCh( pstMenu, iIndex );
        break;
      case CTL_U :    /* Ctrl + u */
        Undo( pstMenu, iIndex );
        break;
      case KEY_HOME :
      case CTL_H  :
        getyx( pstMenu->pwWin, iCurRow, iCurCol );
        if ( iCurCol > pstMenu->pstItem[ iIndex ].iCol ) {
          wmove( pstMenu->pwWin, iCurRow, pstMenu->pstItem[ iIndex ].iCol );
        }
        else {
          beep();
        }
        break;
      case CTL_K  :  /* Backspace */
      case KEY_BACKSPACE :   
        Backspace( pstMenu, iIndex );
        break;
      case 0x05 :    /* Ctrl + e */
        getyx( pstMenu->pwWin, iCurRow, iCurCol );
        if ( iCurCol < pstMenu->pstItem[ iIndex ].iCol +
                       pstMenu->pstItem[ iIndex ].iLength - 1 ) {
          wmove( pstMenu->pwWin, iCurRow, 
                 pstMenu->pstItem[ iIndex ].iCol +
                 pstMenu->pstItem[ iIndex ].iLength - 1);
        }
        else {
          beep();
        }
        break;
      case KEY_F(1) :
        CallHelp();
        break;
      case KEY_F(2) :
/*        UpdateData( pstMenu ); */
        break;
      case '\x1b' :  /* ESC */
        iIndex = stEditList[ iIdx ].iIndex;
        getyx( pwWin, iCurRow, iCurCol );
        iKeyIn = ProcessTrmEscCmd( pstBrhMenu, pstCurBrhNode,
                                   pstCurTrmNode, iIndex );
        if ( iKeyIn == '\x1b' ) { /* the next keyin is ESC */
          ShowMsg(pstMenu,23,25, "                                  ");
          return(0);             /* return to up level menu */
        }
        wmove(pwWin, iCurRow, iCurCol);
        break;
      default :
        AddCh( pstMenu, iIndex, iKeyIn, iInsert );
        break;
    }
  }
}

int EndEditTrm( pstBrhMenu, pstCurBrhNode )
struct stMenuBit *pstBrhMenu;
struct stBrhNode *pstCurBrhNode;
{
/*  ShowMsg(pstBrhMenu,23,25, "                                  "); */
  touchwin( pstBrhMenu->pwWin );
  wrefresh( pstBrhMenu->pwWin );
}

int RetrieveTrmData( pstCurBrhNode )
struct stBrhNode *pstCurBrhNode;
{
  int i;
  int iNoOfTrmRecord;  /* the number of trm records for the current brh node */
  struct stTrmNode *pstCurTrmNode;
  struct stTrmNode *pstTmpTrmNode;
  char   caBitData[DCS_MAX_DATA_LEN];
  int    iRc;
  int    iOffset;

  memset (caBitData, 0, sizeof(caBitData));
  memcpy(caBitData,pstCurBrhNode->stBrhRecord.caBrhId,MAX_BR_LEN);
  SendCmdToMon(&sg_stMonCmd,IN_SUB);
  iRc = GetInfoFmEms(RETRIEVE,BIT_TRM,caBitData);
  if (iRc !=0) {
    return(-1);
  }
  memcpy(&iNoOfTrmRecord,caBitData,4);

  if ( pstCurBrhNode->pstTrmHead != NULL ) {

    pstCurTrmNode = pstCurBrhNode->pstTrmHead;
    for (i = 0; i < iNoOfTrmRecord; i ++) {
      iOffset = 4 + i*sizeof(struct TermArea);
      memcpy (&(pstCurTrmNode->stTrmRecord),
              &caBitData[iOffset], sizeof(struct TermArea));
      pstCurTrmNode = pstCurTrmNode->next;
    }
    return(0);
  }
  else {
    pstCurTrmNode = pstCurBrhNode->pstTrmHead;
    for (i = 0; i < iNoOfTrmRecord; i ++) {
      if ( pstCurTrmNode == NULL ) {
        /* to allocate the first terminal node */
        pstCurTrmNode = (struct stTrmNode *)
                         calloc( sizeof( struct stTrmNode ), 1 );
        pstCurTrmNode->iNodeIdx = i + 1;
        pstCurTrmNode->next = NULL;
        pstCurTrmNode->prev = NULL;
        pstCurBrhNode->pstTrmHead = pstCurTrmNode;
      }
      else {
        /* to allocate the rest terminal nodes */
        pstTmpTrmNode = pstCurTrmNode;
        pstCurTrmNode = (struct stTrmNode *)
                         calloc( sizeof( struct stTrmNode ), 1 );
        pstCurTrmNode->iNodeIdx = i + 1;
        pstCurTrmNode->prev = pstTmpTrmNode;
        pstCurTrmNode->next = NULL;
        pstTmpTrmNode->next = pstCurTrmNode;
      }

      /* to fill data got from EMS server into each terminal record */
      iOffset = 4 + i*sizeof(struct TermArea);
      memcpy (&(pstCurTrmNode->stTrmRecord),
              &caBitData[iOffset], sizeof(struct TermArea));
    } /* FOR for (i = 0; i < iNoOfTrmRecord; i ++) */
  } /* FOR if ( pstCurBrhNode->pstTrmHead != NULL ) */
  return(0);
}

int ShowTrmRecord( pstMenu, pstCurTrmNode )
struct stMenuBit *pstMenu;             /* The Terminal menu structure  */
struct stTrmNode *pstCurTrmNode;
{
  int i;  /* for counting the number of terminal record's field */
  int iNodeIdx;
  int iCurRow, iCurCol;
  char cAttr;
  char caDataBuf[ MAX_DATA_LEN + 1 ]; /* add a space to contain '\0' */
  char caSpaceBuf[ MAX_DATA_LEN + 1 ]; /* add a space to contain '\0' */
  struct stBIT_TRM *pstCurTrmRecord;
  WINDOW *pwWin;

  pwWin = pstMenu->pwWin;

  iNodeIdx = pstCurTrmNode->iNodeIdx;
  pstCurTrmRecord = &(pstCurTrmNode->stTrmRecord);
  CpyTrmRec2Item( pstMenu, pstCurTrmRecord );

  /* to show each terminal's index */
  mvwprintw( pwWin, 20, 65, "%2d", iNodeIdx );

  /* to show each terminal record's content */
  for (i = 0; i < NO_ITEM_TRM; i ++) {
    /* to show each field in the terminal record */
    cAttr = pstMenu->pstItem[ i ].cAttribute;
    /* for filling '\0' to end a string */
    memset( caDataBuf, 0, sizeof(caDataBuf));
    memcpy( caDataBuf, pstMenu->pstItem[ i ].caData,
            pstMenu->pstItem[ i ].iLength );
    caDataBuf[ pstMenu->pstItem[ i ].iLength ] = '\0';
  
    iCurRow = pstMenu->pstItem[ i ].iRow;
    iCurCol = pstMenu->pstItem[ i ].iCol;

    memset(caSpaceBuf,' ',pstMenu->pstItem[ i ].iLength);
    caSpaceBuf[ pstMenu->pstItem[ i ].iLength ] = '\0';
    if ( cAttr == 'd' ) {
      mvwaddstr( pwWin, iCurRow, iCurCol, caSpaceBuf );
      mvwaddstr( pwWin, iCurRow, iCurCol, caDataBuf );
    }
    else if ( cAttr == 'e' ) {
      wattron( pwWin, A_STANDOUT );
      mvwaddstr( pwWin, iCurRow, iCurCol, caSpaceBuf );
      mvwaddstr( pwWin, iCurRow, iCurCol, caDataBuf );
      wattroff( pwWin, A_STANDOUT );
    }
  } /* end for loop */

  wrefresh( pwWin );
}


int CpyTrmRec2Item( pstMenu, pstTrmRecord )
struct stMenuBit *pstMenu;            /* Use The Terminal Menu structure */
struct TermArea *pstTrmRecord;
{
  int   i;
  char  cTermType;
  unsigned char  cStatus;
  char  caTmpBuf[24];

  sprintf( pstMenu->pstItem[ LAST_ONLN_RRN ].caData, "%*d",
           pstMenu->pstItem[ LAST_ONLN_RRN ].iLength,
           pstTrmRecord->lLastOnlnRrn);
  sprintf( pstMenu->pstItem[ LAST_BTCH_RRN ].caData, "%*d",
           pstMenu->pstItem[ LAST_BTCH_RRN ].iLength,
           pstTrmRecord->lLastBtchRrn);
  sprintf( pstMenu->pstItem[ CUR_BTCH_ERR_RRN ].caData, "%*d",
           pstMenu->pstItem[ CUR_BTCH_ERR_RRN ].iLength,
           pstTrmRecord->lCurBtchErrRrn);

  strcpy( pstMenu->pstItem[ LOGIC_ID ].caData, pstTrmRecord->caLogicId);

  strcpy( pstMenu->pstItem[ TERM_ID ].caData, pstTrmRecord->caTermId);

  pstMenu->pstItem[ TERM_TYPE ].caData[0] = pstTrmRecord->cTermType;
  pstMenu->pstItem[ TERM_TYPE ].caData[1] = '\0';

  memset(caTmpBuf, ' ', sizeof(caTmpBuf));
  cStatus = pstTrmRecord->cTermStatus ;

  if ( (cStatus & ON_TXN) != 0  )  
    caTmpBuf[0] = 'Y';
  else
    caTmpBuf[0] = 'N';

  if ( (cStatus & NO_PAYUP) != 0  )  
    caTmpBuf[3] = 'Y';
  else
    caTmpBuf[3] = 'N';

  if ( (cStatus & BACK_SEND) != 0  )  
    caTmpBuf[6] = 'Y';
  else
    caTmpBuf[6] = 'N';

  if ( (cStatus & LINK_CENTER) != 0  )  
    caTmpBuf[9] = 'Y';
  else
    caTmpBuf[9] = 'N';

/*  following are reserverd for future use */
    caTmpBuf[12]  = '*';
    caTmpBuf[15] = '*';
    caTmpBuf[18] = '*';
    caTmpBuf[21] = '*';
/* TCC
  memcpy( pstMenu->pstItem[ TERM_STATUS ].caData, caTmpBuf,
          pstMenu->pstItem[ TERM_STATUS ].iLength );
*/
  memcpy( pstMenu->pstItem[ TERM_STATUS_1 ].caData, caTmpBuf,
          pstMenu->pstItem[ TERM_STATUS_1 ].iLength );
  memcpy( pstMenu->pstItem[ TERM_STATUS_2 ].caData, &caTmpBuf[3],
          pstMenu->pstItem[ TERM_STATUS_2 ].iLength );

  memset (caTmpBuf, ' ', sizeof(caTmpBuf));
  cStatus = pstTrmRecord->cTermMode ;

  if ( (cStatus & LATE_VERIFY) != 0  )  
    caTmpBuf[0] = 'Y';
  else
    caTmpBuf[0] = 'N';

/*  following are reserverd for future use */
    caTmpBuf[3]  = '*';
    caTmpBuf[6]  = '*';
    caTmpBuf[9] = '*';
    caTmpBuf[12] = '*';
    caTmpBuf[15] = '*';
    caTmpBuf[18] = '*';
    caTmpBuf[21] = '*';

  memcpy( pstMenu->pstItem[ TERM_MODE ].caData, caTmpBuf,
          pstMenu->pstItem[ TERM_MODE ].iLength );

  strcpy( pstMenu->pstItem[ BACK_BRH_ID ].caData, pstTrmRecord->caBackBrhId);

  strcpy( pstMenu->pstItem[ BACK_TERM_ID ].caData, pstTrmRecord->caBackTermId);

  sprintf( pstMenu->pstItem[ ACC_TXN_NO ].caData, "%*d",
           pstMenu->pstItem[ ACC_TXN_NO ].iLength, pstTrmRecord->lAccTxnNo );
  sprintf( pstMenu->pstItem[ NON_ACC_TXN_NO ].caData, "%*d",
           pstMenu->pstItem[ NON_ACC_TXN_NO ].iLength,
           pstTrmRecord->lNonAccTxnNo );
  sprintf( pstMenu->pstItem[ BTCH_TXN_NO ].caData, "%*d",
           pstMenu->pstItem[ BTCH_TXN_NO ].iLength,
           pstTrmRecord->lBtchTxnNo );
}

UptBrhItmField(pstMenu,pstBrhNode)
struct stMenuBit *pstMenu;
struct stBrhNode *pstBrhNode;
{
  int i, j;
  int iCurRow, iCurCol;
  int iIndex, iLength;
  struct stItem *pstItem;
  WINDOW *pwWin;

  pwWin = pstMenu->pwWin;
  pstItem = pstMenu->pstItem;
  getyx( pwWin, iCurRow, iCurCol );

  for (i = 0; i < NO_ITEM_BRH; i ++) {
    iCurCol = pstItem[ i ].iCol;
    iLength = pstItem[ i ].iLength;
    /* copy screen's data to buffer */
    for (j = 0; j < iLength; j ++) {
      pstItem[ i ].caData[ j ] = mvwinch( pwWin, iCurRow, iCurCol + j );
    }
  } /* end for loop */

  /* Only update Txn date now.... */
  memcpy(&(pstBrhNode->stBrhRecord.caTxnDate),
         &(pstItem[TXN_DATE].caData), pstItem[TXN_DATE].iLength);
  memcpy(&(pstBrhNode->stBrhRecord.caNxtTxnDate),
         &(pstItem[NXT_TXN_DATE].caData),pstItem[NXT_TXN_DATE].iLength);
  memcpy(&(pstBrhNode->stBrhRecord.caNNxtTxnDate),
         &(pstItem[NNXT_TXN_DATE].caData), pstItem[NNXT_TXN_DATE].iLength);
}

UptTrmItmField(pstMenu)
struct stMenuBit *pstMenu;
{
  int i, j;
  int iCurRow, iCurCol;
  int iIndex, iLength;
  struct stItem *pstItem;
  WINDOW *pwWin;

  pwWin = pstMenu->pwWin;
  pstItem = pstMenu->pstItem;

  for (i = 0; i < NO_ITEM_TRM; i ++) {
    iCurCol = pstItem[ i ].iCol;
    iCurRow = pstItem[ i ].iRow;
    iLength = pstItem[ i ].iLength;
    /* copy screen's data to buffer */
    for (j = 0; j < iLength; j ++) {
      pstItem[ i ].caData[ j ] = mvwinch( pwWin, iCurRow, iCurCol + j );
    }
  } /* end for loop */
}

int
ChkRtn1(pstMenu,iItmidx)
struct stMenuBit *pstMenu;
int    iItmidx;
{
  struct stItem *pstItem;
  char   caTmpBuf[30],cChar;
  int    i,j,iRc ;
  int    iCurRow,iCurCol;
  WINDOW *pwWin;

    pwWin = pstMenu->pwWin;
    getyx( pwWin, iCurRow, iCurCol );
    memcpy(caTmpBuf,pstMenu->pstItem[ iItmidx ].caData, 
           pstMenu->pstItem[ iItmidx ].iLength);

    caTmpBuf[ pstMenu->pstItem[ iItmidx ].iLength ] = '\0';
    
    if ( (*pstMenu->pstItem[ iItmidx ].Routine2) == NULL) {
      ShowMsg(pstMenu,23,25, "                                  ");
      return(1);
    }

    iRc = (*pstMenu->pstItem[ iItmidx ].Routine2)(caTmpBuf); 

    if ( iRc != 1 )  {   /* return code == 1 represents TRUE */
      ShowMsg(pstMenu,23,25, "Field Check Error!!");
      printf("\a\a\a");
    }
    else {
      ShowMsg(pstMenu,23,25, "                                  ");
    }

    wmove(pwWin, iCurRow, iCurCol);
    return(iRc);
}

int
ChkRtn(pstMenu,iItmidx)
struct stMenuBit *pstMenu;
int    iItmidx;
{
  struct stItem *pstItem;
  char   caTmpBuf[30],cChar;
  int    i,j,iRc ;
  int    iCurRow,iCurCol;
  int    iLength;
  WINDOW *pwWin;

    pwWin = pstMenu->pwWin;
    pstItem = pstMenu->pstItem;
    getyx( pwWin, iCurRow, iCurCol );

    iCurCol = pstItem[ iItmidx ].iCol;
    iLength = pstItem[ iItmidx ].iLength;
    /* copy screen's data to buffer */
    for (j = 0; j < iLength; j ++) {
      caTmpBuf[j] = mvwinch( pwWin, iCurRow, iCurCol + j );
    }

    caTmpBuf[ pstMenu->pstItem[ iItmidx ].iLength ] = '\0';

    if ( (*pstMenu->pstItem[ iItmidx ].Routine2) == NULL) {
      ShowMsg(pstMenu,23,25, "                                  ");
      return(1);
    }

    iRc = (*pstMenu->pstItem[ iItmidx ].Routine2)(caTmpBuf); 

    if ( iRc != 1 )  {   /* return code == 1 represents TRUE */

      ShowMsg(pstMenu,23,25, "Field Check Error!!");
      printf("\a\a\a"); 
    }
    else {
      ShowMsg(pstMenu,23,25, "                                  ");
    }

    wmove(pwWin, iCurRow, iCurCol);
    return(iRc);
}


int
DateValid(pcaDate_List)
char  *pcaDate_List ;
{
   /*  this procedure perform a date validation.                     */
       char   *C_String();
       char   caShowBuf[80];
       char   caTmpYear[4];
       char   caBaseYear[5];
       int  iDays  ,
            iMonth ,
            iYear  ;
       int  i;
       int iDateLen;

       iDateLen = strlen(pcaDate_List);

       if (iDateLen != 8) {
         return(FALSE);  /* Invalid date length */
       }

       for (i=0; i<8; i++) {
         if (pcaDate_List[i] < '0' || pcaDate_List[i] > '9') {
           return(FALSE);  /* Invalid chars in the Date_List */
         }
       }

       iDays  = atoi(C_String(pcaDate_List + DAYS_OFFSET, 2)) ;
       iMonth = atoi(C_String(pcaDate_List + MNTH_OFFSET, 2)) ;
       iYear  = atoi(C_String(pcaDate_List + YEAR_OFFSET, 4)) ;

       if (g_iBaseYear != 0) {   /* add the base year to the pcaDate_List */
         iYear = iYear + g_iBaseYear;
       }

       if (iYear % 4 == 0 && iYear % 100 != 0 || iYear % 400 == 0) {
         iaMax_Days[2]=29;       /* this iYear is leap iYear. */
       } else {
         iaMax_Days[2]=28;       /* this iYear is normal iYear. */
       }

       if ( iMonth >=1 && iMonth <= 12 &&
            iDays  >=1 && iDays  <= iaMax_Days[iMonth]) {
         return(TRUE);
       }
       else {
         return(FALSE);
       }

}

char
*C_String(pcaChar_List,iN_char)
char  *pcaChar_List ;
int   iN_char     ;                        
{
   /*  this procedure can pack character at most 12 chars.           */
       static char  scaChar_String[14] ;


       if (iN_char <= 12) {
          strncpy(scaChar_String,pcaChar_List,iN_char) ;
          scaChar_String[iN_char] = '\0' ;
       }

       return(scaChar_String) ;
}

int
TermTypeChk(pcaTermType)
char  *pcaTermType;
{
  char cTermType;

  cTermType = pcaTermType[0];
  
  switch(cTermType) {
    case '1':
    case '2':
    case '3':
    case '4':
    case '9':
      return(TRUE);
    default:
      return(FALSE);
  }
}


int
TermStatChk (char *cTrmOnTxn)
{

  switch (*cTrmOnTxn)
  {
    case 'Y':
    case 'y':
    case 'N':
    case 'n':
               return(TRUE);
    default:
               return(FALSE);
  }
}


ShowMsg(pstMenu,iY,iX,pcaShowStr)
struct stMenuBit *pstMenu;
int    iY;
int    iX;
char   *pcaShowStr;
{
   char caFiller[60];
   int  iSpaceFlag=1;
   int  i;

   for (i=0;i<10;i++) {
     if (pcaShowStr[i] != ' ') {
       iSpaceFlag = 0;
       break;
     }
   }

   memset(caFiller,' ',sizeof(caFiller));
   caFiller[59] = '\0';
   wattron(pstMenu->pwWin,A_NORMAL);
   mvwaddstr(pstMenu->pwWin, iY, iX, caFiller);
   wattroff(pstMenu->pwWin,A_NORMAL);
 
   if (iSpaceFlag == 0) {
     wattron(pstMenu->pwWin,A_BLINK|A_REVERSE);
     mvwaddstr(pstMenu->pwWin, iY, iX, pcaShowStr);
     wattroff(pstMenu->pwWin,A_BLINK|A_REVERSE);
   }
}

int
RntySeqChk(pcaSeqNo)
char  *pcaSeqNo;
{
  int iSeqNo;
 
  iSeqNo = atoi(pcaSeqNo);
  
  if (iSeqNo >= 40001 && iSeqNo <= 99999) {
    return(TRUE);
  }
  else { 
    return(FALSE);
  }
}
