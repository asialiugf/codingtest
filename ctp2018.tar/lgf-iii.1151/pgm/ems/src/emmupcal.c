#include <stdio.h>
#include <errno.h>
#ifdef HP_UNIX
#define _XOPEN_SOURCE_EXTENDED
#endif
#include "emcmonth.h"

main(int argc,char *argv[])
{
  char cRc;
  char caBrCode[80], caYear[80], caMonth[80];
  int iYear, iMonth, i, reinput, len;
  char caFlName[80];
  FILE *zFp;

  memset(caFlName, 0, sizeof(caFlName));
  strcpy(caFlName,(char *) getenv("III_DIR"));
  strcat(caFlName,(char *) "/");

  if (argc >= 2)
  {
    if (toupper(argv[1][0]) == 'E')
       strcat(caFlName,UPCAL_E);
    else  
       strcat(caFlName,UPCAL_C);
  }
  else
    strcat(caFlName,UPCAL_C);

  zFp = fopen(caFlName,"r");
  if (zFp == NULL)
  {
    printf("Failure to open file [%s]! (errno:%d)",caFlName, errno);
    return(OPEN_PROMPTFILE_ERR);
  }

  for (i=0;i<13;i++) {
    fgets(g_caPromBuf[i],MAX_LINE_LEN,zFp);
    memset(g_caPromBuf[i]+strlen(g_caPromBuf[i])-1,'\0',1);
  }

  fclose (zFp);

  initscr();
  
  cbreak();
  /* 
  idlok(stdscr,TRUE);
  */
  keypad(stdscr,TRUE);

  clear();
  move(0,0);

  while (1)
  {
    clear();
    move(0,0);

    /* Input the Branch Code */
    reinput = 1;
    do
    {
      move(0,0);
      clrtoeol();
      printw ("%s ", g_caPromBuf[1]);
      refresh();
      scanw ("%s", caBrCode);
      if ((len = strlen (caBrCode)) > 10)
         continue;
      for (i=0; isdigit(caBrCode[i]) != 0; i++)
        if (i == len-1)
           reinput = 0;
        else
           reinput = 1;
    } while (reinput);

    /* Input the Year */
    reinput = 1;
    do
    {
      move(1,0);
      clrtoeol();
      printw ("%s ",g_caPromBuf[2]);
      refresh();
      scanw ("%s", caYear);
      iYear = atoi (caYear);
      if ((len = strlen (caYear)) > 4)
         continue;
      for (i=0; isdigit(caYear[i]) != 0; i++)
        if (i == len-1)
           reinput = 0;
        else
           reinput = 1;
    } while (reinput);

    /* Input the Month */
    reinput = 1;
    do
    {
      move(2,0);
      clrtoeol();
      printw ("%s ", g_caPromBuf[3]);
      refresh();
      scanw ("%s", caMonth);
      iMonth = atoi (caMonth);
      iMonth--;
      if ( ((len = strlen (caMonth)) > 2) || ((iMonth < 0) || (iMonth > 11)) )
         continue;

      for (i=0; isdigit(caMonth[i]) != 0; i++)
        if (i == len-1)
           reinput = 0;
        else
           reinput = 1;
    } while (reinput);

    if (iYear % 4 == 0 && (iYear % 400 == 0 || iYear % 100 != 0))
       day[1] = 29;
    else
       day[1] = 28;

    cRc = Init_Calend (caBrCode, caYear, iMonth);
    if (cRc != UPDATE_OK)
       continue;

    Disp_Calend (iYear, iMonth);

    cRc = Edit_Calend (caBrCode, caYear, iMonth);
    if (cRc != UPDATE_OK)
       continue;
    else
       break;
  }
  endwin();
  exit(0);
}



Init_Calend(char *pcaBrCode,char *pcaYear,int iMonth)
{
  char cRc;
  int i,j,k,iYear,y1,date[31];
  static int iFirst = 0;

  iYear = atoi (pcaYear);

  memcpy (stPara.caBrCode, pcaBrCode, 10);
  memcpy (stPara.caYear, pcaYear, 4);

  ASDAYIN2 (&stPara);
  cRc = stPara.cReturn;
  switch (cRc)
  {
   case '0':
             if (iFirst == 0)
             {
               for (i=0; i<12; i++)
                 for (j=0; j<31; j++)
                     g_caIsBusi[i][j] = stPara.caDayInfo[i][j];

               iFirst = 1;
               clear();
               attrset(A_REVERSE);
               mvprintw (1, 35, "<< %04d >>", iYear);
               attrset(0);
               refresh();
             }
             break;
   case '1':
             move (20,0);
             clrtoeol();
             printw ("==> %s",g_caPromBuf[5]);
             refresh ();
             getch();
             return(NO_SUCH_BRCODE);
   case '2':
             move (20,0);
             clrtoeol();
             printw ("==> %s",g_caPromBuf[6]);
             refresh ();
             getch();
             return(NO_SUCH_YEAR);
   case '3':
             move (20,0);
             clrtoeol();
             printw ("==> %s",g_caPromBuf[7]);
             refresh ();
             getch();
             return(OVERFLOW_DATE);
   case '4':
             move (20,0);
             clrtoeol();
             printw ("==> %s",g_caPromBuf[8]);
             refresh ();
             getch();
             return(CALFILE_NOTEXIST);
   case '5':
             move (20,0);
             clrtoeol();
             printw ("==> %s",g_caPromBuf[9]);
             refresh ();
             getch();
             return(CALFILE_READ_ERR);
   case '6':
   case '7':
             move (20,0);
             clrtoeol();
             printw ("==> %s",g_caPromBuf[10]);
             refresh ();
             getch();
             return(OTHER_ERR);
   default:
             move (20,0);
             clrtoeol();
             printw ("==> %s",g_caPromBuf[10]);
             refresh ();
             getch();
             return(RETURN_CODE_ERR);
  }

  y1 = iYear-1;
  n = (iYear + y1/4 + y1/400 - y1/100) % 7;

  attrset(A_REVERSE);
  mvprintw (3, 34, "[ %s ]", mon[iMonth]);
  attrset(0);
  move (5,30);
  for (i=0; i<15; i++)
      mvprintw(CAL_TABLE_ROW0 + i,CAL_TABLE_COL0,"%s",CAL_TABLE[i]);
  mvprintw( 5,0,"%s","Y:Set");
  mvprintw( 6,0,"%s","  Business");
  mvprintw( 7,0,"%s","  Day");
  mvprintw( 8,0,"%s","N:Set");
  mvprintw( 9,0,"%s","NonBusiness");
  mvprintw(10,0,"%s","  Day");
  mvprintw(11,0,"%s","F1:Save");
  mvprintw(13,0,"%s","F2:Quit");
  mvprintw(15,0,"%s","F3:Last");
  mvprintw(16,0,"%s","   Month");
  mvprintw(17,0,"%s","F4:Next");
  mvprintw(18,0,"%s","   Month");
  refresh();

  for (i=0; i<31; i++)
      date[i]=i+1;

  for (i = 0; i <= iMonth; i++)
  {
    for (j = 0; j < n; j++)
      d[j] = 0;

    for (k = 0; k < day[i]; k++)
      d[j++] = date[k];

    for (;j < 42; j++)
      d[j] = 0;

    n = (n + day[i]) % 7;
  }

  row = CAL_TABLE_ENT_ROW0;
  col = CAL_TABLE_ENT_COL0;
  for (min_ent=0; min_ent<42; min_ent++)
      if (d[min_ent] == 0)
         col += COL_UNIT_SIZE;
      else
         break;
  ent = min_ent;
  max_ent = ent + day[iMonth]-1;

  return (UPDATE_OK);
}



Edit_Calend (char *pcaBrCode,char *pcaYear,int iMonth)
{
  char cRc;
  int c;
  int i,iYear;

  iYear = atoi (pcaYear);

  noecho();
  for (;;)
  {
    move(row,col);
    refresh();
    c=getch();
    clear_msg_line();
    move(row,col);
    switch (c)
    {
      case KEY_F(1):
           cRc = Update_BusiDate(pcaBrCode,pcaYear,iMonth);
           if (cRc != UPDATE_OK)
              return (cRc);
           break;
      case KEY_F(2):
           return (UPDATE_OK);
      case KEY_F(3):
      case KEY_PPAGE:
      case KEY_HOME:
           if (iMonth > 0)
           {
             iMonth--;
             cRc = Init_Calend (pcaBrCode, pcaYear, iMonth);
             if (cRc != UPDATE_OK)
                return (cRc);
             Disp_Calend (iYear, iMonth);
           }
           else
           {
             flash();
             beep();
           }
           break;
      case KEY_F(4):
      case KEY_NPAGE:
      case KEY_END:
           if (iMonth < 11)
           {
             iMonth++;
             cRc = Init_Calend (pcaBrCode, pcaYear, iMonth);
             if (cRc != UPDATE_OK)
                return (cRc);
             Disp_Calend (iYear, iMonth);
           }
           else
           {
             flash();
             beep();
           }
           break;
      case 'h':
      case KEY_LEFT:
           if ((col > CAL_TABLE_ENT_COL0) &&
               (ent > min_ent) && (ent <= max_ent))
           {
             ent--;
             col-=COL_UNIT_SIZE;
           }
           else
           {
             flash();
             beep();
           }
           break;
      case 'j':
      case KEY_DOWN:
           if ((row < CAL_TABLE_ENT_ROW_LMT) &&
               (ent >= min_ent) && ((ent+7) <= max_ent))
           {
             ent += 7;
             row+=ROW_UNIT_SIZE;
           }
           else
           {
             flash();
             beep();
           }
           break;
      case 'k':
      case KEY_UP:
           if ((row > CAL_TABLE_ENT_ROW0) &&
               ((ent-7) >= min_ent) && (ent <= max_ent))
           {
             ent -= 7;
             row-=ROW_UNIT_SIZE;
           }
           else
           {
             flash();
             beep();
           }
           break;
      case 'l':
      case KEY_RIGHT:
           if ((col < CAL_TABLE_ENT_COL_LMT) &&
               (ent >= min_ent) && (ent < max_ent))
           {
             ent++;
             col+=COL_UNIT_SIZE;
           }
           else
           {
             flash();
             beep();
           }
           break;
      case 'Y':
      case 'y':
           if ((ent >= min_ent) && (ent <= max_ent))
           {
             printw ("%-2d",d[ent]);
             g_caIsBusi[iMonth][ent-min_ent] = '0';
           }
           break;
      case 'N':
      case 'n':
           if ((ent >= min_ent) && (ent <= max_ent))
           {
             attrset (A_REVERSE);
             printw ("%-2d",d[ent]);
             attrset(0);
             g_caIsBusi[iMonth][ent-min_ent] = '1';
           }
           break;
      default:
           flash();
           break;
    }
  }
}



Disp_Calend (int iYear, int iMonth)
{
  int i=0,j,k,l,row,col;

  row = CAL_TABLE_DAY_ROW0;
  col = CAL_TABLE_DAY_COL0;

  for (j = 0,k = -1; j < 6; j++)
  {
    move (row,col);
    refresh();
    
    for (l = 0; l < 7; l++)
      if (d[++k] == 0)
      {
        mvprintw (row,col,"%s","  ");
        col += COL_UNIT_SIZE;
      }
      else
      {
        mvprintw (row,col,"%-2d",d[k]);
        if (g_caIsBusi[iMonth][i] == '0')
           mvprintw (row,col,"%-2d",d[k]);
        else
        if (g_caIsBusi[iMonth][i] == '1')
        {
          attrset (A_REVERSE);
          mvprintw (row,col,"%-2d",d[k]);
          attrset (0);
        }
        col += COL_UNIT_SIZE;
        i++;
      }
    row += ROW_UNIT_SIZE;
    col = CAL_TABLE_DAY_COL0;
  }

}




Update_BusiDate(char *pcaBrCode,char *pcaYear,int iMonth)
{
  int    i,iRc;
  char   cRc;
  int j;
 
  memcpy (stPara.caBrCode,pcaBrCode,10);
  memcpy (stPara.caYear,pcaYear,4);

  for (i=0; i<12; i++)
    for (j=0; j<day[iMonth]; j++)
        stPara.caDayInfo[i][j] =  g_caIsBusi[i][j];

  ASDAYUPD(&stPara);

  cRc = stPara.cReturn;
  switch (cRc) {
    case '0': 
              move (20,0);
              clrtoeol();
              printw ("==> %s",g_caPromBuf[4]);
              refresh ();
              return(UPDATE_OK);
    case '1': 
              move (20,0);
              clrtoeol();
              printw ("==> %s",g_caPromBuf[5]);
              refresh ();
              getch();
              return(NO_SUCH_BRCODE);
    case '2': 
              move (20,0);
              clrtoeol();
              printw ("==> %s",g_caPromBuf[6]);
              refresh ();
              getch();
              return(NO_SUCH_YEAR);
    case '3': 
              move (20,0);
              clrtoeol();
              printw ("==> %s",g_caPromBuf[7]);
              refresh ();
              getch();
              return(OVERFLOW_DATE);
    case '4': 
              move (20,0);
              clrtoeol();
              printw ("==> %s",g_caPromBuf[8]);
              refresh ();
              getch();
              return(CALFILE_NOTEXIST);
    case '5': 
              move (20,0);
              clrtoeol();
              printw ("==> %s",g_caPromBuf[9]);
              refresh ();
              getch();
              return(CALFILE_READ_ERR);
    case '6': 
    case '7': 
              move (20,0);
              clrtoeol();
              printw ("==> %s",g_caPromBuf[10]);
              refresh ();
              getch();
              return(OTHER_ERR);
    default:
              move (20,0);
              clrtoeol();
              printw ("==> %s",g_caPromBuf[10]);
              refresh ();
              getch();
              return(RETURN_CODE_ERR);
  }
}


clear_msg_line()
{
  move (20,0);
  clrtoeol();
}
