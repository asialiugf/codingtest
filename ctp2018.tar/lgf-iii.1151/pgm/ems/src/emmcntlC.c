
/*
 *&N& ROUTINE NAME: main  
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&           
 *&R& RETURN VALUES:
 *&R&           
 *&R&           
 *&D& DESCRIPTION:           
 *&D&     ���{�������Һ޲z�l�t�α���ʱ��D�{��, �t�d�ʱ��e������ܻP�R�O���ǰe
 *&D& ( This program is Curses mode, i.e. using CURSES as the output)        
 */

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/signal.h>
#include <fcntl.h>
#include <errno.h>
#include <curses.h>

#include "errlog.h"
#include "dcs.h"
#include "cwa.h"
#include "emctcwa.h"

#define  P_FindBit2         20506
#define  P_Memmcntl         88900

#define  FIND_BIT_ERR       -2
#define  GET_SSA_PTR_ERR    -3
#define  UNDEFINED_TERM     -4

#define  DCS_ERR            -1
#define  OPEN_FILE_ERR      -1
#define  TOOLPROG_EXEC_ERR  -2
#define  FORK_TOOLPG_ERR    -3
#define  OPEN_MENUFILE_ERR  -4

#define  DEST_NAME_LEN      10
#define  FILE_NAME_LEN      80
#define  MAX_EXEC_PATH_LEN  80
#define  MAX_LINE_LEN       100

#define  GETTXNDATE         1  /* Get Txn Date      */
#define  GETOPMODE          2  /* Online or Batch   */
#define  GETSYSMODE         3  /* Normal or Restart */
#define  SYSTEM_RESTART     0x4000 /* 1:restarted ; 0:Normal Begin */
#define  ONLINE_CLOSE       0x0400 /* 1:Batch ; 0:On_line        */

#define  CHINESE_TYPE       '1'
#define  TEST_MODE          "TEST_MODE"
#define  CWA_SHM_KEY        "CWA_SHM_KEY"
#define  QUEUE_DCS          'Q'
#define  QUIT_MENU          'Z'
#define  MONITOR_HOST       "00Monitor1"
#define  PASSWORD_USER      "PASSWORD_USER"
#define  PROTOCOL_TYPE      "III_PROTOCOL"
#define  CWATOOL            "emxtcwa.x"
#define  BITTOOL            "emxtbit.x"
#define  CONFIG_FILE        "iii/etc/tbl/config.dat"
#define  CUSTOM_FILE        "iii/etc/tbl/custom.dat"
#define  CNTLSN_C           "iii/etc/cmg/emdcntl.scr"
#define  CNTLSN_E           "iii/etc/emg/emdcntl.scr"
#define  SERVSN_C           "iii/etc/cmg/emdserv.scr"
#define  SERVSN_E           "iii/etc/emg/emdserv.scr"
#define  TOOLSN_C           "iii/etc/cmg/emdtool.scr"
#define  TOOLSN_E           "iii/etc/emg/emdtool.scr"
/* TCC */
#define  BATCHSN_C          "iii/etc/cmg/emdbatch.scr"
#define  BATCHSN_E          "iii/etc/emg/emdbatch.scr"

struct MonCmd               stMonCmd;
struct FkdStat              stFkdStat;
struct DcsBuf               stDcsBuf;
struct DcsSiof              stDcsSiof;
struct MDA                  *pstMda;
struct SSA                  *pstSsa;

static char                 gs_caEnvStr[50];
int g_iShmid;
int g_iSessidx;
int g_iCwaKey;
int g_iTestMode;
int g_iPassUsr;
char g_cTmMode;
static struct stMenu *sg_pstMenu1;
static struct stMenu *sg_pstMenu2;
static struct stMenu *sg_pstMenu3;
static struct stMenu *sg_pstMenu4;
/*    ----------------   Prototype Define --------------------------------*/
int ShowCfgScrn(char *caCmd,char cCmd);
/* TCC: For compatibility with Tandem */
char *getenv();
extern int  errno;
extern char *sys_errlist[];

main(argc,argv)
int  argc;
char **argv;
{
  int  iRtn;
  int  iIdx;
  char caIdx[5];
  char cPause;
  int  iRc;
  struct CwaCtl stCwaCtl;
  struct CwaCreatIobuf stCCBuf;
  char caFileName[ FILE_NAME_LEN + 1 ];
  short sStatus;
  /* TCC */
  struct SSA *pstSsa;
  struct TermArea  stTmArea;
  char   caLogName[128];
  char   caKillTpuCmd[128];  /*added by pjw for tu995005    1999 6 8*/
  
  UCP_TRACE(P_Memmcntl);
  SignlHdl();
  /* add one line by pjw for tu995005    1999 6 8 */
  sprintf(caKillTpuCmd,"%s/iii/bin/bat/killalltpu  1>/dev/null  2>/dev/null",(char *)getenv("III_DIR")); 
  sprintf(caLogName, "%s/iii/log/ems_errlog", getenv("III_DIR") );
  ChgLog(LOG_CHG_LOG,caLogName);

  sprintf (caFileName, "%s/%s", (char *)getenv("III_DIR"), CONFIG_FILE);
  iRc = InitCnfTbl(caFileName);
  if ( iRc < 0 ){
    return( -1 );
  }

  g_iTestMode = GetCnfValue( TEST_MODE );
  if (g_iTestMode < 0){
    sprintf(g_caMsg, "<EMS> Failure to access config.dat.(errno:%d)", errno);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("%s\n", g_caMsg);
    return( -2 );
  }

  if ( g_iTestMode == 1) {
    ChgLog(LOG_CHG_MODE,"1");
  }
  else {
    ChgLog(LOG_CHG_MODE,"0");
  }

  g_iCwaKey = GetCnfValue( CWA_SHM_KEY );
  if (g_iCwaKey < 0){
    return( -3 );
  }

  sprintf (caFileName, "%s/%s", (char *)getenv("III_DIR"), CUSTOM_FILE);
  iRc = InitCusTbl(caFileName);
  if ( iRc < 0 ){
    return( -1 );
  }

  g_iPassUsr = GetCusValue( PASSWORD_USER );
  if (g_iPassUsr < 0){
    return( -2 );
  }

  stCwaCtl.cFunCode = CWA_GET_ID;
  stCCBuf.iShmKey = g_iCwaKey;
  stCCBuf.iSemKey = g_iCwaKey;
  
  iRc = CwaCtlFac(&stCwaCtl,&stCCBuf);
  if (iRc != CWA_NORMAL) {
    sprintf (g_caMsg, "<EMS> Failure to get CWA ID! (iRc:%d)", iRc);
    printf ("\n%s\n", g_caMsg);
    printf ("\nTPE is not started yet!\n");
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    exit(0);
  }

  stCwaCtl.cFunCode = CWA_ATTACH;
  stCCBuf.iShmKey = g_iCwaKey;
  stCCBuf.iSemKey = g_iCwaKey;
  
  iRc = CwaCtlFac(&stCwaCtl,&stCCBuf);
  if (iRc != CWA_NORMAL) {
    sprintf (g_caMsg, "<EMS> Failure to attach CWA! (iRc:%d)", iRc);
    printf ("\n%s\n", g_caMsg);
    ErrLog (40000, g_caMsg, RPT_TO_TTY|RPT_TO_LOG, 0, 0);
  }
/*
  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);

  if (iRc != 0) {
    sprintf (g_caMsg, "<EMS> Failure to get SSA pointer! (iRc:%d)", iRc);
    printf ("%s\n", g_caMsg);
    ErrLog (40000, g_caMsg, RPT_TO_TTY|RPT_TO_LOG, 0, 0);
    UCP_TRACE_END(iRc);
  }

  sStatus = pstSsa->sSysStatus;
*/
  /* TCC */
  iRc = FindBit(&stTmArea);
  if (iRc != 0) {
    sprintf (g_caMsg,
          "F856: Can't find such ttyname in Bit Table (check bit.dat)");
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("\n%s\n", g_caMsg);
    return (FIND_BIT_ERR);
  }

  /* attach MDA share memory */
  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_MDA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstMda);

  if (iRc != 0) {
    sprintf (g_caMsg, "<EMS> Failure to get MDA pointer! (iRc:%d)", iRc);
    printf ("\n%s\n", g_caMsg);
    printf ("Check to see if EMS monitor is started!\n");
    ErrLog (40000, g_caMsg, RPT_TO_TTY|RPT_TO_LOG, 0, 0);
    UCP_TRACE_END(iRc);
  }

  if (argc == 1) {
      g_cTmMode = '1';
  }
  else if ( (argc == 2) && ( (argv[1][0]=='e') || (argv[1][0]=='E') ) ){
      g_cTmMode = '4';
  }
  else if ( argc > 2) {
    printf("<Usage> emxcntl.x [e\\E] \n");
    exit(-1);
  }
  else {
    printf("WRONG TERMINAL TYPE!!! Null for Chinese,(e/E) for English.\n");
    exit(-1);
  }
  /* a unlimit while to show command screen */
  while(1){
    stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
    stCwaCtl.cSegCode = CWA_SEG_SSA;
    iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);

    if (iRc != 0) {
      sprintf (g_caMsg, "<EMS> Failure to get SSA pointer! (iRc:%d)", iRc);
      ErrLog (40000, g_caMsg, RPT_TO_TTY|RPT_TO_LOG, 0, 0);
      printf ("%s\n", g_caMsg);
      UCP_TRACE_END(iRc);
    }
    sStatus = pstSsa->sSysStatus;
    ShowCmdScrn(&stMonCmd.cCmd);

    switch (stMonCmd.cCmd){
      case TPE_SHUTDOWN:
        PassWord(sg_pstMenu1,g_iPassUsr);
        iRc = SendCmdToMon(&stMonCmd,sg_pstMenu1);
        if (iRc < 0) {
          Err_Hdl();
        }
        if (iRc != MON_SAVE_CWA_ERR)
           ShowMsg(sg_pstMenu1,23,20,"TPE Normal Shutdown Completed!!");
        Quit(sg_pstMenu1);
        system(caKillTpuCmd);    /* added by pjw for tu995005   1999 6 8*/
        UCP_TRACE_END(0);
      case TPE_QUCKSHUT:
        PassWord(sg_pstMenu1,g_iPassUsr);
        iRc = SendCmdToMon(&stMonCmd,sg_pstMenu1);
        if (iRc < 0) {
          Err_Hdl();
        }
        if (iRc != MON_SAVE_CWA_ERR)
           ShowMsg(sg_pstMenu1,23,20,"TPE Emergency Shutdown Completed!!");
        Quit(sg_pstMenu1);
        system(caKillTpuCmd);    /* added by pjw for tu995005   1999 6 8*/
        UCP_TRACE_END(0);
      case TPE_SYSMODE:
        PassWord(sg_pstMenu1,g_iPassUsr);
        while(stMonCmd.cCmd != QUIT_MENU){
          stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
          stCwaCtl.cSegCode = CWA_SEG_SSA;
          iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);
          if (iRc != 0) {
            sprintf (g_caMsg,
              "<EMS> Failure to get SSA pointer! (iRc:%d)", iRc);
            ErrLog (40000, g_caMsg, RPT_TO_LOG, 0, 0);
            ShowMsg (sg_pstMenu1, 23, 20, "%s\n", g_caMsg);
            UCP_TRACE_END(iRc);
          }
          sStatus = pstSsa->sSysStatus;

          ShowBatchScrn(&stMonCmd.cCmd);

          switch (stMonCmd.cCmd){
            case TPE_DOBATCH:
              if ( !(sStatus & ONLINE_CLOSE) ) {
                iRc = SendCmdToMon(&stMonCmd,sg_pstMenu4);
                if (iRc < 0) {
                  Err_Hdl();
                }
              }
              else {
                ShowMsg (sg_pstMenu4, 16, 20,
                         "EMS has already been in Batch Mode!!");
                ShowMsg (sg_pstMenu4, 17, 20,
                         "Please press any key to continue.");
                getchar();
              }
              break;
            case TPE_DOONLINE:
              if ( (sStatus & ONLINE_CLOSE) ) {
                iRc = SendCmdToMon(&stMonCmd,sg_pstMenu4);
                if (iRc < 0) {
                  Err_Hdl();
                }
              }
              else {
                ShowMsg (sg_pstMenu4, 16, 20,
                         "EMS has already been in Online Mode!!\n");
                ShowMsg (sg_pstMenu4, 17, 20,
                         "Please press any key to continue.\n");
                getchar();
              }
              break;
            case QUIT_MENU:
              Quit (sg_pstMenu4);
              break;
            default:
              ShowMsg (sg_pstMenu4, 16, 20, "Invalid input choice!");
              break;
          }
        }
        break;
      case TPE_SERV_MG:
        PassWord(sg_pstMenu1,g_iPassUsr);
        while(stMonCmd.cCmd != QUIT_MENU){
          ShowSrvScrn(&stMonCmd.cCmd);
          switch (stMonCmd.cCmd){
            case MON_QUERY:
              while((iRtn=ShowFokScrn(caIdx)) == -1){
                ShowMsg(sg_pstMenu2,23,20,"!! Choice error !!");
              }
              if (iRtn != 9) {   /* 9: User press 'q' or 'Q' key  */
                iIdx=atoi(caIdx);
                ShowPrcStat(iIdx);
              }
              break;
            case MON_FORK:
            case MON_SHUTDOWN:
              if ( !(sStatus & ONLINE_CLOSE) ) {  /* online mode */
                while((iRtn=ShowCfgScrn(stMonCmd.caTblidx,stMonCmd.cCmd))== -1){
                  ShowMsg(sg_pstMenu2,23,20,"!! Choice error !!");
                }
                if(iRtn == 0){
                  iRc = SendCmdToMon(&stMonCmd,sg_pstMenu2);
                  if (iRc < 0) {
                    Err_Hdl();
                  }
                }
              }
              else {  /* batch mode */
                ShowMsg(sg_pstMenu2,22,20," EMS is in Batch Mode!!");
                ShowMsg(sg_pstMenu2,23,20," Can't execute this option.");
              }
              break;
            case MON_KILL:
              if ( !(sStatus & ONLINE_CLOSE) ) {  /* online mode */
                while((iRtn=ShowFokScrn(stMonCmd.caTblidx)) == -1){
                  ShowMsg(sg_pstMenu2,23,20,"!! Choice error !!");
                }
                if(iRtn == 0){
                  iRc = SendCmdToMon(&stMonCmd,sg_pstMenu2);
                  if (iRc < 0) {
                    Err_Hdl();
                  }
                }
              }
              else {  /* batch mode */
                ShowMsg(sg_pstMenu2,23,20," EMS is in Batch Mode!!");
                ShowMsg(sg_pstMenu2,23,20," Can't execute this option.");
              }
              break;
            case QUIT_MENU:
              break;
            default:
              ShowMsg(sg_pstMenu2, "Choice Error!!");
          } /* FOR switch (stMonCmd.cCmd) */
          attrset(A_NORMAL);
        } /* FOR while while(stMonCmd.cCmd != QUIT_MENU) */
        break;
      case TPE_TOOLS:
        PassWord(sg_pstMenu1,g_iPassUsr);
        while(stMonCmd.cCmd != QUIT_MENU){
          ShowToolScrn(&stMonCmd.cCmd);
          switch (stMonCmd.cCmd){
            case TPE_DUMPCWA:
               ForkEmsTool(&stMonCmd);
               break;
            case TPE_DUMPBIT:
               ForkEmsTool(&stMonCmd);
               break;
            case QUIT_MENU:
              break;
            default:
              ShowMsg(sg_pstMenu3, "Choice Error!!");
          }
        } /* FOR while(stMonCmd.cCmd != QUIT_MENU) */
        break;
      case MON_QUERY:
        Quit(sg_pstMenu1);
        UCP_TRACE_END(1);
      default:
        ShowMsg(sg_pstMenu1, "Choice Error!!");
    }
  } /* FOR while(1)  */ 
  UCP_TRACE_END(0);
}

ShowCmdScrn(char *cCmd)
{
    int  iRc,i,j;
    char caDateBuf[20];
    char caOpmodeBuf[20];
    struct stMenu *InitTool();
    struct stMenu *pstMenu;
    static int    iHadExist=0;

    if (iHadExist == 0) {
      if (g_cTmMode == CHINESE_TYPE) {
        sg_pstMenu1 = (struct stMenu *) InitTool(CNTLSN_C,1);
      }
      else  {
        sg_pstMenu1 = (struct stMenu *) InitTool(CNTLSN_E,1);
      }
      iHadExist = 1;
    }
    else {
      if (g_cTmMode == CHINESE_TYPE) {
        sg_pstMenu1 = (struct stMenu *) InitMenu(CNTLSN_C,1);
      }
      else  {
        sg_pstMenu1 = (struct stMenu *) InitMenu(CNTLSN_E,1);
      }
    }

    memset(caDateBuf,'\0',20);
    GetSsaInfo(GETTXNDATE,caDateBuf);
    RetrieveData( sg_pstMenu1 ,0,caDateBuf );
    memset(caOpmodeBuf,'\0',20);
    GetSsaInfo(GETOPMODE,caOpmodeBuf);
    RetrieveData( sg_pstMenu1 ,1,caOpmodeBuf );
    DisplayData( sg_pstMenu1 );
    iRc = Process( sg_pstMenu1);

    while ( ( iRc < 49) || (iRc > 54) ) {
      ShowMsg(sg_pstMenu1, "Choice Error!!");
      iRc = Process( sg_pstMenu1);
    }
    *cCmd = (char) iRc;
    
    return(0);
}

ShowSrvScrn(char *cCmd)
{
    int  iRc,i,j;
    char caDateBuf[20];
    char caOpmodeBuf[20];
    struct stMenu *InitTool();
    static int    iHadExist=0;

    if (iHadExist == 0) {
      if (g_cTmMode == CHINESE_TYPE) {
        sg_pstMenu2 = (struct stMenu *) InitTool(SERVSN_C,2);
      }
      else  {
        sg_pstMenu2 = (struct stMenu *) InitTool(SERVSN_E,2);
      }
      iHadExist = 1;
    }
    else {
      if (g_cTmMode == CHINESE_TYPE) {
      sg_pstMenu2 = (struct stMenu *) InitMenu(SERVSN_C,2);
      }
      else  {
      sg_pstMenu2 = (struct stMenu *) InitMenu(SERVSN_E,2);
      }
    }

    memset(caDateBuf,'\0',20);
    GetSsaInfo(GETTXNDATE,caDateBuf);
    RetrieveData( sg_pstMenu2,0,caDateBuf );
    memset(caOpmodeBuf,'\0',20);
    GetSsaInfo(GETOPMODE,caOpmodeBuf);
    RetrieveData( sg_pstMenu2,1,caOpmodeBuf );
    DisplayData( sg_pstMenu2 );
    iRc = Process( sg_pstMenu2 );

    while ( ( iRc < 49) || (iRc > 53) ) {
      ShowMsg(sg_pstMenu2, "Choice Error!!");
      iRc = Process( sg_pstMenu2);
    }
    *cCmd = (char) iRc;

    switch(*cCmd)  {
      case '1': 
               *cCmd = '7';
               break;
      case '2': 
               *cCmd = '8';
               break;
      case '3': 
               *cCmd = '9';
               break;
      case '4': 
               *cCmd = 'A';
               break;
      case '5': 
               *cCmd = 'Z';
               break;
    }

    return(0);
}

ShowToolScrn(char *cCmd)
{
    int  iRc,i,j;
    char caDateBuf[20];
    char caOpmodeBuf[20];
    struct stMenu *InitTool();
    static int    iHadExist=0;

    if (iHadExist == 0) {
      if (g_cTmMode == CHINESE_TYPE) {
        sg_pstMenu3 = (struct stMenu *) InitTool(TOOLSN_C,3);
      }
      else  {
        sg_pstMenu3 = (struct stMenu *) InitTool(TOOLSN_E,3);
      }
      iHadExist = 1;
    }
    else {
      if (g_cTmMode == CHINESE_TYPE) {
      sg_pstMenu3 = (struct stMenu *) InitMenu(TOOLSN_C,3);
      }
      else  {
      sg_pstMenu3 = (struct stMenu *) InitMenu(TOOLSN_E,3);
      }
    }

    memset(caDateBuf,'\0',20);
    GetSsaInfo(GETTXNDATE,caDateBuf);
    RetrieveData( sg_pstMenu3,0,caDateBuf );
    memset(caOpmodeBuf,'\0',20);
    GetSsaInfo(GETOPMODE,caOpmodeBuf);
    RetrieveData( sg_pstMenu3,1,caOpmodeBuf );
    DisplayData( sg_pstMenu3 );
    iRc = Process( sg_pstMenu3 );

    while ( ( iRc < 49) || (iRc > 51) ) {
      ShowMsg(sg_pstMenu2, "Choice Error!!");
      iRc = Process( sg_pstMenu3);
    }
    *cCmd = (char) iRc;

    switch(*cCmd)  {
      case '1': 
               *cCmd = 'B';
               break;
      case '2': 
               *cCmd = 'C';
               break;
      case '3': 
               *cCmd = 'Z';
               break;
    }
    return(0);
}

int ShowCfgScrn(char *caCmd,char cCmd)
{
    int i,iCmd;
    int iEntyCont;
    char cDummy;
    int  iRow,iCol;
    char caShowBuf[80];
    char cIn;
    struct stMenu *pstMenu;

    pstMenu = (struct stMenu *) InitNullMenu();
    ErrLog(10,"ShowCfgScrn:start",RPT_TO_LOG,0,0);

    iRow=0;
    if ( cCmd == MON_FORK) {
      ShowStr(pstMenu,iRow,0,"**** Fork Process Choice Menu ****",'d');
    }
    else  {
      ShowStr(pstMenu,iRow,0,"**** ShutDown Process Choice Menu ****",'d');
    }
    i=0;
    iRow++;
    while(MCfg(i).caPrgname[0] != '\0'){
      sprintf(caShowBuf,"%d.%s  %s",i,MCfg(i).caPrgname,MCfg(i).caPara);
      ShowStr(pstMenu,iRow,0,caShowBuf,'d');
      i++;
      iRow++;
    }

    if ( cCmd == MON_SHUTDOWN) {
      sprintf(caShowBuf,"%d.All Process.",i);
      ShowStr(pstMenu,iRow,0,caShowBuf,'d');
      iEntyCont = i ;
    }
    else {
      iEntyCont = i - 1;
    }
    iRow += 2;
    sprintf(caShowBuf,"Please enter a number of choice :(Q/q to quit)");
    ShowStr(pstMenu,iRow,0,caShowBuf,'d');
    iRow++;
    ShowStr(pstMenu,iRow,0," ",'e');
    GetInChar(pstMenu,iRow,0,&cIn);
    DisplayMenu( pstMenu );      /* to show menu onto the screen */

    caCmd[0] = cIn;
    caCmd[1] = '\0';
    /* is quit the choice */
    if((caCmd[0] == 'q') || (caCmd[0] == 'Q')){
      return(9);
    }

    /* check nonnummeric input */
    i=0;
    while(caCmd[i] != '\0'){
      iCmd=(int) caCmd[i];
      if((iCmd > 57) || (iCmd < 48)){
        return(-1);
      }
      i++;
    }

    iCmd=atoi(caCmd);
    sprintf(g_caMsg,"caCmd=%s iCmd=%d",caCmd,iCmd);
    ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
    /* check input is out of rang */
    if(iCmd > iEntyCont){
      return(-1);
    }
    /* set all process idx */
    if ( (iCmd == iEntyCont) && (cCmd == MON_SHUTDOWN) ){
      itoa1(ALL_IDX,caCmd,3); 
    }
    ErrLog(10,"ShowCfgScrn:end",RPT_TO_LOG,0,0);
    return(0);
}

int ShowFokScrn(char *caCmd)
{
    int i,iCmd;
    int iEntyCont;
    int iCfgIdx;
    char cDummy;
    int  iRow,iCol;
    char caShowBuf[80];
    char cIn;
    struct stMenu *pstMenu;

    pstMenu = (struct stMenu *) InitNullMenu();

    iRow = 0;
    ErrLog(10,"ShowFokScrn:start",RPT_TO_LOG,0,0);
    ShowStr(pstMenu,iRow,0,"***** List The Processes For Choice to operate *****",'d');
    i=0;
    iRow++;
    while(MFok(i).iProcid != -1){
      iCfgIdx=MFok(i).iTblidx;
      sprintf(caShowBuf,"%d.%s %s",i,MCfg(iCfgIdx).caPrgname,MCfg(iCfgIdx).caPara);
      ShowStr(pstMenu,iRow,0,caShowBuf,'d');
      i++;
      iRow++;
    }
    sprintf(caShowBuf,"%d.All Process.",i);
    ShowStr(pstMenu,iRow,0,caShowBuf,'d');
    iEntyCont = i;
    iRow += 2;
    sprintf(caShowBuf,"Please enter a number of choice :(Q/q to quit)");
    ShowStr(pstMenu,iRow,0,caShowBuf,'d');

    iRow++;
    ShowStr(pstMenu,iRow,0," ",'e');
    GetInChar(pstMenu,iRow,0,&cIn);

    DisplayMenu( pstMenu );      /* to show menu onto the screen */

    caCmd[0] = cIn;
    caCmd[1] = '\0';

    /* is quit the choice */
    if((caCmd[0] == 'q') || (caCmd[0] == 'Q')){
      return(9);
    }

    /* check nonnummeric input */
    i=0;
    while(caCmd[i] != '\0'){
      iCmd = (int) caCmd[i];
      if((iCmd > 57) || (iCmd < 48)){
        return(-1);
      }
      i++;
    }

    iCmd=atoi(caCmd);
    sprintf(g_caMsg,"caCmd=%s iCmd=%d",caCmd,iCmd);
    ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
    /* check input is out of rang */
    if(iCmd > iEntyCont){
      return(-1);
    }

    /* set all process idx */
    if(iCmd == iEntyCont){
      itoa1(ALL_IDX,caCmd,3); 
    }
    ErrLog(10,"ShowFokScrn:end",RPT_TO_LOG,0,0);
    return(0);
}

int ShowPrcStat(int iIdx)
{
    int i;
    int iCfgIdx;
    char cPause;
    char caPrcSta[20], caMonErr[25];
    int  iRow,iCol;
    char caShowBuf[80];
    char cIn;
    struct stMenu *pstMenu;

    pstMenu = (struct stMenu *) InitNullMenu();

    iRow = 0;
    ShowStr(pstMenu,iRow,0,"***** Forked Process name | Process Status | Monitor Error Message | Errno *****",'d');
    iRow++;
    if(iIdx == ALL_IDX){
      i=0;
      while(MFok(i).iProcid != -1){
        sprintf(g_caMsg,"MFok(%d).iProcid=%d",i,MFok(i).iProcid);
        ErrLog(10,g_caMsg,RPT_TO_LOG,0,0); 
        iCfgIdx=MFok(i).iTblidx;
        sprintf(caShowBuf,"%d.%s %s",i,MCfg(iCfgIdx).caPrgname,MCfg(iCfgIdx).caPara);
        ShowStr(pstMenu,iRow,0,caShowBuf,'r');
        CovStatStr(MFok(i).cStatus,caPrcSta,MFok(i).iMonerr,caMonErr);
        sprintf(caShowBuf," %s %s %d",caPrcSta,caMonErr,MFok(i).iErrno);
        ShowStr(pstMenu,iRow,26,caShowBuf,'d');
        i++;
        iRow++;
      }
      sprintf(g_caMsg,"MFok(%d).iProcid=%d",i,MFok(i).iProcid);
      ErrLog(10,g_caMsg,RPT_TO_LOG,0,0); 
    }
    else{
      i=iIdx;
      iCfgIdx=MFok(i).iTblidx;
      sprintf(caShowBuf,"%d.%s %s ",i,MCfg(iCfgIdx).caPrgname,MCfg(iCfgIdx).caPara);
      ShowStr(pstMenu,iRow,0,caShowBuf,'r');
      CovStatStr(MFok(i).cStatus,caPrcSta,MFok(i).iMonerr,caMonErr);
      sprintf(caShowBuf," %s %s %d",caPrcSta,caMonErr,MFok(i).iErrno);
      ShowStr(pstMenu,iRow,26,caShowBuf,'d');
    }
    ShowMsg(pstMenu,23,20," Please press any key to continue.");
    DisplayMenu(pstMenu);
    wgetch(pstMenu->pwWin);
    ErrLog(10,"ShowPrcStat:end",RPT_TO_LOG,0,0);
    wclear(pstMenu->pwWin);
    return(0);
}

ShowBatchScrn(char *cCmd)
{
    int  iRc;
    char caDateBuf[20];
    char caOpmodeBuf[20];
    struct stMenu *InitTool();
    static int    iHadExist=0;

    if (iHadExist == 0) {
      if (g_cTmMode == CHINESE_TYPE) {
        sg_pstMenu4 = (struct stMenu *) InitTool(BATCHSN_C,4);
      }
      else  {
        sg_pstMenu4 = (struct stMenu *) InitTool(BATCHSN_E,4);
      }
      iHadExist = 1;
    }
    else {
      if (g_cTmMode == CHINESE_TYPE) {
      sg_pstMenu4 = (struct stMenu *) InitMenu(BATCHSN_C,4);
      }
      else  {
      sg_pstMenu4 = (struct stMenu *) InitMenu(BATCHSN_E,4);
      }
    }

    memset(caDateBuf,'\0',sizeof(caDateBuf));
    GetSsaInfo(GETTXNDATE,caDateBuf);
    RetrieveData( sg_pstMenu4,0,caDateBuf );
    memset(caOpmodeBuf,'\0',sizeof(caOpmodeBuf));
    GetSsaInfo(GETOPMODE,caOpmodeBuf);
    RetrieveData( sg_pstMenu4,1,caOpmodeBuf );
    DisplayData( sg_pstMenu4 );

    iRc = Process( sg_pstMenu4 );

    while ( ( iRc < 49) || (iRc > 51) ) {
      ShowMsg(sg_pstMenu4, "Choice Error!!");
      iRc = Process( sg_pstMenu4);
    }
    *cCmd = (char) iRc;

    switch(*cCmd)  {
      case '1':
               *cCmd = 'F';
               break;
      case '2':
               *cCmd = 'G';
               break;
      case '3':
               *cCmd = 'Z';
               break;
      default:
               ShowMsg(sg_pstMenu4, "\n\nUnknown choice\n!!");
               break;
    }
    return(0);
}



CovStatStr(cPrcSta, caPrcStat, iMonErr, caMonErr)
char cPrcSta;
char *caPrcStat;
int iMonErr;
char *caMonErr;
{
  sprintf(g_caMsg,"CovStatSrt:cPrcSta=%c iMonErr=%d",cPrcSta,iMonErr);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
  /* forked process status */
  switch(cPrcSta){
    case PRC_NORMAL :
           strcpy(caPrcStat,"PRC_NORMAL        ");
           break;
    case PRC_FORK_OK :
           strcpy(caPrcStat,"PRC_FORK_OK       ");
           break;
    case PRC_FORK_ERR :
           strcpy(caPrcStat,"PRC_FORK_ERR      ");
           break;
    case PRC_EXEC_OK :
           strcpy(caPrcStat,"PRC_EXEC_OK       ");
           break;
    case PRC_EXEC_ERR :
           strcpy(caPrcStat,"PRC_EXEC_ERR      ");
           break;
    case PRC_KILL_OK :
           strcpy(caPrcStat,"PRC_KILL_OK       ");
           break;
    case PRC_KILL_ERR :
           strcpy(caPrcStat,"PRC_KILL_ERR      ");
           break;
    case PRC_SHUTDOWN_OK :
           strcpy(caPrcStat,"PRC_SHUTDOWN_OK   ");
           break;
    case PRC_SHUTDOWN_ERR :
           strcpy(caPrcStat,"PRC_SHUTDOWN_ERR  ");
           break;
    case PRC_RESTART_OK :
           strcpy(caPrcStat,"PRC_RESTART_OK    ");
           break;
    case PRC_RESTART_ERR :
           strcpy(caPrcStat,"PRC_RESTART_ERR   ");
           break;
    case PRC_DEAD :
           strcpy(caPrcStat,"PRC_DEAD          ");
           break;
    case PRC_UNFORK :
           strcpy(caPrcStat,"PRC_UNFORK        ");
           break;
    default:
           strcpy(caPrcStat,"ERROR MSG UNDEFINE");
           break;
  }

  /* monitor error code */
  switch(iMonErr){
    case MON_NORMAL :
           strcpy(caMonErr,"MON_NORMAL            ");
           break;
    case MON_READ_FILE_ERR :
           strcpy(caMonErr,"MON_READ_FILE_ERR     ");
           break;
    case MON_LOAD_OVERFLOW :
           strcpy(caMonErr,"MON_LOAD_OVERFLOW     ");
           break;
    case MON_FORK_ERR :
           strcpy(caMonErr,"MON_FORK_ERR          ");
           break;
    case MON_EXEC_ERR :
           strcpy(caMonErr,"MON_EXEC_ERR          ");
           break;
    case MON_RCV_STAT_ERR :
           strcpy(caMonErr,"MON_RCV_STAT_ERR      ");
           break;
    case MON_OPEN_Q_ERR :
           strcpy(caMonErr,"MON_OPEN_Q_ERR        ");
           break;
    case MON_READ_Q_ERR :
           strcpy(caMonErr,"MON_READ_Q_ERR        ");
           break;
    case MON_READ_Q_TIMEOUT_ERR :
           strcpy(caMonErr,"MON_READ_Q_TIMEOUT_ERR");
           break;
    case MON_WRITE_Q_ERR :
           strcpy(caMonErr,"MON_WRITE_Q_ERR       ");
           break;
    case MON_COMM_ERR :
           strcpy(caMonErr,"MON_COMM_ERR          ");
           break;
    case MON_KILL_ERR :
           strcpy(caMonErr,"MON_KILL_ERR          ");
           break;
    case MON_SHUTDOWN_ERR :
           strcpy(caMonErr,"MON_SHUTDOWN_ERR      ");
           break;
    case MON_DCS_ERR :
           strcpy(caMonErr,"MON_DCS_ERR           ");
           break;
    case MON_GETOKEN_ERR :
           strcpy(caMonErr,"MON_GETOKEN_ERR       ");
           break;
    case MON_CMD_ERR :
           strcpy(caMonErr,"MON_CMD_ERR           ");
           break;
    case MON_PROC_OVERFLOW :
           strcpy(caMonErr,"MON_PROC_OVERFLOW     ");
           break;
    case MON_PARA_OVERFLOW :
           strcpy(caMonErr,"MON_PARA_OVERFLOW     ");
           break;
    case MON_CNFG_ERR :
           strcpy(caMonErr,"MON_CNFG_ERR          ");
           break;
    case MON_PROC_OVERLIMIT :
           strcpy(caMonErr,"MON_PROC_OVERLIMIT    ");
           break;
    case MON_UNWK_OVERFLOW :
           strcpy(caMonErr,"MON_UNWK_OVERFLOW     ");
           break;
    case MON_RESTART_LIMIT_ERR :
           strcpy(caMonErr,"MON_RESTART_LIMIT_ERR ");
           break;
    case MON_HAS_NO_PROCESS_TO_SHUTDOWN :
           strcpy(caMonErr,"MON_HAS_NO_PROCESS_TO_SHUTDOWN ");
           break;
    case MON_HAS_NO_PROCESS_TO_KILL :
           strcpy(caMonErr,"MON_HAS_NO_PROCESS_TO_KILL ");
           break;
    case MON_SAVE_CWA_ERR:
           strcpy(caMonErr,"MON_SAVE_CWA_ERR ");
           break;
    default:
           strcpy(caMonErr,"ERROR MSG UNDEFINE    ");
           break;
  }
  sprintf(g_caMsg,"CovStatSrt:caPrcStat=%s caMonErr=%s",caPrcStat,caMonErr);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
}

/*--------------------------------------------------------------------------*/
/* end routing								    */
/*--------------------------------------------------------------------------*/
EndRtn(dcs_buf,iSessidx,pstMenu)
struct DcsBuf *dcs_buf;
int iSessidx;
struct stMenu *pstMenu;
{
  int i, iRc;
  int iRcvDataLen;
  int iStatus;
  struct FkdStat stFkdStat; /* monitor rtn the forked process's status  */
  char caPrcSta[20], caMonErr[25];
  char caShowBuf[80];

  /* a dummy receive */
  i=0;
  while((PcMoreByte(dcs_buf) == '1') && (i++ < 5)){
    PcRqstCode(dcs_buf) = DCSREAD;
    /* TCC
    PlWaiTime(dcs_buf) = 10;*/ /* emmcntl dummy receive time out is 10 sec */
    PlWaiTime(dcs_buf) = 60; /* emmcntl dummy receive time out is 10 sec */
    PiDataLen(dcs_buf) = 1024;
    PcProto(dcs_buf) = QUEUE_DCS;
    PiSesIdx(dcs_buf) = iSessidx;
    DcsDispatch(dcs_buf);
    if(PiReply(dcs_buf) != DCS_NORMAL){
       sprintf(g_caMsg,"emmcntl:i=%d EndRtn dummy DCSREAD error reply %d errno %d",i,PiReply(dcs_buf),PiErrno(dcs_buf));
       ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    }
    else {
      PcMoreByte(dcs_buf) == '0';
    }
  }  /* FOR while((PcMore..))  */

  iRcvDataLen= MiDataLen(stDcsBuf) - 8 ;
  if(iRcvDataLen > sizeof(struct FkdStat)){
    sprintf(g_caMsg,"EndRtn:rcv fkd data reply %d errno %d",
            MiReply(stDcsBuf),MiErrno(stDcsBuf));
    ErrLog(1000,g_caMsg,RPT_TO_LOG,McaData(stDcsBuf),iRcvDataLen);
    return (MON_CMD_ERR);
  }

  memcpy(stFkdStat.caTblidx,McaData(stDcsBuf),5);
  stFkdStat.cStatus = McaData(stDcsBuf)[5];

  iRc = 0;
  if (stFkdStat.cStatus == 0) {
    ShowMsg(pstMenu,22,20," EXECUTE COMMAND OK!!!");
    ShowMsg(pstMenu,23,20," Please press any key to continue.");
    DisplayMenu(pstMenu);
    wgetch(pstMenu->pwWin);
  }
  else  {
    iStatus = (int) stFkdStat.cStatus;
    CovStatStr('0',caPrcSta,iStatus,caMonErr);
    sprintf(caShowBuf," EXECUTE COMMAND error!!! status = %s",caMonErr);
    ShowMsg(pstMenu,19,5,caShowBuf);
    if (iStatus == MON_SAVE_CWA_ERR)
    {
      ShowMsg (pstMenu, 20, 5,
        " Failure to save files sbcwa0.bin/sbcwa1.bin!");
      ShowMsg (pstMenu, 21, 5,
        " (1) Please check permission of files sbcwa0.bin/sbcwa1.bin!");
      ShowMsg (pstMenu, 22, 5,
        " (2) Please check if file system is full!");
      iRc = MON_SAVE_CWA_ERR;
    }

    ShowMsg(pstMenu,23,20," Please press any key to continue.");
    DisplayMenu(pstMenu);
    wgetch(pstMenu->pwWin);
  }

  /* receive server response */
  PcRqstCode(dcs_buf) = DCSDISCONNECT;
  PcProto(dcs_buf) = QUEUE_DCS;
  PiSesIdx(dcs_buf) = g_iSessidx;
  PiDataLen(dcs_buf) = 0;
  DcsDispatch(dcs_buf);
  if(PiReply(dcs_buf) != DCS_NORMAL){
    sprintf(g_caMsg,"emmcntl:EndRtn DCSDISCONNECT error reply %d errno %d",
                                    PiReply(dcs_buf),PiErrno(dcs_buf));
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
  }

  return (iRc);
}

int
SendCmdToMon(struct MonCmd *stCmd,struct stMenu *pstMenu)
{
  int  iLen, iRc;
  char caTmpBuf[20];

  /* initial dcs_buf & DcsSiof */
  memset(&stDcsSiof,0x00,sizeof(struct DcsSiof));
  memset(&stDcsBuf,0x00,sizeof(struct DcsBuf));
  memcpy(McaDesCode(stDcsBuf), MONITOR_HOST, DEST_NAME_LEN);
  memcpy(McaServCode(stDcsBuf),MON_TXN_CODE,4);
  MpstDcsSiof(stDcsBuf) = &stDcsSiof;
  iLen=sizeof(struct MonCmd);

  memcpy(McaData(stDcsBuf),stCmd,iLen);
  McRqstCode(stDcsBuf) = DCSCONNECTWRITE;
  /* TCC
  MlWaiTime(stDcsBuf) = 10;*/ /* rctst dummy receive time out is 10 sec */
  MlWaiTime(stDcsBuf) = 60; /* rctst dummy receive time out is 10 sec */
  McProto(stDcsBuf) = QUEUE_DCS;
  MiDataLen(stDcsBuf) = iLen+8;
  McKind(stDcsBuf) = 'A';
  itoa1(iLen,caTmpBuf,5);
  caTmpBuf[5] = '\0';
  memcpy(McaDataLen(stDcsBuf),caTmpBuf,5);
  DcsDispatch(&stDcsBuf);
  g_iSessidx = MiSesIdx(stDcsBuf);
  if(MiReply(stDcsBuf) != DCS_NORMAL){
     sprintf(g_caMsg,"emmcntl.c:DCSCONNECTWRITE to monitor fail reply=%d errno=%d", MiReply(stDcsBuf),MiErrno(stDcsBuf));
     ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
     return(-1);
  }

  McMoreByte(stDcsBuf) = '1';
  iRc = EndRtn(&stDcsBuf,g_iSessidx,pstMenu);

  return (iRc);
}

int Quit(struct stMenu *pstMenu)
{
  /* terminate communication */
  McRqstCode(stDcsBuf) = DCSTERMINATE;
  McProto(stDcsBuf) = QUEUE_DCS;
  DcsDispatch(&stDcsBuf);
  if(MiReply(stDcsBuf) != DCS_NORMAL)
  {
     sprintf(g_caMsg,"P_env_setup:DCSTERMINATE error,rtn_code=%d,errno=%d",
             MiReply(stDcsBuf),MiErrno(stDcsBuf));
     ErrLog(1000, g_caMsg, RPT_TO_LOG,0,0);
  }

  EndTool(pstMenu);
  return(0); 
}

int
GetSsaInfo(iKind,pcaRtnStr)
int  iKind;
char *pcaRtnStr;
{
  int   iRc;
  struct SSA    *pstSsa;
  struct CwaCtl stCwaCtl;
  char   caTmpBuf[20];
  short  sStatus;
  char   *D_String();

  /* attach SSA share memory */
  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);

  if (iRc != 0) {
    sprintf(g_caMsg,"GetSsaInfo:get SSA error!!");
    ErrLog(40000,g_caMsg,RPT_TO_TTY|RPT_TO_LOG,0,0);
  }

  sStatus = pstSsa->sSysStatus;

  switch(iKind)  {
    case GETTXNDATE:
      memcpy(caTmpBuf,pstSsa->caTxnDate,8);
      memcpy(pcaRtnStr,D_String(caTmpBuf),10);
      break;
    case GETOPMODE:
      if ( !(sStatus & ONLINE_CLOSE) ) { 
        strcpy(pcaRtnStr,"ONLINE");
      }
      else  {
        strcpy(pcaRtnStr,"BATCH");
      }
      break;
    case GETSYSMODE:
      if ( !(sStatus & SYSTEM_RESTART) ) {  
        strcpy(pcaRtnStr,"NORMAL");
      }
      else  {
        strcpy(pcaRtnStr,"RESTART");
      }
      break;
  }

  return(0);
}

#define  DAYS_OFFSET   6  /* YYYYMMDD  */
#define  MNTH_OFFSET   4  /* YYYYMMDD  */
#define  YEAR_OFFSET   0  /* YYYYMMDD  */

char
*D_String(pcaDate_List)
char  *pcaDate_List ;
{
   /*  this procedure pack date string into date representation form */
    char   *pcaDate_String = "//////////\0" ;

    if(YEAR_OFFSET == 0)
    {
      strncpy(pcaDate_String+0,pcaDate_List+YEAR_OFFSET,4);/* date_string+0  */
      strncpy(pcaDate_String+5,pcaDate_List+MNTH_OFFSET,2);/* date_string+5  */
      strncpy(pcaDate_String+8,pcaDate_List+DAYS_OFFSET,2);/* date_string+8  */
    }
    else
    {
      strncpy(pcaDate_String+6,pcaDate_List+YEAR_OFFSET,4);/* date_string+6  */
      strncpy(pcaDate_String+3,pcaDate_List+MNTH_OFFSET,2);/* date_string+3  */
      strncpy(pcaDate_String+0,pcaDate_List+DAYS_OFFSET,2);/* date_string+0  */
    }

    return(pcaDate_String);
}

ForkEmsTool(struct MonCmd *pstMonCmd)
{
  int iChiPid, iWaitCode, iStatus;
  char caExePath[MAX_EXEC_PATH_LEN], caExeName[FILE_NAME_LEN], caCmd[6];

  switch (pstMonCmd->cCmd){
    case TPE_DUMPCWA:
      strcpy(caExeName,CWATOOL);
      break;
    case TPE_DUMPBIT:
      strcpy(caExeName,BITTOOL);
      break;
  }

  if ((iChiPid=fork()) == 0 ) {
    memset (caExePath, 0, sizeof(caExePath));
    sprintf (caExePath, "%s/iii/bin/exe/%s",
             (char *)getenv("III_DIR"), caExeName);
    memcpy (pstMonCmd->caTblidx, "11111", 5);
    memcpy (caCmd, pstMonCmd, 6);

    if (execl(caExePath,caExeName,caCmd,(char *)0) != 0)
    {
      sprintf (g_caMsg, "<EMS> Failure to execute [%s]. (errno:%d=>%s)",
               caExePath, errno, sys_errlist[errno]);
      printf ("\n%s\n", g_caMsg);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      getchar ();
      exit (TOOLPROG_EXEC_ERR);
    }
    sprintf (g_caMsg, "<EMS> Fork and execute [%s %s]", caExePath, caCmd);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
  }
  else{
    if(iChiPid == -1) {
      sprintf (g_caMsg, "<EMS> Failure to fork to execute [%s]. (errno:%d=>%s)",
               caExePath, errno, sys_errlist[errno]);
      printf ("\n%s\n", g_caMsg);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      getchar ();
      return (FORK_TOOLPG_ERR);
    }
  }

  while ( (iWaitCode = wait(&iStatus)) != iChiPid ) ;
  return(0);
}


Err_Hdl()
{
   Quit(sg_pstMenu1);
   system("clear");
   printf("Fatal error has cccured,Control Process can't connect with EMS\n");
   printf("Please execute <killallp> after these messages under Shell\n");
   printf("And restart EMS again or contact with the Platform Operator!!\n");
   exit(-1);
}

/****************AUXILIARY FUNCTIONS ******************************/

itoa(n,s)
char *s;
int n;
{
     int i;
     i=0;
     do  {
         *(s+i) = n % 10 + '0';
         i++;
     }   while ((n /= 10) >0);
     *(s+i) = '\0';
     reverse(s);
}

itoa1(n,s,len)
int n,len;
char *s;
{
 int i,j;

 itoa(n,s);
 i=strlen(s);
 if (i == len) {
   return(0);
 }
 else {
   for ( j=i; j >= 0; j-- )
     s[len-i+j]=s[j];
   while ( (len-i+j) >= 0 ) {
     s[len-i+j]='0';
     j--;
   }
 }
}

reverse(s)
char *s;
{
     int   i, j;
     char  c;

     for (i = 0, j = strlen(s) - 1 ; i < j ; i++, j--) {
          c = *(s+i);
          *(s+i) = *(s+j);
          *(s+j) = c;
     }
}
/****************AUXILIARY FUNCTIONS ******************************/
/* TCC */
int
FindBit(pstTmArea)
struct  TermArea  *pstTmArea;
{
  char   *pcaBitTbl;
  struct CwaCtl stCwaCtl;
  struct TermArea  stTermArea;
  struct BrhArea   stBrhArea;
  int    iTotBrhCnt,i;
  int    iOffset,iBrhOffset;
  int    iRc;
  char   caTtyStr[14];

  UCP_TRACE(P_FindBit2);

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_BIT_START;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcaBitTbl);
  if (iRc != 0)
  {
   sprintf (g_caMsg, "<EMs> Failure to get BIT pointer! (iRc:%d)", iRc);
   ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
   UCP_TRACE_END(iRc);
  }

  iRc = GetDevHostName(caTtyStr);
  if (iRc != 0)
  {
   sprintf (g_caMsg, "<EMS> GetDevHostName() fails! (iRc:%d)", iRc);
   ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
   UCP_TRACE_END(iRc);
  }
  if (caTtyStr[13] != '\0')  caTtyStr[13] = '\0';

  memcpy(&iTotBrhCnt,pcaBitTbl,4);
  iBrhOffset = 8;

  do  {
    memcpy(&stBrhArea,pcaBitTbl+iBrhOffset,sizeof(struct BrhArea));
    iOffset = stBrhArea.iTermOffset;

    while (iOffset != -1)  {
      memcpy(&stTermArea,pcaBitTbl+iOffset,sizeof(struct TermArea));
      if (strcmp(caTtyStr,stTermArea.caLogicId)== 0) {
        memcpy(pstTmArea,&stTermArea,sizeof(struct TermArea));
        UCP_TRACE_END(0);
      }
      else  {
        iOffset = stTermArea.iNxtTmOffset;
      }
    }

    iBrhOffset = stBrhArea.iNxtBrhOffset;
  } while(iBrhOffset != -1);

  if ((iOffset == -1)&&(iBrhOffset == -1))  {
    sprintf (g_caMsg,
             "<EMS> Failure to find terminal [%s] in BIT", caTtyStr);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END (UNDEFINED_TERM);
  }
}

