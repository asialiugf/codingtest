
/*
 *&N& File: emserhdl.c  ���Һ޲z�l�t�ο��~�B�z�{��
 *&N&   
 *&N&    TYPE      NAME                 DESCRIPTION
 *&N& --------- ---------- ---------------------------------------- 
 *&N&    int       EmsErrHdl    ���Һ޲z�l�t�ο��~�B�z�{��
 *&N&    int       ErrorMap     ���Һ޲z�l�t�ο��~�X�ഫ�{��
 *&N&
 */


/* ---------------------- INCLUDE FILES DECLARATION ------------------- */
#include  "twa.h"
#include  "errlog.h"
#include  "errno.h"
#include  "emcpgdef.h"	/* EMS �ҨϥΨ쪺�@�ǵ{���Ψ�ƥN�� */
#include  "emcerror.h"	/* EMS ���~�T�� */


/* ------------------------- CONSTANT DEFINITION ---------------------- */
#define         PRG_ID_LEN                  5
#define         RET_CODE_LEN                2
#define         ROLLBACK_FLAG              '1'

#define         NO 			    0
#define         YES 			    1

#define         INFORM_DBP_MASK           0x01 
#define         DO_ROLLBACK_MASK          0x02 
#define         INFORM_EMS_MASK           0x04 
#define         DO_ABEND_MASK             0x08 
#define         INFORM_DBP_FLAG           0x01 
#define         DO_ROLLBACK_FLAG          0x02 
#define         INFORM_EMS_FLAG           0x04 
#define         DO_ABEND_FLAG             0x08 

/* ------------------------- GLOBAL & EXTERN VARIABLE ------------------ */
char g_caToDbpErrCode[10];
int  g_iCwaExist=0;
extern char g_cErrActFlag;
extern struct TMA *g_pstTma;

/* ------------------------- FUNCTION PROTYPE -------------------------- */
void EmsErrHdl(char,int);
void ErrorMap(char,int);
void ErrorAction();
int IsMultipleDataEnd();
int IsListDataEnd();
char *GetPrgId(int);

extern  int errno;
extern char *sys_errlist[];

void
EmsErrHdl( char cL2Step , int iRc )
{
  ErrorMap( cL2Step, iRc );
  ErrorAction();
}

void
ErrorMap( char cL2Step , int iRc )
{
  char *pcPrgIdStr;
  char caErrorCode[10];
  char caIrcBuf[10];
  int  iPrgIdVal;              /* iPrgIdVal = atoi(pcPrgIdStr) */
  int  iAbsIrc;                /* iAbsIrc = abs(iRc)           */
  char caShowMsg[80];
  char *GetPrgId();

  memset( caErrorCode, 0, 10);
  memset( g_caToDbpErrCode, 0, 10);
  memset( caIrcBuf, 0, 10);

  if ( cL2Step == '0' ) {
    pcPrgIdStr = GetPrgId( 0 );
  }
  else {
    pcPrgIdStr = GetPrgId( 1 );
  }
  
  iPrgIdVal = atoi(pcPrgIdStr);
  iAbsIrc = abs(iRc);
  memcpy(caErrorCode , pcPrgIdStr, PRG_ID_LEN);
  sprintf(caIrcBuf,"%.2d", iAbsIrc );
  strncat(caErrorCode, caIrcBuf, RET_CODE_LEN);
  
/*
  sprintf(caShowMsg,"ErrorMap-------iPrgIdStr------%s-------\n",caErrorCode);
  EmsShowData('0',caShowMsg);
  sprintf(caShowMsg,"ErrorMap-------iPrgIdVal------%d-------\n",iPrgIdVal);
  EmsShowData('0',caShowMsg);
  sprintf(caShowMsg,"ErrorMap-------iAbsIrc------%d-------\n",iAbsIrc);
  EmsShowData('0',caShowMsg);
*/
  
  switch ( iPrgIdVal ) {
    case P_EnvSetup:
         /* TCC: */
         g_iCwaExist = 0;   
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,INIT_CUSTOMTBL_ERR_E,4); 
             break; 
           case 2:
             memcpy(g_caToDbpErrCode,GET_CUSTOMVALUE_ERR_E,4); 
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

    case P_SignlHdl:
         /* TCC: */
         g_iCwaExist = 0;   
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,SIGNAL_HDL_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

    case P_GetConfg:
         /* TCC: */
         g_iCwaExist = 0;   
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,INIT_CNFTBL_ERR_E,4); 
             break; 
           case 2:
             memcpy(g_caToDbpErrCode,GET_CWAKEY_ERR_E,4); 
             break;
           case 3:
             memcpy(g_caToDbpErrCode,GET_CTFKEY_ERR_E,4);
             break;
           case 4:
             memcpy(g_caToDbpErrCode,GET_ICTKEY_ERR_E,4);
             break;
           case 5:
             memcpy(g_caToDbpErrCode,GET_IETKEY_ERR_E,4);
             break;
           case 6:
             memcpy(g_caToDbpErrCode,GET_DBTKEY_ERR_E,4);
             break;
           case 7:
             memcpy(g_caToDbpErrCode,GET_SYSOPMODE_ERR_E,4);
             break;
           case 8:
             memcpy(g_caToDbpErrCode,GET_BRHIDLEN_ERR_E,4);
             break;
           case 9:
             memcpy(g_caToDbpErrCode,GET_TMIDLEN_ERR_E,4);
             break;
           case 10:
             memcpy(g_caToDbpErrCode,GET_TXNIDLEN_ERR_E,4);
             break;
           case 11:
             memcpy(g_caToDbpErrCode,GET_TESTMODE_ERR_E,4);
             break;
           case 12:
             memcpy(g_caToDbpErrCode,GET_TELLERIDLEN_ERR_E,4);
             break;
           case 13:
             memcpy(g_caToDbpErrCode,GET_LOADCVTTBL_ERR_E,4);
             break;
           case 14:
             memcpy(g_caToDbpErrCode,GET_SYSTEMROLE_ERR_E,4);
             break;
           case 15:
             memcpy(g_caToDbpErrCode,GET_BASEYEAR_ERR_E,4);
             break;
           case 16:
             memcpy(g_caToDbpErrCode,GET_NOBATCH_ERR_E,4);
             break;
           case 17:
             memcpy(g_caToDbpErrCode,GET_NOSIGNON_ERR_E,4);
             break;
           case 18:
             memcpy(g_caToDbpErrCode,GET_MAXPACKETSIZE_ERR_E,4);
             break;
           case 19:
             memcpy(g_caToDbpErrCode,GET_TMAX_ERR_E,4);
             break;
           case 20:
             memcpy(g_caToDbpErrCode,GET_TMIN_ERR_E,4);
             break;
           case 21:
             memcpy(g_caToDbpErrCode,GET_TOFFSET_ERR_E,4);
             break;
           case 22:
             memcpy(g_caToDbpErrCode,TMAX_VALUE_ERR_E,4);
             break;
           case 23:
             memcpy(g_caToDbpErrCode,TMIN_VALUE_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

    case P_EnvStatuChk:
         /* TCC: */
         g_iCwaExist = 0;   
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,CWA_HAD_EXISTED_ERR_E,4);
             /* TCC
             g_iCwaExist = 1;
             */
             /* TCC: */
             g_iCwaExist = 0;   
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;


    case P_CwaHdl:
         /* TCC: */
         g_iCwaExist = 1;   
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,CREATE_CWA_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode,ATTACH_CWA_ERR_E,4);
             break;
           case 3:
             memcpy(g_caToDbpErrCode,GET_SSA_PTR_ERR_E,4);
             break;
           case 4:
             memcpy(g_caToDbpErrCode,GET_BIT_PTR_ERR_E,4);
             break;
           case 5:
             memcpy(g_caToDbpErrCode,OPEN_BIT_ERR_E,4);
             break;
           case 6:
             memcpy(g_caToDbpErrCode,SCAN_BIT_ERR_E,4);
             break;
           case 7:
             memcpy(g_caToDbpErrCode,BIT_TYPE_ERR_E,4);
             break;
           case 8:
             memcpy(g_caToDbpErrCode,BR_LEN_ERR_E,4);
             break;
           case 9:
             memcpy(g_caToDbpErrCode,TM_LEN_ERR_E,4);
             break;
           case 10:
             memcpy(g_caToDbpErrCode,BIT_ENTRY_DUPL_ERR_E,4);
             break;
           case 11:
             memcpy(g_caToDbpErrCode,TM_TYPE_ERR_E,4);
             break;
           case 12:
             memcpy(g_caToDbpErrCode,GET_SES_PTR_ERR_E,4);
             break;
           case 13:
             memcpy(g_caToDbpErrCode,GET_SPA_PTR_ERR_E,4);
             break;
           case 14:
             memcpy(g_caToDbpErrCode,GET_B2N_PTR_ERR_E,4);
             break;
           case 15:
             memcpy(g_caToDbpErrCode,INIT_CVT_TBL_ERR_E,4);
             break;
           case 16:
             memcpy(g_caToDbpErrCode,BIT_OVERFLOW_ERR_E,4);
             break;
           case 17:
             memcpy(g_caToDbpErrCode,BRH_OVERFLOW_ERR_E,4);
             break;
           case 18:
             memcpy(g_caToDbpErrCode,TERM_OVERFLOW_ERR_E,4);
             break;
           case 19:
             memcpy(g_caToDbpErrCode,NO_BRH_ERR_E,4);
             break;
           case 20:
             memcpy(g_caToDbpErrCode,GET_MDA_PTR_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

    case P_KernTblLd:
         /* TCC: */
         g_iCwaExist = 0;   
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,OPEN_CTFFILE_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode,CNT_BUSINUM_ERR_E,4);
             break;
           case 3:
             memcpy(g_caToDbpErrCode,CREATE_CTFSHM_ERR_E,4);
             break;
           case 4:
             memcpy(g_caToDbpErrCode,READ_CTFFILE_ERR_E,4);
             break;
           case 5:
             memcpy(g_caToDbpErrCode,BUSI_DUPL_ERR_E,4);
             break;
           case 6:
             memcpy(g_caToDbpErrCode,OPEN_IETFILE_ERR_E,4);
             break;
           case 7:
             memcpy(g_caToDbpErrCode,IET_FILESIZE_NEG_ERR_E,4);
             break;
           case 8:
             memcpy(g_caToDbpErrCode,IET_FILESIZE_ERR_E,4);
             break;
           case 9:
             memcpy(g_caToDbpErrCode,CREATE_IETSHM_ERR_E,4);
             break;
           case 10:
             memcpy(g_caToDbpErrCode,READ_IETFILE_ERR_E,4);
             break;
           case 11:
             memcpy(g_caToDbpErrCode,IET_TYPE_ERR_E,4);
             break;
           case 12:
             memcpy(g_caToDbpErrCode,CTF_SIZE_ERR_E,4);
             break;
           case 13:
             memcpy(g_caToDbpErrCode,CIT_SIZE_ERR_E,4);
             break;
           case 14:
             memcpy(g_caToDbpErrCode,GUD_SIZE_ERR_E,4);
             break;
           case 15:
             memcpy(g_caToDbpErrCode,MENU_SIZE_ERR_E,4);
             break;
           case 16:
             memcpy(g_caToDbpErrCode,HLP_SIZE_ERR_E,4);
             break;
           case 17:
             memcpy(g_caToDbpErrCode,MST_SIZE_ERR_E,4);
             break;
           case 18:
             memcpy(g_caToDbpErrCode,CREATE_ICTSHM_ERR_E,4);
             break;
           case 19:
             memcpy(g_caToDbpErrCode,CIT_LOAD_ERR_E,4);
             break;
           case 20:
             memcpy(g_caToDbpErrCode,GUD_LOAD_ERR_E,4);
             break;
           case 21:
             memcpy(g_caToDbpErrCode,MENU_LOAD_ERR_E,4);
             break;
           case 22:
             memcpy(g_caToDbpErrCode,HLP_LOAD_ERR_E,4);
             break;
           case 23:
             memcpy(g_caToDbpErrCode,MST_LOAD_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

    case P_TpeIfSet:
         /* TCC: */
         g_iCwaExist = 1;   
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,OPEN_MODFILE_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode,MODFILE_FORMAT_ERR_E,4);
             break;
           case 3:
             memcpy(g_caToDbpErrCode,MODPROG_EXEC_ERR_E,4);
             break;
           case 4:
             memcpy(g_caToDbpErrCode,FORK_MODPG_ERR_E,4);
             break;
           case 5:
             memcpy(g_caToDbpErrCode,RM_MODPROG_EXEC_ERR_E,4);
             break;
           case 6:
             memcpy(g_caToDbpErrCode,FORK_RM_MODPG_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

    case P_TxPreHdl:
         /* TCC: */
         g_iCwaExist = 1;   
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,OPEN_TXNPREFILE_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode,TXNPREFILE_FORMAT_ERR_E,4);
             break;
           case 3:
             memcpy(g_caToDbpErrCode,OPERATE_MODE_ERR_E,4);
             break;
           case 4:
             memcpy(g_caToDbpErrCode,SYSTEM_STATUS_ERR_E,4);
             break;
           case 5:
             memcpy(g_caToDbpErrCode,SHELL_EXEC_ERR_E,4);
             break;
           case 6:
             memcpy(g_caToDbpErrCode,SHELL_FORK_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

    case P_SysStart:
         /* TCC: */
         g_iCwaExist = 1;   
         switch( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,GET_SSA_PTR_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode,GET_SYSTEMROLE_ERR_E,4);
             break;
           case 3:
             memcpy(g_caToDbpErrCode,NOSUCH_BRHID_ERR_E,4);
             break;
           case 4:
             memcpy(g_caToDbpErrCode,ILL_STARTDATE_ERR_E,4);
             break;
           case 5:
             memcpy(g_caToDbpErrCode,TXNDATE_OVERFLOW_ERR_E,4);
             break;
           case 6:
             memcpy(g_caToDbpErrCode,CALFILE_NOEXIST_ERR_E,4);
             break;
           case 7:
             memcpy(g_caToDbpErrCode,READ_CALFILE_ERR_E,4);
             break;
           case 8:
             memcpy(g_caToDbpErrCode,UNKNOWN_CAL_ERR_E,4);
             break;
           case 9:
             memcpy(g_caToDbpErrCode,UNKNOWN_RTNCODE_ERR_E ,4);
             break;
           case 10:
             memcpy(g_caToDbpErrCode,UPT_TXNDATE_FMLOCAL_ERR_E ,4);
             break;
           case 11:
             memcpy(g_caToDbpErrCode,CENTER_NOTOPEN_ERR_E ,4);
             break;
           case 12:
             memcpy(g_caToDbpErrCode,TTY_NOTDEFINED_ERR_E,4);
             break;
           case 13:
             memcpy(g_caToDbpErrCode,GET_NOSIGNON_ERR_E,4);
             break;
           case 14:
             memcpy(g_caToDbpErrCode,FORWARD_RV_CWA_ERR_E,4);
             break;
           /* TCC: 1995/11/23 Begin */
           case 51:
             memcpy(g_caToDbpErrCode,F701_ERR_E,4);
             break;
           case 52:
             memcpy(g_caToDbpErrCode,F702_ERR_E,4);
             break;
           case 53:
             memcpy(g_caToDbpErrCode,F703_ERR_E,4);
             break;
           case 54:
             memcpy(g_caToDbpErrCode,F704_ERR_E,4);
             break;
           case 55:
             memcpy(g_caToDbpErrCode,F705_ERR_E,4);
             break;
           case 56:
             memcpy(g_caToDbpErrCode,F706_ERR_E,4);
             break;
           case 57:
             memcpy(g_caToDbpErrCode,F707_ERR_E,4);
             break;
           case 58:
             memcpy(g_caToDbpErrCode,F708_ERR_E,4);
             break;
           case 59:
             memcpy(g_caToDbpErrCode,F709_ERR_E,4);
             break;
           case 60:
             memcpy(g_caToDbpErrCode,F710_ERR_E,4);
             break;
           case 61:
             memcpy(g_caToDbpErrCode,F711_ERR_E,4);
             break;
           case 62:
             memcpy(g_caToDbpErrCode,F712_ERR_E,4);
             break;
           case 63:
             memcpy(g_caToDbpErrCode,F713_ERR_E,4);
             break;
           case 64:
             memcpy(g_caToDbpErrCode,F714_ERR_E,4);
             break;
           case 65:
             memcpy(g_caToDbpErrCode,F715_ERR_E,4);
             break;
           case 66:
             memcpy(g_caToDbpErrCode,F716_ERR_E,4);
             break;
           case 67:
             memcpy(g_caToDbpErrCode,F717_ERR_E,4);
             break;
           /* TCC: 1995/11/23 End */
           /* TCC: 1996/01/15 Begin */
           case 27:
             memcpy(g_caToDbpErrCode,FIND_BIT_ERR_E,4);
             break;
           case 28:
             memcpy(g_caToDbpErrCode,GET_BIT_PTR_ERR_E,4);
             break;
           case 29:
             memcpy(g_caToDbpErrCode,NETWORKTBL_ERR_E,4);
             break;
           case 30:
             memcpy(g_caToDbpErrCode,SEND_ERR_E,4);
             break;
           case 31:
             memcpy(g_caToDbpErrCode,READ_ERR_E,4);
             break;
           case 32:
             memcpy(g_caToDbpErrCode,GET_CENTER_DESKEY_ERR_E,4);
             break;

           /* TCC: 1996/01/15 End    */

           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

    case P_GetCalDate:
         /* TCC: */
         g_iCwaExist = 1;   
         switch ( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,GET_SSA_PTR_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode,FIND_BIT_ERR_E,4);
             break;
           case 3:
             memcpy(g_caToDbpErrCode,OPEN_TXNDATE_ERR_E,4);
             break;
           case 4:
             memcpy(g_caToDbpErrCode,TXNDATE_INPUT_ERR_E,4);
             break;
           case 5:
             memcpy(g_caToDbpErrCode,NOSUCH_BRHID_ERR_E,4);
             break;
           case 6:
             memcpy(g_caToDbpErrCode,ILL_STARTDATE_ERR_E,4);
             break;
           case 7:
             memcpy(g_caToDbpErrCode,TXNDATE_OVERFLOW_ERR_E,4);
             break;
           case 8:
             memcpy(g_caToDbpErrCode,CALFILE_NOEXIST_ERR_E,4);
             break;
           case 9:
             memcpy(g_caToDbpErrCode,READ_CALFILE_ERR_E,4);
             break;
           case 10:
             memcpy(g_caToDbpErrCode,UNKNOWN_CAL_ERR_E,4);
             break;
           case 11:
             memcpy(g_caToDbpErrCode,UNKNOWN_RTNCODE_ERR_E ,4);
             break;
           case 12:
             memcpy(g_caToDbpErrCode,NONBUSI_DATE_ERR_E ,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

/*
    case P_GetCkDat: 
         g_iCwaExist = 1;   
         switch ( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,GET_SSA_PTR_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode,FIND_BIT_ERR_E,4);
             break;
           case 3:
             memcpy(g_caToDbpErrCode,OPEN_TXNDATE_ERR_E,4);
             break;
           case 4:
             memcpy(g_caToDbpErrCode,TXNDATE_INPUT_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;
*/

    case P_SyStuIni:
         /* TCC: */
         g_iCwaExist = 1;   
         switch ( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,GET_SSA_PTR_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

    case P_IsuSvPrs 		:
         /* TCC: */
         g_iCwaExist = 1;   
         switch ( iAbsIrc ) {
           case 10:
             memcpy(g_caToDbpErrCode,OPEN_SERVER_FILE_ERR_E,4);
             break;
           case 11:
             memcpy(g_caToDbpErrCode,SERV_PARA_ERR_E,4);
             break;
           case 12:
             memcpy(g_caToDbpErrCode,SERV_ENTRY_OVERFLOW_ERR_E,4);
             break;
           case 13:
             memcpy(g_caToDbpErrCode,SERV_PROC_OVERFLOW_ERR_E,4);
             break;
           case 20:
             memcpy(g_caToDbpErrCode,OPEN_CHRON_FILE_ERR_E,4);
             break;
           case 21:
             memcpy(g_caToDbpErrCode,CHRON_PARA_ERR_E,4);
             break;
           case 22:
             memcpy(g_caToDbpErrCode,CHRON_PROC_OVERFLOW_ERR_E,4);
             break;
           case 30:
             memcpy(g_caToDbpErrCode,FORK_SERVER_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

    case P_WaitCmd 		: 
         /* TCC: */
         g_iCwaExist = 1;   
         switch ( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,GET_CMD_DCS_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode,RCV_CMD_DATA_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

    case P_Dispatch 		:
         /* TCC: */
         g_iCwaExist = 1;   
         switch ( iAbsIrc ) {
           case 1:
             memcpy(g_caToDbpErrCode,SENDACK_TO_CALLER_ERR_E,4);
             break;
           case 2:
             memcpy(g_caToDbpErrCode,REMOVE_COMPO_ERR_E,4);
             break;
           case 3:
             memcpy(g_caToDbpErrCode,SAVE_CWA_ERR_E,4);
             break;
           default:
             memcpy(g_caToDbpErrCode,SYSTEM_ERR_E,4);
         }
         break;

    default:
      sprintf (g_caMsg," <EMS> No such function program ID! (PrgID:%5d iRc=%d)"
              ,iPrgIdVal,iAbsIrc);
      ErrLog (1000, g_caMsg, RPT_TO_LOG|RPT_TO_TTY, 0, 0);
  } /* end switch */

}

#define  ERRMSG_F  "iii/etc/tbl/emderr.dat" 
#define  OPEN_ERRMSG_ERR   -1

void 
ErrorAction()
{
  int iRc ;
  char caShowMsg[80];
  char caFileName[80];
  FILE *zErrFp;  
  char caErrMsg[80];
  char caErrCode[10];
  int  iFound=0;
  int  iRdLen;
  char caTmpBuf[80];

  if (g_iCwaExist) { 
    ShutAll ();

    iRc = EnvRelse();
    if ( iRc != 0 ) {
      sprintf (g_caMsg, "<EMS> Failure to release chron/shm/sem");
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      printf ("<EMS> Failure to release TPE resources!\n");
    }

    iRc = RmComponent();
    if (iRc != 0) {
      sprintf (g_caMsg, 
               "<EMS> Failure to remove TPE interface components!");
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      printf ("<EMS> Failure to remove TPE interface components!\n");
    }
  }

  sprintf (caFileName, "%s/%s", (char *)getenv("III_DIR"), ERRMSG_F);
  zErrFp = fopen(caFileName,"r");
  if (zErrFp == NULL) {
    sprintf(g_caMsg, 
            "<EMS> Failure to open error message file %s! (errno:%d==>%s)",
            ERRMSG_F, errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("<EMS> Failure to open error message file %s! (errno:%d==>%s)",
            ERRMSG_F, errno, sys_errlist[errno]);
  }

  while ( fgets(caTmpBuf,80,zErrFp) != NULL )  {
  memset(caErrMsg, 0, sizeof(caErrMsg));
  memcpy(caErrCode,caTmpBuf,4);
  caErrCode[4] = '\0';
    strcpy(caErrMsg,&caTmpBuf[6]);
    if ( strncmp(caErrCode,g_caToDbpErrCode,4) == 0 ) {
      iFound = 1;
      break;
    }
  } 

  if (iFound != 1) {
    memset(caErrMsg, 0, sizeof(caErrMsg));
  }

  EmsShowData('0'," EMS ERROR message is \n");
  sprintf(caShowMsg,"%4s %s\n",g_caToDbpErrCode,caErrMsg);
  EmsShowData('0',caShowMsg);

}
