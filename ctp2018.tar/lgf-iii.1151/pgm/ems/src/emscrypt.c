char  *crypt(const char *,const char *);  /* Add 11/07 for SCO UNIX*/

char *
crypt(const char *pcaPassWord, const char *pcaCryptId)
{
  int  i,j;
  char caCryPass[14];
  char caHdlPass[11];
  char caRecPass;

  memset(caCryPass,'\0',14);
  memset(caHdlPass,'\0',11);
  memcpy(caCryPass,pcaCryptId,2);

  if(strlen(pcaPassWord) > 11) {
    memcpy(caHdlPass,pcaPassWord,10);
  }
  else {
    memcpy(caHdlPass,pcaPassWord,strlen(pcaPassWord));

    for(i=0,j=1;i<11,j<12;i+=2,j+=2) {
     if(caHdlPass[i] == '\0')
       caHdlPass[i] = '5';
     if(caHdlPass[j] == '\0')
       caHdlPass[j] = 'F';
    }

  }

  for(i=0,j=10;i<10,j>5;i+=2,--j) {
    caRecPass=caHdlPass[i];
    caHdlPass[i]=caHdlPass[j];
    caHdlPass[j]=caRecPass;
  }

  for(i=0;i<11;i++) {

    if ( (caHdlPass[i] >= 48) && (caHdlPass[i] <= 57) ) {
      caHdlPass[i] = caHdlPass[i] -  '0' + 'e' ;
    }
    else if ( (caHdlPass[i] >= 65) && (caHdlPass[i] <= 90) )  {
      caHdlPass[i] = caHdlPass[i] -  'A' + 'a' + pcaCryptId[0] - '0';
      if ( caHdlPass[i] > 'z' ) {
        caHdlPass[i] = caHdlPass[i] -  'z' + 'a';
      }
    }
    else if ( (caHdlPass[i] >= 97) && (caHdlPass[i] <= 122) )  {
      caHdlPass[i] = caHdlPass[i] -  'a' + 'A' + pcaCryptId[1] - '0';
      if ( caHdlPass[i] > 'Z' ) {
        caHdlPass[i] = caHdlPass[i] -  'Z' + 'A';
      }
    }

  }

  memcpy(&(caCryPass[2]),caHdlPass,11);
  caCryPass[13] = '\0';
  return(caCryPass);
}
