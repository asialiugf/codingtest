

/* ---------------- OLD BUSINESS DAY INPUT CODE ------------------------*/  
/* ---------------- int the emsstart.c's SysStart()---------------------*/  
#ifdef  OLDDAYINPUT
    /* Get the base year before the TXN day check  */
    g_iBaseYear = GetCnfValue( BASE_YEAR );

    EmsShowData('0',"TRANSACTION DATE CHECK\n");
    iRc = GetCkDat();
  
    if (iRc != 0) {
      *pcErrStep = '2';
      UCP_TRACE_END(iRc);  
    }
#endif

/* ---------------- OLD BUSINESS DAY INPUT CODE ------------------------*/  
/* -------------------------------------------------------------------- */
/* ----------Not used in the future between the line ------------------ */
/* ----------Replace with the routine                            ------ */
/* ----------Enter the date that the TPE open(defalut is system date)-- */
#ifdef  OLDDAYINPUT
 
#define  DATE_LEN      8
#define  DAYS_OFFSET   6  /* YYYYMMDD  */
#define  MNTH_OFFSET   4  /* YYYYMMDD  */
#define  YEAR_OFFSET   0  /* YYYYMMDD  */
#define  TRUE          1
#define  FALSE         0
#define  MAX_DATW      3
int      iaMax_Days[13] = {  0, 31, 28, 31, 30, 31, 30,
                                   31, 31, 30, 31, 30, 31} ;
#ifndef CURSES
int
GetCkDat()
{
  int    iTct_Cnt;
  char   *D_String();
  char   *pfTty_Code();
  char   caKey_Buf[81];
  char   caTmp_Buf[80];
  char   caShowBuf[80];
  int    iKey_Len;
  int    iRc;
  int    iDate_Chk_No;
  int    iDate_Win_No;
  struct SSA *pstSsa;
  struct CwaCtl stCwaCtl;
  struct TermArea  stTmArea;
  FILE   *zFp,*fopen();
  char   caFlName[FILE_NAME_LEN];
  short  sStatus;

  UCP_TRACE(P_GetCkDat);

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);

  if (iRc != 0) {
    UCP_TRACE_END(GET_SSA_PTR_ERR);
  }

  sStatus = pstSsa->sSysStatus;

  iRc = FindBit(&stTmArea);
  if (iRc != 0) {
    UCP_TRACE_END(FIND_BIT_ERR);
  }


  memset(caFlName,'\0',FILE_NAME_LEN);
  strcpy(caFlName,(char *) getenv("III_DIR"));
  strcat(caFlName,(char *) "/");
  if (stTmArea.cTermType == CHINESE_TYPE) {
    strcat(caFlName,TXNDAT_C);
  }
  else  {
    strcat(caFlName,TXNDAT_E);
  }

  zFp = fopen(caFlName,"r");
  if (zFp == NULL) {
    ErrLog(1000,g_caMsg,RPT_TO_TTY|RPT_TO_LOG,0,0);
    sprintf(g_caMsg,"LoadTct : Can't open txndate input errno = %d",errno);
    DetErrRpt(OPEN_FILE_ERR,g_caMsg);
    UCP_TRACE_END(OPEN_TXNDATE_ERR);
  }
 
  signal(SIGCLD, SIG_IGN);
  EmsShowData('1',"clear");

  while ( fgets(caTmp_Buf,80,zFp) != NULL ){
    EmsShowData('0',caTmp_Buf);
    EmsShowData('0',"\n");
  }

  fclose(zFp);

  if ( !(sStatus & SYSTEM_RESTART) ) {  
    EmsShowData('0',"System Status:NORMAL\n");
    EmsShowData('0',"\n");
  }
  else  {
    EmsShowData('0',"System Status:RESTART\n");
    EmsShowData('0',"\n");
  }
    
  if ( !(sStatus & ONLINE_CLOSE) ) { 
    EmsShowData('0',"Operating Mode:ONLINE\n");
    EmsShowData('0',"\n");
  }
  else  {
    EmsShowData('0',"Operating Mode:BATCH\n");
    EmsShowData('0',"\n");
  }
  memset(caTmp_Buf,'\0',80);
  memcpy(caTmp_Buf,&(pstSsa->caTxnDate[0]),8);

  sprintf(caShowBuf,"Date : %s\n",D_String(caTmp_Buf));
  EmsShowData('0',caShowBuf);

  iDate_Chk_No = -1;
  iDate_Win_No = -1;

  do {
    iDate_Win_No ++;
    memset(caKey_Buf,'\0',DATE_LEN);
    Get_Wdata(iDate_Win_No,DATE_LEN,caKey_Buf);
    Filter_Wdata(caKey_Buf);
    EmsShowData('0',"\r");
    EmsShowData('0',D_String(caKey_Buf));
    EmsShowData('0',"\n");
    if (Date_Valid(caKey_Buf))
      Txn_Date_Check(&iDate_Chk_No,&iDate_Win_No,caKey_Buf);
    else
      iDate_Win_No --;
  }  while (iDate_Win_No < MAX_DATW -1 );

  if (iDate_Win_No != iDate_Chk_No) {
    EmsShowData('0',"txn date input error!! \n");
    UCP_TRACE_END(TXNDATE_INPUT_ERR);
  }

  UCP_TRACE_END(0);
}
#else   /*  have to link emscurss.o */

#define NO_ITEM       3
#define NO_RECORD     1
#define MAX_DATA_LEN  20
struct stMenu {
	WINDOW *pwWin;
	int iNoRecord; /* the number of records shown at the same time */
	struct stMenu *pstNextMenu;
	struct stItem *pstItem;
	};
struct stItem {
	int iPage;
	int iRow;
	int iCol;
	int (*Routine1)();
	int (*Routine2)();
	char caData[ MAX_DATA_LEN ];
	char cType;
	int iLength;
	char cAttribute;
        } stRecord4[ NO_ITEM * NO_RECORD ] = {
            {1, 16, 48, NULL, NULL, "        ", 'c', 8, 'e'},
            {1, 18, 48, NULL, NULL, "        ", 'c', 8, 'e'},
            {1, 20, 48, NULL, NULL, "        ", 'c', 8, 'e'},
        };
int
GetCkDat()
{
  int    iTct_Cnt;
  char   *D_String();
  char   *pfTty_Code();
  char   caKey_Buf[81];
  char   caTmp_Buf[80];
  char   caShowBuf[80];
  int    iKey_Len;
  int    iRc;
  int    iDate_Chk_No;
  int    iDate_Win_No;
  struct SSA *pstSsa;
  struct CwaCtl stCwaCtl;
  struct TermArea  stTmArea;
  FILE   *zFp,*fopen();
  char   caFlName[FILE_NAME_LEN];
  short  sStatus;
  struct stMenu *pstMenu;
  int    iRow,iCol;
  int    iChkNo;

  UCP_TRACE(P_GetCkDat);

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);

  if (iRc != 0) {
    UCP_TRACE_END(GET_SSA_PTR_ERR);
  }

  sStatus = pstSsa->sSysStatus;

  iRc = FindBit(&stTmArea);
  if (iRc != 0) {
    UCP_TRACE_END(FIND_BIT_ERR);
  }

  memset(caFlName,'\0',FILE_NAME_LEN);
  strcpy(caFlName,(char *) getenv("III_DIR"));
  strcat(caFlName,(char *) "/");
  if (stTmArea.cTermType == CHINESE_TYPE) {
    strcat(caFlName,TXNDAT_C);
  }
  else  {
    strcat(caFlName,TXNDAT_E);
  }

  zFp = fopen(caFlName,"r");
  if (zFp == NULL) {
    ErrLog(1000,g_caMsg,RPT_TO_TTY|RPT_TO_LOG,0,0);
    sprintf(g_caMsg,"LoadTct : Can't open txndate input errno = %d",errno);
    DetErrRpt(OPEN_FILE_ERR,g_caMsg);
    UCP_TRACE_END(OPEN_TXNDATE_ERR);
  }

  pstMenu = (struct stMenu *) InitNullMenu1();
  pstMenu->pstItem = (struct stItem *) &stRecord4;

  signal(SIGCLD, SIG_IGN);

  iRow = 0;
  while (  fgets(caTmp_Buf,80,zFp) != NULL ){
    ShowStr(pstMenu,iRow,0,caTmp_Buf,'d');
    iRow++;
  }

  fclose(zFp);

  if ( !(sStatus & SYSTEM_RESTART) ) {  
    ShowStr(pstMenu,10,0,"System Status:NORMAL",'r');
  }
  else  {
    ShowStr(pstMenu,10,0,"System Status:RESTART",'r');
  }
    
  iRow += 2;
  if ( !(sStatus & ONLINE_CLOSE) ) { 
    ShowStr(pstMenu,12,0,"Operating Mode:ONLINE",'r');
  }
  else  {
    ShowStr(pstMenu,12,0,"Operating Mode:BATCH",'r');
  }
  memset(caTmp_Buf,'\0',80);
  memcpy(caTmp_Buf,&(pstSsa->caTxnDate[0]),8);

  iRow += 2;
  sprintf(caShowBuf,"Date : %s",D_String(caTmp_Buf));
  ShowStr(pstMenu,14,0,caShowBuf,'r');

  iRow += 2;
  iDate_Chk_No = -1;
  iDate_Win_No = -1;

  DisplayHead(pstMenu);
  DisplayData(pstMenu);

  do {
    iDate_Win_No ++;
    Get_Wdata(iDate_Win_No,caKey_Buf,pstMenu);
    Filter_Wdata(caKey_Buf);
    ShowStr(pstMenu,17+(iDate_Win_No*2),0,D_String(caKey_Buf),'r');
    if (Date_Valid(caKey_Buf,pstMenu)){
      iChkNo = iDate_Chk_No;
      Txn_Date_Check(&iDate_Chk_No,&iDate_Win_No,caKey_Buf,pstMenu);
      if (iDate_Chk_No != iChkNo) { /* compare both to know sucess or not */
        ShowMsg(pstMenu,23,20,"TxnDate Input Success!!");
        DisplayMenu(pstMenu);
      }
    }
    else
      iDate_Win_No --;
  }  while (iDate_Win_No < MAX_DATW -1 );
  ShowMsg(pstMenu,23,20,"TxnDate Input Success!! press any key to continue..");
  DisplayMenu(pstMenu);
  wgetch(pstMenu->pwWin);
  

  if (iDate_Win_No != iDate_Chk_No) {
    ShowMsg(pstMenu,23,20,"txn date input error!! ");
    UCP_TRACE_END(TXNDATE_INPUT_ERR);
  }

  EndTool(pstMenu);
  UCP_TRACE_END(0);
}
#endif

#ifndef CURSES
Get_Wdata(iWinno,iDatelen,pcaKey_Buf)
int  iWinno;
int  iDatelen;
char *pcaKey_Buf;
{
  char caTmpBuf[80];
  char caShowBuf[80];

     memset(caTmpBuf,'\0',80);

     switch(iWinno)  {
       case 0:
               strcpy(caTmpBuf,"Transaction");
               break;
       case 1:
               strcpy(caTmpBuf,"Next Transaction");
               break;
       case 2:
               strcpy(caTmpBuf,"Next  Next Transaction");
               break;
     }

     EmsShowData('0',"\n");
     sprintf(caShowBuf,"please enter the %s Day:\n",caTmpBuf);
     EmsShowData('0',caShowBuf);
     scanf("%8s",pcaKey_Buf);
     pcaKey_Buf[8] = 0x0;
}
#else
DisplayHead(pstMenu)
struct stMenu *pstMenu;
{
  char caTmpBuf[80];
  char caShowBuf[80];
  int  i;

  for (i=0;i<3;i++){   
    switch(i){
      case 0:
              strcpy(caTmpBuf,"Transaction");
              break;
      case 1:
              strcpy(caTmpBuf,"Next Transaction");
              break;
      case 2:
              strcpy(caTmpBuf,"Next  Next Transaction");
              break;
    }
    sprintf(caShowBuf,"Please enter the %s Day:",caTmpBuf);
    ShowStr(pstMenu,16+i*2,0,caShowBuf,'d');
  }
  sprintf(caShowBuf,"^D: Delete, ^U: Undo, Enter:Input Over.",caTmpBuf);
  ShowStr(pstMenu,22,0,caShowBuf,'d');
}

Get_Wdata(iWinno,pcaKey_Buf,pstMenu)
int  iWinno;
char *pcaKey_Buf;
struct stMenu *pstMenu;
{
  char caTmpBuf[80];
  char caShowBuf[80];
  int  i,j;
  char cChar;
  int  iKeyIn;
  int  iCurRow,iCurCol;

     memset(caTmpBuf,'\0',80);

     MvEdtItem(pstMenu,iWinno,A_UNDERLINE);
     keypad(pstMenu->pwWin,TRUE);

     while (1) {
       wrefresh( pstMenu->pwWin);
       iKeyIn = wgetch(pstMenu->pwWin);

       switch(iKeyIn)  {
         case 0x0797 :   /* ENTER */
         case CR :       /* ENTER */
           for(j=0;j<8;j++) {
              cChar = mvwinch(  pstMenu->pwWin,pstMenu->pstItem[ iWinno ].iRow,
                                pstMenu->pstItem[ iWinno ].iCol+j);
              pcaKey_Buf[j] = cChar;
           }
           pcaKey_Buf[8] = 0x0;
           return;
         case KEY_LEFT :
           getyx( pstMenu->pwWin, iCurRow, iCurCol );
           if ( iCurCol > pstMenu->pstItem[ iWinno ].iCol ) {
             wmove( pstMenu->pwWin, iCurRow, iCurCol - 1 );
           }
           else {
             Beep();
           }
           break;
         case KEY_RIGHT :
           getyx( pstMenu->pwWin, iCurRow, iCurCol );
           if ( iCurCol < pstMenu->pstItem[ iWinno ].iCol +
                          pstMenu->pstItem[ iWinno ].iLength - 1 ) {
             wmove( pstMenu->pwWin, iCurRow, iCurCol + 1 );
           }
           else {
             Beep();
           }
           break;
         case 0x04 :    /* Ctrl + d */
           DeleteCh( pstMenu, iWinno );
           break;
         case 0x15 :    /* Ctrl + u */
           Undo( pstMenu, iWinno );
           break;
         case '\x1b' :  /* ESC */
           Beep();
           break;
         default :
           AddCh( pstMenu, iWinno, iKeyIn, 0 );
           break;
       } /* FOR switch(iKeyIn) */
     } /* FOR while(1)  */
}
#endif
#ifndef CURSES
Txn_Date_Check(piChkno,piWinno,pcaKey_Buf)
int  *piChkno;
int  *piWinno;
char *pcaKey_Buf;
{
  int    iRc;
  struct CwaCtl stCwaCtl;
  struct SSA *pstSsa;
  short  sStatus;       /* the system status  */
  char   caTmp_Buf[80];
  char   caShowBuf[80];
  long   lDateInput,lDateCore;

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);

  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }

  if (g_iFirstRun == 1) {
    switch((*piWinno)) {
      case 0: /* first time enter */
        (*piChkno)++;
        memcpy(pstSsa->caTxnDate,pcaKey_Buf,DATE_LEN);
        break;
      case 1: /* second time enter */
        (*piChkno)++;
        memcpy(pstSsa->caNextDate,pcaKey_Buf,DATE_LEN);
        break;
      case 2: /* first time enter */
        (*piChkno)++;
        memcpy(pstSsa->caNext2Date,pcaKey_Buf,DATE_LEN);
        break;
    }
    return;
  }

  sStatus =  pstSsa->sSysStatus;

  if ( !(sStatus & SYSTEM_RESTART) ) {  
    /* Normal Begin,Can't Check next next day, if not load ACIF */
    switch((*piWinno)) {
      case 0: /* first time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caTxnDate,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
          memcpy(pstSsa->caTxnDate,pcaKey_Buf,DATE_LEN);
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caTxnDate[0]),8);
	  sprintf(caShowBuf,"business day check error!!%8s\r",D_String(caTmp_Buf));
          EmsShowData('0',caShowBuf);
	  Beep();
        }
        break;
      case 1: /* second time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caNextDate,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
          memcpy(pstSsa->caNextDate,pcaKey_Buf,DATE_LEN);
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
	  sprintf(caShowBuf,"business day check error!!%8s\r",D_String(caTmp_Buf));
          EmsShowData('0',caShowBuf);
	  Beep();
        }
        break;
      case 2: /* third  time enter */
        if ( (sStatus & ONLINE_CLOSE) ) {  /* Normal & Batch */ 
          iRc = strncmp(pcaKey_Buf,pstSsa->caNext2Date,DATE_LEN);
          if (iRc == 0) {
            (*piChkno)++;
            memcpy(pstSsa->caNext2Date,pcaKey_Buf,DATE_LEN);
          }
          else {      /* Normal & Online , Don't check Next2date */
            (*piWinno)--;
            memset(caTmp_Buf,'\0',80);
            memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
	    sprintf(caShowBuf,"business day check error!!%8s\r",D_String(caTmp_Buf));
            EmsShowData('0',caShowBuf);
	    Beep();
          }
        }
        else  {
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
          lDateCore  = atol(caTmp_Buf);
          lDateInput = atol(pcaKey_Buf);
          if (lDateInput > lDateCore) {
            memcpy(pstSsa->caNext2Date,pcaKey_Buf,DATE_LEN);
            (*piChkno)++;
          }
          else  {
            (*piWinno)--;
            memset(caTmp_Buf,'\0',80);
            memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
	    sprintf(caShowBuf,"next next business day should not small than %8s\r",D_String(caTmp_Buf));
            EmsShowData('0',caShowBuf);
	    Beep();
          }
        }
	break;
    }  /* FOR switch(...)  */
  }
  else {
    /* Abnormal Begin,Check business days in CWA */
    switch((*piWinno)) {
      case 0: /* first time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caTxnDate,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caTxnDate[0]),8);
	  sprintf(caShowBuf,"business day check error!!%8s\r",D_String(caTmp_Buf));
          EmsShowData('0',caShowBuf);
	  Beep();
        }
        break;
      case 1: /* second time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caNextDate,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
	  sprintf(caShowBuf,"business day check error!!%8s\r",D_String(caTmp_Buf));
          EmsShowData('0',caShowBuf);
	  Beep();
        }
        break;
      case 2: /* third  time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caNext2Date,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caNext2Date[0]),8);
	  sprintf(caShowBuf,"business day check error!!%8s\r",D_String(caTmp_Buf));
          EmsShowData('0',caShowBuf);
	  Beep();
        }
	break;
    }  /* FOR switch(...)  */
  }  /* FOR if( !(cStatus.....))  */

  return;
}
#else
Txn_Date_Check(piChkno,piWinno,pcaKey_Buf,pstMenu)
int  *piChkno;
int  *piWinno;
char *pcaKey_Buf;
struct stMenu *pstMenu;
{
  int    iRc;
  struct CwaCtl stCwaCtl;
  struct SSA *pstSsa;
  short  sStatus;       /* the system status  */
  char   caTmp_Buf[80];
  char   caShowBuf[80];
  long   lDateInput,lDateCore;

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);

  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }

  if (g_iFirstRun == 1) {
    switch((*piWinno)) {
      case 0: /* first time enter */
        (*piChkno)++;
        memcpy(pstSsa->caTxnDate,pcaKey_Buf,DATE_LEN);
        break;
      case 1: /* second time enter */
        (*piChkno)++;
        memcpy(pstSsa->caNextDate,pcaKey_Buf,DATE_LEN);
        break;
      case 2: /* first time enter */
        (*piChkno)++;
        memcpy(pstSsa->caNext2Date,pcaKey_Buf,DATE_LEN);
        break;
    }
    return;
  }

  sStatus =  pstSsa->sSysStatus;

  if ( !(sStatus & SYSTEM_RESTART) ) {  
    /* Normal Begin,Can't Check next next day, if not load ACIF */
    switch((*piWinno)) {
      case 0: /* first time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caTxnDate,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
          memcpy(pstSsa->caTxnDate,pcaKey_Buf,DATE_LEN);
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caTxnDate[0]),8);
	  sprintf(caShowBuf,"business day check error!!%8s",D_String(caTmp_Buf));
          ShowMsg(pstMenu,23,20,caShowBuf);
	  Beep();
        }
        break;
      case 1: /* second time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caNextDate,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
          memcpy(pstSsa->caNextDate,pcaKey_Buf,DATE_LEN);
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
	  sprintf(caShowBuf,"business day check error!!%8s",D_String(caTmp_Buf));
          ShowMsg(pstMenu,23,20,caShowBuf);
	  Beep();
        }
        break;
      case 2: /* third  time enter */
        if ( (sStatus & ONLINE_CLOSE) ) {  /* Normal & Batch */ 
          iRc = strncmp(pcaKey_Buf,pstSsa->caNext2Date,DATE_LEN);
          if (iRc == 0) {
            (*piChkno)++;
            memcpy(pstSsa->caNext2Date,pcaKey_Buf,DATE_LEN);
          }
          else {      /* Normal & Online , Don't check Next2date */
            (*piWinno)--;
            memset(caTmp_Buf,'\0',80);
            memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
	    sprintf(caShowBuf,"business day check error!!%8s",D_String(caTmp_Buf));
            ShowMsg(pstMenu,23,20,caShowBuf);
            EmsShowData('0',caShowBuf);
	    Beep();
          }
        }
        else  {
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
          lDateCore  = atol(caTmp_Buf);
          lDateInput = atol(pcaKey_Buf);
          if (lDateInput > lDateCore) {
            memcpy(pstSsa->caNext2Date,pcaKey_Buf,DATE_LEN);
            (*piChkno)++;
          }
          else  {
            (*piWinno)--;
            memset(caTmp_Buf,'\0',80);
            memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
	    sprintf(caShowBuf,"next next business day should not small than %8s",D_String(caTmp_Buf));
            ShowMsg(pstMenu,23,20,caShowBuf);
	    Beep();
          }
        }
	break;
    }  /* FOR switch(...)  */
  }
  else {
    /* Abnormal Begin,Check business days in CWA */
    switch((*piWinno)) {
      case 0: /* first time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caTxnDate,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caTxnDate[0]),8);
	  sprintf(caShowBuf,"business day check error!!%8s",D_String(caTmp_Buf));
          ShowMsg(pstMenu,23,20,caShowBuf);
	  Beep();
        }
        break;
      case 1: /* second time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caNextDate,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
	  sprintf(caShowBuf,"business day check error!!%8s",D_String(caTmp_Buf));
          ShowMsg(pstMenu,23,20,caShowBuf);
	  Beep();
        }
        break;
      case 2: /* third  time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caNext2Date,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caNext2Date[0]),8);
	  sprintf(caShowBuf,"business day check error!!%8s",D_String(caTmp_Buf));
          ShowMsg(pstMenu,23,20,caShowBuf);
	  Beep();
        }
	break;
    }  /* FOR switch(...)  */
  }  /* FOR if( !(cStatus.....))  */

  return;
}
#endif

#endif   /* for the #ifdef OLDDAYINPUT */
/* -------------------------------------------------------------------- */
/* ----------End for the code mark for the new business day input ----- */
