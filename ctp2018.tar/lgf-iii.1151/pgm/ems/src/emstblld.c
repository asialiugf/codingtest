/**


    �z�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�s�w�w�w�w�w�w�w�{
    �x<-(pcCtfBas)�~�ȭӼ�(4 Bytes) �x<-(pcCtfBusi) �x
    �u�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�}        �z�w�w�t
    �x�~�ȴy�z sizeof(busi_ctf)*�̤j�~�ȭӼ�  �x<-( �x
    �u�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�}    �x
    �xpcCtfItem) �@�P����榡�Ӷ��y�z               �x
    �x(struct ctf_item_def) .......                 �x
    �x                                              �x
    �x                                              �x
    �x                                              �x
    �x                                              �x
    �x                                              �x
    �x                                              �x
    �x                                              �x
    �|�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�}
**/


/* ------------------------------------------ */
/* function name definition in the emstblld.c */
/* ------------------------------------------ */
/*
#define  P_CtfBuild       1
#define  P_TxnBuild       2
#define  P_ChkBinFlSize   3
#define  P_CompCitSize    4
*/

/* ---------------------------------------- */
/* Error return value in the emstblld.c     */
/* ---------------------------------------- */
#define  OPEN_FILE_ERR  -1
#define  FILE_SIZE_ERR  -2
#define  ATTA_SHM_ERR   -3


#define  CTF_LOADED     ".. CTF TABLE has been loaded !!\n"
#define  TXN_LOADED     ".. IET TABLE has been loaded !!\n"


#include  <errno.h>
#include  <sys/types.h>
#include  <sys/stat.h>
#include  "errlog.h"
#include  "emctldef.h"
#include  "emctblld.h"
#include  "emctblof.h"
#include  "emcenvhl.h"
#include  "emcpgdef.h"

extern key_t  g_iCtfKey;
extern key_t  g_iIetKey;


/*
 *&N& ROUTINE NAME: CtfBuild()
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&           
 *&R& RETURN VALUES:
 *&R& 
 *&R&  -1 : �}���ɮ׿��~.
 *&R&  -2 : �ˬd�ɮפj�p�B�z���~.
 *&R&  -3 :    
 *&R&           
 *&R&           
 *&D& DESCRIPTION:           
 *&D&     ����Ƭ��إߦ@�P����榡����(CFT).
 *&D&   1.�}�Ҧ@�P����榡��,�I�s�t�Ψ��(open()).
 *&D&   2.�p��@�P����榡��(ctf_file)�j�p,�I�s(ChkBinFlSize() in emstblld.c).
 *&D&   3.�إ�  �J�@�P����榡����һݦ@�ΰO����Ŷ�,
 *&D&     �I�s(CrtTblArea() in tmsctf.c).
 *&D&   4.��Ū�J�@�P����榡�ɰO�����A(caCtfRecBuf[0])  �J�~�ȴy�z���,�Φ@�P��
 *&D&     ���榡���شy�z��� :
 *&D&     4.1 �ˬdŪ�J�ɮ׸�ƬO�_����.
 *&D&     4.2 �̰O�����A�]�w  �J��Ʀb�@�ΰO����Ŷ���},��  �J.
 *&D&   5.�����@�P����榡��,�I�s�t�Ψ��(close()).  
 *&D&           
 */


int
CtfBuild(ppcCtfBas)
char **ppcCtfBas;
{
   int iRc;
   int iCtfFd;
   int iShmFlg;
   int iBusiCnt;
   int iItemCnt;
   int iCtfFlSize;
   unsigned int uiShmSize;

   char *pcCtfBas,*pcCtfBusi,*pcCtfItem;
   char caCtfRecBuf[sizeof(ctf_head)];
   char caFlName[FILE_NAME_LEN];
   char caShowBuf[80];

   int iCnt;
   ctf_head *pstCtfHead;
   busi_ctf *pstCurBusiNd;
   busi_ctf *pstPrevBusiNd;
   ctf_item *pstCtfItem;
   ctf_item *pstCurCtfItem;

   UCP_TRACE(P_CtfBuild);


  
  /* ------------------- */
  /*    open ctf file    */
  /* ------------------- */
     /* -------------------- */
     /* get open file name   */
     /* -------------------- */
   memset(caFlName,'\0',FILE_NAME_LEN);
   strcpy(caFlName,(char *) getenv("III_DIR"));
   strcat(caFlName,(char *) "/");
   strcat(caFlName,CTF_FILE);

   iCtfFd = open(caFlName, O_RDONLY);
   if (iCtfFd < 0) {
     sprintf(g_caMsg,"Open CTF_FILE = [%s] error,errno = %d",caFlName,errno);
     ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
     sprintf(g_caMsg,"CtfBuild() : Can't open %s ,errno = %d",caFlName,errno);
     DetErrRpt(OPEN_FILE_ERR,g_caMsg);
     UCP_TRACE_END(OPEN_CTFFILE_ERR);
   }

   /* ------------------------- */
   /*    check ctf file size    */
   /* ------------------------- */
    iCtfFlSize = ChkBinFlSize(iCtfFd,caFlName);
    if (iCtfFlSize < 0) {
      sprintf(g_caMsg,"Call fstat() compute [%s] size errno = %d",
                                            caFlName,errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(CTF_SIZE_ERR);
    }
   /* ----------------------------- */
   /*  compute business node number */
   /* ----------------------------- */
    iBusiCnt = 0;
    iBusiCnt = CompBusiNum(iCtfFd);
/*
    if ( (iBusiCnt > 10) || (iBusiCnt <=0) ) {
      sprintf(g_caMsg,"call ComBusiNum error = %d",iBusiCnt);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(CNT_BUSINUM_ERR);
    }
*/
/*
    sprintf(g_caMsg,"CTFBUILD: BUSINESS CNT NO= %d",iBusiCnt);   
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
*/

   /* ---------------------------------- */
   /*    create ctf item share memory    */
   /* ---------------------------------- */
    uiShmSize = 4 +
                sizeof(busi_ctf) * iBusiCnt +
                iCtfFlSize;

    iRc = IpcShmCr(g_iCtfKey,uiShmSize,CTF_SHM_MODE,&pcCtfBas);
    if (iRc != 0) {
      sprintf(g_caMsg,"Creat CTF share memory error = %d",iRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(CREATE_CTFSHM_ERR);
    }

    pcCtfBusi = (char *)(pcCtfBas + 4); /* storing the busi_cnt */
    pcCtfItem = (char *)(pcCtfBusi + sizeof(busi_ctf) * iBusiCnt);

   /* ------------------------------------------------------------- */
   /*    establish business node and ctf item table share memory    */
   /* ------------------------------------------------------------- */
    lseek(iCtfFd,0L,SEEK_SET);
    iBusiCnt = 0;
    iItemCnt = 0;
    memset(caCtfRecBuf,'\0',sizeof(ctf_head));
    while ((iRc = read(iCtfFd,caCtfRecBuf,sizeof(ctf_head))) > 0) {
      if (iRc != sizeof(ctf_head)) {
        sprintf(g_caMsg,"BusiEstl() : read ctf_head =%d not completed",iRc);
        DetErrRpt(READ_CTFFILE_ERR,g_caMsg);
        UCP_TRACE_END(READ_CTFFILE_ERR);
      } /* if (iRc != sizeof(ctf_head))  */
      if (caCtfRecBuf[0] == M_CTF_HEAD ) {
       /* ------------------------ */
       /*  establish business node */
       /* ------------------------ */
         pstCtfHead = (ctf_head *) caCtfRecBuf;
         pstCurBusiNd =(busi_ctf *) (pcCtfBusi + sizeof(busi_ctf) * iBusiCnt++);
         iCnt = 0;
         while (iBusiCnt > ++iCnt) {
           pstPrevBusiNd =  pstCurBusiNd - iCnt;
           if (pstPrevBusiNd->cBusiType == pstCtfHead->cBusiType) {
             sprintf(g_caMsg,"BusiEstl() : dupl busi_type");
             DetErrRpt(BUSI_DUPL_ERR,g_caMsg);
             UCP_TRACE_END(BUSI_DUPL_ERR);
           }
         } /* while(iBusiCnt > ++iCnt) */
         pstCurBusiNd->cBusiType = pstCtfHead->cBusiType;
         pstCurBusiNd->iTotItem  = pstCtfHead->iTotItem;
         pstCurBusiNd->iCtfSize  = pstCtfHead->iCtfSize;
         pstCurBusiNd->iTblIdx   = iItemCnt;
      }
      else {
       /* ------------------------------ */
       /*  establish ctf_item to ctf_tbl */
       /* ------------------------------ */
         pstCtfItem = (ctf_item *) caCtfRecBuf;
         pstCurCtfItem =(ctf_item *)(pcCtfItem + sizeof(ctf_item) * iItemCnt++);
         strncpy(pstCurCtfItem->caCtfName,pstCtfItem->caCtfName,CTF_NAME_LEN);
         pstCurCtfItem->cDatType  = pstCtfItem->cDatType;
         pstCurCtfItem->iDatLen   = pstCtfItem->iDatLen;
         pstCurCtfItem->iCtfLen   = pstCtfItem->iCtfLen;
         pstCurCtfItem->iCtfOffs  = pstCtfItem->iCtfOffs;
         pstCurCtfItem->iCtfRelat = pstCtfItem->iCtfRelat;
         pstCurCtfItem->iDotPos   = pstCtfItem->iDotPos;
         pstCurCtfItem->cIniValue = pstCtfItem->cIniValue;
      } /* if (caCtfRecBuf[0] == M_CTF_HEAD ) */
      memset(caCtfRecBuf,'\0',sizeof(ctf_head));
    } /* while ((iRc = read(iCtfFd,caCtfRecBuf,sizeof(ctf_head)) > 0) */
    memcpy(pcCtfBas,&iBusiCnt, sizeof(int));
    *ppcCtfBas = pcCtfBas;
/*
    ErrLog(1000,"Dump Ctf_file",RPT_TO_LOG,pcCtfBas,300);
*/
    /* -------------------- */
    /*    close ctf file    */
    /* -------------------- */
    close(iCtfFd);
    sprintf(caShowBuf,"%s", CTF_LOADED);
    EmsShowData('0',caShowBuf);
    UCP_TRACE_END(0);
} /* CtfBuild() */

#define READ_FILE_ERR  -10

int
TxnBuild()
{
  int iRc;
  int iTxnFd;                  /* TXN_FILE file description */
  unsigned int uiTotIdxCnt;    /* */
  unsigned int uiIetShmSize;   /* Share memory space will be created */
  unsigned int uiIetKeySize;   /* Total key size of Iet Item Data */
  int iTxnFlSize;              /* TXN_FILE file Size */
  int iInAPageItmCnt;          /* Input Item number in the same one page */
  int iOriPage;                /* Is in the same one page flag :1(yes),0(no)-*/
  int iReadItmCnt;

  char *pcIetBas;   /* Iet Share memory starting address */
  char *pcKeyIdx;   /* Iet Indexe key starting address   */
  char *pcIetDat;   /* Iet detail item data starting address */
  char caIetKey[TXN_KEY_LEN+1];
  char caItemBuff[sizeof (struct busi_head_node)];
  struct busi_head_node *pstBusi;
  struct txn_head_node  *pstTxn;
  struct txn_item_node  *pstItem;
  char *pcBusi,*pcKey;
  char *pcTxn,*pcItem;
  char caTxnCd[TXN_CODE_LEN+1];
  char caFlName[FILE_NAME_LEN];
  char caShowBuf[80];

  UCP_TRACE(P_TxnBuild);
 /* -------------------------- */
 /*  compute size of txn_file  */
 /* -------------------------- */
  memset(caFlName,'\0',FILE_NAME_LEN);
  strcpy(caFlName,(char *) getenv("III_DIR"));
  strcat(caFlName,(char *) "/");
  strcat(caFlName,TXN_FILE);

  iTxnFd = open(caFlName, O_RDONLY); /*  open binary file from the parser */
  if (iTxnFd < 0) {
    sprintf(g_caMsg,"TxnBuild()--txn_file can't be open for read");
    DetErrRpt(OPEN_IETFILE_ERR,g_caMsg);
    UCP_TRACE_END(OPEN_IETFILE_ERR);
  }

  iTxnFlSize = ChkBinFlSize(iTxnFd,caFlName);
  if (iTxnFlSize < 0) {
    sprintf(g_caMsg,"ChkBinFlSize() Compute File Error! size=%d",iTxnFlSize);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(IET_FILESIZE_NEG_ERR);
  }

  if ( (iTxnFlSize % sizeof(busi_head))) {
    sprintf(g_caMsg,"TxnBuild()--txn_file size error");
    DetErrRpt(FILE_SIZE_ERR,g_caMsg);
    UCP_TRACE_END(IET_FILESIZE_ERR);
  }

  uiTotIdxCnt =  iTxnFlSize / sizeof(busi_head) ;
  uiIetKeySize = (TXN_KEY_LEN+1) * uiTotIdxCnt;/* 10 len of key : "........." */
  uiIetShmSize = iTxnFlSize   +            /* Item data sizes */
                 uiIetKeySize +            /* Index of Item size */
                 sizeof(int);  /*  the value of the data offset */

/*
  sprintf(g_caMsg,"uiTotIdxCnt = %d",uiTotIdxCnt);
  ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
*/
 /* ------------------------------------------ */
 /*    establish IET  share memory             */
 /* ------------------------------------------ */
  iRc = IpcShmCr(g_iIetKey,uiIetShmSize,IET_SHM_MODE,&pcIetBas);
  if (iRc != 0) {
    sprintf(g_caMsg,"Creat TXN_FILE share memory error iRc = %d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(CREATE_IETSHM_ERR);
  }

  pcKeyIdx = (char *) (pcIetBas + 4);  /* iTotIdxCnt int type occupy 4 bytes */
  pcIetDat = (char *) (pcKeyIdx + uiIetKeySize);

  memcpy(pcIetBas,&uiTotIdxCnt,4);

  iReadItmCnt = 0;

  while ((iRc = read(iTxnFd,caItemBuff,sizeof (busi_head))) > 0) {
/*
    sprintf(g_caMsg,"iReadItmCnt = %d",iReadItmCnt);
    ErrLog(1000,g_caMsg ,RPT_TO_LOG,0,0);
*/
    if ( iRc != sizeof(busi_head) ) {
      sprintf(g_caMsg,"read txn file not completed size =%d  error sizeof=%d",
                       iRc,sizeof(busi_head));
      DetErrRpt(READ_IETFILE_ERR,g_caMsg);
      close(iTxnFd);
      UCP_TRACE_END(READ_IETFILE_ERR);
    } /* if ( iRc != sizeof(struct busi_head) ) */
    memset(caIetKey,'.',TXN_KEY_LEN);
    caIetKey[TXN_KEY_LEN] = '\0';

    switch(caItemBuff[0]) {
      case  IET_BUSI_TYPE :  /* load business node */
        pstBusi = (struct busi_head_node *) caItemBuff;
        caIetKey[0] = pstBusi->cBusiType;
        pcKey  = (char *) (pcKeyIdx + (TXN_KEY_LEN + 1) * iReadItmCnt);
        pcBusi = (char *) (pcIetDat + sizeof(busi_head) * iReadItmCnt);
        memcpy(pcKey,caIetKey,TXN_KEY_LEN + 1);
        memcpy(pcBusi,pstBusi,sizeof(busi_head));
        iInAPageItmCnt = 0; /* reset the item count in a transaction in a page*/
        break;
      case  IET_TXN_TYPE :  /* load transaction node */
        pstTxn = (struct txn_head_node  *) caItemBuff;
        memcpy(caIetKey,pstTxn->caTxnCode,TXN_CODE_LEN);
        memset(caTxnCd,'\0',TXN_CODE_LEN+1);
        strncpy(caTxnCd,pstTxn->caTxnCode,TXN_CODE_LEN);
        pcKey = (char *) (pcKeyIdx + (TXN_KEY_LEN + 1) * iReadItmCnt);
        pcTxn = (char *) (pcIetDat + sizeof(txn_head) * iReadItmCnt);
        memcpy(pcKey,caIetKey,TXN_KEY_LEN+1);
        memcpy(pcTxn,pstTxn,sizeof(txn_head));
        iInAPageItmCnt = 0; /* reset the item count in a transaction on a page*/
        iOriPage = 1;       /* reset the frist page in a transaction */
        break;
      case   IET_ITEM_TYPE :  /* load item node */
        iInAPageItmCnt += 1; /* Counting input items in a txn on a page */
        pstItem = (struct txn_item_node  *) caItemBuff;

        if ((int) pstItem->cPage != iOriPage) {
          iInAPageItmCnt = 1; /* first input field 0n a page */
          iOriPage = pstItem->cPage;
        } /* if (pstItem->cPage != iOriPage) */
        sprintf(caIetKey,"%s%.2d%.3d",caTxnCd,(int) pstItem->cPage,
                                               iInAPageItmCnt);
        pcKey = (char *) (pcKeyIdx + (TXN_KEY_LEN + 1) * iReadItmCnt);
        pcItem = (char *) (pcIetDat + sizeof(txn_item) * iReadItmCnt);
        memcpy(pcKey,caIetKey,TXN_KEY_LEN+1);
        memcpy(pcItem,pstItem,sizeof(txn_item));
        break;
      default:
        sprintf(g_caMsg,"TxnBuild(): invalid rec_type->%c item cnt =%d\n",
                caItemBuff[0],iReadItmCnt);
        DetErrRpt(IET_TYPE_ERR,g_caMsg);
        UCP_TRACE_END(IET_TYPE_ERR);
    } /* for switch(caItemBuff[0]) */
    iReadItmCnt++;
  } /* while((iRc = read(iTxnFd,caItemBuff,sizeof(busi_head_node))) > 0) */

 /* -------------------- */
 /*    close txn file    */
 /* -------------------- */
  close(iTxnFd);

  sprintf(caShowBuf,"%s", TXN_LOADED);
  EmsShowData('0',caShowBuf);
  UCP_TRACE_END(0);
}

   /* ------------------------- */
   /*    check ctf file size    */
   /* ------------------------- */

int
ChkBinFlSize(iFlDp,pcFlName)
int iFlDp;
char *pcFlName;
{
  int iRc;
  struct stat stFlStatus;

  UCP_TRACE(P_ChkBinFlSize);

  iRc = fstat(iFlDp,&stFlStatus);
  if (iRc == -1) {
    sprintf(g_caMsg,"ChkFlSize() : Get %s size error,errno=%d",pcFlName,errno);
    DetErrRpt(FILE_SIZE_ERR,g_caMsg);
    UCP_TRACE_END(FILE_SIZE_ERR);
  }
  UCP_TRACE_END(stFlStatus.st_size);
} /* ChkBinFlSize(iFlDp,pcFlName) */

/* ---------------------------- */
/* compute business node number */
/* ---------------------------- */
int
CompBusiNum(iCtfFd)
int iCtfFd;
{
  int iRc;
  int iBusiCnt;
  char caCtfRecBuf[sizeof(ctf_head)];

  UCP_TRACE(P_CompBusiNum);

  iBusiCnt = 0;
  memset(caCtfRecBuf,'\0',sizeof(ctf_head));
  while ((iRc = read(iCtfFd,caCtfRecBuf,sizeof(ctf_head))) > 0) {
    if (iRc != sizeof(ctf_head)) {
      sprintf(g_caMsg,"BusiEstl() : read ctf_head =%d not completed",iRc);
      DetErrRpt(READ_FILE_ERR,g_caMsg);
      UCP_TRACE_END(READ_FILE_ERR);
    } /* if (iRc != sizeof(ctf_head))  */
    if (caCtfRecBuf[0] == M_CTF_HEAD ) {
       /* ------------------------ */
       /*  establish business node */
       /* ------------------------ */
       iBusiCnt++;
    }
  } /* while ((iRc = read(iCtfFd,caCtfRecBuf,sizeof(ctf_head)) > 0) */

/*
 printf("BUSINESS CNT NO= %d\n",iBusiCnt);
*/

 UCP_TRACE_END(iBusiCnt);
} /* CompBusiNum(iCtfFlDp) */




int CompCitSize(piBusiCnt)
int *piBusiCnt;
{
  int iCtfFd;
  int iRc;
  int iCitSize;
  ctf_head stCtfHd;
  char caFlName[FILE_NAME_LEN];

  UCP_TRACE(P_CompCitSize);
  memset(caFlName,'\0',FILE_NAME_LEN);
  strcpy(caFlName,(char *) getenv("III_DIR"));
  strcat(caFlName,(char *) "/");
  strcat(caFlName,CTF_FILE);

  iCtfFd = open(caFlName, O_RDONLY);
  if (iCtfFd < 0) {
     sprintf(g_caMsg,"CompCitSize() : Can't open %s,errno = %d",caFlName,errno);
     DetErrRpt(OPEN_FILE_ERR,g_caMsg);
     UCP_TRACE_END(OPEN_FILE_ERR);
  }  /* if (iCtfFd < 0) */

  iCitSize = 0;
  *piBusiCnt = 0;
  while ((iRc = read(iCtfFd,&stCtfHd,sizeof(ctf_head))) > 0) {
   if (iRc != sizeof(ctf_head)) {
     sprintf(g_caMsg,"CompCitSize() : read ctf_head =%d not completed",iRc);
     DetErrRpt(READ_FILE_ERR,g_caMsg);
     close(iCtfFd);
     UCP_TRACE_END(READ_FILE_ERR);
   } /* if (iRc != sizeof(ctf_head))  */

   if (stCtfHd.cRecHead == M_CTF_HEAD) {
     *piBusiCnt++;
     iCitSize += stCtfHd.iCtfSize;
   } /* if (stCtfhd->rec_head == M_CTF_HEAD) */
  } /* while ((iRc = read(iCtfFd,&stCtfHd,sizeof(ctf_head)) > 0) */
  close(iCtfFd);
  UCP_TRACE_END(iCitSize);
}
