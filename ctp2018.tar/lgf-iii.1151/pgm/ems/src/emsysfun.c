/*
 *&N& File : emsysfun.c
 *&N&
 * FUNCTION & SUBROUTINE DESCRIPTION
 *&N&    TYPE        NAME                    DESCRIPTION
 *&N& --------- ---------------- ----------------------------------------
 *&N& int        Dispatch        �� Control Process �ǨӪ��R�O���u�@����
 *&N& int        LoadMonCfg      Ū�J�ʷ��{�����Ұʵ{�������ɨ�O���^.
 *&N& int        LoadMonCrn      Ū�J�w�ɵ{�����Ұʵ{�������ɨ�O���^.
 *&N& int        ReadCrnLn       �ѩw�q�w�ɵ{�����ɮפ��@��Ū�J�@��
 *&N& int        ForkAll         �t�Ϊ�l�ɨ̾ڰO���^�����Ұʵ{�����ҰʩҦ��{��.
 *&N& int        ForkOne         �̾ڶǤJ���O���^�����Ұʵ{�������ޱҰʸӵ{��.
 *&N& int        ForkProc        �̾ڰO���^�����Ұʵ{�����Ұʵ{��.
 *&N& int        WaitCmd         ���ͱ���{���γQ�Ұʵ{�����R�O.
 *&N& int        RestarProc      ���s�Ұʦ������Q�Ұʵ{��.
 *&N& int        KillProc        �����Q�Ұʪ��{��.
 *&N& int        ShutOne         ���U�Q�Ұʪ��{��.
 *&N& int        ShutAll         ���U�Ҧ��Q�Ұʪ��{��.
 *&N& int        GetToken        ����ѼƦ�C���� Token
 *&N& int        SdCmdRvSta      �e�X�����T�������A���õ��ݶǦ^���A
 *&N& int        UnWork_incr     ���Y�@���A��Process���`��������椤�Хܸӱ��p
 *&N&                            �W�[�ӥ��u�@Process�����ޥH�K���ӭ��s�Ұʨϥ�
 *&N& int        UnWork_decr     ���Y�@���A��Process���s�Ұʦ��\��,�Хܸӥ��u�@
 *&N&                            Process�����ި���,�N���u�@�`�ƴ�@
 *&N& int        Init_Tbl        �N���A�������l��
 *&N& int        Mtn_FokTbl      ���@ Fork Process ���椤���@�Ǫ��A(Process,
 *&N&                            Monitor, & Errno )
 *&N& int        SysShutdown     �t�������B�z(��Normal Shutdown,Quick Shutdown
 *&N&                            & DoBatch �T�ر��p)
 *&N& int        EnvRelse        �t�ε����e����Ҧ��귽
 *&N& void       ABEND_RTN       �t�β��`�����e����Ҧ��귽
 *&N& int        RmComponent     �����Ҧ� Fork �_�Ӫ�����
 *&N& void       Daemon_Start    �N�{���אּ Daemon Process ���D�禡
*/

/* ---------------------- INCLUDE FILE DECLARATION --------------------------*/
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/signal.h>
#include <fcntl.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>
#include <sys/shm.h>
#include <sys/param.h>
#include <sys/stat.h>

#include "errlog.h"
#include "dcs.h"
#include "cwa.h"
#include "emcstart.h"
#include "emcserve.h"
#include "emcpgdef.h"

#define  SERVER_FILE        "iii/etc/tbl/server.dat"
#define  CHRON_FILE         "iii/etc/tbl/chron.dat"
#define  PROTOCOL_TYPE      "III_PROTOCOL"
#define  QUEUE_DCS          'Q'
#define  MONITOR_HOST       "00Monitor1"
#define  GET_FORK_STATUS    "00Monitor2"
#define  DEST_NAME_LEN      10
#define  DATE_LEN           10
#define  MON_ERR_PASS       99
#define  ONLINE_CLOSE       0x0400  /* 1:Batch  0:On_line */
#define  EMS_SHUTDOWN_OK    1
#define  EMS_DOBATCH_OK     2
#define  EMS_DOONLINE_OK    2

#define  REMOVE_SHM_ERR     -1
#define  SEND_CMD_ERR       -3
#define  STOP_SERV_ERR      -4
#define  REMOVE_COMPO_ERR   -7

/* ========== External Global Variables Declaration ========== */
extern int  g_iCwaKey;
extern int  g_iCtfKey;
extern int  g_iIctKey;
extern int  g_iDbtKey;
extern int  g_iIetKey;
extern int  g_iChronPid;
extern int  g_iNoBatch;
extern char g_caRlPgName[10][20];
extern int  errno;
extern char *sys_errlist[];

/* ========== Global Variables Declaration ========== */
char            *getenv();
int             g_iSessIdx;
int             g_iMaxLoadCrn=0;
int             gs_iMaxLoadCfg;
int             gs_iMaxFork;

struct MonCmd   stMonCmd;
struct FkdStat  stFkdStat;
struct DcsBuf   stDcsBuf;
struct DcsSiof  stDcsSiof;

/* ========== Function Prototype Declaration ========== */
int     LoadMonCfg();
int     LoadMonCrn();
int     ForkProc(int iTblidx,int iFokidx);
int     WaitCmd(struct MonCmd *stMonCmd);
int     RestarProc(int iCfgidx,int Fokidx);
int     KillProc(int iTblidx);
int     ShutOne(int iTblidx);
int     ShutAll();
int     SdCmdRvSta (char cProtocolType, char *paDesCode,
                    struct MonCmd *pstMonCmd, struct FkdStat *pstFkdStat);
/* ===================================================== */
#define  SEM_NUM             6
#define  MAX_NETWKTBL_ARRAY  30
#define  QUEUE_TABLE         "iii/etc/dcd/queuetbl"
struct QuNetwk {
  char ucDesCode[10];
  char caField[2][20];
};
struct QuNetwk g_stQuTbl[MAX_NETWKTBL_ARRAY];
int g_iMaxQuLine=0;

extern int g_iMdaFlag;
extern struct MDA      *pstMda;

int
IsuSvPrs(iStatus)
int  iStatus;
{
  int  iRc;

  UCP_TRACE(P_IsuSvPrs);

  /* initial table array */
  Init_Tbl();

  /* 0409 */
  iRc = LoadQuTbl ();
  if (iRc != MON_NORMAL) {
    UCP_TRACE_END(iRc);
  }

  /* Load server table defined in server.dat */
  iRc = LoadMonCfg();
  if(iRc != MON_NORMAL){
    UCP_TRACE_END(iRc);
  }

  /* Load chron table defined in chron.dat */
  iRc = LoadMonCrn();
  if(iRc != MON_NORMAL){
    UCP_TRACE_END(iRc);
  }

  /* Fork server and chron */
  if (iStatus == 0) {  /* ONLINE status */
    iRc = ForkAll();
      if(iRc != 0){
        UCP_TRACE_END(FORK_SERVER_ERR);
      }
  }

  UCP_TRACE_END(0);
}

int
Dispatch(stMonCmd)
struct MonCmd *stMonCmd;
{
  int  iRc,iRc1;
  int  iCfgidx,iFokidx;
  struct FkdStat stRtnStat; /* monitor rtn status to cntl process */

  UCP_TRACE(P_Dispatch);

  if((stMonCmd->cCmd!=TPE_SHUTDOWN) || (stMonCmd->cCmd!=TPE_QUCKSHUT)){
    if( (stMonCmd->cCmd == MON_FORK) || (stMonCmd->cCmd == MON_SHUTDOWN) ){
      iCfgidx = atoi(stMonCmd->caTblidx);
    }
    else{
      iFokidx = atoi(stMonCmd->caTblidx);
    }
    /* TCC: 1996/08/26
    sprintf(g_caMsg,"<EMS> Dispatch: iCfgidx=%d",iCfgidx);
    ErrLog(50,g_caMsg,RPT_TO_LOG,0,0);
    */
  }

  switch (stMonCmd->cCmd){
    case MON_FORK :
      iRc = ForkOne(iCfgidx);
      /* send an ack to control process to notify fork status  */
      stRtnStat.cStatus = (char) iRc;
      strncpy(stRtnStat.caTblidx,stMonCmd->caTblidx,5); ;

      iRc=EmsDataSend(sizeof(struct FkdStat),&stRtnStat,'0',g_iSessIdx);
      if ( iRc != 0 ) {
        ErrLog (1000,"<EMS> EMS is unable to send MON_FORK ack to emxcntl.x!",
                RPT_TO_LOG, 0, 0);
        UCP_TRACE_END ( SENDACK_TO_CALLER_ERR );
      }
      break;

    case MON_KILL :
      ErrLog (1000, "<EMS> EMS receives control request to kill TPU!",
              RPT_TO_LOG, 0, 0);

      iRc = KillProc(iFokidx);

      stRtnStat.cStatus = (char) iRc;
      strncpy(stRtnStat.caTblidx,stMonCmd->caTblidx,5); ;

      iRc = EmsDataSend(sizeof(struct FkdStat),&stRtnStat,'0',g_iSessIdx);
      if ( iRc != 0 ) {
         ErrLog (1000,"<EMS> EMS is unable to send MON_KILL ack to emxcntl.x!",
                 RPT_TO_LOG, 0, 0);
         UCP_TRACE_END ( SENDACK_TO_CALLER_ERR );
       }
       break;

    case MON_SHUTDOWN :
      ErrLog (1000, "<EMS> EMS receives control request to shut TPU!",
              RPT_TO_LOG, 0, 0);
      if(iCfgidx == ALL_IDX){
        iRc = ShutAll();
      }
      else{
        iRc = ShutOne(iCfgidx);
      }

      stRtnStat.cStatus = (char) iRc;
      strncpy(stRtnStat.caTblidx,stMonCmd->caTblidx,5); ;

      iRc1=EmsDataSend(sizeof(struct FkdStat),&stRtnStat,'0',g_iSessIdx);
      if ( iRc1 != 0 ) {
         ErrLog (1000,
                 "<EMS> EMS is unable to send MON_SHUTDOWN ack to emxcntl.x!",
                 RPT_TO_LOG, 0, 0);
         UCP_TRACE_END ( SENDACK_TO_CALLER_ERR );
      }

      /* there is a server but can't shutdown it */
      if ( iRc != 0 && iRc != 23) 
      { 
        iRc = EnvRelse();
        if ( iRc != 0 ) {
          ErrLog (1000,"<EMS> Failure to release TPE resources (chron/shm)!",
                  RPT_TO_LOG,0,0);
        }

        iRc = RmComponent();
        if (iRc != 0) {
          ErrLog (1000,"<EMS> Failure to remove TPE components!",
                  RPT_TO_LOG, 0, 0);
        }
        UCP_TRACE_END ( SENDACK_TO_CALLER_ERR );
      }
      break;

    case MON_RESTART :
      iCfgidx = MFok(iFokidx).iTblidx;
      iRc = RestarProc(iCfgidx,iFokidx); 
      if(iRc != MON_NORMAL){
        UnWork_incr(iCfgidx,iFokidx);
      }
      stRtnStat.cStatus = (char) iRc;
      strncpy(stRtnStat.caTblidx,stMonCmd->caTblidx,5); ;
      iRc=EmsDataSend(sizeof(struct FkdStat),&stRtnStat,'0',g_iSessIdx);
      if ( iRc != 0 ) {
        ErrLog (1000,
                "<EMS> ems.x is unable to send MON_RESTART ack to emxcntl.x!",
                RPT_TO_LOG, 0, 0);
        UCP_TRACE_END ( SENDACK_TO_CALLER_ERR );
      }
      break;

    case TPE_SHUTDOWN :
    case TPE_QUCKSHUT :
    case TPE_DOBATCH  :
    case TPE_DOONLINE  :
      if (stMonCmd->cCmd == TPE_SHUTDOWN)
         ErrLog (1000, "<EMS> ems.x receives TPE_SHUTDOWN command!",
                 RPT_TO_LOG, 0, 0);
      else
      if (stMonCmd->cCmd == TPE_QUCKSHUT)
         ErrLog (1000, "<EMS> ems.x receives TPE_QUCKSHUT command!",
                 RPT_TO_LOG, 0, 0);
      else
      if (stMonCmd->cCmd == TPE_DOBATCH)
         ErrLog (1000, "<EMS> ems.x receives TPE_DOBATCH command!",
                 RPT_TO_LOG, 0, 0);
      else
      if (stMonCmd->cCmd == TPE_DOONLINE)
         ErrLog (1000, "<EMS> ems.x receives TPE_DOONLINE command!",
                 RPT_TO_LOG, 0, 0);

      iRc = SysShutdown(stMonCmd->cCmd);
      if (iRc != 0) {   
        if (iRc == SAVE_CWA_ERR)
           stRtnStat.cStatus = MON_SAVE_CWA_ERR;
        else
           stRtnStat.cStatus = MON_SHUTDOWN_ERR;
      }
      else  {
        stRtnStat.cStatus = (char) iRc;
      }

      strncpy(stRtnStat.caTblidx,stMonCmd->caTblidx,5); ;

      iRc = EmsDataSend (sizeof(struct FkdStat), &stRtnStat, '0', g_iSessIdx);
      if ( iRc != 0 ) {
        ErrLog (1000, "<EMS> EMS is unable to send control ack to emxcntl.x!",
                RPT_TO_LOG, 0, 0);
        /* TCC: 19960925
        UCP_TRACE_END ( SENDACK_TO_CALLER_ERR );
        */
      }
        
      if (stMonCmd->cCmd == TPE_DOBATCH) {
        UCP_TRACE_END(EMS_DOBATCH_OK);
      }
      else  
      if (stMonCmd->cCmd == TPE_DOONLINE) {
        UCP_TRACE_END(EMS_DOONLINE_OK);
      }
      else  
      {
        if (stRtnStat.cStatus == MON_SAVE_CWA_ERR)
        {
           UCP_TRACE_END(MON_SAVE_CWA_ERR);
        }
           
        iRc = EnvRelse();
        if ( iRc != 0 ) {
          ErrLog (1000,"<EMS> Failure to release resources (chron/shm)!",
                  RPT_TO_LOG,0,0);
        }
/*          
        sleep (2);
*/          
        iRc = RmComponent();
        if (iRc != 0) {
          ErrLog (40000,
                  "<EMS> Failure to remove TPE components!" ,
                  RPT_TO_LOG, 0, 0);
          UCP_TRACE_END( REMOVE_COMPO_ERR );
        }

        UCP_TRACE_END(EMS_SHUTDOWN_OK);
      }
      break;

    case TPE_DUMPCWA  :    /* Fork Execl */
      stRtnStat.cStatus = 0;
      strncpy(stRtnStat.caTblidx,"00000",5); ;

      iRc=EmsDataSend(sizeof(struct FkdStat),&stRtnStat,'0',g_iSessIdx);
      if ( iRc != 0 ) {
        ErrLog (1000,
                "<EMS> ems.x fails to send TPE_DUMPCWA ack to emxcntl.x!",
                RPT_TO_LOG, 0, 0);
        UCP_TRACE_END ( SENDACK_TO_CALLER_ERR );
      }

      /* Begin to interact with the Tools program  */
      DumpCwa();
      break;

    case TPE_DUMPBIT  :    /* Fork Execl */
      stRtnStat.cStatus = 0;
      strncpy(stRtnStat.caTblidx,"00000",5); ;

      iRc=EmsDataSend(sizeof(struct FkdStat),&stRtnStat,'0',g_iSessIdx);
      if ( iRc != 0 ) {
        ErrLog (1000,
                "<EMS> ems.x fails to send TPE_DUMPBIT ack to emxcntl.x!",
                RPT_TO_LOG, 0, 0);
        UCP_TRACE_END ( SENDACK_TO_CALLER_ERR );
      }
      /* Begin to interact with the Tools program  */
      DumpCwa();
      break;

    case MON_STOP :
      ABEND_RTN();
      exit (-1);

    default :
      Mtn_FokTbl (MAX_FORK_PROC, PRC_UNFORK, MON_CMD_ERR, 0);
      break;
  }
  UCP_TRACE_END(0);
}


/*
 *&N& ROUTINE NAME: LoadMonCfg
 *&A& ARGUMENTS:
 *&A&    struct FokTbl *stTbl
 *&R& RETURN VALUE(S):
 *&R&    int
 *&D& DESCRIPTION:
 *&D*
 */
int LoadMonCfg()
{
  FILE *Fp;
  int  i, j, k, iRc, iTotForkProc;
  char caFileName[128];
  char caBuf[128], *pcaToken;

  UCP_TRACE(P_LoadMonCfg);

  sprintf (caFileName, "%s/%s", 
           (char *)getenv("III_DIR"), SERVER_FILE);

  if ((Fp = fopen(caFileName,"r")) == NULL){
    sprintf (g_caMsg,"<EMS> Failure to open %s! (errno:%d=>%s)",
             caFileName, errno, sys_errlist[errno]);
    ErrLog (1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END (OPEN_SERVER_FILE_ERR);
  } 

  memset (caBuf, 0, sizeof(caBuf));
  fgets (caBuf, sizeof (caBuf), Fp);

  i = 1;
  j = iTotForkProc = 0;
  do
  {
     for (k=0; k<sizeof(caBuf); k++)
     if (caBuf[k] == '\n')
     {
       caBuf[k] = 0;
       break;
     }

     pcaToken = (char *)strtok (caBuf, " \t\n");
     if (pcaToken != NULL && pcaToken[0] != '#')
     {
        errno = 0;
        iRc = StrToInt (pcaToken, &MCfg(j).iFkLimitPerTime);
        if ((iRc < 0) || (MCfg(j).iFkLimitPerTime < 0) ||
            (MCfg(j).iFkLimitPerTime > MAX_FORK_PERTIME))
        {
          sprintf (g_caMsg,
"<EMS> Parameter 1 (%s) of line (%d) in server.dat is less than 0 or larger than %d.",
          pcaToken, i, MAX_FORK_PERTIME);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          fclose (Fp);
          UCP_TRACE_END (SERV_PARA_ERR);
        }

        pcaToken = (char *)strtok (NULL, " \t\n");
        if (pcaToken == NULL)
        {
          sprintf (g_caMsg,
         "<EMS> Illegal parameter 2 (%s) of line (%d) in server.dat.(errno:%d)",
          pcaToken, i, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          fclose (Fp);
          UCP_TRACE_END (SERV_PARA_ERR);
        }
        else
        {
          iRc = StrToInt (pcaToken, &MCfg(j).iRestartno);
          if (iRc < 0 || MCfg(j).iRestartno < 0)
          {
            sprintf (g_caMsg,
            "<EMS> Parameter 2 (%s) of line (%d) in server.dat is less than 0.",
            pcaToken, i);
            ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
            fclose (Fp);
            UCP_TRACE_END (SERV_PARA_ERR);
          }
        }

        pcaToken = (char *)strtok (NULL, " \t\n");
        if (pcaToken == NULL)
        {
          sprintf (g_caMsg,
         "<EMS> Illegal parameter 3 (%s) of line (%d) in server.dat.(errno:%d)",
          pcaToken, i, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          fclose (Fp);
          UCP_TRACE_END (SERV_PARA_ERR);
        }
        else
        {
          iRc = StrToInt (pcaToken, &MCfg(j).iFstFokNo);
          if ((iRc < 0) || (MCfg(j).iFstFokNo < 0) || 
              (MCfg(j).iFstFokNo > MAX_FORK_PERTIME) ||
              (MCfg(j).iFstFokNo > MCfg(j).iFkLimitPerTime))
          {
            sprintf (g_caMsg,
           "<EMS> Illegal parameter 3 (%s) of line (%d) in server.dat.(0 ~ %d)",
            pcaToken, i, MAX_FORK_PERTIME);
            ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
            fclose (Fp);
            UCP_TRACE_END (SERV_PARA_ERR);
          }
        }

        pcaToken = (char *)strtok (NULL, " \t\n");
        if (pcaToken == NULL)
        {
          sprintf (g_caMsg,
         "<EMS> Illegal parameter 4 (%s) of line (%d) in server.dat.(errno:%d)",
          pcaToken, i, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          fclose (Fp);
          UCP_TRACE_END (SERV_PARA_ERR);
        }
        else
        {
          if (pcaToken[0] != 'Q')
          {
            sprintf (g_caMsg,
            "<EMS> Unknown protocol(%s) of line(%d) in server.dat",
            pcaToken, i);
            ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
            fclose (Fp);
            UCP_TRACE_END (SERV_PARA_ERR);
          }
          MCfg(j).cProtocolType = pcaToken[0];
        }

        pcaToken = (char *)strtok (NULL, " \t\n");
        if (pcaToken == NULL)
        {
          sprintf (g_caMsg,
         "<EMS> Illegal parameter 5 (%s) of line (%d) in server.dat.(errno:%d)",
          pcaToken, i, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          fclose (Fp);
          UCP_TRACE_END (SERV_PARA_ERR);
        }
        else
        {
          iRc = CheckQuDest(pcaToken);
          if (iRc == -1)
          {
            sprintf (g_caMsg,
"<EMS> Destination code(%s) of line(%d) in server.dat is undefined in queuetbl",
            pcaToken, i);
            ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
            fclose (Fp);
            UCP_TRACE_END (SERV_PARA_ERR);
          }
          if (iRc == -2)
          {
            sprintf (g_caMsg,
"<EMS> Destination code(%s) of line(%d) in server.dat is duplicated",
            pcaToken, i);
            ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
            fclose (Fp);
            UCP_TRACE_END (SERV_PARA_ERR);
          }
          memcpy (MCfg(j).caDesCode, pcaToken, 10);
        }

        pcaToken = (char *)strtok (NULL, " \t\n");
        if (pcaToken == NULL)
        {
          sprintf (g_caMsg,
         "<EMS> Illegal parameter 6 (%s) of line (%d) in server.dat.(errno:%d)",
          pcaToken, i, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          fclose (Fp);
          UCP_TRACE_END (SERV_PARA_ERR);
        }
        else
        {
          if (sizeof(MCfg(j).caPrgname) < strlen(pcaToken))
          {
            sprintf (g_caMsg,
"<EMS> Program name (%s) of line (%d) in server.dat exceeds the limit (%d)",
            pcaToken, i, sizeof(MCfg(j).caPrgname));
            ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
            fclose (Fp);
            UCP_TRACE_END (SERV_PARA_ERR);
          }

          iRc = CheckSrvName (pcaToken);
          if (iRc == -1)
          {
            sprintf (g_caMsg,
            "<EMS> Server name(%s) of line(%d) in server.dat is duplicated!",
            pcaToken, i);
            ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
            fclose (Fp);
            UCP_TRACE_END (SERV_PARA_ERR);
          }      
          if (iRc == -2)
          {
            sprintf (g_caMsg,
            "<EMS> Server name(%s) of line(%d) in server.dat is corrupted!",
            pcaToken, i);
            ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
            fclose (Fp);
            UCP_TRACE_END (SERV_PARA_ERR);
          }      
          memcpy (MCfg(j).caPrgname, pcaToken, strlen(pcaToken));
        }

        memset (MCfg(j).caPara, 0, sizeof(MCfg(j).caPara));
        pcaToken = (char *)strtok (NULL, " \t\n");
        while (pcaToken != NULL)
        {
          if ((sizeof(MCfg(j).caPara) - strlen(MCfg(j).caPara) - 1)
              < strlen(pcaToken))
          {
            sprintf (g_caMsg,
            "<EMS> Illegal parameter(%s) of line(%d) in server.dat.(errno:%d)",
            pcaToken, i, errno);
            ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
            fclose (Fp);
            UCP_TRACE_END (SERV_PARA_ERR);
          }
          
          strcat (MCfg(j).caPara, " ");
          strcat (MCfg(j).caPara, pcaToken);
          
          pcaToken = (char *)strtok (NULL, " \t\n");
        }
        iTotForkProc += MCfg(j).iFstFokNo;
        if (iTotForkProc > MAX_FORK_PROC)
        {
          sprintf (g_caMsg,
"<EMS> The total number of servers(%d) defined in server.dat exceed limit %d!",
          iTotForkProc, MAX_FORK_PROC);
          ErrLog (1000,g_caMsg,RPT_TO_LOG,0,0);
          UCP_TRACE_END (SERV_PROC_OVERFLOW_ERR);
        }
        j++;
     }

     if (j >= MAX_TABLE_ARRAY)
     {
       sprintf (g_caMsg,
       "<EMS> The number of total lines defined in [%s] exceed limit %d!",
       caFileName, MAX_TABLE_ARRAY);
       ErrLog (40000,g_caMsg,RPT_TO_LOG,0,0);
       UCP_TRACE_END (SERV_ENTRY_OVERFLOW_ERR);
     }

     i++;
     gs_iMaxLoadCfg = j;
     fgets (caBuf, sizeof (caBuf), Fp);
  }  while (!feof(Fp));

  gs_iMaxLoadCfg = j;

  UCP_TRACE_END (MON_NORMAL);
}

/*
 *&N& ROUTINE NAME: LoadMonCrn
 *&A& ARGUMENTS:
 *&A&    struct FokTbl *stTbl
 *&R& RETURN VALUE(S):
 *&R&    int
 *&D& DESCRIPTION:
 *&D*
 */
int LoadMonCrn()
{
  int i, j, iRc;
  int iTotal;
  int iRtnCode;
  char caFilename[128];
  char *pcaToken, caBuf[128], caTokenBuf[128];
  FILE *zChronFp;

  UCP_TRACE(P_LoadMonCrn);

  sprintf (caFilename, "%s/%s", 
           (char *) getenv("III_DIR"), CHRON_FILE);

  if((zChronFp=fopen(caFilename,"r")) == NULL){
    sprintf(g_caMsg,"<EMS> Failure to open chron.dat! (errno:%d)",errno);
    ErrLog(4000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(OPEN_CHRON_FILE_ERR);
  }

  iTotal=i=0;
  memset (caBuf, 0, sizeof(caBuf));
  fgets (caBuf, sizeof(caBuf), zChronFp);

  do
  {
    if ((i >= MAX_TABLE_ARRAY) || (iTotal >= MAX_FORK_PROC))
    {
      sprintf (g_caMsg,"<EMS> Too many entries in chron.dat!(limit:%d)",
               MAX_TABLE_ARRAY);
      ErrLog (4000,g_caMsg,RPT_TO_LOG,0,0);
      fclose (zChronFp);
      UCP_TRACE_END (CHRON_PROC_OVERFLOW_ERR);
    }

    for (j=0; j<sizeof(caBuf); j++)
      if (caBuf[j] == '\n')
      {
        caBuf[j] = 0;
        break;
      }
    /*
    sprintf (g_caMsg, "TCC: chron entry: %s", caBuf);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    */
    strcpy (caTokenBuf, caBuf);

    pcaToken = (char *)strtok (caTokenBuf, " \t\n");

    if (pcaToken != NULL && pcaToken[0] != '#')
    {
      errno = 0;
      iRc = StrToInt (pcaToken, &MCrn(i).iFkLimitPerTime);
      if (iRc < 0 || errno != 0 || pcaToken == NULL)
      {
        sprintf (g_caMsg,
                 "<EMS> Illegal parameter [%s] in chron.dat.(errno:%d)",
                 pcaToken, errno);
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        fclose (zChronFp);
        UCP_TRACE_END (CHRON_PARA_ERR);
      }

      pcaToken = (char *)strtok (NULL, " \t\n");
      iRc = StrToInt (pcaToken, &MCrn(i).iRestartno);
      if (iRc < 0 || errno != 0 || pcaToken == NULL)
      {
        sprintf (g_caMsg,
                 "<EMS> Illegal parameter [%s] in chron.dat.(errno:%d)",
                 pcaToken, errno);
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        fclose (zChronFp);
        UCP_TRACE_END (CHRON_PARA_ERR);
      }

      pcaToken = (char *)strtok (NULL, " \t\n");
      iRc = StrToInt (pcaToken, &MCrn(i).iFstFokNo);
      if (iRc < 0 || errno != 0 || pcaToken == NULL)
      {
        sprintf (g_caMsg,
                 "<EMS> Illegal parameter [%s] in chron.dat.(errno:%d)",
                 pcaToken, errno);
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        fclose (zChronFp);
        UCP_TRACE_END (CHRON_PARA_ERR);
      }

      pcaToken = (char *)strtok (NULL, " \t\n");
      iRc = StrToInt (pcaToken, &MCrn(i).iChronType);
      if (iRc < 0 || errno != 0 || pcaToken == NULL)
      {
        sprintf (g_caMsg,
                 "<EMS> Illegal parameter [%s] in chron.dat.(errno:%d)",
                 pcaToken, errno);
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        fclose (zChronFp);
        UCP_TRACE_END (CHRON_PARA_ERR);
      }

      pcaToken = (char *)strtok (NULL, " \t\n");
      if (pcaToken == NULL)
      {
        sprintf (g_caMsg,
                 "<EMS> Illegal parameter [%s] in chron.dat.(errno:%d)",
                 pcaToken, errno);
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        fclose (zChronFp);
        UCP_TRACE_END (CHRON_PARA_ERR);
      }
      else
      if (sizeof(MCrn(i).caMonth) < strlen(pcaToken))
      {
        sprintf (g_caMsg,
                 "<EMS> Illegal parameter [%s] in chron.dat.(errno:%d)",
                 pcaToken, errno);
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        fclose (zChronFp);
        UCP_TRACE_END (CHRON_PARA_ERR);
      }
      memcpy (MCrn(i).caMonth, pcaToken, strlen(pcaToken));

      pcaToken = (char *)strtok (NULL, " \t\n");
      if (pcaToken == NULL)
      {
        sprintf (g_caMsg,
                 "<EMS> Illegal parameter [%s] in chron.dat.(errno:%d)",
                 pcaToken, errno);
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        fclose (zChronFp);
        UCP_TRACE_END (CHRON_PARA_ERR);
      }
      else
      if (sizeof(MCrn(i).caWeek) < strlen(pcaToken))
      {
        sprintf (g_caMsg,
                 "<EMS> Illegal parameter [%s] in chron.dat.(errno:%d)",
                 pcaToken, errno);
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        fclose (zChronFp);
        UCP_TRACE_END (CHRON_PARA_ERR);
      }
      memcpy (MCrn(i).caWeek, pcaToken, strlen(pcaToken));

      pcaToken = (char *)strtok (NULL, " \t\n");
      if (pcaToken == NULL)
      {
        sprintf (g_caMsg,
                 "<EMS> Illegal parameter [%s] in chron.dat.(errno:%d)",
                 pcaToken, errno);
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        fclose (zChronFp);
        UCP_TRACE_END (CHRON_PARA_ERR);
      }
      else
      if (sizeof(MCrn(i).caDay) < strlen(pcaToken))
      {
        sprintf (g_caMsg,
                 "<EMS> Illegal parameter [%s] in chron.dat.(errno:%d)",
                 pcaToken, errno);
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        fclose (zChronFp);
        UCP_TRACE_END (CHRON_PARA_ERR);
      }
      memcpy (MCrn(i).caDay, pcaToken, strlen(pcaToken));

      pcaToken = (char *)strtok (NULL, " \t\n");
      if (pcaToken == NULL)
      {
        sprintf (g_caMsg,
                 "<EMS> Illegal parameter [%s] in chron.dat.(errno:%d)",
                 pcaToken, errno);
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        fclose (zChronFp);
        UCP_TRACE_END (CHRON_PARA_ERR);
      }
      else
      if (sizeof(MCrn(i).caTime) < strlen(pcaToken))
      {
        sprintf (g_caMsg,
                 "<EMS> Illegal parameter [%s] in chron.dat.(errno:%d)",
                 pcaToken, errno);
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        fclose (zChronFp);
        UCP_TRACE_END (CHRON_PARA_ERR);
      }
      memcpy (MCrn(i).caTime, pcaToken, strlen(pcaToken));

      pcaToken = (char *)strtok (NULL, " \t\n");
      iRc = StrToInt (pcaToken, &MCrn(i).iPeriod);
      if (iRc < 0 || errno != 0 || pcaToken == NULL)
      {
        sprintf (g_caMsg,
                 "<EMS> Illegal parameter [%s] in chron.dat.(errno:%d)",
                 pcaToken, errno);
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        fclose (zChronFp);
        UCP_TRACE_END (CHRON_PARA_ERR);
      }

      pcaToken = (char *)strtok (NULL, " \t\n");
      if (pcaToken == NULL)
      {
        sprintf (g_caMsg,
                 "<EMS> Illegal parameter [%s] in chron.dat.(errno:%d)",
                 pcaToken, errno);
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        fclose (zChronFp);
        UCP_TRACE_END (CHRON_PARA_ERR);
      }
      else
      if (sizeof(MCrn(i).caPrgname) < strlen(pcaToken))
      {
        sprintf (g_caMsg,
                 "<EMS> Illegal parameter [%s] in chron.dat.(errno:%d)",
                 pcaToken, errno);
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        fclose (zChronFp);
        UCP_TRACE_END (CHRON_PARA_ERR);
      }
      memcpy (MCrn(i).caPrgname, pcaToken, strlen(pcaToken));

      pcaToken = (char *)strtok (NULL, "");
      if (pcaToken != NULL) {
         if (sizeof(MCrn(i).caPara) < strlen(pcaToken))
         {
           sprintf (g_caMsg, 
                    "<EMS> Illegal parameter [%s] in chron.dat.(errno:%d)",
                    pcaToken, errno);
           ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
           fclose (zChronFp);
           UCP_TRACE_END (CHRON_PARA_ERR);
         }
         memcpy (MCrn(i).caPara, pcaToken, strlen(pcaToken));
      }

      iTotal=iTotal + MCrn(i).iFstFokNo;
      i++;

    }  /* if (pcaToken[0] == '#' */

    fgets (caBuf, sizeof(caBuf), zChronFp);

  } while (!feof(zChronFp));

  g_iMaxLoadCrn = i;
  /*
  sprintf (g_caMsg,"<EMS> Total entries in chron.dat : %d(%d)",
           iTotal, g_iMaxLoadCrn);
  ErrLog (10,g_caMsg,RPT_TO_LOG,0,0);
  */
  fclose (zChronFp);

  UCP_TRACE_END(MON_NORMAL);
}


/*
 *&N& ROUTINE NAME: ForkAll
 *&A& ARGUMENTS:
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    int
 *&D& DESCRIPTION:
 *&D*
 */
int ForkAll()
{
  int  i, iCfgIdx,iFokIdx;
  int  iMaxFork;        /* realy fork max process */
  int  iUnWorkno;
  int  iRc;

  UCP_TRACE(P_ForkAll);
  
  iCfgIdx=0; iFokIdx=0;
  while (iCfgIdx < gs_iMaxLoadCfg)
  {
    i=0;

    while (i < MCfg(iCfgIdx).iFstFokNo)
    {
      if (iFokIdx >= MAX_FORK_PROC)
      {
        sprintf (g_caMsg,
                "<EMS> Total number of processes exceed limit (%d)",
                MAX_FORK_PROC);
        ErrLog(4000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END(MON_PROC_OVERFLOW);
      }

      iRc = ForkProc(iCfgIdx, iFokIdx);
      if( iRc != MON_NORMAL)
      {
        sprintf(g_caMsg,
        "<EMS> Failure to fork the [%d] server of line [%d] in server.dat!",
        iFokIdx, iCfgIdx);
        ErrLog(4000,g_caMsg,RPT_TO_LOG,0,0);
        UnWork_incr(iCfgIdx, iFokIdx);
        UCP_TRACE_END(iRc);
      }
      else
      {
        /*
        sprintf(g_caMsg,"ForkAll:fork %d,%d ok", iCfgIdx, iFokIdx);
        ErrLog(40,g_caMsg,RPT_TO_LOG,0,0);
        */
      }

      MCfg(iCfgIdx).iForkprc++;
      i++; iFokIdx++;
      gs_iMaxFork = iFokIdx-1;

    }/* FOR whiel(j) loop */

    iCfgIdx++;
    gs_iMaxFork = iFokIdx-1;

  }/* FOR while(i) loop */

  UCP_TRACE_END(0);
}

/*
 *&N& ROUTINE NAME: ForkOne
 *&A& ARGUMENTS:
 *&A&    int iCfgIdx
 *&R& RETURN VALUE(S):
 *&R&    int
 *&D& DESCRIPTION:
 *&D*
 */
int ForkOne(int iCfgIdx)
{
  int  iRc;
  int  iMaxFork;        /* realy fork max process */
  int  iUnWorkno;
  int  iFokIdx;

  UCP_TRACE(P_ForkOne);
 
  /* fork process loop */
  if(MCfg(iCfgIdx).iUnWorkno > 0){
    iUnWorkno=MCfg(iCfgIdx).iUnWorkno;
    iFokIdx=MCfg(iCfgIdx).piaUnWkidx[iUnWorkno-1];
    if((iRc=RestarProc(iCfgIdx,iFokIdx)) == MON_NORMAL){
      UnWork_decr(iCfgIdx,iFokIdx);
    }
    UCP_TRACE_END(iRc);
  }

  if (++gs_iMaxFork > MAX_FORK_PROC){
    sprintf (g_caMsg,
             "<EMS> Number of TPU has exceeded maximum %d! No Fork.", 
             MAX_FORK_PROC);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    gs_iMaxFork--;
    iFokIdx = gs_iMaxFork;
    Mtn_FokTbl (MAX_FORK_PROC, PRC_UNFORK, MON_PROC_OVERFLOW, 0);
    UCP_TRACE_END (MON_PROC_OVERFLOW);
  }

  if (MCfg(iCfgIdx).iForkprc++ >= MCfg(iCfgIdx).iFkLimitPerTime){
    sprintf (g_caMsg,
         "<EMS> Number of TPU has exceeded limit %d defined in server.dat!",
         MCfg(iCfgIdx).iFkLimitPerTime);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    gs_iMaxFork--;
    iFokIdx = gs_iMaxFork;
    Mtn_FokTbl (MAX_FORK_PROC, PRC_UNFORK, MON_PROC_OVERLIMIT, 0);
    UCP_TRACE_END (MON_PROC_OVERLIMIT);
  }

  iFokIdx=gs_iMaxFork;

  if( (iRc = ForkProc(iCfgIdx,iFokIdx) ) != MON_NORMAL){
    UnWork_incr(iCfgIdx,iFokIdx);
  }
  UCP_TRACE_END(iRc);
}

/*
 *&N& ROUTINE NAME: ForkProc
 *&A& ARGUMENTS:
 *&A&    int iCfgIdx
 *&A&    int iFokIdx
 *&R& RETURN VALUE(S):
 *&R&    int
 *&D& DESCRIPTION:
 *&D*
 */
int ForkProc(int iCfgIdx, int iFokIdx)
{
  int  i, iRc, iChiPid;
  char caIdx[10];
  char *pcaArgv [MAX_PARAS], caExePath [MAX_EXEC_PATH_LEN];
  char caForkBuf [MAX_PARA_LEN];

  UCP_TRACE(P_ForkProc);
  
  MFok(iFokIdx).iTblidx=iCfgIdx;

  memset (caExePath, 0, sizeof(caExePath));
  sprintf (caExePath, "%s/iii/bin/exe/%s",
           (char *)getenv("III_DIR"), MCfg(iCfgIdx).caPrgname);

  pcaArgv[0] = MCfg(iCfgIdx).caPrgname;
  itoa1 (iFokIdx, caIdx, 3);
  pcaArgv[1] = caIdx;
  pcaArgv[2] = MCfg(iCfgIdx).caDesCode;
  memcpy (caForkBuf, MCfg(iCfgIdx).caPara, MAX_PARA_LEN);
  if (GetToken(caForkBuf,pcaArgv) != 0)
  {
    Mtn_FokTbl (iFokIdx, PRC_FORK_ERR, MON_GETOKEN_ERR, errno);
    UCP_TRACE_END (MON_GETOKEN_ERR);
  }

  if ((iChiPid=fork()) == 0) {
    if (execvp(caExePath,pcaArgv) != 0) {
      sprintf (g_caMsg, "<EMS> Failure to execute [%s] (errno:%d)",
               caExePath, errno);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      Mtn_FokTbl (iFokIdx, PRC_EXEC_ERR, MON_EXEC_ERR, errno);
      exit (MON_EXEC_ERR);
/*
      UCP_TRACE_END (MON_EXEC_ERR);
*/
    }
  }
  else{
    if (iChiPid == -1) {
      sprintf (g_caMsg, "<EMS> Failure to fork [%s] (errno:%d)",
               caExePath, errno);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      Mtn_FokTbl (iFokIdx, PRC_FORK_ERR, MON_FORK_ERR, errno);
      UCP_TRACE_END (MON_FORK_ERR);
    }
  }

  sprintf (g_caMsg,"<EMS> Fork & execute [%s %s %s]",
           caExePath, pcaArgv[1], MCfg(iCfgIdx).caPara);
  ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);

  MFok(iFokIdx).cStatus = PRC_EXEC_OK;
  /* rcv forked process rtn status & update stFokTbl cStatus */
  iRc = EmsGetInput(&stFkdStat);
  if (iRc < 0)
  {
    sprintf (g_caMsg, "<EMS> Failure to receive ACK from Transaction Server!");
    ErrLog (4000, g_caMsg, RPT_TO_LOG, 0, 0);
    Mtn_FokTbl (iFokIdx, PRC_FORK_ERR, MON_READ_Q_ERR, errno);
  }
  
  if ((iFokIdx == atoi(stFkdStat.caTblidx)) && (iRc >= 0))
  {
    MFok(iFokIdx).cStatus = stFkdStat.cStatus;
    MFok(iFokIdx).iProcid = stFkdStat.lProcPid;
  }

  /* if forked process is not normal then kill it */
  if(MFok(iFokIdx).cStatus != PRC_NORMAL)
  {
    MFok(iFokIdx).iProcid = -2; 
    Mtn_FokTbl (iFokIdx, PRC_EXEC_ERR, MON_EXEC_ERR, errno);
  }
  else
  {
    Mtn_FokTbl (iFokIdx, PRC_NORMAL, MON_NORMAL, 0);
    MFok(iFokIdx).iForktime++;
  }
  
  sprintf (g_caMsg, "<EMS> Receive ACK from TPU [%s]!", stFkdStat.caTblidx);
  ErrLog (10, g_caMsg, RPT_TO_LOG, 0, 0);
  UCP_TRACE_END(MFok(iFokIdx).iMonerr);
}

/*
 *&N& ROUTINE NAME: GetToken
 *&A& ARGUMENTS:
 *&A&    char *pcForkBuf
 *&A&    char **ppcPara
 *&R& RETURN VALUE(S):
 *&R&    int
 *&D& DESCRIPTION:
 *&D*
 */
int GetToken(char *pcForkBuf,char **ppcPara)
{
  int i;

  UCP_TRACE(P_GetToken);
/* TCC:
  i=2;
*/
  i=3;
  if ((ppcPara[i]=strtok(pcForkBuf,WHITE)) == NULL)
  {
     ppcPara[i]=NULL;
     /*
     sprintf (g_caMsg, "ppcPara[%d]:[%s]", i, ppcPara[i]);
     ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
     */
     UCP_TRACE_END(0);
  }

  while((ppcPara[++i]=strtok(NULL,WHITE)) != NULL);
  ppcPara[++i]=NULL;

  UCP_TRACE_END(0);
}

/*
 *&N& ROUTINE NAME: WaitCmd
 *&A& ARGUMENTS:
 *&A&    struct MonCmd stMonCmd
 *&R& RETURN VALUE(S):
 *&R&    int
 *&D& DESCRIPTION:
 *&D*
 */
int WaitCmd(struct MonCmd *stMonCmd)
{
  char caProtocol[80], cProtoType;
  int  iRcvDataLen, iStrCmdSize;

  UCP_TRACE(P_WaitCmd);

  /* get env III_PROTOCOL for protocol type */
  memset (caProtocol, 0, sizeof(caProtocol));
  strcpy ((char *)caProtocol, (char *)getenv("III_PROTOCOL"));

  if (caProtocol[0] != '\0') {
    cProtoType = caProtocol[0];
  }
  else{
    cProtoType = QUEUE_DCS;
  }

  /*   1.accept and read  */
  memcpy (McaDesCode(stDcsBuf), "00Monitor1", 10);
  McRqstCode(stDcsBuf) = DCSACCEPTREAD;
  MlWaiTime(stDcsBuf) = DCS_BLOCK;
  MiDataLen(stDcsBuf) = DCS_MAX_DATA_LEN;
  MpstDcsSiof(stDcsBuf) = &stDcsSiof;
  McProto(stDcsBuf) = cProtoType;
  DcsDispatch(&stDcsBuf);
  if(MiReply(stDcsBuf) != DCS_NORMAL)
  {
    sprintf (g_caMsg,
             "<EMS> Failure to accept/read request to EMS (iRc:%d errno:%d)",
             MiReply(stDcsBuf),MiErrno(stDcsBuf));
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END (GET_CMD_DCS_ERR);
  }
  
  g_iSessIdx = MiSesIdx(stDcsBuf);
  iRcvDataLen = MiDataLen(stDcsBuf) - 8 ;
  if(iRcvDataLen > sizeof(struct MonCmd))
  {
    sprintf (g_caMsg, 
             "<EMS> Receive EMS request incorrectly! (iRc:%d errno:%d)",
             MiReply(stDcsBuf), MiErrno(stDcsBuf));
    ErrLog (1000, g_caMsg, RPT_TO_LOG, McaData(stDcsBuf), iRcvDataLen);
    UCP_TRACE_END (RCV_CMD_DATA_ERR);
  }

  memcpy (stMonCmd->caTblidx, McaData(stDcsBuf), 5);
  stMonCmd->cCmd = McaData(stDcsBuf)[5];

  UCP_TRACE_END (0);
}


/*
 *&N& ROUTINE NAME: RestarProc
 *&A& ARGUMENTS:
 *&A&    int iCfgidx
 *&A&    int iFokidx
 *&R& RETURN VALUE(S):
 *&R&    int
 *&D& DESCRIPTION:
 *&D*
 */
int RestarProc(int iCfgIdx,int iFokIdx)
{
  int iRc;

  if (MFok(iFokIdx).iForktime <= MCfg(iCfgIdx).iRestartno)
  {
    if ((iRc = ForkProc(iCfgIdx,iFokIdx)) != MON_NORMAL){
      Mtn_FokTbl (iFokIdx, PRC_RESTART_ERR, iRc, 0);
      return(iRc);
    }

    Mtn_FokTbl (iFokIdx, PRC_RESTART_OK, MON_NORMAL, 0);

    sprintf (g_caMsg, "<EMS> TPU process is restarted! (Pid:%d),Forktime is %d",
             MFok(iFokIdx).iProcid,MFok(iFokIdx).iForktime);
    ErrLog (1008, g_caMsg, RPT_TO_LOG, 0, 0);
    return(0);
  }

  MFok(iFokIdx).cStatus = PRC_DEAD;
  Mtn_FokTbl (iFokIdx, PRC_DEAD, MON_RESTART_LIMIT_ERR, 0);
  return (MON_RESTART_LIMIT_ERR);
}

/*
 *&N& ROUTINE NAME: KillProc
 *&A& ARGUMENTS:
 *&A&    int iTblidx
 *&R& RETURN VALUE(S):
 *&R&    int
 *&D& DESCRIPTION:
 *&D*
 */
int KillProc(int iFokIdx)
{
  int i,j;
  int iMaxKill;
  int iCfgIdx;
  int iUnWorkno;
  int iHasKill=0;

  UCP_TRACE(P_KillProc);

  if (iFokIdx == ALL_IDX) {
    i = j = 0;
    iMaxKill = gs_iMaxFork;
  }
  else{
    i = j = iFokIdx;
    iMaxKill = iFokIdx;
  }

  if (iFokIdx == ALL_IDX)  {  /* kill all processes */
    iHasKill = 1;
    while (j <= iMaxKill) {
      if ( MFok(j).iProcid != -2 ) {
        iHasKill = 0;
        break;
      }
      j++;
    }
  }
  else {  /* only kill one process */
    if ( MFok(iFokIdx).iProcid == -2 ) {
      iHasKill = 1;
    }
  }
  
  if (iHasKill == 1) {
    UCP_TRACE_END(24);
  }

  while (i <= iMaxKill){
    iCfgIdx = MFok(i).iTblidx;
    if((MFok(i).cStatus == PRC_NORMAL) ||
      (MFok(i).cStatus == PRC_FORK_OK) ||
      (MFok(i).cStatus == PRC_EXEC_OK) ||
      (MFok(i).cStatus == PRC_KILL_ERR) ||
      (MFok(i).cStatus == PRC_SHUTDOWN_ERR) ||
      (MFok(i).cStatus == PRC_RESTART_OK))
    {
      if (kill (MFok(i).iProcid, SIGKILL) != 0)
      {
        sprintf (g_caMsg,
                 "<EMS> Failure to kill TPU by force! (errno:%d=>%s)",
                 errno, sys_errlist[errno]);
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        Mtn_FokTbl (i, PRC_KILL_ERR, MON_KILL_ERR, errno);
      }
      else
      {
        sprintf (g_caMsg,"<EMS> Kill TPU with PID:%d by force!",
                 MFok(i).iProcid);
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        Mtn_FokTbl (i,PRC_KILL_OK,MON_NORMAL,0);
        UnWork_incr (iCfgIdx,i);
        RemoveShm (MFok(i).iProcid);
        RemoveSem (MFok(i).iProcid);
        MFok(i).iProcid = -2;
      }
    }
    i++;
  }

  UCP_TRACE_END(0);
}

/*
 *&N& ROUTINE NAME: ShutOne
 *&A& ARGUMENTS:
 *&A&    int iTblidx
 *&R& RETURN VALUE(S):
 *&R&    int
 *&D& DESCRIPTION:
 *&D*
 */
int ShutOne(int iCfgIdx)
{
  int iFokIdx;
  int i, iRc;

  UCP_TRACE(P_ShutOne);

  itoa1(iCfgIdx,stMonCmd.caTblidx,3);

  if ( MCfg(iCfgIdx).iForkprc == MCfg(iCfgIdx).iUnWorkno ) {
     sprintf (g_caMsg, "<EMS> No more server [%s] to shutdown!",
              MCfg(iCfgIdx).caPrgname);
     ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
     UCP_TRACE_END (23);
  }

  stMonCmd.cCmd=MON_SHUTDOWN;
  iRc = SdCmdRvSta (MCfg(iCfgIdx).cProtocolType, MCfg(iCfgIdx).caDesCode,
                    &stMonCmd,&stFkdStat);
  iFokIdx = atoi(stFkdStat.caTblidx);
  if (iRc != 0)
  {
    sprintf (g_caMsg, "<EMS> Failure to shut server [%s]!",
              MCfg(iCfgIdx).caPrgname);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
/* TCC
    iRc = KillProc(ALL_IDX);
*/
    iRc = KillProc(iCfgIdx);
    if(iRc != 0)
    {
      sprintf (g_caMsg,
               "<EMS> Failure to kill server [%s]! (errno:%d)", 
               MCfg(iCfgIdx).caPrgname, errno);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      UCP_TRACE_END (MON_KILL_ERR);
    }
    UCP_TRACE_END(MON_READ_Q_ERR);
  }

  for (i=0; i<=gs_iMaxFork; i++)
  {
     if (stFkdStat.lProcPid == (long)MFok(i).iProcid)
     {
        iCfgIdx = MFok(i).iTblidx;
        break;
     }
  }

  Mtn_FokTbl (iFokIdx, stFkdStat.cStatus, MON_NORMAL, 0);
  UnWork_incr (iCfgIdx, iFokIdx);

  if (stFkdStat.cStatus == PRC_SHUTDOWN_OK) {
    MFok(iFokIdx).iProcid = -2;
  }

  sprintf (g_caMsg, "<EMS> Server [%s %03d] is shut!",
           MCfg(iCfgIdx).caPrgname, iFokIdx);
  ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);

  UCP_TRACE_END(0);
}


int ShutAll()
{
  int i, iCfgIdx, iRc;
  int iShmKey, iShmId;
  int iSemKey, iSemId;
  struct CwaCtl stCwaCtl;

  if (g_iMdaFlag == 0)
  {
     /* attach MDA share memory */
     stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
     stCwaCtl.cSegCode = CWA_SEG_MDA;
     iRc = CwaLowCtlFac(&stCwaCtl,&pstMda);
     if (iRc != 0) {
       return (-1);
     }
  }

  if (gs_iMaxFork < 0)
     return (0);

  for (i=0; i<=gs_iMaxFork; i++)
  {
     iCfgIdx = MFok(i).iTblidx;
     /* TCC
     sprintf (g_caMsg,
     "<EMS> [%d %02d] iProcId:[%d] gs_iMaxFork:[%d] Status:[%c]",
     iCfgIdx, i, MFok(i).iProcid, gs_iMaxFork, MFok(i).cStatus);
     ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
     */

     ShutOne(iCfgIdx);
  }

  for (i=0; i<=gs_iMaxFork; i++)
  {
     if (MFok(i).iProcid > 0)
     {
        iShmKey = iSemKey = MFok(i).iProcid;
        RemoveShm (iShmKey); 
        RemoveSem (iSemKey); 
     }
  }

  return (0);
}


/*
 *&N& ROUTINE NAME: SdCmdRvSta
 *&A& ARGUMENTS:
 *&A&    char   cProtocolType
 *&A&    char   *paDesCode
 *&A&    struct MonCmd *pstMonCmd
 *&R& RETURN VALUE(S):
 *&R&    int
 *&D& DESCRIPTION:
 *&D*
 */
int SdCmdRvSta (char cProtocolType, char *paDesCode, 
                struct MonCmd *pstMonCmd, struct FkdStat *pstFkdStat)
{
  int    iCfgIdx, iFokIdx;
  int    iDataLen,iRcvDataLen,iSessidx;
  char   cProtoType = '\0';
  char   caProtoType[80], caTmpBuf[10];   
  struct DcsBuf stDcsBuf;
  struct DcsSiof stDcsSiof;

  UCP_TRACE (P_SdCmdRvSta);

  iCfgIdx = atoi(pstMonCmd->caTblidx);
  iFokIdx = atoi(pstFkdStat->caTblidx);

  memset (&stDcsBuf, 0, sizeof(struct DcsBuf));
  memset (&stDcsSiof, 0, sizeof(struct DcsSiof));

  if (cProtocolType == '\0') 
  {
    memset (caProtoType, 0, sizeof(caProtoType));
    strcpy (caProtoType, (char *)getenv( PROTOCOL_TYPE ));
    if (caProtoType[0] != '\0') 
       cProtoType = caProtoType[0];
  } 
  else
    cProtoType = cProtocolType;

  MpstDcsSiof(stDcsBuf) = &stDcsSiof;
  McMoreByte(stDcsBuf) = '0';
  memcpy (McaDesCode(stDcsBuf), paDesCode, DEST_NAME_LEN);
  McRqstCode(stDcsBuf) = DCSCONNECTWRITE;

  memcpy (caTmpBuf, "MONI", 4);
  memcpy (&caTmpBuf[4], pstMonCmd, sizeof(struct MonCmd));
  iDataLen = sizeof(caTmpBuf);
  sprintf (McaDataLen(stDcsBuf), "%.4d", iDataLen + 8);
  memcpy (McaData(stDcsBuf), caTmpBuf, iDataLen);
  MlWaiTime(stDcsBuf) = 35;
  MiDataLen(stDcsBuf) = iDataLen + 8;
  McProto(stDcsBuf) = cProtoType;

  DcsDispatch( &stDcsBuf );

  if (MiReply(stDcsBuf) != DCS_NORMAL) {
    sprintf (g_caMsg, 
         "<EMS> Failure to connect & write shutdown cmd to TPU (iRc:%d)",
         MiReply(stDcsBuf) );
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END (SEND_CMD_ERR);
  }
  iSessidx = MiSesIdx(stDcsBuf)  ;
  McRqstCode(stDcsBuf) = DCSREAD;
  /* set the monitor rcv timeout, if mon doesn't get ack before timeout */
  /* mon will kill the server   */
  MlWaiTime(stDcsBuf) = 35;
  MiDataLen(stDcsBuf) = 1024;
  McProto(stDcsBuf) = cProtoType;
  MiSesIdx(stDcsBuf) = iSessidx;
  DcsDispatch(&stDcsBuf);

  if(MiReply(stDcsBuf) != DCS_NORMAL){
     sprintf (g_caMsg,
     "<EMS> Failure to read shutdown ACK from TPU! (iRc:%d errno:%d)",
     MiReply(stDcsBuf), MiErrno(stDcsBuf));
     ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
     if (MiReply(stDcsBuf) == DCS_E_TIMEOUT) {
       Mtn_FokTbl (iFokIdx, MON_ERR_PASS, MON_READ_Q_TIMEOUT_ERR, errno);
       UCP_TRACE_END (MON_READ_Q_TIMEOUT_ERR);
     }
  }

  iRcvDataLen = MiDataLen(stDcsBuf) - 8 ;

  if (iRcvDataLen > sizeof(struct FkdStat))
  {
    sprintf (g_caMsg,
            "<EMS> Failure to read shutdown ACK from TPU! (iRc:%d errno:%d)",
            MiReply(stDcsBuf), MiErrno(stDcsBuf));
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    Mtn_FokTbl (iFokIdx, MON_ERR_PASS, MON_READ_Q_ERR, errno);
    UCP_TRACE_END (MON_READ_Q_ERR);
  }

  memcpy (pstFkdStat, McaData(stDcsBuf), sizeof(struct FkdStat));
  iFokIdx = atoi(pstFkdStat->caTblidx);

  McRqstCode(stDcsBuf) = DCSDISCONNECT;
  McProto(stDcsBuf) = cProtoType;
  MiSesIdx(stDcsBuf) = iSessidx;
  MiDataLen(stDcsBuf) = 0;
  DcsDispatch(&stDcsBuf);
  if(MiReply(stDcsBuf) != DCS_NORMAL){
    sprintf (g_caMsg,
             "<EMS> Failure to disconnect with TPU! (iRc:%d errno:%d)",
             MiReply(stDcsBuf), MiErrno(stDcsBuf));
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
  }
  /*
  sprintf (g_caMsg,"<EMS> Disconnect session[%d] with TPU!", iSessidx);
  ErrLog (10,g_caMsg,RPT_TO_LOG,0,0);
  */
  UCP_TRACE_END(0);
}

/*
 *&N& ROUTINE NAME: UnWork_incr
 *&A& ARGUMENTS:
 *&A&    int iCfgIdx
 *&A&    int iFokIdx
 *&A&    int iUnWork_no
 *&R& RETURN VALUE(S):
 *&R&    int
 *&D& DESCRIPTION:
 *&D*
 */
int UnWork_incr(int iCfgIdx, int iFokIdx)
{
  int iUnWkno;

  iUnWkno=MCfg(iCfgIdx).iUnWorkno;
  /* TCC: 1996/12/17
  iUnWkno=++MCfg(iCfgIdx).iUnWorkno;
  
  if (iUnWkno >= MAX_FORK_PERTIME){
  */

  if (++iUnWkno > MAX_FORK_PERTIME){
    sprintf (g_caMsg,
      "<EMS> Total number of unwork process [%d] exceeds limit [%d]",
      iUnWkno, MAX_FORK_PERTIME);
    ErrLog (1000,g_caMsg,RPT_TO_LOG,0,0);
    return (MON_UNWK_OVERFLOW);
  }

  MCfg(iCfgIdx).iUnWorkno = iUnWkno;
  MCfg(iCfgIdx).piaUnWkidx[iUnWkno-1]=iFokIdx;

  return(0);
}

/*
 *&N& ROUTINE NAME: UnWork_decr
 *&A& ARGUMENTS:
 *&A&    int iCfgIdx
 *&A&    int iFokIdx
 *&A&    int iUnWorkno
 *&R& RETURN VALUE(S):
 *&R&    int
 *&D& DESCRIPTION:
 *&D*
 */
int UnWork_decr(int iCfgIdx, int iFokIdx)
{
  int iUnWkno;

  iUnWkno=MCfg(iCfgIdx).iUnWorkno;
  MCfg(iCfgIdx).piaUnWkidx[iUnWkno-1] = -1;
  iUnWkno = --MCfg(iCfgIdx).iUnWorkno;
  
  /*
  sprintf(g_caMsg,"<EMS> iUnWkno=%d MCfg(%d).iUnWorkno=%d",
                   iUnWkno,iCfgIdx,MCfg(iCfgIdx).iUnWorkno);
  ErrLog(20,g_caMsg,RPT_TO_LOG,0,0);
  */

  return(0);
}


/*
 *&N& ROUTINE NAME: Init_Tbl
 *&A& ARGUMENTS:
 *&R& RETURN VALUE(S):
 *&R&    int
 *&D& DESCRIPTION:
 *&D*
 */
Init_Tbl()
{
  int i,j;

  /* initial table array */
  i=0;
  while(i < MAX_TABLE_ARRAY){
    MCfg(i).iFkLimitPerTime=0;   /* init Config Table */
    MCfg(i).iRestartno=0;
    MCfg(i).iFstFokNo=0;
    MCfg(i).iForkprc=0;
    MCfg(i).iUnWorkno=0;
    MCrn(i).iFkLimitPerTime=0;   /* init Chron Table  */
    MCrn(i).iRestartno=0;
    MCrn(i).iFstFokNo=0;
    MCrn(i).iForkprc=0;
    MCrn(i).iUnWorkno=0;
    j=0;
    while(j < MAX_FORK_PERTIME){
      MCfg(i).piaUnWkidx[j]=-1;
/* TCC ###
      MCrn(i).piaUnWkidx[j]=-1;
*/
      j++;
    }
    MCfg(i).cProtocolType='Q';
    memset(MCfg(i).caDesCode, 0, sizeof(MCfg(i).caDesCode));
    memset(MCfg(i).caPrgname, 0, sizeof(MCfg(i).caPrgname));
    memset(MCfg(i).caPara, 0, sizeof(MCfg(i).caPara));
    memset(MCrn(i).caPrgname, 0, sizeof(MCrn(i).caPrgname));
    memset(MCrn(i).caPara, 0, sizeof(MCrn(i).caPara));
    i++;
  }

  /* initial process table array */
  i=0;
  while(i < MAX_FORK_PROC){
    MFok(i).iServType=-1;
    MFok(i).iTblidx=0;
    MFok(i).iProcid=-1;
    MFok(i).iForktime=-1;
    MFok(i).cStatus=' ';
    MFok(i).iMonerr=0;
    MFok(i).iErrno=0;
    i++;
  }
}

Mtn_FokTbl(int iFokIdx, int cPrcStatus, int iMonStatus, int iErrno)
{
  /*
  ErrLog(10,"Mtn_FokTbl start",RPT_TO_LOG,0,0);
  */
  if(iMonStatus != MON_ERR_PASS){
    MFok(iFokIdx).cStatus=(char) cPrcStatus;
  }
  if(iMonStatus != MON_ERR_PASS){
    MFok(iFokIdx).iMonerr=iMonStatus;
  }
  if(iMonStatus != MON_ERR_PASS){
    MFok(iFokIdx).iErrno=iErrno;
  }
  /*
  ErrLog(10,"Mtn_FokTbl end",RPT_TO_LOG,0,0);
  */
}

int
SysShutdown(cCmd)
char  cCmd;
{
  int    iRc;
  struct CwaCtl stCwaCtl;
  struct SSA *pstSsa;
  short  sStatus;       /* the system status  */

  UCP_TRACE(P_SysShutdown);

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);

  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }

  sStatus = pstSsa->sSysStatus;

  switch(cCmd) {
    case  TPE_SHUTDOWN:
      if ( !(sStatus & ONLINE_CLOSE) ) {   /* On-Line Mode */
        ErrLog(1000, "<EMS> Normal shutdown at online mode", RPT_TO_LOG, 0, 0);
        iRc = ShutAll();
        if ( iRc != 0 ) {
          sprintf (g_caMsg, " <EMS> Failure to shut TPU!"); 
          printf ("\n%s\n", g_caMsg);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          /* TCC: 19960925
          ErrLog (40000,"<EMS> Failure to shut TPU!", RPT_TO_LOG, 0, 0);
          UCP_TRACE_END (STOP_SERV_ERR);
          */
        }
        /* distinguish if it's transfer to online mode or batch mode */
        if (g_iNoBatch == 1) {  /* online -> online */
          sStatus = sStatus & 0xfb00 ; /* & 11111011 set online-close bit as 0*/
          sStatus = sStatus & 0xbf00 ; /* & 10111111 set restart bit as 0 */
          sStatus = sStatus & 0x7f00 ; /* & 01111111 set system-on bit as 0 */
          pstSsa->sSysStatus = sStatus ;
        }
        else {                  /* online -> batch */
          sStatus = sStatus | ONLINE_CLOSE ; /* set to batch mode */
          sStatus = sStatus & 0xbf00 ;    /* & 10111111  set restart bit as 0 */
          pstSsa->sSysStatus = sStatus ;
        }
      }
      else  {                             /* Batch Mode  */
        ErrLog(1000,"<EMS> Normal shutdown at batch mode",RPT_TO_LOG,0,0);
/*
        memcpy(pstSsa->caTxnDate,pstSsa->caNextDate,DATE_LEN);
        memcpy(pstSsa->caNextDate,pstSsa->caNext2Date,DATE_LEN);
*/
        sStatus = sStatus & 0xfb00 ; /* & 11111011  set online-close bit as 0*/ 
        sStatus = sStatus & 0xbf00 ; /* & 10111111  set restart bit as 0 */
        sStatus = sStatus & 0x7f00 ; /* & 01111111  set system-on bit as 0 */
        pstSsa->sSysStatus = sStatus ;
      }    
      alarm(0);
      iRc = SaveCwaToFile();
      if (iRc != 0){
        sprintf(g_caMsg,"<EMS> Failure to save CWA to file!");
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      }
      iRc = SaveCwaToFile();
      if (iRc != 0){
        sprintf(g_caMsg,"<EMS> Failure to save CWA to file!");
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END (SAVE_CWA_ERR);
      }
      break;
    case  TPE_QUCKSHUT:
      if ( !(sStatus & ONLINE_CLOSE) ) {   /* On-Line Mode */
        ErrLog(1000,"<EMS> Abnormal shutdown at online mode",RPT_TO_LOG,0,0);
        iRc = ShutAll();
        if ( iRc != 0 ) {
          sprintf (g_caMsg, " <EMS> Failure to shut TPU!"); 
          printf ("\n%s\n", g_caMsg);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          /* TCC: 19960925
          ErrLog (40000,"<EMS> Failure to execute abnormal shutdown request!",
                  RPT_TO_LOG, 0, 0);
          UCP_TRACE_END (STOP_SERV_ERR);
          */
        }
        sStatus = sStatus | 0x4000 ;    /* & 10111111  set restart bit as 1 */
        sStatus = sStatus & 0x7f00 ;    /* & 01111111  set system-on bit as 0 */
        pstSsa->sSysStatus = sStatus ;
	alarm(0);
      }
      else  {                             /* Batch Mode  */
        ErrLog(1000,"<EMS> Abnormal shutdown at batch mode",RPT_TO_LOG,0,0);
        sStatus = sStatus | 0x4000 ;    /* & 10111111  set restart bit as 1 */
        sStatus = sStatus & 0x7f00 ;    /* & 01111111  set system-on bit as 0 */
        pstSsa->sSysStatus = sStatus ;
	alarm(0);
      }    
      iRc = SaveCwaToFile();
      if (iRc != 0){
        sprintf(g_caMsg,"<EMS> Failure to save CWA to file!");
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      }
      iRc = SaveCwaToFile();
      if (iRc != 0){
        sprintf(g_caMsg,"<EMS> Failure to save CWA to file!");
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END (SAVE_CWA_ERR);
      }
      break;
    case  TPE_DOBATCH:
      /* TCC */
      if (g_iNoBatch == 1)
      {
        sprintf (g_caMsg, "Warning: Unable to transfer to batch mode !");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        printf ("\n %s\n", g_caMsg);
        printf (" Please check the NO_BATCH value in config.dat.\n");
        UCP_TRACE_END (0);
      }

      iRc = ShutAll();
      if ( iRc != 0 ) 
      {
        sprintf (g_caMsg, 
                 " <EMS> Failure to shut TPU to convert to batch mode!"); 
        printf ("\n%s\n", g_caMsg);
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      }

      sStatus = sStatus | ONLINE_CLOSE ; /* set to batch mode */
      sStatus = sStatus & 0xbf00 ;    /* & 10111111  set restart bit as 0 */
      pstSsa->sSysStatus = sStatus ;

      alarm(0);
      iRc = SaveCwaToFile();
      if (iRc != 0)
      {
        sprintf (g_caMsg, "<EMS> Failure to save CWA to file!");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      }
      iRc = SaveCwaToFile();
      if (iRc != 0)
      {
        sprintf (g_caMsg, "<EMS> Failure to save CWA to file!");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      }
      
      ErrLog (1000, "<EMS> Transfer to batch mode", RPT_TO_LOG, 0, 0);
      break;
    case  TPE_DOONLINE:
      /* TCC 
      if (g_iNoBatch == 1)
      {
        sprintf (g_caMsg, "Warning: Unable to transfer to batch mode !");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        printf ("\n %s\n", g_caMsg);
        printf (" Please check the NO_BATCH value in config.dat.\n");
        UCP_TRACE_END (0);
      }
*/
      iRc = ForkAll();
      if ( iRc != 0 ) 
      {
        sprintf (g_caMsg, 
                 " <EMS> Failure to fork TPU to convert to online mode!"); 
        printf ("\n%s\n", g_caMsg);
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      }
/*
      sStatus = sStatus & ONLINE_CLOSE ; /x set to online mode x/
*/
      sStatus = sStatus & 0x0fbff;    /* & 10111111  set restart bit as 0 */
      pstSsa->sSysStatus = sStatus ;
      alarm(0);
      iRc = SaveCwaToFile();
      if (iRc != 0)
      {
        sprintf (g_caMsg, "<EMS> Failure to save CWA to file!");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      }
      iRc = SaveCwaToFile();
      if (iRc != 0)
      {
        sprintf (g_caMsg, "<EMS> Failure to save CWA to file!");
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      }
      
      ErrLog (1000, "<EMS> Transfer to online mode", RPT_TO_LOG, 0, 0);
      break;
  }
  UCP_TRACE_END(0);
}


/* Release chron task, shared memory and semaphore */
/* TCC: 1996/08/26 Remove Chron Task */
EnvRelse()
{
  FILE   *iFp;
  int    i, iRc;
  struct CwaCtl stCwaCtl;
  struct CwaCreatIobuf stCCBuf;
  int    iChildPid;
  char   caExePath[128], *pcaArgv[MAX_PARAS];

  UCP_TRACE(P_EnvRelse);

  alarm(0);

  if (g_iChronPid != 0) {
    iRc = kill(g_iChronPid,SIGKILL); 
    if (iRc != 0)
    {
      sprintf (g_caMsg, "<EMS> Failure to kill chron server(PID:%d errno:%d)",
               g_iChronPid, errno);
      ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    }
    else
    {
      sprintf (g_caMsg, "<EMS> Kill chron server (PID:%d)!", g_iChronPid);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    }

    sprintf (caExePath, "%s/iii/bin/bat/killchron", 
             (char *)getenv("III_DIR"));
    if ((iFp = fopen (caExePath, "r")) != NULL)
    {
      fclose (iFp);
      
      for (i=0; i<g_iMaxLoadCrn; i++)
      {
        pcaArgv [0] = caExePath;
        pcaArgv [1] = MCrn(i).caPrgname;
        pcaArgv [2] = NULL;

        signal(SIGCLD, SIG_IGN);
        if ((iChildPid=fork()) == 0 ) 
        {
          if (execvp (caExePath, pcaArgv) != 0) 
          {
            sprintf (g_caMsg,
            "<EMS> Failure to fork & execute [%s %s] (errno:%d=>%s)",
            caExePath, pcaArgv[1], errno, sys_errlist[errno]);
            ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
            continue;
          }
        }
        else 
        {
          if (iChildPid == -1) 
          {
           sprintf (g_caMsg,"<EMS> Failure to fork [%s %s] (errno:%d=>%s)",
           caExePath, pcaArgv[1], errno, sys_errlist[errno]);
           ErrLog (1000,g_caMsg,RPT_TO_LOG,0,0);
           continue;
          }
        }
        sprintf(g_caMsg,"<EMS> Kill chron task [%s] by [%s]", 
                MCrn(i).caPrgname, caExePath);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      }
    }
    else
    {
      sprintf (g_caMsg, 
               "<EMS> Chron killer [%s] does not exist! (errno:%d=>%s)",
               caExePath, errno, sys_errlist[errno]);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    }
      
  }

  iRc = IpcShmRm( g_iCtfKey);
  if ( iRc < 0 ) 
  {
    sprintf (g_caMsg, "<EMS> Failure to remove CTF Shm (key:0x%0x)!", 
             g_iCtfKey);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
  }
  else
  {
    sprintf (g_caMsg, "<EMS> Remove CTF Shared Memory (key:0x%0x)!", 
             g_iCtfKey);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
  }

  iRc = IpcShmRm( g_iIctKey);
  if ( iRc < 0 ) 
  {
    sprintf (g_caMsg, "<EMS> Failure to remove ICT Shm (key:0x%0x)!",
             g_iIctKey);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
  }
  else
  {
    sprintf (g_caMsg, "<EMS> Remove ICT Shared Memory (key:0x%0x)!", 
             g_iIctKey);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
  }

  iRc = IpcShmRm( g_iIetKey);
  if ( iRc < 0 ) 
  {
    sprintf (g_caMsg, "<EMS> Failure to remove IET Shared Memory (key:0x%0x)!", 
             g_iIetKey);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
  }
  else
  {
    sprintf (g_caMsg, "<EMS> Remove IET Shared Memory (key:0x%0x)!", 
             g_iIetKey);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
  }
  /*
  iRc = IpcShmRm( g_iDbtKey);
  if ( iRc < 0 ) 
  {
    sprintf (g_caMsg, "<EMS> Failure to remove DBT Shared Memory (key:0x%0x)!", 
             g_iDbtKey);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
  }
  else
  {
    sprintf (g_caMsg, "<EMS> Remove DBT Shared Memory (key:0x%0x)!", 
             g_iDbtKey);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
  }
  */

  stCwaCtl.cFunCode = CWA_REMOVE;
  stCCBuf.iShmKey = g_iCwaKey;
  stCCBuf.iSemKey = g_iCwaKey;

  iRc = CwaCtlFac(&stCwaCtl,&stCCBuf);
  if (iRc != CWA_NORMAL) 
  {
    sprintf (g_caMsg, "<EMS> Failure to remove CWA Shared Memory (key:0x%0x)!", 
             g_iCwaKey);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( REMOVE_SHM_ERR );
  }
  else
  {
    sprintf (g_caMsg, "<EMS> Remove CWA Shared Memory & Semaphore(key:0x%0x)!", 
             g_iCwaKey);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
  }

  UCP_TRACE_END(0);
}


/* TCC: Remove tasks defined in emdifmod.dat */
#define    FORK_RM_MODPG_ERR      -1
#define    RM_MODPROG_EXEC_ERR    -2

int
RmComponent()
{
  int  i;
  int  iStatus, iChildPid, iWaitCode;
  char caExePath[MAX_EXEC_PATH_LEN];    /* buf for keep exec path str */

  UCP_TRACE (P_RmComponent);

  for (i=0; strlen(g_caRlPgName[i]) != 0; i++)
  {
    if (strncmp(g_caRlPgName[i],"NULL",4) != 0)
    {
      memset (caExePath, 0, MAX_EXEC_PATH_LEN);
      sprintf (caExePath, "%s/iii/bin/exe/%s",
               (char *) getenv("III_DIR"), g_caRlPgName[i]);

      if ((iChildPid = fork()) == 0)
      {
        if (execlp (caExePath, caExePath, "R", (char *)0) != 0)
        {
          sprintf (g_caMsg,
              "<EMS> Failure to remove interface module [%s] (errno:%d==>%s)",
              caExePath, errno, sys_errlist[errno]);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          continue;
        }
      }
      else
      {
        if(iChildPid == -1)
        {
          sprintf (g_caMsg, 
                   "<EMS> Failure to fork to remove [%s]! (errno:%d==>%s)",
                   caExePath, errno, sys_errlist[errno]);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          continue;
        }
      }

      sprintf (g_caMsg, "<EMS> Interface module [%s] removed!", 
               caExePath);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    }
  }

  UCP_TRACE_END (0);
}


ABEND_RTN ()
{

  UCP_TRACE (P_ABEND_RTN);

  alarm(0);
  EnvRelse ();
  RmComponent ();

  UCP_TRACE_END (0);
}


/****************AUXILIARY FUNCTIONS ******************************/

itoa(n,s)
char *s;
int n;
{
     int i;
     i=0;
     do  {
         *(s+i) = n % 10 + '0';
         i++;
     }   while ((n /= 10) >0);
     *(s+i) = '\0';
     reverse(s);
}

itoa1(n,s,len)
int n,len;
char *s;
{
 int i,j;

 itoa(n,s);
 i=strlen(s);
 if (i == len) {
   return(0);
 }
 else {
   for ( j=i; j >= 0; j-- )
     s[len-i+j]=s[j];
   while ( (len-i+j) >= 0 ) {
     s[len-i+j]='0';
     j--;
   }
 }
}

reverse(s)
char *s;
{
     int   i, j;
     char  c;

     for (i = 0, j = strlen(s) - 1 ; i < j ; i++, j--) {
          c = *(s+i);
          *(s+i) = *(s+j);
          *(s+j) = c;
     }
}
/****************AUXILIARY FUNCTIONS END******************************/

Daemon_Start(ignsigcld)
int ignsigcld;  /* this variable is used for telling whether ignore CLD */
{
	register  int	iChildPid,iFd;
        char      caCdPath[40];

	if (getppid() == 1) {
	       goto out;
        }

#ifdef SIGTTOU
	signal(SIGTTOU, SIG_IGN);
#endif
#ifdef SIGTTIN
	signal(SIGTTIN, SIG_IGN);
#endif
#ifdef SIGTSTP
	signal(SIGTSTP, SIG_IGN);
#endif

	if (  (iChildPid = fork() ) < 0)
        {
          sprintf(g_caMsg, "<EMS> Failure to fork the first child");
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        }
	else if (iChildPid > 0)
             {
               sprintf (g_caMsg, "<EMS> ems.x daemon fork ok(PID:%d)", 
                        getpid());
               ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
	       exit(0);
             }

	if (setpgrp() == -1)
        {
          sprintf(g_caMsg, "<EMS> Failure to change process group");
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        }

 	signal(SIGHUP, SIG_IGN);

	if (  (iChildPid = fork() ) < 0)
        {
          sprintf(g_caMsg, "<EMS> Failure to fork the second child");
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        }
	else if (iChildPid > 0)
             {
               sprintf (g_caMsg, "<EMS> ems.x daemon fork ok(PID:%d)", 
                        iChildPid);
               ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
	       exit(0);
             }

out:
#ifdef SCO_UNIX
	for (iFd=0; iFd < NOFILES_MAX; iFd++) {
#else
	for (iFd=0; iFd < NOFILE; iFd++) {
#endif

          if ( (iFd == 1) || (iFd == 2) ) {
	  }
  	  else {
	     close(iFd);
	  }

	}

	errno = 0;

        memset(caCdPath,'\0',40);
        strcpy(caCdPath,(char *) getenv("III_DIR"));
        strcat(caCdPath,"/iii/log");
	chdir(caCdPath);
	umask(0);
	
	if (ignsigcld) {
	     signal(SIGCLD, SIG_IGN);
	}
}


int LoadQuTbl ()
{
  FILE *pfQuTbl;
  int  j, k;
  char caQuTbl[256], caBuf[256], *pcaToken;

  sprintf (caQuTbl, "%s/%s",
           (char *)getenv("III_DIR"), QUEUE_TABLE);
  if ((pfQuTbl = fopen (caQuTbl, "r")) == NULL)
  {
    sprintf (g_caMsg,
             "<DCS> Failure to open queue table [%s]! (errno:%d==>%s)",
             caQuTbl, errno, sys_errlist[errno]);
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    return (DCS_ES_OPENTBLFILE);
  }

  memset (caBuf, 0, sizeof(caBuf));
  fgets (caBuf, sizeof (caBuf), pfQuTbl);

  j = 0;
  do
  {
     memset (&g_stQuTbl[j], 0, sizeof(g_stQuTbl[j]));
     for (k=0; k<sizeof(caBuf); k++)
     if (caBuf[k] == '\n')
     {
       caBuf[k] = 0;
       break;
     }

     pcaToken = (char *)strtok (caBuf, " \t\n");
     if (pcaToken != NULL && pcaToken[0] != '#')
     {
        errno = 0;
        if (strlen(pcaToken) != 10)
        {
          sprintf (g_caMsg,
          "<EMS> The length of the destination code [%d] is not equal to 10",
          strlen(pcaToken));
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          return (-1);
        }
        memcpy (g_stQuTbl[j].ucDesCode, pcaToken, 10);

        j++;
     }
  
    fgets (caBuf, sizeof (caBuf), pfQuTbl);
  } while (!feof(pfQuTbl));

  g_iMaxQuLine = j;

  fclose (pfQuTbl);

  return (0);
}


CheckQuDest (char *pcaDest)
{
  int i;

  for (i=0; i<g_iMaxQuLine; i++)
  {
     if (strncmp(pcaDest, g_stQuTbl[i].ucDesCode, 10) == 0)
        break;
  }

  if (i >= g_iMaxQuLine)
  {
     sprintf (g_caMsg,
"<EMS> Destination code[%.10s] in server.dat is not defined in queuetbl",
     pcaDest);
     ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
     return (-1);
  }

  for (i=0; i<gs_iMaxLoadCfg; i++)
  {
     if (strncmp(pcaDest, MCfg(i).caDesCode, 10) == 0)
        return (-2);
  }

  return (0);
}


int CheckSrvName (char *pcaSrvName)
{
  int i, iRc;
  struct stat buff;
  char caSrvPath[256];

  for (i=0; i<gs_iMaxLoadCfg; i++)
  {
     if (strncmp(pcaSrvName, MCfg(i).caPrgname, strlen(pcaSrvName)) == 0)
        return (-1);
  }

  sprintf (caSrvPath, "%s/iii/bin/exe/%s",
           (char *)getenv("III_DIR"), pcaSrvName);
  iRc = stat (caSrvPath, &buff);
  if (iRc == 0)
  {
     if (buff.st_size <= 0)
        return (-2);
  }
  else
    return (-2);

  return (0);
}


RemoveShm (int iShmKey)
{
  int iShmId, iRc;

  iShmId = shmget(iShmKey,0,0);

  if (iShmId == -1) {
    sprintf (g_caMsg,
      "<EMS> Share memory key [0x%x] does not exist! [errno:%d]\n",
      iShmKey, errno);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    return (-1);
  }
  else
  {
    iRc = shmctl(iShmId, IPC_RMID, 0);
    if (iRc == -1){
      sprintf (g_caMsg,
        "<EMS> Failure to remove share memory ID:[%d]! [errno:%d]\n",
        iShmId, errno);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      return (-2);
    }
    sprintf (g_caMsg, "<EMS> Remove TPU shared memory with key:[0x%0x]",
             iShmKey);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
  }

  return (0);
}


RemoveSem (int iSemKey)
{
  int iSemId, iRc;

  iSemId = semget((key_t)iSemKey,0,0);
  if (iSemId == -1) {
    sprintf (g_caMsg,
      "<COM> Semaphore key [0x%0x] does not exist! (errno:%d)",
      iSemKey, errno);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    return (-1);
  }
  else
  {
    iRc = semctl(iSemId, SEM_NUM, IPC_RMID,0);
    if (iRc == -1) {
      sprintf (g_caMsg,
      "<COM> Failure to remove semaphore with id[%d]! (errno:%d)",
      iSemId, errno);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      return (-2);
    }
    sprintf (g_caMsg, "<EMS> Remove TPU semaphore with key:[0x%0x]",
             iSemKey);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
  }
  return (0);
}


