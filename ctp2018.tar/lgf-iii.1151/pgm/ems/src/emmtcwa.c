/*
 *&N& ROUTINE NAME: main  
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&           
 *&R& RETURN VALUES:
 *&R&           
 *&R&           
 *&D& DESCRIPTION:           
 *&D&     ���{�������Һ޲z�l�t�α���ʱ��u��{��, �t�d��� CWA �����p�P���@
 *&D&     ���{���i����W����ά��ʱ��{���s��
 *&D&     ( This program is Curses mode, i.e. using Curses as the output)      
 */

#include <curses.h>
#include <signal.h>
#include "emctcwa.h"
#include "errlog.h"
#include "dcs.h"
#include "cwa.h"
#include "emctool.h"

/* tool specific constants */

#define  MAX_DATA_LEN   20
#define	 MENU_FILE      "cwa.scr"
#define  TOOL_NAME      "emstcwa"
/* the number of records shown at the same time */
#define  NO_RECORD      1
/* the number of fields in CWA-SSA data structure */
#define  NO_ITEM        17
#define  SYSTEM_RESTART 0x4000 /* 1:restarted ; 0:Normal Begin */
#define  IS_OVER_TIME   0x0800 /* 1:Overtime  ; 0:NotOvertime  */
#define  ONLINE_CLOSE   0x0400 /* 1:Batch ; 0:On_line          */
#define  OPERATE_ERR    -1
#define  SEND_SIF_ERR   -2
#define  RCV_SOF_ERR    -3
#define  IN_MAIN         1
#define  IN_SUB          2
#define  BASE_YEAR       "BASE_YEAR"
#define  CONFIG_FILE     "iii/etc/tbl/config.dat"

/* Key Definition */
#define  CTL_P           16
#define  CTL_N           14
#define  CTL_L           12
#define  CTL_R           18
#define  CTL_I            9
#define  CTL_H            8
#define  CTL_D            4
#define  CTL_U           21
#define  CTL_K           11
#define  CR              13
#define  ESC             27
#define  ENTER           0x0797  

#define  DATE_LEN        8
#define  DAYS_OFFSET     6  /* YYYYMMDD  */
#define  MNTH_OFFSET     4  /* YYYYMMDD  */
#define  YEAR_OFFSET     0  /* YYYYMMDD  */
#define  TRUE            1
#define  FALSE           0
#define  MAX_DATW        3

int      iaMax_Days[13] = {  0, 31, 28, 31, 30, 31, 30,
                                   31, 31, 30, 31, 30, 31} ;
int      DateValid();
int      TestChk();

struct stItem {
	int iPage;
	int iRow;
	int iCol;
	int (*Routine1)();
	int (*Routine2)();
	char caData[ MAX_DATA_LEN ];
	char cType;
	int iLength;
	char cAttribute;
	} stRecord[ NO_ITEM * NO_RECORD ] = {
            {1, 5, 33, NULL, NULL, "", 'c', 7, 'd'},
            {1, 6, 33, NULL, NULL, "", 'c', 4, 'd'},
            {1,12, 33, NULL, DateValid, "", 'c', 8, 'e'},
            {1,13, 33, NULL, DateValid, "", 'c', 8, 'e'},
            {1,14, 33, NULL, DateValid, "", 'c', 8, 'e'},
            {1, 0,  0, NULL, NULL, "", 'c', 4, 'r'},
            {1, 7, 33, NULL, NULL, "", 'c', 7, 'd'},
            {1, 8, 33, NULL, NULL, "", 'c', 6, 'd'},
            {1, 9, 33, NULL, NULL, "", 'c',13, 'd'},
            {1,18, 33, NULL, NULL, "", 'c', 2, 'd'},
            {1,15, 33, NULL, NULL, "", 'c', 5, 'd'},
            {1, 0,  0, NULL, NULL, "", 'c', 4, 'r'},
            {1, 0,  0, NULL, NULL, "", 'c', 4, 'r'},
            {1,17, 33, NULL, NULL, "", 'c', 5, 'd'},
            {1,16, 33, NULL, NULL, "", 'c', 5, 'd'},
/* TCC: 1997/05/12
            {1,11, 33, NULL, NULL, "", 'c', 4, 'd'},
*/
            {1,11, 33, NULL, TestChk, "", 'c', 7, 'e'},
            {1,10, 33, NULL, NULL, "", 'c', 7, 'd'}
	}; 

struct stEditItem {
	int iRowCol;  /* iRow * 100 + iCol */
	int iIndex;
	};
static struct SSA  sg_stSsaArea;
static struct MonCmd  sg_stMonCmd;
int    g_iBaseYear;

main( argc, argv )
int argc;
char **argv;
{
  struct stMenu *pstMenu;
  struct stMenu *InitTool();
  int    i,iRc;
  char   caFileName[81];

/*
  printf("argv[1] = %s\n",argv[1]);
*/
  if (argc == 1) {
    printf("Usage : emxtcwa.x 11111B\n");
    exit(0);
  }
  else if (argc ==2) {
    if (argv[1][5] != 'B') {
      printf("Usage : emxtcwa.x 11111B\n");
      exit(0);
    }
  }
  else if ( (argc == 3) && (argv[2][0] == 'E') ) {
    for (i=0;i<NO_ITEM;i++) {
      if ( stRecord[i].iRow != 0){
        stRecord[i].cAttribute = 'e';
      }
    }
  }
  else {
    printf("Usage : emxtcwa.x 11111B\n");
    exit(0);
  }
    
  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat((char *)caFileName, (char *)"/");
  strcat((char *)caFileName,  CONFIG_FILE);
  iRc = InitCnfTbl(caFileName);
  if ( iRc < 0 ){
    printf("Initial Config Table Fail !!\n");
    exit( -1 );
  }

  g_iBaseYear = GetCnfValue( BASE_YEAR );
  if (g_iBaseYear < 0){
    printf("Get Base Year Value Fail !!\n");
    exit( -2 );
  }

  memcpy(sg_stMonCmd.caTblidx,argv[1],sizeof(struct MonCmd));
  SendCmdToMon(&sg_stMonCmd,IN_MAIN);

  pstMenu = (struct stMenu *) InitTool();
  iRc = RetrieveData( pstMenu );
  if (iRc != 0) {
    DisplayData( pstMenu );
    wgetch(pstMenu->pwWin);
    EndTool( pstMenu );
    exit(0);
  }
  DisplayData( pstMenu );
  Process( pstMenu, 0 );
  EndTool( pstMenu );
}

struct stMenu *InitTool()
{
  struct stMenu *pstMenu;
  struct stMenu *InitMenu();
  int Interrupt();

  /* call Interrupt() if user hits BREAK or DELETE */
  signal( SIGINT, Interrupt );

  /* initially setup of curses */
  initscr();
  cbreak();
/*  raw(); */
  noecho();
  nonl();
/*  keypad( stdscr, TRUE );    /x to get arrow keys */

  /* to display menu and initialize menu data structure */
  pstMenu = (struct stMenu *) InitMenu();

  return( pstMenu );
}

/* this routine should be modified for each tool */
struct stMenu *InitMenu()
{
  FILE *pfMenuFile;
  char caBuff[ 80 ];
  char caFlName[80];
  struct stMenu *pstMenu;
  struct stItem *pstItem;
  int iCurRow;

  memset (caFlName, 0, sizeof(caFlName));
  sprintf (caFlName, "%s/iii/etc/cmg/%s",
           (char *) getenv("III_DIR"), MENU_FILE);

  if (( pfMenuFile = fopen(caFlName, "r" )) == NULL) {
    fprintf( stderr, "%s: cannot open file: %s\n", TOOL_NAME, MENU_FILE );
    EndTool();
  }

  /* to allocate the menu data structure */
  pstMenu = (struct stMenu *) calloc( sizeof( struct stMenu ), 1 );
  pstMenu->pwWin = (WINDOW *) newwin( LINES, COLS, 0, 0 );
  pstMenu->iNoRecord = NO_RECORD;
  pstMenu->pstNextMenu = NULL;
  pstMenu->pstItem = (struct stItem *) &stRecord;

  /* to get menu from the menu file */
  iCurRow = 0;
  while ((fgets( caBuff, COLS, pfMenuFile )) != NULL) {
    if (strlen( caBuff ) != 0) {
      mvwaddstr( pstMenu->pwWin, iCurRow, 0, caBuff );
    }
    iCurRow = iCurRow + 1;
  }

  wrefresh( pstMenu->pwWin );      /* to show menu onto the screen */
  fclose( pfMenuFile );

  /* to initialize menu data structure */
  pstItem = pstMenu->pstItem;

  return( pstMenu );
}

/* to retrieve data from EMS server */
int RetrieveData( pstMenu )
struct stMenu *pstMenu;
{
  struct stItem *pstItem;
  struct SSA    stSsaArea;
  char   caTmpBuf[20];
  char   caDateBuf[11]="//////////";
  int    iRc;

  pstItem = pstMenu->pstItem;
  iRc = GetInfoFmEms(RETRIEVE,CWA_SSA,&stSsaArea);
  memcpy(&sg_stSsaArea,&stSsaArea,sizeof(struct SSA));
  strncpy( caTmpBuf, stSsaArea.caTxnDate,8 );
  memcpy( caDateBuf,caTmpBuf,4);
  memcpy( caDateBuf+5,caTmpBuf+4,2);
  memcpy( caDateBuf+8,caTmpBuf+6,2);
  mvwaddstr( pstMenu->pwWin, 0, 65, caDateBuf);
  if (iRc ==0) {
    itoa1(stSsaArea.iDumpSeqNo,caTmpBuf,4); 
    caTmpBuf[4] = '\0';
    strcpy( pstItem[ DUMP_SEQ_NO ].caData,caTmpBuf );
    strcpy( pstItem[ SYS_ID ].caData, stSsaArea.caSysId );
    strncpy( pstItem[ TXN_DATE ].caData, stSsaArea.caTxnDate,8 );
    strncpy( pstItem[ NEXT_DATE ].caData, stSsaArea.caNextDate,8 );
    strncpy( pstItem[ NEXT_2_DATE ].caData, stSsaArea.caNext2Date,8  );
    itoa1(stSsaArea.sNextDayCnt,caTmpBuf,2); 
    caTmpBuf[2] = '\0';
    strcpy( pstItem[ NEXT_DAY_CNT ].caData, caTmpBuf );
    if ( !(stSsaArea.sSysStatus & SYSTEM_RESTART) ) { 
      strcpy(caTmpBuf,"NORMAL");
    }
    else {
      strcpy(caTmpBuf,"RESTART");
    }
    strcpy( pstItem[ SYS_STATUS ].caData, caTmpBuf );

    if ( !(stSsaArea.sSysStatus & ONLINE_CLOSE) ) { 
      strcpy(caTmpBuf,"ONLINE");
    }
    else {
      strcpy(caTmpBuf,"BATCH");
    }
    strcpy( pstItem[ OP_STATUS ].caData, caTmpBuf );

    if ( !(stSsaArea.sSysStatus & IS_OVER_TIME) ) { 
      strcpy(caTmpBuf,"NOT OVER TIME");
    }
    else if (stSsaArea.sSysStatus == '1') { 
      strcpy(caTmpBuf,"OVER TIME");
    } 
    strcpy( pstItem[ OVER_TIME ].caData, caTmpBuf );

    pstItem[ FRONT_LINE_STATUS ].caData[0] = stSsaArea.cFrontLineStatus;
    pstItem[ FRONT_LINE_STATUS ].caData[1] = '\0';
    strncpy( pstItem[ PREV_TXN_LOG_RRN ].caData, stSsaArea.caPrevTxnLogRrn,5);
    strncpy( pstItem[ PREV_BTEF_RRN ].caData, stSsaArea.caPrevBtefRrn,5);
    strncpy( pstItem[ LAST_RRN_IN_BTEF ].caData,stSsaArea.caLastRrnInBeft,5);
    itoa1(stSsaArea.lTotalTxnCnt,caTmpBuf,5); 
    strcpy( pstItem[ TOTAL_TXN_CNT ].caData, caTmpBuf );
    itoa1(stSsaArea.lNextAvLogRrn,caTmpBuf,5); 
    strcpy( pstItem[ NEXT_AV_LOG_RRN ].caData, caTmpBuf );
    switch(stSsaArea.cSysOperatingMode) {
      case '1':
        strcpy(caTmpBuf,"PRODUCT");
        break;
      case '2':
        strcpy(caTmpBuf,"TEST   ");
        break;
      case '3':
        /* TCC
        strcpy(caTmpBuf,"Simulation");
        */
        strcpy(caTmpBuf,"DEBUG  ");
        break;
      default:
        strcpy(caTmpBuf,"Unknown");
    }
    strcpy( pstItem[ SYS_OPERATING_MODE ].caData, caTmpBuf );

    if (stSsaArea.cSystemRole == '0') { 
      strcpy(caTmpBuf,"CENTER");
    }
    else if (stSsaArea.cSystemRole == '1') { 
      strcpy(caTmpBuf,"BRANCH");
    } 
    else {
      strcpy(caTmpBuf,"UNKNOWN");
    } 

    strcpy( pstItem[ SYSTEM_ROLE ].caData, caTmpBuf );
    return(0);
  }
  else {
    wattron(pstMenu->pwWin,A_BLINK|A_REVERSE);
    mvwaddstr( pstMenu->pwWin, 23, 25, "CWA OPERATING ERROR,Press Any Key to Exit");
    wattroff(pstMenu->pwWin,A_BLINK|A_REVERSE);
    printf("\a\a\a");
    return(-1);
  }
}

/* to update data into EMS server */
int UpdateData( pstMenu )
struct stMenu *pstMenu;
{
  struct stItem *pstItem;
  char   caTmpBuf[10],cChar;
  int    i,j,iRc ;

    pstItem = pstMenu->pstItem;

    for (i=0; i<7; i++)
    {
      caTmpBuf [i] = mvwinch (pstMenu->pwWin,
                              pstMenu->pstItem [SYS_OPERATING_MODE].iRow,
                              pstMenu->pstItem [SYS_OPERATING_MODE].iCol+i);
      caTmpBuf[i] = toupper (caTmpBuf[i]);
    }
    strcpy (pstItem[ SYS_OPERATING_MODE ].caData, caTmpBuf);
    if (strncmp (caTmpBuf, "PRODUCT", 7) == 0)
       sg_stSsaArea.cSysOperatingMode = '1';
    else
    if (strncmp (caTmpBuf, "TEST   ", 7) == 0)
       sg_stSsaArea.cSysOperatingMode = '2';
    else
    if (strncmp (caTmpBuf, "DEBUG  ", 7) == 0)
       sg_stSsaArea.cSysOperatingMode = 'D';

    for (i=TXN_DATE;i<=NEXT_2_DATE;i++) {
      for (j=0;j<8;j++) {
        cChar = mvwinch(  pstMenu->pwWin,pstMenu->pstItem[ i ].iRow,
                          pstMenu->pstItem[ i ].iCol+j);
        caTmpBuf[j] = cChar;
      }
      caTmpBuf[j] = '\0';
      strncpy( pstItem[ i ].caData,caTmpBuf,8 );
    }
  /* Copy each item shown on screen to pstItem                       */
  /* Copy each item in pstItem[] to stCWA_SSA                        */
  /* Fill MSG-0004, then call DcsDispatch's function to send to server */
  strncpy( sg_stSsaArea.caTxnDate, pstItem[ TXN_DATE ].caData, 8 );
  strncpy( sg_stSsaArea.caNextDate, pstItem[ NEXT_DATE ].caData, 8 );
  strncpy( sg_stSsaArea.caNext2Date, pstItem[ NEXT_2_DATE ].caData, 8 );

  SendCmdToMon(&sg_stMonCmd,IN_SUB);

  iRc = GetInfoFmEms(UPDATE,CWA_SSA,&sg_stSsaArea);
  if (iRc ==0) {
    wattron(pstMenu->pwWin,A_BLINK|A_REVERSE);
    mvwaddstr( pstMenu->pwWin, 23, 25, "Update SSA successfully!!");
    wattroff(pstMenu->pwWin,A_BLINK|A_REVERSE);
  }
  else {
    wattron(pstMenu->pwWin,A_BLINK|A_REVERSE);
    mvwaddstr( pstMenu->pwWin, 23, 25, "Failure to update SSA!!");
    wattroff(pstMenu->pwWin,A_BLINK|A_REVERSE);
  }
  return(0);
}

int DisplayData( pstMenu )
struct stMenu *pstMenu;
{
  int i;
  char cAttr;

  for (i = 0; i < NO_ITEM; i ++) {
    cAttr = pstMenu->pstItem[ i ].cAttribute;
    if ( cAttr == 'd' ) {
      mvwaddstr( pstMenu->pwWin,
                 pstMenu->pstItem[ i ].iRow,
                 pstMenu->pstItem[ i ].iCol, 
                 pstMenu->pstItem[ i ].caData );
    }
    else if ( cAttr == 'e' ) {
      wattron( pstMenu->pwWin, A_UNDERLINE );
      mvwaddstr( pstMenu->pwWin,
                 pstMenu->pstItem[ i ].iRow,
                 pstMenu->pstItem[ i ].iCol, 
                 pstMenu->pstItem[ i ].caData );
      wattroff( pstMenu->pwWin, A_UNDERLINE );
    }
  }

  wrefresh( pstMenu->pwWin );
}

int EndTool( pstMenu )
struct stMenu *pstMenu;
{
  struct stMenu *ptr1, *ptr2;

  /* to release menu structure allocated */
  ptr1 = pstMenu;
  while (ptr1 != NULL) {
    ptr2 = ptr1->pstNextMenu;
    free( ptr1 );
    ptr1 = ptr2;
  }

  endwin();
  exit( 0 );
}

int Process( pstMenu,iIdx )
struct stMenu *pstMenu;
int    iIdx;            /* current editable item's index for stEditList */
{
  int iKeyIn;
  int iCurRow, iCurCol, iMaxCol;
  int iInsert; /* insert / replace flag */
  int iIndex;  /* current editable item's index for stRecord */
  int iNoEditItem;
  int iRc;
  struct stEditItem stEditList[ NO_ITEM ];

  iInsert = 0;
  BuildEdtList( pstMenu, stEditList, &iNoEditItem );
  iIndex = stEditList[ iIdx ].iIndex;
  mvwprintw( pstMenu->pwWin, 20, 57, "%2d", iIdx + 1 );
  MvEdtItem( pstMenu, iIndex, A_UNDERLINE );
  keypad(pstMenu->pwWin,TRUE);

  while (1) {
    /* to refresh screen */
    wrefresh( pstMenu->pwWin );

    /* get key and process */
    iKeyIn = wgetch(pstMenu->pwWin);
    switch( iKeyIn ) {
      case KEY_UP :
      case CTL_P  :
        iRc = ChkRtn(pstMenu, stEditList[ iIdx ].iIndex);
        /* iRc == 1 represents check ok !! */
        if (iRc != 1) {   /* still stay in the same field */
          iIndex = stEditList[ iIdx ].iIndex;
          MvEdtItem( pstMenu, iIndex, A_UNDERLINE );
        }
        else {
          iIdx = (iIdx + iNoEditItem - 1) % iNoEditItem;
          mvwprintw( pstMenu->pwWin, 20, 57, "%2d", iIdx + 1 );
          iIndex = stEditList[ iIdx ].iIndex;
          MvEdtItem( pstMenu, iIndex, A_UNDERLINE );
        }
        break;
      case CTL_N  :
      case KEY_DOWN :
      case ENTER :
      case CR :
        iRc = ChkRtn(pstMenu, stEditList[ iIdx ].iIndex);
        /* iRc == 1 represents check ok !! */
        if (iRc != 1) {   /* still stay in the same field */
          iIndex = stEditList[ iIdx ].iIndex;
          MvEdtItem( pstMenu, iIndex, A_UNDERLINE );
        }
        else {
          iIdx = (iIdx + 1) % iNoEditItem;
          mvwprintw( pstMenu->pwWin, 20, 57, "%2d", iIdx + 1 );
          iIndex = stEditList[ iIdx ].iIndex;
          MvEdtItem( pstMenu, iIndex, A_UNDERLINE );
        }
        break;
      case KEY_LEFT :
      case CTL_L  :
        getyx( pstMenu->pwWin, iCurRow, iCurCol );
        if ( iCurCol > pstMenu->pstItem[ iIndex ].iCol ) {
          wmove( pstMenu->pwWin, iCurRow, iCurCol - 1 );
        }
        else {
          beep();
        }
        break;
      case KEY_RIGHT :
      case CTL_R  :
        getyx( pstMenu->pwWin, iCurRow, iCurCol );
        if ( iCurCol < pstMenu->pstItem[ iIndex ].iCol +
                       pstMenu->pstItem[ iIndex ].iLength - 1 ) {
          wmove( pstMenu->pwWin, iCurRow, iCurCol + 1 );
        }
        else {
          beep();
        }
        break;
      case KEY_HOME :
      case CTL_H  :
        getyx( pstMenu->pwWin, iCurRow, iCurCol );
        if ( iCurCol > pstMenu->pstItem[ iIndex ].iCol ) {
          wmove( pstMenu->pwWin, iCurRow, pstMenu->pstItem[ iIndex ].iCol );
        }
        else {
          beep();
        }
        break;
      case CTL_I  :
      case KEY_IC :   
        iInsert = 1 - iInsert;
        getyx( pstMenu->pwWin, iCurRow, iCurCol );
        mvwaddstr( pstMenu->pwWin, 20, 41, (iInsert ? "INS" : "REP") );
        wmove( pstMenu->pwWin, iCurRow, iCurCol );
        break;
      case CTL_D  :
      case KEY_DC :   
        DeleteCh( pstMenu, iIndex );
        break;
      case CTL_U  :
        Undo( pstMenu, iIndex );
        break;
      case CTL_K  :
      case KEY_BACKSPACE :   
        Backspace( pstMenu, iIndex );
        break;
      case 0x05 :    /* Ctrl + e */
        getyx( pstMenu->pwWin, iCurRow, iCurCol );
        if ( iCurCol < pstMenu->pstItem[ iIndex ].iCol +
                       pstMenu->pstItem[ iIndex ].iLength - 1 ) {
          wmove( pstMenu->pwWin, iCurRow, 
                 pstMenu->pstItem[ iIndex ].iCol +
                 pstMenu->pstItem[ iIndex ].iLength - 1);
        }
        else {
          beep();
        }
        break;
      case KEY_F(1) :
        CallHelp();
        break;
      case KEY_F(2) :
        iRc = ChkRtn(pstMenu, stEditList[ iIdx ].iIndex);
        /* iRc == 1 represents check ok !! */
        if (iRc != 1) {   /* still stay in the same field */
          iIndex = stEditList[ iIdx ].iIndex;
          MvEdtItem( pstMenu, iIndex, A_UNDERLINE );
        }
        else {
          UpdateData( pstMenu );
        }
        break;
      case ESC :  /* ESC */
        ProcessEscCmd( pstMenu, stEditList[ iIdx ].iIndex );
        break;
      default :
        AddCh( pstMenu, iIndex, iKeyIn, iInsert );
        break;
    }
  }
}
 
int AddCh( pstMenu, iIndex, iKeyIn, iInsert )
struct stMenu *pstMenu;
int iIndex;
int iKeyIn;
int iInsert;
{
  int i;
  int iMaxCol, iCurRow, iCurCol;
  char cCh;
  WINDOW *pwWin;

  pwWin = pstMenu->pwWin;
  iMaxCol = pstMenu->pstItem[ iIndex ].iCol +
            pstMenu->pstItem[ iIndex ].iLength;
  getyx( pwWin, iCurRow, iCurCol );
  if ( iCurCol < iMaxCol ) {
    wattron( pwWin, A_UNDERLINE );
    if (iInsert) {
      for (i = iMaxCol - 2; i >= iCurCol; i --) {
        cCh = mvwinch( pwWin, iCurRow, i );
        mvwaddch( pwWin, iCurRow, i + 1, cCh );
      }
      mvwaddch( pwWin, iCurRow, iCurCol, iKeyIn );
      wmove( pwWin, iCurRow, iCurCol );
    }
    else {
      waddch( pwWin, iKeyIn );
    }

    if ( iCurCol == iMaxCol - 1 ) {
      wmove( pwWin, iCurRow, iCurCol );
      beep();
    }
    wattroff( pstMenu->pwWin, A_UNDERLINE );
  }
}

int Undo( pstMenu, iIndex )
struct stMenu *pstMenu;
int iIndex;
{
  int i;
  int iCurRow, iCurCol, iMaxCol;
  char caData[ MAX_DATA_LEN ];
  struct stItem *pstItem;
  WINDOW *pwWin;

  pwWin = pstMenu->pwWin;
  pstItem = (struct stItem *)&(pstMenu->pstItem[ iIndex ]);
  iCurRow = pstItem->iRow;
  iCurCol = pstItem->iCol;
  iMaxCol = iCurCol + pstItem->iLength - 1;
  strncpy( caData, pstItem->caData, pstItem->iLength );
  caData[ pstItem->iLength ] = '\0';
  wattron( pwWin, A_UNDERLINE );
  mvwaddstr( pwWin, iCurRow, iCurCol, caData );
  getyx( pwWin, iCurRow, iCurCol );
  if (iCurCol < iMaxCol) {
    for (i = iCurCol; i <= iMaxCol; i ++) {
      mvwaddch( pwWin, iCurRow, i, ' ' );
    }
  }
  wmove( pwWin, iCurRow, pstItem->iCol );
  wattroff( pwWin, A_UNDERLINE );
}

int ProcessEscCmd( pstMenu, iIndex )
struct stMenu *pstMenu;
int iIndex;
{
  int iKeyIn;
  int iRc;

  /* get key and process */
  iKeyIn = wgetch(pstMenu->pwWin);
  switch( iKeyIn ) {
    case '\x1b' :
      EndTool( pstMenu );
      break;
    case '1' :     /* has the same function as F1 key if F1 key is disable */
      CallHelp();
      break;
    case '2' :     /* has the same function as F2 key if F2 key is disable */
      iRc = ChkRtn(pstMenu, iIndex);
      /* iRc == 1 represents check ok !! */
      if (iRc == 1) {   /* still stay in the same field */
        UpdateData( pstMenu );
        MvEdtItem( pstMenu, iIndex, A_UNDERLINE );
      }
      break;
  }
}

int Interrupt()
{
  endwin();
  exit( 1 );
}

int SrhFirstEdtItem( pstMenu, piIndex )
struct stMenu *pstMenu;
int *piIndex;
{
  int i;
  int iCurRow, iCurCol;
  int iMinRow, iMinCol;

  iMinRow = LINES;
  iMinCol = COLS;
  *piIndex = -1;

  for (i = 0; i < NO_ITEM; i ++ ) {
    iCurRow = pstMenu->pstItem[ i ].iRow;
    iCurCol = pstMenu->pstItem[ i ].iCol;
    if (pstMenu->pstItem[ i ].cAttribute == 'e') {
      if (iCurRow < iMinRow) {
        iMinRow = iCurRow;
        iMinCol = iCurCol;
        *piIndex = i;
      }
      else if (iCurRow = iMinRow) {
        if (iCurCol < iMinCol) {
          iMinCol = iCurCol;
          *piIndex = i;
        } 
      }  /* end else */
    } /* end if */
  } /* end for */
}

int MvEdtItem( pstMenu, iIndex, iAttr )
struct stMenu *pstMenu;
int iIndex;
int iAttr;  /* terminal attribute */
{
  int i;
  int iCurRow, iCurCol;
  int iLength;
  char cCh;
  WINDOW *pwWin;
  struct stItem *pstItem;

  pstItem = (struct stItem *)&(pstMenu->pstItem[ iIndex ]);
  iCurRow = pstItem->iRow;
  iCurCol = pstItem->iCol;
  iLength = pstItem->iLength;
  pwWin = pstMenu->pwWin;

  wattron( pwWin, iAttr );

  for (i = 0; i < iLength; i ++) { 
    cCh = mvwinch( pwWin, iCurRow, iCurCol + i );
    mvwaddch( pwWin, iCurRow, iCurCol + i, cCh );
  }
  wmove( pwWin, iCurRow, iCurCol );

  wattroff( pwWin, iAttr );
}

int BuildEdtList( pstMenu, pstEditList, piNoEditItem )
struct stMenu *pstMenu;
struct stEditItem *pstEditList;
int *piNoEditItem;
{
  int Compare();
  int i, j;

  for (i = 0, j = 0; i < NO_ITEM; i ++) {
    if (pstMenu->pstItem[ i ].cAttribute == 'e') {
      pstEditList[ j ].iIndex = i;
      pstEditList[ j ].iRowCol = pstMenu->pstItem[ i ].iRow * 100 +
                                 pstMenu->pstItem[ i ].iCol; 
      j ++;
    }
  }

  *piNoEditItem = j;

  qsort( (char *) pstEditList, *piNoEditItem, 
         sizeof( struct stEditItem ), Compare );
}

int Compare( pstEditItem1, pstEditItem2 )
struct stEditItem *pstEditItem1;
struct stEditItem *pstEditItem2;
{
  if ( pstEditItem1->iRowCol < pstEditItem2->iRowCol ) {
    return( -1 );
  }
  else if ( pstEditItem1->iRowCol == pstEditItem2->iRowCol ) {
    return( 0 );
  }
  else
    return( 1 );
}

int DeleteCh( pstMenu, iIndex )
struct stMenu *pstMenu;
int iIndex;
{
  int i;
  int iMaxCol, iCurRow, iCurCol;
  char cCh;

  iMaxCol = pstMenu->pstItem[ iIndex ].iCol +
            pstMenu->pstItem[ iIndex ].iLength;
  getyx( pstMenu->pwWin, iCurRow, iCurCol );
  wattron( pstMenu->pwWin, A_UNDERLINE );
  for (i = iCurCol + 1; i <= iMaxCol; i ++) {
    cCh = mvwinch( pstMenu->pwWin, iCurRow, i );
    mvwaddch( pstMenu->pwWin, iCurRow, i - 1, cCh );
  }
  wattroff( pstMenu->pwWin, A_UNDERLINE );
  wmove( pstMenu->pwWin, iCurRow, iCurCol );
}

int Backspace( pstMenu, iIndex )
struct stMenu *pstMenu;
int iIndex;
{
  int i;
  int iMaxCol, iCurRow, iCurCol;
  char cCh;

  iMaxCol = pstMenu->pstItem[ iIndex ].iCol +
            pstMenu->pstItem[ iIndex ].iLength;
  getyx( pstMenu->pwWin, iCurRow, iCurCol );
  if ( iCurCol == pstMenu->pstItem[ iIndex ].iCol ) {
    beep();
  }
  else {
    wattron( pstMenu->pwWin, A_UNDERLINE );
    for (i = iCurCol; i <= iMaxCol; i ++) {
      cCh = mvwinch( pstMenu->pwWin, iCurRow, i );
      mvwaddch( pstMenu->pwWin, iCurRow, i - 1, cCh );
    }
    wattroff( pstMenu->pwWin, A_UNDERLINE );
    wmove( pstMenu->pwWin, iCurRow, iCurCol - 1 );
  }
}

int CallHelp()
{
}

int
ChkRtn(pstMenu,iItmidx)
struct stMenu *pstMenu;
int    iItmidx;
{
  struct stItem *pstItem;
  char   caTmpBuf[30],cChar;
  int    i,j,iRc ;
  int    iCurRow,iCurCol;
  int    iLength;
  WINDOW *pwWin;

    pwWin = pstMenu->pwWin;
    pstItem = pstMenu->pstItem;
    getyx( pwWin, iCurRow, iCurCol );

    iCurCol = pstItem[ iItmidx ].iCol;
    iLength = pstItem[ iItmidx ].iLength;
    /* copy screen's data to buffer */
    for (j = 0; j < iLength; j ++) {
      caTmpBuf[j] = mvwinch( pwWin, iCurRow, iCurCol + j );
    }

    caTmpBuf[ pstMenu->pstItem[ iItmidx ].iLength ] = '\0';

    if ( (*pstMenu->pstItem[ iItmidx ].Routine2) == NULL) {
      ShowMsg(pstMenu,23,25, "                                  ");
      return(1);
    }

    iRc = (*pstMenu->pstItem[ iItmidx ].Routine2)(caTmpBuf); 

    if ( iRc != 1 )  {   /* return code == 1 represents TRUE */
      ShowMsg(pstMenu,23,25, "Field Check Error!!");
      printf("\a\a\a");
    }
    else {
      ShowMsg(pstMenu,23,25, "                                  ");
    }

    wmove(pwWin, iCurRow, iCurCol);
    return(iRc);
}


int
DateValid(pcaDate_List)
char  *pcaDate_List ;
{
   /*  this procedure perform a date validation.                     */
       char   *C_String();
       char   caShowBuf[80];
       char   caTmpYear[4];
       char   caBaseYear[5];
       int  iDays  ,
            iMonth ,
            iYear  ;
       int  i;
       int iDateLen;

       iDateLen = strlen(pcaDate_List);

       if (iDateLen != 8) {
         return(FALSE);  /* Invalid date length */
       }

       for (i=0; i<8; i++) {
         if (pcaDate_List[i] < '0' || pcaDate_List[i] > '9') {
           return(FALSE);  /* Invalid chars in the Date_List */
         }
       }

       iDays  = atoi(C_String(pcaDate_List + DAYS_OFFSET, 2)) ;
       iMonth = atoi(C_String(pcaDate_List + MNTH_OFFSET, 2)) ;
       iYear  = atoi(C_String(pcaDate_List + YEAR_OFFSET, 4)) ;

       if (g_iBaseYear != 0) {   /* add the base year to the pcaDate_List */
         iYear = iYear + g_iBaseYear;
       }

       if (iYear % 4 == 0 && iYear % 100 != 0 || iYear % 400 == 0) {
         iaMax_Days[2]=29;       /* this iYear is leap iYear. */
       } else {
         iaMax_Days[2]=28;       /* this iYear is normal iYear. */
       }

       if ( iMonth >=1 && iMonth <= 12 &&
            iDays  >=1 && iDays  <= iaMax_Days[iMonth]) {
         return(TRUE);
       }
       else {
         return(FALSE);
       }

}

char
*C_String(pcaChar_List,iN_char)
char  *pcaChar_List ;
int   iN_char     ;                        
{
   /*  this procedure can pack character at most 12 chars.           */
       static char  scaChar_String[14] ;


       if (iN_char <= 12) {
          strncpy(scaChar_String,pcaChar_List,iN_char) ;
          scaChar_String[iN_char] = '\0' ;
       }

       return(scaChar_String) ;
}

ShowMsg(pstMenu,iY,iX,pcaShowStr)
struct stMenu *pstMenu;
int    iY;
int    iX;
char   *pcaShowStr;
{
   char caFiller[60];
   int  iSpaceFlag=1;
   int  i;

   for (i=0;i<10;i++) {
     if (pcaShowStr[i] != ' ') {
       iSpaceFlag = 0;
       break;
     }
   }

   memset(caFiller,' ',60);
   caFiller[59] = '\0';
   wattron(pstMenu->pwWin,A_NORMAL);
   mvwaddstr(pstMenu->pwWin, iY, iX, caFiller);
   wattroff(pstMenu->pwWin,A_NORMAL);
 
   if (iSpaceFlag == 0) {
     wattron(pstMenu->pwWin,A_BLINK|A_REVERSE);
     mvwaddstr(pstMenu->pwWin, iY, iX, pcaShowStr);
     wattroff(pstMenu->pwWin,A_BLINK|A_REVERSE);
   }
}

/****************AUXILIARY FUNCTIONS ******************************/

itoa(n,s)
char *s;
int n;
{
     int i;
     i=0;
     do  {
         *(s+i) = n % 10 + '0';
         i++;
     }   while ((n /= 10) >0);
     *(s+i) = '\0';
     reverse(s);
}

itoa1(n,s,len)
int n,len;
char *s;
{
 int i,j;

 itoa(n,s);
 i=strlen(s);
 if (i == len) {
   return(0);
 }
 else {
   for ( j=i; j >= 0; j-- )
     s[len-i+j]=s[j];
   while ( (len-i+j) >= 0 ) {
     s[len-i+j]='0';
     j--;
   }
 }
}

reverse(s)
char *s;
{
     int   i, j;
     char  c;

     for (i = 0, j = strlen(s) - 1 ; i < j ; i++, j--) {
          c = *(s+i);
          *(s+i) = *(s+j);
          *(s+j) = c;
     }
}


TestChk (char *pTestMode)
{
   char caTmpBuf [10];
   int  i;

   memset (caTmpBuf, 0, sizeof(caTmpBuf));
   for (i=0; i<7; i++)
       caTmpBuf [i] = toupper(pTestMode [i]);

   if (strncmp(caTmpBuf, "PRODUCT", 7) == 0)
      return (TRUE);
   else
   if (strncmp(caTmpBuf, "TEST   ", 7) == 0)
      return (TRUE);
   else
   if (strncmp(caTmpBuf, "DEBUG  ", 7) == 0)
      return (TRUE);
   else
      return (FALSE);
}

