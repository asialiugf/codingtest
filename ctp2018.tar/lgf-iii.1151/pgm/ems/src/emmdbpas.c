/*
=============================================================================
=  Program: emmcode.c                                                       =
=  Author:  Tso-Chih Chou                                                   =
=  Date:    September 11, 1996                                              =
=============================================================================
*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <errno.h>
#include "errlog.h"

#define  P_ENCODE      12000
#define  DELIMITER     " \t=;"
#define  MAX_CODE_LEN  256

FILE *pFpin, *pFpout;

extern int  errno;
extern char *sys_errlist[];

main()
{
  int   i=0, iRc, iLine, iTPE_DBPW_Flag=0;
  char  caFile1[81], caFile2[81];
  char  ch, *pcaToken;
  char  caPass1 [MAX_CODE_LEN], caPass2 [MAX_CODE_LEN];
  char  caPass [MAX_CODE_LEN], caPassCode [MAX_CODE_LEN];
  char  caBuf [MAX_CODE_LEN], caTmpBuf [MAX_CODE_LEN];

  UCP_TRACE (P_ENCODE);

  memset (caPass, 0, sizeof(caPass));
  memset (caPassCode, 0, sizeof(caPassCode));
  memset (caBuf, 0, sizeof(caBuf));
  memset (caTmpBuf, 0, sizeof(caTmpBuf));

  while (1)
  {
    system ("clear");
    printf ("==============================================================\n");
    printf ("=                                                            =\n");
    printf ("=       << TPE Encryption Tool For DBMS Password >>          =\n");
    printf ("=                                                            =\n");
    printf ("==============================================================\n");
    printf ("\n\n");

    strcpy (caPass1, (char *)getpass("Password : "));
    strcpy (caPass2, (char *)getpass("Confirm Password : "));

    if (strcmp (caPass1, caPass2) == 0)
       break;
    else
    {
      printf ("\n");
      printf ("The confirmation password does not match!\n");
      printf ("The password has not been changed.\n");
      printf ("Press any key to try again...  ");
      getchar ();
    }
  } 
  
  strcpy (caPass, caPass1);
  encode (caPass, caPassCode);

  sprintf (caFile1, "%s/.profile", (char *) getenv("III_DIR"));
  sprintf (caFile2, "%s/.profile.tmp", (char *) getenv("III_DIR"));

  iRc = chmod (caFile1, S_IRUSR|S_IWUSR|S_IRGRP|S_IWGRP);
  if (iRc != 0)
  {
    sprintf (g_caMsg, "<EMS> Failure to chmod file \'%s\'! (errno:%d => %s)\n", 
             caFile1, errno, sys_errlist[errno]);
    printf ("%s", g_caMsg);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("The encryption for DBMS password is aborted!\n");
    UCP_TRACE_END (-1);
  }

  pFpin = fopen (caFile1, "r");
  if (pFpin == NULL)
  {
    sprintf (g_caMsg, "Failure to open %s! (errno:%d=>%s)\n",
             caFile1, errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("%s", g_caMsg);
    printf ("The encryption for DBMS password is aborted!\n");
    UCP_TRACE_END (-1);
  }

  pFpout = fopen (caFile2, "w");
  if (pFpout == NULL)
  {
    sprintf (g_caMsg, "Failure to open %s! (errno:%d=>%s)\n",
             caFile2, errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("%s", g_caMsg);
    printf ("The encryption for DBMS password is aborted!\n");
    UCP_TRACE_END (-1);
  }

  fgets (caBuf, sizeof(caBuf), pFpin);

  iLine = 0;
  do 
  {
    strcpy (caTmpBuf, caBuf);

    pcaToken = (char *)strtok (caBuf, DELIMITER);

    if (pcaToken != NULL)
    {
      errno = 0;
      if (strncmp (pcaToken, "TPE_DBPW", 7) == 0)
      {
         sprintf (g_caMsg, "TPE_DBPW=%s;  export TPE_DBPW\n", caPassCode);
         fprintf (pFpout, "%s", g_caMsg);
         ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
         iTPE_DBPW_Flag = 1;
      }
      else
        fprintf (pFpout, "%s", caTmpBuf);
    }

    iLine++;
    
    fgets (caBuf, sizeof(caBuf), pFpin);

  } while (!feof(pFpin));

  if (iTPE_DBPW_Flag == 0)
  {
     sprintf (g_caMsg, "TPE_DBPW=%s;  export TPE_DBPW\n", caPassCode);
     fprintf (pFpout, "%s", g_caMsg);
     ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
  }   

  fprintf (pFpout, "TPE_DBPW_CRYPT=YES;  export TPE_DBPW_CRYPT");
    
  fclose (pFpin);
  fclose (pFpout);

  memset (caBuf, 0, sizeof(caBuf));
  sprintf (caBuf, "mv %s/.profile %s/.profile.old", 
           (char *) getenv("III_DIR"), (char *) getenv("III_DIR") );
  iRc = system (caBuf);
  if (iRc != 0)
  {
    sprintf (g_caMsg, "Failure to execute \'%s\'!\n", caBuf);
    printf ("%s", g_caMsg);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("The encryption for DBMS password is aborted!\n");
    UCP_TRACE_END (-1);
  }

  memset (caBuf, 0, sizeof(caBuf));
  sprintf (caBuf, "mv %s/.profile.tmp %s/.profile",
           (char *) getenv("III_DIR"), (char *) getenv("III_DIR") );
  iRc = system (caBuf);
  if (iRc != 0)
  {
    sprintf (g_caMsg, "Failure to execute \'%s\'!\n", caBuf);
    printf ("%s", g_caMsg);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("The encryption for DBMS password is aborted!\n");
    sprintf (caBuf, "mv %s/.profile.old %s/.profile",
             (char *) getenv("III_DIR"), (char *) getenv("III_DIR") );
    iRc = system (caBuf);
    UCP_TRACE_END (-1);
  }

  printf ("\nEncryption for DBMS password succeeds!\n");
  printf ("Please logout and then login to effect the change!\n");

  UCP_TRACE_END (0);
}

