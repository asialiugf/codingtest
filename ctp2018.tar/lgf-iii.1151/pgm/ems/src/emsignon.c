#include "cwa.h"
#include "errlog.h"

#define  TXN_ONLINE_MODE  0x0efff  /* TCC: 1996/07/22 */

/*
 *&N& ROUTINE NAME: SignonCenter
 *&A& ARGUMENTS:
 *&A&    none   
 *&R& RETURN VALUE(S):
 *&R&    int
 *&D& DESCRIPTION:
 *&D*      When the Branch open TPE system, it has to signon to the
 *&D*      Center Host to get some informations it need.
 *&D*      Like the Txndate, Next Business Date, Next Next Business Date
 *&D*      Des Encryp Key....
 *&D*      This Program will open to the user to transmit the data they
 *&D*      want to exchange with the Center. This program will combinate
 *&D*      another program (          ) on the host to talk each other.
 *&D*      So the user has to code these two programs coordinately.
 */

struct SifHeader {
  char caTxnCode[4];
  char caTextId[6];
  char caBrhId[10];
  char caTermId[4];
  char caTellerId[4];
  char caFiller[20];
  char cLineno;
  char caStatus[2];
};

struct SofHeader {
  char caFmh[3];
  char caBrhId[10];
  char caTermId[4];
  char cOutDev;
  char caFormId[7];
  char caStatus[2];
  char caLength[2];
};

#define  P_SignonCenter         11112
#define  SYSTEM_RESTART         0x4000 /* 1:restarted ; 0:Normal Begin */
#define  ONLINE_CLOSE           0x0400 /* 1:Batch ; 0:On_line        */
#define  PESUDO_HOST            "0000000000"
#define  DEST_NAME_LEN		10
#define  SIF_HEAD_LEN	 	51
#define  SOF_HEAD_LEN	 	29
#define  MAX_LENGTH             4000

/* for the DCS return status's return code */
#define  NO_SUCH_BRHCODE        -1
#define  STARTDATE_ILLIGAL      -2
#define  OVERFLOW_DATE          -3
#define  CALFILE_NOEXIST        -4
#define  CALFILE_READ_ERR       -5
#define  OTHER_ERR              -6
#define  LESS_30                -7
#define  RETURN_CODE_ERR        -8
#define  CENTER_NOT_OPEN        -9
#define  TTY_NOT_DEFINED        -10
#define  GET_CENTER_DESKEY_ERR  -28

#define  GET_SSA_PTR_ERR        -23
#define  GET_BIT_PTR_ERR        -24

extern int g_iFirstRun;

/* added by Hu Chunlin BEGIN */
extern char g_cCenterSysStatus;
/* added by Hu Chunlin END */

int
SignonCenter()
{
  struct SifHeader  stSifh;
  struct SofHeader  stSofh;
  int    iRc;
  struct CwaCtl stCwaCtl;
  struct BrhArea   stBrhArea;
  struct SSA *pstSsa;
  char   *pcaBitTbl;
  char   *pcaBrhBgAddr;
  char   caDesCode[10];
  char   caTmpDate[8];
  char   caSif[MAX_LENGTH];
  char   caSof[MAX_LENGTH];
  int    iSifLen,iSofLen;
  int    iBrhOffset;
  int    iOffset;
  char   caDate[9];
  char   caNextBusi[8];
  char   *pcaNxtDate;
  short  sStatus;
  unsigned char   cRc;
  int    iLess30=0;
  int    iFirst=1;
  char   caErrCode [7];
  int    iErrCode=0;
 
  UCP_TRACE(P_SignonCenter);

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);
  if (iRc != 0) {
    UCP_TRACE_END(GET_SSA_PTR_ERR);
  }

  pstSsa->sSysStatus &= TXN_ONLINE_MODE;  /* TCC: 1996/07/22 */
  sStatus =  pstSsa->sSysStatus;

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_BIT_START;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcaBitTbl);
  if (iRc != 0) {
    UCP_TRACE_END(GET_BIT_PTR_ERR);
  }

/*  4 bytes reserved for Branch Total Cnt    */
/*  4 bytes reserved for next available addr */  
  pcaBrhBgAddr = pcaBitTbl + 8; 
  memcpy(&stBrhArea,pcaBrhBgAddr,sizeof(struct BrhArea));

  do 
  {
    memset(caSif,'\0',MAX_LENGTH);
    memset(caSof,'\0',MAX_LENGTH);
    memset (&stSifh, 0, sizeof(struct SifHeader));
    memset (&stSifh, 0, sizeof(struct SofHeader));

    /* prepare SIF */
    /* TCC 1995/11/23 */
    /* First, Get CWA TxnDate from Center TPE */
    if (iFirst == 1)
    {
      memcpy (stSifh.caFiller, CWA_GET_CENTER_TXN_DATE, \
              sizeof(CWA_GET_CENTER_TXN_DATE)); 
      /*
      ErrLog (10, "<EMS> Ready to get CWA transaction dates from Center", 
              RPT_TO_LOG, 0, 0);
      */
    }
    else
    {
      memcpy (stSifh.caBrhId, stBrhArea.caBrhId, sizeof(stBrhArea.caBrhId));
      sprintf (g_caMsg, 
            "<EMS> Ready to get transaction date for branch [%s] from center", 
            stSifh.caBrhId);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    }

    memcpy(caDesCode, PESUDO_HOST, DEST_NAME_LEN);
    memcpy(caSif, &stSifh, SIF_HEAD_LEN);
    iSifLen = SIF_HEAD_LEN;
    iSofLen = 0;  /* TCC: 1996/07/22 */

    iRc = SdSifRvSof(caDesCode, caSif, iSifLen, caSof, &iSofLen);
    if (iRc != 0) {
       sprintf(g_caMsg,"<EMS> Failure to signon center! (error:%d)",iRc);
       ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
       UCP_TRACE_END(iRc);
    }

    /* TCC 1995/11/10 Begin */
    sprintf(g_caMsg,
            "<EMS> SIF to get CWA transaction dates from center for branch:");
    ErrLog(10,g_caMsg,RPT_TO_LOG,caSif,iSifLen);

    sprintf(g_caMsg,
            "<EMS> SOF for transaction dates from center:");
    ErrLog(10,g_caMsg,RPT_TO_LOG,caSof,iSofLen);
    /* TCC 1995/11/10 End */

    /* parser SOF */
    memcpy(&stSofh,caSof,SOF_HEAD_LEN);
    cRc = stSofh.caStatus[0];
    switch (cRc) {
      case '0': 
        break;
      case '1': 
        UCP_TRACE_END(NO_SUCH_BRHCODE);
      case '2': 
        UCP_TRACE_END(STARTDATE_ILLIGAL);
      case '3': 
        UCP_TRACE_END(OVERFLOW_DATE);
      case '4': 
        UCP_TRACE_END(CALFILE_NOEXIST);
      case '5': 
        UCP_TRACE_END(CALFILE_READ_ERR);
      case '6': 
        UCP_TRACE_END(OTHER_ERR);
      case '7': 
        iLess30 = 1;
        break;
      case '8':
        UCP_TRACE_END(GET_CENTER_DESKEY_ERR);
      /* TCC 1995/11/23 */
      case 0x88:
          /*
          ErrLog (10, "SignonCenter: Sof 0x88", 
                  RPT_TO_LOG, &stSofh.caFormId, 7);
          */
          if ( memcmp(&stSofh.caFormId[3], "F7", 2) == 0 )
          {   
            memset (caErrCode, 0, sizeof(caErrCode));
            memcpy (caErrCode, &stSofh.caFormId[4], 3);
            iErrCode = atoi(caErrCode) * (-1);
            sprintf (g_caMsg, "<EMS> Pseudio ErrCode: [%d]", iErrCode);
            ErrLog (10, g_caMsg, RPT_TO_LOG, 0, 0);
            UCP_TRACE_END (iErrCode);
          }

          UCP_TRACE_END(RETURN_CODE_ERR);

      default:
        if ( memcmp(stSofh.caFormId,"ZE01",4) == 0) {
          UCP_TRACE_END(TTY_NOT_DEFINED);
        }
        else if ( memcmp(stSofh.caFormId,"ZE02",4) == 0) {
          UCP_TRACE_END(CENTER_NOT_OPEN);
        }
        else {
          UCP_TRACE_END(RETURN_CODE_ERR);
        }
    }
   
    /* TCC 1995/11/23 Begin */
    if (iFirst == 1)
    {
      memcpy (pstSsa->caTxnDate, caSof+SOF_HEAD_LEN, 8);
      memcpy (pstSsa->caNextDate, caSof+SOF_HEAD_LEN+8, 8);
      memcpy (pstSsa->caNext2Date, caSof+SOF_HEAD_LEN+16, 8);
      
      /* add by Hu Chunlin to get Center System Status. BEGIN */
      g_cCenterSysStatus = caSof[SOF_HEAD_LEN + 24];
      /* add by Hu Chunlin to get Center System Status. END   */

      iFirst = 0;
      /*
      ErrLog (10, "<COM> CWA TxnDate Updated", \
              RPT_TO_LOG, pstSsa->caTxnDate, 24);
      */
      continue;
    }
    /* TCC 1995/11/23 End */

#ifdef DESKEY
    iRc = UsrHandle(stBrhArea.caBrhId,caSof);
    if (iRc != 0) {
      UsrErrHdl(iRc);
      /* TCC 1996/11/07 */
      UCP_TRACE_END(GET_CENTER_DESKEY_ERR);
    }
    else
      ErrLog (10, 
              "<EMS> Get DESKEY from center successfully", RPT_TO_LOG, 0, 0); 
#endif
    
    iOffset = SOF_HEAD_LEN; 
/* the first 8 bytes is Txndate,the 2nd one is Next business day */
/* the 3rd one is the next next business day */
    memcpy(caTmpDate,caSof+iOffset,8);
    memcpy(stBrhArea.caTxnDate,caTmpDate,8);
    iOffset +=  8 ; 
    memcpy(caTmpDate,caSof+iOffset,8);
    memcpy(stBrhArea.caNxtTxnDate,caTmpDate,8);
    iOffset +=  8 ; 
    memcpy(caTmpDate,caSof+iOffset,8);
    memcpy(stBrhArea.caNNxtTxnDate,caTmpDate,8);

    memcpy(pcaBrhBgAddr,&stBrhArea,sizeof(struct BrhArea));
    pcaBrhBgAddr = pcaBitTbl + stBrhArea.iNxtBrhOffset;
    iBrhOffset = stBrhArea.iNxtBrhOffset;
    memcpy(&stBrhArea,pcaBrhBgAddr,sizeof(struct BrhArea));
  } while (iBrhOffset != -1) ;  /* not the last Brance node */

  if (iLess30 == 0) {
    UCP_TRACE_END(0);
  }
  else {
    UCP_TRACE_END(LESS_30);
  }
}

#ifdef DESKEY
int
UsrHandle(pcaBrhId,pcaSof)
char  *pcaBrhId;
char  *pcaSof;
{
  int  iRc;
  int  iOffset;
  unsigned char caRc[3];
  unsigned char caKeyBuf[8];

  DESINIT(caRc);

  if ( strncmp(caRc,"00",2) != 0 ) {
    caRc[2]='\0';
    iRc = atoi(caRc);
    ErrLog (1000, "<EMS> Failure to execute DESINIT", RPT_TO_LOG, 0, 0);
    return(iRc);
  }
 
  iOffset = SOF_HEAD_LEN + 24;   /* begn from the 24th byte of the SOF */

  memcpy(caKeyBuf,pcaSof+iOffset,8);
  DESLDMKY(caRc,caKeyBuf);

  if ( strncmp(caRc,"00",2) != 0 ) {
    caRc[2]='\0';
    iRc = atoi(caRc);
    ErrLog (1000, "<EMS> Failure to execute DESLDMKY", RPT_TO_LOG, 0, 0);
    DESCLOSE(caRc);
    if ( strncmp(caRc, "00", 2) != 0) {
        ErrLog (1000, "<EMS> Failure to execute DESLDMKY & DESCLOSE!",
                RPT_TO_LOG, 0, 0);
    }
    return(iRc);
  }
  iOffset += 8;
  memcpy(caKeyBuf,pcaSof+iOffset,8);
  
  DESWRIKY(caRc,"MAC",pcaBrhId,caKeyBuf);

  if ( strncmp(caRc,"00",2) != 0 ) {
    caRc[2]='\0';
    iRc = atoi(caRc);
    ErrLog (1000, "<EMS> Faliure to execute DESWRIKY(MAC)", RPT_TO_LOG, 0, 0);
    DESCLOSE(caRc);
    if ( strncmp(caRc, "00", 2) != 0) {
        ErrLog (1000, "<EMS> Failure to execute DESWRIKY(MAC) & DESCLOSE",
                RPT_TO_LOG,0,0);
    }
    return(iRc);
  }
  iOffset += 8;
  memcpy(caKeyBuf,pcaSof+iOffset,8);
  
  DESWRIKY(caRc,"PPK",pcaBrhId,caKeyBuf);

  if ( strncmp(caRc,"00",2) != 0 ) {
    caRc[2]='\0';
    iRc = atoi(caRc);
    ErrLog (1000, "<EMS> Failure to execute DESWRIKY(PPK)", RPT_TO_LOG, 0, 0);
    DESCLOSE(caRc);
    if ( strncmp(caRc, "00", 2) != 0) {
        ErrLog (1000, "<EMS> Failure to execute DESWRIKY(PPK) & DESCLOSE",
                RPT_TO_LOG, 0, 0);
    }
    return(iRc);
  }
  
  DESCLOSE(caRc);

  if ( strncmp(caRc,"00",2) != 0 ) {
    caRc[2]='\0';
    iRc = atoi(caRc);
    ErrLog (1000, "<EMS> Failure to execute DESCLOSE", RPT_TO_LOG, 0, 0);
    return(iRc);
  }
  
  return(0);
}

UsrErrHdl(iErrCode)
int  iErrCode;
{
   int  i, iRc;
   char caOpt[128];

   switch(iErrCode) {
     case 1:
       EmsShowData('0',"DS01:Time Out(no card insert)!!\n");
       break;
     case 2:
       EmsShowData('0',"DS02:Time Out(no answer to reset)!!\n");
       break;
     case 3:
       EmsShowData('0',"DS03:Illegal answer to reset!!\n");
       break;
     case 4:
       EmsShowData('0',"DS04:No card present!!\n");
       break;
     case 5:
       EmsShowData('0',"DS05:Function key <Cancel> input!!\n");
       break;
     case 6:
       EmsShowData('0',"DS06:Magnetic card data error!!\n");
       break;
     case 7:
       EmsShowData('0',"DS07:Change PIN failed!!\n");
       break;
     case 8:
       EmsShowData('0',"DS08:ID code error!!\n");
       break;
     case 9:
       EmsShowData('0',"DS09:Not enough memory space!!\n");
       break;
     case 10:
       EmsShowData('0',"DS10:RAM error!!\n");
       break;
     case 11:
       EmsShowData('0',"DS11:DES module error!!\n");
       break;
     case 12:
       EmsShowData('0',"DS12:LCD module error!!\n");
       break;
     case 13:
       EmsShowData('0',"DS13:Data overrange!!\n");
       break;
     case 14:
       EmsShowData('0',"DS14:Access denied!!\n");
       break;
     case 15:
       EmsShowData('0',"DS15:Command was already executed!!\n");
       break;
     case 16:
       EmsShowData('0',"DS16:Security module was not initialized!!\n");
       break;
     case 17:
       EmsShowData('0',"DS17:PIN verifiaction failed!!\n");
       break;
     case 18:
       EmsShowData('0',"DS18:Memory error while updating;Key is unusable!!\n");
       EmsShowData('0',"    :or Key is unusable!!\n");
       break;
     case 19:
       EmsShowData('0',"DS19:Master Key is not present or is unusable or!!\n");
       EmsShowData('0',"    :Session Key was not generated!!\n");
       EmsShowData('0',"    :Illegal command sequence!!\n");
       break;
     default:
       EmsShowData('0',"DS20:Unknown Deskey handle error!!\n");
   }

   alarm(0);
   
   iRc = SaveCwaToFile();
   if (iRc != 0){
     sprintf (g_caMsg,"<EMS> Failure to save CWA to file");
     ErrLog (1000,g_caMsg,RPT_TO_LOG,0,0);
   }

   do
   {
     printf ("\nDo you want to change to OFFLINE mode? (yes/no) : ");
     gets (caOpt);

     for (i=0; ((caOpt[i] != 0) && (i<sizeof(caOpt))); i++)
         caOpt[i] = toupper (caOpt[i]);

   } while ((strcmp(caOpt, "YES") != 0) && (strcmp(caOpt, "NO") != 0));

   if (strcmp(caOpt, "NO") == 0)
   {
     iRc = EnvRelse();
     if ( iRc != 0 ) {
       ErrLog (1000,"<EMS> Failure to release TPE resources (chron/shm)!",
               RPT_TO_LOG,0,0);
       EmsShowData('0',"<EMs> Failure to release TPE resources!\n");
     }

     iRc = RmComponent();
     if (iRc != 0) {
       ErrLog (1000,"<EMS> Failure to remove TPE components!",
               RPT_TO_LOG, 0, 0);
       printf("<EMS> Failure to remove TPE components!\n");
     }
     exit(0);
   }

}
#endif
