/*
 *&N& ROUTINE NAME: main  
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&           
 *&R& RETURN VALUES:
 *&R&           
 *&R&           
 *&D& DESCRIPTION:           
 *&D&     ���{�����@���������A��,�i�� EMS �s�ΨӴ��� EMS FORK ���A�������p
 *&D&     �䤤���������� Destination Code �� 000psuserv 
 *&D&     
 */

#include "dcs.h"
int g_SessIdx;		/* keep serv Session index */
char g_cProtType;	/* keep serv use what Protocol type */
struct DcsBuf stDcsBuf;	/* call dcs module struct globl */
struct DcsSiof stDcsSiof;	/* call dcs module input/output struct globl */
int    Disconnect(int, char);
#define  PRC_NORMAL       '0'
#define  PRC_SHUTDOWN_OK  '4'

main(argc,argv)
int  argc;
char **argv;
{
  static char   scProtocol[80];
  int iRcvDataLen;
  int iStrCmdSize;
  int i,iRc;
  int iSessidx;
  struct MonCmd{	/* monitor accepted command structur */
         char caTblidx[5];/* number in table array of forked process */
         char cCmd;	/* commmand to monitor process */
       };
  struct MonCmd stMonCmd;

  struct FkdStat{
	 char caTblidx[5];
	 char cStatus;
  };
  struct FkdStat stFkdStat;

  if (argc < 2)
  {
    printf ("<Usage>  %s server_index\n", argv[0]);
    exit (-1);
  }

  strcpy(stFkdStat.caTblidx,argv[1]); 
  stFkdStat.cStatus =  PRC_NORMAL;
  
  /* get env III_PROTOCOL for protocol type */
  memset(scProtocol,'\0',80);
  strcpy((char *)scProtocol, (char *)getenv("III_PROTOCOL"));
  printf("read_input_data:scProtocol=%s\n",scProtocol); 
  if(scProtocol[0] != '\0') {
    g_cProtType = scProtocol[0];
  }
  else{
    g_cProtType = QUEUE_DCS;
  }
  printf ("Communication Protocol Type: %c\n", g_cProtType);

  /*   1.accept and read  */
  memcpy(McaDesCode(stDcsBuf),"00Monitor2",10);
  McRqstCode(stDcsBuf) = DCSCONNECTWRITE;
  stDcsSiof.cMoreByte  = '0';
  stDcsSiof.cKind      = '1';
  stDcsSiof.cProtoType = ' ';
  MiDataLen(stDcsBuf) = 8 + sizeof(struct FkdStat) ;
  sprintf(stDcsSiof.caDataLen,"%.5d",MiDataLen(stDcsBuf));   
  MpstDcsSiof(stDcsBuf) = &stDcsSiof;
  memcpy(McaData(stDcsBuf),&stFkdStat,sizeof(struct FkdStat));
  memcpy(McaServCode(stDcsBuf),"0000",4);
  MlWaiTime(stDcsBuf) = DCS_BLOCK;
  McProto(stDcsBuf) =  g_cProtType ; 
  DcsDispatch( &stDcsBuf );
  if(MiReply(stDcsBuf) != DCS_NORMAL)
  { 
    printf("WaitCmd:dcsacceptread reply %d errno %d\n", 
            MiReply(stDcsBuf),MiErrno(stDcsBuf)); 
    exit(-1);
  }

  iSessidx = MiSesIdx(stDcsBuf);

  iRc = Disconnect(iSessidx,g_cProtType);
  if (iRc < 0) {
    printf("psuserv: Disconnect() fails!");
    exit(-5);
  }
  printf("b4 read shutdown mesg:psuserv:Monitor2 iSessidx:%d\n",iSessidx);


    memcpy(McaDesCode(stDcsBuf),"000psuserv",10);
    McRqstCode(stDcsBuf) = DCSACCEPTREAD;
    MlWaiTime(stDcsBuf) = DCS_BLOCK;
    MiDataLen(stDcsBuf) = DCS_MAX_DATA_LEN;
    MpstDcsSiof(stDcsBuf) = &stDcsSiof;
    McProto(stDcsBuf) = g_cProtType;
    DcsDispatch(&stDcsBuf);
    if(MiReply(stDcsBuf) != DCS_NORMAL)
    {
      printf("psuserv:dcsacceptread reply %d errno %d",
              MiReply(stDcsBuf),MiErrno(stDcsBuf));
      exit(-2);
    }

    iRcvDataLen= MiDataLen(stDcsBuf) - 8  - 4;
    if(iRcvDataLen > sizeof(struct MonCmd) ){
      printf("psuserv:rcv cmd data reply %d errno %d",
              MiReply(stDcsBuf),MiErrno(stDcsBuf));
      exit(-2);
    }

    memcpy(stMonCmd.caTblidx,&McaData(stDcsBuf)[4],5);
    stMonCmd.cCmd = McaData(stDcsBuf)[9];
    printf("argv1=%s,%5s psuserv.x get,cmd=%c\n",argv[1],stMonCmd.caTblidx,stMonCmd.cCmd);
    iSessidx = MiSesIdx(stDcsBuf);


  strcpy(stFkdStat.caTblidx,argv[1]); 
  stFkdStat.cStatus =  PRC_SHUTDOWN_OK;
  McRqstCode(stDcsBuf) = DCSWRDISCONECT;
  stDcsSiof.cMoreByte  = '0';
  stDcsSiof.cKind      = '1';
  stDcsSiof.cProtoType = ' ';
  MiDataLen(stDcsBuf) = 8 + sizeof(struct FkdStat) ;
  MiSesIdx(stDcsBuf) = iSessidx;
  sprintf(stDcsSiof.caDataLen,"%.5d",MiDataLen(stDcsBuf));   
  MpstDcsSiof(stDcsBuf) = &stDcsSiof;
  memcpy(McaData(stDcsBuf),&stFkdStat,sizeof(struct FkdStat));
  memcpy(McaServCode(stDcsBuf),"0000",4);
  McProto(stDcsBuf) =  g_cProtType ; 
  DcsDispatch( &stDcsBuf );
  if(MiReply(stDcsBuf) != DCS_NORMAL)
  { 
    printf("WaitCmd:dcsacceptread reply %d errno %d\n", 
            MiReply(stDcsBuf),MiErrno(stDcsBuf)); 
    exit(-1);
  }
  printf("execute %s pesudo server OK!!\n",argv[1]);
  exit(0);
}

int
Disconnect(int iSessidx,char cProtocolType)
{
  static struct DcsBuf stDcsBuf;
  static struct DcsSiof stDcsSiof;

  McRqstCode(stDcsBuf) = DCSDISCONNECT;
  McProto(stDcsBuf) = cProtocolType;
  MiSesIdx(stDcsBuf) = iSessidx;
  MiDataLen(stDcsBuf) = 0;
  DcsDispatch(&stDcsBuf);
  if(MiReply(stDcsBuf) != DCS_NORMAL){
    printf("Disconnect:DCSDISCONNECT error reply %d errno %d",
                                    MiReply(stDcsBuf),MiErrno(stDcsBuf));
    return(-1);
  }
  printf("Disconnect:DCSDISCONNECT ok!\n");
  return(0);
}
