/*
 *&N& File : emsstart.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    void      GetCkDat()    ��~�餧���o�P�ˬd(CURSES & printf ��)
 *&N&                                     
 *&N&    void      Get_Wdata()   �����~�餧��J���(CURSES & printf ��)
 *&N&                                     
 *&N&    void      DisplayHead() �����~�餧��J��Ƥ����Y�e��(for CURSES��)
 *&N&                                     
 *&N&    int       Date_Valid()  
 *&N&              �ˬd��~�餧��J��ƬO�_�ŦX������W�h(CURSES & printf��)
 *&N&                                     
 *&N&    int       Txn_Date_Check()  
 *&N&              �ˬd��~�餧��J��Ƥ����T��(CURSES & printf��)         
 *&N&                                     
 *&N&   char(*)()  D_String()       �ഫYYYYMMDD��YYYY/MM/DD���r��    
 *&N&                                     
 *&N&   char(*)()  C_String()       ��YYYYMMDD����ݭn�����r��    
 *&N&                                     
 *&N&   void       Beep()           ���~ĵ�ܩI�s
 *&N&                                     
 *&N&   int        FindBit()        ��Bit Table���̲׺ݾ��W�ٴM����������e
 *&N&                                     
 *&N&   int        GetHostName()    ������׺ݾ��W��
 *&N&                                     
 *&N&   int (*)()  TxLogIni()       ����y���ɪ�l��
 *&N&                                     
 *&N&   int (*)()  SyStuIni()       �t�Ϊ��A��l��
 *&N&                                     
 *&N&   int (*)()  ShowRestInfo()   �ھڨt�Τ�������ܪ����O
 */

#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#ifdef   CURSES
#include <curses.h>
#endif
#include "errlog.h"
#include "emctldef.h"
#include "cwa.h"
#include "emcstart.h"
#include "emcpgdef.h"

#ifndef H_TMCENV
#define H_TMCENV
#define  CWA_SHM_KEY    "CWA_SHM_KEY"
#define  CTF_SHM_KEY    "CTF_SHM_KEY"
#define  ICT_SHM_KEY    "ICT_SHM_KEY"
#define  DBT_SHM_KEY    "DBT_SHM_KEY"
#define  IET_SHM_KEY    "IET_SHM_KEY"
#define  SYS_MODE       "SYSMODE"
#define  BASE_YEAR      "BASE_YEAR"
#endif
#define  SYSTEM_STARTED 0x8000 /* 1:started ; 0:not started */
#define  SYSTEM_RESTART 0x4000 /* 1:restarted ; 0:Normal Begin */
#define  REQUEST_ABEND  0x2000
#define  OFFLINE_MODE   0x1000
#define  OVER_TIME      0x0800
#define  ONLINE_CLOSE   0x0400 /* 1:Batch ; 0:On_line        */
#define  DEBUG_MODE     0x0200
#define  FILE_NAME_LEN  80
#define  CHINESE_TYPE   '1'
#define  ONLINE          0 
#define  BATCH           1

/* Key Definition */
#define  CTL_P           16
#define  CTL_N           14
#define  CTL_L           12
#define  CTL_R           18
#define  CTL_I            9
#define  CTL_H            8
#define  CTL_D            4
#define  CTL_U           21
#define  CR              13
#define  ESC             27
#define  ENTER           0x0797  

extern int g_iCwaKey;
extern int g_iCtfKey;
extern int g_iIctKey;
extern int g_iDbtKey;
extern int g_iIetKey;
extern int g_iSysOpMode;
extern int g_iTotTmNum;
extern int g_iBaseYear;
extern int g_iFirstRun;
extern char g_caIfVerName[10][20];
struct CWA  *pstCwa;

/*
 *&N& ROUTINE NAME: SysStart()
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&           
 *&R& RETURN VALUES:
 *&R& 
 *&R&           
 *&R&           
 *&D& DESCRIPTION:           
 *&D&     ����Ƭ��t�ζ}���B�z,�ھڨt�Ϊ��A�i��۹������}���B�z
 *&D&   1.��~����o�P�ˬd
 *&D&   2.�ˬd�t�ζ}�����A
 *&D&   3.����y���ɪ�l�B�z
 *&D&   4.�t�Ϊ��A��l��
 *&D&   5.�Ұʦ��A�{��
 *&D&           
 */


SysStart(char *pcErrStep)
{
  int    iRc;
  struct CwaCtl stCwaCtl;
  struct SSA *pstSsa;
  short  sStatus;       /* the system status  */

  UCP_TRACE(P_SysStart);

  *pcErrStep = '0';
  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);

  if (iRc != 0) {
    *pcErrStep = '1';
    UCP_TRACE_END(GET_SSA_PTR_ERR);
  }

  sStatus = pstSsa->sSysStatus;

/* Get the base year before the TXN day check  */
  g_iBaseYear = GetCnfValue( BASE_YEAR );

/*
  EmsShowData('0',"TRANSACTION DATE CHECK\n");
  iRc = GetCkDat();
  
  if (iRc != 0) {
    *pcErrStep = '2';
    UCP_TRACE_END(iRc);  
  }
*/

  if ( (!(sStatus & SYSTEM_RESTART)) && (!(sStatus & ONLINE_CLOSE)) ) {
    iRc = TxLogIni();

      if (iRc != 0) {
        *pcErrStep = '3';
        UCP_TRACE_END(iRc);
      }

    iRc = SyStuIni();

      if (iRc != 0) {
        *pcErrStep = '4';
        UCP_TRACE_END(iRc);
      }

  }

  EmsShowData('0',"Start to invoke the TPE servers.....\n");
  if ( !(sStatus & ONLINE_CLOSE) ) { 
    iRc = IsuSvPrs(ONLINE);    /* Online Processing */

    if (iRc != 0) {
      *pcErrStep = '5';
      UCP_TRACE_END(iRc);
    }
  }
  else {
    iRc = IsuSvPrs(BATCH);    /* Batch Processing */

    if (iRc != 0) {
      *pcErrStep = '5';
      UCP_TRACE_END(iRc);
    }
  }

  EmsShowData('0',"TPE servers have been invoked.\n");
  EmsShowData('1',"clear");
  EmsShowData('0',"The Current System Configuration are:\n");
  EmsShowData('0',"TPE kernel version 1.1.3\n");
  if ( !(sStatus & ONLINE_CLOSE) ) { 
    ShowRestInfo(ONLINE);
  }
  else {
    ShowRestInfo(BATCH);
  }
  EmsShowData('0',"TPE has been started up.\n");
  UCP_TRACE_END(0);  
}

#define  READ_DATA_ERR  -1
#define  OPEN_FILE_ERR  -2
#define  CLOSE_FILE_ERR  -3

int
TxLogIni()
{
  struct CwaCtl stCwaCtl;
  struct SSA *pstSsa;
  int  iRc;
  short sStatus;
  int  iLogFd;
  char caFlName[FILE_NAME_LEN];

  UCP_TRACE(P_TxLogIni);

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);

  if (iRc != 0) {
    UCP_TRACE_END(GET_SSA_PTR_ERR);
  }

  sStatus = pstSsa->sSysStatus;
  
  if ( !(sStatus & ONLINE_CLOSE) && !(sStatus & SYSTEM_RESTART)) {
 
    memset(caFlName,'\0',FILE_NAME_LEN);
    strcpy(caFlName,(char *) getenv("III_DIR"));
    strcat(caFlName,(char *) "/");
    strcat(caFlName,SBBSLOG_F);

    iLogFd = open(caFlName, O_RDWR+O_CREAT+O_TRUNC+O_APPEND,00666);
    if (iLogFd < 0) {
      sprintf(g_caMsg,"Open LOG_FILE = [%s] error,errno = %d",caFlName,errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      sprintf(g_caMsg,"CtfBuild() : Can't open %s ,errno = %d",caFlName,errno);
      DetErrRpt(OPEN_FILE_ERR,g_caMsg);
      UCP_TRACE_END(OPEN_LOGFILE_ERR);
    }

    if ( close(iLogFd) != 0) {
      sprintf(g_caMsg,"Close LOG_FILE = [%s] error,errno = %d",caFlName,errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      sprintf(g_caMsg,"CtfBuild() : Can't close %s ,errno = %d",caFlName,errno);
      DetErrRpt(CLOSE_FILE_ERR,g_caMsg);
      UCP_TRACE_END(CLOSE_LOGFILE_ERR);
    }
  }
    UCP_TRACE_END(0);
}

int
SyStuIni()
{
  struct CwaCtl stCwaCtl;
  struct SSA *pstSsa;
  int  iRc;
  char cStatus; 

  UCP_TRACE(P_SyStuIni);

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);

  if (iRc != 0) {
    UCP_TRACE_END(GET_SSA_PTR_ERR);
  }

  pstSsa->cFrontLineStatus = '0';
  memset(pstSsa->caPrevTxnLogRrn,'0',5); 
  memset(pstSsa->caPrevBtefRrn,'0',5); 
  memset(pstSsa->caLastRrnInBeft,'0',5); 
  pstSsa->lTotalTxnCnt = 0;
  pstSsa->lNextAvLogRrn = 1;
  UCP_TRACE_END(0);
}

#define  DATE_LEN      8
#define  DAYS_OFFSET   6  /* YYYYMMDD  */
#define  MNTH_OFFSET   4  /* YYYYMMDD  */
#define  YEAR_OFFSET   0  /* YYYYMMDD  */
#define  TRUE          1
#define  FALSE         0
#define  MAX_DATW      3
int      iaMax_Days[13] = {  0, 31, 28, 31, 30, 31, 30,
                                   31, 31, 30, 31, 30, 31} ;
#ifndef CURSES
int
GetCkDat()
{
  int    iTct_Cnt;
  char   *D_String();
  char   *pfTty_Code();
  char   caKey_Buf[81];
  char   caTmp_Buf[80];
  char   caShowBuf[80];
  int    iKey_Len;
  int    iRc;
  int    iDate_Chk_No;
  int    iDate_Win_No;
  struct SSA *pstSsa;
  struct CwaCtl stCwaCtl;
  struct TermArea  stTmArea;
  FILE   *zFp,*fopen();
  char   caFlName[FILE_NAME_LEN];
  short  sStatus;

  UCP_TRACE(P_GetCkDat);

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);

  if (iRc != 0) {
    UCP_TRACE_END(GET_SSA_PTR_ERR);
  }

  sStatus = pstSsa->sSysStatus;

  iRc = FindBit(&stTmArea);
  if (iRc != 0) {
    UCP_TRACE_END(FIND_BIT_ERR);
  }


  memset(caFlName,'\0',FILE_NAME_LEN);
  strcpy(caFlName,(char *) getenv("III_DIR"));
  strcat(caFlName,(char *) "/");
  if (stTmArea.cTermType == CHINESE_TYPE) {
    strcat(caFlName,TXNDAT_C);
  }
  else  {
    strcat(caFlName,TXNDAT_E);
  }

  zFp = fopen(caFlName,"r");
  if (zFp == NULL) {
    ErrLog(1000,g_caMsg,RPT_TO_TTY|RPT_TO_LOG,0,0);
    sprintf(g_caMsg,"LoadTct : Can't open txndate input errno = %d",errno);
    DetErrRpt(OPEN_FILE_ERR,g_caMsg);
    UCP_TRACE_END(OPEN_TXNDATE_ERR);
  }
 
  signal(SIGCLD, SIG_IGN);
  system("clear");

  while ( fgets(caTmp_Buf,80,zFp) != NULL ){
    EmsShowData('0',caTmp_Buf);
    EmsShowData('0',"\n");
  }

  fclose(zFp);

  if ( !(sStatus & SYSTEM_RESTART) ) {  
    EmsShowData('0',"System Status:NORMAL\n");
    EmsShowData('0',"\n");
  }
  else  {
    EmsShowData('0',"System Status:RESTART\n");
    EmsShowData('0',"\n");
  }
    
  if ( !(sStatus & ONLINE_CLOSE) ) { 
    EmsShowData('0',"Operating Mode:ONLINE\n");
    EmsShowData('0',"\n");
  }
  else  {
    EmsShowData('0',"Operating Mode:BATCH\n");
    EmsShowData('0',"\n");
  }
  memset(caTmp_Buf,'\0',80);
  memcpy(caTmp_Buf,&(pstSsa->caTxnDate[0]),8);

  sprintf(caShowBuf,"Date : %s\n",D_String(caTmp_Buf));
  EmsShowData('0',caShowBuf);

  iDate_Chk_No = -1;
  iDate_Win_No = -1;

  do {
    iDate_Win_No ++;
    Get_Wdata(iDate_Win_No,DATE_LEN,caKey_Buf);
    Filter_Wdata(caKey_Buf);
    EmsShowData('0',"\r");
    EmsShowData('0',D_String(caKey_Buf));
    EmsShowData('0',"\n");
    if (Date_Valid(caKey_Buf))
      Txn_Date_Check(&iDate_Chk_No,&iDate_Win_No,caKey_Buf);
    else
      iDate_Win_No --;
  }  while (iDate_Win_No < MAX_DATW -1 );

  if (iDate_Win_No != iDate_Chk_No) {
    EmsShowData('0',"txn date input error!! \n");
    UCP_TRACE_END(TXNDATE_INPUT_ERR);
  }

  UCP_TRACE_END(0);
}
#else   /*  have to link emscurss.o */

#define NO_ITEM       3
#define NO_RECORD     1
#define MAX_DATA_LEN  20
struct stMenu {
	WINDOW *pwWin;
	int iNoRecord; /* the number of records shown at the same time */
	struct stMenu *pstNextMenu;
	struct stItem *pstItem;
	};
struct stItem {
	int iPage;
	int iRow;
	int iCol;
	int (*Routine1)();
	int (*Routine2)();
	char caData[ MAX_DATA_LEN ];
	char cType;
	int iLength;
	char cAttribute;
        } stRecord4[ NO_ITEM * NO_RECORD ] = {
            {1, 16, 48, NULL, NULL, "        ", 'c', 8, 'e'},
            {1, 18, 48, NULL, NULL, "        ", 'c', 8, 'e'},
            {1, 20, 48, NULL, NULL, "        ", 'c', 8, 'e'},
        };
int
GetCkDat()
{
  int    iTct_Cnt;
  char   *D_String();
  char   *pfTty_Code();
  char   caKey_Buf[81];
  char   caTmp_Buf[80];
  char   caShowBuf[80];
  int    iKey_Len;
  int    iRc;
  int    iDate_Chk_No;
  int    iDate_Win_No;
  struct SSA *pstSsa;
  struct CwaCtl stCwaCtl;
  struct TermArea  stTmArea;
  FILE   *zFp,*fopen();
  char   caFlName[FILE_NAME_LEN];
  short  sStatus;
  struct stMenu *pstMenu;
  int    iRow,iCol;
  int    iChkNo;

  UCP_TRACE(P_GetCkDat);

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);

  if (iRc != 0) {
    UCP_TRACE_END(GET_SSA_PTR_ERR);
  }

  sStatus = pstSsa->sSysStatus;

  iRc = FindBit(&stTmArea);
  if (iRc != 0) {
    UCP_TRACE_END(FIND_BIT_ERR);
  }

  memset(caFlName,'\0',FILE_NAME_LEN);
  strcpy(caFlName,(char *) getenv("III_DIR"));
  strcat(caFlName,(char *) "/");
  if (stTmArea.cTermType == CHINESE_TYPE) {
    strcat(caFlName,TXNDAT_C);
  }
  else  {
    strcat(caFlName,TXNDAT_E);
  }

  zFp = fopen(caFlName,"r");
  if (zFp == NULL) {
    ErrLog(1000,g_caMsg,RPT_TO_TTY|RPT_TO_LOG,0,0);
    sprintf(g_caMsg,"LoadTct : Can't open txndate input errno = %d",errno);
    DetErrRpt(OPEN_FILE_ERR,g_caMsg);
    UCP_TRACE_END(OPEN_TXNDATE_ERR);
  }

  pstMenu = (struct stMenu *) InitNullMenu();
  pstMenu->pstItem = (struct stItem *) &stRecord4;
  signal(SIGCLD, SIG_IGN);

  iRow = 0;
  while (  fgets(caTmp_Buf,80,zFp) != NULL ){
    ShowStr(pstMenu,iRow,0,caTmp_Buf,'d');
    iRow++;
  }

  fclose(zFp);

  if ( !(sStatus & SYSTEM_RESTART) ) {  
    ShowStr(pstMenu,10,0,"System Status:NORMAL",'r');
  }
  else  {
    ShowStr(pstMenu,10,0,"System Status:RESTART",'r');
  }
    
  iRow += 2;
  if ( !(sStatus & ONLINE_CLOSE) ) { 
    ShowStr(pstMenu,12,0,"Operating Mode:ONLINE",'r');
  }
  else  {
    ShowStr(pstMenu,12,0,"Operating Mode:BATCH",'r');
  }
  memset(caTmp_Buf,'\0',80);
  memcpy(caTmp_Buf,&(pstSsa->caTxnDate[0]),8);

  iRow += 2;
  sprintf(caShowBuf,"Date : %s\n",D_String(caTmp_Buf));
  ShowStr(pstMenu,14,0,caShowBuf,'r');

  iRow += 2;
  iDate_Chk_No = -1;
  iDate_Win_No = -1;

  DisplayHead(pstMenu);
  DisplayData(pstMenu);

  do {
    iDate_Win_No ++;
    Get_Wdata(iDate_Win_No,caKey_Buf,pstMenu);
    Filter_Wdata(caKey_Buf);
    ShowStr(pstMenu,17+(iDate_Win_No*2),0,D_String(caKey_Buf),'r');
    if (Date_Valid(caKey_Buf,pstMenu)){
      iChkNo = iDate_Chk_No;
      Txn_Date_Check(&iDate_Chk_No,&iDate_Win_No,caKey_Buf,pstMenu);
      if (iDate_Chk_No != iChkNo) { /* compare both to know sucess or not */
        ShowMsg(pstMenu,23,20,"TxnDate Input Success!!");
        DisplayMenu(pstMenu);
      }
    }
    else
      iDate_Win_No --;
  }  while (iDate_Win_No < MAX_DATW -1 );
  ShowMsg(pstMenu,23,20,"TxnDate Input Success!! press any key to continue..");
  DisplayMenu(pstMenu);
  wgetch(pstMenu->pwWin);
  

  if (iDate_Win_No != iDate_Chk_No) {
    ShowMsg(pstMenu,23,20,"txn date input error!! ");
    UCP_TRACE_END(TXNDATE_INPUT_ERR);
  }

  EndTool(pstMenu);
  UCP_TRACE_END(0);
}
#endif

#ifndef CURSES
Get_Wdata(iWinno,iDatelen,pcaKey_Buf)
int  iWinno;
int  iDatelen;
char *pcaKey_Buf;
{
  char caTmpBuf[80];
  char caShowBuf[80];

     memset(caTmpBuf,'\0',80);

     switch(iWinno)  {
       case 0:
               strcpy(caTmpBuf,"Transaction");
               break;
       case 1:
               strcpy(caTmpBuf,"Next Transaction");
               break;
       case 2:
               strcpy(caTmpBuf,"Next  Next Transaction");
               break;
     }

     EmsShowData('0',"\n");
     sprintf(caShowBuf,"please enter the %s Day:\n",caTmpBuf);
     EmsShowData('0',caShowBuf);
     scanf("%8s",pcaKey_Buf);
     pcaKey_Buf[8] = 0x0;
}
#else
DisplayHead(pstMenu)
struct stMenu *pstMenu;
{
  char caTmpBuf[80];
  char caShowBuf[80];
  int  i;

  for (i=0;i<3;i++){   
    switch(i){
      case 0:
              strcpy(caTmpBuf,"Transaction");
              break;
      case 1:
              strcpy(caTmpBuf,"Next Transaction");
              break;
      case 2:
              strcpy(caTmpBuf,"Next  Next Transaction");
              break;
    }
    sprintf(caShowBuf,"Please enter the %s Day:",caTmpBuf);
    ShowStr(pstMenu,16+i*2,0,caShowBuf,'d');
  }
  sprintf(caShowBuf,"^D: Delete, ^U: Undo, Enter:Input Over.",caTmpBuf);
  ShowStr(pstMenu,22,0,caShowBuf,'d');
}

Get_Wdata(iWinno,pcaKey_Buf,pstMenu)
int  iWinno;
char *pcaKey_Buf;
struct stMenu *pstMenu;
{
  char caTmpBuf[80];
  char caShowBuf[80];
  int  i,j;
  char cChar;
  int  iKeyIn;
  int  iCurRow,iCurCol;

     memset(caTmpBuf,'\0',80);

     MvEdtItem(pstMenu,iWinno,A_UNDERLINE);
     keypad(pstMenu->pwWin,TRUE);

     while (1) {
       wrefresh( pstMenu->pwWin);
       iKeyIn = wgetch(pstMenu->pwWin);

       switch(iKeyIn)  {
         case 0x0797 :   /* ENTER */
         case CR :       /* ENTER */
           for(j=0;j<8;j++) {
              cChar = mvwinch(  pstMenu->pwWin,pstMenu->pstItem[ iWinno ].iRow,
                                pstMenu->pstItem[ iWinno ].iCol+j);
              pcaKey_Buf[j] = cChar;
           }
           pcaKey_Buf[8] = 0x0;
           return;
         case KEY_LEFT :
           getyx( pstMenu->pwWin, iCurRow, iCurCol );
           if ( iCurCol > pstMenu->pstItem[ iWinno ].iCol ) {
             wmove( pstMenu->pwWin, iCurRow, iCurCol - 1 );
           }
           else {
             Beep();
           }
           break;
         case KEY_RIGHT :
           getyx( pstMenu->pwWin, iCurRow, iCurCol );
           if ( iCurCol < pstMenu->pstItem[ iWinno ].iCol +
                          pstMenu->pstItem[ iWinno ].iLength - 1 ) {
             wmove( pstMenu->pwWin, iCurRow, iCurCol + 1 );
           }
           else {
             Beep();
           }
           break;
         case 0x04 :    /* Ctrl + d */
           DeleteCh( pstMenu, iWinno );
           break;
         case 0x15 :    /* Ctrl + u */
           Undo( pstMenu, iWinno );
           break;
         case '\x1b' :  /* ESC */
           Beep();
           break;
         default :
           AddCh( pstMenu, iWinno, iKeyIn, 0 );
           break;
       } /* FOR switch(iKeyIn) */
     } /* FOR while(1)  */
}
#endif

#ifndef CURSES
int
Date_Valid(pcaDate_List)
char  *pcaDate_List ;
{
   /*  this procedure perform a date validation.                     */
       char   *C_String();
       char   caShowBuf[80];
       char   caBaseYear[5];
       char   caTmpYear[4];
       int  iDays  ,
            iMonth ,
            iYear  ;
       int  i;

       UCP_TRACE(P_Date_Valid);

       memcpy(caTmpYear,pcaDate_List,4); /* keep the original content */

       if (g_iBaseYear != 0) {   /* add the base year to the pcaDate_List */
         sprintf(caBaseYear,"%.4d",g_iBaseYear);
         for (i=0;i<MNTH_OFFSET;i++) {
           pcaDate_List[i] +=  (caBaseYear[i] - '0');
         }
       }
         
       iDays  = atoi(C_String(pcaDate_List + DAYS_OFFSET, 2)) ;
       iMonth = atoi(C_String(pcaDate_List + MNTH_OFFSET, 2)) ;
       iYear  = atoi(C_String(pcaDate_List + YEAR_OFFSET, 4)) ;

       if (iYear % 4 == 0 && iYear % 100 != 0 || iYear % 400 == 0)
         iaMax_Days[2]=29;       /* this iYear is leap iYear.             */

       if (strlen(pcaDate_List) == 8  &&
           iMonth >=1 && iMonth <= 12 &&
           iDays  >=1 && iDays  <= iaMax_Days[iMonth]) {
         memcpy(pcaDate_List,caTmpYear,4); /* keep the original content */
         UCP_TRACE_END(TRUE);
       }
       else {
         sprintf(caShowBuf,"Invalid Date Input!!  %s\n",D_String(pcaDate_List) ) ;     
         EmsShowData('0',caShowBuf);
	 Beep();
         memcpy(pcaDate_List,caTmpYear,4); /* keep the original content */
         UCP_TRACE_END(FALSE);
       }

}
#else
int
Date_Valid(pcaDate_List,pstMenu)
char  *pcaDate_List ;
struct stMenu *pstMenu;
{
   /*  this procedure perform a date validation.                     */
       char   *C_String();
       char   caShowBuf[80];
       char   caBaseYear[5];
       char   caTmpYear[4];
       int  iDays  ,
            iMonth ,
            iYear  ;
       int  i;

       UCP_TRACE(P_Date_Valid);

       memcpy(caTmpYear,pcaDate_List,4); /* keep the original content */

       if (g_iBaseYear != 0) {   /* add the base year to the pcaDate_List */
         sprintf(caBaseYear,"%.4d",g_iBaseYear);
         for (i=0;i<MNTH_OFFSET;i++) {
           pcaDate_List[i] +=  (caBaseYear[i] - '0');
         }
       }

       iDays  = atoi(C_String(pcaDate_List + DAYS_OFFSET, 2)) ;
       iMonth = atoi(C_String(pcaDate_List + MNTH_OFFSET, 2)) ;
       iYear  = atoi(C_String(pcaDate_List + YEAR_OFFSET, 4)) ;

       if (iYear % 4 == 0 && iYear % 100 != 0 || iYear % 400 == 0)
         iaMax_Days[2]=29;       /* this iYear is leap iYear.             */

       if (strlen(pcaDate_List) == 8  &&
           iMonth >=1 && iMonth <= 12 &&
           iDays  >=1 && iDays  <= iaMax_Days[iMonth]) {
         memcpy(pcaDate_List,caTmpYear,4); /* keep the original content */
         UCP_TRACE_END(TRUE);
       }
       else {
         sprintf(caShowBuf,"Invalid Date Input!! %s",D_String(pcaDate_List) );  
         ShowMsg(pstMenu,23,20,caShowBuf);
	 Beep();
         memcpy(pcaDate_List,caTmpYear,4); /* keep the original content */
         UCP_TRACE_END(FALSE);
       }

}
#endif

#ifndef CURSES
Txn_Date_Check(piChkno,piWinno,pcaKey_Buf)
int  *piChkno;
int  *piWinno;
char *pcaKey_Buf;
{
  int    iRc;
  struct CwaCtl stCwaCtl;
  struct SSA *pstSsa;
  short  sStatus;       /* the system status  */
  char   caTmp_Buf[80];
  char   caShowBuf[80];
  long   lDateInput,lDateCore;

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);

  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }

  if (g_iFirstRun == 1) {
    switch((*piWinno)) {
      case 0: /* first time enter */
        (*piChkno)++;
        memcpy(pstSsa->caTxnDate,pcaKey_Buf,DATE_LEN);
        break;
      case 1: /* second time enter */
        (*piChkno)++;
        memcpy(pstSsa->caNextDate,pcaKey_Buf,DATE_LEN);
        break;
      case 2: /* first time enter */
        (*piChkno)++;
        memcpy(pstSsa->caNext2Date,pcaKey_Buf,DATE_LEN);
        break;
    }
    return;
  }

  sStatus =  pstSsa->sSysStatus;

  if ( !(sStatus & SYSTEM_RESTART) ) {  
    /* Normal Begin,Can't Check next next day, if not load ACIF */
    switch((*piWinno)) {
      case 0: /* first time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caTxnDate,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
          memcpy(pstSsa->caTxnDate,pcaKey_Buf,DATE_LEN);
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caTxnDate[0]),8);
	  sprintf(caShowBuf,"business day check error!!%8s\r",D_String(caTmp_Buf));
          EmsShowData('0',caShowBuf);
	  Beep();
        }
        break;
      case 1: /* second time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caNextDate,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
          memcpy(pstSsa->caNextDate,pcaKey_Buf,DATE_LEN);
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
	  sprintf(caShowBuf,"business day check error!!%8s\r",D_String(caTmp_Buf));
          EmsShowData('0',caShowBuf);
	  Beep();
        }
        break;
      case 2: /* third  time enter */
        if ( (sStatus & ONLINE_CLOSE) ) {  /* Normal & Batch */ 
          iRc = strncmp(pcaKey_Buf,pstSsa->caNext2Date,DATE_LEN);
          if (iRc == 0) {
            (*piChkno)++;
            memcpy(pstSsa->caNext2Date,pcaKey_Buf,DATE_LEN);
          }
          else {      /* Normal & Online , Don't check Next2date */
            (*piWinno)--;
            memset(caTmp_Buf,'\0',80);
            memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
	    sprintf(caShowBuf,"business day check error!!%8s\r",D_String(caTmp_Buf));
            EmsShowData('0',caShowBuf);
	    Beep();
          }
        }
        else  {
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
          lDateCore  = atol(caTmp_Buf);
          lDateInput = atol(pcaKey_Buf);
          if (lDateInput > lDateCore) {
            memcpy(pstSsa->caNext2Date,pcaKey_Buf,DATE_LEN);
            (*piChkno)++;
          }
          else  {
            (*piWinno)--;
            memset(caTmp_Buf,'\0',80);
            memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
	    sprintf(caShowBuf,"next next business day should not small than %8s\r",D_String(caTmp_Buf));
            EmsShowData('0',caShowBuf);
	    Beep();
          }
        }
	break;
    }  /* FOR switch(...)  */
  }
  else {
    /* Abnormal Begin,Check business days in CWA */
    switch((*piWinno)) {
      case 0: /* first time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caTxnDate,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caTxnDate[0]),8);
	  sprintf(caShowBuf,"business day check error!!%8s\r",D_String(caTmp_Buf));
          EmsShowData('0',caShowBuf);
	  Beep();
        }
        break;
      case 1: /* second time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caNextDate,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
	  sprintf(caShowBuf,"business day check error!!%8s\r",D_String(caTmp_Buf));
          EmsShowData('0',caShowBuf);
	  Beep();
        }
        break;
      case 2: /* third  time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caNext2Date,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caNext2Date[0]),8);
	  sprintf(caShowBuf,"business day check error!!%8s\r",D_String(caTmp_Buf));
          EmsShowData('0',caShowBuf);
	  Beep();
        }
	break;
    }  /* FOR switch(...)  */
  }  /* FOR if( !(cStatus.....))  */

  return;
}
#else
Txn_Date_Check(piChkno,piWinno,pcaKey_Buf,pstMenu)
int  *piChkno;
int  *piWinno;
char *pcaKey_Buf;
struct stMenu *pstMenu;
{
  int    iRc;
  struct CwaCtl stCwaCtl;
  struct SSA *pstSsa;
  short  sStatus;       /* the system status  */
  char   caTmp_Buf[80];
  char   caShowBuf[80];
  long   lDateInput,lDateCore;

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);

  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }

  if (g_iFirstRun == 1) {
    switch((*piWinno)) {
      case 0: /* first time enter */
        (*piChkno)++;
        memcpy(pstSsa->caTxnDate,pcaKey_Buf,DATE_LEN);
        break;
      case 1: /* second time enter */
        (*piChkno)++;
        memcpy(pstSsa->caNextDate,pcaKey_Buf,DATE_LEN);
        break;
      case 2: /* first time enter */
        (*piChkno)++;
        memcpy(pstSsa->caNext2Date,pcaKey_Buf,DATE_LEN);
        break;
    }
    return;
  }

  sStatus =  pstSsa->sSysStatus;

  if ( !(sStatus & SYSTEM_RESTART) ) {  
    /* Normal Begin,Can't Check next next day, if not load ACIF */
    switch((*piWinno)) {
      case 0: /* first time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caTxnDate,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
          memcpy(pstSsa->caTxnDate,pcaKey_Buf,DATE_LEN);
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caTxnDate[0]),8);
	  sprintf(caShowBuf,"business day check error!!%8s",D_String(caTmp_Buf));
          ShowMsg(pstMenu,23,20,caShowBuf);
	  Beep();
        }
        break;
      case 1: /* second time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caNextDate,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
          memcpy(pstSsa->caNextDate,pcaKey_Buf,DATE_LEN);
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
	  sprintf(caShowBuf,"business day check error!!%8s",D_String(caTmp_Buf));
          ShowMsg(pstMenu,23,20,caShowBuf);
	  Beep();
        }
        break;
      case 2: /* third  time enter */
        if ( (sStatus & ONLINE_CLOSE) ) {  /* Normal & Batch */ 
          iRc = strncmp(pcaKey_Buf,pstSsa->caNext2Date,DATE_LEN);
          if (iRc == 0) {
            (*piChkno)++;
            memcpy(pstSsa->caNext2Date,pcaKey_Buf,DATE_LEN);
          }
          else {      /* Normal & Online , Don't check Next2date */
            (*piWinno)--;
            memset(caTmp_Buf,'\0',80);
            memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
	    sprintf(caShowBuf,"business day check error!!%8s",D_String(caTmp_Buf));
            ShowMsg(pstMenu,23,20,caShowBuf);
            EmsShowData('0',caShowBuf);
	    Beep();
          }
        }
        else  {
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
          lDateCore  = atol(caTmp_Buf);
          lDateInput = atol(pcaKey_Buf);
          if (lDateInput > lDateCore) {
            memcpy(pstSsa->caNext2Date,pcaKey_Buf,DATE_LEN);
            (*piChkno)++;
          }
          else  {
            (*piWinno)--;
            memset(caTmp_Buf,'\0',80);
            memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
	    sprintf(caShowBuf,"next next business day should not small than %8s",D_String(caTmp_Buf));
            ShowMsg(pstMenu,23,20,caShowBuf);
	    Beep();
          }
        }
	break;
    }  /* FOR switch(...)  */
  }
  else {
    /* Abnormal Begin,Check business days in CWA */
    switch((*piWinno)) {
      case 0: /* first time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caTxnDate,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caTxnDate[0]),8);
	  sprintf(caShowBuf,"business day check error!!%8s",D_String(caTmp_Buf));
          ShowMsg(pstMenu,23,20,caShowBuf);
	  Beep();
        }
        break;
      case 1: /* second time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caNextDate,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caNextDate[0]),8);
	  sprintf(caShowBuf,"business day check error!!%8s",D_String(caTmp_Buf));
          ShowMsg(pstMenu,23,20,caShowBuf);
	  Beep();
        }
        break;
      case 2: /* third  time enter */
        iRc = strncmp(pcaKey_Buf,pstSsa->caNext2Date,DATE_LEN);
        if (iRc == 0) {
          (*piChkno)++;
        }
	else {
          (*piWinno)--;
          memset(caTmp_Buf,'\0',80);
          memcpy(caTmp_Buf,&(pstSsa->caNext2Date[0]),8);
	  sprintf(caShowBuf,"business day check error!!%8s",D_String(caTmp_Buf));
          ShowMsg(pstMenu,23,20,caShowBuf);
	  Beep();
        }
	break;
    }  /* FOR switch(...)  */
  }  /* FOR if( !(cStatus.....))  */

  return;
}
#endif
 

char 
*D_String(pcaDate_List)
char  *pcaDate_List ;
{
   /*  this procedure pack date string into date representation form */
    int    iZeroCnt,i;
    char   *pcaDate_String="//////////\0" ;

    UCP_TRACE(P_D_String);     

    iZeroCnt = 0;
    memset(pcaDate_String,'/',11);
    for (i=0;i<MNTH_OFFSET;i++) { /* check the year is west or east year */
      if (pcaDate_List[i] != '0') { /* break out the loop when meet the first */
        break;                      /* non-zero character */
      }
      else {
        iZeroCnt++;
      }
    }

    /* pcaDate_List is always the format YYYYMMDD    */
    strncpy(pcaDate_String,pcaDate_List+YEAR_OFFSET+iZeroCnt,4-iZeroCnt);
    strncpy(pcaDate_String+5-iZeroCnt,pcaDate_List+MNTH_OFFSET,2);
    strncpy(pcaDate_String+8-iZeroCnt,pcaDate_List+DAYS_OFFSET,2);
    pcaDate_String[10-iZeroCnt] = '\0';

    UCP_TRACE_END(pcaDate_String);
}

char
*C_String(pcaChar_List,iN_char)
char  *pcaChar_List ;
int   iN_char     ;                        
{
   /*  this procedure can pack character at most 12 chars.           */
       static char  scaChar_String[14] ;

       UCP_TRACE(P_C_String);

       if (iN_char <= 12) {
          strncpy(scaChar_String,pcaChar_List,iN_char) ;
          scaChar_String[iN_char] = '\0' ;
       }

       UCP_TRACE_END(scaChar_String) ;
}

Beep()
{
  EmsShowData('0',"\a\a\a");
}

#define  UNDEFINED_TERM  -4

int
FindBit(pstTmArea)
struct  TermArea  *pstTmArea;
{
  char   *pcaBitTbl;
  struct CwaCtl stCwaCtl;
  struct TermArea  stTermArea;
  struct BrhArea   stBrhArea;
  int    iTotBrhCnt,i;
  int    iOffset,iBrhOffset;
  int    iRc;
  char   caTtyStr[14];

  UCP_TRACE(P_FindBit);

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_BIT_START;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcaBitTbl);
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }

  iRc = GetDevHostName(caTtyStr);
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }
  if (caTtyStr[13] != '\0')  caTtyStr[13] = '\0';

  memcpy(&iTotBrhCnt,pcaBitTbl,4);
  iBrhOffset = 8;

  do  {
    memcpy(&stBrhArea,pcaBitTbl+iBrhOffset,sizeof(struct BrhArea));
    iOffset = stBrhArea.iTermOffset;

    while (iOffset != -1)  {
      memcpy(&stTermArea,pcaBitTbl+iOffset,sizeof(struct TermArea));
      if (strcmp(caTtyStr,stTermArea.caLogicId)== 0) {
        memcpy(pstTmArea,&stTermArea,sizeof(struct TermArea));
        UCP_TRACE_END(0);
      }
      else  {
        iOffset = stTermArea.iNxtTmOffset;
      }
    }

    iBrhOffset = stBrhArea.iNxtBrhOffset;
  } while(iBrhOffset != -1);  
  
  if ((iOffset == -1)&&(iBrhOffset == -1))  {
    sprintf(g_caMsg,"FindBit:can't find terminal data %s",caTtyStr);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(UNDEFINED_TERM);
  }
}

ShowRestInfo(int iOpMode)
{
   int  i,iRc;
   char caShowBuf[80];
   struct MDA    *pstMda;
   struct CwaCtl stCwaCtl;
 
   i=0;
   while( strlen(g_caIfVerName[i]) != 0)  {
     EmsShowData('0',g_caIfVerName[i]);
     EmsShowData('0',"\n");
     i++;
   }

   /* attach MDA share memory */
   stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
   stCwaCtl.cSegCode = CWA_SEG_MDA;
   iRc = CwaLowCtlFac(&stCwaCtl,&pstMda);

   if (iRc != 0) {
     EmsShowData('0',"Can't Attach MDA !!");
     return(-1);
   }

   if (iOpMode == 0) {
     i=0;
     while(MCfg(i).caPrgname[0] != '\0'){
       sprintf(caShowBuf,"%i  %s  servers\n",MCfg(i).iFstFokNo,MCfg(i).caPrgname);
       EmsShowData('0',caShowBuf);
  
       i++;
     }
   } /* FOR if (iOpMode == 0) */
   return(0);

}

Filter_Wdata(pcaWdata)
char *pcaWdata;
{
  int  i,iSpaceCnt;
  char caTmpBuf[DATE_LEN];

  iSpaceCnt = 0;
  for (i=DATE_LEN-1;i>=0;i--) {
    if (pcaWdata[i] == ' ') {
      iSpaceCnt++;
    }
  }
  
  if (iSpaceCnt != 0) {   /* replace the tail spaces as the head zero  */ 
    memcpy(caTmpBuf,pcaWdata,DATE_LEN-iSpaceCnt);
    memset(pcaWdata,'0',DATE_LEN);
    memcpy(&pcaWdata[iSpaceCnt],caTmpBuf,DATE_LEN-iSpaceCnt);
  } 

  return;
}
