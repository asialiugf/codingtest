           
         
/**
                 �z�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�{
                 �x         ict_head {                 �x
          �z�w�w�w�w�w�w�w�w�wint cit_offs;            �x
        �z�q�w�w�w�w�w�w�w�w�wint gdt_offs;            �x
      �z�q�q�w�w�w�w�w�w�w�w�wint mdt_offs;            �x
    �z�q�q�q�w�w�w�w�w�w�w�w�wint hlp_offs;            �x
  �z�q�q�q�q�w�w�w�w�w�w�w�w�wint mst_offs;            �x
  �x�x�x�x�x  �z�w�w�w�w�w�w�wint hlp_idx_offs;        �x
  �x�x�x�x�x�z�w�w�w�w�w�w�w�wint mst_idx_offs;        �x
  �x�x�x�x�x�x�x �x           int reserve2;            �x
  �x�x�x�x�x�x�x �x           int reserve3;            �x
  �x�x�x�x�x�x�x �x         } (sizeof(struct ict_head) �x
  �x�x�x�x�x�x�x �u�w�w�w�w�w�w�w�w�w�w�w�w�w�s�w�w�w�w�t
  �x�x�x�x�x�x�|>�xHelp Total Count (4 Bytes)�xHelp Key�x
  �x�x�x�x�x�x   �u�w�w�w�w�w�w�w�w�w�w�w�w�w�}        �x
  �x�x�x�x�x�x   �xIndex ..........                    �x
  �x�x�x�x�x�x   �x(Help Total Count * sizeof(hlp_head)�x
  �x�x�x�x�x�x   �x......... �z�w�w�w�w�w�w�w�w�w�w�w�w�t
  �x�x�x�x�x�|�w�w�w�w�w�w�w>�xMst Total Count(4 Bytes)�x
  �x�x�x�x�x     �u�w�w�w�w�w�r�w�w�w�w�w�w�w�w�w�w�w�w�t
  �x�x�x�x�x     �xMst Key Index ..................... �x
  �x�x�x�x�x     �x(Key Len (4) * Mst Total Count ) ...�x
  �x�x�x�x�x     �u�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�t
  �x�x�x�x�|�w�w>�x CIT .............................. �x
  �x�x�x�x       �x .. (Total CTF Sizes of Business).. �x
  �x�x�x�x       �u�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�t
  �x�x�x�|�w�w�w>�x GDT .............................. �x
  �x�x�x         �x .(Sizeof(struct gud_node) * Count) �x
  �x�x�x         �u�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�t
  �x�x�|�w�w�w�w>�x MENU.............................. �x
  �x�x           �x .(Sizeof(struct menu_node) * Count)�x
  �x�x           �u�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�t
  �x�|�w�w�w�w�w>�x HLP .............................. �x
  �x             �x .(Sizeof(struct help_node) * Count)�x
  �x             �u�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�t
  �|�w�w�w�w�w�w>�x MST .............................. �x
                 �x .(Sizeof(struct mst_node) * Count) �x
                 �|�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�}
                              �� ICT
**/

/*
 *&N& ROUTINE NAME: ICTBuild()
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&           
 *&R& RETURN VALUES:
 *&R&    0  : ���`.
 *&R&           
 *&R&           
 *&D& DESCRIPTION:           
 *&D&     ����Ƭ�  �J��J��Ʀ@�P����.
 *&D&       ��J��Ʀ@�P����]�A : �p (�� ICT).
 *&D&   1.�p��ICT �ҧt�U����һݪŶ� :
 *&D&    1.1 �p��@�P�����ƪ�l�Ȫ���(CIT)�j�p,�η~�ȭӼ�,�I�s(CompCitSize()).
 *&D&    1.2 �p��޾ɴy�z����(GDT)�j�p,�I�s(CompGdtSize()).
 *&D&    1.3.�p�⹺����Ϊ���(MDT)�j�p,�I�s(CompMenuSize()).
 *&D&    1.4.�p�⻲�U��������(HLP)�j�p,�λ������Y�j�p,�I�s(CompHlpSize()).
 *&D&    1.5.�p����~�T������(MST)�j�p,�T���N�X�j�p,�I�s(CompMstSize()).
 *&D&    1.6.�p��ICT����j�p : �֭p(CIT)���Y,1.2~1.5.
 *&D&  2.�t�m(ICT)����@�ΰO����Ŷ�,�I�s(CrtTblShm()).
 *&D&  3.�]�w Help Index �ҩl��} offsets.
 *&D&    �]�w Mst Index �ҩl��} offsets.
 *&D&  4.�N�@�P�����ƪ�l��  �J(ICT)���椤�ҩl��}
 *&D&    (pcICTBas+pstICTHd->cit_offs),�I�sCitLoad().
 *&D&  5.�N�޾ɴy�z������  �J(ICT)���椤�ҩl��}
 *&D&    (pcICTBas+pstICTHd->gud_offs),�I�sGdtLoad().
 *&D&  6.�N������Ϊ�����  �J(ICT)���椤�ҩl��}
 *&D&    (pcICTBas+pstICTHd->menu_offs),�I�sMenuLoad().
 *&D&  7.�N���U��������  �J(ICT)����,�ò֭p���ޭӼ�,�ҩl��}(pcHlpCnt),
 *&D&    ���U����������  �J(ICT)���椤�ҩl��}(pcICTBas+pstICTHd->hlp_offs).
 *&D&    �I�sHlpLoad().
 *&D&  8.�N�T���N�X  �J(ICT)����,�ò֭p�N�X�Ӽ�,�ҩl��}(pcMstCnt),
 *&D&    ���~�T��������  �J(ICT)���椤�ҩl��}(pcICTBas+pstICTHd->mst_offs),
 *&D&    �I�sMstLoad().
 *&D&           
 */

#define   FILE_SIZE_ERR    -1
#define   OPEN_FILE_ERR    -2
#define   READ_FILE_ERR    -3

#define   ICT_SHM_MODE     00666
#define   CIT_LOADED       ".. CIT Table has been loaded !!\n"
#define   GDT_LOADED       ".. GDT Table has been loaded !!\n"
#define   MDT_LOADED       ".. MDT Table has been loaded !!\n"
#define   HLP_LOADED       ".. HLP Table has been loaded !!\n"
#define   MST_LOADED       ".. MST Table has been loaded !!\n"


#include  <errno.h>
#include  "errlog.h"
#include  "emctldef.h"
#include  "emctblld.h"
#include  "emctblof.h"
#include  "emcenvhl.h"
#include  "emcpgdef.h"
#include  "ucp.h"
extern int g_iSysOpMode;
extern int g_iIctKey;
extern int g_iCtfKey;

#define   SIF_SIZE        MAX_SIF_LEN

int
ICTBuild(char *pcCtfBas)
{
  int iRc;
  int iCitSize,iGudSize,iMenuSize,
      iHlpSize,iMstSize;
  int iBusiCnt;
  int iFreeOffs;
  char caShowBuf[80];
  unsigned int uiHlpHdSize;
  unsigned int uiHlpDetSize;
  unsigned int uiMstHdSize;
  unsigned int uiMstArySize;
  unsigned int uiICTShmSize;
  char *pcICTBas,*pcICTDat;
  char *pcHlpCnt,*pcMstCnt;
  struct hlp_idx *pstHlpIdx;
  char *pcaMstAry;
  ict_head stICTHd,*pstICTHd;
  long int lAddr;
  int iAlignment;

  UCP_TRACE(P_ICTBuild);
  
  iCitSize = CompCitSize(&iBusiCnt);  /* call from emstblld.c */
  if (iCitSize <= 0) {
    sprintf(g_caMsg,"Call compCitSize() error iRc = %d\n",iCitSize);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(CIT_SIZE_ERR);
  }

  iGudSize = CompGdtSize(g_iSysOpMode);
  if (iGudSize <= 0) {
    sprintf(g_caMsg,"Call compGdtSize() error iRc = %d\n",iGudSize);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(GUD_SIZE_ERR);
  }

  iMenuSize = CompMenuSize();
  if (iMenuSize <= 0) {
    sprintf(g_caMsg,"Call compMenuSize() error iRc = %d\n",iMenuSize);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(MENU_SIZE_ERR);
  }

  iHlpSize = CompHlpSize(g_iSysOpMode,&uiHlpHdSize);
  if (iHlpSize <= 0) {
    sprintf(g_caMsg,"Call compHlpSize() error iRc = %d\n",iHlpSize);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(HLP_SIZE_ERR);
  }

  iMstSize = CompMstSize(g_iSysOpMode,&uiMstArySize);
  if (iMstSize < 0) {
    sprintf(g_caMsg,"Call compMstSize() error iRc = %d\n",iMstSize);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(MST_SIZE_ERR);
  }

  iAlignment = 5 * 4;  /* 5: # of business tables; 4: alignment base */
  uiICTShmSize = sizeof(ict_head) + iCitSize + iGudSize +
                iMenuSize + iHlpSize + iMstSize + iAlignment;
  /*
  sprintf (g_caMsg,"TCC: ShmSize:%d ict_head:%d Cit:%d Gud:%d Menu:%d Hlp:%d Mst:%d",
          uiICTShmSize,sizeof(ict_head),iCitSize,iGudSize,iMenuSize,iHlpSize,iMstSize); 
  ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
  */
 /* --------------------------------- */
 /* Get ICT share memory space        */
 /* call CrtTblArea() from emstblld.c */
 /* --------------------------------- */
  
  iRc = IpcShmCr(g_iIctKey,uiICTShmSize,ICT_SHM_MODE,&pcICTBas);
  if (iRc < 0) {
    sprintf(g_caMsg,"Create ICT share memory iRc = %d\n",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(CREATE_ICTSHM_ERR);
  }
  
  pstICTHd = (ict_head *) pcICTBas;
  pstICTHd->iHlpIdxOffs = sizeof(ict_head);
  pstICTHd->iMstIdxOffs = pstICTHd->iHlpIdxOffs + 4 + uiHlpHdSize;

  iFreeOffs = pstICTHd->iMstIdxOffs + uiMstArySize + 4;
  
  pstICTHd->iCitOffs = iFreeOffs;
  lAddr = (long) (pcICTBas+pstICTHd->iCitOffs);

  if (lAddr % 4)
     pstICTHd->iCitOffs += (lAddr % 4);

  iRc = CitLoad((char *) (pcICTBas+pstICTHd->iCitOffs), pcCtfBas);
  if (iRc <= 0) {
    sprintf(g_caMsg,"Call CitLoad() error iRc = %d\n",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(CIT_LOAD_ERR);
  }
  sprintf(caShowBuf,"%s", CIT_LOADED);
  EmsShowData('0',caShowBuf);
  iFreeOffs += iRc;

  pstICTHd->iGdtOffs = iFreeOffs;
  lAddr = (long) (pcICTBas+pstICTHd->iGdtOffs);

  if (lAddr % 4)
     pstICTHd->iGdtOffs += (lAddr % 4);

  iRc = GudLoad(g_iSysOpMode,(char *) (pcICTBas+pstICTHd->iGdtOffs));
  if (iRc <= 0) {
    sprintf(g_caMsg,"Call GdtLoad() error iRc = %d\n",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(GUD_LOAD_ERR);
  }
  sprintf(caShowBuf,"%s", GDT_LOADED);
  EmsShowData('0',caShowBuf);
  iFreeOffs += iRc;

  pstICTHd->iMdtOffs = iFreeOffs;
  lAddr = (long) (pcICTBas+pstICTHd->iMdtOffs);

  if (lAddr % 4)
     pstICTHd->iMdtOffs += (lAddr % 4);

  iRc = MenuLoad(g_iSysOpMode,(char *) (pcICTBas+pstICTHd->iMdtOffs));
  if (iRc <= 0) {
    sprintf(g_caMsg,"Call MenuLoad() error iRc = %d\n",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(MENU_LOAD_ERR);
  }
  sprintf(caShowBuf,"%s", MDT_LOADED);
  EmsShowData('0',caShowBuf);
  iFreeOffs += iRc;

  pcHlpCnt = pcICTBas + pstICTHd->iHlpIdxOffs;
  pstICTHd->iHlpOffs = iFreeOffs;
  lAddr = (long) (pcICTBas+pstICTHd->iHlpOffs);

  if (lAddr % 4)
     pstICTHd->iHlpOffs += (lAddr % 4);

  iRc = HlpLoad(g_iSysOpMode,(char *) (pcICTBas+pstICTHd->iHlpOffs),pcHlpCnt);
  if (iRc < 0) {     /* modify by JessWu, allow hlp file is empty  */  
    sprintf(g_caMsg,"Call HlpLoad() error iRc = %d\n",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(HLP_LOAD_ERR);
  }

  sprintf(caShowBuf,"%s", HLP_LOADED);
  EmsShowData('0',caShowBuf);
  iFreeOffs += iRc;
  
  pcMstCnt = pcICTBas + pstICTHd->iMstIdxOffs;
  pstICTHd->iMstOffs = iFreeOffs;
  lAddr = (long) (pcICTBas+pstICTHd->iMstOffs);

  if (lAddr % 4)
     pstICTHd->iMstOffs += (lAddr % 4);

  iRc = MstLoad(g_iSysOpMode,(char *) (pcICTBas+pstICTHd->iMstOffs),pcMstCnt);
  if (iRc <= 0) {
    sprintf(g_caMsg,"Call MstLoad() error iRc = %d\n",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(MST_LOAD_ERR);
  }

  sprintf(caShowBuf,"%s", MST_LOADED);
  EmsShowData('0',caShowBuf);
  iFreeOffs += iRc;
  UCP_TRACE_END(0);
}  /* ICTBuild() */


int 
CompGdtSize(iSysMode)
int iSysMode;
{
  struct gud_node stGudRec;
  int iRc;
  int iGudFd;
  int iGudFlSize;
  char caFlName[FILE_NAME_LEN];

  UCP_TRACE(P_CompGdtSize);

  iGudFlSize = 0;

  memset(caFlName,'\0',FILE_NAME_LEN);
  strcpy(caFlName,(char *) getenv("III_DIR"));
  strcat(caFlName,(char *) "/");
  
  if (iSysMode == CHINESE_MODE) {
    strcat(caFlName,GUD_FILE_C);
  }
  else {
    strcat(caFlName,GUD_FILE_E);
  }

  iRc = OpenFile(caFlName,&iGudFd);

  if (iRc < 0) {
    sprintf(g_caMsg,"Call OpenFile() error iRc = %d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(iRc);
  }

  while ((iRc = read(iGudFd,&stGudRec,sizeof(struct gud_node))) > 0) {
   if (iRc != sizeof(struct gud_node)) {
     sprintf(g_caMsg,"read GUD_FILE:%s size = %d error,sizeof = %d",
                               caFlName,iRc,sizeof(struct gud_node));
     DetErrRpt(FILE_SIZE_ERR,g_caMsg);
     UCP_TRACE_END(FILE_SIZE_ERR);
   } /* if (iRc != sizeof(struct gud_node))  */
   iGudFlSize += sizeof(struct gud_node);
  } /* while ((iRc = read(iGudFd,&stGudRec,sizeof(struct gud_node)) > 0) */

  close(iGudFd);

  UCP_TRACE_END(iGudFlSize);
}  /* CompGdtSize(iGudFd) */


int 
CompMenuSize()
{
  int i=0;
  struct menu_rec  stMenuRec;
  int iRc;
  int iMenuFlSize;
  int iMenuFd;
  char caFlName[FILE_NAME_LEN];

  UCP_TRACE(P_CompMenuSize);

  iMenuFlSize = 0;

  memset(caFlName,'\0',FILE_NAME_LEN);
  strcpy(caFlName,(char *) getenv("III_DIR"));
  strcat(caFlName,(char *) "/");
  strcat(caFlName,MENU_FILE);

  iRc = OpenFile(caFlName,&iMenuFd);

  if (iRc < 0) {
    sprintf(g_caMsg,"Call OpenFile() error iRc = %d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(iRc);
  }

  while ((iRc = read(iMenuFd,&stMenuRec,sizeof(struct menu_rec ))) > 0) {
    i++;

   if (iRc != sizeof(struct menu_rec )) {
     sprintf(g_caMsg,"read MENU_FILE size = %d error,sizeof = %d",
                                         iRc,sizeof(struct menu_rec ));
     DetErrRpt(FILE_SIZE_ERR,g_caMsg);
     UCP_TRACE_END(FILE_SIZE_ERR);
   } /* if (iRc != sizeof(struct menu_rec ))  */

   iMenuFlSize += sizeof(struct menu_node);

  } /* while ((iRc = read(iMenuFd,&stMenudRec,sizeof(struct menu_rec )) > 0) */

  close(iMenuFd);
  UCP_TRACE_END(iMenuFlSize);
}  /* CompMenuSize(iMenuFd) */



int 
CompHlpSize(iSysMode,puiHlpHdSize)
int iSysMode;
unsigned int *puiHlpHdSize;
{

  struct help_node stHlpRec;
  char caLastHlpId[GUD_NO_LEN+1];
  int iRc;
  int iHlpFd;
  int iHlpSize;
  int iHlpHdCnt;
  int iHlpRecCnt;
  char caFlName[FILE_NAME_LEN];

  UCP_TRACE(P_CompHlpSize);

  memset(caFlName,'\0',FILE_NAME_LEN);
  strcpy(caFlName,(char *) getenv("III_DIR"));
  strcat(caFlName,(char *) "/");

  if (iSysMode == CHINESE_MODE) {
    strcat(caFlName,HLP_FILE_C);
  }
  else {
    strcat(caFlName,HLP_FILE_E);
  }

  iRc = OpenFile(caFlName,&iHlpFd);
  if (iRc < 0) {
    sprintf(g_caMsg,"Call OpenFile() error iRc = %d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(iRc);
  }

  iHlpSize = 0;
  *puiHlpHdSize = 0;
  iHlpRecCnt = 0;
  iHlpHdCnt = 0;
  memset(caLastHlpId,'\0',GUD_NO_LEN+1);

  while ((iRc = read(iHlpFd,&stHlpRec,sizeof(struct help_node))) > 0) {
   if (iRc != sizeof(struct help_node)) {
     sprintf(g_caMsg,"read MENU_FILE size = %d error,sizeof = %d",
                                         iRc,sizeof(struct help_node));
     DetErrRpt(FILE_SIZE_ERR,g_caMsg);
     UCP_TRACE_END(FILE_SIZE_ERR);
   } /* if (iRc != sizeof(struct gud_node))  */
   stHlpRec.caHlpNo[GUD_NO_LEN] = '\0';
   if (strcmp(stHlpRec.caHlpNo,caLastHlpId) != 0) {
     strcpy(caLastHlpId,stHlpRec.caHlpNo);
     iHlpHdCnt++;
   }
   iHlpRecCnt++;
  } /* while ((iRc = read(iHlpFd,&stGudRec,sizeof(struct help_node)) > 0) */

  close(iHlpFd);

  *puiHlpHdSize = sizeof(hlp_head) * iHlpHdCnt;
  iHlpSize = 4 +                           /* Storing help index count length */
             *puiHlpHdSize +                 /* Help index count */
             sizeof(struct help_node) * iHlpRecCnt;  /* Help constent */

  UCP_TRACE_END(iHlpSize);
}  /* CompHlpSize(iHlpFd) */



int 
CompMstSize(iSysMode,puiMstArySize)
int iSysMode;
unsigned int *puiMstArySize;
{

  struct mst_node stMstRec;
  int iRc;
  int iMstFd;
  int iMstSize;
  int iMstRecCnt;
  char caFlName[FILE_NAME_LEN];

  UCP_TRACE(P_CompMstSize);

  memset(caFlName,'\0',FILE_NAME_LEN);
  strcpy(caFlName,(char *) getenv("III_DIR"));
  strcat(caFlName,(char *) "/");

  if (iSysMode == CHINESE_MODE) {
    strcat(caFlName,MST_FILE_C);
  }
  else {
    strcat(caFlName,MST_FILE_E);
  }

  iRc = OpenFile(caFlName,&iMstFd);
  if (iRc < 0) {
    sprintf(g_caMsg,"Call OpenFile() error iRc = %d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(iRc);
  }
  iMstSize = 0;
  iMstRecCnt = 0;

  while ((iRc = read(iMstFd,&stMstRec,sizeof(struct mst_node))) > 0) {
   if (iRc != sizeof(struct mst_node)) {
     sprintf(g_caMsg,"read MENU_FILE size = %d error,sizeof = %d",
                                         iRc,sizeof(struct mst_node));
     DetErrRpt(FILE_SIZE_ERR,g_caMsg);
     close(iMstFd);
     UCP_TRACE_END(FILE_SIZE_ERR);
   } /* if (iRc != sizeof(struct gud_node))  */
   iMstRecCnt++;
  } /* while ((iRc = read(iMstFd,&stGudRec,sizeof(struct gud_node)) > 0) */

  close(iMstFd);

  *puiMstArySize = GUD_NO_LEN * iMstRecCnt;
  iMstSize   = 4              +  /* Mst Total counter */
               *puiMstArySize +  /* MST key arrary */
               sizeof(struct mst_node) * iMstRecCnt; /* MST detail constent */

  UCP_TRACE_END(iMstSize);
}  /* CompMstSize(iMstFd) */


int
CitLoad(pcCitDat, pcCtfBas)
char *pcCitDat;
char *pcCtfBas;
{
  int iRc;
  int iBusiCnt;
  int iBusiNum;
  int iItemCnt;
  int iInitIdx;
  int iCitSize;
  int iInputLen;
  int iWdCnt;
  char *pcBusiHd,*pcItem;
  char *pcCitBegin,*pcCitPos;
  char caDataBuf[SIF_SIZE],caDataCnv[SIF_SIZE];
  busi_ctf *pstBusiNd;
  ctf_item *pstItem;
  
  UCP_TRACE(P_CitLoad);
  /*
  iRc = IpcShmat(g_iCtfKey,&pcCtfBas);
  if (iRc < 0) {
    sprintf(g_caMsg,"Call AttchCtf() error iRc = %d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(iRc);
  }
  */
  
  memcpy(&iBusiNum,pcCtfBas,4);
  pcBusiHd = (char *)(pcCtfBas + 4); /* storing the busi_cnt */
  pcItem = (char *)(pcBusiHd + iBusiNum * sizeof(busi_ctf));
  pcCitBegin = pcCitDat;
  iCitSize = 0;
  for (iBusiCnt = 0;iBusiCnt < iBusiNum;iBusiCnt++) {
   pstBusiNd = (busi_ctf *) (pcBusiHd + sizeof(busi_ctf) * iBusiCnt);
   for (iItemCnt = 0; iItemCnt < pstBusiNd->iTotItem; iItemCnt++) {
     pstItem = (ctf_item *) (pcItem + sizeof(ctf_item) *
                                        (iItemCnt + pstBusiNd->iTblIdx));
     if (pstItem->cDatType != 'y') {
       switch (pstItem->cDatType) {
         case 'q' :
         case 'r' :
         case 't' :
          iInputLen = pstItem->iDatLen - pstItem->iDotPos - 2;
          break;
         case 'f' :
         case 'g' :
         case 'h' :
          iInputLen = pstItem->iDatLen - pstItem->iDotPos - 1;
          break;
         case 'i' :
         case 'j' :
         case 'k' :
          iInputLen = pstItem->iDatLen - 1;
          break;
         default  :
          iInputLen = pstItem->iDatLen;
       } /* switch (pstItem->dat_type) */

       memset(caDataBuf,'\0',SIF_SIZE);
       for (iWdCnt = 0; iWdCnt < iInputLen; iWdCnt++) {
         caDataBuf[iWdCnt] = pstItem->cIniValue;
       } /* for (iWdCnt = 0; iWdCnt < iInputLen; iWdCnt++) */
       memset(caDataCnv,'\0',SIF_SIZE);

       iRc = DataCnv(pstItem,caDataBuf,caDataCnv ,iWdCnt);
       if (iRc == -1) {
         sprintf(g_caMsg,"DataCnv() error iRc = %d",iRc);
         ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
         UCP_TRACE_END(iRc);
       }
       else {
         pcCitPos = (char *) (pcCitBegin + pstItem->iCtfOffs);
         memcpy(pcCitPos, caDataCnv, pstItem->iCtfLen);
       } /* if (iRc == -1) */
     }  /* if (pstItem->dat_type != 'y') */
   } /* for (iItemCnt = 0; iItemCnt < pstBusiNd->iTotItem; iItemCnt++) */
  /* ----------------------------- */
  /* Change Next Business Node     */
  /* ----------------------------- */
   iInitIdx = (int) (pcCitBegin - pcCitDat);
   pstBusiNd->iInitIdx = iInitIdx;         
   pcCitBegin = (char *) (pcCitBegin + pstBusiNd->iCtfSize);
   iCitSize += pstBusiNd->iCtfSize;
  }  /* for (iBusiCnt = 0;iBusiCnt < iBusiNum;iBusiCnt++) */
  UCP_TRACE_END(iCitSize);
}  /* CitLoad(pcCitDat) */

int
GudLoad(iSysMode,pcGudDat)
int iSysMode;
char *pcGudDat;
{
  int iRc;
  int iGudFd;
  int iGudSize;
  int iGudCnt;
  struct gud_node stGudRec;
  struct gud_node *pstGudNd;
  char caFlName[FILE_NAME_LEN];

  UCP_TRACE(P_GudLoad);
  memset(caFlName,'\0',FILE_NAME_LEN);
  strcpy(caFlName,(char *) getenv("III_DIR"));
  strcat(caFlName,(char *) "/");
  
  if (iSysMode == CHINESE_MODE) {
    strcat(caFlName,GUD_FILE_C);
  }
  else {
    strcat(caFlName,GUD_FILE_E);
  }

  iRc = OpenFile(caFlName,&iGudFd);

  if (iRc < 0) {
    sprintf(g_caMsg,"Call OpenFile() error iRc = %d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(iRc);
  } /* if (iRc < 0) */

  iGudCnt = 0;
  while((iRc = read(iGudFd,&stGudRec,sizeof(struct gud_node))) > 0) {
    if (iRc != sizeof(struct gud_node)) {
      sprintf(g_caMsg,"read GUD_FILE size = %d error,sizeof = %d",
                                         iRc,sizeof(struct gud_node));
      DetErrRpt(FILE_SIZE_ERR,g_caMsg);
      UCP_TRACE_END(FILE_SIZE_ERR);
    }  /* if (iRc != sizeof(struct gud_node)) */
    pstGudNd = (struct gud_node *) (pcGudDat +
                                    sizeof(struct gud_node) * iGudCnt++);
    strcpy(pstGudNd->caGudNo,stGudRec.caGudNo);
    strcpy(pstGudNd->caGudLine,stGudRec.caGudLine);
  } /* while((iRc = read(iGudFd,&stGudRec,sizeof(struct gud_node))) > 0) */
  close(iGudFd);
  UCP_TRACE_END(sizeof(struct gud_node) * iGudCnt);
}  /* GudLoad(iSysMode,pcGudDat) */



int
MenuLoad(iSysMode,pcMenuDat)
int iSysMode;
char *pcMenuDat;
{
  int iRc;
  int iMenuFd;
  int iMenuCnt;
  struct menu_node *pstMenuNd;
  struct menu_rec stMenuRec;
  char caFlName[FILE_NAME_LEN];
  
  UCP_TRACE(P_MenuLoad);

  memset(caFlName,'\0',FILE_NAME_LEN);
  strcpy(caFlName,(char *) getenv("III_DIR"));
  strcat(caFlName,(char *) "/");
  strcat(caFlName,MENU_FILE);

  iRc = OpenFile(caFlName,&iMenuFd);

  if (iRc < 0) {
    sprintf(g_caMsg,"Call OpenFile() error iRc = %d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(iRc);
  }

  iMenuCnt = 0;

  while ((iRc = read(iMenuFd,&stMenuRec,sizeof(struct menu_rec))) > 0) {
    if (iRc != sizeof(struct menu_rec)) {
     sprintf(g_caMsg,"read MENU_FILE size = %d error,sizeof = %d",
                                         iRc,sizeof(struct menu_rec));
     DetErrRpt(FILE_SIZE_ERR,g_caMsg);
     UCP_TRACE_END(FILE_SIZE_ERR);
    }  /* if (iRc != sizeof(struct menu_node)) */
    pstMenuNd = (struct menu_node *) (pcMenuDat +
                                     sizeof(struct menu_node) * iMenuCnt++);
    pstMenuNd->sChildNo = stMenuRec.sChildNo;

    pstMenuNd->lGudRelat  = stMenuRec.lGudRelat;
    pstMenuNd->cMainMenu  = stMenuRec.cMainMenu;
    pstMenuNd->cPriviledge = stMenuRec.cPriviledge;
    pstMenuNd->lHelpOff   = stMenuRec.lHelpOff;
    strcpy(pstMenuNd->caTxnCode,stMenuRec.caTxnId);
  }  /*  while ((iRc = read(iMenuFd,&stMenuRec,sizeof(struct menu_node)) > 0) */
  close(iMenuFd);
  UCP_TRACE_END(sizeof(struct menu_node) * iMenuCnt);
}  /* MenuLoad(iSysMode,pcMenuDat) */


int
HlpLoad(iSysMode,pcHlpDat,pcHlpCnt)
int iSysMode;
char *pcHlpDat;
char *pcHlpCnt;
{
  int iRc;
  int iHlpFd;
  int iHlpNdCnt;
  int iHlpIdxCnt;
  char *pcHlpIdx;
  char caLastHlpNo[GUD_NO_LEN+1];
  struct help_node stHlpNd,*pstHlpNd;
  struct hlp_idx *pstHlpIdx;
  char caFlName[FILE_NAME_LEN];

  UCP_TRACE(P_HlpLoad);

  memset(caFlName,'\0',FILE_NAME_LEN);
  strcpy(caFlName,(char *) getenv("III_DIR"));
  strcat(caFlName,(char *) "/");

  if (iSysMode == CHINESE_MODE) {
    strcat(caFlName,HLP_FILE_C);
  }
  else {
    strcat(caFlName,HLP_FILE_E);
  }

  iRc = OpenFile(caFlName,&iHlpFd);
  if (iRc < 0) {
    sprintf(g_caMsg,"Call OpenFile() error iRc = %d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(iRc);
  }

  pcHlpIdx = pcHlpCnt + 4;
  pstHlpNd = (struct help_node *) pcHlpDat;
  iHlpNdCnt = 0;
  iHlpIdxCnt = 0;
  memset(caLastHlpNo,'\0',GUD_NO_LEN+1);
  while ((iRc = read(iHlpFd,&stHlpNd,sizeof(struct help_node))) > 0 ) {
    if (iRc != sizeof(struct help_node)) {
     sprintf(g_caMsg,"read HELP_FILE size = %d error,sizeof = %d",
                                         iRc,sizeof(struct help_node));
     DetErrRpt(FILE_SIZE_ERR,g_caMsg);
     UCP_TRACE_END(FILE_SIZE_ERR);
    } /* if (iRc != sizeof(struct help_node))  */
    pstHlpNd = (struct help_node *) (pcHlpDat + 
                                    sizeof(struct help_node) * iHlpNdCnt++);
    strcpy(pstHlpNd->caHlpNo,stHlpNd.caHlpNo);
    strcpy(pstHlpNd->caHlpLine,stHlpNd.caHlpLine);
    stHlpNd.caHlpNo[GUD_NO_LEN] = '\0';
    if (strcmp(stHlpNd.caHlpNo,caLastHlpNo) != 0) {
      strcpy(caLastHlpNo,stHlpNd.caHlpNo);
      pstHlpIdx = (struct hlp_idx *) (pcHlpIdx +
                                      sizeof(struct hlp_idx) * iHlpIdxCnt);
      strcpy(pstHlpIdx->caKey,stHlpNd.caHlpNo);
/* modified by wjc 1994/01/06 in Dalian */
      /*pstHlpIdx->lRecNo = iHlpIdxCnt++;*/ 
      iHlpIdxCnt++;
      pstHlpIdx->lRecNo = iHlpNdCnt-1;
    } /* if (strcmp(stHlpNd.hlp_no,caLastHlpNo) != 0) */ 
  } /* while ((iRc = read(iHlpFd,&stHlpNd,sizeof(struct help_node)) > 0 )  */
  memcpy(pcHlpCnt,&iHlpIdxCnt,4);
  close(iHlpFd);
  UCP_TRACE_END(sizeof(struct help_node) * iHlpNdCnt);
} /* HlpLoad(iSysMode,pcHlpDat,pcHlpCnt) */


int
MstLoad(iSysMode,pcMstDat,pcMstCnt)
int iSysMode;
char *pcMstDat;
char *pcMstCnt;
{
  int iRc;
  int iMstFd;
  int iMstNdCnt;
  char *pcMstAry;
  char caLastMstNo[GUD_NO_LEN+1];
  struct mst_node stMstNd,*pstMstNd;
  char caFlName[FILE_NAME_LEN];

  UCP_TRACE(P_MstLoad);

  memset(caFlName,'\0',FILE_NAME_LEN);
  strcpy(caFlName,(char *) getenv("III_DIR"));
  strcat(caFlName,(char *) "/");

  if (iSysMode == CHINESE_MODE) {
    strcat(caFlName,MST_FILE_C);
  }
  else {
    strcat(caFlName,MST_FILE_E);
  }

  iRc = OpenFile(caFlName,&iMstFd);
  if (iRc < 0) {
    sprintf(g_caMsg,"Call OpenFile() error iRc = %d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(iRc);
  }

  pcMstAry = pcMstCnt + 4;
  pstMstNd = (struct mst_node *) pcMstDat;
  iMstNdCnt = 0;
  while ((iRc = read(iMstFd,&stMstNd,sizeof(struct mst_node))) > 0 ) {
    if (iRc != sizeof(struct mst_node)) {
     sprintf(g_caMsg,"read MENU_FILE size = %d error,sizeof = %d",
                                         iRc,sizeof(struct mst_node));
     DetErrRpt(FILE_SIZE_ERR,g_caMsg);
     close(iMstFd);
    } /* if (iRc != sizeof(struct mst_node))  */
    pstMstNd = (struct mst_node *) (pcMstDat + 
                                    sizeof(struct mst_node) * iMstNdCnt++);
    memcpy(pcMstAry,stMstNd.caMstNo,MST_NO_LEN);
    pcMstAry += MST_NO_LEN;
    strncpy(pstMstNd->caMstNo,stMstNd.caMstNo,MST_NO_LEN);
    strncpy(pstMstNd->caMstCont,stMstNd.caMstCont,MST_CONT_LEN);
  } /* while ((iRc = read(iMstFd,&stMstNd,sizeof(struct mst_node)) > 0 )  */

  memcpy(pcMstCnt,&iMstNdCnt,4);
  close(iMstFd);
  UCP_TRACE_END(sizeof(struct mst_node) * iMstNdCnt);
} /* MstLoad(iSysMode,pcMstDat,pcMstCnt) */

int
NewCitLoad(pcCitDat)
char *pcCitDat;
{
  int iRc;
  int iWdCnt;
  int iBusiCnt;
  int iCitSize;
  int iLastCtfSize;
  int iInputLen;
  int iCtfFd;

  char *pcCurCit,*pcCitPos;
  char caDataBuf[SIF_SIZE],caDataCnv[SIF_SIZE];
  ctf_head *pstCtfHead;
  ctf_item *pstCtfItem;
  char caFlName[FILE_NAME_LEN];
  char caCtfRecBuf[sizeof(ctf_head)];
  
  UCP_TRACE(P_CitLoad);

  memset(caFlName,'\0',FILE_NAME_LEN);
  strcpy(caFlName,(char *) getenv("III_DIR"));
  strcat(caFlName,(char *) "/");
  strcat(caFlName,CTF_FILE);

  iRc = OpenFile(caFlName,&iCtfFd);
  if (iRc < 0) {
    sprintf(g_caMsg,"Open CTF_FILE = [%s] ,errno = %d",caFlName,errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(iRc);
  }

  pcCurCit = pcCitDat;
  iLastCtfSize = 0;
  iCitSize = 0;
  memset(caCtfRecBuf,'\0',sizeof(ctf_head));
  while ((iRc = read(iCtfFd,caCtfRecBuf,sizeof(ctf_head))) > 0) {
    if (iRc != sizeof(ctf_head)) {
      close(iCtfFd);
      sprintf(g_caMsg,"CitLoad() : read ctf_head =%d not completed",iRc);
      DetErrRpt(READ_FILE_ERR,g_caMsg);
      UCP_TRACE_END(READ_FILE_ERR);
    } /* if (iRc != sizeof(ctf_head))  */

    if (caCtfRecBuf[0] == M_CTF_HEAD ) {
      pcCurCit += iLastCtfSize;
      pstCtfHead = (ctf_head *) caCtfRecBuf;
      iLastCtfSize  = pstCtfHead->iCtfSize;
      iCitSize += iLastCtfSize;
    }
    else {
       pstCtfItem = (ctf_item *) caCtfRecBuf;

       if (pstCtfItem->cDatType != 'y') {
         switch (pstCtfItem->cDatType) {
           case 'q' :
           case 'r' :
           case 't' :
            iInputLen = pstCtfItem->iDatLen - pstCtfItem->iDotPos - 2;
            break;
           case 'f' :
           case 'g' :
           case 'h' :
            iInputLen = pstCtfItem->iDatLen - pstCtfItem->iDotPos - 1;
            break;
           case 'i' :
           case 'j' :
           case 'k' :
            iInputLen = pstCtfItem->iDatLen - 1;
            break;
           default  :
            iInputLen = pstCtfItem->iDatLen;
         } /* switch (pstCtfItem->dat_type) */

         memset(caDataBuf,'\0',SIF_SIZE);
         for (iWdCnt = 0; iWdCnt < iInputLen; iWdCnt++) {
           caDataBuf[iWdCnt] = pstCtfItem->cIniValue;
         } /* for (iWdCnt = 0; iWdCnt < iInputLen; iWdCnt++) */

         memset(caDataCnv,'\0',SIF_SIZE);
         iRc = DataCnv(pstCtfItem,caDataBuf,caDataCnv ,iWdCnt);
         if (iRc < 0) {
           close(iCtfFd);
           sprintf(g_caMsg,"DataCnv() error iRc=%d",iRc);
           ErrLog(1000,g_caMsg,RPT_TO_LOG,pstCtfItem,sizeof(ctf_item));
           ErrLog(1000,"dump caDataBuf",RPT_TO_LOG,caDataBuf,iWdCnt);
           UCP_TRACE_END(iRc);
         }
         else {
           pcCitPos = (char *) (pcCurCit + pstCtfItem->iCtfOffs);
           memcpy(pcCitPos, caDataCnv, pstCtfItem->iCtfLen);
         } /* if (iRc == -1) */

       }  /* if (pstItem->dat_type != 'y') */

    } /* if (caCtfRecBuf[0] == M_CTF_HEAD ) */

    memset(caCtfRecBuf,'\0',sizeof(ctf_head));
  } /* while ((iRc = read(iCtfFd,caCtfRecBuf,sizeof(ctf_head)) > 0) */

  close(iCtfFd);
  UCP_TRACE_END(iCitSize);
}  /* NewCitLoad(pcCitDat) */


int
OpenFile(pcFlName,piFlDp)
char *pcFlName;
int *piFlDp;
{
  UCP_TRACE(P_OpenFile);

  if ((*piFlDp = open(pcFlName,O_RDONLY,0666)) < 0) {
      sprintf(g_caMsg,"open %s file error, errno = %d",pcFlName,errno);
      DetErrRpt(OPEN_FILE_ERR,g_caMsg);
      UCP_TRACE_END(OPEN_FILE_ERR);
  }
  UCP_TRACE_END(0);
}
