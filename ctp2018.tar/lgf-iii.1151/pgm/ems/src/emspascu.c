/*
 *&N& File : emspascu.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int       PassWord()        Curses ���K�X�ˬd�D�禡(��ܿ�J�P����) 
 *&N&                                     
 *&N&    int       ChkPassWord()          ���K�X�禡 
 *&N&                                    
 *&N&   void       Get_Data()             �ѱK�X��J�����������J���
 *&N&                                     
 *&N&   void       Beep()                 ���~ĵ�ܩI�s
 *&N&                                     
 */

#include <signal.h>
#include <curses.h>
#include <signal.h>
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include "emctcwa.h"

#define NO_RECORD	1
#define NO_ITEM		2
#define MAX_DATA_LEN	20

/* Key Definition */
#define  CTL_P           16
#define  CTL_N           14
#define  CTL_L           12
#define  CTL_R           18
#define  CTL_I            9
#define  CTL_H            8
#define  CTL_D            4
#define  CTL_U           21
#define  CR              13
#define  ESC             27
#define  ENTER           0x0797  

struct stItem {
	int iPage;
	int iRow;
	int iCol;
	int (*Routine1)();
	int (*Routine2)();
	char caData[ MAX_DATA_LEN ];
	char cType;
	int iLength;
	char cAttribute;
	} stRecord[ NO_ITEM * NO_RECORD ] = {
            {1, 2, 10, NULL, NULL, "          ", 'c',10, 'e'},
            {1, 5, 10, NULL, NULL, "          ", 'c',10, 'e'},
        };

#define  PASSWORD_F    "iii/etc/tbl/emdpass.dat"
#define  READ_PASS_ERR                  -1

PassWord(pstMenu,iPassUsr)
struct stMenu *pstMenu;
int    iPassUsr;
{
  char  caId[128];
  char  caUname[128];
  char  caInPassWord[128];
  char  caEncrpPassWord[128];
  char  caOriPassWord[128];
  char  cPause;
  int   iRc,i,j;
  char caFileName[256];
  FILE *zPSfgid;
  struct IdPasswd  {
    char  caUname[128];
    char  caCryptPasswd[128];
  }stIdPasswd; 
  struct stMenu *pstSubMenu;
  char   caKeyBuf[256];

  if (iPassUsr == 0){  
    return(0);
  }

  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat((char *)caFileName, (char *)"/");
  strcat((char *)caFileName,  PASSWORD_F);
   
  /* open password file name */
  if((zPSfgid=fopen(caFileName,"r")) == NULL){
    printf("PassWord:open password file err!!");
    return(READ_PASS_ERR);
  } /* FOR if((zPSfgid=fopen(cFilename,"r")) == NULL) */

  fscanf(zPSfgid,"%2s\n",caId);

  pstSubMenu = (struct stMenu *) calloc( sizeof( struct stMenu ), 1 );
  pstSubMenu->pwWin = (WINDOW *) newwin(8, 22, 14, 58 );
  pstSubMenu->iNoRecord = NO_RECORD;
  pstSubMenu->pstNextMenu = NULL;
  pstSubMenu->pstItem = (struct stItem *) &stRecord;

  box(pstSubMenu->pwWin,'.','.');
  ShowStr(pstSubMenu,2,0," UserName:       ",'d');
  ShowStr(pstSubMenu,5,0," Password:       ",'d');
  DisplayData(pstSubMenu);

  for (i=0;i<3;i++) {

    Get_Data(0,caKeyBuf,pstSubMenu);
    strcpy(caUname,caKeyBuf);
    Get_Data(1,caKeyBuf,pstSubMenu);
    strcpy(caInPassWord,caKeyBuf);

    for (j=0;j<10;j++) {
      if (caUname[j] == ' ')      caUname[j] = '\0';
      if (caInPassWord[j] == ' ') caInPassWord[j] = '\0';
    }

    iRc = ChkPassWord(caId,caUname,caInPassWord);
    if (iRc != 1) {

      if (i < 2) {
        ShowMsg(pstMenu,22,20,"Password Error!!");
        ShowMsg(pstMenu,23,20,"Press any key to retry again.");
      }
      else {
        fclose(zPSfgid);
        ShowMsg(pstMenu,22,20,"Password Error!! Illegal User!!");
        ShowMsg(pstMenu,23,20,"Please Connecting with TPE Administrator.");
        DisplayMenu(pstMenu);
        wgetch(pstMenu->pwWin);
        EndTool(pstSubMenu);
        EndTool(pstMenu);
        exit(-1) ;
      }
      DisplayMenu(pstMenu);
      wgetch(pstMenu->pwWin);
      ShowStr(pstMenu,22,10,"                                            ",'n');
      ShowStr(pstMenu,23,10,"                                            ",'n');
      DisplayMenu(pstMenu);
    } /* FOR if (iRc != 1) */
    else { 
      if (iPassUsr == 2){  
        iRc = Chk2ndPassWord(caUname,pstSubMenu,pstMenu);
        switch(iRc) {
          case  1:
            break;
          case -9:
            ShowMsg(pstMenu,22,10,"The second user is the same as the first one!");
            ShowMsg(pstMenu,23,10,"Please Connecting with TPE Administrator.");
            DisplayMenu(pstMenu);
            wgetch(pstMenu->pwWin);
            EndTool(pstSubMenu);
            EndTool(pstMenu);
            exit(-1) ;
          case -1:
            ShowMsg(pstMenu,23,10,"The password file doesn't exist!! please check..");
            DisplayMenu(pstMenu);
            wgetch(pstMenu->pwWin);
            EndTool(pstSubMenu);
            EndTool(pstMenu);
            exit(-1) ;
        }
        break;
      }
      else 
      break;  /* iPassUsr == 1 */
    }
  } /* FOR for (i=0;i<3;i++) */

  fclose(zPSfgid);
  return(0) ;
}

int
ChkPassWord(pcaId,pcaUname,pcaPasswd)
char  *pcaId;
char  *pcaUname;
char  *pcaPasswd;
{
  char  caCrpPassWd[128];
  char  caUname[128];
  char  caPasswd[128];
  char  caFileName[256];
  char  caId[128];
  int   iRc;
  FILE *zPSfgid;

  /* open password file name */
  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat((char *)caFileName, (char *)"/");
  strcat((char *)caFileName,  PASSWORD_F);
  if((zPSfgid=fopen(caFileName,"r")) == NULL){
    printf("ChkPassWord:open password file err\n");
    return(-1);
  } /* FOR if((zPSfgid=fopen(cFilename,"r")) == NULL) */
  
  fscanf(zPSfgid,"%s \n",caId);

  iRc=fscanf(zPSfgid,"%s %s\n",caUname,caPasswd);

  strcpy(caCrpPassWd,crypt(pcaPasswd,pcaId));

  while (iRc != EOF) {
    if ( ( strcmp(caUname,pcaUname) == 0) &&
      ( strncmp(caCrpPassWd,caPasswd,13) == 0 ) ) {
      fclose(zPSfgid);
      return(1) ;
    }
    else {
      iRc=fscanf(zPSfgid,"%s %s\n",caUname,caPasswd);
    }
  }  /*  FOR while(iRc...)  */

  fclose(zPSfgid);
  return(0) ;
}

Get_Data(iWinno,pcaKey_Buf,pstMenu)
int  iWinno;
char *pcaKey_Buf;
struct stMenu *pstMenu;
{
  char caTmpBuf[256];
  char caShowBuf[256];
  int  i,j;
  char cChar;
  int  iKeyIn;
  int  iCurRow,iCurCol;
  int  iPcnt=0;

     memset(caTmpBuf,'\0',80);

     MvEdtItem(pstMenu,iWinno,A_UNDERLINE);
     while (1) {
       wrefresh( pstMenu->pwWin);
       iKeyIn = wgetch(pstMenu->pwWin);

       switch(iKeyIn)  {
         case 0x0797 :   /* ENTER */
         case CR :   /* ENTER */
           if (iWinno != 1) {
             for(j=0;j<10;j++) {
                cChar = mvwinch( pstMenu->pwWin,pstMenu->pstItem[ iWinno ].iRow,
                                 pstMenu->pstItem[ iWinno ].iCol+j);
                pcaKey_Buf[j] = cChar;
             }
             pcaKey_Buf[10] = 0x0;
           }
           else {
             pcaKey_Buf[iPcnt] = 0x0;
           }
           return(0);
         case KEY_LEFT :
           getyx( pstMenu->pwWin, iCurRow, iCurCol );
           if ( iCurCol > pstMenu->pstItem[ iWinno ].iCol ) {
             wmove( pstMenu->pwWin, iCurRow, iCurCol - 1 );
           }
           else {
             Beep();
           }
           break;
         case KEY_RIGHT :
           getyx( pstMenu->pwWin, iCurRow, iCurCol );
           if ( iCurCol < pstMenu->pstItem[ iWinno ].iCol +
                          pstMenu->pstItem[ iWinno ].iLength - 1 ) {
             wmove( pstMenu->pwWin, iCurRow, iCurCol + 1 );
           }
           else {
             Beep();
           }
           break;
         case 0x04 :    /* Ctrl + d */
           DeleteCh( pstMenu, iWinno );
           break;
         case 0x15 :    /* Ctrl + u */
           Undo( pstMenu, iWinno );
           break;
         case '\x1b' :  /* ESC */
           Beep();
           break;
         default :
           if (iWinno != 1) {
             AddCh( pstMenu, iWinno, iKeyIn, 0 );
           }
           else {
             AddCh( pstMenu, iWinno, 42, 0 ); /* add(*) to the password field */
             pcaKey_Buf[iPcnt] = (char) iKeyIn;
             iPcnt++;
           }
           break;
       } /* FOR switch(iKeyIn) */
     } /* FOR while(1)  */
}

Beep()
{
  printf("\a\a\a");
}

int
Chk2ndPassWord(pcaFirstName,pstSubMenu,pstMenu)
char  *pcaFirstName;         /* the name of the first user */
struct stMenu *pstSubMenu;
struct stMenu *pstMenu;
{
  char  caCrpPassWd[128];
  char  caUname[128];
  char  caPasswd[128];
  char  caFileName[256];
  char  caId[128];
  char  caInPassWord[128];
  char  caKeyBuf[256];
  char  cPause;
  int   iRc,i,j;
  FILE *zPSfgid;

  /* open password file name */
  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat((char *)caFileName, (char *)"/");
  strcat((char *)caFileName,  PASSWORD_F);
  if((zPSfgid=fopen(caFileName,"r")) == NULL){
    printf("ChkPassWord:open password file err\n");
    return(-1);
  } /* FOR if((zPSfgid=fopen(cFilename,"r")) == NULL) */
  
  fscanf(zPSfgid,"%2s\n",caId);

  box(pstSubMenu->pwWin,'.','.');
  ShowStr(pstSubMenu,2,0," Another :       ",'d');
  ShowStr(pstSubMenu,5,0," Password:       ",'d');
  DisplayData(pstSubMenu);

  for (i=0;i<3;i++) {
    Get_Data(0,caKeyBuf,pstSubMenu);
    strcpy(caUname,caKeyBuf);

    for (j=0;j<10;j++) {
      if (caUname[j] == ' ')      caUname[j] = '\0';
    }

    if ( ( strcmp(caUname,pcaFirstName) == 0) ) { 
      fclose(zPSfgid);    /* the 2nd name is the same as the 1st one */
      return(-9) ;
    }

    Get_Data(1,caKeyBuf,pstSubMenu);
    strcpy(caInPassWord,caKeyBuf);

    for (j=0;j<10;j++) {
      if (caInPassWord[j] == ' ') caInPassWord[j] = '\0';
    }

    iRc = ChkPassWord(caId,caUname,caInPassWord);
    if (iRc != 1) {

      if (i < 2) {
        ShowMsg(pstMenu,22,10,"Second User Password Error!!");
        ShowMsg(pstMenu,23,10,"Press any key to retry again.");
      }
      else {
        fclose(zPSfgid);
        ShowMsg(pstMenu,22,10,"Second User Password Error!! Illegal User!!");
        ShowMsg(pstMenu,23,10,"Please Connecting with TPE Administrator.");
        DisplayMenu(pstMenu);
        wgetch(pstMenu->pwWin);
        EndTool(pstSubMenu);
        EndTool(pstMenu);
        exit(-8) ;
      }
      DisplayMenu(pstMenu);
      wgetch(pstMenu->pwWin);
      ShowStr(pstMenu,22,10,"                                            ",'n');
      ShowStr(pstMenu,23,10,"                                            ",'n');
      DisplayMenu(pstMenu);
    } /* FOR if (iRc != 1) */
    else  break;
  } /* for (i=0;i<3;i++) */

  return(1) ;
}
