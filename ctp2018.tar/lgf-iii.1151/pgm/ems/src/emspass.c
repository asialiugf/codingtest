/*
 *&N& File : emspass.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int       PassWord()         ���q���K�X�ˬd�D�禡(��ܿ�J�P����) 
 *&N&                                     
 *&N&    int       ChkPassWord()          ���K�X�禡 
 *&N&                                    
 *&N&   void       PassShowData()         �Ѥ@�Τ@�ɭ���X�r��
 *&N&                                     
 *&N&   void       EchoOff()              Disable echo ���\��
 *&N&                                     
 *&N&   void       EchoOn()               Enable echo ���\��
 *&N&                                     
 */

#include <stdio.h>
#include <errno.h>
#include <fcntl.h>

#define  PASSWORD_F    "iii/etc/tbl/emdpass.dat"
#define  USER_NAME       "\n ..Username:" 
#define  SECOND_USER_NAME   "\n ..Another username:" 
#define  PASS_WD         "\n ..Password:" 
#define  SECOND_PASS_WD     "\n ..Another password:" 
#define  WAIT            "\n ....wait for a moment...\n" 
#define  READ_PASS_ERR                  -1

PassWord(iPassUsr)
int  iPassUsr;
{
  char  caId[128];
  char  caUname[128];
  char  caInPassWord[128];
  char  caEncrpPassWord[128];
  char  caOriPassWord[128];
  char  cPause;
  int   iRc,i;
  char caFileName[256];
  FILE *zPSfgid;
  struct IdPasswd  {
    char  caUname[128];
    char  caCryptPasswd[128];
  }stIdPasswd; 


  if (iPassUsr == 0){  
    return(0);
  }

  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat((char *)caFileName, (char *)"/");
  strcat((char *)caFileName,  PASSWORD_F);
   
  /* open password file name */
  if((zPSfgid=fopen(caFileName,"r")) == NULL){
    PassShowData('0',"PassWord:open password file err!!");
    return(READ_PASS_ERR);
  } /* FOR if((zPSfgid=fopen(cFilename,"r")) == NULL) */

  fscanf(zPSfgid,"%2s\n",caId);

  for (i=0;i<3;i++) {
    PassShowData('0',USER_NAME);
    scanf("%s",caUname);
    PassShowData('0',PASS_WD);
    EchoOff();
    scanf("%s",caInPassWord);
    EchoOn();
    scanf("%c",&cPause);
    PassShowData('0',WAIT);

    iRc = ChkPassWord(caId,caUname,caInPassWord);
    if (iRc != 1) {

      if (i < 2) {
        PassShowData('0',"\nPassword Error!!\n");
        PassShowData('0',"\nPlease retry again.\n");
      }
      else {
        fclose(zPSfgid);
        PassShowData('0',"\nPassword Error!! Illegal User!!\n");
        PassShowData('0',"\nPlease Connecting with TPE Administrator.\n");
        exit(-1) ;
      }

    } /* FOR if (iRc != 1) */
    else { 
      if (iPassUsr == 2){  
        iRc = Chk2ndPassWord(caUname);
        switch(iRc) {
          case  1:
            break;
          case -9:
            PassShowData('0',"\nThe second user is the same as the first one!\n");
            PassShowData('0',"\nPlease Connecting with TPE Administrator.\n");
            exit(-1) ;
          case -1:
            PassShowData('0',"\nThe password file doesn't exist!! please check..\n");
            exit(-1) ;
        }
        break;
      }
      else 
      break;  /* iPassUsr == 1 */
    }
  } /* FOR for (i=0;i<3;i++) */

  fclose(zPSfgid);
  return(0) ;
}

int
ChkPassWord(pcaId,pcaUname,pcaPasswd)
char  *pcaId;
char  *pcaUname;
char  *pcaPasswd;
{
  char  caCrpPassWd[128];
  char  caUname[128];
  char  caPasswd[128];
  char  caFileName[256];
  char  caId[128];
  int   iRc;
  FILE *zPSfgid;

  /* open password file name */
  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat((char *)caFileName, (char *)"/");
  strcat((char *)caFileName,  PASSWORD_F);
  if((zPSfgid=fopen(caFileName,"r")) == NULL){
    PassShowData('0',"ChkPassWord:open password file err\n");
    return(-1);
  } /* FOR if((zPSfgid=fopen(cFilename,"r")) == NULL) */
  
  fscanf(zPSfgid,"%s\n",caId);

  iRc=fscanf(zPSfgid,"%s %s\n",caUname,caPasswd);

  strcpy(caCrpPassWd,crypt(pcaPasswd,pcaId));

  while (iRc != EOF) {
    if ( ( strcmp(caUname,pcaUname) == 0) &&
      ( strncmp(caCrpPassWd,caPasswd,13) == 0 ) ) {
      fclose(zPSfgid);
      return(1) ;
    }
    else {
      iRc=fscanf(zPSfgid,"%s %s\n",caUname,caPasswd);
    }
  }  /*  FOR while(iRc...)  */

  fclose(zPSfgid);
  return(0) ;
}

int
Chk2ndPassWord(pcaFirstName)
char  *pcaFirstName;         /* the name of the first user */
{
  char  caCrpPassWd[128];
  char  caUname[128];
  char  caPasswd[128];
  char  caFileName[256];
  char  caId[128];
  char  caInPassWord[128];
  char  cPause;
  int   iRc,i;
  FILE *zPSfgid;

  /* open password file name */
  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat((char *)caFileName, (char *)"/");
  strcat((char *)caFileName,  PASSWORD_F);
  if((zPSfgid=fopen(caFileName,"r")) == NULL){
    PassShowData('0',"ChkPassWord:open password file err\n");
    return(-1);
  } /* FOR if((zPSfgid=fopen(cFilename,"r")) == NULL) */
  
  fscanf(zPSfgid,"%2s\n",caId);

  for (i=0;i<3;i++) {
    PassShowData('0',SECOND_USER_NAME);
    scanf("%s",caUname);
    if ( ( strcmp(caUname,pcaFirstName) == 0) ) { 
      fclose(zPSfgid);    /* the 2nd name is the same as the 1st one */
      return(-9) ;
    }
    PassShowData('0',SECOND_PASS_WD);
    EchoOff();
    scanf("%s",caInPassWord);
    EchoOn();
    scanf("%c",&cPause);
    PassShowData('0',WAIT);

    iRc = ChkPassWord(caId,caUname,caInPassWord);
    if (iRc != 1) {

      if (i < 2) {
        PassShowData('0',"\nSecond User Password Error!!\n");
        PassShowData('0',"\nPlease retry again.\n");
      }
      else {
        fclose(zPSfgid);
        PassShowData('0',"\nSecond User Password Error!! Illegal User!!\n");
        PassShowData('0',"\nPlease Connecting with TPE Administrator.\n");
        exit(-8) ;
      }

    } /* FOR if (iRc != 1) */
    else  break;
  } /* for (i=0;i<3;i++) */

  return(1) ;
}

#define  DISPLAY   '0'
#define  COMMAND   '1'

/*
 *&N& ROUTINE NAME:PassShowData()
 *&A& ARGUMENTS:
 *&A&    NAME         TYPE            DESCRIPTION
 *&A& -------------  ------  -------------------------------
 *&A&  pcaData       char *    ����ܪ��r��
 *&A&
 *&R& RETURN VALUE(S):
 *&R&  0 : ��ܶǤJ��Ʀ��\
 *&R&
 *&D& DESCRIPTION
 *&D& �ھڳq�T��w�����ܼ�( �t��_PROTOCOL ) 
 *&D& �I�s�����A�ȵ{���e�X EMS ����ܪ��r��
 *&D&
 */
int
PassShowData(cOp,pcaData)
char  cOp;
char  *pcaData;
{
    switch(cOp) {
      case DISPLAY:
        printf("%s",pcaData);
        return(0);
      case COMMAND:
        system(pcaData);
        return(0);
    }
        
}

EchoOff()
{
  system("stty -echo");
}
  
EchoOn()
{
  system("stty echo");
}
