/*
 *&N& ROUTINE NAME: main  
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&           
 *&R& RETURN VALUES:
 *&R&           
 *&R&           
 *&D& DESCRIPTION:           
 *&D&     ���{���i�� EMS �s�Ψөw���x�s�t�� CWA ����Ʃ� log �ؿ����ɮפ�.
 */

#include <errno.h>
#include "cwa.h"
#include "errlog.h"
#include "emctldef.h"

#define  CWA_SHM_KEY    "CWA_SHM_KEY"
#define  CONFIG_FILE    "iii/etc/tbl/config.dat"

int        g_iCwaKey;
extern int g_iBitSize=0;

main(int argc,char **argv)
{
  int    iRc;
  struct CwaCtl stCwaCtl;
  struct CwaCreatIobuf stCCBuf;
  char   caFileName[ FILE_NAME_LEN + 1 ];
  char   *pcaBitTbl, caBuf[10];

  SignlHdl();

  sprintf (caFileName, "%s/%s", (char *)getenv("III_DIR"), CONFIG_FILE);
  iRc = InitCnfTbl(caFileName);
  if ( iRc < 0 ){
    sprintf (g_caMsg,"<EMS> Failure to InitCnfTbl!");
    printf ("%s\n", g_caMsg);
    ErrLog (1000,g_caMsg,RPT_TO_LOG,0,0);
    exit (-1);
  }

  g_iCwaKey = GetCnfValue( CWA_SHM_KEY );
  if (g_iCwaKey < 0){
    sprintf (g_caMsg,"<EMS> Failure to GetCnfValue!");
    printf ("%s\n", g_caMsg);
    ErrLog (1000,g_caMsg,RPT_TO_LOG,0,0);
    exit (-2);
  }

  stCwaCtl.cFunCode = CWA_GET_ID;
  stCCBuf.iShmKey = g_iCwaKey;
  stCCBuf.iSemKey = g_iCwaKey;

  iRc = CwaCtlFac(&stCwaCtl,&stCCBuf);

  strncpy (caBuf, &stCwaCtl.caRtnCode, 3);
  iRc = atoi(caBuf);

  if (iRc != CWA_NORMAL) {
    sprintf (g_caMsg,"<EMS> Failure to get CWA id with key [0x%0x]!",
             g_iCwaKey);
    printf ("%s\n", g_caMsg);
    ErrLog (1000,g_caMsg,RPT_TO_LOG,0,0);
    sprintf (g_caMsg,
             "<EMS> Check to see if TPE has been started up completely!\n");
    printf ("%s\n", g_caMsg);
    ErrLog (1000,g_caMsg,RPT_TO_LOG,0,0);
    exit (-3);
  }

  stCwaCtl.cFunCode = CWA_ATTACH;
  stCCBuf.iShmKey = g_iCwaKey;
  stCCBuf.iSemKey = g_iCwaKey;
  
  iRc = CwaCtlFac(&stCwaCtl,&stCCBuf);
  if (iRc != CWA_NORMAL) {
    sprintf (g_caMsg,"<EMS> Failure to attach CWA with key [0x%0x]!",
             g_iCwaKey);
    printf ("%s\n", g_caMsg);
    ErrLog (1000,g_caMsg,RPT_TO_LOG,0,0);
    exit (-4);
  }

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_BIT_START;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcaBitTbl);
  if (iRc != 0) {
    sprintf (g_caMsg,"<EMS> Failure to get BIT pointer!");
    printf ("%s\n", g_caMsg);
    ErrLog (1000,g_caMsg,RPT_TO_LOG,0,0);
    exit (-5);
  }

  memcpy (&g_iBitSize, &pcaBitTbl[4], 4); 

  iRc = SaveCwaToFile();
  if (iRc != 0) {
    sprintf (g_caMsg,"<EMS> Failure to save CWA to file! (errno:%d)", iRc);
    printf ("%s\n", g_caMsg);
    /* TCC
    ErrLog (40000,g_caMsg,RPT_TO_LOG,0,0);
    */
    ErrLog (1000,g_caMsg,RPT_TO_LOG,0,0);
  }

  sprintf (g_caMsg, "<EMS> Execute [%s] to save CWA to file! (Size:%d)",
           argv[0], g_iBitSize);
  ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
  exit(0);
}
