#include <errno.h>
#include "cwa.h"
#include "errlog.h"
#include "emctldef.h"

#define  CWA_MODNO    4
#define  TXN_ENABLE   0x0200
#define  TXN_DISABLE  ~TXN_ENABLE & 0x0FFFF

extern int g_iBitSize;
int g_iConsole=-1;

/*
 *&N& ROUTINE NAME: SaveCwaToFile  
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&           
 *&R& RETURN VALUES:
 *&R&           
 *&R&           
 *&D& DESCRIPTION:           
 *&D&     ���{�����@�w�ɪ����A��,�i�� EMS �s�Ψөw���x�s�t�� CWA �����
 *&D&     �� log  �ؿ����ɮפ�
 */

SaveCwaToFile()
{
  int    iSaveSize;
  short  sSaveStatus;
  int    iRc;
  static struct SSA    *pstSsa;
  static char   *pcaBitTbl;
  static sg_cFirst = 'y';
  struct CwaCtl stCwaCtl;
  struct CwaCreatIobuf stCCBuf;
  int    iFd;
  char   caFileName[ FILE_NAME_LEN + 1 ];
  
  if (sg_cFirst == 'y'){
    /* attach SSA share memory */
    stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
    stCwaCtl.cSegCode = CWA_SEG_SSA;
    iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);
  
    if (iRc != 0) {
      sprintf(g_caMsg,
      "<EMS> Failure to get SSA pointer in SaveCwaToFile (iRc:%d)",iRc);
      printf ("%s\n", g_caMsg);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      if (g_iConsole > 0)
         ErrLog (0, g_caMsg, RPT_TO_CON, 0, 0);
      return (iRc);
    }

    stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
    stCwaCtl.cSegCode = CWA_SEG_BIT_START;
    iRc = CwaLowCtlFac(&stCwaCtl,&pcaBitTbl);
    if (iRc != 0) {
      sprintf (g_caMsg, "<EMS> Failure to get BIT pointer!");
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      if (g_iConsole > 0)
         ErrLog (0, g_caMsg, RPT_TO_CON, 0, 0);
      return (iRc);
    }
    sg_cFirst = 'n';
  }

  /*
  iSaveSize = sizeof(struct SSA) + sizeof(struct SPA) + MAX_BIT_SIZE ;
  */
/* TCC
  iSaveSize = sizeof(struct SSA) + sizeof(struct SPA) + g_iBitSize;
*/
  iSaveSize = sizeof(struct SSA) + sizeof(struct SPA);
  
  sSaveStatus = pstSsa->sSysStatus;
  pstSsa->iDumpSeqNo = (pstSsa->iDumpSeqNo + 1) % CWA_MODNO ;
 
  if (pstSsa->iDumpSeqNo % 2) {
    sprintf(caFileName,"%s/%s",(char *) getenv("III_DIR"),SBCWA0_F);
  }else{
    sprintf(caFileName,"%s/%s",(char *) getenv("III_DIR"),SBCWA1_F);
  }

  iFd = creat(caFileName,0600); 
  if (iFd != -1){
/* TCC
    iRc = write(iFd,pstSsa,iSaveSize);
    if (iRc != iSaveSize){
      sprintf(g_caMsg,
      "<EMS> Failure to write file [%s]! (errno:%d)", caFileName, errno);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      if (g_iConsole > 0)
         ErrLog (0, g_caMsg, RPT_TO_CON, 0, 0);
      close(iFd);
      return (errno);
    }
*/
    iRc = write(iFd,pstSsa,iSaveSize);
    if (iRc != iSaveSize){
      sprintf(g_caMsg,
      "<EMS> Failure to write SSA/SPA into file [%s]! (errno:%d)",
      caFileName, errno);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      if (g_iConsole > 0)
         ErrLog (0, g_caMsg, RPT_TO_CON, 0, 0);
      close(iFd);
      if (pstSsa->sSysStatus & TXN_ENABLE)
      {
        pstSsa->sSysStatus &= TXN_DISABLE;
        sprintf (g_caMsg, "<EMS> Disable TXN_ENABLE bit! [0x%0x]",
                 pstSsa->sSysStatus&0x0FFFF);
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      }
      return (errno);
    }

    iRc = write(iFd,pcaBitTbl,g_iBitSize);
    if (iRc != g_iBitSize){
      sprintf(g_caMsg,
      "<EMS> Failure to write BIT into file [%s]! (errno:%d)",
      caFileName, errno);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      if (g_iConsole > 0)
         ErrLog (0, g_caMsg, RPT_TO_CON, 0, 0);
      close(iFd);
      if (pstSsa->sSysStatus & TXN_ENABLE)
      {
        pstSsa->sSysStatus &= TXN_DISABLE;
        sprintf (g_caMsg, "<EMS> Disable TXN_ENABLE bit! [0x%0x]",
                 pstSsa->sSysStatus&0x0FFFF);
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      }
      return (errno);
    }
  }
  else {
    sprintf (g_caMsg,
    "<EMS> Failure to create file [%s]! (errno:%d)", caFileName, errno);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    if (g_iConsole > 0)
       ErrLog (0, g_caMsg, RPT_TO_CON, 0, 0);
    if (pstSsa->sSysStatus & TXN_ENABLE)
    {
      pstSsa->sSysStatus &= TXN_DISABLE;
      sprintf (g_caMsg, "<EMS> Disable TXN_ENABLE bit! [0x%0x]",
               pstSsa->sSysStatus&0x0FFFF);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    }
    return (errno);
  }

  /* TCC: 1996/09/12 */
  fsync (iFd);
  
  close(iFd);

  /* TCC: 1996/09/12 */
  /*
  sync();
  sync();
  */
  if (!(pstSsa->sSysStatus & TXN_ENABLE))
  {
    pstSsa->sSysStatus |= TXN_ENABLE;
    sprintf (g_caMsg, "<EMS> Enable TXN_ENABLE bit! [0x%0x]",
             pstSsa->sSysStatus&0x0FFFF);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
  }
  pstSsa->sSysStatus |= TXN_ENABLE;

  return(0);
}
