/*
 *&N& File : emstxpre.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int       TxPreHdl()             ����Ұʫe���e�m�B�z
 *&N&                                     (�ҰʬY�Ǳ������e�B�z���{��)
 *&N&                                     (�p   Load��ACIF.....    etc )
 */

#include  <stdio.h>
#include  <errno.h>
#include  <sys/wait.h>

#include  "cwa.h"
#include  "errlog.h"
#include  "emctxpre.h"
#include  "emcpgdef.h"

extern int  errno;
extern char *sys_errlist[]; 

/*
 *&N& ROUTINE NAME: TxPreHdl()
 *&A& ARGUMENTS:
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&   ����ƥΥH�ǳ� TPE ����Ұʫe������:
 *&D&   ����ƥD�n�\��O�� sg_staTxPreTbl �������e,�Ұʬ۹�����������,�H��
 *&D&   TPE �����}���e���@�ǻݭn
 *&D&
 *&D&   �U�C���Τ��@,�|�Ϧ���ư��楢��
 *&D&       1. Fork�@�Ӥl�{������
 *&D&       2. ����(Execl)�@�Ӥl�{������
 *&D&
 */

TxPreHdl(char *pcErrStep)
{
  FILE   *zTxPre;
  int    i, j, iRc, iTblSize, iChildPid;
  int    iStatus, iWaitCode;
  short  sStatus;
  char   caExePath[MAX_EXEC_PATH_LEN], caFlName[FILE_NAME_LEN];
  char   caSysStatus[10], caOperateMode[10];
  char   caBuf [256], *pcaToken;
  struct CwaCtl stCwaCtl;
  struct SSA *pstSsa;

  UCP_TRACE( P_TxPreHdl );

  *pcErrStep = '0';
  EmsShowData('0',"TPE Preprocessing Starting up....\n");
  sprintf (caFlName, "%s/%s", (char *)getenv("III_DIR"), TXNPRE_FILE);

  if ((zTxPre = fopen(caFlName, "r")) == NULL)
  {
    sprintf (g_caMsg, "<EMS> Failure to open file [%s]! (errno:%d==>%s)",
             caFlName, errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END (OPEN_TXNPREFILE_ERR);
  }

  i = 0;
  memset (caBuf, 0, sizeof(caBuf));
  fgets (caBuf, sizeof (caBuf), zTxPre);

  do
  {
     for (j=0; j<sizeof(caBuf); j++)
     if (caBuf[j] == '\n')
     {
       caBuf[j] = 0;
       break;
     }

     pcaToken = (char *)strtok (caBuf, " \t\n");

     if (pcaToken != NULL && pcaToken[0] != '#')
     {
        if (sizeof(sg_staTxPreTbl[i].caModuleName) <= strlen (pcaToken))
        {
          sprintf (g_caMsg,
          "<EMS> Illegal parameter [%s] in line [%d] of file [%s].(errno:%d)",
          pcaToken, i, caFlName, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          printf ("%s\n", g_caMsg);
          fclose (zTxPre);
          UCP_TRACE_END (TXNPREFILE_FORMAT_ERR);
        }
        memcpy (sg_staTxPreTbl [i].caModuleName, pcaToken, strlen(pcaToken));

        pcaToken = (char *)strtok (NULL, " \t\n");

        if (pcaToken == NULL)
        {
          sprintf (g_caMsg,
          "<EMS> Illegal parameter [%s] in line [%d] of file [%s].(errno:%d)",
          pcaToken, i, caFlName, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          printf ("%s\n", g_caMsg);
          fclose (zTxPre);
          UCP_TRACE_END (TXNPREFILE_FORMAT_ERR);
        }
        else
        if ( (strcmp(pcaToken, "ONLINE") != 0) && 
             (strcmp(pcaToken, "BATCH")  != 0) &&
             (strcmp(pcaToken, "BOTH")   != 0) )
        {
          sprintf (g_caMsg,
          "<EMS> Illegal parameter [%s] in line [%d] of file [%s].(errno:%d)",
          pcaToken, i, caFlName, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          printf ("%s\n", g_caMsg);
          fclose (zTxPre);
          UCP_TRACE_END (TXNPREFILE_FORMAT_ERR);
        }
        memcpy (sg_staTxPreTbl [i].caOperatingMode, pcaToken, strlen(pcaToken));

        pcaToken = (char *)strtok (NULL, " \t\n");

        if (pcaToken == NULL)
        {
          sprintf (g_caMsg,
          "<EMS> Illegal parameter [%s] in line [%d] of file [%s].(errno:%d)",
          pcaToken, i, caFlName, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          printf ("%s\n", g_caMsg);
          fclose (zTxPre);
          UCP_TRACE_END (TXNPREFILE_FORMAT_ERR);
        }
        else
        if ( (strcmp(pcaToken, "NORMAL")  != 0) && 
             (strcmp(pcaToken, "RESTART") != 0) &&
             (strcmp(pcaToken, "BOTH")    != 0) )
        {
          sprintf (g_caMsg,
          "<EMS> Illegal parameter [%s] in line [%d] of file [%s].(errno:%d)",
          pcaToken, i, caFlName, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          printf ("%s\n", g_caMsg);
          fclose (zTxPre);
          UCP_TRACE_END (TXNPREFILE_FORMAT_ERR);
        }
        memcpy (sg_staTxPreTbl [i].caSystemStatus, pcaToken, strlen(pcaToken));

        pcaToken = (char *)strtok (NULL, " \t\n");

        if (pcaToken == NULL)
        {
          sprintf (g_caMsg,
          "<EMS> Illegal parameter [%s] in line [%d] of file [%s].(errno:%d)",
          pcaToken, i, caFlName, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          printf ("%s\n", g_caMsg);
          fclose (zTxPre);
          UCP_TRACE_END (TXNPREFILE_FORMAT_ERR);
        }
        else
        if (sizeof(sg_staTxPreTbl[i].caShellPgmName) <= strlen (pcaToken))
        {
          sprintf (g_caMsg,
          "<EMS> Illegal parameter [%s] in line [%d] of file [%s].(errno:%d)",
          pcaToken, i, caFlName, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          printf ("%s\n", g_caMsg);
          fclose (zTxPre);
          UCP_TRACE_END (TXNPREFILE_FORMAT_ERR);
        }
        memcpy (sg_staTxPreTbl [i].caShellPgmName, pcaToken, strlen(pcaToken));

        i++;
     }
     fgets (caBuf, sizeof (caBuf), zTxPre);
  }  while (!feof(zTxPre));


  iTblSize = i;

  /*
  for (i=0; i<iTblSize; i++) 
  {
    if (!( (strncmp(sg_staTxPreTbl[i].caOperatingMode, "ONLINE", 6) == 0) || 
         (strncmp(sg_staTxPreTbl[i].caOperatingMode, "BATCH", 5) == 0) || 
         (strncmp(sg_staTxPreTbl[i].caOperatingMode, "BOTH", 4) == 0) )) 
    {
      sprintf (g_caMsg, "<EMS> Illegal operating mode [%s] defined in [%s].",
               sg_staTxPreTbl[i].caOperatingMode, caFlName);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      UCP_TRACE_END (OPERATE_MODE_ERR);
    }

    if (!( (strncmp(sg_staTxPreTbl[i].caSystemStatus, "NORMAL", 6) == 0) || 
         (strncmp(sg_staTxPreTbl[i].caSystemStatus, "RESTART", 7) == 0) || 
         (strncmp(sg_staTxPreTbl[i].caSystemStatus, "BOTH", 4) == 0) )) 
    {
      sprintf (g_caMsg, "<EMS> Illegal system status [%s] defined in [%s].",
               sg_staTxPreTbl[i].caSystemStatus, caFlName);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      UCP_TRACE_END (SYSTEM_STATUS_ERR);
    }

  }
  */

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac (&stCwaCtl, &pstSsa);

  if (iRc != 0) 
  {
    UCP_TRACE_END(iRc);
  }

  sStatus = pstSsa->sSysStatus;
  
  if ( !(sStatus & ONLINE_CLOSE) ) 
  {
    strcpy (caOperateMode, "ONLINE");
    ErrLog (10, "<EMS> TPE operation mode : [ONLINE]", RPT_TO_LOG, 0, 0);
  }
  else 
  {
    strcpy (caOperateMode, "BATCH");
    ErrLog (10, "<EMS> TPE operation mode : [BATCH]", RPT_TO_LOG, 0, 0);
  }

  if ( !(sStatus & SYSTEM_RESTART) ) 
  {
    strcpy (caSysStatus, "NORMAL");
    ErrLog (10, "<EMS> TPE system status : [NORMAL]", RPT_TO_LOG, 0, 0);
  }
  else 
  {
    strcpy (caSysStatus, "RESTART");
    ErrLog (10, "<EMS> TPE system status : [RESTART]", RPT_TO_LOG, 0, 0);
  }

/*
  if ( !(sStatus & SYSTEM_STARTED) ) 
*/
  {
    for (i = 0; i < iTblSize; i ++)
    {
      if ( (strcmp(sg_staTxPreTbl[i].caOperatingMode, "BOTH") == 0) || 
           (strcmp(sg_staTxPreTbl[i].caOperatingMode, caOperateMode) == 0) ) 
      {
        if ( (strcmp(sg_staTxPreTbl[i].caSystemStatus, "BOTH") == 0) || 
             (strcmp(sg_staTxPreTbl[i].caSystemStatus, caSysStatus) == 0) ) 
        {
          sprintf (caExePath, "%s/iii/bin/exe/%s", 
                   (char *) getenv("III_DIR"), 
                   sg_staTxPreTbl[ i ].caShellPgmName);

          if ((iChildPid=fork()) == 0 ) 
          {
            iRc = execlp(caExePath, caExePath, (char *)0);
            if (iRc != 0)
            {
              sprintf (g_caMsg,
              "<EMS> Failure to fork & execute file [%s].(errno:%d==>%s)",
              caExePath, errno, sys_errlist[errno]);
              ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
              printf ("\n%s\n", g_caMsg);
              exit (SHELL_EXEC_ERR);
            }
          }
          else
          {
            if (iChildPid == -1) 
            {
              sprintf (g_caMsg,
              "<EMS> Failure to fork file [%s].(errno:%d==>%s)",
              caExePath, errno, sys_errlist[errno]);
              ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
              UCP_TRACE_END (SHELL_FORK_ERR);
            }
          }

          iWaitCode = wait(&iStatus);
          
          while ( (iWaitCode != iChildPid) && (iWaitCode != -1) );

          if (iStatus == 0 && iWaitCode != -1)
          {
            sprintf (g_caMsg,
            "<EMS> Transaction preprocessing module [%s] forked & executed!",
            caExePath);
            ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          }
          else
          {
            sprintf (g_caMsg,
            "<EMS> Transaction preprocessing module [%s] ends abnormally!",
            caExePath);
            ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
            printf ("\n%s\n", g_caMsg);
            UCP_TRACE_END (SHELL_EXEC_ERR);        
          }

        }
      } 
    }
  }

  UCP_TRACE_END (0);
}
