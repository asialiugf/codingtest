/*
 *&N& ROUTINE NAME: main  
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&           
 *&R& RETURN VALUES:
 *&R&           
 *&R&           
 *&D& DESCRIPTION:           
 *&D&     ����Ƭ����Һ޲z�l�t�ΥD�{��, �t�d�إߥ�����ҤΥ����������.
 *&D&           
 */

/* ---------------------- INCLUDE FILES DECLARATION ------------------- */
#include	"errlog.h"
#include	"emcpgdef.h"
#include	"emctldef.h"
#include	"emcenvhl.h"
/* -------------------------------------------------------------------- */


/* ------------------------- CONSTANT DEFINITION ---------------------- */

#define		UCP_SYSTEM                 'S'
#define		EMS_SUB_SYSTEM             '1'
#define		ENVSETUP_STEP              '1'
#define		TPEIFSET_STEP              '2'
#define		TXPREHDL_STEP              '3'
#define		SYSSTART_STEP              '4'
#define		MASERVER_STPE              '5'

#define         BATCH_SAVECWA_TIME         "BATCH_SAVECWA_TIME"
#define         SAVECWA_TIME_ERR           "SAVECWA_TIME_ERR"

/* -------------------------------------------------------------------- */

/* ----------------- STATIC GLOBAL VARIABLES DECLARATION -------------- */

/* -------------------------------------------------------------------- */

/* ------ CALLED FUNCTION AND SUBROUTINE PROTOTYPE DECLARATIONS ------- */

/* -------------------------------------------------------------------- */
int g_iCtfKey;
int g_iDbtKey;
int g_iIctKey;
int g_iIetKey;
int g_iCwaKey;
int g_iSysOpMode;
int g_iTestMode;
int g_iErrlogMax;
int g_iBrhNodeLen;
int g_iTermNodeLen;
int g_iTxnCodeLen;
int g_iTellerCodeLen;
int g_iLoadCvtTbl;
int g_iSystemRole;
int g_iBaseYear;
int g_iNoBatch;
int g_iNoSignon;
int g_iMaxPacketSize;
int g_iTmax;
int g_iTmin;
int g_iToffset;
int g_iPiggyBack_Size;
int g_iBatch_SaveCwa_Time;

int g_iBrhNodeNum;
int g_iPassUsr;
int g_iTotTmNum;
int g_iFirstRun;
int g_iChronPid=0;
int g_iBitSize=0;

char g_caIfVerName[10][20];
/*
char g_caRlPgName[10][20];
*/
char g_cByPassInput='n';

/* Add by Hu Chunlin to save Center System Status. BEGIN */
char g_cCenterSysStatus = ' ';
/* Add by Hu Chunlin to save Center System Status. END   */

/*
 *&N& ROUTINE NAME: main  
 *&A& ARGUMENTS:
 *&A&           
 *&R& RETURN VALUES:
 *&R&           
 *&R&           
 *&D& DESCRIPTION:           
 *&D&     ����Ƭ����Һ޲z�l�t�ΥD�{��, �t�d�إߤ���������޲z�i���檺����
 *&D&           
 */

main(int iArgCnt, char *pcaArgVec[])
{
  int  iRc;
  char cLevel2Step;
  char caLogName[256];

  UCP_TRACE(P_Main_ems);

  sprintf(caLogName, "%s/iii/log/ems_errlog", getenv("III_DIR") );
  ChgLog(LOG_CHG_LOG,caLogName);

  iRc = GetConfg();
  if (iRc != 0) {
     /*
     sprintf (g_caMsg, 
              "<EMS> Failure to obtain configuration value! (iRc:%d)", iRc);
     ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
     */
     exit (iRc);
  }

  if ( g_iTestMode == 1) {
    ChgLog(LOG_CHG_MODE,"1");
  }
  else {
    ChgLog(LOG_CHG_MODE,"0");
  }

  if (iArgCnt > 1){
    g_cByPassInput = pcaArgVec[1][0];
  }

  iRc = EnvSetup(&cLevel2Step);
  if (iRc < 0){
    ErrorRpt (UCP_SYSTEM, EMS_SUB_SYSTEM, ENVSETUP_STEP, cLevel2Step, iRc); 
    EmsErrHdl (cLevel2Step,iRc);
    sprintf (g_caMsg, 
             "<EMS> Failure to startup TPE! (EnvSetup iRc:%d)", iRc);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    exit (-1);
  }

  iRc = TpeIfSet(&cLevel2Step);
  if (iRc < 0){
    ErrorRpt (UCP_SYSTEM, EMS_SUB_SYSTEM, TPEIFSET_STEP, cLevel2Step, iRc); 
    EmsErrHdl (cLevel2Step,iRc);
    sprintf (g_caMsg, "<EMS> Failure to startup TPE! (TpeIfSet iRc:%d)", iRc);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    exit (-1);
  }

  iRc = TxPreHdl(&cLevel2Step);
  if (iRc < 0){
    ErrorRpt (UCP_SYSTEM, EMS_SUB_SYSTEM, TXPREHDL_STEP, cLevel2Step, iRc); 
    EmsErrHdl (cLevel2Step,iRc);
    sprintf (g_caMsg, "<EMS> Failure to startup TPE! (TxPreHdl iRc:%d)", iRc);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    exit(-1);
  }

  iRc = SysStart(&cLevel2Step);
  if (iRc < 0){
    ErrorRpt (UCP_SYSTEM, EMS_SUB_SYSTEM, SYSSTART_STEP, cLevel2Step, iRc); 
    EmsErrHdl (cLevel2Step,iRc);
    sprintf (g_caMsg, "<EMS> Failure to startup TPE! (SysStart iRc:%d)", iRc);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    exit(-1);
  }


  iRc = MaServer(&cLevel2Step);
  if (iRc < 0){
    ErrorRpt (UCP_SYSTEM, EMS_SUB_SYSTEM, MASERVER_STPE, cLevel2Step, iRc); 
    EmsErrHdl (cLevel2Step,iRc);
    sprintf (g_caMsg, "<EMS> Failure to startup TPE! (MaServer iRc:%d)", iRc);
    /* ???
    ErrLog (40000, g_caMsg, RPT_TO_LOG, 0, 0);
    */
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
  }


}



/*
 *&N& ROUTINE NAME: GetConfg()
 *&A& ARGUMENTS:
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&   ����ƥΥH���o�t�ΰѼ��� config.dat ���Ҵy�z���t�ΰѼƭ�,�P�ɱN�ȳ]�w
 *&D&   ���۹����������ܼ�
 *&D&               �t�ΰѼ�                �����ܼ�
 *&D&       ----------------------------------------------
 *&D&        CWA Shared Memory Key          g_iCwaKey
 *&D&        CTF Shared Memory Key          g_iCtfKey
 *&D&        ICT Shared Memory Key          g_iIctKey
 *&D&        DBT Shared Memory Key          g_iDbtKey
 *&D&        IET Shared Memory Key          g_iIetKey
 *&D&        SYSMODE                        g_iSysOpMode
 *&D&                                         0 : �^��
 *&D&                                         1 : ����
 *&D&   �U�C���Τ��@,�|�Ϧ���ư��楢��
 *&D&       1. �L�k�}�� config.dat ��
 *&D&       2. �Өt�ΰѼƤ��s�b
 *&D&       3. config.dat �ɤ����t�ΰѼƭӼƶW�X�̤j����
 *&d&          (�Ѧұ`�� MAX_PARA_NO ����)
 *&D&       4. �t�ΰѼƦW�٤����׶W�X�̤j����
 *&D&          (�Ѧұ`�� MAX_PARA_NAME_LEN ����)
 *&D&
 */

int
GetConfg()
{
  int iRc;
  char caFileName[ FILE_NAME_LEN + 1 ];

  UCP_TRACE(P_GetConfg);

  sprintf (caFileName, "%s/%s", (char *) getenv("III_DIR"), CONFIG_FILE);

  iRc = InitCnfTbl(caFileName);
  if ( iRc < 0 ){
    UCP_TRACE_END( INIT_CNFTBL_ERR );
  }

  g_iCtfKey = GetCnfValue( CTF_SHM_KEY );
  if (g_iCtfKey < 0){
    sprintf (g_caMsg, 
             "<EMS> Illegal CTF_SHM_KEY value [0x%0x] defined in config.dat", 
             g_iCtfKey);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("\n%s\n", g_caMsg);
    UCP_TRACE_END( GET_CTFKEY_ERR );
  }

  g_iDbtKey = GetCnfValue( DBT_SHM_KEY );
  if (g_iDbtKey < 0){
    sprintf (g_caMsg, 
             "<EMS> Illegal DBT_SHM_KEY value [0x%0x] defined in config.dat", 
             g_iDbtKey);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("\n%s\n", g_caMsg);
    UCP_TRACE_END( GET_DBTKEY_ERR );
  }

  g_iIctKey = GetCnfValue( ICT_SHM_KEY );
  if (g_iIctKey < 0){
    sprintf (g_caMsg, 
             "<EMS> Illegal ICT_SHM_KEY value [0x%0x] defined in config.dat", 
             g_iIctKey);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("\n%s\n", g_caMsg);
    UCP_TRACE_END( GET_ICTKEY_ERR );
  }

  g_iIetKey = GetCnfValue( IET_SHM_KEY );
  if (g_iIetKey < 0){
    sprintf (g_caMsg, 
             "<EMS> Illegal IET_SHM_KEY value [0x%0x] defined in config.dat", 
             g_iIetKey);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("\n%s\n", g_caMsg);
    UCP_TRACE_END( GET_IETKEY_ERR );
  }

  g_iCwaKey = GetCnfValue( CWA_SHM_KEY );
  if (g_iCwaKey < 0){
    sprintf (g_caMsg, 
             "<EMS> Illegal CWA_SHM_KEY value [0x%0x] defined in config.dat", 
             g_iCwaKey);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("\n%s\n", g_caMsg);
    UCP_TRACE_END( GET_CWAKEY_ERR );
  }

  g_iSysOpMode = GetCnfValue( SYS_MODE );
  if (g_iSysOpMode != 0 && g_iSysOpMode != 1){
    sprintf (g_caMsg, 
             "<EMS> Illegal SYS_MODE value [%d] defined in config.dat", 
             g_iSysOpMode);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("\n%s\n", g_caMsg);
    UCP_TRACE_END( GET_SYSOPMODE_ERR );
  }

  g_iTestMode = GetCnfValue( TEST_MODE );
  if ( (g_iTestMode != 0) && (g_iTestMode != 1) && (g_iTestMode != 9) ){
    sprintf (g_caMsg, 
             "<EMS> Illegal TEST_MODE value [%d] defined in config.dat", 
             g_iTestMode);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("\n%s\n", g_caMsg);
    UCP_TRACE_END( GET_TESTMODE_ERR );
  }

  g_iErrlogMax = GetCnfValue( ERRLOG_MAX );
  if (g_iErrlogMax < 0){
    sprintf (g_caMsg, 
             "<EMS> Illegal ERRLOG_MAX value [%d] defined in config.dat", 
             g_iErrlogMax);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("\n%s\n", g_caMsg);
    UCP_TRACE_END( GET_ERRLOGMAX_ERR );
  }

  g_iBrhNodeLen = GetCnfValue( BRH_NODE_LEN );
  if ( (g_iBrhNodeLen < 0) || (g_iBrhNodeLen > MAX_BRH_NODE_LEN) ){
    sprintf (g_caMsg, 
             "<EMS> Illegal BRH_NODE_LEN value [%d] defined in config.dat", 
             g_iBrhNodeLen);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("\n%s\n", g_caMsg);
    UCP_TRACE_END( GET_BRHIDLEN_ERR );
  }

  g_iTermNodeLen = GetCnfValue( TERM_NODE_LEN );
  if ( (g_iTermNodeLen < 0) || (g_iTermNodeLen > MAX_TERM_NODE_LEN)){
    sprintf (g_caMsg, 
             "<EMS> Illegal TERM_NODE_LEN value [%d] defined in config.dat", 
             g_iTermNodeLen);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("\n%s\n", g_caMsg);
    UCP_TRACE_END( GET_TMIDLEN_ERR );
  }

  g_iTxnCodeLen = GetCnfValue( TXN_CODE_LEN );
  if ( (g_iTxnCodeLen < 0) || (g_iTxnCodeLen > MAX_TXN_CODE_LEN)){
    sprintf (g_caMsg, 
             "<EMS> Illegal TXN_CODE_LEN value [%d] defined in config.dat", 
             g_iTxnCodeLen);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("\n%s\n", g_caMsg);
    UCP_TRACE_END( GET_TXNIDLEN_ERR );
  }

  g_iTellerCodeLen = GetCnfValue( TELLER_CODE_LEN );
  if ( (g_iTellerCodeLen < 0) || (g_iTellerCodeLen > MAX_TELLER_CODE_LEN)){
    sprintf (g_caMsg, 
             "<EMS> Illegal TELLER_CODE_LEN value [%d] defined in config.dat", 
             g_iTellerCodeLen);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("\n%s\n", g_caMsg);
    UCP_TRACE_END( GET_TELLERIDLEN_ERR );
  }

  g_iLoadCvtTbl = GetCnfValue( LOAD_CVT_TABLE );
  if ( (g_iLoadCvtTbl != 0) && (g_iLoadCvtTbl != 1)){
    sprintf (g_caMsg, 
             "<EMS> Illegal LOAD_CVT_TABLE value [%d] defined in config.dat", 
             g_iLoadCvtTbl);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("\n%s\n", g_caMsg);
    UCP_TRACE_END( GET_LOADCVTTBL_ERR );
  }

  g_iSystemRole = GetCnfValue( SYSTEM_ROLE );
  if ( (g_iSystemRole != 0) && (g_iSystemRole != 1)){
    sprintf (g_caMsg, 
             "<EMS> Illegal SYSTEM_ROLE value [%d] defined in config.dat", 
             g_iSystemRole);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("\n%s\n", g_caMsg);
    UCP_TRACE_END( GET_SYSTEMROLE_ERR );
  }

  g_iBaseYear = GetCnfValue( BASE_YEAR );
  if (g_iBaseYear < 0) {
    sprintf (g_caMsg, 
             "<EMS> Illegal BASE_YEAR value [%d] defined in config.dat", 
             g_iBaseYear);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("\n%s\n", g_caMsg);
    UCP_TRACE_END( GET_BASEYEAR_ERR );
  }

  g_iNoBatch = GetCnfValue( NO_BATCH );
  if ( (g_iNoBatch != 0) && (g_iNoBatch != 1)){
    sprintf (g_caMsg, 
             "<EMS> Illegal NO_BATCH value [%d] defined in config.dat", 
             g_iNoBatch);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("\n%s\n", g_caMsg);
    UCP_TRACE_END( GET_NOBATCH_ERR );
  }

  g_iNoSignon= GetCnfValue( NO_SIGNON );
  if ( (g_iNoSignon != 0) && (g_iNoSignon != 1)){
    sprintf (g_caMsg, 
             "<EMS> Illegal NO_SIGNON value [%d] defined in config.dat", 
             g_iNoSignon);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("\n%s\n", g_caMsg);
    UCP_TRACE_END( GET_NOSIGNON_ERR );
  }

  g_iMaxPacketSize = GetCnfValue( MAX_PACKET_SIZE );
  if ( g_iMaxPacketSize < 0 ) {
    sprintf (g_caMsg, 
             "<EMS> Illegal MAX_PACKET_SIZE value [%d] defined in config.dat", 
             g_iMaxPacketSize);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("\n%s\n", g_caMsg);
    UCP_TRACE_END( GET_MAXPACKETSIZE_ERR );
  }

  g_iTmax = GetCnfValue( T_MAX );
  if ( g_iTmax < 0 ) {
    sprintf (g_caMsg, 
             "<EMS> Illegal T_MAX value [%d] defined in config.dat", 
             g_iTmax);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("\n%s\n", g_caMsg);
    UCP_TRACE_END( GET_TMAX_ERR );
  }

  g_iTmin = GetCnfValue( T_MIN );
  if ( g_iTmin < 0 ) {
    sprintf (g_caMsg, 
             "<EMS> Illegal T_MIN value [%d] defined in config.dat", 
             g_iTmin);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("\n%s\n", g_caMsg);
    UCP_TRACE_END( GET_TMIN_ERR );
  }

  g_iToffset = GetCnfValue( T_OFFSET );
  if ( g_iToffset < 0 ) {
    sprintf (g_caMsg, 
             "<EMS> Illegal T_OFFSET value [%d] defined in config.dat", 
             g_iToffset);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("\n%s\n", g_caMsg);
    UCP_TRACE_END( GET_TOFFSET_ERR );
  }

  if ( g_iTmax < g_iTmin+g_iToffset ) {
    sprintf (g_caMsg, 
    "<EMS> T_MAX value [%d] is less than (T_MIN+T_OFFSET) value [%d] defined in config.dat", 
    g_iTmax, g_iTmin+g_iToffset);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("\n%s\n", g_caMsg);
    UCP_TRACE_END( TMAX_VALUE_ERR );
  }

  if ( g_iTmin >= g_iTmin+g_iToffset ) {
    sprintf (g_caMsg, 
    "<EMS> T_MIN value [%d] is more than (T_MIN+T_OFFSET) value [%d] defined in config.dat", 
    g_iTmin, g_iTmin+g_iToffset);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    printf ("\n%s\n", g_caMsg);
    UCP_TRACE_END( TMIN_VALUE_ERR );
  }

  g_iBatch_SaveCwa_Time = GetCnfValue( BATCH_SAVECWA_TIME );
  if ( g_iBatch_SaveCwa_Time <= 0 ) {
     sprintf (g_caMsg,
     "<EMS> BATCH_SAVECWA_TIME value [%d] is less than or equal to zero!",
     g_iBatch_SaveCwa_Time);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    /* For compatability with the former version
    printf ("\n%s\n", g_caMsg);
    UCP_TRACE_END( SAVECWA_TIME_ERR );
    */
  }

  UCP_TRACE_END( 0 );
}

