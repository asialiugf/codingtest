#include <errno.h>
#include "cwa.h"
#include "errlog.h"

#define  BIG2HOST  "iii/etc/tbl/big2host.dat"

int loopcnt=0;

/*----------------------------------------------*/
Init_Cvt_Table(tab_p)
struct Big2Nhost *tab_p;
{
  FILE *fi;
  unsigned int i;
  unsigned int Big,I5550,Nhost;
  unsigned short *ptr_1,*ptr_2;
  char caFileName[ 80 ];

  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat((char *)caFileName, (char *)"/");
  strcat((char *)caFileName,  BIG2HOST);
  if ((fi=fopen(caFileName,"r"))==NULL) {
    ErrLog(1000,g_caMsg,RPT_TO_TTY|RPT_TO_LOG,0,0);
    sprintf(g_caMsg,"Init_Cvt_Table:can't open big2host cvtable file=%d",errno);
    return (Error);
  }

  ptr_1=tab_p->Big2Nhost;
  ptr_2=tab_p->Nhost2Big;
  memset((char *)ptr_1,0xff,sizeof(tab_p->Big2Nhost));
  memset((char *)ptr_2,0xff,sizeof(tab_p->Nhost2Big));
  while ((!feof(fi))&&(loopcnt<20000)) {
    fscanf(fi,"%4x%c%4x%c%4x",&Big,&i,&I5550,&i,&Nhost);
    if (feof(fi)) {
      fclose(fi);
      return(Ok);
    }
    loopcnt++;
    tab_p->Big2Nhost[Big-0x8000]=Nhost;
    if (Nhost!=0xffff) {

      if (Nhost<0xc200){
       	tab_p->Nhost2Big[Nhost-0x4000]=Big;
      }
      else {
     	tab_p->Nhost2Big[Nhost-0xc200+0x5200]=Big;
      }

    } /* FOR if (Nhost!=0xffff) */

  } /* FOR while ((!feof(fi))&&(loopcnt<20000)) */

  fclose(fi);
  return(Ok);
}

/*----------------------------------------------*/

unsigned int CBig2Nhost(BIG,tab_p)
unsigned int BIG;
struct Big2Nhost *tab_p;
{
/*
return (tab_p->Big2Nhost[BIG-0x8000]);
*/
unsigned work;

work=tab_p->Big2Nhost[BIG-0x8000];
if (work == 0xffff)
   return(NO_CODE);
else
   return(work);
}

/*----------------------------------------------*/

unsigned int CNhost2Big(NHOST,tab_p)
unsigned int NHOST;
struct Big2Nhost *tab_p;
{
/*
if (((NHOST-0x4000)<0) || ((NHOST-0xc200+0x5200)>32768))
   return (0x2020);
*/
if (NHOST<0xc240){
       if ((NHOST-0x4000)<0) {
          return (0x2020);
       }
       else{
          return (tab_p->Nhost2Big[NHOST-0x4000]);
       }
}
else{
       if ((NHOST-0xc200+0x5200)>32768){
          return (0x2020);
       }
       else{
          return (tab_p->Nhost2Big[NHOST-0xc200+0x5200]);
       }
}
/*
       return (tab_p->Nhost2Big[NHOST-0x4000+0x5200]);
*/
}
/*----------------------------------------------*/

int big5_host(ptr1,ptr2,slen,tab_p)
unsigned char *ptr1;
unsigned char *ptr2;
int slen;
struct Big2Nhost *tab_p;
{
int str_len;
int cnt1=0,cnt2=0;
int in_ch=0;

  str_len=slen;
  while (cnt1<str_len) {
  /* 81.03.14 D.M. Lin */
  /* PACIFIC Co. update */

    if(((*(ptr1+cnt1) >= 0xa1) || 
       ((*(ptr1+cnt1) >= 0x81) &&
       (*(ptr1+cnt1) <= 0xfe))) &&
       ((cnt1+1)<str_len)&&
       ((*(ptr1+cnt1+1)>=0x40)&&(*(ptr1+cnt1+1)<=0x7e)||
    /* 04/30/1992 modify boundary */
       (*(ptr1+cnt1+1)>=0x80)&&(*(ptr1+cnt1+1)<=0xfe))) {

      if (in_ch==0) {
        in_ch=1;
        *(ptr2+cnt2)=SI;
        cnt2++;
      }
      *(ptr2+cnt2)=(unsigned char)((CBig2Nhost(((unsigned int)(*(ptr1+cnt1))<<8)
                                   +*(ptr1+cnt1+1),tab_p))>>8);
      *(ptr2+cnt2+1)=(unsigned char)((CBig2Nhost(((unsigned int)(*(ptr1+cnt1))
                                   <<8)+*(ptr1+cnt1+1),tab_p))&0x0ff);
      cnt2+=2;
      cnt1+=2;
    }
    else {
      if (in_ch==1) {
        in_ch=0;
        *(ptr2+cnt2)=SO;
        cnt2++;
      }
      *(ptr2+cnt2)=Asc2Ebcd[*(ptr1+cnt1)];
      cnt2++;
      cnt1++;
    }
  }  /* FOR while (cnt1<str_len) */

  if (in_ch==1) {
    in_ch=0;
    *(ptr2+cnt2)=SO;
    cnt2++;
  }
  *(ptr2+cnt2)=0x0;
  return(cnt2);
}

/*----------------------------------------------*/

int host_big5(ptr1,ptr2,slen,tab_p)
unsigned char *ptr1;
unsigned char *ptr2;
int slen;
struct Big2Nhost *tab_p;
{
int str_len;
int cnt1=0,cnt2=0;
unsigned char in_ch=0;
/*
str_len=strlen(ptr1);
*/
str_len=slen;
while (cnt1<str_len)
       {
       if (in_ch==0)
               {
               if (*(ptr1+cnt1)!=SI)
                       {
                       *(ptr2+cnt2)=Ebcd2Asc[*(ptr1+cnt1)];
                       cnt2++;
                       }
               else
                       in_ch=1;
               cnt1++;
               }
       else
               {
               if ((*(ptr1+cnt1)!=SO)&&((cnt1+1)<str_len))
                       {
                       *(ptr2+cnt2)=(unsigned char)((CNhost2Big(((unsigned int)(*(ptr1+cnt1))<<8)+*(ptr1+cnt1+1),tab_p))>>8);
                       *(ptr2+cnt2+1)=(unsigned char)((CNhost2Big(((unsigned int)(*(ptr1+cnt1))<<8)+*(ptr1+cnt1+1),tab_p))&0x0ff);
                       cnt2+=2;
                       cnt1+=2;
                       }
               else if(*(ptr1+cnt1)==SO)
                       {
                       in_ch=0;
                       cnt1++;
                       }
               else
                       {
                       *(ptr2+cnt2)=Ebcd2Asc[*(ptr1+cnt1)];
                       cnt2++;
                       cnt1++;
                       }

               }


      }
*(ptr2+cnt2)=0x0;
/*
return(strlen(ptr2));
*/
return(cnt2);
}
/*----------------------------------------------*/
int host_big5_ci(ptr1,ptr2,slen,tab_p)
unsigned char *ptr1;
unsigned char *ptr2;
int slen;
struct Big2Nhost *tab_p;
{
int str_len;
int cnt1=0,cnt2=0,space=0,i;
unsigned char in_ch=0;
/*
str_len=strlen(ptr1);
*/
str_len=slen;
while (cnt1<str_len)
       {
       if (in_ch==0)
               {
               if (*(ptr1+cnt1)!=SI)
                       {
                       *(ptr2+cnt2)=Ebcd2Asc[*(ptr1+cnt1)];
                       cnt2++;
                       }
               else
                       {
                       *(ptr2+cnt2)=0x20;
                       cnt2++;
                       in_ch=1;
                       }
               cnt1++;
               }
       else
               {
               if ((*(ptr1+cnt1)!=SO)&&((cnt1+1)<str_len))
                       {
                       *(ptr2+cnt2)=(unsigned char)((CNhost2Big(((unsigned int)(*(ptr1+cnt1))<<8)+*(ptr1+cnt1+1),tab_p))>>8);
                       *(ptr2+cnt2+1)=(unsigned char)((CNhost2Big(((unsigned int)(*(ptr1+cnt1))<<8)+*(ptr1+cnt1+1),tab_p))&0x0ff);
                       cnt2+=2;
                       cnt1+=2;
                       }
               else if(*(ptr1+cnt1)==SO)
                       {
                       *(ptr2+cnt2)=0x20;
                       cnt2++;
                       in_ch=0;
                       cnt1++;
                       }
               else
                       {
                       *(ptr2+cnt2)=Ebcd2Asc[*(ptr1+cnt1)];
                       cnt2++;
                       cnt1++;
                       }

               }


      }
*(ptr2+cnt2)=0x0;
/*
return(strlen(ptr2));
*/
return(cnt2);
}

/*----------------------------------------------*/
