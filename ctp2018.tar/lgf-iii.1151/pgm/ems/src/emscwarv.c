
/*
 *&N& File : emscwarv.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int           RecoveryCwa         �_��CWA
 *&N&    int           RecoveryBit         �_��BIT�U�Ǹ����
 *&N&    long          SeqStrToInt         �Ʀr�r���নlong type �Ʀr
 */

/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include  <errno.h>
#include  "errlog.h"
#include  "cwa.h"
#include  "lgcopewa.h"
#include  "lgclgfmt.h"

/* -------------------- CONSTANT DEFINE  --------------------------- */
#define  P_RecoveryCwa   72001
#define  P_RecoveryBit   72002
#define  P_SeqStrToInt   72003

/* -------------------- STRUCT  DECLARATION ------------------ */
struct SeqNoInfoSt {
   long lNextAvBtefRrn;
   long lLastLogRecRrn;
   long lSystemTxnSeqNo;
   long lAccTxnSeqNo;
   long lNonAccTxnSeqNo;
   long lBatchTxnSeqNo;
   char caBrCode[LG_MAX_BR_CODE_SIZE];
   char caTmCode[LG_MAX_TM_CODE_SIZE];
   /* Only Normal Log data can be used for recovery
      Txn Seq No
    */
   unsigned char ucRecoverySeqNo;
};

long SeqStrToInt(char*,short);
/* -------------------- GLOBAL DECLARATION ------------------ */
static int sg_iBrhNodeLen;
static int sg_iTermNodeLen;

/*
 *&N& ROUTINE NAME: CwaRecovery()
 *&A& ARGUMENTS:
 *&A& ---------  ---------------------    -------------------------
 *&A& long          lRrn                    next available rrn of cwa
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&    0 <    : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&  1. Read and lock CWA
 *&D&  2. Open log : call LOGFCALL()
 *&D&  3. Read log by next available rrn of CWA :  call LOGFCALL()
 *&D&  4. Setting Sequence number data to stSeqNo struct
 *&D&  5. Modify pstSsa->lNextAvLogRrn,pstSsa->lTotalTxnCnt
 *&D&  6. call RecoveryBit() : 
 *&D&     6.1 Read TCT's data by Branch code and Termal code
 *&D&     6.2 Modify : lLastLogRecRrn,lAccTxnSeqNo,
 *&D&                  lNonAccTxnSeqNo,lBatchTxnSeqNo of BIT 
 *&D&  7. Read next log record AND Repeat step(5.)
 *&D&  8. Unlock CWA
 *&D&  9. Close log : call LOGFCALL()
 *&D&
 */

int
RecoveryCwa()
{

  int i = 1;
  int iRc;
  char          *pcDummy;
  struct CwaCtl stCwaCtl;
  struct SSA    *pstSsa;
  LOGFUNIF stFun;
  LOGFMT   stLogFmt;
  struct SeqNoInfoSt stSeqNo;

  UCP_TRACE(P_RecoveryCwa);
  stCwaCtl.cFunCode = CWA_SEG_LOCK;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcDummy);

  if (iRc != CWA_NORMAL) {
    ErrLog(1000,"RecoveryCwa: CwaCtlFac lock SSA fail!",RPT_TO_LOG,0,0);
    UCP_TRACE_END( -1 );
  }

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);

  if (iRc != CWA_NORMAL) {
    ErrLog(1000,"RecoveryCwa: CwaCtlFac get SSA ptr fail!",RPT_TO_LOG,0,0);
    UCP_TRACE_END( -1 );
  }

  stFun.caFunCode[0] = OPEN_LOG;
  stFun.caReturn[0] = LG_NORMAL;
  LOGFCALL(&stFun,&stLogFmt);
  if (stFun.caReturn[0] != LG_NORMAL) {
    ErrLog(1000,"RecoveryCwa: Open Log Error!",RPT_TO_LOG,0,0);
    UCP_TRACE_END( -1 );
  }

  while (stFun.caReturn[0] == LG_NORMAL) {
     stFun.caFunCode[0] = DIRECT_READ_LOG;
     stFun.caLockMode[0] = FLAG_OFF;
     sprintf(stFun.caRrn,"%.*d",LG_RRN_SIZE,pstSsa->lNextAvLogRrn);
  /*
     sprintf(stFun.caRrn,"%.*d",LG_RRN_SIZE,i++);
   */
     stFun.caReturn[0] = LG_NORMAL;
     LOGFCALL(&stFun,&stLogFmt);
     if (stFun.caReturn[0] == LG_NORMAL) {
       stSeqNo.lNextAvBtefRrn = 
       SeqStrToInt(stLogFmt.caNextAvBtefRrn,LG_RRN_SIZE);
       /* modified 2-lines by WuChihLiang 19950519 for current BIT 
          LastLogRecRrn is stLogFmt.caNextAvBtefRrn */
       /*stSeqNo.lLastLogRecRrn = 
       SeqStrToInt(stLogFmt.caLastLogRecRrn,LG_RRN_SIZE);*/
       /*stSeqNo.lLastLogRecRrn = 
       SeqStrToInt(stLogFmt.caNextAvBtefRrn ,LG_RRN_SIZE);*/
       stSeqNo.lLastLogRecRrn = 
       SeqStrToInt(stLogFmt.caCurrLogRrn ,LG_RRN_SIZE);
       stSeqNo.lSystemTxnSeqNo =
       SeqStrToInt(stLogFmt.caSystemTxnSeqNo,10);
       stSeqNo.lAccTxnSeqNo =
       SeqStrToInt(stLogFmt.caAccTxnSeqNo,LG_TXN_SEQ_SIZE);
       stSeqNo.lNonAccTxnSeqNo =
       SeqStrToInt(stLogFmt.caNonAccTxnSeqNo,LG_TXN_SEQ_SIZE);
       stSeqNo.lBatchTxnSeqNo =
       SeqStrToInt(stLogFmt.caBatchTxnSeqNo,LG_TXN_SEQ_SIZE);
       memcpy(stSeqNo.caBrCode,stLogFmt.caBrCode,LG_MAX_BR_CODE_SIZE);
       memcpy(stSeqNo.caTmCode,stLogFmt.caTmCode,LG_MAX_TM_CODE_SIZE);
      /* recovery CWA lNextAvLogRrn,lTotalTxnCnt */
       pstSsa->lNextAvLogRrn++;
       pstSsa->lTotalTxnCnt++;
      /*
       */
      /* only normal log data can be used for recovery,
         so set ucRecoverySeqNo to 1.
         else set to 0.
       */
       if (stLogFmt.caTxnReturnCd[0] =='0' || stLogFmt.caTxnReturnCd[0] =='2' ||
           stLogFmt.caTxnReturnCd[0] =='3' || stLogFmt.caTxnReturnCd[0] =='5')
           stSeqNo.ucRecoverySeqNo = 1;
       else
           stSeqNo.ucRecoverySeqNo = 0;

       iRc = RecoveryBit(&stSeqNo);
       if (iRc < 0) {
         ErrLog(1000,"RecoveryCwa: Recovery BIT fail!",RPT_TO_LOG,0,0);
         UCP_TRACE_END( -1 );
       }
     }
  }

  stCwaCtl.cFunCode = CWA_SEG_UNLOCK;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcDummy);

  if (iRc != CWA_NORMAL) {
    ErrLog(1000,"RecoveryCwa: CwaCtlFac unlock SSA fail!",RPT_TO_LOG,0,0);
    UCP_TRACE_END( -1 );
  }

  stFun.caFunCode[0] = CLOSE_LOG;
  stFun.caReturn[0] = LG_NORMAL;
  LOGFCALL(&stFun,&stLogFmt);
  if (stFun.caReturn[0] != LG_NORMAL) {
    ErrLog(1000,"RecoveryCwa: Close LOG Error!",RPT_TO_LOG,0,0);
    UCP_TRACE_END( -1 );
  }
  UCP_TRACE_END( 0 );
}

/*
 *&N& ROUTINE NAME: SeqStrToInt()
 *&A& ARGUMENTS:
 *&A& ---------  ---------------------    -------------------------
 *&A& char          *pcStr                 Sequence number of pointer
 *&A& short         sLen                   sequence number string len in log
 *&A&
 *&R& RETURN VALUE(long):
 *&R& long          sequence number
 *&R&
 *&D& DESCRIPTION:
 *&D&  Numeric String Conver to long type integer
 *&D&
 *&D&
 */
long
SeqStrToInt(char *pcStr,short sLen)
{
   char caNumBuf[LG_RRN_SIZE+LG_TXN_SEQ_SIZE];

   UCP_TRACE(P_SeqStrToInt);
   memset(caNumBuf,'\0',LG_RRN_SIZE+LG_TXN_SEQ_SIZE);
   memcpy(caNumBuf,pcStr,sLen);
   UCP_TRACE_END((long) atoi(caNumBuf));
}

/*
 *&N& ROUTINE NAME: RecoveryBit()
 *&A& ARGUMENTS:
 *&A& ---------  ---------------------    -------------------------
 *&A& struct        *pstSeqNo              Sequence number struct of pointer
 *&A&
 *&R& RETURN VALUE(long):
 *&R&    0      : ����ư��榨�\
 *&R&    0 <    : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&  1. Read and Lock BIT
 *&D&  2. Read TCT
 *&D&  3. Modefy : TCT pstTct->lLastOnlnRrn,pstTct->lNonAccTxnNo,
 *&D&                  pstTct->lAccTxnNo, pstTct->lBtchTxnNo;
 *&D&  4. Unlock BIT
 *&D&
 */

int
RecoveryBit(pstSeqNo)
struct SeqNoInfoSt *pstSeqNo;
{
  int iRc;
  char *pcTerm;
  char *pcDummy;
  struct SPA    *pstSpa;

  struct CwaCtl stCwaCtl;
  struct TermArea *pstTct;

  UCP_TRACE(P_RecoveryBit);
  stCwaCtl.cFunCode = CWA_SEG_LOCK;
  stCwaCtl.cSegCode = CWA_SEG_BIT_BRH;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcDummy);

  if (iRc != CWA_NORMAL) {
    ErrLog(1000,"RecoveryBit : CwaCtlFac lock TCT fail!",RPT_TO_LOG,0,0);
    UCP_TRACE_END( -1 );
  }

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SPA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSpa);
  if (iRc != 0) {
    UCP_TRACE_END( -1 );
  }
 
  sg_iBrhNodeLen  = (int) pstSpa->cBrCodeLen;
  sg_iTermNodeLen = (int) pstSpa->cTmCodeLen;

  stCwaCtl.cFunCode = CWA_GET_TERM_PTR;
  memcpy(stCwaCtl.caBrhId, pstSeqNo->caBrCode, sg_iBrhNodeLen);
  memcpy(stCwaCtl.caTermId,pstSeqNo->caTmCode, sg_iTermNodeLen);
  iRc = CwaLowCtlFac(&stCwaCtl,&pcTerm);

  if (iRc != CWA_NORMAL) {
    ErrLog(1000,"RecoveryBit: CwaCtlFac get TCT ptr fail!",RPT_TO_LOG,0,0);
    UCP_TRACE_END( -1 );
  }


  pstTct = (struct TermArea *) pcTerm;

  /* ---------------------------------------------------------------------- */
  /* ��s CWA.TCT���Ӳ׺ݾ��W��log��RRN,�b�ȩʡB�D�b�ȩ�, ������y����    */
  /* ---------------------------------------------------------------------- */
/*
  printf("Tct->caLogicId = %.*s\n",MAX_BR_LEN+MAX_TM_LEN,pstTct->caLogicId);
  printf("Tct->lLastOnlnRrn = %d\n",pstTct->lLastOnlnRrn);
  printf("pstSeqNo->lLastLogRecRrn = %d\n",pstSeqNo->lLastLogRecRrn);
  printf("Tct->lNonAccTxnNo = %d\n",pstTct->lNonAccTxnNo);
  printf("pstSeqNo->lNonAccTxnSeqNo = %d\n",pstSeqNo->lNonAccTxnSeqNo);
  printf("Tct->lAccTxnNo = %d\n",pstTct->lAccTxnNo);
  printf("pstSeqNo->lAccTxnSeqNo = %d\n",pstSeqNo->lAccTxnSeqNo);
  printf("Tct->lBtchTxnNo = %d\n",pstTct->lBtchTxnNo);
  printf("pstSeqNo->lBatchTxnSeqNo = %d\n",pstSeqNo->lBatchTxnSeqNo);
  */

  pstTct->lLastOnlnRrn = pstSeqNo->lLastLogRecRrn;
  /* modified 3-lines by WuChihLiang 19950523 for BIT TxnSeqNo is current 
     LOG_TXN_SEQ_NO plus 1 -- BEGIN */
  /* pstTct->lNonAccTxnNo = pstSeqNo->lNonAccTxnSeqNo;
  pstTct->lAccTxnNo = pstSeqNo->lAccTxnSeqNo;
  pstTct->lBtchTxnNo = pstSeqNo->lBatchTxnSeqNo;*/
  /* if normal log data then recovery seq no
   */
  if (pstSeqNo->ucRecoverySeqNo) {
    switch( pstSeqNo->lSystemTxnSeqNo/10000){
      case 0: /* Center host Account Txn */
      case 2: /* Branch Host Account Txn */
        pstTct->lAccTxnNo = pstSeqNo->lSystemTxnSeqNo + 1;
        break;
      case 1: /* Center host NonAccount Txn */
      case 3: /* Branch host NonAccount Txn */
        pstTct->lNonAccTxnNo = pstSeqNo->lSystemTxnSeqNo + 1;
        break;
      case 4: /* Batch Txn */
        pstTct->lBtchTxnNo = pstSeqNo->lSystemTxnSeqNo + 1;
        break;
    }
  }
  /* modified 3-lines by WuChihLiang 19950523 for BIT TxnSeqNo is current 
     LOG_TXN_SEQ_NO plus 1 -- END   */

  stCwaCtl.cFunCode = CWA_SEG_UNLOCK;
  stCwaCtl.cSegCode = CWA_SEG_BIT_BRH;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcDummy);

  if (iRc != CWA_NORMAL) {
    ErrLog(1000,"RecoveryBit: CwaCtlFac unlock TCT fail!",RPT_TO_LOG,0,0);
    UCP_TRACE_END( -1 );
  }
  UCP_TRACE_END(0);
}
