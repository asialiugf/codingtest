/*
 *&N& File : emsifenv.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int       TpeIfSet()             �ǳ� TPE �����Ҳդ�����
 *&N&                                     (�Ұʬ۹����������Ҳճs���{��)
 */

/* ------------------------- INCLUDE FILES ---------------------------- */
#include  <stdio.h>
#include  <errno.h>
#include  "errlog.h"
#include  "emctldef.h"
#include  "emcifenv.h"
#include  "emcpgdef.h"
#include  "cwa.h"

/* ------------------------- CONSTANT DEFINITION  --------------------- */
extern int  errno;
extern char *sys_errlist[];
extern char g_caIfVerName [10][20];
char g_caRlPgName  [10][20];
extern int  g_iCtfKey;
extern int  g_iIctKey;
extern int  g_iDbtKey;
extern int  g_iIetKey;

/*
 *&N& ROUTINE NAME: TpeIfSet()
 *&A& ARGUMENTS:
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&   ����ƥΥH�ǳ� TPE �����Ҳդ�����:
 *&D&   ����ƥD�n�\��O�� sg_staIfModTbl �������e,�Ұʬ۹����������Ҳճs��
 *&D&   �{�� (attach program)
 *&D&
 *&D&   �U�C���Τ��@,�|�Ϧ���ư��楢��
 *&D&       1. Fork�@�Ӥl�{������
 *&D&       2. ����(Execl)�@�Ӥl�{������
 *&D&
 */

int
TpeIfSet (pcErrStep)
char *pcErrStep;
{
  FILE *zIfMod;
  int  i, j;
  int  iRc;
  int  iTblSize;
  int  iStatus;
  int  iChildPid, iWaitCode;
  char caFlName[FILE_NAME_LEN];
  char caBuf [256], *pcaToken;
  char caExePath [256];

  UCP_TRACE( P_TpeIfSet );

  *pcErrStep = '0';
  EmsShowData('0',"TPE COMPONENT Starting up....\n");
     
  memset (g_caIfVerName, 0, sizeof(g_caIfVerName));
  memset (g_caRlPgName, 0, sizeof(g_caRlPgName));
  memset (caFlName, 0, FILE_NAME_LEN);
  sprintf (caFlName, "%s/%s", (char *) getenv("III_DIR"), IFMOD_FILE);

  if ((zIfMod=fopen(caFlName,"r")) == NULL)
  {
    sprintf (g_caMsg,"<EMS> Failure to open [%s]! (errno:%d==>%s)",
             caFlName, errno, sys_errlist[errno]);
    ErrLog (1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END (OPEN_IFMOD_ERR);
  } 

  i = 0;
  memset (caBuf, 0, sizeof(caBuf));
  fgets (caBuf, sizeof (caBuf), zIfMod);

  do 
  {
     for (j=0; j<sizeof(caBuf); j++)
     if (caBuf[j] == '\n')
     {
       caBuf[j] = 0;
       break;
     }

     pcaToken = (char *)strtok (caBuf, " \t\n");
        
     if (pcaToken != NULL && pcaToken[0] != '#')
     {
        errno = 0;
        if (sizeof(sg_staIfModTbl[i].pcaModuleName) <= strlen (pcaToken))
        {
          sprintf (g_caMsg, 
                   "<EMS> Illegal parameter(%s) in emdifmod.dat.(errno:%d)",
                   pcaToken, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          fclose (zIfMod);
          UCP_TRACE_END (IFMOD_ENTRY_ERR);
        }
        memcpy (sg_staIfModTbl [i].pcaModuleName, pcaToken, strlen(pcaToken));

        pcaToken = (char *)strtok (NULL, " \t\n");
        
        if (pcaToken == NULL)
        {
          sprintf (g_caMsg, 
                   "<EMS> Illegal parameter(%s) in emdifmod.dat.(errno:%d)",
                   pcaToken, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          fclose (zIfMod);
          UCP_TRACE_END (IFMOD_ENTRY_ERR);
        }
        else
        if (sizeof(sg_staIfModTbl[i].pcaVersionName) <= strlen (pcaToken))
        {
          sprintf (g_caMsg, 
                   "<EMS> Illegal parameter(%s) in emdifmod.dat.(errno:%d)",
                   pcaToken, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          fclose (zIfMod);
          UCP_TRACE_END (IFMOD_ENTRY_ERR);
        }
        memcpy (sg_staIfModTbl [i].pcaVersionName, pcaToken, strlen(pcaToken));

        pcaToken = (char *)strtok (NULL, " \t\n");
        
        if (pcaToken == NULL)
        {
          sprintf (g_caMsg, 
                   "<EMS> Illegal parameter(%s) in emdifmod.dat.(errno:%d)",
                   pcaToken, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          fclose (zIfMod);
          UCP_TRACE_END (IFMOD_ENTRY_ERR);
        }
        else
        if (sizeof(sg_staIfModTbl[i].pcaLoadPgmName) <= strlen (pcaToken))
        {
          sprintf (g_caMsg, 
                   "<EMS> Illegal parameter(%s) in emdifmod.dat.(errno:%d)",
                   pcaToken, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          fclose (zIfMod);
          UCP_TRACE_END (IFMOD_ENTRY_ERR);
        }
        memcpy (sg_staIfModTbl [i].pcaLoadPgmName, pcaToken, strlen(pcaToken));

        pcaToken = (char *)strtok (NULL, " \t\n");
        
        if (pcaToken == NULL)
        {
          sprintf (g_caMsg, 
                   "<EMS> Illegal parameter(%s) in emdifmod.dat.(errno:%d)",
                   pcaToken, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          fclose (zIfMod);
          UCP_TRACE_END (IFMOD_ENTRY_ERR);
        }
        else
        if (sizeof(sg_staIfModTbl[i].pcaAttFunName) <= strlen (pcaToken))
        {
          sprintf (g_caMsg, 
                   "<EMS> Illegal parameter(%s) in emdifmod.dat.(errno:%d)",
                   pcaToken, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          fclose (zIfMod);
          UCP_TRACE_END (IFMOD_ENTRY_ERR);
        }
        memcpy (sg_staIfModTbl [i].pcaAttFunName, pcaToken, strlen(pcaToken));

        pcaToken = (char *)strtok (NULL, " \t\n");
        
        if (pcaToken == NULL)
        {
          sprintf (g_caMsg, 
                   "<EMS> Illegal parameter(%s) in emdifmod.dat.(errno:%d)",
                   pcaToken, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          fclose (zIfMod);
          UCP_TRACE_END (IFMOD_ENTRY_ERR);
        }
        else
        if (sizeof(sg_staIfModTbl[i].pcaIniFunName) <= strlen (pcaToken))
        {
          sprintf (g_caMsg, 
                   "<EMS> Illegal parameter(%s) in emdifmod.dat.(errno:%d)",
                   pcaToken, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          fclose (zIfMod);
          UCP_TRACE_END (IFMOD_ENTRY_ERR);
        }
        memcpy (sg_staIfModTbl [i].pcaIniFunName, pcaToken, strlen(pcaToken));

        pcaToken = (char *)strtok (NULL, " \t\n");
        
        if (pcaToken == NULL)
        {
          sprintf (g_caMsg, 
                   "<EMS> Illegal parameter(%s) in emdifmod.dat.(errno:%d)",
                   pcaToken, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          fclose (zIfMod);
          UCP_TRACE_END (IFMOD_ENTRY_ERR);
        }
        else
        if (sizeof(sg_staIfModTbl[i].pcaBgnFunName) <= strlen (pcaToken))
        {
          sprintf (g_caMsg, 
                   "<EMS> Illegal parameter(%s) in emdifmod.dat.(errno:%d)",
                   pcaToken, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          fclose (zIfMod);
          UCP_TRACE_END (IFMOD_ENTRY_ERR);
        }
        memcpy (sg_staIfModTbl [i].pcaBgnFunName, pcaToken, strlen(pcaToken));

        pcaToken = (char *)strtok (NULL, " \t\n");
        
        if (pcaToken == NULL)
        {
          sprintf (g_caMsg, 
                   "<EMS> Illegal parameter(%s) in emdifmod.dat.(errno:%d)",
                   pcaToken, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          fclose (zIfMod);
          UCP_TRACE_END (IFMOD_ENTRY_ERR);
        }
        else
        if (sizeof(sg_staIfModTbl[i].pcaEndFunName) <= strlen (pcaToken))
        {
          sprintf (g_caMsg, 
                   "<EMS> Illegal parameter(%s) in emdifmod.dat.(errno:%d)",
                   pcaToken, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          fclose (zIfMod);
          UCP_TRACE_END (IFMOD_ENTRY_ERR);
        }
        memcpy (sg_staIfModTbl [i].pcaEndFunName, pcaToken, strlen(pcaToken));

        pcaToken = (char *)strtok (NULL, " \t\n");
        
        if (pcaToken == NULL)
        {
          sprintf (g_caMsg, 
                   "<EMS> Illegal parameter(%s) in emdifmod.dat.(errno:%d)",
                   pcaToken, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          fclose (zIfMod);
          UCP_TRACE_END (IFMOD_ENTRY_ERR);
        }
        else
        if (sizeof(sg_staIfModTbl[i].pcaRelFunName) <= strlen (pcaToken))
        {
          sprintf (g_caMsg, 
                   "<EMS> Illegal parameter(%s) in emdifmod.dat.(errno:%d)",
                   pcaToken, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          fclose (zIfMod);
          UCP_TRACE_END (IFMOD_ENTRY_ERR);
        }
        memcpy (sg_staIfModTbl [i].pcaRelFunName, pcaToken, strlen(pcaToken));

        pcaToken = (char *)strtok (NULL, " \t\n");
        
        if (pcaToken == NULL)
        {
          sprintf (g_caMsg, 
                   "<EMS> Illegal parameter(%s) in emdifmod.dat.(errno:%d)",
                   pcaToken, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          fclose (zIfMod);
          UCP_TRACE_END (IFMOD_ENTRY_ERR);
        }
        else
        if (sizeof(sg_staIfModTbl[i].pcaDetFunName) <= strlen (pcaToken))
        {
          sprintf (g_caMsg, 
                   "<EMS> Illegal parameter(%s) in emdifmod.dat.(errno:%d)",
                   pcaToken, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          fclose (zIfMod);
          UCP_TRACE_END (IFMOD_ENTRY_ERR);
        }
        memcpy (sg_staIfModTbl [i].pcaDetFunName, pcaToken, strlen(pcaToken));

        pcaToken = (char *)strtok (NULL, " \t\n");
        
        if (pcaToken == NULL)
        {
          sprintf (g_caMsg, 
                   "<EMS> Illegal parameter(%s) in emdifmod.dat.(errno:%d)",
                   pcaToken, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          fclose (zIfMod);
          UCP_TRACE_END (IFMOD_ENTRY_ERR);
        }
        else
        if (sizeof(sg_staIfModTbl[i].pcaRlsePgmName) <= strlen (pcaToken))
        {
          sprintf (g_caMsg, 
                   "<EMS> Illegal parameter(%s) in emdifmod.dat.(errno:%d)",
                   pcaToken, errno);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          fclose (zIfMod);
          UCP_TRACE_END (IFMOD_ENTRY_ERR);
        }
        memcpy (sg_staIfModTbl [i].pcaRlsePgmName, pcaToken, strlen(pcaToken));

        i++;
     }

     fgets (caBuf, sizeof (caBuf), zIfMod);
  }  while (!feof(zIfMod));

  iTblSize = i;
  
  for (i=0; i<iTblSize; i++) {
    strcpy (g_caIfVerName[i], sg_staIfModTbl[ i ].pcaVersionName);
    strcpy (g_caRlPgName[i], sg_staIfModTbl[ i ].pcaRlsePgmName);
  }

  for (i=0; i<iTblSize; i++)
  {
    if ( strncmp(sg_staIfModTbl[ i ].pcaLoadPgmName, "NULL", 4) !=0 ) 
    {
      sprintf (caExePath, "%s/iii/bin/exe/%s",
              (char *) getenv("III_DIR"), sg_staIfModTbl [i].pcaLoadPgmName);

      if ((iChildPid = fork()) == 0)
      {
        if (execlp (caExePath, caExePath, "C", (char *)0) != 0)
        {
          sprintf (g_caMsg,
       "<EMS> Failure to fork & execute interface module [%s] (errno:%d==>%s)",
              caExePath, errno, sys_errlist[errno]);
          printf ("\n%s\n", g_caMsg);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          exit (EXEC_IFMOD_ERR);
        }
      }
      else
      {
        if(iChildPid == -1) 
        {
          sprintf (g_caMsg, "<EMS> Failure to fork [%s]! (errno:%d==>%s)",
                   caExePath, errno, sys_errlist[errno]);
          printf ("\n%s\n", g_caMsg);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          UCP_TRACE_END (FORK_IFMOD_ERR);
        }
      }      

      while ( (iWaitCode = wait(&iStatus)) != iChildPid ) ;

      if (iStatus == 0)
      {
        sprintf (g_caMsg,
                 "<EMS> Interface module [%s] forked & executed!",
                 caExePath);
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      }
      else
      {
        sprintf (g_caMsg,
                 "<EMS> Interface module [%s] ends abnormally!",
                 caExePath);
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        printf ("\n%s\n", g_caMsg);
        UCP_TRACE_END (FORK_IFMOD_ERR);
      }
    }
  }

  UCP_TRACE_END(0);
}
