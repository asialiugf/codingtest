
/*
 *&N& File : emstools.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int       DumpCwa()     ���禡��Control Process�ҥs��,�����P Fork
 *&N&                            �_�Ӫ� Tool Process ���,�@�t�Τ������@        
 *&N&                                     
 *&N&    int       SsaOperate()  �� SSA �U�ʧ@
 *&N&                                     
 *&N&    int       BrhOperate()  �� Bit Table �� Branch Node�U�ʧ@
 *&N&                                     
 *&N&    int       TermOperate() �� Bit Table �� Terminal Node�U�ʧ@
 *&N&                                     
 *&N&    int       GetBrhCode()  �̯��޴M��� Branch Node ���Ҧ���� 
 *&N&                                     
 *&N&    int       GetTmCode()   �̯��޴M��� Terminal Node ���Ҧ���� 
 *&N&                                     
 *&N&    int       SrhBrhCode()  �̤���N���M��� Branch Node ������
 *&N&                                     
 *&N&    int       SrhTmCode()   �̲׺ݾ��N���M��� Terminal Node ������
 *&N&                                     
 *&N&    int       UptBrhCode()  ��s�� Branch Node ���Ҧ���� 
 *&N&                                     
 *&N&    int       UptTmCode()   ��s�� Terminal Node ���Ҧ���� 
 *&N&                                     
 *&N&    int       ApdBrhCode()  �[�J�@�s�W�� Branch Node
 *&N&                                     
 *&N&    int       ApdTmCode()   �[�J�@�s�W�� Terminal Node
 *&N&                                     
 *&N&    int       DelBrhCode()  �R���@ Branch Node
 *&N&                                     
 *&N&    int       DelTmCode()   �R���@ Terminal Node
 *&N&                                     
 *&N&    int       PrepareSof()  �ǳƶǦ^Tool Process�� SOF �����Y���
 *&N&                                     
 *&N&    int       PackSendSof() ��X SOF �����Y��ƻP�Ǧ^��Ƥ��e
 *&N&                                     
 *&N&    int       SofDataSend() �z�L DCS �Ǧ^��X�᪺��Ƥ��e
 *&N&                                     
 */

#include "errlog.h"
#include "emctool.h" 
#include "dcs.h" 
#include "cwa.h" 
#include "emcpgdef.h" 

#define  DEST_NAME_LEN   10
#define  SEG_NAME_ERR    -1
#define  OPERATE_ERR     -2
#define  SOF_SEND_ERR    -3
#define  RCV_LEN_ERR     -4
#define  GET_BRHCODE_ERR -5
#define  NOT_FOUND       -6
#define  BRH_NXTOFF_ERR  -7
#define  GET_TMCODE_ERR  -8
#define  SEND_CMD_ERR    -9

#define  IS_DELETE       0x08

static   int   sg_iSessidx;
static   int   sg_iBrhNodeLen;
static   int   sg_iTmNodeLen;
static   char g_cProtType = '\0';

int g_iBrhCnt=0;
int g_iBrhOff=0;

int DumpCwa()
{
  static char   scProtocol[80];
  char   caProtoType[80];  /* enviroment variable buffer */
  struct DcsBuf stDcsBuf;
  struct DcsSiof stDcsSiof;
  int iRcvDataLen;
  int iStrCmdSize;
  int iOffset;
  struct  SifHeader  stSifHbuff;
  struct  SofHeader  stSofHbuff;
  struct  SSA        stSsaArea;
  struct  SPA        *pstSpa;
  struct  BrhArea    stBrhArea;
  struct  TermArea   stTmArea;
  char    cSeg;
  char    cOperation;
  char    caStatus[2];
  char    caRealData[DCS_MAX_DATA_LEN];
  char    cMoreData;
  int     iRealLen;
  short   sLen;
  int     iRc;
  int     iTotCnt,i;
  int     iStartBrh, iBrhCnt,iTmCnt;
  struct  CwaCtl stCwaCtl;
  char    *pcaBitTbl;
  int     iIdx,iTmOff;

  UCP_TRACE(P_DumpCwa);

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SPA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSpa);
  if (iRc != 0) {
    sprintf (g_caMsg, "<EMS> Failure to get SPA pointer! (iRc:%d)", iRc);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END(iRc);
  }

  sg_iBrhNodeLen = (int) pstSpa->cBrCodeLen ;
  sg_iTmNodeLen  = (int) pstSpa->cTmCodeLen ;

  /* get env III_PROTOCOL for protocol type */
  memset(scProtocol,0,sizeof(scProtocol));
  strcpy((char *)scProtocol, (char *)getenv("III_PROTOCOL"));
  if(scProtocol[0] != '\0') {
    g_cProtType = scProtocol[0];
  }
  else{
    g_cProtType = QUEUE_DCS;
  }

  /*   1.accept and read  */
  memcpy(McaDesCode(stDcsBuf),"00000tools",10);
  McRqstCode(stDcsBuf) = DCSACCEPTREAD;
  MlWaiTime(stDcsBuf) = DCS_BLOCK;
  MiDataLen(stDcsBuf) = DCS_MAX_DATA_LEN;
  MpstDcsSiof(stDcsBuf) = &stDcsSiof;
  McProto(stDcsBuf) = g_cProtType;
  DcsDispatch(&stDcsBuf);
  if(MiReply(stDcsBuf) != DCS_NORMAL)
  {
    sprintf(g_caMsg,
      "<EMS> Failure to accept & read from EMS! (reply:%d errno:%d)",
      MiReply(stDcsBuf),MiErrno(stDcsBuf));
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(MON_DCS_ERR);
  }
  
  sg_iSessidx = MiSesIdx(stDcsBuf);
  iRcvDataLen= MiDataLen(stDcsBuf) - 8 ;
  if(iRcvDataLen < sizeof(struct SifHeader)){
    sprintf(g_caMsg,
      "<EMS> Failure to accept & read from EMS! (reply:%d errno:%d)",
      MiReply(stDcsBuf),MiErrno(stDcsBuf));
    ErrLog(1000,g_caMsg,RPT_TO_LOG,McaData(stDcsBuf),iRcvDataLen);
    UCP_TRACE_END(MON_CMD_ERR);
  }

  memset (caRealData, 0, sizeof(caRealData));
  memcpy (&stSifHbuff, McaData(stDcsBuf), sizeof(struct SifHeader));
  cSeg = stSifHbuff.caTextId[0];
  cOperation = stSifHbuff.caTxnCode[0];

  memcpy (&iStartBrh, stSifHbuff.caFiller, sizeof(int));
  iRealLen = iRcvDataLen - sizeof(struct SifHeader); 

  switch(cSeg)  {
    case  CWA_SSA:
                 if (cOperation == RETRIEVE) {
	           iRc = SsaOperate(cOperation,&stSsaArea);
                   if (iRc == 0) {
                     caStatus[0] = 0x00;
                     caStatus[1] = 0x00;
                   }
                   else  {
                     caStatus[0] = 0x00;
                     caStatus[1] = ERR0001;
                   }
                   iRc = PrepareSof(cSeg,cOperation,&stSsaArea,
                                    sizeof(struct SSA),&caStatus);
                   if (iRc < 0) {
                     sprintf(g_caMsg,"DumpCwa:prepare SOF err=%d",iRc);
                     ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
                     UCP_TRACE_END(OPERATE_ERR);
                   }
                 }
                 else if (cOperation == UPDATE) {
                   iOffset = sizeof(struct SifHeader)+2;
                   if (iRealLen != sizeof(struct SSA)+2 ) {
                     UCP_TRACE_END(RCV_LEN_ERR);
                   }
                   memcpy(&stSsaArea,&McaData(stDcsBuf)[iOffset],iRealLen-2);
	           iRc = SsaOperate(cOperation,&stSsaArea);
                   if (iRc == 0) {
                     caStatus[0] = 0x00;
                     caStatus[1] = 0x00;
                   }
                   else  {
                     caStatus[0] = 0x00;
                     caStatus[1] = ERR0004;
                   }
                   iRc = PrepareSof(cSeg,cOperation,&stSsaArea,
                                   sizeof(struct SSA),&caStatus);
                   if (iRc < 0) {
                     sprintf(g_caMsg,"DumpCwa:prepare SOF err=%d",iRc);
                     ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
                     UCP_TRACE_END(OPERATE_ERR);
                   }
	         }
                 else {
                   sprintf(g_caMsg,"DumpCwa:SSA Wrong Operation %c",cOperation);
                   ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
                   UCP_TRACE_END(OPERATE_ERR);
                 }
                 break;
    case  BIT_BRH:
                 stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
                 stCwaCtl.cSegCode = CWA_SEG_BIT_START;
                 iRc = CwaLowCtlFac(&stCwaCtl,&pcaBitTbl);
                 if (iRc != 0) {
                   sprintf (g_caMsg,
                   "<EMS> Failure to get BIT pointer", RPT_TO_LOG, 0, 0);
                   ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
                   UCP_TRACE_END(iRc);
                 }
                 memcpy (&g_iBrhCnt, pcaBitTbl, sizeof(int));

                 switch(cOperation) {
                   case RETRIEVE:
                     iOffset = 0;
                     i = iStartBrh;
                     g_iBrhOff = 0;
                     do {
                       iRc = GetBrhCode(i, pcaBitTbl, &stBrhArea);
                       if (iRc != 0) {
                         sprintf(g_caMsg,"DumpCwa:Get BrhCode err=%d",iRc);
                         ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
                         break;
                       }    
                       else  {
                         sLen = sizeof(struct BrhArea);
                         memcpy(caRealData+iOffset,&sLen,sizeof(short)); 
                         iOffset += sizeof(short);
                         memcpy(caRealData+iOffset,&stBrhArea
                                ,sizeof(struct BrhArea));

                         iOffset += sizeof(struct BrhArea);
			 i++;
                         g_iBrhOff++;
                       }
                     } while ( g_iBrhOff < PAGE_LIMIT &&
                               stBrhArea.iNxtBrhOffset != -1);
                     /*  set len as 99 representing end of Brh data */
                     sLen = 99;
                     memcpy(caRealData+iOffset,&sLen,sizeof(short)); 
                     iOffset += sizeof(short);

                     if (iRc == 0) {  /* abort cause cMoreData == '0'  */
                       caStatus[0] = 0x00;
                       caStatus[1] = 0x00;
                     }
                     else  {         /* abort cause iRc != 0 */
                       caStatus[0] = 0x00;
                       caStatus[1] = ERR0002;
                     }
                     iRc = PrepareSof(cSeg,cOperation,caRealData,
                                      iOffset,&caStatus);
                     if (iRc < 0) {
                       sprintf(g_caMsg,"DumpCwa:prepare SOF err=%d",iRc);
                       ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
                       UCP_TRACE_END(OPERATE_ERR);
                     }
                     break;
                   case UPDATE:
                     iOffset = sizeof(struct SifHeader)+2;
                     if ( iRealLen != (sizeof(struct BrhArea)+2) ) {
                       UCP_TRACE_END(RCV_LEN_ERR);
                     }
                     memcpy(&stBrhArea,&McaData(stDcsBuf)[iOffset]
                            ,sizeof(struct BrhArea));
	             iRc = BrhOperate(cOperation,&stBrhArea);
                     if (iRc == 0) {
                       caStatus[0] = 0x00;
                       caStatus[1] = 0x00;
                     }
                     else  {
                       caStatus[0] = 0x00;
                       caStatus[1] = ERR0005;
                     }
                     iRc = PrepareSof(cSeg,cOperation,&stBrhArea,
                                      sizeof(struct BrhArea),&caStatus);
                     if (iRc < 0) {
                       sprintf(g_caMsg,"DumpCwa:prepare SOF err=%d",iRc);
                       ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
                       UCP_TRACE_END(OPERATE_ERR);
                     }
                     break;
                   case INSERT:
                     iOffset = sizeof(struct SifHeader)+2;
                     if ( iRealLen != (sizeof(struct BrhArea)+2) ) {
                       UCP_TRACE_END(RCV_LEN_ERR);
                     }
                     memcpy(&stBrhArea,&McaData(stDcsBuf)[iOffset]
                            ,sizeof(struct BrhArea));
	             iRc = BrhOperate(cOperation,&stBrhArea);
                     if (iRc == 0) {
                       caStatus[0] = 0x00;
                       caStatus[1] = 0x00;
                     }
                     else  {
                       caStatus[0] = 0x00;
                       caStatus[1] = ERR0008;
                     }
                     iRc = PrepareSof(cSeg,cOperation,&stBrhArea,
                                      sizeof(struct BrhArea),&caStatus);
                     if (iRc < 0) {
                       sprintf(g_caMsg,"DumpCwa:prepare SOF err=%d",iRc);
                       ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
                       UCP_TRACE_END(OPERATE_ERR);
                     }
                     break;
                   case DELETE:
                        memcpy(stBrhArea.caBrhId,
                               stSifHbuff.caBrhId,sg_iBrhNodeLen);
                        stBrhArea.caBrhId[sg_iBrhNodeLen] = '\0';
	                iRc = BrhOperate(cOperation,&stBrhArea);
                        if (iRc == 0) {
                          caStatus[0] = 0x00;
                          caStatus[1] = 0x00;
                        }
                        else  {
                          caStatus[0] = 0x00;
                          caStatus[1] = ERR0010;
                        }
                        iRc = PrepareSof(cSeg,cOperation,&stBrhArea,
                                         sizeof(struct BrhArea),&caStatus);
                        if (iRc < 0) {
                          sprintf(g_caMsg,"DumpCwa:prepare SOF err=%d",iRc);
                          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
                          UCP_TRACE_END(OPERATE_ERR);
                        }
                        break;
                   default:
                        sprintf(g_caMsg,"DumpCwa:BRH Wrong Op %c",cOperation);
                        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
                        UCP_TRACE_END(OPERATE_ERR);
                        break;
                 }
                 break;
    case  BIT_TRM:
                 stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
                 stCwaCtl.cSegCode = CWA_SEG_BIT_START;
                 iRc = CwaLowCtlFac(&stCwaCtl,&pcaBitTbl);
                 if (iRc != 0) {
                   sprintf (g_caMsg,
                   "<EMS> Failure to get BIT pointer", RPT_TO_LOG, 0, 0);
                   ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
                   UCP_TRACE_END(iRc);
                 }

                 memcpy(stBrhArea.caBrhId,
                        stSifHbuff.caBrhId,sg_iBrhNodeLen);
                 stBrhArea.caBrhId[sg_iBrhNodeLen] = '\0';
                 /* Get branch index first */
                 iRc = SrhBrhCode (&iIdx, pcaBitTbl, &stBrhArea);
                 if (iRc != 0 ) {
                   if (iRc == NOT_FOUND) {
                     UCP_TRACE_END(NOT_FOUND);
                   }
                   else {
                     UCP_TRACE_END(iRc);
                   }
                 }
                 /* use the branch index to get the branch record */
                 iRc = GetBrhCode(iIdx, pcaBitTbl, &stBrhArea);
                 if (iRc != 0) {
                   sprintf(g_caMsg,"DumpCwa:Get BrhCode err=%d",iRc);
                   ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
                   break;
                 }    

                 switch(cOperation) {
                   case RETRIEVE:
                        iOffset = 0;
                        i = 0;
                        iTmOff  = stBrhArea.iTermOffset;

                        do {
                          iRc = GetTmCode(i,iTmOff,&stTmArea);
                          if (iRc != 0) {
                            sprintf(g_caMsg,"DumpCwa:Get TmCode err=%d",iRc);
                            ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
                            break;
                          }    
                          else  {
                            iTmOff = stTmArea.iNxtTmOffset;
                            sLen = sizeof(struct TermArea);
                            memcpy(caRealData+iOffset,&sLen,sizeof(short)); 
                            iOffset += sizeof(short);
                            memcpy(caRealData+iOffset,&stTmArea
                                   ,sizeof(struct TermArea));
                            iOffset += sizeof(struct TermArea);
       	              	    i++;
                          }
                        } while ( iTmOff != -1);
                        sprintf(g_caMsg,"tot get Brh Cnt=%d & dump",i);
                        ErrLog(1000,g_caMsg,RPT_TO_LOG,caRealData,910);

                     /*  set len as 99 representing end of Brh data */
                     sLen = 99;
                     memcpy(caRealData+iOffset,&sLen,sizeof(short)); 
                     iOffset += sizeof(short);

                     if (iRc == 0) {  /* abort cause cMoreData == '0'  */
                       caStatus[0] = 0x00;
                       caStatus[1] = 0x00;
                     }
                     else  {         /* abort cause iRc != 0 */
                       caStatus[0] = 0x00;
                       caStatus[1] = ERR0003;
                     }

                     iRc = PrepareSof(cSeg,cOperation,caRealData,
                                      iOffset,&caStatus);
                     if (iRc < 0) {
                       sprintf(g_caMsg,"DumpCwa:prepare SOF err=%d",iRc);
                       ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
                       UCP_TRACE_END(OPERATE_ERR);
                     }

                     break;
                   case UPDATE:
                     iOffset = sizeof(struct SifHeader)+2;
                     if ( iRealLen != (sizeof(struct TermArea)+2) ) {
                       UCP_TRACE_END(RCV_LEN_ERR);
                     }
                     memcpy(&stTmArea,&McaData(stDcsBuf)[iOffset]
                            ,sizeof(struct TermArea));
	             iRc = TermOperate(cOperation,&stTmArea,&stBrhArea);
                     if (iRc == 0) {
                       caStatus[0] = 0x00;
                       caStatus[1] = 0x00;
                     }
                     else  {
                       caStatus[0] = 0x00;
                       caStatus[1] = ERR0006;
                     }
                     iRc = PrepareSof(cSeg,cOperation,&stTmArea,
                                      sizeof(struct TermArea),&caStatus);
                     if (iRc < 0) {
                       sprintf(g_caMsg,"DumpCwa:prepare SOF err=%d",iRc);
                       ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
                       UCP_TRACE_END(OPERATE_ERR);
                     }
                     break;
                   case INSERT:
                     iOffset = sizeof(struct SifHeader)+2;
                     if ( iRealLen != (sizeof(struct TermArea)+2) ) {
                       UCP_TRACE_END(RCV_LEN_ERR);
                     }
                     memcpy(&stTmArea,&McaData(stDcsBuf)[iOffset]
                            ,sizeof(struct TermArea));
	             iRc = TermOperate(cOperation,&stTmArea,&stBrhArea);
                     if (iRc == 0) {
                       caStatus[0] = 0x00;
                       caStatus[1] = 0x00;
                     }
                     else  {
                       caStatus[0] = 0x00;
                       caStatus[1] = ERR0008;
                     }
                     iRc = PrepareSof(cSeg,cOperation,&stTmArea,
                                      sizeof(struct TermArea),&caStatus);
                     if (iRc < 0) {
                       sprintf(g_caMsg,"DumpCwa:prepare SOF err=%d",iRc);
                       ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
                       UCP_TRACE_END(OPERATE_ERR);
                     }
                     break;
                   case DELETE:
                     iOffset = sizeof(struct SifHeader)+2;
                     if ( iRealLen != (sizeof(struct TermArea)+2) ) {
                       UCP_TRACE_END(RCV_LEN_ERR);
                     }
                     memcpy(&stTmArea,&McaData(stDcsBuf)[iOffset]
                            ,sizeof(struct TermArea));
	             iRc = TermOperate(cOperation,&stTmArea,&stBrhArea);
                     if (iRc == 0) {
                       caStatus[0] = 0x00;
                       caStatus[1] = 0x00;
                     }
                     else  {
                       caStatus[0] = 0x00;
                       caStatus[1] = ERR0010;
                     }
                     iRc = PrepareSof(cSeg,cOperation,&stTmArea,
                                      sizeof(struct TermArea),&caStatus);
                     if (iRc < 0) {
                       sprintf(g_caMsg,"DumpCwa:prepare SOF err=%d",iRc);
                       ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
                       UCP_TRACE_END(OPERATE_ERR);
                     }
                     break;
                   default:
                        sprintf(g_caMsg,"DumpCwa:TRM Wrong Op %c",cOperation);
                        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
                        UCP_TRACE_END(OPERATE_ERR);
                        break;
                 }
                 break;
    default:
                 sprintf(g_caMsg,"DumpCwa:Wrong Segment %c",cSeg);
                 ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
                 UCP_TRACE_END(SEG_NAME_ERR);
  }

  UCP_TRACE_END(0);
}

int
SsaOperate(cOperation,pstSsaArea)
char  cOperation;
struct SSA  *pstSsaArea;
{
  int    iRc;
  struct CwaCtl stCwaCtl;
  struct SSA *pstSsa;

  UCP_TRACE(P_SsaOperate);

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);

  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }

  switch(cOperation)  {
    case RETRIEVE:
         memcpy(pstSsaArea,pstSsa,sizeof(struct SSA));
         break;
    case UPDATE:
         memcpy(pstSsa,pstSsaArea,sizeof(struct SSA));
         break;
  } /* FOR  switch(cOperation)  */

  UCP_TRACE_END(0);
}

int
BrhOperate(cOperation,pstBrhArea)
char  cOperation;
struct BrhArea  *pstBrhArea;
{
  int    iRc;
  struct CwaCtl stCwaCtl;
  char   *pcaBitTbl;
  struct BitBrhTermSt stCCBuf;
  struct BrhArea  stCurBrhArea;
  int    iOffset;
  int    iBrhCnt;
  int    iIdx;

  UCP_TRACE(P_BrhOperate);

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_BIT_START;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcaBitTbl);
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }
  memcpy(&iBrhCnt,pcaBitTbl,sizeof(int));

  switch(cOperation)  {
    case UPDATE:
         iRc = SrhBrhCode (&iIdx, pcaBitTbl, pstBrhArea);
         if (iRc != 0 ) {
           if (iRc == NOT_FOUND) {
             UCP_TRACE_END(NOT_FOUND);
           }
           else {
             UCP_TRACE_END(iRc);
           }
         }
         iRc = UptBrhCode(iIdx,pstBrhArea);
         if (iRc != 0 ) {
           UCP_TRACE_END(iRc);
         }
         break;
    case INSERT:
         iRc = ApdBrhCode(pstBrhArea);
         if (iRc != 0 ) {
           UCP_TRACE_END(iRc);
         }
         break;
    case DELETE:
         iRc = SrhBrhCode (&iIdx, pcaBitTbl, pstBrhArea);
         if (iRc != 0 ) {
           if (iRc == NOT_FOUND) {
             UCP_TRACE_END(NOT_FOUND);
           }
           else {
             UCP_TRACE_END(iRc);
           }
         }
         iRc = DelBrhCode(iIdx,pstBrhArea);
         if (iRc != 0 ) {
           UCP_TRACE_END(iRc);
         }
         break;
  } /* FOR  switch(cOperation)  */
  UCP_TRACE_END(0);
}

int
TermOperate(cOperation,pstTmArea,pstBrhArea)
char  cOperation;
struct TermArea  *pstTmArea;
struct brhArea   *pstBrhArea;
{
  int iIdx,iRc;
 
  UCP_TRACE(P_TermOperate);

  switch(cOperation)  {
    case UPDATE:
      iRc = SrhTmCode(&iIdx,pstTmArea,pstBrhArea);
      if (iRc != 0 ) {
        if (iRc == NOT_FOUND) {
          UCP_TRACE_END(NOT_FOUND);
        }
        else {
          UCP_TRACE_END(iRc);
        }
      }
      iRc = UptTmCode(iIdx,pstTmArea,pstBrhArea);
      if (iRc != 0 ) {
        UCP_TRACE_END(iRc);
      }
      break;
    case INSERT:
      iRc = ApdTmCode(pstTmArea,pstBrhArea);
      if (iRc != 0 ) {
        UCP_TRACE_END(iRc);
      }
      break;
    case DELETE:
      iRc = SrhTmCode(&iIdx,pstTmArea,pstBrhArea);
      if (iRc != 0 ) {
        if (iRc == NOT_FOUND) {
          UCP_TRACE_END(NOT_FOUND);
        }
        else {
          UCP_TRACE_END(iRc);
        }
      }
      iRc = DelTmCode(iIdx,pstTmArea,pstBrhArea);
      if (iRc != 0 ) {
        UCP_TRACE_END(iRc);
      }
      break;
  }
  UCP_TRACE_END(0);
}

int
GetBrhCode (iIdx, pcaBitTbl, pstBrhArea)
int    iIdx;
char   *pcaBitTbl;
struct BrhArea  *pstBrhArea;
{
  int     i, iOffset;
  
  UCP_TRACE(P_GetBrhCode);
  
  iOffset = 8;
  memcpy (pstBrhArea, pcaBitTbl+iOffset, sizeof(struct BrhArea)); 
  for (i=0; i<iIdx; i++)  {
    while ( (pstBrhArea->cBrhStatus & IS_DELETE) != 0 ) {
      /* this node had been deleted ,look for next node directly  */
      iOffset =  pstBrhArea->iNxtBrhOffset;
      pstBrhArea = (struct BrhArea *) (pcaBitTbl + iOffset);
    }
      
    iOffset = pstBrhArea->iNxtBrhOffset;
    memcpy (pstBrhArea, pcaBitTbl+iOffset, sizeof(struct BrhArea)); 
  }

  UCP_TRACE_END(0);
}

int
GetTmCode(iIdx,iTmOff,pstTmArea)
int    iIdx;
int    iTmOff;
struct TermArea  *pstTmArea;
{
  struct  CwaCtl stCwaCtl;
  char    *pcaBitTbl;
  int     i,iOffset,iRc;
  
  UCP_TRACE(P_GetTmCode);
  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_BIT_START;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcaBitTbl);
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }
  
  memcpy(pstTmArea, pcaBitTbl+iTmOff,sizeof(struct TermArea) );
  for (i=0;i<iIdx;i++)  {
    while ( (pstTmArea->cTermStatus & IS_DELETE) != 0 ) {
      /* this node had been deleted ,look for next node directly  */
      iOffset =  pstTmArea->iNxtTmOffset;
      memcpy(pstTmArea, pcaBitTbl+iTmOff,sizeof(struct TermArea) );
    }
    iOffset = pstTmArea->iNxtTmOffset;
    memcpy(pstTmArea, pcaBitTbl+iTmOff,sizeof(struct TermArea) );
  }
  UCP_TRACE_END(0);
}

int
SrhBrhCode (piIdx, pcaBitTbl, pstBrhArea)
int    *piIdx;
char   *pcaBitTbl;
struct BrhArea  *pstBrhArea;
{
  int    iRc;
  struct BitBrhTermSt stCCBuf;
  struct BrhArea  stCurBrhArea;
  int    iOffset, iBrhCnt, i;

  i = 0;
  do {
    iRc = GetBrhCode(i, pcaBitTbl, &stCurBrhArea);
    if (iRc != 0) {
      sprintf(g_caMsg,"BitOperate:Get BrhCode err=%d",iRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(GET_BRHCODE_ERR);
    }    
    else  {
      if (strncmp(stCurBrhArea.caBrhId,pstBrhArea->caBrhId,sg_iBrhNodeLen)== 0){
        *piIdx = i;
        UCP_TRACE_END(0);
      }
    }
    i++;
  } while ( stCurBrhArea.iNxtBrhOffset != -1);

  UCP_TRACE_END(NOT_FOUND);
}

int
SrhTmCode(piIdx,pstTmArea,pstBrhArea)
int    *piIdx;
struct TermArea *pstTmArea;
struct BrhArea  *pstBrhArea;
{
  int    iRc;
  struct CwaCtl stCwaCtl;
  char   *pcaBitTbl;
  struct BitBrhTermSt stCCBuf;
  struct TermArea  stCurTmArea;
  int    iTmOffset;
  int    iTmCnt,i;

  UCP_TRACE(P_SrhTmCode);
  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_BIT_START;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcaBitTbl);
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }

  iTmOffset = pstBrhArea->iTermOffset;

  i = 0;
  do {
    iRc = GetTmCode(i,iTmOffset,&stCurTmArea);
    if (iRc != 0) {
      sprintf(g_caMsg,"SrhBrhCode:Get TmCode err=%d",iRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(GET_TMCODE_ERR);
    }    
    else  {
      if (strncmp(stCurTmArea.caTermId,pstTmArea->caTermId,sg_iTmNodeLen)== 0){
        *piIdx = i;
        UCP_TRACE_END(0);
      }
    }
    i++;
    iTmOffset = stCurTmArea.iNxtTmOffset;
  } while ( iTmOffset != -1);

  UCP_TRACE_END(NOT_FOUND);
}

int
UptBrhCode(iIdx,pstBrhArea)
int    iIdx;
struct BrhArea  *pstBrhArea;
{
  struct  CwaCtl stCwaCtl;
  char    *pcaBitTbl;
  int     iOffset,i,iRc;
  struct  BrhArea  *pstUptBrhArea;
  
  UCP_TRACE(P_UptBrhCode);
  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_BIT_START;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcaBitTbl);
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }
  
  iOffset = 8   ;
  pstUptBrhArea = (struct BrhArea *) (pcaBitTbl + iOffset);
  for (i=0;i<iIdx;i++)  {
    while ( (pstUptBrhArea->cBrhStatus & IS_DELETE) != 0 ) {
      /* this node had been deleted ,look for next node directly  */
      iOffset =  pstUptBrhArea->iNxtBrhOffset;
      pstUptBrhArea = (struct BrhArea *) (pcaBitTbl + iOffset);
    }
    iOffset = pstUptBrhArea->iNxtBrhOffset;
    pstUptBrhArea = (struct BrhArea *) (pcaBitTbl + iOffset);
  }
  memcpy(pstUptBrhArea,pstBrhArea,sizeof(struct BrhArea));
  UCP_TRACE_END(0);
}

int
UptTmCode(iIdx,pstTmArea,pstBrhArea)
int    iIdx;
struct TermArea *pstTmArea;
struct BrhArea  *pstBrhArea;
{
  struct  CwaCtl stCwaCtl;
  char    *pcaBitTbl;
  int     iTmOffset,iRc,i;
  struct  TermArea  *pstUptTmArea;
  
  UCP_TRACE(P_UptTmCode);
  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_BIT_START;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcaBitTbl);
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }
  
  iTmOffset =  pstBrhArea->iTermOffset  ;
  pstUptTmArea = (struct TermArea *) (pcaBitTbl + iTmOffset);
  for (i=0;i<iIdx;i++)  {
    while ( (pstUptTmArea->cTermStatus & IS_DELETE) != 0 ) {
      /* this node had been deleted ,look for next node directly  */
      iTmOffset =  pstUptTmArea->iNxtTmOffset;
      pstUptTmArea = (struct TermArea *) (pcaBitTbl + iTmOffset);
    }
    iTmOffset = pstUptTmArea->iNxtTmOffset;
    pstUptTmArea = (struct TermArea *) (pcaBitTbl + iTmOffset);
  }
  memcpy(pstUptTmArea,pstTmArea,sizeof(struct TermArea));

  UCP_TRACE_END(0);
}

int
ApdBrhCode(pstBrhArea)
struct BrhArea  *pstBrhArea;
{
  struct  CwaCtl stCwaCtl;
  char    *pcaBitTbl;
  int     iOffset,i,iRc;
  struct  BrhArea  *pstLastBrhArea;
  int     iBrhCnt;
  int     iNxtAvailOff;
  
  UCP_TRACE(P_ApdBrhCode);
  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_BIT_START;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcaBitTbl);
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }
  memcpy(&iNxtAvailOff,pcaBitTbl+4,sizeof(int));
  
  iOffset = 8   ;

  do {
  pstLastBrhArea = (struct BrhArea *) (pcaBitTbl + iOffset);
  iOffset = pstLastBrhArea->iNxtBrhOffset;
  } while (iOffset != -1);

  pstLastBrhArea->iNxtBrhOffset = iNxtAvailOff;
  pstBrhArea->iNxtBrhOffset = -1;
  memcpy(pcaBitTbl+iNxtAvailOff,pstBrhArea,sizeof(struct BrhArea));
  iNxtAvailOff += sizeof(struct BrhArea);
  iBrhCnt++;
  memcpy(pcaBitTbl+4,&iNxtAvailOff,sizeof(int));
  memcpy(pcaBitTbl,&iBrhCnt,sizeof(int));
  
  UCP_TRACE_END(0);
}

int
ApdTmCode(pstTmArea,pstBrhArea)
struct TermArea *pstTmArea;
struct BrhArea  *pstBrhArea;
{
  struct  CwaCtl stCwaCtl;
  char    *pcaBitTbl;
  int     iTmOffset,i,iRc;
  struct  TermArea  *pstLastTmArea;
  int     iTmCnt;
  int     iNxtAvailOff;
  
  UCP_TRACE(P_ApdTmCode);
  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_BIT_START;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcaBitTbl);
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }
  memcpy(&iNxtAvailOff,pcaBitTbl+4,sizeof(int));
  
  iTmOffset = pstBrhArea->iTermOffset;

  do {
  pstLastTmArea = (struct TermArea *) (pcaBitTbl + iTmOffset);
  iTmOffset = pstLastTmArea->iNxtTmOffset;
  } while (iTmOffset != -1);

  pstLastTmArea->iNxtTmOffset = iNxtAvailOff;
  pstTmArea->iNxtTmOffset = -1;
  memcpy(pcaBitTbl+iNxtAvailOff,pstTmArea,sizeof(struct TermArea));
  iNxtAvailOff += sizeof(struct TermArea);
  pstBrhArea->iNoOfTerm++;
  memcpy(pcaBitTbl+4,&iNxtAvailOff,sizeof(int));
  
  UCP_TRACE_END(0);
}

int
DelBrhCode(iIdx,pstBrhArea)
int    iIdx;
struct BrhArea  *pstBrhArea;
{
  struct  CwaCtl stCwaCtl;
  char    *pcaBitTbl;
  int     iOffset,i,iRc;
  struct  BrhArea  *pstDelBrhArea;
  int     iBrhCnt;
  
  UCP_TRACE(P_DelBrhCode);
  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_BIT_START;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcaBitTbl);
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }

  memcpy(&iBrhCnt,pcaBitTbl,sizeof(int));
  
  iOffset = 8   ;
  pstDelBrhArea = (struct BrhArea *) (pcaBitTbl + iOffset);
  for (i=0;i<iIdx;i++)  {
    while ( (pstDelBrhArea->cBrhStatus & IS_DELETE) != 0 ) {
      /* this node had been deleted ,look for next node directly  */
      iOffset =  pstDelBrhArea->iNxtBrhOffset;
      pstDelBrhArea = (struct BrhArea *) (pcaBitTbl + iOffset);
    }
    iOffset = pstDelBrhArea->iNxtBrhOffset;
    pstDelBrhArea = (struct BrhArea *) (pcaBitTbl + iOffset);
  }
  pstDelBrhArea->cBrhStatus |= IS_DELETE;  /* set the delete bit ON  */
  iBrhCnt--;
  memcpy(pcaBitTbl,&iBrhCnt,sizeof(int));

  UCP_TRACE_END(0);
}

int
DelTmCode(iIdx,pstTmArea,pstBrhArea)
int    iIdx;
struct TermArea *pstTmArea;
struct BrhArea  *pstBrhArea;
{
  struct  CwaCtl stCwaCtl;
  char    *pcaBitTbl;
  int     iTmOffset,i,iRc;
  struct  TermArea  *pstDelTmArea;
  
  UCP_TRACE(P_DelTmCode);
  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_BIT_START;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcaBitTbl);
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }
  
  iTmOffset = pstBrhArea->iTermOffset;
  pstDelTmArea = (struct TermArea *) (pcaBitTbl + iTmOffset);
  for (i=0;i<iIdx;i++)  {
    while ((pstDelTmArea->cTermStatus & IS_DELETE) != 0 ) {
      /* this node had been deleted ,look for next node directly  */
      iTmOffset =  pstDelTmArea->iNxtTmOffset;
      pstDelTmArea = (struct TermArea *) (pcaBitTbl + iTmOffset);
    }
    iTmOffset = pstDelTmArea->iNxtTmOffset;
    pstDelTmArea = (struct TermArea *) (pcaBitTbl + iTmOffset);
  }
  pstDelTmArea->cTermStatus |= IS_DELETE;  /* set the delete bit ON  */
  pstBrhArea->iNoOfTerm--;

  UCP_TRACE_END(0);
}

int 
PrepareSof(cSeg,cOp,pcaRtnStr,iStrLen,pcaStatus)
char  cSeg;
char  cOp;
char  *pcaRtnStr;
int   iStrLen;
char  *pcaStatus;
{
  struct  SofHeader  stSofHbuff;   
  int     iOffset=0;
  short   iLen;
  short   sStatus;
  int     iRc;
  
  UCP_TRACE(P_PrepareSof);

  memset (&stSofHbuff, 0, sizeof(stSofHbuff));
  memcpy (&sStatus, pcaStatus, 2);
  memcpy (stSofHbuff.caBrhId, &g_iBrhCnt, sizeof(int));
  memcpy (stSofHbuff.caTermId, &g_iBrhOff, sizeof(int));

  stSofHbuff.caFmh[0] = cOp;
  if ( sStatus == 0) {
    stSofHbuff.caFormId[0] = cSeg;
    memcpy(stSofHbuff.caStatus,pcaStatus,2);
  }
  else {
    stSofHbuff.caFormId[0] = pcaStatus[1];
    stSofHbuff.caStatus[0] = 0x00;
    stSofHbuff.caStatus[1] = 0x01;
  }

  iRc = PackSendSof(cOp,sStatus,pcaRtnStr,iStrLen,&stSofHbuff);
  if (iRc < 0) {
    sprintf(g_caMsg,"PrepareSof:PackSendSof err=%d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(SOF_SEND_ERR);
  }  
  UCP_TRACE_END(0);
}

int
PackSendSof(cOp,sStatus,pcaRtnStr,iStrLen,pstSofHbuff)
char  cOp;
short sStatus;
char  *pcaRtnStr;
int   iStrLen;
char  *pstSofHbuff;
{
  short  sOffset=0;
  short  sLen=0;  
  int    iLen;
  int  iRc;
  char    caSendBuf[DCS_MAX_DATA_LEN];

    UCP_TRACE(P_PackSendSof);
    /* only when retrieve data and retrieve ok, send back the series data */
    /* other cases, only send back the sof header                         */
    memset(caSendBuf,0,sizeof(caSendBuf));  
    
    if ( (cOp == RETRIEVE) && (sStatus == 0) )  {
      memcpy(caSendBuf,pstSofHbuff,sizeof(struct SofHeader));
      sOffset += sizeof(struct SofHeader);
      sLen = (short) iStrLen;
      memcpy(caSendBuf+sOffset,&sLen,sizeof(short));
      sOffset += sizeof(short);
      memcpy(caSendBuf+sOffset,pcaRtnStr,sLen);
      sOffset += sLen;
    }
    else {      /* Other case  */      
      memcpy(caSendBuf,pstSofHbuff,sizeof(struct SofHeader));
      sOffset = sizeof(struct SofHeader);
    }
  
    iLen = (int) sOffset;

    iRc = SofDataSend(iLen,caSendBuf,'0',sg_iSessidx);
    if (iRc < 0) {
      sprintf(g_caMsg,"PackSendSof:SofDataSend err=%d",iRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(SOF_SEND_ERR);
    }  /* FOR if (sStatus ==0)  */
    
    UCP_TRACE_END(0);
}

/*
 *&N& ROUTINE NAME:SofDataSend()
 *&A& ARGUMENTS:
 *&A&    NAME         TYPE            DESCRIPTION
 *&A& -------------  ------  -------------------------------
 *&A&
 *&R& RETURN VALUE(S):
 *&R&  0 : ������J��Ʀ��\
 *&R& SEND_CMD_ERR : ������J��ƥ���
 *&R&
 *&D& DESCRIPTION
 *&D&
 */
int
SofDataSend(iDataLen, caData, cMoreData,iSessIdx)
int iDataLen;
char *caData;
char cMoreData;
int  iSessIdx;
{
  char caProtoType[80];  /* enviroment variable buffer */
  static struct DcsBuf stDcsBuf;
  static struct DcsSiof stDcsSiof;

  UCP_TRACE( P_SofDataSend );
  /*
  ErrLog(4000,"SofDataSend() DATA:",RPT_TO_LOG,caData,iDataLen);
  ErrLog(4000,"SofDataSend() FLAG:",RPT_TO_LOG,&cMoreData,1);
  */
  memset(&stDcsBuf,0,sizeof(struct DcsBuf));
  memset(&stDcsSiof,0,sizeof(struct DcsSiof));

  if (g_cProtType == '\0') {
    memset(caProtoType, 0, sizeof(caProtoType));
    strcpy(caProtoType, (char *)getenv("III_PROTOCOL"));
    if (caProtoType[0] != '\0') {
      g_cProtType = caProtoType[0];
    }
    else {
      g_cProtType = QUEUE_DCS;
    }
  } 

  MpstDcsSiof(stDcsBuf) = &stDcsSiof;
  McMoreByte(stDcsBuf) = cMoreData;
  memcpy(McaDesCode(stDcsBuf), "00000tools", DEST_NAME_LEN);

  if (cMoreData != '1') {
    McRqstCode(stDcsBuf) = DCSWRDISCONECT;
  }
  else {
    McRqstCode(stDcsBuf) = DCSWRITE;
  }

  memcpy(McaData(stDcsBuf), caData, iDataLen);
  MlWaiTime(stDcsBuf) = DCS_BLOCK;
  /*
  sprintf(McaDataLen(stDcsBuf),"%.4d",iDataLen + 8);
  ErrLog(4000,"EmsDataSend() McaDataLen:",RPT_TO_LOG,McaDataLen(stDcsBuf),5);
  */

  MiDataLen(stDcsBuf) = iDataLen + 8;
  McProto(stDcsBuf) = g_cProtType;
  /*
   * Add by Chi Fu-Song   1994/07/19 
   * Assign Sessin id to stDcsBuf.stDcsInfo.iSesIdx
   */
  MiSesIdx(stDcsBuf) = sg_iSessidx ;
  /*
  ErrLog(4000,"EmsDataSend() DcsBuf.DcsInfo:",RPT_TO_LOG,&stDcsBuf.stDcsInfo,
       sizeof(struct DcsInfo) );
  ErrLog(4000,"EmsDataSend() DcsBuf.unData:",RPT_TO_LOG,
       stDcsBuf.unData.pstDcsSiof,200);
  */     
  DcsDispatch( &stDcsBuf );

  if (MiReply(stDcsBuf) != DCS_NORMAL) {
    sprintf( g_caMsg, "EmsDataSend: DcsDispatch() fails! reply=%d",
             MiReply(stDcsBuf) );
    ErrLog(4000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( SEND_CMD_ERR, g_caMsg );
    UCP_TRACE_END( SEND_CMD_ERR );
  }
  
  UCP_TRACE_END( 0 );
}

