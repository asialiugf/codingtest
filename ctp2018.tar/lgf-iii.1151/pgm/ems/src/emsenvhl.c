/**
                            �z�w�w�w�w�w�{
                            �xemsenvhl.c�x
                            �u�w�w�w�w�w�t
                            �xEnvSetup()�x
                            �|�w�w�s�w�w�}
      �z�w�w�w�w�w�w�w�w�w�w�w�w�w�r
�z�w�w�r�w�w�{�z�w�w�w�w�w�{�z�w�w�w�w�w�w�w�{
�xemsighld.c�x�x          �x�x              �x
�u�w�w�w�w�w�t�u�w�w�w�w�w�t�u�w�w�w�w�w�w�w�t
�xSignlHdl()�x�xGetConfg()�x�x EnvStatuChk()�x
�|�w�w�w�w�w�}�|�w�w�w�w�w�}�|�w�w�w�w�w�w�w�}

 **/

/*
 *&N& ROUTINE NAME: EnvSetup()
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&           
 *&R& RETURN VALUES:
 *&R& 
 *&R&           
 *&R&           
 *&D& DESCRIPTION:           
 *&D&     ����Ƭ��t�����ҫظm�P��l��.���� Kernel �һݤ��t�θ귽���o,
 *&D&     �P�t�Ϊ��椧  �J.
 *&D&   1.�t�ο��~�O���ɪ��ƥ��P�M��.
 *&D&   2.�T���B�z�{���]�w.
 *&D&   3.���o�t�ΰѼ�.
 *&D&   4.TPE�Ұʪ��A�ˬd.
 *&D&   5.CWA�����o�P���e�ˬd,�]�w.
 *&D&   6.  �JKernel����L�w�q����.
 *&D&           
 *&D&           
 */

#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "errlog.h"
#include "cwa.h"
#include "emcenvhl.h"
#include "emctldef.h"
#include "emcpgdef.h"
/*
#define  MAX_BR_NUM         500
*/
#define  MAX_TERM_NUM       100
#define  MAX_BRH_CODE_LEN   10
#define  MAX_TERM_CODE_LEN  4
#define  MAX_TERM_NAME_LEN  14
#define  LOAD_BIT_ERR       -4
#define  CWA_MODNO          4       /* CWA save modulo no.            */
#define  FILE_NAME_LEN      80
#define  SYSTEM_STARTED     0x8000 /* 1:started ; 0:not started */
#define  SYSTEM_RESTART     0x4000 /* 1:restarted ; 0:Normal Begin */
#define  ONLINE_CLOSE       0x0400 /* 1:Batch ; 0:On_line        */
#define  REENTRY_TM         '9'
#define  DELIMITER          " \t\n"

struct CWA  *pstCwa;
struct MDA  *pstMda;
int         g_iMdaFlag=0;
/* ====================================================================*/
/* Declarations for extern variables                               */
/* ====================================================================*/
extern int  g_iCtfKey;
extern int  g_iDbtKey;
extern int  g_iIctKey;
extern int  g_iIetKey;
extern int  g_iCwaKey;
extern int  g_iSysOpMode;
extern int  g_iTestMode;
extern int  g_iBrhNodeLen;
extern int  g_iTermNodeLen;
extern int  g_iTxnCodeLen;
extern int  g_iTellerCodeLen;
extern int  g_iLoadCvtTbl;
extern int  g_iSystemRole;
extern int  g_iBaseYear;
extern int  g_iNoBatch;
extern int  g_iNoSignon;
extern int  g_iMaxPacketSize;
extern int  g_iTmax;
extern int  g_iTmin;
extern int  g_iToffset;

extern char g_cByPassInput;
extern int  g_iPassUsr;
extern int  g_iTotTmNum;
extern int  g_iBrhNodeNum;
extern int  g_iFirstRun;

extern int  errno;
extern char *sys_errlist[];
extern int  g_iBitSize;
/* ====================================================================*/

int
EnvSetup(cErrStep)
char *cErrStep;
{
  int  iRc;
  char caFlName[81];

  UCP_TRACE(P_EnvSetup);
  
  *cErrStep = '0';
  sprintf (caFlName, "%s/%s", (char *)getenv("III_DIR"), CUSTOM_FILE);
  iRc = InitCusTbl(caFlName);
  if ( iRc < 0 ){
    UCP_TRACE_END(INIT_CUSTOMTBL_ERR);
  }

  g_iPassUsr = GetCusValue( PASSWORD_USER );
  if (g_iPassUsr < 0){
    UCP_TRACE_END(GET_CUSTOMVALUE_ERR);
  }
 
  /* added by WuChihLiang 19960207 for double-mechine switch */ 
  if ( g_cByPassInput != 'y'){
    PassWord(g_iPassUsr);
  }

  ShowVerRtn();

  iRc = SignlHdl();
  if (iRc != 0) {
    *cErrStep = '1';
    UCP_TRACE_END(SIGNAL_HDL_ERR);
  }

  iRc = EnvStatuChk();
  if (iRc == 0) {
    *cErrStep = '3';
    UCP_TRACE_END(CWA_HAD_EXISTED_ERR); 
  }

  EmsShowData('0',"TPE Kernel starting up......\n");
  iRc = CwaHdl();
  if (iRc != 0) {
    *cErrStep = '4';
    UCP_TRACE_END(iRc);
  }

  EmsShowData('0',"TPE System Tables Loading.....\n");
  iRc = KernTblLd();
  if (iRc != 0) {
    *cErrStep = '5';
    UCP_TRACE_END(iRc);
  }

  UCP_TRACE_END(0);

}  /* EnvSetup(*cErrStep) */

/*
 *&N& ROUTINE NAME: EnvStatuChk()
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&           
 *&R& RETURN VALUES:
 *&R&   0  :  ���Ұ�TPE.
 *&R&   1  :  �Ұ�TPE.
 *&R&           
 *&D& DESCRIPTION:           
 *&D&   ����Ƭ� TPE �Ұʪ��A�ˬd,�èM�w�O�_���s�Ұ� TPE.
 *&D&   1.�I�sCwaCtlFac()Ū�o CWA ��,�Y���o���ܤw��TPE�Ұ�.
 *&D&   2.�I�sPassRest(),�w��TPE�Ұʮ�,�T�w�O�_���s�Ұ� TPE.
 *&D&           
 *&D&           
 */


int
EnvStatuChk()
{
  int iRc;
  struct CwaCtl stCwaCtl;
  struct CwaCreatIobuf stCCBuf;

  UCP_TRACE(P_EnvStatuChk);

  stCwaCtl.cFunCode = CWA_GET_ID;
  stCCBuf.iShmKey = g_iCwaKey;
  stCCBuf.iSemKey = g_iCwaKey;
  
  iRc = CwaCtlFac(&stCwaCtl,&stCCBuf);
  if (iRc == CWA_NORMAL) {
    EmsShowData('0',"EMS had been started !!\n");
    EmsShowData('0',"Please Check Before Running EMS !!\n");
    UCP_TRACE_END(0); 
  }
  
  UCP_TRACE_END(1);

} /* EnvStatuChk() */


/*
 *&N& ROUTINE NAME: CwaHdl()
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&           
 *&R& RETURN VALUES:
 *&R& 
 *&R&           
 *&R&           
 *&D& DESCRIPTION:           
 *&D&   ����Ƭ�CWA�����o,���e  �J.
 *&D&   1.�I�sCwaCtlFac()���o CWA.
 *&D&   2.�I�sCwaLoad() �J�t�ΰѼ�.
 *&D&   3.�I�sBitLoad() �J�׺ݾ��������.
 *&D&           
 *&D&           
 */

int
CwaHdl()
{
  int iRc;
  struct CwaCtl stCwaCtl;
  struct CwaCreatIobuf stCCBuf;

  UCP_TRACE(P_CwaHdl);

  iRc = GetBitSize ();
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }

  stCwaCtl.cFunCode = CWA_CREAT;
  stCCBuf.iShmKey = g_iCwaKey;
  stCCBuf.iSemKey = g_iCwaKey;
  iRc = CwaCtlFac(&stCwaCtl,&stCCBuf);
  if (iRc != CWA_NORMAL) {
    UCP_TRACE_END(CREATE_CWA_ERR);
  }

  stCwaCtl.cFunCode = CWA_ATTACH;
  iRc = CwaCtlFac(&stCwaCtl,&stCCBuf);
  if (iRc != 0) {
    UCP_TRACE_END(ATTACH_CWA_ERR);
  }

  iRc = CwaLoad();
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }
  
  UCP_TRACE_END(0);

} /* CwaHdl() */

/*
 *&N& ROUTINE NAME: KernlTblLd()
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&           
 *&R& RETURN VALUES:
 *&R&     0  :  ���`
 *&R&           
 *&R&           
 *&D& DESCRIPTION:           
 *&D&   ����Ƭ�  �JKernel����L�w�q����.
 *&D&   1.  �J�@�P����榡��(CFT) : �I�s CtfBuild().
 *&D&   2.  �J�����J�s���(IET) : �I�s TxnBuild().
 *&D&     2.2 ��Ū�J��ƪ��פ���  �J��ƪ�(iLoadSize)�h�H�t�@�ɦL��Ū�J,�Y���ɪ� *&D&         �׬Ҥ���  �J��ƪ�,�h�NCWA(InitCwa()),��BIT����(InitBit())��l��.
 *&D&   3.�I�sCwaLowCtlFac()���oCWA��SSA�ҩl��}(pstSsa).
 *&D&   4.�I�sCwaLowCtlFac()���o�׺ݱ������(BIT)�ҩl��}(pcaBitTbl).
 *&D&   5.�I�sBitLoad(pcaBitTbl) �J�׺ݱ������.
 *&D&   6.�N�|�ͪ���(pstaSess)��l��.
 *&D&     6.1 �I�sCwaLowCtlFac()���oSessTbl�ҩl��}(pstaSess).
 *&D&           
 */

int
KernTblLd()
{
  int iRc;
  char *pcCtfBas;

  UCP_TRACE(P_KernTblLd);

  iRc = CtfBuild(&pcCtfBas);
  if (iRc < 0) {
    sprintf(g_caMsg,"<EMS> Failure to build CTF table! (iRc:%d)",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(iRc);
  }

  iRc = TxnBuild();
  if (iRc < 0) {
    sprintf(g_caMsg,"<EMS> Failure to build IET table! (iRc:%d)",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(iRc);
  }

  iRc = ICTBuild(pcCtfBas);
  if (iRc < 0) {
    sprintf(g_caMsg,"<EMS> Failure to build ICT table! (iRc:%d)",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(iRc);
  }

  UCP_TRACE_END(0);

}

#define CWA_DUMP_ERR  -1

/*
 *&N& ROUTINE NAME: CwaLoad()
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&           
 *&R& RETURN VALUES:
 *&R&     0  :  ���`
 *&R&           
 *&R&           
 *&D& DESCRIPTION:           
 *&D&   ����Ƭ���CWA�ɦL�����,�NCWA���t�Ϊ��A�ϸ��(SSA)�β׺ݱ������(BIT)
 *&D&     �^ CWA.
 *&D&   1.�}��CWA�ɦL�����(SBCWA0_F,�MSBCWA1_F),�èM�w�Ѩ��ӶɦL��Ū�J:
 *&D&     1.1 �ɦL�Ǹ���(0,1,2,3)�`��,���ɦL�Ǹ��t����Ȭ�1�h�����j�Ǹ��ɦL��.
 *&D&         ���ɦL�Ǹ��t����Ȥ���1,�h�����p�Ǹ��ɦL��.
 *&D&     1.2 ��Ū�J��ƪ��פ���  �J��ƪ�(iLoadSize)�h�H�t�@�ɦL��Ū�J,�Y���ɪ�
 *&D&         �׬Ҥ���  �J��ƪ�,�h�NCWA(InitCwa()),��BIT����(InitBit())��l��.
 *&D&   2.�I�sCwaLowCtlFac()���oCWA��SSA�ҩl��}(pstSsa).
 *&D&   3.�I�sCwaLowCtlFac()���o�׺ݱ������(BIT)�ҩl��}(pcaBitTbl).
 *&D&   4.�I�sBitLoad(pcaBitTbl) �J�׺ݱ������.
 *&D&   5.�N�|�ͪ���(pstaSess)��l��.
 *&D&     5.1 �I�sCwaLowCtlFac()���oSessTbl�ҩl��}(pstaSess).
 *&D&           
 */


int
CwaLoad()
{
  int    iDump0Fd=0, iDump1Fd=0;
  int    iDumpSeqNo0=0, iDumpSeqNo1=0;
  int    iLoadSize0=0, iLoadSize1=0;
  int    i, iRc, iRc0, iRc1;
  int    iBitLoadFlag = 0;
  int    iBrhCnt, iBrhOffset;
  short  sStatus;
  char   *pcaBitTbl, caOpt[128];
  char   caFileName0 [FILE_NAME_LEN+1], caFileName1 [FILE_NAME_LEN+1];
  struct CwaCtl    stCwaCtl;
  struct SSA       *pstSsa;
  struct SPA       *pstSpa;
  struct SessTbl   *pstaSess;
  struct BrhArea   stBrhArea;
  struct TermArea  stTermArea;
  struct Big2Nhost *pstCnvPtr;
  struct stat      stStatBuf;
  char   *pcTermArea;

  UCP_TRACE(P_CwaLoad);

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);
  if (iRc != 0) {
    sprintf (g_caMsg, "<EMS> Failure to get SSA pointer!");
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END(GET_SSA_PTR_ERR);
  }

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SPA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSpa);
  if (iRc != 0) {
    sprintf (g_caMsg, "<EMS> Failure to get SPA pointer!");
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END(GET_SPA_PTR_ERR);
  }

  pstCwa = (struct CWA *) pstSsa;

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_BIT_START;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcaBitTbl);
  if (iRc != 0) {
    sprintf (g_caMsg, "<EMS> Failure to get BIT pointer!");
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END(GET_BIT_PTR_ERR);
  }

  g_iFirstRun = 0;    /* set the first time run flag as FALSE */ 

  sprintf (caFileName0, "%s/%s", (char *)getenv("III_DIR"), SBCWA0_F);
  iDumpSeqNo0 = CheckCwaFile (caFileName0, &iDump0Fd, &iLoadSize0);
  lseek (iDump0Fd, 0, SEEK_SET);

  sprintf (caFileName1, "%s/%s", (char *)getenv("III_DIR"), SBCWA1_F);
  iDumpSeqNo1 = CheckCwaFile (caFileName1, &iDump1Fd, &iLoadSize1);
  lseek (iDump1Fd, 0, SEEK_SET);

  /* Case 1: sbcwa0.bin ok, sbcwa1.bin corrupted */
  if (iDumpSeqNo1 == -CWA_MODNO && iDumpSeqNo0 != -CWA_MODNO)
  {
      sprintf (g_caMsg,
  "<Warning> The system file sbcwa1.bin is corrupted but sbcwa0.bin is ok!");
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    do 
    {
      printf (
  "<Warning> The system file sbcwa1.bin is corrupted but sbcwa0.bin is ok!\n");
      printf (" (0) Load CWA by sbcwa0.bin.\n");
      printf (" (1) Discard and initialize CWA.\n");
      printf (" Select option 0 or 1.\n");
      printf (" ==> ");
      gets (caOpt);
    } while ((caOpt[0] != '0') && (caOpt[0] != '1'));

    if (caOpt[0] == '0')
    {
       sprintf (g_caMsg,
       "<EMS> User select option [(0) Load CWA by sbcwa0.bin]");
       ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);

       iRc0 = read (iDump0Fd, pstCwa, (iLoadSize0-g_iBitSize)) ;
       iRc1 = read (iDump0Fd, pcaBitTbl, g_iBitSize) ;
       iRc = iRc0 + iRc1;
       if (iRc != iLoadSize0)
       {
         sprintf (g_caMsg,
"<EMS> The file sbcwa1.bin is corrupted, sbcwa0.bin is ok but unable to read.");
         ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
         InitCwa ((char *) pstCwa);
         InitBit (pcaBitTbl);
         iBitLoadFlag = 1;
         g_iFirstRun = 1;
       }
    }
    else
    {
      sprintf (g_caMsg,
      "<EMS> User select option [(1) Discard and initialize CWA]");
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);

      InitCwa ((char *) pstCwa);
      InitBit (pcaBitTbl);
      iBitLoadFlag = 1;
      g_iFirstRun = 1;
    }
  }
  else
  /* Case 2: sbcwa1.bin ok, sbcwa0.bin corrupted */
  if (iDumpSeqNo0 == -CWA_MODNO && iDumpSeqNo1 != -CWA_MODNO)
  {
      sprintf (g_caMsg,
  "<Warning> The system file sbcwa0.bin is corrupted but sbcwa1.bin is ok!");
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    do 
    {
      printf (
  "<Warning> The system file sbcwa0.bin is corrupted but sbcwa1.bin is ok!\n");
      printf (" (0) Load CWA by sbcwa1.bin.\n");
      printf (" (1) Discard and initialize CWA.\n");
      printf (" Select option 0 or 1.\n");
      printf (" ==> ");
      gets (caOpt);
    } while ((caOpt[0] != '0') && (caOpt[0] != '1'));

    if (caOpt[0] == '0')
    {
       sprintf (g_caMsg,
       "<EMS> User select option [(0) Load CWA by sbcwa1.bin]");
       ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);

       iRc0 = read (iDump1Fd, pstCwa, (iLoadSize1-g_iBitSize)) ;
       iRc1 = read (iDump1Fd, pcaBitTbl, g_iBitSize) ;
       iRc = iRc0 + iRc1;
       if (iRc != iLoadSize1)
       {
         sprintf (g_caMsg,
"<EMS> The file sbcwa0.bin is corrupted, sbcwa1.bin is ok but unable to read.");
         ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
         InitCwa ((char *) pstCwa);
         InitBit (pcaBitTbl);
         iBitLoadFlag = 1;
         g_iFirstRun = 1;
       }
    }
    else
    {
      sprintf (g_caMsg,
      "<EMS> User select option [(1) Discard and initialize CWA]");
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);

      InitCwa ((char *) pstCwa);
      InitBit (pcaBitTbl);
      iBitLoadFlag = 1;
      g_iFirstRun = 1;
    }
  }
  else
  /* Case 3: sbcwa0.bin and sbcwa1.bin are ok */
  if (iDump0Fd != -1 && iDump1Fd != -1)
  {
    if (abs(iDumpSeqNo0 - iDumpSeqNo1) == 1) {
      if (iDumpSeqNo0 > iDumpSeqNo1) {
        iRc0 = read (iDump0Fd, pstCwa, iLoadSize0-g_iBitSize) ;
        iRc1 = read (iDump0Fd, pcaBitTbl, g_iBitSize) ;
        iRc = iRc0 + iRc1;
        if (iRc != iLoadSize0){
          iRc0 = read (iDump1Fd, pstCwa, iLoadSize1-g_iBitSize) ;
          iRc1 = read (iDump1Fd, pcaBitTbl, g_iBitSize) ;
          iRc = iRc0 + iRc1;
          if (iRc != iLoadSize1){
            sprintf (g_caMsg,
"<EMS> Both of sbcwa0.bin/sbcwa1.bin ok, but failure to read. Initialize CWA.");
            ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
            InitCwa ((char *) pstCwa);
            InitBit (pcaBitTbl);
            iBitLoadFlag = 1;
            g_iFirstRun = 1;
          }
        }
      }
      else{
        iRc0 = read (iDump1Fd, pstCwa, iLoadSize1-g_iBitSize) ;
        iRc1 = read (iDump1Fd, pcaBitTbl, g_iBitSize) ;
        iRc = iRc0 + iRc1;
        if (iRc != iLoadSize1){
          iRc0 = read (iDump0Fd, pstCwa, iLoadSize0-g_iBitSize) ;
          iRc1 = read (iDump0Fd, pcaBitTbl, g_iBitSize) ;
          iRc = iRc0 + iRc1;
          if (iRc != iLoadSize0){
            sprintf (g_caMsg,
"<EMS> Both of sbcwa0.bin/sbcwa1.bin ok, but failure to read. Initialize CWA.");
            ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
            InitCwa ((char *) pstCwa);
            InitBit (pcaBitTbl);
            iBitLoadFlag = 1;
            g_iFirstRun = 1;
          }
        }
      }
    }
    else {
      if (iDumpSeqNo1 >= iDumpSeqNo0) {
        iRc0 = read (iDump0Fd, pstCwa, iLoadSize0-g_iBitSize) ;
        iRc1 = read (iDump0Fd, pcaBitTbl, g_iBitSize) ;
        iRc = iRc0 + iRc1;
        if (iRc != iLoadSize0) {
          iRc0 = read (iDump1Fd, pstCwa, iLoadSize1-g_iBitSize) ;
          iRc1 = read (iDump1Fd, pcaBitTbl, g_iBitSize) ;
          iRc = iRc0 + iRc1;
          if (iRc != iLoadSize1) {
            sprintf (g_caMsg,
"<EMS> Both of sbcwa0.bin/sbcwa1.bin ok, but failure to read. Initialize CWA.");
            ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
            InitCwa ((char *) pstCwa);
            InitBit (pcaBitTbl);
            iBitLoadFlag = 1;
            g_iFirstRun = 1;
          }
        }
      }
      else {
        if (iDumpSeqNo1 < iDumpSeqNo0) {
          iRc0 = read (iDump1Fd, pstCwa, iLoadSize1-g_iBitSize) ;
          iRc1 = read (iDump1Fd, pcaBitTbl, g_iBitSize) ;
          iRc = iRc0 + iRc1;
          if (iRc != iLoadSize1){
            iRc0 = read (iDump0Fd, pstCwa, iLoadSize0-g_iBitSize) ;
            iRc1 = read (iDump0Fd, pcaBitTbl, g_iBitSize) ;
            iRc = iRc0 + iRc1;
            if (iRc != iLoadSize0) {
            sprintf (g_caMsg,
"<EMS> Both of sbcwa0.bin/sbcwa1.bin ok, but failure to read. Initialize CWA.");
            ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
              InitCwa ((char *) pstCwa);
              InitBit (pcaBitTbl);
              iBitLoadFlag = 1;
              g_iFirstRun = 1;
            }
          }
        }
      }
    }
  }
  else
  /* Case 4: sbcwa0.bin and sbcwa1.bin do not exist  */
  {
    sprintf (g_caMsg,
      "<EMS> The system files sbcwa0.bin and sbcwa1.bin do not exist.");
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    InitCwa ((char *) pstCwa);
    InitBit (pcaBitTbl);
    iBitLoadFlag = 1;
    g_iFirstRun = 1;
  }

  sprintf (g_caMsg, "<EMS> TPE Initial Status : 0x%0x", 
           pstSsa->sSysStatus&0x0FFFF);
  ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);

  if ( (pstSsa->sSysStatus & SYSTEM_STARTED) )  {
    pstSsa->sSysStatus = pstSsa->sSysStatus | SYSTEM_RESTART;
  }

  sStatus = pstSsa->sSysStatus;

  switch(g_iTestMode) {
    case 0:
      pstSsa->cSysOperatingMode = '1';
      EmsShowData('0',"Production Mode\n");
      break;
    case 1:
      pstSsa->cSysOperatingMode = '2';
      EmsShowData('0',"Test Mode\n");
      break;
    case 9:
      pstSsa->cSysOperatingMode = 'D';
      EmsShowData('0',"Non-Daemon Mode\n");
      break;
    default:
      sprintf (g_caMsg, "<EMS> Illegal TEST_MODE value in config.dat! ");
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      EmsShowData ('0', g_caMsg);
  }

/* when Normal & Online status, Reload the BitTbl from the file bit.dat  */
  if ( !(sStatus & ONLINE_CLOSE) && !(sStatus & SYSTEM_RESTART) ) {   
    iBitLoadFlag = 1;
  }

  if (iBitLoadFlag == 1) {
    iRc = LoadBit(pstSsa,pcaBitTbl);
    if (iRc < 0) {
      sprintf(g_caMsg,"<EMS> Failure to load BIT! (iRc:%d)", iRc);
      DetErrRpt(LOAD_BIT_ERR,g_caMsg);
      UCP_TRACE_END(iRc);
    }
    pstSpa->cBrCodeLen = (char) g_iBrhNodeLen;
    pstSpa->cTmCodeLen = (char) g_iTermNodeLen;
    pstSpa->cTxnCodeLen = (char) g_iTxnCodeLen;
    pstSpa->cTellerCodeLen = (char) g_iTellerCodeLen;
  }
  else  {
    memcpy(&iBrhCnt,pcaBitTbl,4);  /* set the total branch node count  */
    memcpy(&stBrhArea,pcaBitTbl+8,sizeof(struct BrhArea)); 
    g_iTotTmNum = 0;

    for (i=0;i<iBrhCnt;i++)  {
      g_iTotTmNum += stBrhArea.iNoOfTerm ;
      iBrhOffset =  stBrhArea.iNxtBrhOffset;
      memcpy(&stBrhArea,pcaBitTbl+iBrhOffset,sizeof(struct BrhArea));
    }

    /* ### TCC */
    pcTermArea = pcaBitTbl + (8 + g_iBrhNodeNum*(sizeof(struct BrhArea)));
    for (i=0; i<g_iTotTmNum; i++) {
      memcpy (&stTermArea, pcTermArea, sizeof(struct TermArea));
      stTermArea.cTermStatus = 0x0;   
      memcpy (pcTermArea, &stTermArea, sizeof(struct TermArea));
      pcTermArea += sizeof(struct TermArea);
    }
  }   /* FOR if (iBitLoadFlag != 1) */

  if (g_iLoadCvtTbl == 1) { /* set 1 in config to present load cvt table */
    stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
    stCwaCtl.cSegCode = CWA_SEG_B2N;

    iRc = CwaLowCtlFac(&stCwaCtl,&pstCnvPtr);
    if (iRc != 0) {
      UCP_TRACE_END(GET_B2N_PTR_ERR);
    }

    EmsShowData('0',"Loading Chinese Convert Table....\n");

    if( CheckCvtTbl(pstCnvPtr) )
    {
      iRc = Init_Cvt_Table(pstCnvPtr);
      if (iRc != 0) {
        ErrLog(1000,"<EMS> Failure to Init_Cvt_Table!",RPT_TO_LOG,0,0);
        UCP_TRACE_END(INIT_CVT_TBL_ERR);
      }
    }
    /*
    sprintf (g_caMsg, "<EMS> dump CnvPtr & size of CVT TABLE = %d",
             sizeof(struct Big2Nhost)); 
    ErrLog(100,g_caMsg,RPT_TO_LOG,pstCnvPtr,4096);
    */
  }  /* FOR if (g_iLoadCvtTbl == 1) */

 
  /* added one line by pjw for tu970148  1999 6 8 */
  memset((char *)&stCwaCtl,0x00,sizeof(struct CwaCtl));

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SES;


  iRc = CwaLowCtlFac(&stCwaCtl,&pstaSess);
  if (iRc != 0) {
    UCP_TRACE_END(GET_SES_PTR_ERR);
  }

  memset(pstaSess,0x00,sizeof(struct SessTbl) * MAX_SESS_NO);

  /* attach MDA share memory */
  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_MDA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstMda);
  if (iRc != 0) {
    g_iMdaFlag = 0;
    UCP_TRACE_END(GET_MDA_PTR_ERR);
  }
  g_iMdaFlag = 1;

  close(iDump0Fd);
  close(iDump1Fd);

  UCP_TRACE_END(0);

} /* CwaLoad() */


/*
 *&N& ROUTINE NAME: InitCwa()
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&           
 *&R& RETURN VALUES:
 *&R&     0  :  ���`
 *&R&           
 *&R&           
 *&D& DESCRIPTION:           
 *&D&   ����Ƭ��N�t�Ϊ��A��(pstSsa),�t�ΰѼư�(pstSpa)��l��.
 *&D&           
 */

int
InitCwa(pcCwa)
char *pcCwa;
{
  int iRc;
  struct SSA *pstSsa;
  struct SPA *pstSpa;
  char   *GetSysDate();
  char   *GetNextDate();
  char   *pcaDate;
  char   *pcaNxtDate;
  char   caYy[5];
  char   caTmpDate[9];

  UCP_TRACE(P_InitCwa);

  pstSsa = (struct SSA *) pcCwa;
  pstSpa = (struct SPA *) (pcCwa + sizeof(struct SSA));

  memset(pstSsa,0x00,sizeof(struct SSA));
  pstSsa->iDumpSeqNo = 1;
  memcpy(pstSsa->caSysId , "TPE", 3);

  pcaDate = (char *) GetSysDate() ;
  if ( strlen(pcaDate) != 8 ) {
    memcpy(pcaDate,"19940824",8);
  }
  memcpy(caTmpDate,pcaDate,8);
  caTmpDate[8] = 0x0;               /* resolve the BASE_YEAR's question */
  memcpy(caYy,pcaDate,4);
  caYy[4] = 0x0;
  sprintf(caYy, "%.4d", atoi(caYy) - g_iBaseYear );
  memcpy(pcaDate,caYy,4);
  pcaDate[8] = '\0';
  memcpy(pstSsa->caTxnDate,pcaDate,8);

  pcaNxtDate = (char *) GetNextDate(caTmpDate) ;
  memcpy(caTmpDate,pcaNxtDate,8);
  caTmpDate[8] = 0x0;               /* resolve the BASE_YEAR's question */
  memcpy(caYy,pcaNxtDate,4);
  caYy[4] = 0x0;
  sprintf(caYy, "%.4d", atoi(caYy) - g_iBaseYear );
  memcpy(pcaNxtDate,caYy,4);
  pcaNxtDate[8] = '\0';
  memcpy(pstSsa->caNextDate,pcaNxtDate,8);

  pcaNxtDate = (char *) GetNextDate(caTmpDate) ;
  memcpy(caYy,pcaNxtDate,4);       /* resolve the BASE_YEAR's question */
  caYy[4] = 0x0;
  sprintf(caYy, "%.4d", atoi(caYy) - g_iBaseYear );
  memcpy(pcaNxtDate,caYy,4);
  pcaNxtDate[8] = '\0';
  memcpy(pstSsa->caNext2Date,pcaNxtDate,8);

  pstSsa->lTotalTxnCnt  = 0;
  pstSsa->lNextAvLogRrn = 1;
  pstSsa->sSysStatus    = 0x0000;
/*  mark by Jesswu 19950508 for set again in ending of the SysStart() 
  pstSsa->sSysStatus    = pstSsa->sSysStatus | SYSTEM_STARTED ;
*/
  pstSsa->cFrontLineStatus = '0';
  pstSsa->cSystemRole = (char) (g_iSystemRole + '0');
  /* pstSsa->cSysOperatingMode  set in other place  */

  memset(pstSpa,0x00,sizeof(struct SPA));
  pstSpa->cBrCodeLen = (char) g_iBrhNodeLen;
  pstSpa->cTmCodeLen = (char) g_iTermNodeLen;
  pstSpa->cTxnCodeLen = (char) g_iTxnCodeLen;
  /*
  sprintf(g_caMsg,"InitCwa:BrhCodeLen=%ld,TmCodeLen=%d,TxnCodeLen=%d",
          pstSpa->cBrCodeLen,pstSpa->cTmCodeLen,pstSpa->cTxnCodeLen);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
  */
  pstSpa->cTellerCodeLen = (char) g_iTellerCodeLen;

  UCP_TRACE_END(0);
}

/*
 *&N& ROUTINE NAME: InitBit()
 *&A& ARGUMENTS:
 *&A&   NAME         TYPE             DESCRIPTION
 *&A& ------------ -------------- --------------------
 *&A&  *pcaBitTbl     char        �ݥ��������_�l��}
 *&A&           
 *&A&           
 *&R& RETURN VALUES:
 *&R&     0  :  ���`
 *&R&           
 *&R&           
 *&D& DESCRIPTION:           
 *&D&   ����Ƭ��N�ݥ��������(pcaBitTbl)��l��,�I�s���J�ݥ��ɸ��.
 *&D&           
 */

int
InitBit(pcaBitTbl)
char   *pcaBitTbl;
{
  int iRc;

  UCP_TRACE(P_InitBit);
/* TCC
  memset(pcaBitTbl,'\0',MAX_BIT_SIZE);
*/
  memset(pcaBitTbl, 0, g_iBitSize);
  UCP_TRACE_END(0);
}  /* InitBit() */

/*
 *&N& ROUTINE NAME: LoadBit()
 *&A& ARGUMENTS:
 *&A&   NAME         TYPE             DESCRIPTION
 *&A& ------------ -------------- --------------------
 *&A& *pcaBitTbl      char         �ݥ��������_�l��}
 *&A&           
 *&A&           
 *&R& RETURN VALUES:
 *&R&     0  :  ���`
 *&R&           
 *&R&           
 *&D& DESCRIPTION:           
 *&D&   ����Ƭ��N�ݥ���(SBSBIT_F)��ƤJ�ݥ��������(pcaBitTbl):
 *&D&   1. �ˬd�ݥ��ɺݥ��W�٬O�_����(�I�sChkBitEntry()).
 *&D&   2. �C��Ū�J�@���ɮפ��e(�I�sReadLn()).
 *&D&   3. �ˬd�C�@�ݥ���ƬO�_�X�k(�I�sBitLeaglChk()).
 *&D&   4. �N�X�k�ݥ���Ƽg�J�ݥ����椤.
 *&D&           
 *&D&           
 */

int
LoadBit(pstSsa,pcaBitTbl)
struct SSA *pstSsa;
char  *pcaBitTbl;
{
  char caBuf[128], caTokenBuf[128], *pcaToken;
  int  iRc,i;
  FILE *zBitFp;
  char caBrhCode  [MAX_BRH_CODE_LEN+1];
  char caTermCode [MAX_TERM_CODE_LEN+1];
  char caTermName [MAX_TERM_NAME_LEN+1];
  char caFileName [FILE_NAME_LEN + 1];
  char cTermType;
  struct BrhArea   stBrhArea;
  struct TermArea  stTermArea;
  char *pcaBrhBgAddr;
  char *pcaTermBgAddr;
  int  iBrhCnt, iTermCnt, iTotTmCnt;
  int  iTmOffset;
  int  iFirstBrh=0;
  int  iNxtAvailAdd;
  
  UCP_TRACE(P_LoadBit);

  iRc = ChkBitEntry();
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }

  sprintf (caFileName, "%s/%s", (char *)getenv("III_DIR"), SBSBIT_F);
  zBitFp = fopen(caFileName,"r");
  if (zBitFp == NULL) {
    sprintf (g_caMsg,"<EMS> Unable to open [%s]! (errno:%d)",
             caFileName, errno);
    ErrLog(1000,g_caMsg,RPT_TO_TTY|RPT_TO_LOG,0,0);
    DetErrRpt(OPEN_BIT_ERR,g_caMsg);
    UCP_TRACE_END(OPEN_BIT_ERR);
  }
				/*  4 bytes reserved for Branch Total Cnt */ 
  pcaBrhBgAddr = pcaBitTbl + 8; /* 4 bytes reserved for next available addr */  
  pcaTermBgAddr = pcaBrhBgAddr + g_iBrhNodeNum * sizeof(struct BrhArea);  
  iTmOffset = g_iBrhNodeNum * sizeof(struct BrhArea);

  iBrhCnt = iTermCnt = iTotTmCnt = 0;

  memset (caBuf, 0, sizeof(caBuf));
  fgets (caBuf, sizeof(caBuf), zBitFp);
  
  do
  {
    for (i=0; i<sizeof(caBuf); i++)
      if (caBuf[i] == '\n')
      {
        caBuf[i] = 0;
        break;
      }

    strcpy (caTokenBuf, caBuf);

    pcaToken = (char *)strtok (caTokenBuf, DELIMITER);

    switch (pcaToken[0])
    {
      case '#':
                break;
      case 'b':
      case 'B':
/* ###
                if (iBrhCnt >= MAX_BR_NUM)
                {
                  sprintf (g_caMsg,
                  "<EMS> The total number of branch is over the limit [%d]",
                  MAX_BR_NUM);
                  ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
                  printf ("%s\n", g_caMsg);
                  UCP_TRACE_END (BRH_OVERFLOW_ERR);
                }
*/
                if (iFirstBrh == 1) {
                  stBrhArea.iNoOfTerm = iTermCnt;
                  memcpy (pcaBrhBgAddr, &stBrhArea, sizeof(struct BrhArea));
                  pcaBrhBgAddr += sizeof(struct BrhArea);
                  pcaTermBgAddr -= sizeof(struct TermArea);
                  memcpy (&stTermArea, pcaTermBgAddr, sizeof(struct TermArea));
                  stTermArea.iNxtTmOffset = -1; 
                  memcpy (pcaTermBgAddr, &stTermArea, sizeof(struct TermArea));
                  pcaTermBgAddr += sizeof(struct TermArea);
                }

                memset (&stBrhArea, 0, sizeof(struct BrhArea));
                
                pcaToken = (char *)strtok (NULL, DELIMITER);
                memcpy (caBrhCode, pcaToken, g_iBrhNodeLen);

                memcpy(stBrhArea.caBrhId, caBrhCode, g_iBrhNodeLen);
                stBrhArea.cBrhStatus = 0x90;
                memcpy(stBrhArea.caBrchClsTime, "240000",
                       sizeof(stBrhArea.caBrchClsTime));
                memcpy(stBrhArea.caTxnDate, pstSsa->caTxnDate,
                       sizeof(stBrhArea.caTxnDate));
                memcpy(stBrhArea.caNxtTxnDate, pstSsa->caNextDate,
                       sizeof(stBrhArea.caNxtTxnDate));
                memcpy(stBrhArea.caNNxtTxnDate, pstSsa->caNext2Date,
                       sizeof(stBrhArea.caNNxtTxnDate));
                stBrhArea.iTermOffset =  iTotTmCnt;

                iBrhCnt++;
                stBrhArea.iNxtBrhOffset = 8 + iBrhCnt*sizeof(struct BrhArea);
                iTermCnt = 0;               
                iFirstBrh = 1;

                break;
      case 't':
      case 'T':
                if (iTermCnt >= MAX_TERM_NUM)
                {
                  sprintf (g_caMsg,
"<EMS> The number of terminal for branch [%*s] is over the limit [%d]",
                  g_iBrhNodeLen, caBrhCode, MAX_TERM_NUM);
                  ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
                  printf ("%s\n", g_caMsg);
                  UCP_TRACE_END (TERM_OVERFLOW_ERR);
                }

                memset (&stTermArea, 0, sizeof(struct TermArea));
                 
                stTermArea.lLastOnlnRrn =  0;
                stTermArea.lLastBtchRrn =  0;
                stTermArea.lCurBtchErrRrn =  0;

                pcaToken = (char *)strtok (NULL, DELIMITER);
                memcpy (stTermArea.caTermId, pcaToken, g_iTermNodeLen);

                pcaToken = (char *)strtok (NULL, DELIMITER);
                memcpy (stTermArea.caLogicId, pcaToken, strlen(pcaToken));

                pcaToken = (char *)strtok (NULL, DELIMITER);
                stTermArea.cTermType = pcaToken[0];
/* ### TCC
                stTermArea.cTermStatus =  0x80;
*/
                stTermArea.cTermStatus =  0x0;
                stTermArea.cTermMode   =  0x0;
                memset (stTermArea.caBackBrhId, '\0', 
                        sizeof(stTermArea.caBackBrhId));
                memset (stTermArea.caBackTermId, '\0',
                        sizeof(stTermArea.caBackTermId));

                if ( g_iSystemRole == 0 ) {
                   stTermArea.lAccTxnNo      =  1;
                   stTermArea.lNonAccTxnNo   =  10001;
                }
                else {
                  stTermArea.lAccTxnNo      =  20001;
                  stTermArea.lNonAccTxnNo   =  30001;
                }

                if ( stTermArea.cTermType == REENTRY_TM ) {
                   if ( g_iSystemRole == 0 ) {
                      stTermArea.lBtchTxnNo     =  40001;
                   }
                   else {
                      stTermArea.lBtchTxnNo     =  40001;
                   }
                }
                else {
                   stTermArea.lBtchTxnNo     =  40001;
                }

                stTermArea.iNxtTmOffset = 
                  8+iTmOffset+(iTotTmCnt+1)*sizeof(struct TermArea);
                memcpy(pcaTermBgAddr,&stTermArea,sizeof(struct TermArea));
                pcaTermBgAddr += sizeof(struct TermArea);
                iTotTmCnt++;
                iTermCnt++;
                break;
       default:
                sprintf (g_caMsg,
                "<EMS> Illegal branch or terminal type: [%s]\n", pcaToken);
                ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
                fclose (zBitFp);
                UCP_TRACE_END(BIT_TYPE_ERR);
                break;
    }

    memset (caBuf, 0, sizeof(caBuf));
    fgets (caBuf, sizeof(caBuf), zBitFp);
  } while (!feof(zBitFp));

  fclose (zBitFp);

  stBrhArea.iNoOfTerm = iTermCnt;
  stBrhArea.iNxtBrhOffset = -1;  /* the last Brance node */
  memcpy (pcaBrhBgAddr, &stBrhArea, sizeof(struct BrhArea));
  pcaTermBgAddr -= sizeof(struct TermArea);
  memcpy (&stTermArea, pcaTermBgAddr, sizeof(struct TermArea));
  stTermArea.iNxtTmOffset = -1;  /* the last Terminal node */
  memcpy (pcaTermBgAddr, &stTermArea, sizeof(struct TermArea));
  pcaTermBgAddr += sizeof(struct TermArea);
  
  memcpy(pcaBitTbl,&iBrhCnt,4);  /* set the total branch node count  */
  iNxtAvailAdd = 8+iTmOffset+(g_iTotTmNum)*sizeof(struct TermArea);
  memcpy(pcaBitTbl+4,&iNxtAvailAdd,4);
/* TCC
  g_iBitSize = iNxtAvailAdd;
*/
  SetTermOffset(iBrhCnt,pcaBitTbl+8);
/* TCC
  sprintf (g_caMsg, "<EMS> Total Brh#:%d  Total Term#:%d  Total BIT Size:%d",
           g_iBrhNodeNum, g_iTotTmNum, g_iBitSize);
  ErrLog (10, g_caMsg, RPT_TO_LOG, 0, 0);
*/
  ErrLog (10, "<EMS> Load BIT from bit.dat", RPT_TO_LOG, 0, 0);
  
  UCP_TRACE_END(0);
}  /* LoadBit(pcaBitTbl) */

SetTermOffset(iBrhCnt,pcaBrhBgAddr)
int  iBrhCnt;
char *pcaBrhBgAddr;
{
   int iOffset;
   struct BrhArea *pstBrhArea;
   int i;

   for (i=0;i<iBrhCnt;i++) {
     pstBrhArea = (struct BrhArea *) (pcaBrhBgAddr + i*sizeof(struct BrhArea));
     iOffset = 8 + iBrhCnt*sizeof(struct BrhArea) + 
               ( pstBrhArea->iTermOffset * sizeof(struct TermArea));
   /* convert iTermOffset from the Term Index to real offset from the begin */  
   /* of the BitTbl(pcaBitTbl)                                              */
     pstBrhArea->iTermOffset = iOffset;
   } /* FOR for (i=0;i<iBrhCnt;i++) */
   return(0);
}


/*
 *&N& ROUTINE NAME: ChkBitEntry()
 *&A& ARGUMENTS:
 *&A&   NAME         TYPE             DESCRIPTION
 *&A& ------------ -------------- --------------------
 *&A&    �L
 *&A&           
 *&R& RETURN VALUES:
 *&R&     0  :  ���`
 *&R&           
 *&R&           
 *&D& DESCRIPTION:           
 *&D&   ����Ƭ��ˬd�ݥ�����ɤ��ݥ��W�٬O�_���� :
 *&D&   1. �I�s system() �H����N�X�β׺ݥN�X���Ƨ��_�ñN���и�ƨ��@.
 *&D&   2. �I�s system() �֭p�Ƨ��ɤκݥ��ɸ�Ʀ��.
 *&D&   3. �ˬd�֭p�Ƨ��ɻP�ݥ��ɸ�Ʀ�ƬO�_�ۦP,���P�������и��.
 *&D&   4. �N�֭p�Ƨ��ɸm�����ݥ���.
 *&D&           
 *&D&           
 */

struct BrhNode 
{
            char caBrhCode[MAX_BRH_CODE_LEN];
  struct BrhNode *next;
};

struct TermNode 
{
           char caTermCode[MAX_TERM_CODE_LEN+1];
           char caTermName[MAX_TERM_NAME_LEN+1];
  struct TmNode *next;
};

int
ChkBitEntry ()
{
  char caBuf[128], caTokenBuf[128], *pcaToken;
  int  iRc,i;
  FILE *zBitFp;
  /*
  char caBrhCode  [MAX_BR_NUM][MAX_BRH_CODE_LEN+1];
  */
  char caTermCode [MAX_TERM_NUM][MAX_TERM_CODE_LEN+1];
  char caTermName [MAX_TERM_NUM][MAX_TERM_NAME_LEN+1];
  char caFileName [FILE_NAME_LEN + 1];
  char cTermType;
  struct BrhArea   stBrhArea;
  struct TermArea  stTermArea;
  char *pcaBrhBgAddr;
  char *pcaTermBgAddr;
  int  iBrhCnt,iTermCnt;
  int  iTmOffset;
  int  iBrh_Flag;
  struct BrhNode  *pBrhList, *pBrhHeadList, *pTmp;
/* to clear garbage by wdm on 980406
  struct TermNode *pTermList, *pTermHeadList;   */

  UCP_TRACE(P_ChkBitEntry);

  sprintf (caFileName, "%s/%s", (char *)getenv("III_DIR"), SBSBIT_F);
  zBitFp = fopen(caFileName,"r");
  if (zBitFp == NULL) {
    ErrLog(1000,g_caMsg,RPT_TO_TTY|RPT_TO_LOG,0,0);
    sprintf (g_caMsg, "<EMS> Failure to open [%s]! (errno:%d=>%s)",
             caFileName, errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END(OPEN_BIT_ERR);
  }
  
  g_iBrhNodeNum = iBrhCnt = g_iTotTmNum = 0;
/* to fix PTM970145 on 980406  */
/*  pBrhHeadList = NULL;  */
  pBrhList = pBrhHeadList = pTmp = NULL;

  fgets (caBuf, sizeof(caBuf), zBitFp);

  do
  {
    for (i=0; i<sizeof(caBuf); i++)
      if (caBuf[i] == '\n')
      {
        caBuf[i] = 0;
        break;
      }

    pcaToken = (char *)strtok (caBuf, DELIMITER);

    switch (pcaToken[0])
    {
      case '#':
                break;
      case 'b':
      case 'B':
                iBrh_Flag = 0;
/* TCC
                if (iBrhCnt >= MAX_BR_NUM)
                {
                  sprintf (g_caMsg,
                  "<EMS> The total number of branch is over the limit [%d]",
                  MAX_BR_NUM);
                  ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
                  printf ("%s\n", g_caMsg);
                  UCP_TRACE_END (BRH_OVERFLOW_ERR);
                }
*/
                memset (&stBrhArea, 0, sizeof(struct BrhArea));

                pcaToken = (char *)strtok (NULL, DELIMITER);

                if (strlen(pcaToken) != g_iBrhNodeLen)
                {
                  sprintf(g_caMsg,
 "<EMS> The len(%d) of branch code(%s) is unequal to %d defined in config.dat",
                  strlen(pcaToken), pcaToken, g_iBrhNodeLen);
                  DetErrRpt(BR_LEN_ERR, g_caMsg);
                  UCP_TRACE_END(BR_LEN_ERR);
                }

                iRc = CmpBrhNode (pcaToken, pBrhHeadList);
                if (iRc < 0)
                {
                   sprintf(g_caMsg, 
                   "<EMS> Invalid duplicate branch code [%s] found in bit.dat",
                   pcaToken);
                   DetErrRpt(BIT_ENTRY_DUPL_ERR, g_caMsg);
                   UCP_TRACE_END(BIT_ENTRY_DUPL_ERR);
                }
                pBrhList = (struct BrhNode *) malloc (sizeof(struct BrhNode));
                memcpy (pBrhList->caBrhCode, pcaToken, g_iBrhNodeLen);
                pBrhList->next = pBrhHeadList;
                pBrhHeadList = pBrhList;

/* TCC
                memcpy (&caBrhCode[iBrhCnt], pcaToken, g_iBrhNodeLen);
                for (i=0;i<iBrhCnt;i++)
                {
                  if (strncmp(caBrhCode[i],caBrhCode[iBrhCnt], g_iBrhNodeLen)
                      == 0)
                  {
                    sprintf(g_caMsg, 
                    "<EMS> Invalid duplicate branch code [%s] found in bit.dat",
                    caBrhCode[iBrhCnt]);
                    DetErrRpt(BIT_ENTRY_DUPL_ERR, g_caMsg);
                    UCP_TRACE_END(BIT_ENTRY_DUPL_ERR);
                  }
                }
*/
                iBrhCnt++;
                iTermCnt = 0;
                iBrh_Flag = 1;
                break;
      case 't':
      case 'T':
                if (iBrh_Flag == 0)
                {
                  sprintf (g_caMsg, "<EMS> No branch declaration in bit.dat");
                  DetErrRpt (NO_BRH_ERR,g_caMsg);
                  ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
                  UCP_TRACE_END (NO_BRH_ERR);
                }

                memset (&stTermArea, 0, sizeof(struct TermArea));
/* TCC
                if (iTermCnt >= MAX_TERM_NUM)
                {
                  sprintf (g_caMsg,
"<EMS> The number of terminal for branch [%*s] is over the limit [%d]",
                  g_iBrhNodeLen, pBrhList->caBrhCode, MAX_TERM_NUM);
                  ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
                  printf ("%s\n", g_caMsg);
                  UCP_TRACE_END (TERM_OVERFLOW_ERR);
                }
*/
                pcaToken = (char *)strtok (NULL, DELIMITER);

                if (strlen(pcaToken) != g_iTermNodeLen)
                {
                  sprintf(g_caMsg,
"<EMS> The len(%d) of terminal code(%s) is unequal to %d defined in config.dat",
                  strlen(pcaToken), pcaToken[iTermCnt], g_iTermNodeLen);
                  DetErrRpt(TM_LEN_ERR,g_caMsg);
                  UCP_TRACE_END(TM_LEN_ERR);
                }
                memcpy (&caTermCode[iTermCnt], pcaToken, g_iTermNodeLen);

                pcaToken = (char *)strtok (NULL, DELIMITER);

                if (strlen(pcaToken) >= MAX_TERM_NAME_LEN)
                {
                  pcaToken[MAX_TERM_NAME_LEN] = 0;
                }
                memcpy (caTermName[iTermCnt], pcaToken, strlen(pcaToken));

                for (i=0; i<iTermCnt; i++)
                {
                  if (strncmp(caTermCode[i], caTermCode[iTermCnt],
                      g_iTermNodeLen) == 0 )
                  {
                    sprintf(g_caMsg,
                 "<EMS> Invalid duplicate terminal code [%.*s],brh_code=[%.*s]",
                      g_iTermNodeLen, caTermCode[iTermCnt],
                      g_iBrhNodeLen, pBrhList->caBrhCode);
                    DetErrRpt(BIT_ENTRY_DUPL_ERR,g_caMsg);
                    UCP_TRACE_END(BIT_ENTRY_DUPL_ERR);
                  }
                  if (strcmp(caTermName[i], caTermName[iTermCnt])
                      == 0 )
                  {
                    sprintf(g_caMsg,
                 "<EMS> Invalid duplicate terminal name [%s],brh_code=[%.*s]",
                    caTermName[iTermCnt],
                    g_iBrhNodeLen, pBrhList->caBrhCode);
                    DetErrRpt(BIT_ENTRY_DUPL_ERR,g_caMsg);
                    UCP_TRACE_END(BIT_ENTRY_DUPL_ERR);
                  }
                }

                pcaToken = (char *)strtok (NULL, DELIMITER);
                switch (pcaToken[0])
                {
                  case '1':
                  case '2':
                  case '3':
                  case '4':
                  case '9':
                            break;
                  default:
                    sprintf(g_caMsg,
                    "<EMS> Illegal terminal type %c in branch code %s",
                    cTermType,  pBrhList->caBrhCode);
                    DetErrRpt(TM_TYPE_ERR,g_caMsg);
                    UCP_TRACE_END(TM_TYPE_ERR);
                }

                iTermCnt++;
                g_iTotTmNum++;
                break;
       default:
                sprintf (g_caMsg, "<EMS> Illegal type: %s\n", pcaToken);
                ErrLog (10, g_caMsg, RPT_TO_LOG, 0, 0);
                fclose (zBitFp);
                UCP_TRACE_END(BIT_TYPE_ERR);
                break;
    }

    fgets (caBuf, sizeof(caBuf), zBitFp);
  } while (!feof(zBitFp));
  
  fclose (zBitFp);
  pTmp = pBrhHeadList;
  while (pTmp != NULL)
  {
    pBrhHeadList = pTmp->next;
    free (pTmp);
    pTmp = pBrhHeadList;
  }
  g_iBrhNodeNum = iBrhCnt;

  g_iBitSize = 8 + g_iBrhNodeNum * sizeof(struct BrhArea)
                 + g_iTotTmNum  * sizeof(struct TermArea);

  sprintf (g_caMsg, "<EMS> Total Brh#:%d  Total Term#:%d  Total BIT Size:%d",
           g_iBrhNodeNum, g_iTotTmNum, g_iBitSize);
  ErrLog (10, g_caMsg, RPT_TO_LOG, 0, 0);

  UCP_TRACE_END (0);
}


int  CheckCvtTbl(pstCnvPtr)
struct Big2Nhost *pstCnvPtr;
{
unsigned char caBigWord[8];
unsigned char caHstWord[8];
int      iRc, iLen;

  caBigWord[0] = 0xb1;
  caBigWord[1] = 0x69;
  caHstWord[0] = 0xb1;
  caHstWord[1] = 0x69;

  big5_host( caBigWord, caHstWord,2,pstCnvPtr);

  if( (unsigned char)caHstWord[1] == (unsigned char)0x57 &&
      (unsigned char)caHstWord[2] == (unsigned char)0x4f     )
    return(0);

  return( -1 );
}


/*
 *&N& ROUTINE NAME: CwaRemove()
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&           
 *&R& RETURN VALUES:
 *&R& 
 *&R&           
 *&R&           
 *&D& DESCRIPTION:           
 *&D&   ����Ƭ�CWA�����o,���e  �J.
 *&D&   1.�I�sCwaCtlFac()���o CWA.
 *&D&   2.�I�sCwaLoad() �J�t�ΰѼ�.
 *&D&   3.�I�sBitLoad() �J�׺ݾ��������.
 *&D&           
 *&D&           
 */

int
CwaRemove()
{
  int iRc;
  struct CwaCtl stCwaCtl;
  struct CwaCreatIobuf stCCBuf;

  UCP_TRACE(P_CwaRemove);

  g_iCwaKey = GetCnfValue( CWA_SHM_KEY );
  if (g_iCwaKey < 0){
    UCP_TRACE_END(-1); 
  }

  stCwaCtl.cFunCode = CWA_REMOVE;
  stCCBuf.iShmKey = g_iCwaKey;
  stCCBuf.iSemKey = g_iCwaKey;

  iRc = CwaCtlFac(&stCwaCtl,&stCCBuf);

  if (iRc != CWA_NORMAL) {
    sprintf (g_caMsg,
    "<EMS> Failure to remove CWA shared memory [key:%d] & semaphore [key:%d]",
    g_iCwaKey, g_iCwaKey);
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END(iRc); 
  }

  UCP_TRACE_END(0);

} /* CwaHdl() */

ShowVerRtn()
{
  /*
  EmsShowData('0',"Transactions Processing Environment (TPE) Version 1.1.3\n");
  */
  printf ("%s  %s\n", UtlProdName(), UtlProdVerId());
  EmsShowData('0',"Copyright 1994 Institute for Information Industry, Taiwan\n");
  EmsShowData('0',"All Rights Reserved\n");
}

char 
*GetSysDate()
{
  time_t     stCalTime;
  struct tm  *pstTm;
  static char   caLine[20];

  memset(caLine,'\0',20);

   if ( (stCalTime = time(NULL) ) == -1) {
     ErrLog(100,"<EMS> GetSysDate: call time() error!!!",RPT_TO_LOG,0,0);
   }

   if ( (pstTm = localtime(&stCalTime) ) == NULL) {
     ErrLog(100,"<EMS> GetSysDate: call localtime() error!!!",RPT_TO_LOG,0,0);
   }

   if (strftime(caLine,20,"%Y", pstTm) == 0) {
     ErrLog(100,"<EMS> GetSysDate: call strftime() error!!!",RPT_TO_LOG,0,0);
   }
   if (strftime(caLine+4,20,"%m%d", pstTm) == 0) {
     ErrLog(100,"<EMS> GetSysDate: call strftime() error!!!",RPT_TO_LOG,0,0);
   }

   return(caLine);
}

char 
*GetNextDate(pcaDate)
char  *pcaDate;
{
  time_t     stCalTime;
  struct tm  stTm;
  struct tm  *pstTm;
  static char   caLine[20];
  char   caYy[5];
  char   caMm[3];
  char   caDd[3];

  memset(caLine,'\0',20);

   memcpy(caYy,pcaDate,4);
   caYy[4] = 0x0;
   memcpy(caMm,pcaDate+4,2);
   caMm[2] = 0x0;
   memcpy(caDd,pcaDate+6,2);
   caDd[2] = 0x0;

   
   stTm.tm_year = atoi(caYy) - 1900 ;
   stTm.tm_mon  = atoi(caMm) - 1 ;
   stTm.tm_mday = atoi(caDd) ;
   stTm.tm_sec  = 1;
   stTm.tm_min  = 1; 
   stTm.tm_hour = 1;
   stTm.tm_wday = 0;
   stTm.tm_yday = 0; 
   stTm.tm_isdst = 0;

   if ( (stCalTime = mktime(&stTm) ) == -1) {
     ErrLog(100,"<EMS> GetNextDate: call mktime() error!!!",RPT_TO_LOG,0,0);
   }

     stCalTime = stCalTime + 86400;
   if ( (pstTm = localtime(&stCalTime) ) == NULL) {
     ErrLog(100,"<EMS> GetNextDate: call localtime() error!!!",RPT_TO_LOG,0,0);
   }

   if (strftime(caLine,20,"%Y", pstTm) == 0) {
     ErrLog(100,"<EMS> GetNextDate: call strftime() error!!!",RPT_TO_LOG,0,0);
   }
   if (strftime(caLine+4,20,"%m%d", pstTm) == 0) {
     ErrLog(100,"<EMS> GetNextDate: call strftime() error!!!",RPT_TO_LOG,0,0);
   }

   return(caLine);
}

CheckCwaFile (pcaFileName, iFd, iLoadSize)
char *pcaFileName;
int  *iFd;
int  *iLoadSize;
{
  int  iDumpSeqNo;
  int  iBitSizeOffset;
  int  iFileSize, iSize_SSA_SPA, iSize_BIT, iMaxCwaSize;
  int  iRc;
  struct SSA   *pstSsa;
  struct stat  stStatBuf;
 
  iSize_SSA_SPA = sizeof(struct SSA) + sizeof(struct SPA);
  iMaxCwaSize = iSize_SSA_SPA + MAX_BIT_SIZE;
  iBitSizeOffset = sizeof(struct SSA) + sizeof(struct SPA) + 4;

  *iFd = open(pcaFileName, O_RDONLY);
  if (*iFd != -1) {
    iRc = read (*iFd, &iDumpSeqNo, sizeof(pstSsa->iDumpSeqNo));
    if ((iRc != sizeof(pstSsa->iDumpSeqNo)) || 
        ((iDumpSeqNo != 0) && (iDumpSeqNo != 1) && 
         (iDumpSeqNo != 2) && (iDumpSeqNo != 3)))
    {
       sprintf (g_caMsg,
       "<EMS> Failure to read iDumpSeqNo [%d] from the file [%s]! (errno:%d)",
       iDumpSeqNo, pcaFileName, errno);
       ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
       iDumpSeqNo = -CWA_MODNO;
       return (iDumpSeqNo);
    }
    
    iRc = lseek (*iFd, iBitSizeOffset-sizeof(pstSsa->iDumpSeqNo), SEEK_CUR);
    /*
    iRc = lseek (*iFd, iBitSizeOffset-sizeof(pstSsa->iDumpSeqNo), SEEK_SET);
    */
    if (iRc == -1)
    {
       sprintf (g_caMsg,
         "<EMS> Failure to lseek the file [%s]! (errno:%d)",
         pcaFileName, errno);
       ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
       iDumpSeqNo = -CWA_MODNO;
       return (iDumpSeqNo);
    }
    iRc = read (*iFd, &g_iBitSize, 4);
    if (iRc == -1)
    {
       sprintf (g_caMsg,
         "<EMS> Failure to read the file [%s]! (errno:%d)",
         pcaFileName, errno);
       ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
       iDumpSeqNo = -CWA_MODNO;
       return (iDumpSeqNo);
    }

    *iLoadSize = iSize_SSA_SPA + g_iBitSize;

    iRc = stat (pcaFileName, &stStatBuf);
    iFileSize = stStatBuf.st_size;
    if (iRc != 0)
    {
       sprintf (g_caMsg,
         "<EMS> Failure to obtain the file size of [%s]! (errno:%d)",
         pcaFileName, errno);
       ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
       iDumpSeqNo = -CWA_MODNO;
       return (iDumpSeqNo);
    }

    if ((*iLoadSize != iFileSize) && (iFileSize != iMaxCwaSize))
    {
       sprintf (g_caMsg,
         "<EMS> The content of file [%s] is corrupted! (errno:%d)",
         pcaFileName, errno);
       ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
       iDumpSeqNo = -CWA_MODNO;
       return (iDumpSeqNo);
    }
  }
  else {
    iDumpSeqNo = -CWA_MODNO;
  }

  return (iDumpSeqNo);
}


CmpBrhNode (char *pcaBrhCode, struct BrhNode  *pBrhList)
{
  struct BrhNode *pTmp;

  pTmp = pBrhList;
  while (pTmp != NULL)
  {
     if (strncmp (pcaBrhCode, pTmp->caBrhCode, g_iBrhNodeLen) == 0)
        return (-1);
     pTmp = pTmp->next; 
  }

  return (0);
}

int
GetBitSize ()
{
  FILE *zBitFp;
  int  iRc, i;
  int  iBrhCnt, iTermCnt;
  char caBuf[128], *pcaToken;
  char caFileName [FILE_NAME_LEN + 1];
  struct BrhArea   stBrhArea;
  struct TermArea  stTermArea;

  sprintf (caFileName, "%s/%s", (char *)getenv("III_DIR"), SBSBIT_F);
  zBitFp = fopen(caFileName,"r");
  if (zBitFp == NULL) {
    ErrLog(1000,g_caMsg,RPT_TO_TTY|RPT_TO_LOG,0,0);
    sprintf (g_caMsg, "<EMS> Failure to open [%s]! (errno:%d=>%s)",
             caFileName, errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    return (OPEN_BIT_ERR);
  }
  
  iBrhCnt = iTermCnt = 0;

  fgets (caBuf, sizeof(caBuf), zBitFp);

  do
  {
    for (i=0; i<sizeof(caBuf); i++)
      if (caBuf[i] == '\n')
      {
        caBuf[i] = 0;
        break;
      }

    pcaToken = (char *)strtok (caBuf, DELIMITER);

    switch (pcaToken[0])
    {
      case '#':
                break;
      case 'b':
      case 'B':
                iBrhCnt++;
                break;
      case 't':
      case 'T':
                iTermCnt++;
                break;
       default:
                sprintf (g_caMsg, "<EMS> Illegal type: %s\n", pcaToken);
                ErrLog (10, g_caMsg, RPT_TO_LOG, 0, 0);
                fclose (zBitFp);
                return (BIT_TYPE_ERR);
                break;
    }

    fgets (caBuf, sizeof(caBuf), zBitFp);
  } while (!feof(zBitFp));
  
  fclose (zBitFp);

  g_iBitSize = 8 + iBrhCnt * sizeof(struct BrhArea)
                 + iTermCnt  * sizeof(struct TermArea);
  g_iBrhNodeNum = iBrhCnt;
  g_iTotTmNum = iTermCnt;
/* ### TCC
  sprintf (g_caMsg, "<EMS> Total Brh#:%d  Total Term#:%d  Total BIT Size:%d",
           iBrhCnt, iTermCnt, g_iBitSize);
  ErrLog (10, g_caMsg, RPT_TO_LOG, 0, 0);

  return(0);
*/
  return(0);
}

