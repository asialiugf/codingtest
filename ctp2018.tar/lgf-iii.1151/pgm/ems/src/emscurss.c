
/*
 *&N& ROUTINE NAME: main  
 *&A& ARGUMENTS:
 *&A&   �L
 *&A&           
 *&R& RETURN VALUES:
 *&R&           
 *&R&           
 *&D& DESCRIPTION:           
 *&D&     ���{�������Һ޲z�l�t�δ��Ѥ@�� Curses ���ɭ�,�{�����i²��s��	
 *&D&     �Ӥ����h�F�� Curses ���Ӹ`
 *&D& ( This program is Curses mode, i.e. using CURSES as the output)        
 */

#include <curses.h>
#include <signal.h>
#include "emctcwa.h"

/* the number of records shown at the same time */
#define NO_RECORD	1
/* the number of fields in CWA-SSA data structure */
#define NO_ITEM		3
#define MAX_DATA_LEN	20

struct stItem {
	int iPage;
	int iRow;
	int iCol;
	int (*Routine1)();
	int (*Routine2)();
	char caData[ MAX_DATA_LEN ];
	char cType;
	int iLength;
	char cAttribute;
	} stRecord1[ NO_ITEM * NO_RECORD ] = {
            {1, 1, 60, NULL, NULL, "", 'c',10, 'd'},
            {1, 2, 60, NULL, NULL, "", 'c', 8, 'd'},
            {1,18, 38, NULL, NULL, "", 'c', 1, 'e'},
        };

struct stItem stRecord2[ NO_ITEM * NO_RECORD ] = {
            {1, 1, 60, NULL, NULL, "", 'c',10, 'd'},
            {1, 2, 60, NULL, NULL, "", 'c', 8, 'd'},
            {1,16, 38, NULL, NULL, "", 'c', 1, 'e'},
        };

struct stItem stRecord3[ NO_ITEM * NO_RECORD ] = {
            {1, 1, 60, NULL, NULL, "", 'c',10, 'd'},
            {1, 2, 60, NULL, NULL, "", 'c', 8, 'd'},
            {1,12, 38, NULL, NULL, "", 'c', 1, 'e'},
        };

struct stItem stRecord4[ NO_ITEM * NO_RECORD ] = {
            {1, 1, 60, NULL, NULL, "", 'c',10, 'd'},
            {1, 2, 60, NULL, NULL, "", 'c', 8, 'd'},
            {1,12, 38, NULL, NULL, "", 'c', 1, 'e'},
        };

struct stEditItem {
	int iRowCol;  /* iRow * 100 + iCol */
	int iIndex;
	};

/*      Used when U want to test this program independently   
main()
{
  struct stMenu *pstMenu;
  struct stMenu *InitTool();
  int    iRc;

  pstMenu = (struct stMenu *) InitTool("emdcntl.scr");
  RetrieveData( pstMenu );
  DisplayData( pstMenu );
  while (iRc != 54) {
  iRc = Process( pstMenu );
    if ( (iRc > 54) || (iRc < 49) ) {
      wattron(pstMenu->pwWin,A_BLINK|A_REVERSE);
      mvwaddstr(pstMenu->pwWin, 23, 25, "Choice Error!!");
      wattroff(pstMenu->pwWin,A_BLINK|A_REVERSE);
    }
  }
  EndTool(pstMenu);

}
*/

struct stMenu *InitTool(pcaFileName,iIdx)
char  *pcaFileName;
int   iIdx;
{
  struct stMenu *pstMenu;
  struct stMenu *InitMenu();
  int Interrupt();

  /* call Interrupt() if user hits BREAK or DELETE */
  signal( SIGINT, Interrupt );

  /* initially setup of curses */
  if (iIdx == 1) {
    initscr();
    cbreak();
    noecho();
    nonl();
  }
/*  keypad( stdscr, TRUE );    /X to get arrow keys */

  /* to display menu and initialize menu data structure */
  pstMenu = (struct stMenu *) InitMenu(pcaFileName,iIdx);

  return( pstMenu );
}

/* this routine should be modified for each tool */
struct stMenu *InitMenu(pcaFileName,iIdx)
char  *pcaFileName;
int   iIdx;
{
  FILE *pfMenuFile;
  char caBuff[ 80 ];
  char caFlName[80];
  struct stMenu *pstMenu;
  struct stItem *pstItem;
  int iCurRow;

  memset(caFlName,'\0',sizeof(caFlName));
  sprintf (caFlName, "%s/%s",
           (char *) getenv("III_DIR"), pcaFileName);

  if (( pfMenuFile = fopen(caFlName, "r" )) == NULL) {
    fprintf( stderr, "cannot open file: %s\n", pcaFileName );
    EndTool();
  }

  /* to allocate the menu data structure */
  pstMenu = (struct stMenu *) calloc( sizeof( struct stMenu ), 1 );
  pstMenu->pwWin = (WINDOW *) newwin( LINES, COLS, 0, 0 );
  pstMenu->iNoRecord = NO_RECORD;
  pstMenu->pstNextMenu = NULL;
  switch(iIdx) {
  case 1:
    pstMenu->pstItem = (struct stItem *) &stRecord1;
    break;
  case 2:
    pstMenu->pstItem = (struct stItem *) &stRecord2;
    break;
  case 3:
    pstMenu->pstItem = (struct stItem *) &stRecord3;
    break;
  case 4:
    pstMenu->pstItem = (struct stItem *) &stRecord4;
    break;
  }

  /* to get menu from the menu file */
  iCurRow = 0;
  while ((fgets( caBuff, COLS, pfMenuFile )) != NULL) {
    if (strlen( caBuff ) != 0) {
      mvwaddstr( pstMenu->pwWin, iCurRow, 0, caBuff );
    }
    iCurRow = iCurRow + 1;
  }

  wrefresh( pstMenu->pwWin );      /* to show menu onto the screen */
  fclose( pfMenuFile );

  /* to initialize menu data structure */
  pstItem = pstMenu->pstItem;

  return( pstMenu );
}

struct stMenu *InitNullMenu()
{
  struct stMenu *pstMenu;
  struct stMenu *InitMenu();
  int Interrupt();

  /* call Interrupt() if user hits BREAK or DELETE */
  signal( SIGINT, Interrupt );

  /* initially setup of curses */
/*
  initscr();
  cbreak();
  noecho();
  nonl();
*/
/*  keypad( stdscr, TRUE );    /x to get arrow keys */

  pstMenu = (struct stMenu *) calloc( sizeof( struct stMenu ), 1 );
  pstMenu->pwWin = (WINDOW *) newwin( LINES, COLS, 0, 0 );
  pstMenu->iNoRecord = NO_RECORD;
  pstMenu->pstNextMenu = NULL;
  pstMenu->pstItem = NULL;

  return( pstMenu );
}

struct stMenu *InitNullMenu1()
{
  struct stMenu *pstMenu;
  struct stMenu *InitMenu();
  int Interrupt();

  /* call Interrupt() if user hits BREAK or DELETE */
  signal( SIGINT, Interrupt );

  /* initially setup of curses */
  initscr();
  cbreak();
  noecho();
  nonl();
/*  keypad( stdscr, TRUE );    /x to get arrow keys */

  pstMenu = (struct stMenu *) calloc( sizeof( struct stMenu ), 1 );
  pstMenu->pwWin = (WINDOW *) newwin( LINES, COLS, 0, 0 );
  pstMenu->iNoRecord = NO_RECORD;
  pstMenu->pstNextMenu = NULL;
  pstMenu->pstItem = NULL;

  return( pstMenu );
}

DisplayMenu(pstMenu)
struct stMenu *pstMenu;
{
  wrefresh( pstMenu->pwWin );      /* to show menu onto the screen */
}

int RetrieveData( pstMenu,iIdx,pcaData )
struct stMenu *pstMenu;
int    iIdx;
char   *pcaData;
{
  struct stItem *pstItem;

  pstItem = pstMenu->pstItem;
  strcpy( pstItem[ iIdx ].caData,pcaData );
}

int DisplayData( pstMenu )
struct stMenu *pstMenu;
{
  int i;
  char cAttr;

  for (i = 0; i < NO_ITEM; i ++) {
    cAttr = pstMenu->pstItem[ i ].cAttribute;
    if ( cAttr == 'd' ) {
      wattron( pstMenu->pwWin, A_REVERSE );
      mvwaddstr( pstMenu->pwWin,
                 pstMenu->pstItem[ i ].iRow,
                 pstMenu->pstItem[ i ].iCol, 
                 pstMenu->pstItem[ i ].caData );
      wattroff( pstMenu->pwWin, A_REVERSE );
    }
    else if ( cAttr == 'e' ) {
      wattron( pstMenu->pwWin, A_UNDERLINE );
      mvwaddstr( pstMenu->pwWin,
                 pstMenu->pstItem[ i ].iRow,
                 pstMenu->pstItem[ i ].iCol, 
                 pstMenu->pstItem[ i ].caData );
      wattroff( pstMenu->pwWin, A_UNDERLINE );
    }
  }

  wrefresh( pstMenu->pwWin );
}

int EndTool( pstMenu )
struct stMenu *pstMenu;
{
  struct stMenu *ptr1, *ptr2;

  /* to release menu structure allocated */
  ptr1 = pstMenu;
  while (ptr1 != NULL) {
    ptr2 = ptr1->pstNextMenu;
    free( ptr1 );
    ptr1 = ptr2;
  }

  endwin();
  return(0);
}


int Interrupt()
{
  endwin();
  exit( 1 );
}

int Process( pstMenu )
struct stMenu *pstMenu;
{
  int iKeyIn;
  int iLastKeyIn;
  int iCurRow, iCurCol, iMaxCol;
  int iInsert; /* insert / replace flag */
  int iIndex;  /* current editable item's index for stRecord */
  int iNoEditItem;
  struct stEditItem stEditList[ NO_ITEM ];
  int    iIdx=0;            /* current editable item's index for stEditList */

  iInsert = 0;
  BuildEdtList( pstMenu, stEditList, &iNoEditItem );
  iIndex = stEditList[ iIdx ].iIndex;
  MvEdtItem( pstMenu, iIndex, A_UNDERLINE );

  keypad(pstMenu->pwWin,TRUE);
  while (1) {
    /* to refresh screen */
    wrefresh( pstMenu->pwWin );

    /* get key and process */
    iKeyIn = wgetch(pstMenu->pwWin);
    switch( iKeyIn ) {
      case KEY_UP :
        iIdx = (iIdx + iNoEditItem - 1) % iNoEditItem;
        iIndex = stEditList[ iIdx ].iIndex;
        MvEdtItem( pstMenu, iIndex, A_UNDERLINE );
        break;
      case KEY_DOWN :
      case 0x0797 :   /* ENTER */
      case 13 :   
        iIdx = (iIdx + 1) % iNoEditItem;
        iIndex = stEditList[ iIdx ].iIndex;
        MvEdtItem( pstMenu, iIndex, A_UNDERLINE );
        return(iLastKeyIn);
      case KEY_LEFT :
        getyx( pstMenu->pwWin, iCurRow, iCurCol );
        if ( iCurCol > pstMenu->pstItem[ iIndex ].iCol ) {
          wmove( pstMenu->pwWin, iCurRow, iCurCol - 1 );
        }
        else {
          beep();
        }
        break;
      case KEY_RIGHT :
        getyx( pstMenu->pwWin, iCurRow, iCurCol );
        if ( iCurCol < pstMenu->pstItem[ iIndex ].iCol +
                       pstMenu->pstItem[ iIndex ].iLength - 1 ) {
          wmove( pstMenu->pwWin, iCurRow, iCurCol + 1 );
        }
        else {
          beep();
        }
        break;
      case KEY_HOME :
        break;
      case 0x09 :    /* Ctrl + i */
        iInsert = 1 - iInsert;
        getyx( pstMenu->pwWin, iCurRow, iCurCol );
        wmove( pstMenu->pwWin, iCurRow, iCurCol );
        break;
      case 0x04 :    /* Ctrl + d */
        DeleteCh( pstMenu, iIndex );
        break;
      case 0x15 :    /* Ctrl + u */
        Undo( pstMenu, iIndex );
        break;
/*
      case 0x0747 :  /x Ctrl + h x/
        Backspace( pstMenu, iIndex );
        break;
      case 0x05 :    /x Ctrl + e x/
        break;
      case KEY_F(1) :
        CallHelp();
        break;
      case KEY_F(2) :
        UpdateData( pstMenu );
        break;
*/
      case '\x1b' :  /* ESC */
        ProcessEscCmd( pstMenu );
        break;
      default :
        AddCh( pstMenu, iIndex, iKeyIn, iInsert );
        iLastKeyIn = iKeyIn;
        break;
    }
  }
}
 
int AddCh( pstMenu, iIndex, iKeyIn, iInsert )
struct stMenu *pstMenu;
int iIndex;
int iKeyIn;
int iInsert;
{
  int i;
  int iMaxCol, iCurRow, iCurCol;
  char cCh;
  WINDOW *pwWin;

  pwWin = pstMenu->pwWin;
  iMaxCol = pstMenu->pstItem[ iIndex ].iCol +
            pstMenu->pstItem[ iIndex ].iLength;
  getyx( pwWin, iCurRow, iCurCol );
  if ( iCurCol < iMaxCol ) {
    wattron( pwWin, A_UNDERLINE );
    if (iInsert) {
      for (i = iMaxCol - 2; i >= iCurCol; i --) {
        cCh = mvwinch( pwWin, iCurRow, i );
        mvwaddch( pwWin, iCurRow, i + 1, cCh );
      }
      mvwaddch( pwWin, iCurRow, iCurCol, iKeyIn );
      wmove( pwWin, iCurRow, iCurCol );
    }
    else {
      waddch( pwWin, iKeyIn );
    }

    if ( iCurCol == iMaxCol - 1 ) {
      wmove( pwWin, iCurRow, iCurCol );
      beep();
    }
    wattroff( pstMenu->pwWin, A_UNDERLINE );
  }
}

int Undo( pstMenu, iIndex )
struct stMenu *pstMenu;
int iIndex;
{
  int i;
  int iCurRow, iCurCol, iMaxCol;
  char caData[ MAX_DATA_LEN ];
  struct stItem *pstItem;
  WINDOW *pwWin;

  pwWin = pstMenu->pwWin;
  pstItem = (struct stItem *)&(pstMenu->pstItem[ iIndex ]);
  iCurRow = pstItem->iRow;
  iCurCol = pstItem->iCol;
  iMaxCol = iCurCol + pstItem->iLength - 1;
  strncpy( caData, pstItem->caData, pstItem->iLength );
  caData[ pstItem->iLength ] = '\0';
  wattron( pwWin, A_UNDERLINE );
  mvwaddstr( pwWin, iCurRow, iCurCol, caData );
  getyx( pwWin, iCurRow, iCurCol );
  if (iCurCol < iMaxCol) {
    for (i = iCurCol; i <= iMaxCol; i ++) {
      mvwaddch( pwWin, iCurRow, i, ' ' );
    }
  }
  wmove( pwWin, iCurRow, pstItem->iCol );
  wattroff( pwWin, A_UNDERLINE );
}

int ProcessEscCmd( pstMenu )
struct stMenu *pstMenu;
{
  int iKeyIn;

  /* get key and process */
  iKeyIn = wgetch(pstMenu->pwWin);
  switch( iKeyIn ) {
    case '\x1b' :
      EndTool( pstMenu );
      break;
/*
    case '1' :     /x has the same function as F1 key if F1 key is disable x/
      CallHelp();
      break;
    case '2' :     /x has the same function as F2 key if F2 key is disable x/
      UpdateData( pstMenu );
      break;
*/
  }
}

int DeleteCh( pstMenu, iIndex )
struct stMenu *pstMenu;
int iIndex;
{
  int i;
  int iMaxCol, iCurRow, iCurCol;
  char cCh;

  iMaxCol = pstMenu->pstItem[ iIndex ].iCol +
            pstMenu->pstItem[ iIndex ].iLength;
  getyx( pstMenu->pwWin, iCurRow, iCurCol );
  wattron( pstMenu->pwWin, A_UNDERLINE );
  for (i = iCurCol + 1; i <= iMaxCol; i ++) {
    cCh = mvwinch( pstMenu->pwWin, iCurRow, i );
    mvwaddch( pstMenu->pwWin, iCurRow, i - 1, cCh );
  }
  wattroff( pstMenu->pwWin, A_UNDERLINE );
  wmove( pstMenu->pwWin, iCurRow, iCurCol );
}

int Backspace( pstMenu, iIndex )
struct stMenu *pstMenu;
int iIndex;
{
  int i;
  int iMaxCol, iCurRow, iCurCol;
  char cCh;

  iMaxCol = pstMenu->pstItem[ iIndex ].iCol +
            pstMenu->pstItem[ iIndex ].iLength;
  getyx( pstMenu->pwWin, iCurRow, iCurCol );
  if ( iCurCol == pstMenu->pstItem[ iIndex ].iCol ) {
    beep();
  }
  else {
    wattron( pstMenu->pwWin, A_UNDERLINE );
    for (i = iCurCol; i <= iMaxCol; i ++) {
      cCh = mvwinch( pstMenu->pwWin, iCurRow, i );
      mvwaddch( pstMenu->pwWin, iCurRow, i - 1, cCh );
    }
    wattroff( pstMenu->pwWin, A_UNDERLINE );
    wmove( pstMenu->pwWin, iCurRow, iCurCol - 1 );
  }
}

int MvEdtItem( pstMenu, iIndex, iAttr )
struct stMenu *pstMenu;
int iIndex;
int iAttr;  /* terminal attribute */
{
  int i;
  int iCurRow, iCurCol;
  int iLength;
  char cCh;
  WINDOW *pwWin;
  struct stItem *pstItem;

  pstItem = (struct stItem *)&(pstMenu->pstItem[ iIndex ]);
  iCurRow = pstItem->iRow;
  iCurCol = pstItem->iCol;
  iLength = pstItem->iLength;
  pwWin = pstMenu->pwWin;

  wattron( pwWin, iAttr );

  for (i = 0; i < iLength; i ++) { 
    cCh = mvwinch( pwWin, iCurRow, iCurCol + i );
    mvwaddch( pwWin, iCurRow, iCurCol + i, cCh );
  }
  wmove( pwWin, iCurRow, iCurCol );

  wattroff( pwWin, iAttr );
}

int BuildEdtList( pstMenu, pstEditList, piNoEditItem )
struct stMenu *pstMenu;
struct stEditItem *pstEditList;
int *piNoEditItem;
{
  int Compare();
  int i, j;

  for (i = 0, j = 0; i < NO_ITEM; i ++) {
    if (pstMenu->pstItem[ i ].cAttribute == 'e') {
      pstEditList[ j ].iIndex = i;
      pstEditList[ j ].iRowCol = pstMenu->pstItem[ i ].iRow * 100 +
                                 pstMenu->pstItem[ i ].iCol; 
      j ++;
    }
  }

  *piNoEditItem = j;

  qsort( (char *) pstEditList, *piNoEditItem, 
         sizeof( struct stEditItem ), Compare );
}

int Compare( pstEditItem1, pstEditItem2 )
struct stEditItem *pstEditItem1;
struct stEditItem *pstEditItem2;
{
  if ( pstEditItem1->iRowCol < pstEditItem2->iRowCol ) {
    return( -1 );
  }
  else if ( pstEditItem1->iRowCol == pstEditItem2->iRowCol ) {
    return( 0 );
  }
  else
    return( 1 );
}
 
ShowMsg(pstMenu,iY,iX,pcaShowStr)
struct stMenu *pstMenu;
int    iY;
int    iX;
char   *pcaShowStr;
{
   char caFiller[60];

   memset(caFiller,' ',60);
   caFiller[59] = '\0';
   mvwaddstr(pstMenu->pwWin, iY, iX, caFiller);
   wattron(pstMenu->pwWin,A_BLINK|A_REVERSE);
   mvwaddstr(pstMenu->pwWin, iY, iX, pcaShowStr);
   wattroff(pstMenu->pwWin,A_BLINK|A_REVERSE);
   wattron(pstMenu->pwWin,A_NORMAL);
}

ShowStr(pstMenu,iY,iX,pcaShowStr,cType)
struct stMenu *pstMenu;
int    iY;
int    iX;
char   *pcaShowStr;
char   cType;
{
   switch(cType)  {
     case 'e':
       wattron( pstMenu->pwWin, A_UNDERLINE );
       break;
     case 'r':
       wattron( pstMenu->pwWin, A_REVERSE );
       break;
     case 'n':
       wattron( pstMenu->pwWin, A_NORMAL );
       break;
     default:
       break;
   }
   mvwaddstr(pstMenu->pwWin, iY, iX, pcaShowStr);

   switch(cType)  {
     case 'e':
       wattroff( pstMenu->pwWin, A_UNDERLINE );
       break;
     case 'r':
       wattroff( pstMenu->pwWin, A_REVERSE );
       break;
     case 'n':
       wattroff( pstMenu->pwWin, A_NORMAL );
       break;
     default:
       break;
   }
}

GetInChar(pstMenu,iY,iX,pcIn)
struct stMenu *pstMenu;
int    iY;
int    iX;
char   *pcIn;
{
  int  iKeyIn;
  char cCh;

    wrefresh( pstMenu->pwWin );
    /* get key and process */
    iKeyIn = wgetch(pstMenu->pwWin);
    cCh    = (char) iKeyIn;

   mvwaddch( pstMenu->pwWin, iY, iX, cCh );
   *pcIn = mvwinch( pstMenu->pwWin, iY, iX );
}
