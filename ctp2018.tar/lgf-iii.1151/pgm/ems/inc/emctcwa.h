/*      Constants for CWA-SSA        */

#define		DUMP_SEQ_NO		0
#define 	SYS_ID			1
#define		TXN_DATE		2
#define		NEXT_DATE		3
#define		NEXT_2_DATE		4
#define		NEXT_DAY_CNT		5
#define		SYS_STATUS		6
#define		OP_STATUS		7
#define		OVER_TIME		8
#define		FRONT_LINE_STATUS	9
#define		PREV_TXN_LOG_RRN	10
#define		PREV_BTEF_RRN		11
#define		LAST_RRN_IN_BTEF	12
#define		TOTAL_TXN_CNT		13
#define		NEXT_AV_LOG_RRN		14
#define		SYS_OPERATING_MODE	15
#define		SYSTEM_ROLE		16

/*      Data structure for CWA-SSA      */

struct stCWA_SSA {
	int iDumpSeqNo;
	char caSysId[ 10 ];
	char caTxnDate[ 10 ];
	char caNextDate[ 10 ];
	char caNext2Date[ 10 ];
	short sNextDayCnt;
	char caSysStatus[ 2 ];
	char cFrontLineStatus;
	char caPrevTxnLogRrn[ 5 ];
	char caPrevBtefRrn[ 5 ];
	char caLastRrnInBtef[ 5 ];
	long lTotalTxnCnt;
	long lNextAvLogRrn;
	char cSysOperatingMode;
	char cSystemRole;
	};

struct stMenu {
	WINDOW *pwWin;
	int iNoRecord; /* the number of records shown at the same time */
	struct stMenu *pstNextMenu;
	struct stItem *pstItem;
	};
