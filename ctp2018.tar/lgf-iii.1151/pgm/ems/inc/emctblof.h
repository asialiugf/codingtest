/*--------------------  emctblof.h ----------------------------*/
/* For compatiable itctblof.str                                */
/*-------------------------------------------------------------*/
/* .............. format of item table entry begins here ............... */
/* every length constant definition are all defined in itctxnld.def      */

/*  CFT entry data structure     */
struct  ctf_item_def {          /* ctf file data item format defined     */
   char caCtfName[CTF_NAME_LEN+1]; /* ctf item name                         */
   char cDatType;               /* type of data item                     */
   int  iDatLen;                /* input item length                     */
   int  iCtfLen;                /* data length in ctf                    */
   int  iCtfOffs;               /* offset relate to ctf                  */
   int  iCtfRelat;              /* relative number to ctf table          */
   int  iDotPos;                /* floating point position from right    */
   char cIniValue;              /* initial value for item ( 0 or blank ) */
};

typedef struct ctf_item_def ctf_item;
                                /* type def of ctf item rec of ctf file  */

/* ............ ctf file rec. format description begins here  .......... */
/* #include "./itctxnld.def" */
struct  ctf_head_def {          /* ctf file head rec. format defined     */
   char cRecHead;               /* rec. id(*: ctf_head; other: ctf_item) */
   char cBusiType;              /* business type                         */
   int  iCtfSize;               /* length of the ctf                     */
   int  iTotItem;               /* total number of items of the business */
   char caFiller[43];             /* space                                 */
};

typedef struct ctf_head_def ctf_head;
                                /* type def of ctf head rec of ctf file  */


/* ------- head defined for Input module Common used Table (ICT) ------- */
struct  ict_head_def {
  int  iCitOffs;              /* offset of CIT in ICT                  */
  int  iGdtOffs;              /* offset of GDT in ICT                  */
  int  iMdtOffs;              /* offset of MDT in ICT                  */
  int  iHlpOffs;              /* offset of HLP in ICT                  */
  int  iMstOffs;              /* offset of MDT in ICT                  */
  int  iHlpIdxOffs;          /* offset of HLP INDEX in ICT            */
  int  iMstIdxOffs;          /* offset of MDT INDEX in ICT            */
  int  iReserve2;              /* reserved for future used              */
  int  iReserve3;              /* reserved for future used              */
};
typedef struct ict_head_def ict_head;

struct hlp_idx {
  char caKey[GUD_NO_LEN + 1];
  long lRecNo;
};
typedef struct hlp_idx hlp_head;
/* ------------------ END OF INCLUDE FILE emctblof.str -------------------- */
