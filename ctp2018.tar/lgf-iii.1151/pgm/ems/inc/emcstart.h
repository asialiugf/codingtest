#define SYSTEM_ERR               -99
/* <emsstart.c> error message code */
#define GET_SSA_PTR_ERR          -1
#define GET_SYSTEMROLE_ERR       -2
#define NOSUCH_BRHID_ERR         -3
#define ILL_STARTDATE_ERR        -4
#define TXNDATE_OVERFLOW_ERR     -5
#define CALFILE_NOEXIST_ERR      -6
#define READ_CALFILE_ERR         -7
#define UNKNOWN_CAL_ERR          -8
#define UNKNOWN_RTNCODE_ERR      -9
#define UPT_TXNDATE_FMLOCAL_ERR  -10
#define CENTER_NOTOPEN_ERR       -11
#define TTY_NOTDEFINED_ERR       -12
#define GET_NOSIGNON_ERR         -13
#define FORWARD_RV_CWA_ERR       -14

/* TCC 1995/11/23 Begin */
#define F701_ERR -51
#define F702_ERR -52
#define F703_ERR -53
#define F704_ERR -54
#define F705_ERR -55
#define F706_ERR -56
#define F707_ERR -57
#define F708_ERR -58
#define F709_ERR -59
#define F710_ERR -60
#define F711_ERR -61
#define F712_ERR -62
#define F713_ERR -63
#define F714_ERR -64
#define F715_ERR -65
#define F716_ERR -66
#define F717_ERR -67
/* TCC 1995/11/23 End   */
/* TCC: 1996/01/15 Begin */
#define FIND_BIT_ERROR           -27
#define GET_BIT_PTR_ERR          -28
#define NETWORKTBL_ERR           -29
#define SEND_ERR                 -30
#define READ_ERR                 -31
/* TCC: 1996/01/15 End   */
#define GET_CENTER_DESKEY_ERR    -32

/* <emsstart.c> GetCkDat() error message code */
#define GET_SSA_PTR_ERR                 -1
#define FIND_BIT_ERR                    -2
#define OPEN_TXNDATE_ERR                -3
#define TXNDATE_INPUT_ERR               -4
#define SNOSUCH_BRHID_ERR               -5
#define SILL_STARTDATE_ERR              -6
#define STXNDATE_OVERFLOW_ERR           -7
#define SCALFILE_NOEXIST_ERR            -8
#define SREAD_CALFILE_ERR               -9
#define SUNKNOWN_CAL_ERR                -10
#define SUNKNOWN_RTNCODE_ERR            -11
#define NONBUSI_DATE_ERR                -12

/* <emsstart.c> TxLogIni() error message code */
#define GET_SSA_PTR_ERR                 -1
#define OPEN_LOGFILE_ERR                -2
#define CLOSE_LOGFILE_ERR               -3

/* <emsstart.c> SyStuIni() error message code */
#define GET_SSA_PTR_ERR                 -1

/* <emsstart.c> IsuPvPre() error message code */
#define OPEN_SERVER_FILE_ERR            -10
#define SERV_PARA_ERR                   -11
#define SERV_ENTRY_OVERFLOW_ERR         -12
#define SERV_PROC_OVERFLOW_ERR          -13

#define OPEN_CHRON_FILE_ERR             -20
#define CHRON_PARA_ERR                  -21
#define CHRON_PROC_OVERFLOW_ERR         -22

#define FORK_SERVER_ERR                 -30
