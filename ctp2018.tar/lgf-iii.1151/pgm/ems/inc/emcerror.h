/* the last error code now is F915            */

/* <emsenvhl.c> SignlHdl() error message code */
#define SIGNAL_HDL_ERR_E                "F801"  
#define INIT_CUSTOMTBL_ERR_E            "F906"  
#define GET_CUSTOMVALUE_ERR_E           "F907"  

/* <emsenvhl.c> GetConfg() error message code */
#define INIT_CNFTBL_ERR_E               "F802" 
#define GET_CWAKEY_ERR_E		"F803"        
#define GET_CTFKEY_ERR_E	        "F804"        
#define GET_ICTKEY_ERR_E		"F805"          
#define GET_DBTKEY_ERR_E		"F806"         
#define GET_IETKEY_ERR_E	        "F807"         
#define GET_SYSOPMODE_ERR_E		"F808" 
#define GET_BRHIDLEN_ERR_E		"F809" 
#define GET_TMIDLEN_ERR_E		"F810"         
#define GET_TXNIDLEN_ERR_E		"F811" 
#define GET_TESTMODE_ERR_E		"F812"  
#define GET_TELLERIDLEN_ERR_E		"F813"  
#define GET_LOADCVTTBL_ERR_E		"F876"  
#define GET_SYSTEMROLE_ERR_E		"F879"  
#define GET_BASEYEAR_ERR_E		"F880"  
#define GET_BASEYEAR_ERR_E		"F880"  
#define GET_NOBATCH_ERR_E		"F897"  
#define GET_NOSIGNON_ERR_E		"F898"  
#define GET_MAXPACKETSIZE_ERR_E		"F899"  
#define GET_TMAX_ERR_E		 	"F900"  
#define GET_TMIN_ERR_E			"F901"  
#define GET_TOFFSET_ERR_E		"F902"  
#define TMAX_VALUE_ERR_E		"F903"  
#define TMIN_VALUE_ERR_E		"F904"  

/* <emsenvhl.c> EnvStatuChk() error message code */
#define CWA_HAD_EXISTED_ERR_E           "F814"  

/* <emsenvhl.c> CwaHdl() error message code */
#define CREATE_CWA_ERR_E                "F815"  
#define ATTACH_CWA_ERR_E                "F816"   
#define GET_SSA_PTR_ERR_E               "F817"   
#define GET_BIT_PTR_ERR_E               "F818"   
#define OPEN_BIT_ERR_E                  "F819"   
#define SCAN_BIT_ERR_E                  "F820"     
#define BIT_TYPE_ERR_E                  "F821"     
#define BR_LEN_ERR_E                    "F822"     
#define TM_LEN_ERR_E                    "F823"     
#define BIT_ENTRY_DUPL_ERR_E            "F824"     
#define TM_TYPE_ERR_E                   "F825"     
#define GET_SES_PTR_ERR_E               "F826"     
#define GET_SPA_PTR_ERR_E               "F875"   
#define GET_B2N_PTR_ERR_E               "F877"   
#define INIT_CVT_TBL_ERR_E              "F878"   
#define BIT_OVERFLOW_ERR_E              "F908"   
#define BRH_OVERFLOW_ERR_E              "F909"   
#define TERM_OVERFLOW_ERR_E             "F910"   
#define NO_BRH_ERR_E                    "F911"   
#define GET_MDA_PTR_ERR_E               "F912"

/* <emsenvhl.c> KernTblLd() error message code */
#define OPEN_CTFFILE_ERR_E              "F827"     
#define CNT_BUSINUM_ERR_E               "F828"     
#define CREATE_CTFSHM_ERR_E             "F829"     
#define READ_CTFFILE_ERR_E              "F830"     
#define BUSI_DUPL_ERR_E                 "F831"     
#define OPEN_IETFILE_ERR_E              "F832"     
#define IET_FILESIZE_NEG_ERR_E          "F833"     
#define IET_FILESIZE_ERR_E              "F834"     
#define CREATE_IETSHM_ERR_E             "F835"       
#define READ_IETFILE_ERR_E              "F836"       
#define IET_TYPE_ERR_E                  "F837"       
#define CTF_SIZE_ERR_E                  "F838"       
#define CIT_SIZE_ERR_E                  "F839"       
#define GUD_SIZE_ERR_E                  "F840"       
#define MENU_SIZE_ERR_E                 "F841"       
#define HLP_SIZE_ERR_E                  "F842"       
#define MST_SIZE_ERR_E                  "F843"      
#define CREATE_ICTSHM_ERR_E             "F844"       
#define CIT_LOAD_ERR_E                  "F845"         
#define GUD_LOAD_ERR_E                  "F846"         
#define MENU_LOAD_ERR_E                 "F847"         
#define HLP_LOAD_ERR_E                  "F848"         
#define MST_LOAD_ERR_E                  "F849"         

/* <emsifenv.c> error message code */
#define OPEN_MODFILE_ERR_E 		"F850"       
#define MODFILE_FORMAT_ERR_E 		"F851"       
#define MODPROG_EXEC_ERR_E              "F852"         
#define FORK_MODPG_ERR_E                "F853"         
#define RM_MODPROG_EXEC_ERR_E           "F854"         
#define FORK_RM_MODPG_ERR_E             "F855"         

/* <emstxpre.c> error message code */
#define OPEN_TXNPREFILE_ERR_E 		"F891"       
#define TXNPREFILE_FORMAT_ERR_E 	"F892"       
#define OPERATE_MODE_ERR_E 	        "F893"       
#define SYSTEM_STATUS_ERR_E 	        "F894"       
#define SHELL_EXEC_ERR_E                "F895"         
#define SHELL_FORK_ERR_E                "F896"         

/* <emsstart.c> SysStart() error message code */
/* TCC 1995/11/23 Begin */
#define F701_ERR_E                      "F701"
#define F702_ERR_E                      "F702"
#define F703_ERR_E                      "F703"
#define F704_ERR_E                      "F704"
#define F705_ERR_E                      "F705"
#define F706_ERR_E                      "F706"
#define F707_ERR_E                      "F707"
#define F708_ERR_E                      "F708"
#define F709_ERR_E                      "F709"
#define F710_ERR_E                      "F710"
#define F711_ERR_E                      "F711"
#define F712_ERR_E                      "F712"
#define F713_ERR_E                      "F713"
#define F714_ERR_E                      "F714"
#define F715_ERR_E                      "F715"
#define F716_ERR_E                      "F716"
#define F717_ERR_E                      "F717"
/* TCC 1995/11/23 End */
/* TCC 1996/01/16 Begin */
#define FIND_BIT_ERROR_E                "F818"
#define NETWORKTBL_ERR_E                "F912"
#define SEND_ERR_E                      "F913"
#define READ_ERR_E                      "F914"
/* TCC 1996/01/16 End */
#define GET_CENTER_DESKEY_ERR_E         "F915"

#define NOSUCH_BRHID_ERR_E              "F881" 
#define ILL_STARTDATE_ERR_E             "F882"         
#define TXNDATE_OVERFLOW_ERR_E          "F883"         
#define CALFILE_NOEXIST_ERR_E           "F884"         
#define READ_CALFILE_ERR_E              "F885"         
#define UNKNOWN_CAL_ERR_E               "F886"         
#define UNKNOWN_RTNCODE_ERR_E           "F887"         
#define UPT_TXNDATE_FMLOCAL_ERR_E       "F888"         
#define CENTER_NOTOPEN_ERR_E            "F889"         
#define TTY_NOTDEFINED_ERR_E            "F890"         
#define FORWARD_RV_CWA_ERR_E		"F905"  

/* <emsstart.c> GetCkDat() error message code */
#define FIND_BIT_ERR_E                  "F856"           
#define OPEN_TXNDATE_ERR_E              "F857"           
#define TXNDATE_INPUT_ERR_E             "F858"           
#define NONBUSI_DATE_ERR_E              "F800"

/* <emsstart.c> TxLogIni() error message code */
#define OPEN_LOGFILE_ERR_E              "F859"           
#define CLOSE_LOGFILE_ERR_E             "F860"           

/* <emsstart.c> IsuSvPrs() error message code */
#define OPEN_SERVER_FILE_ERR_E          "F862"            
#define SERV_PARA_ERR_E                 "F863"            
#define SERV_ENTRY_OVERFLOW_ERR_E       "F864"            
#define SERV_PROC_OVERFLOW_ERR_E        "F865"            
#define OPEN_CHRON_FILE_ERR_E           "F866"            
#define CHRON_PARA_ERR_E                "F867"            
#define CHRON_PROC_OVERFLOW_ERR_E       "F868"            
#define FORK_SERVER_ERR_E               "F870"            


/* <emcserve.c> WaitCmd() error message code */
#define GET_CMD_DCS_ERR_E               "F871"           
#define RCV_CMD_DATA_ERR_E              "F872"             

/* <emcserve.c> Dispatch() error message code */
#define SENDACK_TO_CALLER_ERR_E         "F873"             
#define REMOVE_COMPO_ERR_E              "F874"             
#define SAVE_CWA_ERR_E                  "F912"

#define SYSTEM_ERR_E                    "F999"             
