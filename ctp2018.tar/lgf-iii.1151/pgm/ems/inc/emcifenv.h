
#define OPEN_IFMOD_ERR         -1
#define IFMOD_ENTRY_ERR        -2
#define EXEC_IFMOD_ERR         -3
#define FORK_IFMOD_ERR         -4
#define RM_IFMOD_EXEC_ERR      -5
#define FORK_RM_IFMOD_ERR      -6

#define  MAX_EXEC_PATH_LEN     80
#define  FILE_NAME_LEN         80
#define  MAX_IFMOD_NUM         10
#define  IFMOD_FILE            "iii/etc/tbl/emdifmod.dat"
#define  CWA_SHM_KEY           "CWA_SHM_KEY"

static
struct if_st {
  char pcaModuleName[10];      /* module name     */
  char pcaVersionName[20];     /* version name    */
  char pcaLoadPgmName[20];     /* load program name */
  char pcaAttFunName[20];      /* attach program  */
  char pcaIniFunName[20];      /* initial program */
  char pcaBgnFunName[20];      /* begin program   */
  char pcaEndFunName[20];      /* end program     */
  char pcaRelFunName[20];      /* release program */
  char pcaDetFunName[20];      /* detach program  */
  char pcaRlsePgmName[20];     /* release program name */
} sg_staIfModTbl[MAX_IFMOD_NUM];
