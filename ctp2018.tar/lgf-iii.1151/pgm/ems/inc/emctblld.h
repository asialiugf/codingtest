
/*--------------------  emctblld.h ----------------------------*/
/* for compatiable imctblld.str definition file layout,descri- */
/* ption are delcared                                          */
/* ----------------------------------------------------------- */

#define INT long
#define BUSI_DIR_LEN   2
#define TXN_CODE_LEN   4
#define TXN_PGM_LEN    10
#define GUD_NO_LEN     4
#define CTF_NAME_LEN   30
#define GUD_LINE_LEN   80
#define MST_NO_LEN     4
#define MST_CONT_LEN   76

/*& STRUCTURE_NAME:busi_head_node                                          */
/*& business head rec. description in the transaction definition file      */
struct busi_head_node  {    /*& business head rec. defined                 */
   char cRecHead;           /*& rec. id.                                   */
                            /*& rec. id. description                       */
                            /*& 1 : rec. type is busi_head_def             */
                            /*& 2 : rec. type is txn_head_def              */
                            /*& 3 : rec. type is txn_item_def              */
   char cBusiType;          /*& business type (the 1st char. in the txnid) */
   char caBusiDir[BUSI_DIR_LEN+1];  /*& business program directory         */
   INT  lBusiTitle;         /*& guidance record no. defined in the         */
                            /*& guide-file of the busi_title               */
   char caFiller[60];       /*& space                                      */
};
typedef struct busi_head_node busi_head;

/*& STRUCTURE_NAME:busi_ctf_node                                           */
/*& business ctf rec. description for the ctf and CIT used                 */
struct  busi_ctf_node { /*& business head rec. defined                     */
   char cBusiType;      /*& business type (the 1st char. in the txnid)     */
   int  iTotItem;       /*& total no of the CTF items                      */
   int  iCtfSize;       /*& size of the ctf in this business               */
   int  iInitIdx;	/*& idex to initial ctf area		           */
   int  iTblIdx;        /*& index to first item CTF table of the business  */
};
typedef struct busi_ctf_node busi_ctf;

/*& STRUCTURE_NAME:txn_head_node                                           */
/*& transaction head rec. description in the transaction definition file   */
struct  txn_head_node {           /*& txn head rec. format defined         */
   char cRecHead;                 /*& rec. id.                             */
   char caTxnCode[TXN_CODE_LEN+1];/*& txn code                             */
   char cSec;                     /*& reserved for security                */
   char cCharc;                   /*& reserved for characteristic          */
   char caTxnPgm[TXN_PGM_LEN+1];  /*& transaction program name             */
   char caTrigger1_id[GUD_NO_LEN+1];/*& enter txn-screen trigger rtn id    */
   char caTrigger2_id[GUD_NO_LEN+1];/*& leave txn-screen trigger rtn id    */
   INT  lHelpId;                  /*& the record number of the 1st help    */
                                  /*& entry in online help file            */
   INT  lTxnTitle;                /*& guidance record no. defined in the   */
                                  /*& guide-file of the txn title.         */
   short sTotItem;                /*& total no. of data items of the txn   */
   char caFiller[30];             /*& filler                               */
};
typedef struct txn_head_node txn_head;

/*& STRUCTURE_NAME:txn_item_node                                            */
/*& transaction item rec. description in the transaction definition file    */
struct  txn_item_node {            /*& txn data item format defined         */
   char  cRecHead;                 /*& rec. id.                             */
   char  caInitId[GUD_NO_LEN+1];   /*& initialization rtn ID                */
   char  caChkId[GUD_NO_LEN+1];    /*& check rtn. ID                        */
   char  cDatAttr;                 /*& data attribute(0: option; 1: require)*/
   char  cPage;                    /*& page number                          */
   char  cRow;                     /*& row number                           */
   char  cCol;                     /*& column number                        */
   char  caCtfName[CTF_NAME_LEN+1];/*& ctf name                             */
   char  cDataType;                /*& the data type of the input field     */
   INT   lGudLine;                 /*& guidance record-no in guide file of  */
                                   /*& the data item on screen              */
   INT   lHelpId;                  /*& the record number of the 1st help    */
                                   /*& entry in online help file            */
   INT   lCtfRelat;                /*& relative number to ctf table         */
   short sInputLen;                /*& max length of the input field        */
   short sDotPost;                 /*& the position of the decimal digital  */
   char  caFiller[05];              /*& filler                               */
};
typedef struct txn_item_node txn_item;

/*
typedef struct tbl_item_def tbl_item;
                                /x type define of item entry of item tbl x/
*/

/*& STRUCTURE_NAME:gud_node                                                */
/*& guide-line description table                                           */
struct  gud_node {
  char  caGudNo[GUD_NO_LEN+1];     /*& guide-line number                   */
  char  caGudLine[GUD_LINE_LEN+1]; /*& guidance description                */
};

/*& STRUCTURE_NAME:menu_node                                                 */
/*& menu-driven description record layout in the menu_file (in memory)       */
struct  menu_node {
  short sChildNo;                  /*& no. of child below this menu         */
  INT   lHelpOff;                  /*& online help offset in the help file  */
  INT   lGudRelat;                 /*& offset of the guidance               */
  char  cMainMenu;                 /*& main-menu('1') or not('0')           */
  char  cPriviledge;               /*& priviledge level of this menu node   */
  char  caTxnCode[TXN_CODE_LEN+1]; /*& txn_id or the offset of the 1st child*/
};

/*& STRUCTURE_NAME:menu_rec                                                  */
/*& menu-driven description record layout in the menu_file (after parser)    */
struct  menu_rec {
     short sChildNo;                /*& no. of child below this menu         */
     INT   lHelpOff;                /*& online help offset in the help file  */
     INT   lGudRelat;               /*& record no. of the guidance in gudfile*/
     char  cMainMenu;               /*& main-menu('1') or not('0')           */
     char  cPriviledge;              /*& priviledge level of this menu node   */
     char  caTxnId[TXN_CODE_LEN+1];  /*& txn_id or the offset of the 1st child*/
     char  caMenuId[7];
};

/*& STRUCTURE_NAME:online_help_rec                                            */
/*& online help: help-id and content mapping table                            */
struct help_node {
  char  caHlpNo[GUD_NO_LEN+1];    /*& online-help id                         */
  char  caHlpLine[GUD_LINE_LEN+1];/*& online-help content                    */
                                  /*& the 1st help node of a help-id use the */
                                  /*& following layout:                      */
                                  /*& help-kind[1]:0 -> descriptive help     */
                                  /*&              1 -> item-choice help     */
                                  /*& y1[2] -> y-coordunate of the window    */
                                  /*& x1[2] -> x-coordinate of the window    */
                                  /*& y2[2] -> y-coordunate of the window    */
                                  /*& x2[2] -> x-coordinate of the window    */
                                  /*& filler[GUD_LINE_LEN-9] -> filler       */
};

/*& STRUCTURE_NAME:routine_rec                                                */
/*& routine id and routine content mapping table                              */
struct routine_node {
  char  caRtnId[GUD_NO_LEN+1];      /*& trigger routine id                   */
  char  caHelpCent[GUD_LINE_LEN+1]; /*& trigger routine content              */
};

/*& STRUCTURE_NAME:mst_node                                                   */
/*& mst description table                                                     */
struct  mst_node {
  char  caMstNo[MST_NO_LEN];      /*& message code                           */
  char  caMstCont[MST_CONT_LEN];  /*& message content                        */
};


/*& STRUCTURE_NAME:page_node                                                  */
/*& page description table for multipages                                    */
struct  page_node {
  char  caPageNo;           /*& page number                           */
  int   iFstFldIdx;      /*& the first item's fld_idx in this page   */
};
/* ------------------ END OF INCLUDE FILE imctblld.str -------------------- */
