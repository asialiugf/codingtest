
struct SifHeader {
  char caTxnCode[4];
  char caTextId[6];
  char caBrhId[10];
  char caTermId[4];
  char caTellerId[4];
  char caFiller[20];
};

struct SofHeader {
  char caFmh[3];
  char caBrhId[10];
  char caTermId[4];
  char cOutDev;
  char caFormId[7];
  char caStatus[2];
};

/* Constants definition for EMS Tool */

/* The operations to request EMS Tool server */
#define		RETRIEVE	'1'
#define		UPDATE		'2'
#define		INSERT		'3'
#define		DELETE		'4'

/* The data area to maintain */
#define		CWA_SSA		'1'
#define		BIT_BRH		'2'
#define		BIT_TRM		'3'

/* EMS Tool server reply status */
#define		SUCCESS		0x0000
#define		FAIL		0x0001

/* The error message codes */
#define		ERR0001		0x04
#define		ERR0002		0x05
#define		ERR0003		0x06
#define		ERR0004		0x07
#define		ERR0005		0x08
#define		ERR0006		0x09
#define		ERR0007		0x0a
#define		ERR0008		0x0b
#define		ERR0009		0x0c
#define		ERR0010		0x0d
#define		ERR0011		0x0e
#define		ERR0012		0x0f

#define         PAGE_SIZE       10
#define         PAGE_LIMIT      3*PAGE_SIZE
