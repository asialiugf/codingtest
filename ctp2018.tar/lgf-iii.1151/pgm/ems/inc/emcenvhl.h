
/* <emsenvhl.c> error message code */
#define INIT_CUSTOMTBL_ERR 		-1
#define GET_CUSTOMVALUE_ERR 		-2

/* <emsenvhl.c> SignlHdl() error message code */
#define SIGNAL_HDL_ERR                  -1

/* <emsenvhl.c> GetConfg() error message code */
#define INIT_CNFTBL_ERR                 -1
#define GET_CWAKEY_ERR		        -2
#define GET_CTFKEY_ERR	                -3
#define GET_ICTKEY_ERR		        -4 
#define GET_DBTKEY_ERR		        -5
#define GET_IETKEY_ERR	                -6
#define GET_SYSOPMODE_ERR		-7
#define GET_BRHIDLEN_ERR		-8
#define GET_TMIDLEN_ERR		        -9
#define GET_TXNIDLEN_ERR		-10 
#define GET_TESTMODE_ERR		-11 
#define GET_TELLERIDLEN_ERR		-12 
#define GET_LOADCVTTBL_ERR		-13 
#define GET_SYSTEMROLE_ERR		-14 
#define GET_BASEYEAR_ERR		-15 
#define GET_NOBATCH_ERR		        -16 
#define GET_NOSIGNON_ERR                -17 
#define GET_MAXPACKETSIZE_ERR		-18 
#define GET_TMAX_ERR			-19 
#define GET_TMIN_ERR			-20 
#define GET_TOFFSET_ERR			-21 
#define TMAX_VALUE_ERR			-22 
#define TMIN_VALUE_ERR			-23 
#define GET_ERRLOGMAX_ERR               -24

/* <emsenvhl.c> EnvStatuChk() error message code */
#define CWA_HAD_EXISTED_ERR             -1

/* <emsenvhl.c> CwaHdl() error message code */
#define CREATE_CWA_ERR                  -1
#define ATTACH_CWA_ERR                  -2
#define GET_SSA_PTR_ERR                 -3
#define GET_BIT_PTR_ERR                 -4
#define OPEN_BIT_ERR                    -5
#define SCAN_BIT_ERR                    -6
#define BIT_TYPE_ERR                    -7
#define BR_LEN_ERR                      -8
#define TM_LEN_ERR                      -9
#define BIT_ENTRY_DUPL_ERR              -10
#define TM_TYPE_ERR                     -11
#define GET_SES_PTR_ERR                 -12
#define GET_SPA_PTR_ERR                 -13
#define GET_B2N_PTR_ERR                 -14
#define INIT_CVT_TBL_ERR                -15
#define BIT_OVERFLOW_ERR                -16
#define BRH_OVERFLOW_ERR                -17
#define TERM_OVERFLOW_ERR               -18
#define NO_BRH_ERR                      -19
#define GET_MDA_PTR_ERR                 -20

/* <emsenvhl.c> KernTblLd() error message code */
#define OPEN_CTFFILE_ERR                -1
#define CNT_BUSINUM_ERR                 -2
#define CREATE_CTFSHM_ERR               -3
#define READ_CTFFILE_ERR                -4
#define BUSI_DUPL_ERR                   -5
#define OPEN_IETFILE_ERR                -6
#define IET_FILESIZE_NEG_ERR            -7
#define IET_FILESIZE_ERR                -8
#define CREATE_IETSHM_ERR               -9
#define READ_IETFILE_ERR                -10
#define IET_TYPE_ERR                    -11
#define CTF_SIZE_ERR                    -12
#define CIT_SIZE_ERR                    -13
#define GUD_SIZE_ERR                    -14
#define MENU_SIZE_ERR                   -15
#define HLP_SIZE_ERR                    -16
#define MST_SIZE_ERR                    -17
#define CREATE_ICTSHM_ERR               -18
#define CIT_LOAD_ERR                    -19
#define GUD_LOAD_ERR                    -20
#define MENU_LOAD_ERR                   -21
#define HLP_LOAD_ERR                    -22
#define MST_LOAD_ERR                    -23
