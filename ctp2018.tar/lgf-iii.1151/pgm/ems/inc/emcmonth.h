
#include <curses.h>
#include "asscal.h"

#define ROW_UNIT_NUM  5
#define COL_UNIT_NUM  6
#define ROW_UNIT_SIZE 2
#define COL_UNIT_SIZE 8
#define CAL_TABLE_ROW0 4
#define CAL_TABLE_COL0 11
#define CAL_TABLE_DAY_ROW0 (CAL_TABLE_ROW0 + 3)
#define CAL_TABLE_DAY_COL0 (CAL_TABLE_COL0 + 4)
#define CAL_TABLE_ENT_ROW0 (CAL_TABLE_ROW0 + 3)
#define CAL_TABLE_ENT_COL0 (CAL_TABLE_COL0 + 4)
/*
#define CAL_TABLE_ENT_COL0 (CAL_TABLE_COL0 + 6)
*/
#define CAL_TABLE_ENT_ROW_LMT \
        (CAL_TABLE_ENT_ROW0 + ROW_UNIT_NUM * ROW_UNIT_SIZE) 
#define CAL_TABLE_ENT_COL_LMT \
        (CAL_TABLE_ENT_COL0 + COL_UNIT_NUM * COL_UNIT_SIZE) 

char *CAL_TABLE[15] =
{ 
"+-------+-------+-------+-------+-------+-------+-------+\n",
"|  Sun  |  Mon  |  Tue  |  Wed  |  Thu  |  Fri  |  Sat  |\n",
"+-------+-------+-------+-------+-------+-------+-------+\n",
"|       |       |       |       |       |       |       |\n", 
"+-------+-------+-------+-------+-------+-------+-------+\n",
"|       |       |       |       |       |       |       |\n", 
"+-------+-------+-------+-------+-------+-------+-------+\n",
"|       |       |       |       |       |       |       |\n", 
"+-------+-------+-------+-------+-------+-------+-------+\n",
"|       |       |       |       |       |       |       |\n", 
"+-------+-------+-------+-------+-------+-------+-------+\n",
"|       |       |       |       |       |       |       |\n", 
"+-------+-------+-------+-------+-------+-------+-------+\n",
"|       |       |       |       |       |       |       |\n", 
"+-------+-------+-------+-------+-------+-------+-------+\n"
};

unsigned int n, d[42], ent, min_ent, max_ent;
unsigned int row, col;

char *mon[12] = {
                  " January ", "February ", "  March  ",
                  "  April  ", "   May   ", "  June   ",
                  "   July  ", " August  ", "September",
                  " October ", "November ", "December "
                };
int day[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

#define OPEN_PROMPTFILE_ERR -2
#define NON_BUSINESS_DAY  -1
#define UPDATE_OK          0
#define NO_SUCH_BRCODE     1
#define NO_SUCH_YEAR       2
#define OVERFLOW_DATE      3
#define CALFILE_NOTEXIST   4
#define CALFILE_READ_ERR   5
#define OTHER_ERR          6
#define RETURN_CODE_ERR    8

#define FILE_NAME_LEN     80
#define UPCAL_C           "iii/etc/cmg/emdupcal.scr"
#define UPCAL_E           "iii/etc/emg/emdupcal.scr"

#define MAX_LINE_LEN 100

char g_caPromBuf[13][MAX_LINE_LEN];
char g_caIsBusi[12][31];
struct parASDAYIN2 stPara;
