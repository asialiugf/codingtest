/* <emstxpre.c> error message code */
#define OPEN_TXNPREFILE_ERR 		-1
#define TXNPREFILE_FORMAT_ERR           -2
#define OPERATE_MODE_ERR                -3
#define SYSTEM_STATUS_ERR               -4
#define SHELL_EXEC_ERR                  -5
#define SHELL_FORK_ERR                  -6

#define  MAX_EXEC_PATH_LEN     80
#define  FILE_NAME_LEN         80
#define  MAX_TXNPRE_NUM        10
#define  SYSTEM_STARTED        0x8000 /* 1:started ; 0:not started */
#define  SYSTEM_RESTART        0x4000 /* 1:restarted ; 0:Normal Begin */
#define  ONLINE_CLOSE          0x0400 /* 1:Batch ; 0:On_line        */
#define  TXNPRE_FILE           "iii/etc/tbl/emdtxpre.dat"

static
struct if_st {
  char caModuleName[20];      /* module name     */
  char caOperatingMode[10];  /* operating mode  */
  char caSystemStatus[10];    /* system status   */
  char caShellPgmName[20];     /* load program name */
} sg_staTxPreTbl[MAX_TXNPRE_NUM] ;

