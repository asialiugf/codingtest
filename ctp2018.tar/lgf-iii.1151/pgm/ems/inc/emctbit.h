/*      Constants for BIT-BRH        */

#define         BRH_STATUS              0
#define         BRH_ID                  1
#define         BRCH_CLS_TIME           2
#define         TXN_DATE                3
#define         NXT_TXN_DATE            4
#define         NNXT_TXN_DATE           5
#define         NO_OF_TERM              6
#define         TERM_OFFSET             7

/*      Constants for BIT-TRM        */

#define         LAST_ONLN_RRN           0
#define         LAST_BTCH_RRN           1
#define         CUR_BTCH_ERR_RRN        2
#define         LOGIC_ID                3
#define         TERM_ID                 4
#define         TERM_TYPE               5
#define         TERM_STATUS_1           6
#define         TERM_STATUS_2           7
#define         TERM_MODE               8
#define         BACK_BRH_ID             9
#define         BACK_TERM_ID            10
#define         ACC_TXN_NO              11
#define         NON_ACC_TXN_NO          12
#define         BTCH_TXN_NO             13
/* ###
#define         TERM_MODE               7
#define         BACK_BRH_ID             8
#define         BACK_TERM_ID            9
#define         ACC_TXN_NO              10
#define         NON_ACC_TXN_NO          11
#define         BTCH_TXN_NO             12
*/

/*      Data structure for BIT-BRH      */

struct stBIT_BRH {
        char cBrhStatus;
        char caBrhId[MAX_BR_LEN];
        char caBrchClsTime[6];
        char caTxnDate[8];
        char caNxtTxnDate[8];
        char caNNxtTxnDate[8];
        int  iNoOfTerm;
        int  iTermOffset;
        int  iNxtBrhOffset;
        char filler[7];
        };

/*      Data structure for BIT-TRM      */

struct stBIT_TRM {
        long lLastOnlnRrn;
        long lLastBtchRrn;
        long lCurBtchErrRrn;
        char caLogicId[MAX_BR_LEN+MAX_TM_LEN];
        char caTermId[MAX_TM_LEN];
        char cTermType;
        char cTermStatus;
        char cTermMode;
        char caBackBrhId[MAX_BR_LEN];
        char caBackTermId[MAX_TM_LEN];
        long lAccTxnNo;
        long lNonAccTxnNo;
        long lBtchTxnNo;
        int  iNxtTmOffset;
        char filler[7];
        };

struct stTrmNode {
        struct stBIT_TRM stTrmRecord;
        struct stTrmNode *next;
        struct stTrmNode *prev;
        int iNodeIdx;
        };

struct stBrhNode {
        struct stBIT_BRH stBrhRecord;
        struct stBrhNode *next;
        struct stBrhNode *prev;
        struct stTrmNode *pstTrmHead;
        int iNodeIdx;
        };

struct stMenuBit {
        WINDOW *pwWin;
        int iNoRecord; /* the number of records shown at the same time */
        int iTotalNode; /* the total number of records */
        struct stMenuBit *pstNextMenu;
        struct stItem *pstItem;
        char *pcHead;  /* the head pointer to branch or terminal node list */
        };
