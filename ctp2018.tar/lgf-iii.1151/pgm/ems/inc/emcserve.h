
/* <emcserve.c> WaitCmd() error message code */
#define GET_CMD_DCS_ERR                 -1
#define RCV_CMD_DATA_ERR                -2

/* <emcserve.c> Dispatch() error message code */
#define SENDACK_TO_CALLER_ERR           -1
#define REMOVE_COMPO_ERR                -2
#define SAVE_CWA_ERR                    -3
