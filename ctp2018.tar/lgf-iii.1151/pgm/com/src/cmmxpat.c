
#include <stdio.h>
#include <unistd.h>

#define MAX_LEN      1024
#define MATCH        0

int              index, from_len, to_len;
int              tmp_fd, match_index[MAX_LEN];
unsigned char    buf[MAX_LEN], Tmpfile[16];
unsigned char    *from_ptn, *to_ptn;

int Strncmp (s1, s2, n)
register  unsigned  char  *s1, *s2;
register  unsigned  int   n;
{
        if (s1 == s2 || n == 0) return (0);
        while (n && *s1) {
                if  (*s1  !=*s2)  break;
                if  (--n > 0)  {
                        s1 ++;
                        s2 ++;
                }
         }
         return  (*s1 - *s2);
}

update_file  (filename)
char    *filename;
{
        char    cmd_buf [512];

        sprintf (cmd_buf, "cp %s %s", Tmpfile, filename);
        system (cmd_buf);
}

write_to_temp (size)
int     size;
{
        int     i, j, rc, start, len;

        if (index == 0)  {
            if ( ( rc = write (tmp_fd, buf, size ) ) !=size)
               rc = -1;
        } else {
            for (i = start = 0; i < index; i++) {
                len = match_index [i] - start;
                if ( (rc = write (tmp_fd, buf + start, len) ) !=len){
                   rc = -1;
                   break;
                }
                if ( (rc = write (tmp_fd, to_ptn, to_len)) != to_len) {
                   rc = -1;
                   break;
                   }
                start = match_index[i] + from_len;
            }
            j = size - start;
            if ( j > 0){
              if ( ( rc = write (tmp_fd, buf + start, j)) != j)
                 rc = -1;
              }
            }

            return (rc);
}

main  (argc, argv)
int      argc;
unsigned  char    *argv[];
{
        int                fd, len, do_flg, status;
        register int       i, j;

        if  (argc != 4)  {
            fprintf(stderr,"Usage: xpat filename from-pattern to-pattern\n\r");
            exit(-1);
        }

        if  ( (fd = open  (argv[1], 2)) <=0 )  {
            fprintf (stderr, "Cannot open file \"%s\"\n\r", argv[1]);
            exit(-1);
        }

        sprintf(Tmpfile, "/tmp/.Xpat%05d", getpid());

        if  ( (tmp_fd = creat (Tmpfile, 0600)) < 0) {
            fprintf  (stderr, "Cannot creat temp file\n\r");
            close (fd);
            exit (-1);
        }

        from_ptn = argv[2];
        from_len = strlen (from_ptn);
        to_ptn   = argv[3];
        to_len   = strlen  (to_ptn);

        do_flg = 1;
        while (do_flg && (len = read (fd, buf, MAX_LEN))) {
               if (len != MAX_LEN)
                  do_flg = 0;
               j = do_flg ? len - from_len + 1 : len;
               for (i = index = 0; i < j; i++)  {
                   if (Strncmp (buf + i, from_ptn, from_len) == MATCH) {
                      match_index [index++] = i;
                      i +=  from_len;
                   }
               }
               if ((status = write_to_temp(j)) < 0)  {
                  fprintf(stderr,"Write temp file failure !!\n\r");
                  break;
               }
               if ( match_index[index-1] + from_len == MAX_LEN){
                 lseek  (fd, 0, SEEK_CUR);
               }else{
                 lseek  (fd, j - len, SEEK_CUR);
               }
        }
        close (fd);
        close (tmp_fd);

        if (status >=0)
           update_file  (argv[1]);

/*
        unlink (Tmpfile);
*/
}

