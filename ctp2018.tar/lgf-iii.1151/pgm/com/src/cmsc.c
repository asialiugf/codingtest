TMSINITCOB()
{
}
cobinit()
{
  return 0;
}
cobexit()
{
  return 0;
}
cobcancel()
{
  return 0;
}
