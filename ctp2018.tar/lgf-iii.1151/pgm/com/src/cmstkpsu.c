
#include <errno.h>
#include "errlog.h"
#include "dcs.h"     /* for dcs api */

#define  P_SdSifRvSof         11111
#define  SOCKET_DCS 	'S'
#define  PROTOCOL_TYPE  	"III_PROTOCOL"
#define  INTERACT_PESUDO	'8' /* the kind pesudo IO get & dispatch */
#define  DEST_NAME_LEN  10
#define  SEND_SIF_ERR        -11   /* these 3 err code are concated with */
#define  READ_Q_TIMEOUT_ERR  -12   /* the error codes used by SignonCenter */
#define  READ_Q_ERR          -13
/* TCC: 1996/01/17 */
#define  NETWORKTBL_ERR      -25
#define  SEND_ERR            -26
#define  READ_ERR            -27

struct DcsBuf stDcsBuf; 
struct DcsSiof stDcsSiof;      

/*
 *&N& ROUTINE NAME: SdSifRvSof
 *&A& ARGUMENTS:
 *&A&    char   *pcaDesCode
 *&A&    char   *pcaSif
 *&A&    int    iSifLen
 *&A&    char   *pcaSof 
 *&A&    int    *piSofLen
 *&R& RETURN VALUE(S):
 *&R&    int
 *&D& DESCRIPTION:
 *&D*
 */
int SdSifRvSof(pcaDesCode, pcaSif, iSifLen, pcaSof, piSofLen)
char *pcaDesCode;
char *pcaSif;
int  iSifLen;
char *pcaSof;
int  *piSofLen;
{
  int iLen,iMsgLen;
  char   caTmpBuf[10];   
  int    iDataLen,iRcvDataLen,iSessidx;
  static char   s_cProtocoltype = '\0';
  char caProtoType[80];  /* enviroment variable buffer */
  struct DcsBuf stDcsBuf;   /* call dcs module struct */
  struct DcsSiof stDcsSiof; /* call dcs module input/output struct */

  UCP_TRACE(P_SdSifRvSof);

    memset(&stDcsBuf,0,sizeof(struct DcsBuf));
    memset(&stDcsSiof,0,sizeof(struct DcsSiof));

    /* This routine default the protocol is SOCKET */
    /* Cause whenever a program has to interact with Pesudo IO, */
    /* It should transmit its SIF and SOF between 2 different hosts */ 

    s_cProtocoltype = SOCKET_DCS; /* talk to Pesudo IO with SOCKET */
    MpstDcsSiof(stDcsBuf) = &stDcsSiof;
    McMoreByte(stDcsBuf) = '0';
    McKind(stDcsBuf) = INTERACT_PESUDO; 
/* INTERACT_PESUDO used for send one to & receive one from Pesudo IO */ 
    memcpy(McaDesCode(stDcsBuf), pcaDesCode, DEST_NAME_LEN);
    McRqstCode(stDcsBuf) = DCSCONNECTWRITE;

/*   prepare SIF format */

    sprintf(McaDataLen(stDcsBuf),"%.4d",iSifLen + 8);
    memcpy(McaData(stDcsBuf), pcaSif, iSifLen);
    MlWaiTime(stDcsBuf) = 10;
    MiDataLen(stDcsBuf) = iSifLen + 8;
    McProto(stDcsBuf) = s_cProtocoltype;

    DcsDispatch( &stDcsBuf );

    if (MiReply(stDcsBuf) != DCS_NORMAL) {
      sprintf( g_caMsg, 
      "<COM> Failure to send data to PSEUD IO! (reply:%d)", 
      MiReply(stDcsBuf) );
      ErrLog(4000, g_caMsg, RPT_TO_LOG, 0, 0);
      /* TCC: 1996/01/17
      UCP_TRACE_END( SEND_SIF_ERR );
         TCC: 1996/01/17 */     

      if ( MiReply(stDcsBuf) == DCS_E_NETWORKTBL )
         UCP_TRACE_END (NETWORKTBL_ERR);
      
      UCP_TRACE_END (SEND_ERR);
    }

    iSessidx = MiSesIdx(stDcsBuf)  ;

    McRqstCode(stDcsBuf) = DCSREAD;
    /* set the monitor rcv timeout, if mon doesn't ger ack before timeout */
    /* mon will kill the server   */
    MlWaiTime(stDcsBuf) = 10;
    MiDataLen(stDcsBuf) = DCS_MAX_DATA_LEN;
    McProto(stDcsBuf) = s_cProtocoltype;
    MiSesIdx(stDcsBuf) = iSessidx;
    DcsDispatch(&stDcsBuf);
    if(MiReply(stDcsBuf) != DCS_NORMAL){
       sprintf(g_caMsg,"<COM> DCSREAD error reply %d errno %d"
               ,MiReply(stDcsBuf),MiErrno(stDcsBuf));
       ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
       if (MiReply(stDcsBuf) == DCS_E_TIMEOUT) {
         /* TCC: 1996/01/17  
         UCP_TRACE_END(READ_Q_TIMEOUT_ERR);
            TCC: 1996/01/17  */
         UCP_TRACE_END (READ_ERR);
       }
    }

    iRcvDataLen= MiDataLen(stDcsBuf) - 8 ;

    if(iRcvDataLen < 0) {
      sprintf (g_caMsg,
      "<COM> Failure to receive Sof from PSEUDO_IO! (reply:%d errno:%d)",
      MiReply(stDcsBuf), MiErrno(stDcsBuf));
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 
              McaData(stDcsBuf), MiDataLen(stDcsBuf));
      /* TCC: 1996/01/17  
      UCP_TRACE_END(READ_Q_ERR);
         TCC: 1996/01/17  */
      UCP_TRACE_END (READ_ERR);
    }

    ErrLog(1000,"<COM> Receive Sof from PSEUDO_IO:"
           ,RPT_TO_LOG, McaData(stDcsBuf), iRcvDataLen);

    *piSofLen = iRcvDataLen;
    memcpy(pcaSof,McaData(stDcsBuf),iRcvDataLen);

  /* receive server response */
    McRqstCode(stDcsBuf) = DCSDISCONNECT;
    McProto(stDcsBuf) = s_cProtocoltype;
    MiSesIdx(stDcsBuf) = iSessidx;
    MiDataLen(stDcsBuf) = 0;
    DcsDispatch(&stDcsBuf);
    if(MiReply(stDcsBuf) != DCS_NORMAL){
      sprintf(g_caMsg,
      "<COM> Failure to disconnect with PSEUD_IO! (reply:%d errno:%d)",
      MiReply(stDcsBuf),MiErrno(stDcsBuf));
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    }

    UCP_TRACE_END(0);
}
