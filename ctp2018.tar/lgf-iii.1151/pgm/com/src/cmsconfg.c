/*
 *&N& File : cmsconfg.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int       InitCnfTbl()           Ū�� config.dat �����e,�ó]�w
 *&N&                                     �t�ΰѼƪ� (staConfigTbl ��)
 *&N&    int       GetCnfValue()          ���o���w���t�ΰѼƭ�
 */

/* ---------------------- INCLUDE FILES DECLARATION ------------------- */
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <ctype.h>
#include "errlog.h"

/* ------------------------- CONSTANT DEFINITION ---------------------- */
/* cmsconfg.c */
#define  CONFIG_FILE            "config.dat"

#define P_GetCnfValue 		301
#define P_InitCnfTbl 		302

#define  MAX_PARA_NO		30  /* max. number of parameters */
#define  MAX_PARA_NAME_LEN	80

/* cmsconfg.c error message code */
#define INITCNFTBL_OPEN_ERR     -19
#define INITCNFTBL_STRLEN_ERR   -20
#define INITCNFTBL_MAX_ERR      -21
#define CONFIG_ENTRY_ERR        -22
#define GET_CNF_VALUE_ERR       -23

/* ------------------------- STRUCTURE DEFINITION --------------------- */
struct config_st
{
   char caName[ MAX_PARA_NAME_LEN ];
   int  iValue;
} staConfigTbl[ MAX_PARA_NO ];

/* ----------------- STATIC GLOBAL VARIABLES DECLARATION -------------- */
static int sg_iTotalParaNo;    /* actual parameters in config.dat       */

int ctoi (int base, char ch);
/*
 *&N& ROUTINE NAME: InitCnfTbl(pcFileName)
 *&A& ARGUMENTS:
 *&A&    char  *pcFileName; �t�ΰѼ��ɪ��ɮצW�١C
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&   ����ƥΥH�N�t�ΰѼ��� config.dat �����e��J�����ܼ� staConfigTbl ����,
 *&D&   �����N�Ѩ�� GetCnfValue() �Ѧ�,
 *&D&   �䤤,
 *&D&        �C�ӰѼƦb staConfigTbl ������ 2 �����,
 *&D&        �ѼƦW�ٶ�J staConfigTbl ������ caName ��,
 *&D&        �Ѽƭȶ�J staConfigTbl ������ iValue ��,
 *&D&
 *&D&   �U�C���Τ��@,�|�Ϧ���ư��楢��
 *&D&       1. �L�k�}�� config.dat ��
 *&D&       2. config.dat �ɤ����t�ΰѼƭӼƶW�X�̤j����
 *&D&          (�Ѧұ`�� MAX_PARA_NO ����)
 *&D&       3. �t�ΰѼƦW�٤����׶W�X�̤j����
 *&D&          (�Ѧұ`�� MAX_PARA_NAME_LEN ����)
 */
/* TCC: 1997/03/17 */
int
InitCnfTbl(char *pcaFile)
{
  FILE *fpConfig;
  int  i=0, j=0, iVal, iRc;
  char caName[256], caBuf[256], *pcaToken;

  fpConfig = fopen (pcaFile, "r");
  if (fpConfig == NULL)
  {
    printf ("Failure to open [%s] (errno:%d)\n", pcaFile, errno);
    return (INITCNFTBL_OPEN_ERR);
  }

  memset (caBuf, 0, sizeof(caBuf));
  fgets (caBuf, sizeof (caBuf), fpConfig);

  do
  {
     for (j=0; j<sizeof(caBuf); j++)
     if (caBuf[j] == '\n')
     {
       caBuf[j] = 0;
       break;
     }

     memset (staConfigTbl[i].caName, 0, sizeof(staConfigTbl[i].caName));
     pcaToken = (char *)strtok (caBuf, " \t\n");

     if (pcaToken != NULL && pcaToken[0] != '#')
     {
        errno = 0;
        if (sizeof(staConfigTbl[i].caName) <= strlen (pcaToken))
        {
          sprintf (g_caMsg, 
            "<EMS> Illegal parameter(%s) in config.dat.(errno:%d)",
            pcaToken, errno);
          printf ("%s\n", g_caMsg);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          fclose (fpConfig);
          return (CONFIG_ENTRY_ERR);
        }
        memcpy (staConfigTbl [i].caName, pcaToken, strlen(pcaToken));

        pcaToken = (char *)strtok (NULL, " \t\n");

        if (pcaToken == NULL)
        {
          sprintf (g_caMsg, 
            "<EMS> Illegal parameter(%s) in config.dat.(errno:%d)",
            pcaToken, errno);
          printf ("%s\n", g_caMsg);
          ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
          fclose (fpConfig);
          return (CONFIG_ENTRY_ERR);
        }
        else
        {
          iRc = StrToInt (pcaToken, &iVal);
          if (iRc < 0)
          {
            sprintf (g_caMsg,
              "<EMS> Illegal parameter(%s) in config.dat.(errno:%d)\n",
              pcaToken, errno);
            printf ("%s\n", g_caMsg);
            ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
            fclose (fpConfig);
            return (CONFIG_ENTRY_ERR);
          }
        }
        staConfigTbl[i].iValue = iVal;
     }

     i++;
     fgets (caBuf, sizeof (caBuf), fpConfig);
   } while (!feof(fpConfig));

   sg_iTotalParaNo = i;
   fclose (fpConfig);
   return (0);
}


/*
 *&N& ROUTINE NAME: GetCnfValue()
 *&A& ARGUMENTS:
 *&A&     NAME          TYPE                        DESCRIPTION
 *&A&   --------------------------------------------------------------------
 *&A&     pcName        char *               config.dat �ɤ����t�ΰѼƦW��
 *&A&
 *&R& RETURN VALUE(S):
 *&R&   ����ƭY���榨�\,�h�Ǧ^ config.dat �ɤ��Өt�ΰѼƦW�٩ҹ������t�ΰѼƭ�
 *&R&   �Y���楢��,�h�Ǧ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D&   config.dat �ɤ����t�ΰѼƦW�٤ι������Ȥw�z�L��� InitCnfTbl()
 *&D&   ��J�����ܼ� staConfigTbl ����, ��� GetCnfValue() ��ڤW�O��
 *&D&   staConfigTbl �������o�ѼƤ���,
 *&D&   �U�C���Τ��@,�|�Ϧ���ư��楢��
 *&D&       1. �Өt�ΰѼƤ��s�b
 *&D&       2. staConfigTbl ���w�F�̤j����,�ӸӨt�ΰѼƤ��b����
 */

int
GetCnfValue( pcName )
char *pcName;
{
  int i;

  UCP_TRACE( P_GetCnfValue );

  for (i = 0; i < sg_iTotalParaNo; i ++) {
    if (strcmp( pcName, staConfigTbl[ i ].caName ) == 0) {
      UCP_TRACE_END( staConfigTbl[ i ].iValue );
    }
  }

  if (i == sg_iTotalParaNo) {
    sprintf( g_caMsg, "<COM> Unable to find [%s] in config table!", pcName );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( GET_CNF_VALUE_ERR, g_caMsg );
    UCP_TRACE_END( GET_CNF_VALUE_ERR );
  }
}


/* TCC: 1997/03/17 */
StrToInt (char *pcaVal, int *iVal)
{
  int  m, n, i, len, base;
  char caBuf[80];

  memset (caBuf, 0, sizeof(caBuf));
  if (strncmp(pcaVal, "0x", 2) == 0)
  {
     strcpy (caBuf, &pcaVal[2]);
     base = 16;
  }
  else
  {
     strcpy (caBuf, pcaVal);
     base = 10;
  }

  len = strlen(caBuf);
  for (i=len-1, n=0; i>=0; i--)
  {
    m = ctoi (base, caBuf[i]);
    if (m < 0)
    {
      /*
      printf ("Illegal character caBuf[%d]=%c!\n", i, caBuf[i]);
      */
      return (-1);
    }
    n = n + (m*((int)my_power(base, len-i-1))); 
  }

  *iVal = n;
  return (0);
}


/* TCC: 1997/03/17 */
ctoi (int base, char ch)
{
  int n;
  
  
  if (isdigit(ch) != 0)
  {
    return (ch - '0'); 
  }  

  if (isxdigit(ch) != 0)
  {
    if (base == 16)
       return (tolower(ch) - 'a' + 10);
  }

  return (-1);
}


/* TCC: 1997/03/17 */
my_power (int base, int n)
{
  int i, iVal;

  if (n == 0)
     return (1);

  iVal = 1;
  for (i=0; i<n; i++)
    iVal *= base;    

  return (iVal);
}
