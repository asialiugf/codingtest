#include <errno.h>
#include "errlog.h"
#define P_GetDevHostName      600

#ifdef AIX_UNIX
int
GetDevHostName(pcaDname)
char  *pcaDname;
{
   char caBuff[80];
   FILE *zFp;
   int  i;
   static char caTmp[]={"who am i | cut -d'(' -f2 > "};
   char caTmpFile[20];
   char caTmpCmd[50];
   extern int itoa();

   UCP_TRACE(P_GetDevHostName);
   memset(caTmpFile,'\0',20);
   strcpy(caTmpFile,"./tmp");
   itoa(getpid(),&caTmpFile[5]);
   strcpy(caTmpCmd,caTmp);
   strcat(caTmpCmd,caTmpFile);
   system(caTmpCmd);
   if ( (zFp=fopen(caTmpFile,"r")) == NULL ) {
      printf("open tmp file error errno=%d !\n",errno);
      UCP_TRACE_END(-1);
   }
   if ( fgets(caBuff,80,zFp) == NULL ) {
      fclose(zFp);
      printf("no data error errno=%d !\n",errno);
      UCP_TRACE_END(-1);
   }
   fclose(zFp);
   unlink(caTmpFile);
   for (i=0;i<(int)strlen(caBuff);i++) {
     if (caBuff[i] == ')') {
       caBuff[i]='\0';
       break;
     }
   }
   if ( (int)strlen(caBuff) > 10 ) {
    strcpy(pcaDname,ttyname(0)+5);
   }
   else {
    strcpy(pcaDname, caBuff);
   }

   UCP_TRACE_END(0);
}
#endif


/*#ifdef AT_AND_T_SVR4*/
#if defined(AT_AND_T_SVR4) || defined(TANDEM_UNIX) || defined(NEC_UNIX)
#include	"utmpx.h"
#include	"time.h"

GetDevHostName(char *pcName)
{
  struct utmpx user,*pstUser;
  char   caBuf[30];
  int    i;
  int    iFlag;

  iFlag = 1;
/*
  for (i=0;i<sizeof(user.ut_line); i++)
      user.ut_line[i] = 0;
*/
  strcpy(pcName,ttyname(0)+5);

  while(iFlag){
      pstUser = getutxent();
/*
      cftime(caBuf,"%m-%d-%Y %H:%M:S",&pstUser->ut_tv.tv_sec);	
      printf("uname:[%10s],tname:[%s],address:[%13s],time=[%s]\n",
             pstUser->ut_name,pstUser->ut_line,pstUser->ut_host,caBuf);
*/
      if (strcmp(pcName,pstUser->ut_line) == 0){
          if ((strlen(pstUser->ut_host) <= 10) && 
              (strlen(pstUser->ut_host) > 0)){
              strcpy(pcName,pstUser->ut_host);
          }
/*
          printf("ttyname/hostname:[%s/%s=%s]\n",pstUser->ut_line,
                  pstUser->ut_host, pcName);
*/
          sprintf(g_caMsg,"get_dev_host_name:ttyname/hostname:[%s/%s=%s]",
                  pstUser->ut_line,pstUser->ut_host,pcName);
          ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
          break;
      }
      if((int)pstUser) iFlag = 1;else iFlag = 0;
  }
}
#endif
