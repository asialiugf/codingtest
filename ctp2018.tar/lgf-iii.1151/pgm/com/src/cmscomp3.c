/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include   <stdio.h>
/* -------------------- CONSTANT  DEFINE   ------------------------- */
#define P_PackData         201
#define P_UnpackData       202
#define P_Comp3Conv        203

#define HIGH_NIBBLE_MASK   0xf0
#define LOW_NIBBLE_MASK    0x0f

/*
 *&N& ROUTINE NAME: PackData()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE        DESCRIPTION
 *&A& ------------  -----------   ---------------------------------------
 *&A& pcUnpackList  char *        ���Vunpack string������
 *&A& iNumByte      char *        unpack string ������
 *&A&
 *&R& RETURN VALUE(S):
 *&R& caPackList  : ���Vpacked data������
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& �N���׬�iNumByte�� unpack data �ഫ��COMP-3�榡��data
 *&D&
 */
char *PackData(char *pcUnpackList,int iNumByte)
{
  int  i,j;
  static char caPackList[40] ;
  char cHighNibe;
  char caUnpackData[80] ;

  if (iNumByte % 2) {
      memcpy(caUnpackData+1,pcUnpackList,iNumByte) ;
      caUnpackData[0] = '0' ;
      iNumByte ++ ;       /* iNumByte is always even boundary.      */
  }
  else
      memcpy(caUnpackData,pcUnpackList,iNumByte) ;

  for (i = j = 0 ; i < iNumByte ; j++) {
      if (i%2)
          caPackList[j/2] = (caUnpackData[i++] - '0') + cHighNibe ;
      else
          cHighNibe = ((caUnpackData[i++] - '0') << 4) & HIGH_NIBBLE_MASK ;
  }

  caPackList[j/2] = '\0' ;
  return(caPackList)     ;
}



/*
 *&N& ROUTINE NAME: UnpackData()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE       DESCRIPTION
 *&A& -----------  -----------   -----------------------------------------
 *&A& pcPackList   char *        ���VCOMP-3��data����
 *&A& iNumByte     int           ���NCOMP-3��data�নiNumByte��unpack data
 *&A&
 *&R& RETURN VALUE(S):
 *&R& char *     : ����ư��榨�\,�h�Ǧ^���V unpack data�����СC
 *&D&
 *&D& DESCRIPTION:
 *&D&
 *&D& �NCOMP-3�榡��data�ഫ�����׬�iNumByte�� unpack string
 *&D&
 */
char *UnpackData(char *pcPackList,int iNumByte)
{
  int     i , j ;
  static char    caUnpackList[80] ;

  for (i = j = 0 ; j < iNumByte ; i++) {
      if (j%2)
          caUnpackList[j++] = (pcPackList[i/2] & LOW_NIBBLE_MASK) + '0' ;
      else
          caUnpackList[j++] =((pcPackList[i/2] >> 4) & LOW_NIBBLE_MASK) + '0' ;
  }

  caUnpackList[j] = '\0' ;
  return(caUnpackList)   ;
}

/*
 *&N& ROUTINE NAME: Comp3Conv()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE       DESCRIPTION
 *&A& -----------  -----------   ----------------------------------------
 *&A& pcComp3Conv  char *        ���V "+1255..." �� "-144..." �� "24..."
 *&A&                            �r�ꪺ���СC
 *&R& RETURN VALUE(S):
 *&R&   char *  : ����ư��榨�\,�h�Ǧ^���V packed data�����СC
 *&R&   NULL    : �pdata check �o�{���~,�h�Ǧ^NULL�C
 *&D&
 *&D& DESCRIPTION:
 *&D& 1. ���N�o�ئr���Ʀp:"+1255"�B"-144"�B"24"�ഫ��"1255+"�B"144-"�B"24+"
 *&D&    �ഫ�L�{�����D�@data check���ʧ@�C
 *&D& 2. �A�I�sPackData(),�N"1255+"�B"144-"�B"24+"�r��pack�_�� �C
 */
char *Comp3Conv(char *pcComp3Data)
{
  int   i, j;
  int   iPackLen;
  char  cChar;
  char  cSign;
  char  caPackDataStr[400];

  i = j = 0;
  cChar = pcComp3Data[i];

  if  (cChar == '+' || cChar == '-') {
      if  (cChar == '+')
          cSign = '0' + 0x0c;
      else
          cSign = '0' + 0x0d;
      i++;
  }
  else
      cSign = '0' + 0x0c;

  while ( cChar = pcComp3Data[i++] )  {
      if  (cChar >= '0' && cChar <= '9' || cChar == '.') {
          if  (cChar != '.')
              caPackDataStr[j++] = cChar;
      }
      else {
        return(NULL);
      }
  }

  caPackDataStr[ j++ ] = cSign;
  caPackDataStr[ j   ] = '\0';
  iPackLen = j / 2 + j % 2;
  return( PackData( caPackDataStr, j ) );
}
