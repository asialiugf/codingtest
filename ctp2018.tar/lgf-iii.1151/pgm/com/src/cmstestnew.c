#include <errno.h>
/*----------------------- for testing ----------------------------- */
/* ------------------- define in testing program -------------------------- */
/*
int iDataNo;                            /x who many data input per record x/
char caDataType[MAX_TEST_DATA_NO];      /x what kind data type is per input x/
                                        /x data x/
long *plDataVar[MAX_TEST_DATA_NO];      /x point to variable address of per x/
                                        /x input data x/
*/
/*----------------------- for testing ----------------------------- */
#include <stdio.h>
#include <string.h>
#include <fcntl.h>

#define MAX_DATA_LEN    256

#define P_TestInit      01001
#define P_TestEnd       01002
#define P_GetTestData   01003
#define P_TstLog        01004

/*----------------------- for testing ----------------------------- */
static FILE *g_pfFin;   /* input file for testing */
static FILE *g_pfFout;  /* output file for testing */

/*----------------------- for testing ----------------------------- */
int TestInit(char *pcInputFile,char *pcOutputFile);
int GetTestData(int iDataNo,char caDataType[], long* plDataVar[]);
void TestEnd();
int TstLog(char *OutputMsg);

int
TestInit(char *pcInputFile,char *pcOutputFile)
{

  if(strlen(pcInputFile) > 0){
    g_pfFin = fopen(pcInputFile,"rt");
    if( g_pfFin == NULL) {
      printf("Open In File = %s error,errno=%d\n",pcInputFile,errno);
      return(-1);
    }
  }

  if(strlen(pcOutputFile) > 0){
    g_pfFout = fopen(pcOutputFile,"w+t");
    if(g_pfFout == NULL) {
      printf("Open Out File = %s error,errno=%d\n",pcOutputFile,errno);
      return(-1);
    }
  }

  return(0);

}

int
GetTestData(int iDataNo,char caDataType[], long* plDataVar[])
{
  int i;
  long lOffset;
  char caDataBuf[MAX_DATA_LEN];
  char cBypass,cDummy;


  do {
    if(feof(g_pfFin)){
      return(-1);
    }

    fgets(caDataBuf,MAX_DATA_LEN,g_pfFin);
    if (caDataBuf[0] == '#') {
 /*     fprintf(g_pfFout,"%s",caDataBuf);    */
    }
    else {
      lOffset = (long) strlen(caDataBuf) * -1;
      fseek(g_pfFin,lOffset,SEEK_CUR);
      for(i=0; i < iDataNo ; i++){
        fscanf(g_pfFin,"%c",&cBypass);
        if( cBypass != '*') {
          fseek(g_pfFin,-1,SEEK_CUR);
          switch(caDataType[i]){
            case 't' :
              if(i == (iDataNo-1)) {
                fscanf(g_pfFin,"%d\n",(short *) plDataVar[i]);
              }
              else {
                fscanf(g_pfFin,"%d ",(short *) plDataVar[i]);
              }

       /*       fprintf(g_pfFout,"%d ",(short) *plDataVar[i]);  */
              break;
            case 'd' :
              if(i == (iDataNo-1)) {
                fscanf(g_pfFin,"%d\n",(int *) plDataVar[i]);
              }
              else {
                fscanf(g_pfFin,"%d ",(int *) plDataVar[i]);
              }
       /*       fprintf(g_pfFout,"%d ",(int) *plDataVar[i]); */
              break;
            case 'D' :
              if(i == (iDataNo-1)) {
                fscanf(g_pfFin,"%ld\n",(long *) plDataVar[i]);
              }
              else {
                fscanf(g_pfFin,"%ld ",(long *) plDataVar[i]);
              }
       /*       fprintf(g_pfFout,"%ld ",(long) *plDataVar[i]); */
              break;
            case 'o' :
              if(i == (iDataNo-1)) {
                fscanf(g_pfFin,"%o\n",(int *)plDataVar[i]);
              }
              else {
                fscanf(g_pfFin,"%o ",(int *)plDataVar[i]);
              }
       /*       fprintf(g_pfFout,"%o ",(int) *plDataVar[i]); */
              break;
            case 'O' :
              if(i == (iDataNo-1)) {
                fscanf(g_pfFin,"%lo\n",(long *)plDataVar[i]);
              }
              else {
                fscanf(g_pfFin,"%lo ",(long *)plDataVar[i]);
              }
       /*       fprintf(g_pfFout,"%lo ",(long) *plDataVar[i]); */
              break;
            case 'x' :
              if(i == (iDataNo-1)) {
                fscanf(g_pfFin,"%x\n",(int *)plDataVar[i]);
              }
              else {
                fscanf(g_pfFin,"%x ",(int *)plDataVar[i]);
              }
       /*       fprintf(g_pfFout,"%x ",(int) *plDataVar[i]); */
              break;
            case 'X' :
              if(i == (iDataNo-1)) {
                fscanf(g_pfFin,"%lx\n",(long *)plDataVar[i]);
              }
              else {
                fscanf(g_pfFin,"%lx ",(long *)plDataVar[i]);
              }
       /*       fprintf(g_pfFout,"%lx ",(long) *plDataVar[i]);  */
              break;
            case 'i' :
              if(i == (iDataNo-1)) {
                fscanf(g_pfFin,"%i\n",(int *)plDataVar[i]);
              }
              else {
                fscanf(g_pfFin,"%i ",(int *)plDataVar[i]);
              }
       /*       fprintf(g_pfFout,"%i ",(int) *plDataVar[i]);  */
              break;
            case 'I' :
              if(i == (iDataNo-1)) {
                fscanf(g_pfFin,"%li\n",(long *)plDataVar[i]);
              }
              else {
                fscanf(g_pfFin,"%li ",(long *)plDataVar[i]);
              }
       /*       fprintf(g_pfFout,"%li ",(long) *plDataVar[i]); */
              break;
            case 's' :
              if(i == (iDataNo-1)) {
                fscanf(g_pfFin,"%s\n",(char *)plDataVar[i]);
              }
              else {
                fscanf(g_pfFin,"%s ",(char *)plDataVar[i]);
              }
       /*       fprintf(g_pfFout,"%s ",(char *)plDataVar[i]); */
              break;
            case 'c' :
              if(i == (iDataNo-1)) {
                fscanf(g_pfFin,"%c\n",(char *)plDataVar[i]);
              }
              else {
                fscanf(g_pfFin,"%c ",(char *)plDataVar[i]);
              }
       /*       fprintf(g_pfFout,"%c ",(char) *plDataVar[i]); */
              break;
            default :
              fprintf(g_pfFout,"Undefined data type = %c\n", caDataType[i]);
              return(-2);
          }  /* end switch */
        }
        else {
          if( (i == iDataNo-1) && (cDummy == '\n') ) {
            fscanf(g_pfFin,"\n");
            return(0);
          }
          else fscanf(g_pfFin," ");
        } /* end if '*' */
      }  /* end for */
    }  /* end if  '#' */
  } while(caDataBuf[0] == '#');

 /* fprintf(g_pfFout,"\n"); */
  return(0);

}

void
TestEnd()
{
  fclose(g_pfFin);
  fclose(g_pfFout);
}

int
TstLog(char *pcOutputMsg)
{
  fprintf(g_pfFout,pcOutputMsg);
  fflush(g_pfFout);
  return(0);
}
/*----------------------- for testing ----------------------------- */
