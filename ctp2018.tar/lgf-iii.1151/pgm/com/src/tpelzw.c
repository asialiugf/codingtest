#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include  "errlog.h"
/*
#include <sys/times.h>
#include <unistd.h>
*/

#define TRUE                       1
#define FALSE                      0
#define OUTPUT_BUFF_FULL          -1
#define INVALID_INPUT_LEN         -2
#define COMPRESS_SUCCESS           0
#define MAX_DIC_SIZE            4096
#define EMPTY                     -1

typedef unsigned char byte;
typedef struct
{
  int  prefix;
  byte character;
} NEW_STRING;
typedef NEW_STRING DICTIONARY[MAX_DIC_SIZE];

NEW_STRING NS;
DICTIONARY DIC;

int    iEncodeLen=0;
int    iDecodeLen=0;
int    iCodeLen=0;
int    iBuffFullFlag=0;
int    iMaxOutLen;

long   tmp_buf;
int    DIC_last_position;
byte   buffered_bits=0;

LZW_encode(char *pcInData,int iInDataLen,char *pcOutDataBuff,int *piOutDataLen)
{
  int   i;
  int   RM;
  byte  NC;

  /*   For  Time  Test   */
  /*
  struct tms    tmsstart,tmsend;
  static long   clktck;
  clock_t       start,end;
  start = times(&tmsstart);
  */

  ErrLog(10,"INPUT=",RPT_TO_LOG,pcInData,iInDataLen);

  if (iInDataLen <= 0) {
    return INVALID_INPUT_LEN;
  }

  init_DIC();
  RM = EMPTY;
  iMaxOutLen = *piOutDataLen;

  for (i=0;i<iInDataLen;i++)
  {
    NC = pcInData[i];
    NS.prefix    = RM;
    NS.character = NC;
    RM = DIC_position(NS);

    if (RM < 0) {
      put_code(NS.prefix,pcOutDataBuff);

      if (iEncodeLen > iMaxOutLen) {
        return OUTPUT_BUFF_FULL;
      }

      RM = (int)NS.character;
      if (!DIC_is_full())
        insert_to_DIC(NS);
    }
  }
  put_code(RM,pcOutDataBuff);

  if (iEncodeLen > iMaxOutLen) {
    return OUTPUT_BUFF_FULL;
  }

  if (buffered_bits == 4) {
    pcOutDataBuff[iEncodeLen++]=(byte)tmp_buf;
  }

  /*   For  Time  Test   */
  /*
  end = times(&tmsend);
  clktck = sysconf(_SC_CLK_TCK);
  printf("\n\nRun time : %7.2f\n\n",(end-start) / (double) clktck);
  */

  *piOutDataLen = iEncodeLen;
  return COMPRESS_SUCCESS;
}


LZW_decode(char *pcInData,int iInDataLen,char *pcOutDataBuff,int *piOutDataLen)
{
  int    NC;
  int    RM;

  /*   For  Time  Test   */
  /*
  struct tms    tmsstart,tmsend;
  static long   clktck;
  clock_t       start,end;
  start = times(&tmsstart);
  */

  if (iInDataLen <= 0) {
    return INVALID_INPUT_LEN;
  }

  init_DIC();
  iMaxOutLen = *piOutDataLen;
  NC = get_code(pcInData);
  put_char(NC,pcOutDataBuff);

  if (iDecodeLen > iMaxOutLen) {
    return OUTPUT_BUFF_FULL;
  }

  RM = NC;
  NC = get_code(pcInData);

  while ( iCodeLen < iInDataLen ) {

    NS.prefix    = RM;

    if (NC <= DIC_last_position)
      NS.character = first_char(NC);
    else
      NS.character = first_char(RM);

    if (iBuffFullFlag == OUTPUT_BUFF_FULL) {
      return OUTPUT_BUFF_FULL;
    }

    if (!DIC_is_full())
      insert_to_DIC(NS);
    put_char(NC,pcOutDataBuff);

    if (iDecodeLen > iMaxOutLen) {
      return OUTPUT_BUFF_FULL;
    }

    RM = NC;
    NC = get_code(pcInData);

  }

  NS.prefix    = RM;

  if (NC <= DIC_last_position)
    NS.character = first_char(NC);
  else
    NS.character = first_char(RM);

  if (iBuffFullFlag == OUTPUT_BUFF_FULL) {
    return OUTPUT_BUFF_FULL;
  }

  if (!DIC_is_full())
    insert_to_DIC(NS);
  put_char(NC,pcOutDataBuff);

  if (iDecodeLen > iMaxOutLen) {
    return OUTPUT_BUFF_FULL;
  }

  /*   For  Time  Test   */
  /*
  end = times(&tmsend);
  clktck = sysconf(_SC_CLK_TCK);
  printf("\n\nRun time : %7.2f\n\n",(end-start) / (double) clktck);
  */

  *piOutDataLen = iDecodeLen;
  return COMPRESS_SUCCESS;
}


init_DIC(void)
{
  int i;

  for (i=0; i<=255; i++) {
    DIC[i].prefix = EMPTY;
    DIC[i].character = i;
  }

  DIC_last_position = 255;
  iEncodeLen=0;
  iDecodeLen=0;
  iCodeLen=0;
  iBuffFullFlag=0;
  buffered_bits=0;
  tmp_buf=0;
}


int get_code(char *pcCodeBuff)
{
  static unsigned int   tmp_buf;
  /*static byte           buffered_bits=0;*/
  int                   code;
  code=(byte)pcCodeBuff[iCodeLen++];

  if (buffered_bits == 0) {
    tmp_buf       = code | ((byte)pcCodeBuff[iCodeLen++] << 8);
    code          = tmp_buf & 0x0FFF;
    tmp_buf       = tmp_buf >> 12;
    buffered_bits = 4;
  }

  else {
    code          = (code << 4) | tmp_buf;
    buffered_bits = 0;
  }
  return code;
}


put_char(int code,char *pcDeCode)
{
  byte buf[MAX_DIC_SIZE];
  int  recno=0, i;
  buf[recno++] = DIC[code].character;

  while (DIC[code].prefix != EMPTY) {
    code = DIC[code].prefix;
    buf[recno++] = DIC[code].character;
  }

  for (i=recno-1; i>=0; i--) {
    pcDeCode[iDecodeLen++]=buf[i];
  }
}


first_char(int code)
{
  int i=0;
  while (DIC[code].prefix != EMPTY) {
    code = DIC[code].prefix;
    i++;
    if (i > (iMaxOutLen-iDecodeLen)) {
      iBuffFullFlag = OUTPUT_BUFF_FULL;
      return OUTPUT_BUFF_FULL;
    }
  }
  return DIC[code].character;
}


int DIC_position(NEW_STRING NS)
{
  int i;

  for (i=0; i<=DIC_last_position; i++)
    if ((NS.prefix == DIC[i].prefix) && (NS.character == DIC[i].character))
      return i;
  return -1;
}


int DIC_is_full(void)
{
  if (DIC_last_position == MAX_DIC_SIZE-1)
    return TRUE;
  else
    return FALSE;
}

insert_to_DIC(NEW_STRING NS)
{
  DIC_last_position++;
  DIC[DIC_last_position].prefix = NS.prefix;
  DIC[DIC_last_position].character = NS.character;
}

put_code(int code,char *pcEnCode)
{
  tmp_buf       = tmp_buf | ((long)code << buffered_bits);
  buffered_bits = buffered_bits + 12;

  while (buffered_bits >= 8) {
    pcEnCode[iEncodeLen++]=(byte)tmp_buf;
    tmp_buf       = tmp_buf >> 8;
    buffered_bits = buffered_bits - 8;
  }
}

