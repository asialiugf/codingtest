/*
 *&N& File : cmsighdl.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int       SignlHdl()            �T���]�w�P�B�z
 *&N&    int       SigHandler()           �T���B�z�`��
 */

/* ------------------------- INCLUDE FILES ---------------------------- */
#include <signal.h>
#include "errlog.h"

/* ------------------------- CONSTANT DEFINITION ---------------------- */
#define P_AbendRtn 		701
#define P_SigHandler 		702
#define P_SignlHdl 		703
/* ------------------------- VARIABLE DECLARATION --------------------- */
int iaSignal[] = {
                   SIGHUP,
                   SIGINT,
                   SIGQUIT,
                   SIGILL,
                   SIGTRAP,
                   SIGEMT,
                   SIGFPE,
                   SIGKILL,
                   SIGBUS,
                   SIGSEGV,
                   SIGSYS,
                   SIGPIPE,
                   SIGALRM,
                   SIGTERM,
/*
                   SIGCLD,
*/
                   SIGPWR
                 };

/*
 *&N& ROUTINE NAME: SignlHdl()
 *&A& ARGUMENTS:
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&   �T���]�w�P�B�z
 */

int
SignlHdl()
{
  int iSignalCnt;
  int i;
  void SigHandler();

  UCP_TRACE( P_SignlHdl );

  iSignalCnt = sizeof( iaSignal ) / sizeof( int );

  for (i = 0; i < iSignalCnt; i ++) {
    signal( iaSignal[ i ], SigHandler );
  }

  UCP_TRACE_END( 0 );
}

/*
 *&N& ROUTINE NAME: SigHandler()
 *&A& ARGUMENTS:
 *&A&     NAME          TYPE                        DESCRIPTION
 *&A&   ----------------------------------------------------------
 *&A&    iSigNo         int                         �T�����X
 *&A&
 *&R& RETURN VALUE(S):
 *&R&
 *&D& DESCRIPTION:
 *&D&   �T���B�z�`��:
 *&D&   1.�O������t�Ϊ����ӰT������~�O����.
 *&D&   2.�I�s���`�B�z�����}�{��.
 */

void
SigHandler( iSigNo )
int iSigNo;
{
  switch( iSigNo ) {
    case SIGHUP:
         ErrLog(99901,"signal SIGHUP occured",RPT_TO_LOG | RPT_TO_TTY,0,0);
         break;
    case SIGINT:
         ErrLog(99902,"signal SIGINT occured",RPT_TO_LOG | RPT_TO_TTY,0,0);
         break;
    case SIGQUIT:
         ErrLog(99903,"signal SIGQUIT occured",RPT_TO_LOG | RPT_TO_TTY,0,0);
         break;
    case SIGILL:
         ErrLog(99904,"signal SIGILL occured",RPT_TO_LOG | RPT_TO_TTY,0,0);
         break;
    case SIGTRAP:
         ErrLog(99905,"signal SIGTRAP occured",RPT_TO_LOG | RPT_TO_TTY,0,0);
         break;
    case SIGABRT:
         ErrLog(99906,"signal SIGABRT occured",RPT_TO_LOG | RPT_TO_TTY,0,0);
         break;
    case SIGEMT:
         ErrLog(99907,"signal SIGEMT occured",RPT_TO_LOG | RPT_TO_TTY,0,0);
         break;
    case SIGKILL:
         ErrLog(99908,"signal SIGKILL occured",RPT_TO_LOG | RPT_TO_TTY,0,0);
         break;
    case SIGFPE:
         ErrLog(99910,"signal SIGFPE occured",RPT_TO_LOG | RPT_TO_TTY,0,0);
         break;
    case SIGBUS:
         ErrLog(99911,"signal SIGBUS occured",RPT_TO_LOG | RPT_TO_TTY,0,0);
         break;
    case SIGSEGV:
         ErrLog(99912,"signal SIGSEGV occured",RPT_TO_LOG | RPT_TO_TTY,0,0);
         break;
    case SIGSYS:
         ErrLog(99913,"signal SIGSYS occured",RPT_TO_LOG | RPT_TO_TTY,0,0);
         break;
    case SIGPIPE:
         ErrLog(99914,"signal SIGPIPE occured",RPT_TO_LOG | RPT_TO_TTY,0,0);
         break;
    case SIGALRM:
         ErrLog(99915,"signal SIGALRM occured",RPT_TO_LOG | RPT_TO_TTY,0,0);
         break;
    case SIGTERM:
         ErrLog(99916,"signal SIGTERM occured",RPT_TO_LOG | RPT_TO_TTY,0,0);
         break;
    case SIGCLD:
         ErrLog(99917,"signal SIGCLD occured",RPT_TO_LOG | RPT_TO_TTY,0,0);
         break;
    case SIGPWR:
         ErrLog(99918,"signal SIGPWR occured",RPT_TO_LOG | RPT_TO_TTY,0,0);
         break;
  }

  exit( iSigNo );
}

/*
 *&N& ROUTINE NAME:AbendRtn()
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                 DESCRIPTION
 *&A& ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0	: ����ư��榨�\
 *&R&   -1	: ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&   1.restore the terminal control data.
 *&D&   2.��ܲ��`���~���T��, ���}�{��.
 *&D&
 */

void
AbendRtn()
{
  printf("in ABEND ROUTINE \n");
  printf("in ABEND ROUTINE \n");
  printf("in ABEND ROUTINE \n");
  exit(1);
}
