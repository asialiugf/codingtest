CnvInOutNull()
{
}
