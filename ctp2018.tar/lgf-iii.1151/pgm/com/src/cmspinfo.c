#include <stdio.h>

#define PRODNAME	"Transactions Processing Environment (TPE/UNIX)/1151"
#define PRODVERNO	"Release 1.1.5.4p"

char *UtlPordName ();
char *UtlPordVerId ();

char *UtlProdName ()
{
    return (PRODNAME);
}

char *UtlProdVerId ()
{
    return (PRODVERNO);
}
