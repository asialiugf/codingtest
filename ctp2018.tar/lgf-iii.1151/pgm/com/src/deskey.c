DesKeyNullFunc()
{
}

#ifdef DESKEY
int
DESINIT(char *caRc)
{
    memcpy(caRc, "00", 2);
/*    caRc[2] = 0;  Mark Long 980901 for tu980515*/
}

int
DESGETKY(caRc,arg2,arg3,arg4,arg5)
char *caRc, *arg2, *arg3, *arg4, *arg5;
{
    memcpy(caRc, "00", 2);
/*    caRc[2] = 0;  Mark Long 980901 for tu980515*/
}

int
DESCLOSE(char *caRc)
{
    memcpy(caRc, "00", 2);
/*    caRc[2] = 0;  Mark Long 980901 for tu980515*/
}

int
DESLDMKY(char *caRc, char *caRc2)
{
    memcpy(caRc, "00", 2);
/*    caRc[2] = 0;  Mark Long 980901 for tu980515*/
}

int
DESWRIKY(char *caRc, char *caRc2)
{
    memcpy(caRc, "00", 2);
/*    caRc[2] = 0;  Mark Long 980901 for tu980515*/
}

int
DESMACOP(caRc,arg2,arg3,arg4,arg5)
char *caRc, *arg2, *arg3, *arg4, *arg5;
{
    memcpy(caRc, "00", 2);
/*    caRc[2] = 0;  Mark Long 980901 for tu980515*/
}
#endif
