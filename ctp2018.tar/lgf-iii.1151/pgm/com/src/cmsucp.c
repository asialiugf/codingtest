
/* for compatiable OLD UCP source code */
#define     MAX_LEVEL     40
int         SYSMODE;
int         ICT_SHM_KEY;
int         DBT_SHM_KEY;
int         IET_SHM_KEY;
int         CTF_SHM_KEY;
/*int         TEST_MODE=1; */
char        MSG_STR[200];
int         rtn_idx,rtn_errno,rtn_path[MAX_LEVEL];

err_log(err_code,disp_msg,dump_dev,dump_addr,dump_len)
int err_code;
char *disp_msg,dump_dev;
char  *dump_addr;
long   dump_len;
{

ErrLog(err_code,disp_msg,dump_dev,dump_addr,dump_len);

}

/*
SysStart(char *pcErrStep)
{
}

sig_hdl()
{
 SigHdl();
}
*/
