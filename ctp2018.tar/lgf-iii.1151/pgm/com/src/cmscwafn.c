
/*     FUNCTION & SUBROUTINE DESCRIPTION
 *&N&   
 *&N&    TYPE      NAME                 DESCRIPTION
 *&N& --------- ---------- ---------------------------------------- 
 *&N& 01 int    CwaLowCtlFac     �޲z�@�Τu�@��ưϳ]�� LOW LEVEL �D�\��
 *&N& 02 int    CwaCtlFac        �޲z�@�Τu�@��ưϳ]�ƥD�\��
 *&N& 03 int    CreatCwaShm      ���o�@�Τu�@��ư�
 *&N& 04 int    CreatCwaSem      ���o�@�Τu�@��ưϪ��s������X��
 *&N& 05 int    GetCwaId	 �H�_�Ȩ��o�@�u�@��ưϪ��N�X
 *&N& 06 int    RemoveCwa        ����@�Τu�@��ư�
 *&N& 07 int    AttachCwa        �s���@�Τu�@��ư�
 *&N& 08 int    DetachCwa        �����@�Τu�@��ư�
 *&N& 09 int    UnOLockCwa       ����Υ[��@�Τu�@��ư�
 *&N& 10 int    ReadCwa          Ū���@�Τu�@��ư�
 *&N& 11 int    WriteCwa         �g�^�@�Τu�@��ư�
 *&N& 12 int    SchTctIdx        �M��׺ݾ�������檺index
 *&N& 13 int    GetCwaSegPtr     ���o�@�Τu�@��ưϪ����P�Ϭq pointer
 *&N&
 */

/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include <stdio.h>
#include <errno.h>

#include "errlog.h"	/* �O�����~�T���ɨϥΨ쪺�`�Ƥθ�Ƶ��c */
#include "cwa.h"	/* CWA �ҨϥΨ쪺�@�Ǹ�Ƶ��c */

/* tmscwafn.c */
/* tmcwafac.c  */
#define P_AttachCwa 		401
#define P_CreatCwaSem 		402
#define P_CreatCwaShm 		403
#define P_CwaCtlFac 		404
#define P_CwaLowCtlFac 		405
#define P_GetCwaId		406
#define P_DetachCwa 		407
#define P_ReadCwa 		409
#define P_RemoveCwa 		410
#define P_UnOLockCwa 		411
#define P_WriteCwa 		412
#define P_SchTctIdx 		413
#define P_GetCwaSegPtr		414
#define P_GetBrhPtr 		415
#define P_BitOperation 		416	
#define P_GetTermPtr           	417
#define P_GetBrhTmByName       	418

#define  NO_BRH_DATA             -1
#define  NO_TERM_DATA            -2
#define  FUN_CODE_ERR            -3
#define  UNDEFINED_TERM          -4
#define  RD_BIT                  '1'
#define  WR_BIT                  '2'
/* -------------------- STATIC GLOBAL DECLARATION ------------------ */
static struct CWA *sg_pstCWA = NULL;	/* CWA �����ܼ� */
                                        /* initial value is Null */
static int sg_iCwaShmId = -1;	/* CWA share memory id �������ܼ�, */
                                /* initial value is -1 */
static int sg_iCwaSemId = -1;	/* CWA semapgore id �������ܼ�, */
                                /* initial value is -1 */

/* ------ CALL FUNCTION & SUBROUTINE PROTOTYPE DECLARATIONS -------- */
int    CwaLowCtlFac(struct CwaCtl *stCwaCtl, char **pcIoBuf);
int    CwaCtlFac(struct CwaCtl *stCwaCtl, char *pcIoBuf);
int    CreatCwaShm(key_t iShmKey);
int    CreatCwaSem(key_t iSemKey);
int    GetCwaId(key_t iShmKey, key_t iSemKey);
int    RemoveCwa();
int    AttachCwa();
int    DetachCwa();
int    UnOLockCwa(char cSegCode, int UnlockOLock);
int    ReadCwa(char cSegCode, char *pcaTblIdx, char *pcIoBuf);
int    WriteCwa(char cSegCode, char *pcaTblIdx, char *pcIoBuf);
int    GetCwaSegPtr(char cSegCode, char *pcaTblIdx, char **ppcIoBuf);
int    SchTctIdx(char *pcaBrCode, char *pcaTmBuf);

/* TCC: 1996/11/06 */
extern int  errno;
extern char *sys_errlist[];

int  g_iBitSize;

/*
 *&N& ROUTINE NAME: CwaLowCtlFac(struct CwaCtl *stCwaCtl, char **ppcIoBuf)
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                 DESCRIPTION
 *&A& ---------  ---------------------    -------------------------
 *&A& stCwaCtl    struct CwaCtl *	  �s���@�Τu�@��ưϪ������Ʀ�}
 *&A& ppcIoBuf    char **		  ��X/�J���pointer����}
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0 : ����ư��榨�\.
 *&R&    1 : �\���ƿ��~.
 *&R&
 *&D& DESCRIPTION:
 *&D&   1.�P�_�����\��I�s.
 *&D&   2.�N�\��礧�Ǧ^���ন�r�����A; �Ǧ^���I�s���.
 *&D&
 */

int
CwaLowCtlFac(struct CwaCtl *stCwaCtl, char **ppcIoBuf)
{
  int iRc;
  char caTmpBuf[10];

  UCP_TRACE(P_CwaLowCtlFac);
  iRc = 0;

  switch(stCwaCtl->cFunCode){
    case CWA_REMOVE :
      iRc = RemoveCwa();
      break;
    case CWA_ATTACH :
      iRc = AttachCwa();
      break;
    case CWA_DETACH :
      iRc = DetachCwa();
      break;
    case CWA_SEG_LOCK :
      iRc = UnOLockCwa(stCwaCtl->cSegCode,CWA_LOCK);
      break;
    case CWA_SEG_UNLOCK :
      iRc = UnOLockCwa(stCwaCtl->cSegCode,CWA_UNLOCK);
      break;
    case CWA_GET_SEG_PTR :
      iRc = GetCwaSegPtr(stCwaCtl->cSegCode,stCwaCtl->caTblIdx,ppcIoBuf);
      break;
    case CWA_GET_TERM_PTR :
      iRc = GetTermPtr(stCwaCtl->caBrhId,stCwaCtl->caTermId,ppcIoBuf);
      break;
    case CWA_GET_BRH_PTR :
      iRc = GetBrhPtr(stCwaCtl->caBrhId,stCwaCtl->caTermId,ppcIoBuf);
      break;
    default :
      ErrLog(1000,"<COM> Unknown CWA function request!",RPT_TO_LOG,0,0);
      DetErrRpt(CWA_FUNCODE_ERROR, "<COM> Unknown CWA function request!");
      UCP_TRACE_END(CWA_FUNCODE_ERROR);
  } /* end of switch(stCwaCtl->cFunCode) */

  /* if abnormal log error */
  if(iRc != 0){
    sprintf (g_caMsg,"<COM> CWA function [%c] execution error! (iRc)",
             stCwaCtl->cFunCode, iRc);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, stCwaCtl, sizeof(struct CwaCtl));
  } /* end of if(iRc != 0) */
  sprintf(caTmpBuf,"%.3d",abs(iRc));
  memcpy(stCwaCtl->caRtnCode,caTmpBuf,3);
  UCP_TRACE_END(iRc);
} /* end of CwaLowCtlFac(struct CwaCtl *stCwaCtl, char **ppcIoBuf) */

/*
 *&N& ROUTINE NAME: CwaCtlFac(struct CwaCtl *stCwaCtl, char *pcIoBuf)
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                 DESCRIPTION
 *&A& ---------  ---------------------    -------------------------
 *&A& stCwaCtl    struct CwaCtl *	  �s���@�Τu�@��ưϪ������Ʀ�}
 *&A& pcIoBuf    char *			   ��X/�J��ưϪ���}
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0 : ����ư��榨�\.
 *&R&   -1 : �\���ƿ��~.
 *&R&
 *&D& DESCRIPTION:
 *&D&   1.�P�_�����\��I�s.
 *&D&   2.�N�\��礧�Ǧ^���ন�r�����A; �Ǧ^���I�s���.
 *&D&
 */

int
CwaCtlFac(struct CwaCtl *stCwaCtl, char *pcIoBuf)
{
  int iRc;
  struct CwaCreatIobuf *pstCCIobuf;
  char caTmpBuf[10], *pcaBitTbl;

  UCP_TRACE(P_CwaCtlFac);
  iRc = 0;

  switch(stCwaCtl->cFunCode){
    case CWA_CREAT :
      pstCCIobuf = (struct CwaCreatIobuf *)pcIoBuf; 
      iRc = CreatCwaShm(pstCCIobuf->iShmKey);
      /* TCC
      if(iRc == 0 || iRc == -2){
      */
      if (iRc == 0){
        iRc = CreatCwaSem(pstCCIobuf->iSemKey);
      }
      sprintf(caTmpBuf,"%.3d",abs(iRc));
      memcpy(stCwaCtl->caRtnCode,caTmpBuf,3);
      break;
    case CWA_GET_ID :
      pstCCIobuf = (struct CwaCreatIobuf *)pcIoBuf; 
      iRc = GetCwaId(pstCCIobuf->iShmKey,pstCCIobuf->iSemKey);
      sprintf(caTmpBuf,"%.3d",abs(iRc));
      memcpy(stCwaCtl->caRtnCode,caTmpBuf,3);
      if (iRc == 1 || iRc == 2)
         iRc = 0;
      break;
    case CWA_REMOVE :
      iRc = RemoveCwa();
      sprintf(caTmpBuf,"%.3d",abs(iRc));
      memcpy(stCwaCtl->caRtnCode,caTmpBuf,3);
      break;
    case CWA_ATTACH :
      iRc = AttachCwa();

      pcaBitTbl = (char *) sg_pstCWA;
      sg_pstCWA->pcaBitTbl = (char *) (pcaBitTbl + sizeof(struct CWA));
/*
sprintf (g_caMsg,
"<COM> CWA_ATTACH: pcaBitTbl:[0x%p]=pstCWA:[0x%p]+sizeof(struct CWA):[0x%0x]",
         sg_pstCWA->pcaBitTbl, sg_pstCWA, sizeof(struct CWA));
ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
*/
      sprintf(caTmpBuf,"%.3d",abs(iRc));
      memcpy(stCwaCtl->caRtnCode,caTmpBuf,3);
      break;
    case CWA_DETACH :
      iRc = DetachCwa();
      sprintf(caTmpBuf,"%.3d",abs(iRc));
      memcpy(stCwaCtl->caRtnCode,caTmpBuf,3);
      break;
    case CWA_READ :
      iRc = ReadCwa(stCwaCtl->cSegCode,stCwaCtl->caTblIdx,pcIoBuf);
      sprintf(caTmpBuf,"%.3d",abs(iRc));
      memcpy(stCwaCtl->caRtnCode,caTmpBuf,3);
      break;
    case CWA_READ_LOCK :
      iRc = UnOLockCwa(stCwaCtl->cSegCode,CWA_LOCK);
      if(iRc == 0){
        iRc = ReadCwa(stCwaCtl->cSegCode,stCwaCtl->caTblIdx,pcIoBuf);
        if(iRc != 0){
          UnOLockCwa(stCwaCtl->cSegCode,CWA_UNLOCK);
        }
      }
      sprintf(caTmpBuf,"%.3d",abs(iRc));
      memcpy(stCwaCtl->caRtnCode,caTmpBuf,3);
      break;
    case CWA_WRITE :
      iRc = WriteCwa(stCwaCtl->cSegCode,stCwaCtl->caTblIdx,pcIoBuf);
      sprintf(caTmpBuf,"%.3d",abs(iRc));
      memcpy(stCwaCtl->caRtnCode,caTmpBuf,3);
      break;
    case CWA_WRITE_UNLOCK :
      iRc = WriteCwa(stCwaCtl->cSegCode,stCwaCtl->caTblIdx,pcIoBuf);
      UnOLockCwa(stCwaCtl->cSegCode,CWA_UNLOCK);
      sprintf(caTmpBuf,"%.3d",abs(iRc));
      memcpy(stCwaCtl->caRtnCode,caTmpBuf,3);
      break;
    case CWA_SEG_LOCK :
      iRc = UnOLockCwa(stCwaCtl->cSegCode,CWA_LOCK);
      sprintf(caTmpBuf,"%.3d",abs(iRc));
      memcpy(stCwaCtl->caRtnCode,caTmpBuf,3);
      break;
    case CWA_SEG_UNLOCK :
      iRc = UnOLockCwa(stCwaCtl->cSegCode,CWA_UNLOCK);
      sprintf(caTmpBuf,"%.3d",abs(iRc));
      memcpy(stCwaCtl->caRtnCode,caTmpBuf,3);
      break;
    default :
      ErrLog(1000,"<COM> Unknown CWA function request!",RPT_TO_LOG,0,0);
      DetErrRpt(CWA_FUNCODE_ERROR, "<COM> Unknown CWA function request!");
      UCP_TRACE_END(CWA_FUNCODE_ERROR);
  } /* end of switch(stCwaCtl->cFunCode) */

  /* if abnormal log error */
  /*
  if(iRc != 0){
    ErrLog (1000,"<COM> CWA function execution error",
            RPT_TO_LOG, stCwaCtl, sizeof(struct CwaCtl));
  }
  */

  UCP_TRACE_END(iRc);
} /* end of CwaCtlFac(struct CwaCtl *stCwaCtl, char *pcIoBuf) */


/*
 *&N& ROUTINE NAME: CreatCwaShm(key_t iShmKey)
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                 DESCRIPTION
 *&A& ---------  ---------------------    -------------------------
 *&A& iShmKey    key_t			  ���o�t�ΰO���^���_
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0 : ����ư��榨�\
 *&R&   -2 : �@�Τu�@��ưϤw�s�b.
 *&R&   -3 : ���o�t�ΰO���^����.
 *&R&   -4 : �]�w�u�@��ưϱ����v������.
 *&R&
 *&D& DESCRIPTION:
 *&D&  1.�ˬd CWA �O�_�w�g�s�b.
 *&D&  2.���o CWA �t�θ귽.
 *&D&  3.�]�w CWA ���s���v��.
 *&D&
 */

int
CreatCwaShm(key_t iShmKey)
{
  int iRc;
  struct shmid_ds stShmCtl;
  int iCwaSize;

  UCP_TRACE(P_CreatCwaShm);
  /* �ˬd CWA �O�_�w�g�s�b */
  sg_iCwaShmId = shmget(iShmKey, 0, 0660);
  if(sg_iCwaShmId != -1){
     sprintf (g_caMsg, 
              "<COM> Shared memory key [0x%0x] for CWA is in use", iShmKey);
     ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
/* ???
     ErrLog (40000, g_caMsg, RPT_TO_LOG, 0, 0);
*/
     DetErrRpt(CWA_SHM_EXIST_ERROR, g_caMsg);
     UCP_TRACE_END(CWA_SHM_EXIST_ERROR);
  } /* end of if(sg_iCwaShmId != -1) */

  /* ���o CWA �t�θ귽 */
/* TCC 1997/03/21
  sg_iCwaShmId = shmget(iShmKey, sizeof(struct CWA),0660 | IPC_CREAT);
*/
  iCwaSize = sizeof(struct CWA) + g_iBitSize;
/* 
  sprintf (g_caMsg,
           "<COM> CreatCwaShm: iCwaSize:[%d] = [%d] + iBitSize:[%d]",
           iCwaSize, sizeof(struct CWA), g_iBitSize);
  ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
*/
  sg_iCwaShmId = shmget(iShmKey, iCwaSize, 0660 | IPC_CREAT);
  if(sg_iCwaShmId == -1){
    sprintf(g_caMsg,
    "<COM> Failure to get shared memory id with key [0x%0x]! (errno:%d=>%s)",
    iShmKey, errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
/* ???
     ErrLog (40000, g_caMsg, RPT_TO_LOG, 0, 0);
*/
    DetErrRpt(CWA_CREAT_ERROR,g_caMsg);
    UCP_TRACE_END(CWA_CREAT_ERROR);
  } /* end of if(sg_iCwaShmId == -1) */

  /* �]�w CWA ���s���v�� */
  stShmCtl.shm_perm.mode = 000660;
  stShmCtl.shm_perm.uid = getuid();
  stShmCtl.shm_perm.gid = getgid();
  iRc = shmctl(sg_iCwaShmId, IPC_SET, &stShmCtl);
  if(iRc == -1){
    sprintf (g_caMsg,
    "<COM> Failure to create shared memory with id [%d]! (errno:%d=>%s)",
    sg_iCwaShmId, errno, sys_errlist[errno]);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
/* ???
     ErrLog (40000, g_caMsg, RPT_TO_LOG, 0, 0);
*/
    DetErrRpt(CWA_SHMCTL_ERROR,g_caMsg);
    UCP_TRACE_END(CWA_SHMCTL_ERROR);
  } /* end of if(iRc == -1) */
  UCP_TRACE_END(0);
} /* end of CreatCwaShm(key_t iShmKey) */

/*
 *&N& ROUTINE NAME: GetCwaId(key_t iShmKey,key_t iSemKey)
 *&A& ARGUMENTS:
 *&A&   NAME              TYPE                 DESCRIPTION
 *&A& -------------- ----------------------- ----------------------------------
 *&A& iShmKey          key_t                 ���o�t�θ귽�N�X�_
 *&A& iSemKey          key_t                 ���o�t�κX�ХN�X���_
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0 : ����ư��榨�\
 *&R&  -17 : �@�Τu�@��ưϤ��s�b.
 *&R&  -18 : �@�Τu�@��ưϱ���X�Ф��s�b.
 *&R&
 *&D& DESCRIPTION:
 *&D&  1.�ˬd CWA SHM ID �O�_�v�s�b, �Y���s�b, �h���o CWA �t�ΰO���^�귽�N�X.
 *&D&  1.�ˬd CWA SEM ID �O�_�v�s�b, �Y���s�b, �h���o CWA �t�κX�ХN�X.
 *&D&
 */

int
GetCwaId(key_t iShmKey,key_t iSemKey)
{
  UCP_TRACE(P_GetCwaId);
  /* �ˬd CWA SHM ID �O�_�w�g�s�b, ���s�b�h�I�s shmget */

  if(sg_iCwaShmId == -1){
    sg_iCwaShmId = shmget(iShmKey, 0, 0660);
    if(sg_iCwaShmId == -1){
      sprintf(g_caMsg,
      "<COM> Shared memory key [0x%0x] are available to use! (errno:%d=>%s)",
      iShmKey, errno, sys_errlist[errno]);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    } 
    else
    {
      sprintf(g_caMsg,
      "<COM> Shared memory key [0x%0x] for CWA is in use! (errno:%d=>%s)",
      iShmKey, errno, sys_errlist[errno]);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    }
  }

  /* �ˬd CWA SEM ID �O�_�w�g�s�b, ���s�b�h�I�s semget */
  if(sg_iCwaSemId == -1){
    sg_iCwaSemId = semget(iSemKey,0,0);
    if(sg_iCwaSemId == -1){
      sprintf(g_caMsg,
      "<COM> Semaphore key [0x%0x] are available to use! (errno:%d=>%s)",
      iSemKey, errno, sys_errlist[errno]);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    }
    else
    {
      sprintf(g_caMsg,
      "<COM> Semaphore key [0x%0x] for CWA is in use! (errno:%d=>%s)",
      iSemKey, errno, sys_errlist[errno]);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    }
  }

  if (sg_iCwaShmId > 0 && sg_iCwaSemId > 0)
     UCP_TRACE_END (0);

  if (sg_iCwaShmId > 0 && sg_iCwaSemId < 0)
     UCP_TRACE_END (1);

  if (sg_iCwaSemId > 0 && sg_iCwaShmId < 0)
     UCP_TRACE_END (2);

  if (sg_iCwaShmId < 0)
     UCP_TRACE_END (CWA_SHM_NO_BEEN_ERROR);

  if (sg_iCwaSemId < 0)
     UCP_TRACE_END (CWA_SEM_NO_BEEN_ERROR);
}

/*
 *&N& ROUTINE NAME: RemoveCwa()
 *&A& ARGUMENTS:
 *&A& ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0 : ����ư��榨�\
 *&R&   -5 : ����t�ΰO���^����.
 *&R&   -6 : ����t�κX�Х���.
 *&R&
 *&D& DESCRIPTION:
 *&D&  1.����@�Τu�@��ưϰO���^.
 *&D&  2.����s������X��.
 *&D&
 *&D&
 */

int
RemoveCwa()
{
  int iRc;
  struct shmid_ds stShmCtl;
  struct semid_ds stSemCtl;

  UCP_TRACE(P_RemoveCwa);
  /* ����@�Τu�@��ưϰO���^ */
     iRc = shmctl(sg_iCwaShmId, IPC_RMID, &stShmCtl);
     if (iRc == -1){
       sprintf (g_caMsg,
       "<COM> Failure to remove shared memory with id[%d]! (errno:%d=>%s)",
       sg_iCwaShmId, errno, sys_errlist[errno]);
       ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
       sg_iCwaShmId = -1;
       DetErrRpt(CWA_REMOVE_SHM_ERROR,g_caMsg);
       UCP_TRACE_END(CWA_REMOVE_SHM_ERROR);
     }
     sg_iCwaShmId = -1;

  /* ����s������X�� */
     memset(&stSemCtl,'0',sizeof(struct semid_ds));
     iRc = semctl(sg_iCwaSemId,MAX_CWA_NSEMS,IPC_RMID,&stSemCtl);
     if(iRc == -1){
       sprintf (g_caMsg,
       "<COM> Failure to remove semaphore with id[%d]! (errno:%d=>%s)",
       sg_iCwaSemId, errno, sys_errlist[errno]);
       ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
       sg_iCwaSemId = -1;
       DetErrRpt(CWA_REMOVE_SEM_ERROR,g_caMsg);
       UCP_TRACE_END(CWA_REMOVE_SEM_ERROR);
     }
     sg_iCwaSemId = -1;

  UCP_TRACE_END(0);
} /* end of RemoveCwa() */

/*
 *&N& ROUTINE NAME: AttachCwa()
 *&A& ARGUMENTS:
 *&A& ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0 : ����ư��榨�\
 *&R&   -7 : �s���@�Τu�@��ưϥ���.
 *&R&
 *&D& DESCRIPTION: 
 *&D&   1. �ˬd�O�_�v�g�s���F.
 *&D&   2. �s���@�Τu�@��ư�.
 *&D&  
 */

int
AttachCwa()
{
  UCP_TRACE(P_AttachCwa);

  /* �ˬd�O�_�v�g�s���F */
  if(sg_pstCWA == NULL){
    /* �s���@�Τu�@��ư� */
    sg_pstCWA = (struct CWA *)shmat(sg_iCwaShmId,0,0);
    if(sg_pstCWA == NULL){
      sprintf (g_caMsg,
      "<COM> Failure to attach CWA shared memory with id[%d]! (errno:%d=>%s)",
      sg_iCwaShmId, errno, sys_errlist[errno]);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      DetErrRpt(CWA_ATTACH_ERROR,g_caMsg);
      UCP_TRACE_END(CWA_ATTACH_ERROR);
    } /* end of if(sg_pstCWA == NULL) */
  } /* end of if(sg_pstCWA == NULL) */
  UCP_TRACE_END(0);
} /* end of AttachCwa() */

/*
 *&N& ROUTINE NAME: DetachCwa()
 *&A& ARGUMENTS:
 *&A& ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0 : ����ư��榨�\
 *&R&   -8 : �����@�Τu�@��ưϥ���.
 *&R&
 *&D& DESCRIPTION:
 *&D&  1. �����@�Τu�@��ư�.
 *&D&
 */

int
DetachCwa()
{
  int iRc;

  UCP_TRACE(P_DetachCwa);
  iRc = shmdt(sg_pstCWA);
  sg_pstCWA = NULL;
  if(iRc == -1){
    sprintf (g_caMsg, 
             "<COM> Failure to dettach shared memory! (errno:%d=>%s)",
             errno, sys_errlist[errno]);
    ErrLog (1000,g_caMsg,RPT_TO_LOG,0,0);
    DetErrRpt(CWA_DETACH_ERROR,g_caMsg);
    UCP_TRACE_END(CWA_DETACH_ERROR);
  } /* end of if(iRc == -1) */
  UCP_TRACE_END(0);
} /* end of DetachCwa() */

/*
 *&N& ROUTINE NAME: CreatCwaSem(key_t iSemKey)
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                 DESCRIPTION
 *&A& ---------  ---------------------    -------------------------
 *&A& iSemKey    key_t			  ���o�t�α���X�Ъ��_
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0	: ����ư��榨�\
 *&R&   -9 : CWA ���t�κX�Фw�s�b. 
 *&R&  -10 : ���o CWA ���t�κX�Х���.
 *&R&  -11 : �]�w CWA �t�κX�Ъ��v������.
 *&R&
 *&D& DESCRIPTION:
 *&D&  1.�ˬd CWA SEM �O�_�w�g�s�b.
 *&D&  2.���o CWA SEM �t�θ귽.
 *&D&  3.�]�w CWA SEM ���s���v��.
 *&D&  4.�]�w CWA SEMVAL = 1.
 *&D&
 */

int
CreatCwaSem(key_t iSemKey)
{
  int i;
  int iRc;
  ushort usaSemvals[MAX_CWA_NSEMS];
  struct semid_ds stSemds;
  /* SWA semaphore structure definition */
   union  SemCtl {
       int    iSemval ;
       struct semid_ds *pstSemds ;
       ushort *pusaAray ;
   } unCwaSemCtl;

  UCP_TRACE(P_CreatCwaSem);
  /* �ˬd CWA SEM �O�_�w�g�s�b */
  sg_iCwaSemId = semget(iSemKey,0,0);
  if(sg_iCwaSemId != -1){
    sprintf (g_caMsg, 
             "<COM> Semaphore key [0x%0x] for CWA is in use! (errno:%d=>%s)",
             iSemKey, errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt(CWA_SEM_EXIST_ERROR,g_caMsg);
    UCP_TRACE_END(CWA_SEM_EXIST_ERROR);
  } /* end of if(sg_iCwaSemId != -1) */

  /* ���o CWA SEM �t�θ귽 */
  sg_iCwaSemId = semget(iSemKey,MAX_CWA_NSEMS,IPC_CREAT);
  if(sg_iCwaSemId == -1){
    sprintf (g_caMsg, 
    "<COM> Failure to create CWA semaphore id with key [0x%0x]! (errno:%d=>%s)",
    iSemKey, errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt(CWA_SEM_CREAT_ERROR,g_caMsg);
    UCP_TRACE_END(CWA_SEM_CREAT_ERROR);
  } /* end of if(sg_iCwaSemId == -1) */

  /* �]�w CWA SEM ���s���v�� */
  memset(&stSemds,'0',sizeof(struct semid_ds));
  stSemds.sem_perm.mode = 000660;
  stSemds.sem_perm.uid = getuid();
  stSemds.sem_perm.gid = getgid();
  unCwaSemCtl.pstSemds = &stSemds;
/* modified by alexwu on 19950413
  iRc = semctl(sg_iCwaSemId,MAX_CWA_NSEMS,IPC_SET,unCwaSemCtl.pstSemds);
*/
  iRc = semctl(sg_iCwaSemId,MAX_CWA_NSEMS,IPC_SET,unCwaSemCtl);
  if(iRc == -1){
    sprintf (g_caMsg, 
    "<COM> Failure to set CWA semaphore with id [%0d]! (errno:%d=>%s)",
    sg_iCwaSemId, errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt(CWA_SEMCTL_ERROR,g_caMsg);
    UCP_TRACE_END(CWA_SEMCTL_ERROR);
  } /* end of if(iRc == -1) */

  /* �]�w CWA SEMVAL = 1 */
  for(i=0;i<MAX_CWA_NSEMS;i++){
    usaSemvals[i] = 1;
  } /* end of for(i=0;i<MAX_CWA_NSEMS;i++) */
  unCwaSemCtl.pusaAray = usaSemvals;
/* modified by alexwu on 19950413
  iRc = semctl(sg_iCwaSemId,MAX_CWA_NSEMS,SETALL,unCwaSemCtl.pusaAray);
*/
  iRc = semctl(sg_iCwaSemId,MAX_CWA_NSEMS,SETALL,unCwaSemCtl);
  if(iRc == -1){
    sprintf (g_caMsg, 
    "<COM> Failure to setall CWA semaphore with id [%0d]! (errno:%d=>%s)",
    sg_iCwaSemId, errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt(CWA_SEMCTL_ERROR,g_caMsg);
    UCP_TRACE_END(CWA_SEMCTL_ERROR);
  } /* end of if(iRc == -1) */

  UCP_TRACE_END(0);
} /* end of CreatCwaSem(key_t iSemKey) */

/*
 *&N& ROUTINE NAME: UnOLockCwa(char cSegCode, int UnlockOLock)
 *&A& ARGUMENTS:
 *&A&   NAME          TYPE                 DESCRIPTION
 *&A& ---------  ---------------------    -------------------------
 *&A& cSegCode    char			  �@�Τu�@��ưϪ����P��ưϥN�X
 *&A& UnlockOLock int			  �]�w��w�θ���
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0 : ����ư��榨�\
 *&R&  -12 : �[��θ���Y��ưϥ���.
 *&R&
 *&D& DESCRIPTION:
 *&D&   1. �[��θ���Y��ư�.
 *&D&
 */

int
UnOLockCwa(char cSegCode,int iUnlockOLock)
{
  int iRc;
  int iSemNo;
  int iNSops;
  ushort usSemval;
  struct sembuf stSops;

  UCP_TRACE(P_UnOLockCwa);
  /* for debug */
  /*
  iSemNo = cSegCode - '0';
  usSemval = semctl(sg_iCwaSemId,iSemNo,GETVAL,0);
  sprintf(g_caMsg,"UnOLockCwa: semval=%u",usSemval);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
  */

  stSops.sem_num = cSegCode - '0';
  stSops.sem_op = iUnlockOLock;
  stSops.sem_flg = SEM_UNDO;
  iNSops = 1;
  iRc = semop(sg_iCwaSemId,&stSops,iNSops);
  if(iRc == -1){
    sprintf(g_caMsg,
    "<COM> Failure to unlock CWA semaphore with id[%d]! (errno:%d=>%s)",
    sg_iCwaSemId, errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt(CWA_SEG_LOCK_ERROR,g_caMsg);
    UCP_TRACE_END(CWA_SEG_LOCK_ERROR);
  } /* end of if(iRc == -1) */

  /* for debug */
  /*
  usSemval = semctl(sg_iCwaSemId,iSemNo,GETVAL,0);
  sprintf(g_caMsg,"<COM> semval=%u",usSemval);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
  */
  UCP_TRACE_END(0);
} /* end of UnOLockCwa(char cSegCode,int iUnlockOLock) */


/*
 *&N& ROUTINE NAME: ReadCwa(char cSegCode,char *pcaTblIdx,char *pcIoBuf)
 *&A& ARGUMENTS:
 *&A&   NAME            TYPE                 DESCRIPTION
 *&A& -------------- -----------------    -------------------------
 *&A& cSegCode         char		  �@�Τu�@��ưϪ����P��ưϥN�X
 *&A& pcaTblIdx        char *		  ����}�C��index
 *&A& pcIoBuf          char *		  ��X/�J��ƼȦb�Ϧ�m
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0 : ����ư��榨�\
 *&R&  -13 : ��ưϥN�X���~.
 *&R&  -14 : �M��׺��󱱨������~.
 *&R&
 *&D& DESCRIPTION:
 *&D&   1. �Y�O�׺��󱱨�����ưϩάO�|�ͪ����ư�, �٭n�̸Ӫ��檺index�M��.
 *&D&   2. �Y�O�׺��󱱨���檺index��-1, �h�n�H����N���ε�����N���M��.
 *&D&   3. �̤��P��ưϥN�X�⤣�P����ưϸ�ƴ_�s���X/�J�Ȧs�Ϥ�.
 *&D&
 */

int
ReadCwa(char cSegCode, char *pcaTblIdx, char *pcIoBuf)
{
  struct SSA *stSSABuf;
  struct SPA *stSPABuf;
  struct BitBrhTermSt *pstBitBuf;
  struct SessTbl *stSesBuf;
  struct Big2Nhost *stB2NBuf;
  struct ADA *stADABuf;
  struct AciaInt *stAciaIntBuf;
  int iTblIdx;
  int iRc;
 
  UCP_TRACE(P_ReadCwa);

  /* �ˬd�O�_�v�g�s���F */
  if(sg_pstCWA == NULL){
    ErrLog(1000,"<COM> CWA No Attach error!",RPT_TO_LOG,0,0);
    UCP_TRACE_END(CWA_NO_ATTACH_ERROR);
  }

  switch (cSegCode){
    case CWA_SEG_SSA :
      stSSABuf = (struct SSA *)pcIoBuf;
      memcpy(stSSABuf,&sg_pstCWA->stSSA,sizeof(struct SSA));
      break;
    case CWA_SEG_SPA :
      stSPABuf = (struct SPA *)pcIoBuf;
      memcpy(stSPABuf,&sg_pstCWA->stSPA,sizeof(struct SPA));
      break;
    case CWA_SEG_BIT_BRH :
      pstBitBuf = (struct BitBrhTermSt *)pcIoBuf;
      memset(pstBitBuf->stTerm.caTermId,'\0',MAX_TM_LEN);

      iRc = BitOperation(RD_BIT, pstBitBuf->stBrh.caBrhId,
                         pstBitBuf->stTerm.caTermId,pstBitBuf);
      if ( iRc < 0 ) {
        ErrLog(1000,"<COM> ReadCwa: BitOperation error!",RPT_TO_LOG,0,0);
        DetErrRpt(BIT_OPERATION_ERROR,g_caMsg);
        UCP_TRACE_END(BIT_OPERATION_ERROR);
      }

      break;
    case CWA_SEG_BIT_BRHTM :
      pstBitBuf = (struct BitBrhTermSt *)pcIoBuf;

      iRc = BitOperation(RD_BIT, pstBitBuf->stBrh.caBrhId,
                         pstBitBuf->stTerm.caTermId,pstBitBuf);
      if ( iRc < 0 ) {
        ErrLog(1000,"<COM> ReadCwa: BitOperation error!",RPT_TO_LOG,0,0);
        DetErrRpt(BIT_OPERATION_ERROR,g_caMsg);
        UCP_TRACE_END(BIT_OPERATION_ERROR);
      }

      break;
    case CWA_SEG_BIT_TTYNAME :
      pstBitBuf = (struct BitBrhTermSt *)pcIoBuf;

      iRc = GetBrhTmByName(pstBitBuf->stTerm.caLogicId,pstBitBuf);
      if ( iRc < 0 ) {
        ErrLog(1000,"<COM> ReadCwa: GetBrhTmByName error!",RPT_TO_LOG,0,0);
        DetErrRpt(GET_BRHTM_BYNAME_ERROR,g_caMsg);
        UCP_TRACE_END(GET_BRHTM_BYNAME_ERROR);
      }

      break;
    case CWA_SEG_SES :
      iTblIdx = atoi(pcaTblIdx);
      stSesBuf = (struct SessTbl *)pcIoBuf;
      memcpy(stSesBuf,&sg_pstCWA->stSessTbl[iTblIdx],sizeof(struct SessTbl));
      break;
    case CWA_SEG_B2N :
      stB2NBuf = (struct Big2Nhost *)pcIoBuf;
      memcpy(stB2NBuf,&sg_pstCWA->stCvtTbl,sizeof(struct Big2Nhost));
      break;
    case CWA_SEG_ADA :
      stADABuf = (struct ADA *)pcIoBuf;
      memcpy(stADABuf,&sg_pstCWA->stADA,sizeof(struct ADA));
      break;
    case CWA_SEG_ACI :
      stAciaIntBuf = (struct AciaInt *)pcIoBuf;
      memcpy(stAciaIntBuf,&sg_pstCWA->stAciaInt,sizeof(struct AciaInt));
      break;
    default:
      ErrLog(1000,"<COM> Unknown ReadCwa SegCode!",RPT_TO_LOG,0,0);
      DetErrRpt(CWA_SEGCODE_ERROR,g_caMsg);
      UCP_TRACE_END(CWA_SEGCODE_ERROR);
  } /* end of switch (cSegCode) */
  UCP_TRACE_END(0);
} /* end of ReadCwa(char cSegCode, char *pcaTblIdx, char *pcIoBuf) */

/*
 *&N& ROUTINE NAME: WriteCwa(char cSegCode,char *pcaTblIdx,char *pcIoBuf)
 *&A& ARGUMENTS:
 *&A&   NAME            TYPE                 DESCRIPTION
 *&A& -------------- -----------------    -------------------------
 *&A& cSegCode         char		  �@�Τu�@��ưϪ����P��ưϥN�X
 *&A& pcaTblIdx        char *		  ����}�C��index
 *&A& pcIoBuf          char *		  ��X/�J��ƼȦb�Ϧ�m
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0 : ����ư��榨�\
 *&R&  -13 : ��ưϥN�X���~.
 *&R&  -14 : �M��׺��󱱨������~.
 *&R&
 *&D& DESCRIPTION:
 *&D&   1. �Y�O�׺��󱱨�����ưϩάO�|�ͪ����ư�, �٭n�̸Ӫ��檺index�M��.
 *&D&   2. �Y�O�׺��󱱨���檺index��-1, �h�n�H����N���ε�����N���M��.
 *&D&   3. �̤��P��ưϥN�X���X/�J�Ȧs�Ϥ�����ƴ_�s�줣�P����ưϤ�.
 *&D&
 */

int
WriteCwa(char cSegCode,char *pcaTblIdx,char *pcIoBuf)
{
  struct SSA *stSSABuf;
  struct SPA *stSPABuf;
  struct BitBrhTermSt *pstBitBuf;
  struct SessTbl *stSesBuf;
  struct Big2Nhost *stB2NBuf;
  struct ADA *stADABuf;
  struct AciaInt *stAciaIntBuf;
  int iTblIdx;
  int iRc;
  
  UCP_TRACE(P_WriteCwa);

  /* �ˬd�O�_�v�g�s���F */
  if(sg_pstCWA == NULL){
    ErrLog(1000,"<COM> CWA No Attach error!",RPT_TO_LOG,0,0);
    UCP_TRACE_END(CWA_NO_ATTACH_ERROR);
  }

  switch (cSegCode){
    case CWA_SEG_SSA :
      stSSABuf = (struct SSA *)pcIoBuf;
      memcpy(&sg_pstCWA->stSSA,stSSABuf,sizeof(struct SSA));
      break;
    case CWA_SEG_SPA :
      stSPABuf = (struct SPA *)pcIoBuf;
      memcpy(&sg_pstCWA->stSPA,stSPABuf,sizeof(struct SPA));
      break;
    case CWA_SEG_BIT_BRH :
      pstBitBuf = (struct BitBrhTermSt *)pcIoBuf;
      memset(pstBitBuf->stTerm.caTermId,'\0',MAX_TM_LEN);

      iRc = BitOperation(WR_BIT,pstBitBuf->stBrh.caBrhId,
                         pstBitBuf->stTerm.caTermId,pstBitBuf);

      if ( iRc < 0 ) {
        ErrLog(1000,"<COM> WriteCwa: BitOperation error!",RPT_TO_LOG,0,0);
        DetErrRpt(BIT_OPERATION_ERROR,g_caMsg);
        UCP_TRACE_END(BIT_OPERATION_ERROR);
      }

      break;
    case CWA_SEG_BIT_BRHTM :
      pstBitBuf = (struct BitBrhTermSt *)pcIoBuf;

      iRc = BitOperation(WR_BIT,pstBitBuf->stBrh.caBrhId,
                         pstBitBuf->stTerm.caTermId,pstBitBuf);

      if ( iRc < 0 ) {
        ErrLog(1000,"<COM> WriteCwa: BitOperation error!",RPT_TO_LOG,0,0);
        DetErrRpt(BIT_OPERATION_ERROR,g_caMsg);
        UCP_TRACE_END(BIT_OPERATION_ERROR);
      }

      break;
    case CWA_SEG_SES :
      iTblIdx = atoi(pcaTblIdx);
      stSesBuf = (struct SessTbl *)pcIoBuf;
      memcpy(&sg_pstCWA->stSessTbl[iTblIdx],stSesBuf,sizeof(struct SessTbl));
      break;
    case CWA_SEG_B2N :
      stB2NBuf = (struct Big2Nhost *)pcIoBuf;
      memcpy(&sg_pstCWA->stCvtTbl,stB2NBuf,sizeof(struct Big2Nhost));
      break;
    case CWA_SEG_ADA :
      stADABuf = (struct ADA *)pcIoBuf;
      memcpy(&sg_pstCWA->stADA,stADABuf,sizeof(struct ADA));
      break;
    case CWA_SEG_ACI :
      stAciaIntBuf = (struct AciaInt *)pcIoBuf;
      memcpy(&sg_pstCWA->stAciaInt,stAciaIntBuf,sizeof(struct AciaInt));
      break;
    default:
      ErrLog(1000,"<COM> Unknown WriteCwa SegCode!",RPT_TO_LOG,0,0);
      DetErrRpt(CWA_SEGCODE_ERROR,g_caMsg);
      UCP_TRACE_END(CWA_SEGCODE_ERROR);
  } /* end of switch (cSegCode) */
  UCP_TRACE_END(0);
} /* end of WriteCwa(char cSegCode,char *pcaTblIdx,char *pcIoBuf) */

/*
 *&N& ROUTINE NAME: GetCwaSegPtr(char cSegCode,char *pcaTblIdx,char **ppcIoBuf)
 *&A& ARGUMENTS:
 *&A&   NAME            TYPE                 DESCRIPTION
 *&A& -------------- -----------------    -------------------------
 *&A& cSegCode         char		  �@�Τu�@��ưϪ����P��ưϥN�X
 *&A& pcaTblIdx        char *		  ����}�C��index
 *&A& pcIoBuf          char **		  ��X/�J��ƼȦb�Ϧ�m
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0 : ����ư��榨�\
 *&R&  -13 : ��ưϥN�X���~.
 *&R&  -15 : �M��׺��󱱨����index���~.
 *&R&  -16 : �|�ͱ������index���~.
 *&R&
 *&D& DESCRIPTION:
 *&D&   1. �Y�O�׺��󱱨�����ưϩάO�|�ͪ����ư�, �٭n�̸Ӫ��檺index�M��.
 *&D&   2. �ˬd���檺index�O�_�W�X�Ȱ�d��.
 *&D&   3. �̤��P��ưϥN�X�⤣�P����ưϪ���m�ǵ���X/�J�Ȧs�Ϥ�.
 *&R&
 */

int
GetCwaSegPtr(char cSegCode,char *pcaTblIdx,char **ppcIoBuf)
{
  int iTblIdx;
  int iBrhCnt;
  int iOffset;
  struct BrhArea *pstBrhArea;
  static char *pcaBitTbl;
  
  UCP_TRACE(P_GetCwaSegPtr);

  /* �ˬd�O�_�v�g�s���F */
  if(sg_pstCWA == NULL){
    ErrLog(1000,"<COM> CWA No Attach error!",RPT_TO_LOG,0,0);
    UCP_TRACE_END(CWA_NO_ATTACH_ERROR);
  }

  switch (cSegCode){
    case CWA_SEG_SSA :
      *ppcIoBuf = (char *) &(sg_pstCWA->stSSA);
      break;
    case CWA_SEG_SPA :
      *ppcIoBuf = (char *) &(sg_pstCWA->stSPA);
      /*sprintf(g_caMsg,"GetCwaSegPtr:dump SPA");
      ErrLog(100,g_caMsg,RPT_TO_LOG,&(sg_pstCWA->stSPA), sizeof(struct SPA));*/
      break;
    case CWA_SEG_BIT_START :
/* TCC
sprintf (g_caMsg,
  "<COM> 000 BIT_START: CWA:[%p]  pcaBitTbl:[0x%p]  *ppcIoBuf:[0x%p]",
  sg_pstCWA, sg_pstCWA->pcaBitTbl, *ppcIoBuf);
ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
*/
      pcaBitTbl = (char *) sg_pstCWA;
      sg_pstCWA->pcaBitTbl = (char *) (pcaBitTbl + sizeof(struct CWA));

      *ppcIoBuf = (char *) (sg_pstCWA->pcaBitTbl);
/* TCC
sprintf (g_caMsg,
  "<COM> 111 BIT_START: CWA:[%p]  pcaBitTbl:[0x%p]  *ppcIoBuf:[0x%p]",
  sg_pstCWA, sg_pstCWA->pcaBitTbl, *ppcIoBuf);
ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
*/
      break;
    case CWA_SEG_BIT_TM :
        memcpy(pstBrhArea,sg_pstCWA->pcaBitTbl+8,sizeof(struct BrhArea));
        iOffset = pstBrhArea->iTermOffset;
        *ppcIoBuf = (char *) (sg_pstCWA->pcaBitTbl) + iOffset; 
      break;
    case CWA_SEG_SES :
      iTblIdx = atoi(pcaTblIdx);
      if(iTblIdx < 0 || iTblIdx > MAX_SESS_NO){
      /* add output message by pjw for tu970148       1999 6 8*/
        sprintf(g_caMsg,"<COM> GetCwaSegPtr:  (SES segment)  illegal iTblIdx=%d",iTblIdx);
        ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
        UCP_TRACE_END(CWA_SESSION_IDX_ERROR);
      }
      if(iTblIdx == -1){
        *ppcIoBuf = (char *) (sg_pstCWA->stSessTbl);
        
      }
      else{
        *ppcIoBuf = (char *) &(sg_pstCWA->stSessTbl[iTblIdx]);
      }
      break;
    case CWA_SEG_B2N :
      *ppcIoBuf = (char *) &(sg_pstCWA->stCvtTbl);
      break;
    case CWA_SEG_ADA :
      *ppcIoBuf = (char *) &(sg_pstCWA->stADA);
      break;
    case CWA_SEG_ACI :
      *ppcIoBuf = (char *) &(sg_pstCWA->stAciaInt);
      break;
    case CWA_SEG_MDA :
      /* *ppcIoBuf = (char *) &(sg_pstCWA->stMDA); */
      *ppcIoBuf = (char *) &(sg_pstCWA->caMda);
      break;
    default:
      ErrLog(1000,"<COM> Unknown GetCwaSegPtr SegCode!",RPT_TO_LOG,0,0);
      DetErrRpt(CWA_SEGCODE_ERROR,g_caMsg);
      UCP_TRACE_END(CWA_SEGCODE_ERROR);
  } /* end of switch (cSegCode) */

  UCP_TRACE_END(0);

} /* end of GetCwaSegPtr(char cSegCode,char *pcaTblIdx,char **ppcIoBuf) */

/*
 *&N& ROUTINE NAME:BitOperation()
 *&A& ARGUMENTS:
 *&A&    NAME         TYPE            DESCRIPTION
 *&A& -------------  ------  -------------------------------
 *&A&  
 *&A&
 *&R& RETURN VALUE(S):
 *&R&  0 : ������J��ƪ�����
 *&R& -1 : ������J��ƥ���
 *&R&
 *&D& DESCRIPTION
 *&D& �I�s���ɭ��ҲըӦs��BIT �������
 *&D&
 */

int
BitOperation(cFunCode,pcaBrhCode,pcaTmCode,pstBrhTmArea)
char  cFunCode;
char  *pcaBrhCode;
char  *pcaTmCode;
struct BitBrhTermSt *pstBrhTmArea;
{
  char   *pcaBitTbl;
  struct SPA *pstSpa;
  struct CwaCtl stCwaCtl;
  struct BrhArea   *pstBrhArea;
  struct TermArea  *pstTermArea;
  static int    s_iCurBrhOffset,s_iCurTmOffset;
  static char   s_caLastBrhCode[10]= "\0\0\0\0\0\0\0\0\0\0";
  static char   s_caLastTmCode[4]="\0\0\0\0";
  int    iTotBrhCnt,i;
  int    iBrhNodeLen,iTmNodeLen;
  int    iOffset;
  int    iBrhOffset;
  int    iRc;

  UCP_TRACE(P_BitOperation); 

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_BIT_START;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcaBitTbl);
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SPA;
  iRc = CwaLowCtlFac(&stCwaCtl,(char **)&pstSpa);
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }

  iBrhNodeLen = (int) pstSpa->cBrCodeLen ;
  iTmNodeLen  = (int) pstSpa->cTmCodeLen ;

  if (strncmp(pcaBrhCode,s_caLastBrhCode,iBrhNodeLen)== 0) {
    iOffset = s_iCurBrhOffset ;        /* Branch equal to cache */

    switch ( cFunCode ) {
      case RD_BIT:
        memcpy(pstBrhTmArea,pcaBitTbl+iOffset,sizeof(struct BrhArea));
        break;
      case WR_BIT:
        memcpy(pcaBitTbl+iOffset,pstBrhTmArea,sizeof(struct BrhArea));
        break;
      default:
        sprintf(g_caMsg,"<COM> Unknown BitOperation cFunCode [%c]",cFunCode);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END( FUN_CODE_ERR );
    }

    if (pcaTmCode[0] != '\0')  {

      if (strncmp(pcaTmCode,s_caLastTmCode,iTmNodeLen)== 0) {
        iOffset = s_iCurTmOffset ;      /* Terminal equal to Cache */

        switch ( cFunCode ) {
          case RD_BIT:
            memcpy(pstBrhTmArea+sizeof(struct BrhArea),
                   pcaBitTbl+iOffset,sizeof(struct TermArea));
            break;
          case WR_BIT:
            memcpy(pcaBitTbl+iOffset,pstBrhTmArea+sizeof(struct BrhArea),
                   sizeof(struct TermArea));
            break;
          default:
            sprintf(g_caMsg,
                    "<COM> Unknown BitOperation cFunCode [%c]",cFunCode);
            ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
            UCP_TRACE_END( FUN_CODE_ERR );
        }

        UCP_TRACE_END(0);
      }
      else {             /* Branch equal but Terminal not equal */
        iOffset=pstBrhArea->iTermOffset;
        pstTermArea =(struct TermArea *) (pcaBitTbl+iOffset);
      } /* FOR if (strncmp(pcaTmCode,s_caLastTmCode,iTmNodeLen)== 0) */
    }
    else  {
      memset(pstBrhTmArea+sizeof(struct BrhArea),'\0',sizeof(struct TermArea));
      UCP_TRACE_END(0);
    } /* FOR if (pcaTmCode[0] != '\0') */

  }   /*  end of Branch equal to Cache  */
  else {   /* Branch not equal to Cache */
    memcpy(&iTotBrhCnt,pcaBitTbl,4);
    iBrhOffset = 8 ; 
    pstBrhArea =(struct BrhArea *) (pcaBitTbl+iBrhOffset);

    do {

      if (strncmp(pcaBrhCode,pstBrhArea->caBrhId,iBrhNodeLen)==0) {
        memset(s_caLastBrhCode,'\0',10);
        memcpy(s_caLastBrhCode,pcaBrhCode,iBrhNodeLen);
        s_iCurBrhOffset = iBrhOffset;      /* Keep the record to cache */
        switch ( cFunCode ) {
          case RD_BIT:
            memcpy(pstBrhTmArea,pcaBitTbl+iBrhOffset,sizeof(struct BrhArea));
            break;
          case WR_BIT:
            memcpy(pcaBitTbl+iBrhOffset,pstBrhTmArea,sizeof(struct BrhArea));
            break;
          default:
            sprintf(g_caMsg,
                    "<COM> Unknown BitOperation cFunCode [%c]",cFunCode);
            ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
            UCP_TRACE_END( FUN_CODE_ERR );
        }
      }
      else  {
        iBrhOffset = pstBrhArea->iNxtBrhOffset; 
        pstBrhArea = (struct BrhArea *) (pcaBitTbl+iBrhOffset);
      } /* FOR if (strncmp(pcaBrhCode,pstBrhArea->caBrhId,iBrhNodeLen)==0) */

    } while (iBrhOffset != -1) ;

    if (iBrhOffset == -1) {
      sprintf(g_caMsg,"<COM> Unable to find branch [%.*s] in BIT",
              iBrhNodeLen, pcaBrhCode);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(NO_BRH_DATA);
    }
        
    iOffset = pstBrhArea->iTermOffset;
    pstTermArea = (struct TermArea *) (pcaBitTbl+iOffset);
  }  /* FOR if (strncmp(pcaBrhCode,s_caLastBrhCode,iBrhNodeLen)== 0) */
 
/* following is running when 2 case */
/* 1: Brahch not equal to cache, by sequential searching to get the Brh Info.*/
/* 2: Branch equal to cache,using the cache brh Info. directly  */

  if (pcaTmCode[0] != '\0')  {
    do  {
      if (strncmp(pcaTmCode,pstTermArea->caTermId,iTmNodeLen)== 0) {
        switch ( cFunCode ) {
          case RD_BIT:
            memcpy(pstBrhTmArea+sizeof(struct BrhArea),
                   pcaBitTbl+iOffset,sizeof(struct TermArea));
            break;
          case WR_BIT:
            memcpy(pcaBitTbl+iOffset,pstBrhTmArea+sizeof(struct BrhArea),
                   sizeof(struct TermArea));
            break;
          default:
            sprintf(g_caMsg,
                    "<COM> Unknown BitOperation cFunCode [%c]",cFunCode);
            ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
            UCP_TRACE_END( FUN_CODE_ERR );
        }
        s_iCurTmOffset = iOffset; 
        memset(s_caLastTmCode,'\0',4);
        memcpy(s_caLastTmCode,pcaTmCode,iTmNodeLen);
        break;
      }
      else  {
        iOffset = pstTermArea->iNxtTmOffset;
        pstTermArea = (struct TermArea *) (pcaBitTbl+iOffset);
      }
    }  while (iOffset != -1) ;
  }
  else  {
    memset(pstBrhTmArea+sizeof(struct BrhArea),'\0',sizeof(struct TermArea));
    UCP_TRACE_END(0);
  } /* FOR if (pcaTmCode[0] != '\0') */
  
  if (iOffset == -1) {
    sprintf(g_caMsg,"<COM> Unable to find terminal [%.*s] in BIT",
            iTmNodeLen, pcaTmCode);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(NO_TERM_DATA);
  }

  UCP_TRACE_END(0);
}

/*
 *&N& ROUTINE NAME:GetTermPtr()
 *&A& ARGUMENTS:
 *&A&    NAME         TYPE            DESCRIPTION
 *&A& -------------  ------  -------------------------------
 *&A&  
 *&A&
 *&R& RETURN VALUE(S):
 *&R&  0 : ������J��ƪ�����
 *&R& -1 : ������J��ƥ���
 *&R&
 *&D& DESCRIPTION
 *&D& �I�s���ɭ��ҲըӦs���Y�Ӳ׺ݾ���Ƶ��c���_�l��}
 *&D&
 */

int
GetTermPtr(char *pcaBrhId,char *pcaTermId,char **ppcIoBuf)
{
  char   *pcaBitTbl;
  struct SPA *pstSpa;
  struct CwaCtl stCwaCtl;
  struct BrhArea   *pstBrhArea;
  struct TermArea  *pstTermArea;
  static int    s_iCurBrhOffset,s_iCurTmOffset;
  static char   s_caLastBrhCode[10]= "\0\0\0\0\0\0\0\0\0\0";
  static char   s_caLastTmCode[4]="\0\0\0\0";
  int    iTotBrhCnt,iTotTmCnt,i;
  int    iBrhNodeLen,iTmNodeLen;
  int    iOffset;
  int    iRc;

  UCP_TRACE(P_GetTermPtr);

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_BIT_START;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcaBitTbl);
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SPA;
  iRc = CwaLowCtlFac(&stCwaCtl,(char **)&pstSpa);
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }

  iBrhNodeLen = (int) pstSpa->cBrCodeLen ;
  iTmNodeLen  = (int) pstSpa->cTmCodeLen ;

  /* compare with the cache for TERM */
/* mark for correcting TXN SEQ(ACC & Non-ACC) NO ...1995/01/01..by chi-fu-song
  if (strncmp(pcaTermId,s_caLastTmCode,iTmNodeLen)== 0) {
    iOffset = s_iCurTmOffset ;      /X Terminal equal to Cache X/
    *ppcIoBuf = pcaBitTbl+iOffset;
    UCP_TRACE_END(0);
  }
*/

  memcpy(&iTotBrhCnt,pcaBitTbl,4);
  iOffset = 8 ; 
  pstBrhArea = (struct BrhArea *) (pcaBitTbl+iOffset);
  for(i=0;i<iTotBrhCnt;i++)  {
    if (strncmp(pcaBrhId,pstBrhArea->caBrhId,iBrhNodeLen)== 0) {
      s_iCurBrhOffset = iOffset; 
      memcpy(s_caLastBrhCode,pcaBrhId,iBrhNodeLen);
      break;
    }
    else  {
      iOffset = pstBrhArea->iNxtBrhOffset;
      pstBrhArea = (struct BrhArea *) (pcaBitTbl+iOffset);
    }
  }  /* FOR for(i=0;i<iTotBrhCnt;i++)  */

  if (i == iTotBrhCnt)  {
    sprintf(g_caMsg,"<COM> Unable to find branch [%.*s] in BIT",
            iBrhNodeLen, pcaBrhId);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(NO_BRH_DATA);
  }

  iOffset = pstBrhArea->iTermOffset;
  pstTermArea= (struct TermArea *) (pcaBitTbl+iOffset);

  /* Add by Chi Fu-Song  1994/09/17 PM5:00 */
  iTotTmCnt = pstBrhArea->iNoOfTerm;

  for(i=0;i<iTotTmCnt;i++)  {
    if (strncmp(pcaTermId,pstTermArea->caTermId,iTmNodeLen)== 0) {
      s_iCurTmOffset = iOffset; 
      *ppcIoBuf = pcaBitTbl+iOffset;
      memcpy(s_caLastTmCode,pcaTermId,iTmNodeLen);
      break;
    }
    else  {
      iOffset = pstTermArea->iNxtTmOffset;
      pstTermArea= (struct TermArea *) (pcaBitTbl+iOffset);
    }
  }
  
  if (i == iTotTmCnt)  {
    sprintf(g_caMsg,"<COM> Unable to find terminal [%.*s] in BIT",
            iTmNodeLen, pcaTermId);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(NO_TERM_DATA);
  }

  UCP_TRACE_END(0);
  
}

/*
 *&N& ROUTINE NAME:GetBrhTmByname()
 *&A& ARGUMENTS:
 *&A&    NAME         TYPE            DESCRIPTION
 *&A& -------------  ------  -------------------------------
 *&A&  
 *&A&
 *&R& RETURN VALUE(S):
 *&R&  0 : ������J��ƪ�����
 *&R& -1 : ������J��ƥ���
 *&R&
 *&D& DESCRIPTION
 *&D& �I�s���ɭ��ҲեH�׺ݾ��W����Ӧs��BIT �������
 *&D&
 */

int
GetBrhTmByName(pcaTtyName,pstBrhTmArea)
char  *pcaTtyName;
struct BitBrhTermSt *pstBrhTmArea;
{
  char   *pcaBitTbl;
  struct SPA *pstSpa;
  struct CwaCtl stCwaCtl;
  struct BrhArea   *pstBrhArea;
  struct TermArea  *pstTermArea;
  static int    s_iCurBrhOffset,s_iCurTmOffset;
  static char   s_caLastTtyName[MAX_TTY_LEN];
  int    iTotBrhCnt,iTotTmCnt,i;
  int    iBrhNodeLen,iTmNodeLen;
  int    iOffset;
  int    iBrhOffset;
  int    iRc;
  int    iLogicIdLen;

  UCP_TRACE(P_GetBrhTmByName);

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SPA;
  iRc = CwaLowCtlFac(&stCwaCtl,(char **)&pstSpa);
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }

  iBrhNodeLen = (int) pstSpa->cBrCodeLen ;
  iTmNodeLen  = (int) pstSpa->cTmCodeLen ;

  if ( strlen(pcaTtyName) > 14 ) {
    sprintf(g_caMsg,"<COM> Unable to find terminal [%.*s] in BIT",
            strlen(pcaTtyName), pcaTtyName);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(UNDEFINED_TERM);
  }

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_BIT_START;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcaBitTbl);
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }

  memcpy(&iTotBrhCnt,pcaBitTbl,4);
  iBrhOffset = 8;

  do  {
    pstBrhArea= (struct BrhArea *) (pcaBitTbl+iBrhOffset);
    iOffset = pstBrhArea->iTermOffset;

    while (iOffset != -1)  {
      pstTermArea = (struct TermArea *) (pcaBitTbl+iOffset);
      iLogicIdLen = strlen(pstTermArea->caLogicId) > 14 
                                       ? 14 : strlen(pstTermArea->caLogicId);
      if ( iLogicIdLen < 14 ) {
        if ( strlen(pcaTtyName) > iLogicIdLen ) {
          iLogicIdLen = strlen(pcaTtyName);
        }
      }

      if (strncmp(pcaTtyName,pstTermArea->caLogicId,iLogicIdLen)== 0) {
        memcpy(&pstBrhTmArea->stBrh, pstBrhArea,sizeof(struct BrhArea));
        memcpy(&pstBrhTmArea->stTerm, pstTermArea,sizeof(struct TermArea));
        UCP_TRACE_END(0);
      }
      else  {
        iOffset = pstTermArea->iNxtTmOffset;
      }
    }

    iBrhOffset = pstBrhArea->iNxtBrhOffset;

  } while(iBrhOffset != -1);  
  
  if ((iOffset == -1)&&(iBrhOffset == -1))  {
    sprintf(g_caMsg,"<COM> Unable to find terminal [%.*s] in BIT",
            strlen(pcaTtyName), pcaTtyName);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(UNDEFINED_TERM);
  }
}



/*
 *&N& ROUTINE NAME:GetBrhPtr()
 *&A& ARGUMENTS:
 *&A&    NAME         TYPE            DESCRIPTION
 *&A& -------------  ------  -------------------------------
 *&A&  
 *&A&
 *&R& RETURN VALUE(S):
 *&R&  0 : ������J��ƪ�����
 *&R& -1 : ������J��ƥ���
 *&R&
 *&D& DESCRIPTION
 *&D& �I�s���ɭ��ҲըӦs���Y�a���椧��Ƶ��c���_�l��}
 *&D&
 */

int
GetBrhPtr(char *pcaBrhId,char *pcaTermId,char **ppcIoBuf)
{
  char   *pcaBitTbl;
  struct SPA *pstSpa;
  struct CwaCtl stCwaCtl;
  struct BrhArea   *pstBrhArea;
  struct TermArea  *pstTermArea;
  static int    s_iCurBrhOffset,s_iCurTmOffset;
  static char   s_caLastBrhCode[10]= "\0\0\0\0\0\0\0\0\0\0";
  static char   s_caLastTmCode[4]="\0\0\0\0";
  int    iTotBrhCnt,iTotTmCnt,i;
  int    iBrhNodeLen,iTmNodeLen;
  int    iOffset;
  int    iRc;

  UCP_TRACE(P_GetBrhPtr);

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_BIT_START;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcaBitTbl);
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SPA;
  iRc = CwaLowCtlFac(&stCwaCtl,(char **)&pstSpa);
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }

  iBrhNodeLen = (int) pstSpa->cBrCodeLen ;
  iTmNodeLen  = (int) pstSpa->cTmCodeLen ;
  
  if (strncmp(pcaBrhId,s_caLastBrhCode,iBrhNodeLen)== 0) {
    iOffset = s_iCurBrhOffset;
    *ppcIoBuf = pcaBitTbl+iOffset;
    UCP_TRACE_END(0);
  }

  memcpy(&iTotBrhCnt,pcaBitTbl,4);
  iOffset = 8 ; 
  pstBrhArea = (struct BrhArea *) (pcaBitTbl+iOffset);
  for(i=0;i<iTotBrhCnt;i++)  {
    if (strncmp(pcaBrhId,pstBrhArea->caBrhId,iBrhNodeLen)== 0) {
      s_iCurBrhOffset = iOffset; 
      *ppcIoBuf = pcaBitTbl+iOffset;
      memcpy(s_caLastBrhCode,pcaBrhId,iBrhNodeLen);
      break;
    }
    else  {
      iOffset = pstBrhArea->iNxtBrhOffset;
      pstBrhArea = (struct BrhArea *) (pcaBitTbl+iOffset);
    }
  }

  if (i == iTotBrhCnt)  {
    sprintf(g_caMsg,"<COM> Unable to find branch [%.*s] in BIT",
            iBrhNodeLen, pcaBrhId);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(NO_BRH_DATA);
  }

  UCP_TRACE_END(0);
}

