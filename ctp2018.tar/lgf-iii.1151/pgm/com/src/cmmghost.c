/*
char MSG_STR[200];
#define RPT_TO_LOG 1
*/

main()
{ 
  char caHostName[80];

 GetDevHostName(caHostName);
 /*printf("caHostName = %s\n", caHostName);*/

} 
/*
err_log(err_code,disp_msg,dump_dev,dump_addr,dump_len)
int err_code;
char *disp_msg,dump_dev;
char  *dump_addr;
long   dump_len;
{
}
*/
/*#ifdef AT_AND_T_SVR4*/
#if defined(AT_AND_T_SVR4) || defined(TANDEM_UNIX) || defined(NEC_UNIX)
#include	"utmpx.h"
#include	"time.h"
#endif

GetDevHostName(char *pcName)
{
/*#ifdef AT_AND_T_SVR4*/
#if defined(AT_AND_T_SVR4) || defined(TANDEM_UNIX) || defined(NEC_UNIX)
  struct utmpx user,*pstUser;
  char   caBuf[30];
  int    i;
  int    iFlag;

  iFlag = 1;
/*
  for (i=0;i<sizeof(user.ut_line); i++)
      user.ut_line[i] = 0;
*/
  strcpy(pcName,ttyname(0)+5);

  while(iFlag){
      pstUser = getutxent();
/*
      cftime(caBuf,"%m-%d-%Y %H:%M:S",&pstUser->ut_tv.tv_sec);	
      printf("uname:[%10s],tname:[%s],address:[%13s],time=[%s]\n",
             pstUser->ut_name,pstUser->ut_line,pstUser->ut_host,caBuf);
*/
/*
      if (strcmp(pcName,pstUser->ut_line) == 0){
*/
          if ((strlen(pstUser->ut_host) <= 10) && 
              (strlen(pstUser->ut_host) > 0)){
              strcpy(pcName,pstUser->ut_host);
          }
          printf("ttyname:hostname-->[%s:%s]\n",pstUser->ut_line,
                  pstUser->ut_host);
/*
          printf("ttyname:hostname-->[%s/%s:%s]\n",pstUser->ut_line,
                  pstUser->ut_host, pcName);
          sprintf(MSG_STR,"get_dev_host_name:ttyname/hostname:[%s/%s=%s]",
                  pstUser->ut_line,pstUser->ut_host,pcName);
          err_log(100,MSG_STR,RPT_TO_LOG,0,0);
          break;
      }
*/
      if((int)pstUser) iFlag = 1;else iFlag = 0;
  }
#endif
}
