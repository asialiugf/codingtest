#include "errlog.h"
#include "errno.h"
#define P_GetDevHostName      601

/*#ifndef AT_AND_T_SVR4*/
#if !defined(AT_AND_T_SVR4) && !defined(TANDEM_UNIX) && !defined(NEC_UNIX)
int
GetDevHostName(pcaDname)
char  *pcaDname;
{
   char caBuff[80];
   FILE *zFp;
   int  i;
   #ifdef HP_UNIX
          static char caTmp[]={"who am i -R | cut -d'(' -f2 > "};
   #else
          static char caTmp[]={"who am i | cut -d'(' -f2 > "};
   #endif
   char caTmpFile[20];
   char caTmpCmd[50];
   char caPid[6];

   UCP_TRACE(P_GetDevHostName);
   memset(caTmpFile,'\0',20);
   strcpy(caTmpFile,"./tmp");
   sprintf(caPid,"%.5d",getpid());
   memcpy(&caTmpFile[5],caPid,5);
   strcpy(caTmpCmd,caTmp);
   strcat(caTmpCmd,caTmpFile);
   system(caTmpCmd);
   if ( (zFp=fopen(caTmpFile,"r")) == NULL ) {
      printf("open tmp file error errno=%d !\n",errno);
      UCP_TRACE_END(-1);
   }
   if ( fgets(caBuff,80,zFp) == NULL ) {
      fclose(zFp);
      printf("no data error errno=%d !\n",errno);
      UCP_TRACE_END(-1);
   }
   fclose(zFp);
   unlink(caTmpFile);
   for (i=0;i<(int)strlen(caBuff);i++) {
     if (caBuff[i] == ')') {
       caBuff[i]='\0';
       break;
     }
   }
   if ( (int)strlen(caBuff) > 10 ) {
    /*
    strcpy(pcaDname,ttyname(0)+5);
    */
    strcpy(pcaDname,ttyname(2)+5);
   }
   else {
    strcpy(pcaDname, caBuff);
   }

   UCP_TRACE_END(0);
}
#endif


/*#ifdef AT_AND_T_SVR4*/
#if defined(AT_AND_T_SVR4) || defined(TANDEM_UNIX) || defined(NEC_UNIX)
#include	"utmpx.h"
#include	"time.h"

GetDevHostName(char *pcName)
{
  struct utmpx user,*pstUser;
  char   caBuf[81];
  int    i;
  int    iFlag;

  iFlag = 1;
/*
  for (i=0;i<sizeof(user.ut_line); i++)
      user.ut_line[i] = 0;
*/
  /*
  strcpy(pcName,ttyname(0)+5);
  */
  strcpy(pcName,ttyname(2)+5);

  while(1){
      pstUser = getutxent();
      if(pstUser == NULL ) break;
/*
      cftime(caBuf,"%m-%d-%Y %H:%M:S",&pstUser->ut_tv.tv_sec);	
      printf("uname:[%10s],tname:[%s],address:[%13s],time=[%s]\n",
             pstUser->ut_name,pstUser->ut_line,pstUser->ut_host,caBuf);
*/
      if (strcmp(pcName,pstUser->ut_line) == 0){
          if ((strlen(pstUser->ut_host) <= 10) && 
              (strlen(pstUser->ut_host) > 0)){
              strcpy(pcName,pstUser->ut_host);
          }
/*
          printf("ttyname/hostname:[%s/%s=%s]\n",pstUser->ut_line,
                  pstUser->ut_host, pcName);
*/
          sprintf(g_caMsg,"get_dev_host_name:ttyname/hostname:[%s/%s=%s]",
                  pstUser->ut_line,pstUser->ut_host,pcName);
          ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
          break;
      }
  }
 
  return(0);

}
#endif

#ifdef SCO_UNIX
char  *crypt(const char *,const char *);  /* Add 11/07 for SCO UNIX*/

char *
crypt(const char *pcaPassWord, const char *pcaCryptId)
{
  int  i,j;
  static char caCryPass[128];
  char caHdlPass[128];
  char caRecPass;

  memset(caCryPass,'\0',sizeof(caCryPass));
  memset(caHdlPass,'\0',sizeof(caHdlPass));
  memcpy(caCryPass,pcaCryptId,2);

  if(strlen(pcaPassWord) > 11) {
    memcpy(caHdlPass,pcaPassWord,10);
  }
  else {
    memcpy(caHdlPass,pcaPassWord,strlen(pcaPassWord));

    for(i=0,j=1;i<11,j<12;i+=2,j+=2) {
     if(caHdlPass[i] == '\0')
       caHdlPass[i] = '5';
     if(caHdlPass[j] == '\0')
       caHdlPass[j] = 'F';
    }

  }

  for(i=0,j=10;i<10,j>5;i+=2,--j) {
    caRecPass=caHdlPass[i];
    caHdlPass[i]=caHdlPass[j];
    caHdlPass[j]=caRecPass;
  }

  for(i=0;i<11;i++) {

    if ( (caHdlPass[i] >= 48) && (caHdlPass[i] <= 57) ) {
      caHdlPass[i] = caHdlPass[i] -  '0' + 'e' ;
    }
    else if ( (caHdlPass[i] >= 65) && (caHdlPass[i] <= 90) )  {
      caHdlPass[i] = caHdlPass[i] -  'A' + 'a' + pcaCryptId[0] - '0';
      if ( caHdlPass[i] > 'z' ) {
        caHdlPass[i] = caHdlPass[i] -  'z' + 'a';
      }
    }
    else if ( (caHdlPass[i] >= 97) && (caHdlPass[i] <= 122) )  {
      caHdlPass[i] = caHdlPass[i] -  'a' + 'A' + pcaCryptId[1] - '0';
      if ( caHdlPass[i] > 'Z' ) {
        caHdlPass[i] = caHdlPass[i] -  'Z' + 'A';
      }
    }

  }

  memcpy(&(caCryPass[2]),caHdlPass,11);
  caCryPass[13] = '\0';
  return(caCryPass);
}
#endif
