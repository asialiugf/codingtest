#include <stdio.h>

char *UtlProdName();
char *UtlProdVerId();

main()
{
    printf ("%s\n%s\n", UtlProdName(), UtlProdVerId());
}
