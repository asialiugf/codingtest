CWA_H=$(III_DIR)/iii/pgm/com/inc/cwa.h \
	$(III_DIR)/iii/pgm/com/inc/tmc.h

TWA_H=$(III_DIR)/iii/pgm/tms/inc/twa.h \
	$(III_DIR)/iii/pgm/tms/inc/ucp.h

TMS_H=$(III_DIR)/iii/pgm/tms/inc/tms.h \
	$(III_DIR)/iii/pgm/tms/inc/ucp.h

TMCINEDT_H=$(III_DIR)/iii/pgm/tms/inc/tmcinedt.h \
	$(III_DIR)/iii/pgm/tms/inc/imctblld.def \
	$(III_DIR)/iii/pgm/tms/inc/imctblld.str \
	$(III_DIR)/iii/pgm/tms/inc/itctblof.str \
	$(III_DIR)/iii/pgm/tms/inc/itctxnld.def \
	$(III_DIR)/iii/pgm/tms/inc/ucp.h 

UPCOMTWA_H=$(III_DIR)/iii/pgm/tms/inc/upcomtwa.h \
	$(III_DIR)/iii/pgm/tms/inc/ucp.h

EMCMONTH_H=$(III_DIR)/iii/pgm/ems/inc/emcmonth.h \
	$(III_DIR)/iii/pgm/ass/inc/asscal.h

LGCLGFMT_H=$(III_DIR)/iii/pgm/log/inc/lgclgfmt.h \
	$(III_DIR)/iii/pgm/log/inc/lgcopewa.h \
	$(CWA_H) \
	$(TWA_H) 

LGCLGFMT_H_OLD=$(III_DIR)/iii/pgm/log/inc/lgclgfmt.h.old \
	$(CWA_H) \
	$(TWA_H) 

ITCFLEFM=$(III_DIR)/iii/pgm/parser/inc/itcflefm \
	$(III_DIR)/iii/pgm/parser/inc/itctxnld.def.old
