itoa(n,s)
char *s;
int n;
{
     int i;
     i=0;
     do  {
         *(s+i) = n % 10 + '0';
         i++;
     }   while ((n /= 10) >0);
     *(s+i) = '\0';
     reverse(s);
}

itoa1(n,s,len)
int n,len;
char *s;
{
 int i,j;

 itoa(n,s);
 i=strlen(s);
 if (i == len) {
   return(0); 
 }
 else {
   for ( j=i; j >= 0; j-- ) 
     s[len-i+j]=s[j];
   while ( (len-i+j) >= 0 ) {
     s[len-i+j]='0';
     j--;
   }
 }
}

reverse(s)
char *s;
{
     int   i, j;
     char  c;

     for (i = 0, j = strlen(s) - 1 ; i < j ; i++, j--) {
          c = *(s+i);
          *(s+i) = *(s+j);
          *(s+j) = c;
     }
}
 
/*
atoi(s)
char *s;
{
   int  n, i ;
   n = 0 ;
   for(i = 0; *(s+i) != '\0' && *(s+i) != ' '; i++) {
       n = n * 10 + *(s+i) - '0' ;
   }
   return(n);
}
*/

isalnum(c)
char c;
{
  if ( ((c >= '0') && (c <= '9')) || ((c >= 'a') && (c <= 'z'))
       || ((c >= 'A') && (c <= 'Z')) )
    return(1);
  else
    return(0);
}

/*********************************************************************/
/* check the string which contain any non-decimal character.         */
/* 0 --> all characters are in '0' ~ '9'                             */
/* 1 --> some characters are not in '0' ~ '9'                        */
/*********************************************************************/
isdcmnl(c)
char *c;
{
  int i,len;
  len=strlen(c);
  for (i=0; i<len; i++) {
    if ( (c[i] < '0') || (c[i] > '9') )
      return(1);
  }
  return(0);
}
