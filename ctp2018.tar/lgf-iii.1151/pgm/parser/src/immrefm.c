/*& PROGRAM-NAME:immrefm.c                                                  */
/*& This program reformat gud_file, help_file, mst to binary file format    */
#define MAIN_PROGRAM 1
#include <stdio.h>
#include <fcntl.h>
#include <ctype.h>
#include "errlog.h"
#include "imctblld.def"
#include "imctblld.str"
#include "diff.def"
#include "file.def"
#define  FILE_NAME_LEN          80
char     DF_config[FILE_NAME_LEN];
char  GUD_FILE_DAT[FILE_NAME_LEN];           
char  GUD_FILE[FILE_NAME_LEN];               
char  MST_SRC[FILE_NAME_LEN];               
char  MST_SORT[FILE_NAME_LEN];             
char  MST_BINARY[FILE_NAME_LEN];          
char  HELP_FILE_DAT[FILE_NAME_LEN];      
char  HELP_FILE[FILE_NAME_LEN];         
extern int errno;

main(argc,argv)
int argc;
char *argv[];
{
  int  rc;
  char *cmgpath;

  if (argc == 2)  {
    cmgpath = getenv("DBP_CDIR");
    sprintf(GUD_FILE_DAT,"%s/%s",cmgpath,GFD);
    sprintf(GUD_FILE,"%s/%s",cmgpath,GFB);
    sprintf(MST_SRC,"%s/%s",cmgpath,MSRC);
    sprintf(MST_SORT,"%s/%s",cmgpath,MSOR);
    sprintf(MST_BINARY,"%s/%s",cmgpath,MST);
    sprintf(HELP_FILE_DAT,"%s/%s",cmgpath,HFD);
    sprintf(HELP_FILE,"%s/%s",cmgpath,HFB);
  }
  else if (argc == 3) {
    sprintf(GUD_FILE_DAT,"%s/%s",argv[2],GFD);
    sprintf(GUD_FILE,"%s/%s",argv[2],GFB);
    sprintf(MST_SRC,"%s/%s",argv[2],MSRC);
    sprintf(MST_SORT,"%s/%s",argv[2],MSOR);
    sprintf(MST_BINARY,"%s/%s",argv[2],MST);
    sprintf(HELP_FILE_DAT,"%s/%s",argv[2],HFD);
    sprintf(HELP_FILE,"%s/%s",argv[2],HFB);
  }
  else {
    printf("Usage:%s argument1 argument2\n",argv[0]);
    printf("      where argument1 is following value\n");
    printf("      g : parser gud.dat file\n");
    printf("      h : parser hlp.dat file\n");
    printf("      m : parser mst.src file\n");
    printf("      where argument2 is optional\n");
    printf(" argument2 used whenever need a seperate AP business parser!\n");
    printf(" argument2 not used when a merging AP businesses parser!\n");
    exit(0);
  }

  if ( (argc != 2) && (argc != 3) ) {
    printf("Usage:%s argument1 argument2\n",argv[0]);
    printf("      where argument1 is following value\n");
    printf("      g : parser gud.dat file\n");
    printf("      h : parser hlp.dat file\n");
    printf("      m : parser mst.src file\n");
    printf("      where argument2 is optional\n");
    printf(" argument2 used whenever need a seperate AP business parser!\n");
    printf(" argument2 not used when a merging AP businesses parser!\n");
    exit(0);
  }
  else {
    switch (argv[1][0]) {
      case 'g':
               imfgdtrf();
               break;
      case 'h':
               imfhlp();
               break;
      case 'm':
               imfmstrf();
               break;
      default :printf("Invalid argument=%c\n",argv[1][0]);
               printf("Usage:%s argument1 argument2\n",argv[0]);
               printf("      where argument1 is following value\n");
               printf("      g : parser gud.dat file\n");
               printf("      h : parser hlp.dat file\n");
               printf("      m : parser mst.src file\n");
               printf("      where argument2 is optional\n");
               printf(" argument2 used whenever need a seperate AP business parser!\n");
               printf(" argument2 not used when a merging AP businesses parser!\n");
               exit(0);
    }   /* FOR switch */
  }  /* FOR if (argc != 2) */
/* added by alexwu on 19950412 BEGIN */
  exit(0);
/* added by alexwu on 19950412 END */
}

imfhlp()
{
  int  rc;
  FILE  *fp;
  int   fp1;
  struct help_node hlp_buf,hlp_buf1;
  int   j;
  int   node_cnt;
  char  temp_id[GUD_NO_LEN+1];
  char  hlp_type[2],x_cor[3],y_cor[3],len[3],width[3];
  int   x,y,w_len,w_width;

  /* TCC 
  printf("begin to transform %s to %s !\n",HELP_FILE_DAT,HELP_FILE);
  */

  fp = fopen(HELP_FILE_DAT, "r");
  if  (fp == NULL) {
      printf("HELP-DATA FILE OPEN ERROR\n");
      return(-1);
  }
  if ( (fp1=open(HELP_FILE,O_CREAT|O_TRUNC|O_RDWR,0666)) == -1 ) {
      printf("HELP reformat file open error !\n");
      return(-1);
  }
  node_cnt = 0;
  memset(&hlp_buf,' ',sizeof(hlp_buf));
  memset(temp_id,' ',GUD_NO_LEN+1);
  while ((fgets((char *)(&hlp_buf), sizeof(hlp_buf), fp)) != NULL) {
     node_cnt++;
     strncpy(hlp_buf1.hlp_no, hlp_buf.hlp_no, GUD_NO_LEN);
     hlp_buf1.hlp_no[GUD_NO_LEN]='\0';
     strncpy(hlp_buf1.hlp_line, hlp_buf.hlp_line,GUD_LINE_LEN);
     hlp_buf1.hlp_line[strlen(hlp_buf1.hlp_line)-1] = '\0';
     if ( strcmp(temp_id,hlp_buf1.hlp_no) != 0 ) {
         strcpy(temp_id,hlp_buf1.hlp_no);
         j=0;
         while ( hlp_buf1.hlp_line[j] == ' ' ) {
            j++;
         }
         hlp_type[0]=hlp_buf1.hlp_line[j++];
/* modified by wjc 1994.12.16 begin */
         hlp_type[1]='\0';
/* modified by wjc 1994.12.16 end*/
         if ( (hlp_type[0] != '0') && (hlp_type[0] != '1') &&
              (hlp_type[0] != '2') ) {
            printf("line %d:invalid online help type error, -->%c\n",node_cnt
                   ,hlp_type[0]);
            fclose(fp);
            close(fp1);
            return(-1);
         }
         while ( hlp_buf1.hlp_line[j] == ' ' ) {
            j++;
         }
         if ( get_n_token(hlp_buf1.hlp_line,&j,x_cor) != 0 ) {
            printf("get x error !\n");
            fclose(fp);
            close(fp1);
            return(-1);
         }
         x=atoi(x_cor);
         if ( get_n_token(hlp_buf1.hlp_line,&j,y_cor) != 0 ) {
            printf("get y error !\n");
            fclose(fp);
            close(fp1);
            return(-1);
         }
         y=atoi(y_cor);
         if ( get_n_token(hlp_buf1.hlp_line,&j,len) != 0 ) {
            printf("get len error !\n");
            fclose(fp);
            close(fp1);
            return(-1);
         }
         w_len=atoi(len);
         if ( get_n_token(hlp_buf1.hlp_line,&j,width) != 0 ) {
            printf("get width error !\n");
            fclose(fp);
            close(fp1);
            return(-1);
         }
         w_width=atoi(width);
         sprintf(hlp_buf1.hlp_line,"%s%s%s%s%s",hlp_type,x_cor,y_cor,len,
                 width);
         if ( x+w_width > 80 ) {  /* rigth margin of the screen */
           printf("online help window exceeds the screen's right margin\n");
           printf("help_id=%s x=%d, window width=%d\n",hlp_buf1.hlp_no,x,
                  w_width);
           fclose(fp);
           close(fp1);
           return(-1);
         }
         if ( y+w_len > 24 ) {  /* bottom margin of the screen */
           printf("online help window exceeds the screen's bottom line\n");
           printf("help_id=%s y=%d, window length=%d\n",hlp_buf1.hlp_no,y,
                  w_len);
           fclose(fp);
           close(fp1);
           return(-1);
         }
     }
     else {
         if ( strlen(hlp_buf1.hlp_line) > (w_width-2) ) {
           printf("The length of the help content exceeds the window width!\n");
           printf("help_id=%s width of the window=%d\n",hlp_buf1.hlp_no,w_width);
           printf("help_content=%s len=%d\n",hlp_buf1.hlp_line,
                  strlen(hlp_buf1.hlp_line));
           fclose(fp);
           close(fp1);
           return(-1);
         }
     }
     write(fp1,&hlp_buf1,sizeof(hlp_buf1));
     memset(&hlp_buf,' ',sizeof(hlp_buf));
  }

  /* TCC */
  printf ("\"%s\" is generated !\n", HELP_FILE);
  fclose(fp);
  close(fp1);
}

get_n_token(d_str,pos,dest)
char *d_str,*dest;
int  *pos;
{
   if ( isdigit(d_str[*pos])  ) {
     if ( isdigit(d_str[(*pos)+1]) ) {
        dest[0]=d_str[(*pos)];
        dest[1]=d_str[(*pos)+1];
        (*pos)+=2;
     }
     else {
        dest[0]='0';
        dest[1]=d_str[(*pos)];
        (*pos)+=1;
     }
     while ( d_str[(*pos)] == ' ' ) {
        (*pos)++;
     }
     dest[2]='\0';
     return(0);
   }
   else {
     return(-1);
   }
}

imfgdtrf()
{
  int  rc;
  FILE  *fp;
  int   fp1;
  struct gud_node gud_buf,gud_buf1;
  int   j;
  int   node_cnt;

  /* TCC 
  printf("begin to transform %s to %s !\n",GUD_FILE_DAT,GUD_FILE);
  */

  fp = fopen(GUD_FILE_DAT, "r");
  if  (fp == NULL) {
      printf("GUIDE LINE FILE OPEN ERROR\n");
      return(-1);
  }
  if ( (fp1=open(GUD_FILE,O_CREAT|O_TRUNC|O_RDWR,0666)) == -1 ) {
      printf("GUIDE LINE reformat file open error !\n");
      return(-1);
  }
  node_cnt = 0;
  memset(&gud_buf,' ',sizeof(gud_buf));
  while ((fgets((char *)(&gud_buf), sizeof(gud_buf), fp)) != NULL) {
        strncpy(gud_buf1.gud_no, gud_buf.gud_no, GUD_NO_LEN);
        gud_buf1.gud_no[GUD_NO_LEN]='\0';
        strncpy(gud_buf1.gud_line, gud_buf.gud_line,GUD_LINE_LEN);
        gud_buf1.gud_line[strlen(gud_buf1.gud_line)-1] = '\0';
/*
        printf("write count=%d\n",write(fp1,&gud_buf1,sizeof(gud_buf1)));
*/
        write(fp1,&gud_buf1,sizeof(gud_buf1));
        memset(&gud_buf,' ',sizeof(gud_buf));
  }

  /* TCC */
  printf("\"%s\" is generated !\n", GUD_FILE);
  fclose(fp);
  close(fp1);
}
imfmstrf()
{
  int  rc;
  FILE  *fp;
  int   fp1;
  struct mst_node mst_buf,mst_buf1;
  int   j;
  int   node_cnt;
  static char  sys_buf[128];

  /* TCC 
  printf("begin to transform %s to %s!\n",MST_SRC,MST_BINARY);
  */

  sprintf(sys_buf,"sort -d < %s > %s",MST_SRC,MST_SORT);
  system(sys_buf);
  fp = fopen(MST_SORT, "r");
  if  (fp == NULL) {
      printf("%s file open error,errno=%d\n",MST_SORT,errno);
      return(-1);
  }
  if ( (fp1=open(MST_BINARY,O_CREAT|O_TRUNC|O_RDWR,0666)) == -1 ) {
      printf("%s reformat file open error,errno=%d\n",MST,errno);
      return(-1);
  }
  node_cnt = 0;
  memset(&mst_buf,' ',sizeof(mst_buf));
  while ((fgets((char *)(&mst_buf), sizeof(mst_buf), fp)) != NULL) {
        memcpy(mst_buf1.mst_no, mst_buf.mst_no, MST_NO_LEN);
        strncpy(mst_buf1.mst_cont, mst_buf.mst_cont,MST_CONT_LEN);
        mst_buf1.mst_cont[strlen(mst_buf1.mst_cont)-1] = '\0';
/*
        printf("write count=%d\n",write(fp1,&mst_buf1,sizeof(mst_buf1)));
*/
        write(fp1,&mst_buf1,sizeof(mst_buf1));
        memset(&mst_buf,' ',sizeof(mst_buf));
  }

  /* TCC */
  printf ("\"%s\" is generated !\n", MST_BINARY);
  fclose(fp);
  close(fp1);
}
