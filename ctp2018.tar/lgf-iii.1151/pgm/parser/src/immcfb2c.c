/* -------------------------------------- */
/*    ctf item table loading program      */
/* -------------------------------------- */
#include    <stdio.h>
#include    "errlog.h"
#include    "itcflefm"
#include    "itctblof"
#include    "itctxnld"
#include "diff.def"
#include "file.def"
#define  FILE_NAME_LEN          80

char  CTF_FILE[FILE_NAME_LEN];               
char  CTF_FILE_DOS[FILE_NAME_LEN];               
FILE *c_fp;

main(argc,argv)
int argc;
char **argv;
{
   char *tblpath;



   tblpath = getenv("DBP_TDIR");
   sprintf(CTF_FILE,"%s/%s",tblpath,CF);
   sprintf(CTF_FILE_DOS,"%s/%s",tblpath,CFD);
/*
    if (argc < 2 )
       {
        printf("Usage:%s ctf_file\n",argv[0]);
        exit(1);
       }
    c_fd = open(argv[1], O_RDONLY);
*/
    /* ------------------- */
    /*    open ctf file    */
    /* ------------------- */
    c_fd = open(CTF_FILE, O_RDONLY);
    if (c_fd < 0) {
      printf("\n ctf file can't not open for input !");
      printf("\n file status = %d,errno=%d\n", c_fd,errno);
      exit(1);
    };
    c_fp = fopen(CTF_FILE_DOS, "w");
    if (c_fp == NULL) {
      printf("\n ctf_file.dos can't not open for output,errno=%d\n",errno);
      exit(1);
    };
    tbl_crt();
    /* -------------------- */
    /*    close ctf file    */
    /* -------------------- */
    close(c_fd);
    fclose(c_fp);
    printf("create %s O.K.\n",CTF_FILE_DOS);
}

tbl_crt()
{
    while((rc = read(c_fd, ctf_rd_buf, sizeof(ctf_head))) > 0) {
       if (ctf_rd_buf[0] == M_CTF_HEAD) {
          busi_estl();
       }
       else {
          item_estl();
       };
    };
}

busi_estl()
{
    /* ----------------------------- */
    /*    establish business node    */
    /* ----------------------------- */
    ctf_hd = (ctf_head *)ctf_rd_buf;
    /* -------------------------------- */
    /*    copy ctf_head to busi_node    */
    /* -------------------------------- */
    fprintf(c_fp,"%c %c %d %d\n",
            ctf_hd->rec_head,
            ctf_hd->busi_type,
            ctf_hd->tot_item,
            ctf_hd->ctf_size);
}

item_estl()
{
    ctf_im = (ctf_item *)ctf_rd_buf;

    /* ------------------------------- */
    /*    copy ctf_item to tbl_item    */
    /* ------------------------------- */
    if (ctf_im->ini_value == ' ')   ctf_im->ini_value = '@';
    if (ctf_im->ini_value == 0x0)   ctf_im->ini_value = '0';
    fprintf(c_fp,"%.31s %c %d %d %d %c\n",
           ctf_im->ctf_name,
           ctf_im->dat_type,
           ctf_im->dat_len,
           ctf_im->ctf_relat,
           ctf_im->dot_pos,
           ctf_im->ini_value);
/*
    fprintf(c_fp,"%.31s %c %d %d %d %d %d %c\n",
           ctf_im->ctf_name,
           ctf_im->dat_type,
           ctf_im->dat_len,
           ctf_im->ctf_len,
           ctf_im->ctf_offs,
           ctf_im->ctf_relat,
           ctf_im->dot_pos,
           ctf_im->ini_value);
*/
}
