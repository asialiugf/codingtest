#define MAIN_PROGRAM 1
#include "errlog.h"
#include "imctxnpr.def"
#include "lxcpgdef.def"
#include "diff.def"
#include "file.def"

char curr_busi;               /* record the current business type parser read */
char curr_txnid[TXN_LEN+1];   /* record the current txn-id parser read */
char curr_pgno[PG_LEN+1];     /* record the current page-no parser read */
char curr_row[ROW_LEN+1];     /* record the current row-no parser read */
char curr_col[COL_LEN+1];     /* record the current column-no parser read */
char err_buf[100];
int  item_cnt;              /* record the item number of a transaction */
int  curr_item_cnt;         /* record the current item number */
extern int errno;
#define  FILE_NAME_LEN          80
char     DF_config[FILE_NAME_LEN];
char  GUD_FILE_DAT[FILE_NAME_LEN];           
char  TXN_DATAFILE[FILE_NAME_LEN];           
char  TXN_FILE[FILE_NAME_LEN];               
char  TXN_ERR_FILE[FILE_NAME_LEN];               
char  TXN_FILE_TMP[FILE_NAME_LEN];             
char  MENU_CROSSCHK_FILE[FILE_NAME_LEN];          
char  CTF_FILE[FILE_NAME_LEN];      
char  ERR_FILE[FILE_NAME_LEN];      

main(argc,argv)
int argc;
char *argv[];
{
  int  rc;
  char *tblpath;
  char *cmgpath;
  char caLogName[256];

  if (argc == 2) {
    tblpath = getenv("DBP_TDIR");
    cmgpath = getenv("DBP_CDIR");
    sprintf(GUD_FILE_DAT,"%s/%s",cmgpath,GFD);
    sprintf(TXN_DATAFILE,"%s/%s",tblpath,TFD);
    sprintf(TXN_FILE,"%s/%s",tblpath,TFB);
    sprintf(TXN_ERR_FILE,"%s/%s",tblpath,TFE);
    sprintf(TXN_FILE_TMP,"%s/%s",tblpath,TFT);
    sprintf(MENU_CROSSCHK_FILE,"%s/%s",tblpath,MCF);
    sprintf(CTF_FILE,"%s/%s",tblpath,CF);
    sprintf(ERR_FILE,"%s/%s",tblpath,EF);
  }
  else if (argc ==3) {
    sprintf(GUD_FILE_DAT,"%s/%s",argv[2],GFD);
    sprintf(TXN_DATAFILE,"%s/%s",argv[2],TFD);
    sprintf(TXN_FILE,"%s/%s",argv[2],TFB);
    sprintf(TXN_ERR_FILE,"%s/%s",argv[2],TFE);
    sprintf(TXN_FILE_TMP,"%s/%s",argv[2],TFT);
    sprintf(MENU_CROSSCHK_FILE,"%s/%s",argv[2],MCF);
    sprintf(CTF_FILE,"%s/%s",argv[2],CF);
    sprintf(ERR_FILE,"%s/%s",argv[2],EF);
  }
  else {
    printf("Usage:%s argument1 argument2\n",argv[0]);
    printf("      where argument1 is following value\n");
    printf("      1 : first  phase of the txn_file parser\n");
    printf("      2 : second phase of the txn_file parser\n");
    printf("      3 : first & second phase of the txn_file parser\n");
    printf("      where argument2 is optional\n");
    printf(" argument2 used whenever need a seperate AP business parser!\n");
    printf(" argument2 not used when a merging AP businesses parser!\n");
    exit(0);
  }

  strcpy(DF_config    ,"../TABLE/config.dat");
  sig_hdl();
  sprintf(caLogName, "%s/iii/log/par_errlog", getenv("III_DIR") );
  ChgLog(LOG_CHG_MODE,"1");
  ChgLog(LOG_CHG_LOG,caLogName);
  if ((argc != 2) && (argc != 3)) {
    printf("Usage:%s argument1 argument2\n",argv[0]);
    printf("      where argument1 is following value\n");
    printf("      1 : first  phase of the txn_file parser\n");
    printf("      2 : second phase of the txn_file parser\n");
    printf("      3 : first & second phase of the menu_file parser\n");
    printf("      where argument2 is optional\n");
    printf(" argument2 used whenever need a seperate AP business parser!\n");
    printf(" argument2 not used when a merging AP businesses parser!\n");
    exit(0);
  }
  else {
    switch (argv[1][0]) {
      case '1':
               rc = txn_file_par(1);        /* first phase of the parser */
               break;
      case '2':
               rc = txn_file_par(2);        /* second phase of the parser */
               break;
      case '3':
               rc = txn_file_par(1);   /* first phase of the parser */
               if (rc == 0)
                  {
                  rc = txn_file_par(2);     /* second phase of the parser */
                  }
               break;
      default :printf("Invalid Argument %c\n",argv[1][0]);
               printf("Usage:%s argument1 argument2\n",argv[0]);
               printf("      where argument1 is following value\n");
               printf("  1 : first  phase of the txn_file parser\n");
               printf("  2 : second phase of the txn_file parser\n");
               printf("  3 : first & second phase of the menu_file parser\n");
               printf("      where argument2 is optional\n");
               printf(" argument2 used whenever need a seperate AP business parser!\n");
               printf(" argument2 not used when a merging AP businesses parser!\n");
               exit(0);
    } /* FOR switch (argv[1][0]) */
    exit(rc);
  }
}
