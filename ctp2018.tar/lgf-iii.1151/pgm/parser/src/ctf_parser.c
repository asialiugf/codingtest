#include <stdio.h>
#include <fcntl.h>
#include "itcflefm"
#include "itctblpt"
#include "ctf_file.h"
#include "ctf_file.glb"
#include "diff.def"
#include "file.def"
#define  FILE_NAME_LEN          80
char  CTF_FILE[FILE_NAME_LEN];               
char  CTF_BOOK[FILE_NAME_LEN];               
char  CTF_ERR_FILE[FILE_NAME_LEN];            

ctf_node *headp,*tempp,*tailp;
main(argc,argv)
int argc;
char *argv[];
{
   FILE *fp;
   char str[512];
   char *malloc();
   char *token[100];
   char c;
   char first ;
   int i,k,rec_len;
   int token_no;
   int ret;
   ctf_node *ptr1;
   ctf_node *ptr2;
   char *tblpath;


   if (argc == 1) {
     tblpath = getenv("DBP_TDIR");
     sprintf(CTF_FILE,"%s/%s",tblpath,CF);
     sprintf(CTF_BOOK,"%s/%s",tblpath,CTFB);
     sprintf(CTF_ERR_FILE,"%s/%s",tblpath,EF);
   }
   else if (argc ==2) {
     sprintf(CTF_FILE,"%s/%s",argv[1],CF);
     sprintf(CTF_BOOK,"%s/%s",argv[1],CTFB);
     sprintf(CTF_ERR_FILE,"%s/%s",argv[1],EF);
   }
   else {
     printf("The input argument error!!\n");
     exit(-1);
   }

   /* set initial value of variable and tables */
   first='n';
   g_idx=0;
   ctf_offs_cnt=0;
   bus_type='\0';
   ctf_line=0;
   itm_seq=0;
   ctf_w_cnt=0;
   ctf_fp=file_open(CTF_FILE);
   if((err_fp=fopen(CTF_ERR_FILE,"w")) == NULL)
   {
       fprintf(stderr,"cant open the err_file");
       fprintf(stderr,"CTF_ERR_FILE = %s", CTF_ERR_FILE);
       exit(0);
   }

   headp=tailp=tempp=NULL;
   if((fp=fopen(CTF_BOOK,"r")) == NULL)
   {
       fprintf(stderr,"cant open the copybook file");
       exit(0);
   }

   for(i=0;i<512;i++)
      str[i]=' ';
   i=0;
   while((ret=cget_rec(fp,str,0))!=EOF)
   {
      if(ret==-2)
         continue;
      ctf_line++;
         
      for(i=0;i<6;i++)
        dtype_area[i]=' ';
      dtype_area[i]='\0';
      prs_err(str);

      cget_token(0,str,token,&token_no);
      if(first=='n')
      {
          if((i=char_index(token[0],'%',FORWARD,0))==-1)
          {
            prs_err("busi_type must be first ");
            exit(0);
          }
          else
          {
             bus_type=token[0][i+1];
             first='Y';
          }
      }

      if((i=char_index(token[0],'%',FORWARD,0))!=-1)
      {
         FORM_PROC=FALSE;
         bus_type=token[0][i+1];
         ptr1=(ctf_node *)malloc(sizeof(ctf_node));
         clr_hd_node(ptr1);
         ptr1->right=ptr1->left=NULL;
         if(token[0][i+1]=='#')
         {
             FORM_PROC=TRUE;
         }
         else
         {
            if(headp==NULL)
            {
               headp=ptr1;
               tempp=ptr1;
            }
            else
            {
               w_allbusi();       
               ctf_offs_cnt=0;
               g_idx=0;
               headp=ptr1;
               tempp=ptr1;
            }
            p_hd_token(0,token,token_no);
         }
      }
      else
      {
         itm_seq++;
         ptr2=(ctf_node *)malloc(sizeof(ctf_node));
         clr_it_node(ptr2);
         ptr2->right=ptr2->left=NULL;
         tempp->right=ptr2;
         ptr2->left=tempp;
         tempp=ptr2;
         headp->unode.hd_node.tot_item+=1;
         ptr2->unode.it_node.ctf_relat=itm_seq;
         p_im_token(0,token,token_no);
      }
      for(i=0;i<token_no;i++)
         free(token[i]);
      i++;
   }

   /* free the mem storage made by malloc() */

   w_allbusi();       
   if(fclose(fp)==EOF)
   {
      prs_err("cant close copybook file");
      exit(0);
   }
   exit(0);
/*
   prn_node();
*/
}
/*
cget_rec(fp,string,fun)
FILE *fp;
char string[];
int fun;
{
   int i,j,k;
   int c;
   int flg;

    flg=0;
    i=0;
    k=0;
    j=1;
    while((c=fgetc(fp))!='.')
    {
       k++;
       if(k==7)
       {
          if(c=='*')
          {
             while((c=fgetc(fp))!='\n');
             k=0;
             return(ABEND);
          }
          if(c!=' ')
          {
              prs_err("col 7 must be space or * ");
              exit(0);
          }
       }
       
       if(k==6)
       {
          flg=1;
          if(c!=' ')
             ini_value=c-'0';
          else
             ini_value=0;
       }

       if(k>156)
          break;
       if(c==EOF)
          return(EOF);
       /x
       if(c==' ')
          j=0;
       else
       {
         if(j==0)
           string[i++]=' ';
         j=1;
         if(flg==1)
           string[i++]=' ';
         else
           string[i++]=c;
         flg=0;
       }
       x/
         if(k==6)
           string[i++]=' ';
         else
           string[i++]=c;
    }
    string[i++]='.';
    string[i]='\0';
    return(i);
}
*/

cget_token(fun,string,token,token_no)
int  fun;
char *string;
char *token[];
int  *token_no;
{
   int i,j,k;
   char wk_area[80];
   char c;
   char *malloc();

   i=0;
   k=0;
   do {
      while(string[i]== ' '||string[i]=='\n' )
          i ++;
      j=0;
      c=string[i];
      while(c!=' '&&c!='.'&&c!='\n') {
         wk_area[j]=string[i];
         i++;
         j++;
         c=string[i];
      }
      wk_area[j]='\0';

      token[k]=(char *)malloc(strlen(wk_area)+1);
      strcpy(token[k],wk_area);
      k++;
   } while(string[i]!='.');
   *token_no=k;
}

clr_hd_node(ptr)
ctf_node *ptr;
{
   int i;
   ptr->unode.hd_node.rec_head=' ';
   ptr->unode.hd_node.busi_type=' ';
   ptr->unode.hd_node.ctf_size=0;
   ptr->unode.hd_node.tot_item=0;
   for(i=0;i<27;i++)
      ptr->unode.hd_node.filler[i]=' ';

}

clr_it_node(ptr)
ctf_node *ptr;
{
   int i;
   for(i=0;i<21;i++)
      ptr->unode.it_node.ctf_name[i]=' ';
   ptr->unode.it_node.dat_type=' ';
   ptr->unode.it_node.dat_len=0;
   ptr->unode.it_node.ctf_len=0;
   ptr->unode.it_node.ctf_offs=0;
   ptr->unode.it_node.ctf_relat=0;
   ptr->unode.it_node.dot_pos=0;
   ptr->unode.it_node.ini_value=ini_value;
}
   
   
p_hd_token(fun,token,token_no)
int fun;
char *token[];
int token_no;
{
   ctf_node *lptr;
   int i;

   lptr=tempp;
   lptr->unode.hd_node.rec_head='*';
   /*
   lptr->unode.hd_node.busi_type=token[0][1];
   */
   lptr->unode.hd_node.busi_type=bus_type;
   bus_type='\0';
   lptr->unode.hd_node.ctf_size=0;
   lptr->unode.hd_node.tot_item=0;
   for(i=0;i<27;i++)
      lptr->unode.hd_node.filler[i]=' ';

   /* write name ptr,group_len,.. to stack
   grp_len_stk[g_idx].label_no=0;
   grp_len_stk[g_idx].gp      =tempp;
   grp_len_stk[g_idx].gp_flg  =BUSITYPE;
   g_idx++;
   */
   if((busi_where=lseek(ctf_fp,0L,1))==-1) /* save file current position */
   {
      printf("lseek error ! \n");
      exit(0);
   }
   w_ctf_node(lptr);
}

p_im_token(fun,token,token_no)
int fun;
char *token[];
int token_no;
{
   ctf_node *mptr,*ptr;
   int red_idx,pic_idx,pack_idx,bin_idx;
   int len,k,len1;
   int labno;

   dot_posit=0; /* added by wu for initial dot position in any data type */
   red_idx=pic_idx=pack_idx=bin_idx=0;
   mptr=tempp;
   for(k=0;k<token_no;k++)
   {
       if(strcmp("PIC",token[k])==0)
          pic_idx=k;
       if(strcmp("REDEFINES",token[k])==0)
          red_idx=k;
       if(strcmp("COMP-3",token[k])==0)
       {
          dtype_area[2]='p';
          pack_idx=k;
       }
       if(strcmp("COMP",token[k])==0)
       {
          dtype_area[3]='b';
          bin_idx=k;
       }
    }
   /*printf("123mptr->unode.it_node.ctf_name%s\n",token[1]);*/
   strcpy(mptr->unode.it_node.ctf_name,token[1]);
   mptr->label_no = -1; /* add by wu for initial label for redefined item */
   if(red_idx!=0)     /* redefine is on */
   {
      if(pic_idx==0)  /* redefine and group */
      {
         ptr=mptr->left;
         while(ptr!=NULL)
         {
            if(strcmp(ptr->unode.it_node.ctf_name,token[red_idx+1])==0)
            {
               mptr->unode.it_node.ctf_len=ptr->unode.it_node.ctf_len;
               mptr->unode.it_node.dat_len=ptr->unode.it_node.ctf_len;
               len_to_stk(1,ptr->unode.it_node.ctf_len);
               mptr->unode.it_node.ctf_offs=ptr->unode.it_node.ctf_offs;
               mptr->unode.it_node.dat_type='y';
               ctf_offs_cnt=ptr->unode.it_node.ctf_offs;
               break;
            }
            else
               ptr=ptr->left;
         }
         if(ptr==NULL)
            prs_err("can not find the redefined item ");
      }
      else
      {
         len=get_pic_len(token[pic_idx+1]);
         ptr=mptr->left;
         while(ptr!=NULL)
         {
            len1=strlen(ptr->unode.it_node.ctf_name);
            /*printf("123ctf_name =%s,srh ctf_name=%s\n",
                   ptr->unode.it_node.ctf_name,token[red_idx+1]);*/
            if(strcmp(ptr->unode.it_node.ctf_name,token[red_idx+1])==0)
/*
            if(strncmp(ptr->unode.it_node.ctf_name,token[red_idx+1],len1)==0)
*/
            {
               /*
               mptr->unode.it_node.ctf_len=len;
               mptr->unode.it_node.dat_len=len;
               */
               cal_len(len);
               mptr->unode.it_node.ctf_offs=ptr->unode.it_node.ctf_offs;
               mptr->unode.it_node.dot_pos=dot_posit;
               ctf_offs_cnt=ptr->unode.it_node.ctf_offs;
               ctf_offs_cnt+=mptr->unode.it_node.ctf_len;
               break;
            }
            else
               ptr=ptr->left;
         }
         if(ptr==NULL)
         {
            printf("can not find the redefined name \n");
            exit(0);
         }
      }
   }
   else if(pic_idx==0)            /* group type */
   {
      labno=atoi(token[0]);       /* another group enter */

      /*printf("group 123labno=%d\n",labno);*/
      ptr=tempp->left;
      while(ptr!=headp)
        {
          /*printf("123ptr->label_no=%d\n",ptr->label_no);*/
          /*printf("123ptr->unode.it_node.ctf_name=%s\n",
                 ptr->unode.it_node.ctf_name);*/
          if(labno==ptr->label_no)
          {
              wrrmgp(ptr);        /* write & remove all group data */
              pop(labno);         /* pop the group len stack       */
              break;
          }
          else
              ptr=ptr->left;
        } 
        
      strcpy(grp_len_stk[g_idx].name,token[1]);
      /*printf("123grp_len_stk[%d].name=%s\n",g_idx,token[1]);*/
      grp_len_stk[g_idx].label_no=atoi(token[0]);
      grp_len_stk[g_idx].gp      =tempp;
      grp_len_stk[g_idx].gp_flg  =GROUP;
      g_idx++;
 
         
         
      tempp->unode.it_node.ctf_offs=ctf_offs_cnt;
      tempp->label_no=labno;
      tempp->unode.it_node.dot_pos=0;
      tempp->unode.it_node.dat_type='y';
      /*printf("tempp->unode.it_node.ctf_len=%d\n",tempp->unode.it_node.ctf_len);*/
   }
   else if (pic_idx!=0)
   {
      len=get_pic_len(token[pic_idx+1]);
      cal_len(len);                      /* cal ctf_len and chk dat_type */
      tempp->unode.it_node.ctf_offs=ctf_offs_cnt;
      tempp->unode.it_node.dot_pos=dot_posit;
      ctf_offs_cnt+=tempp->unode.it_node.ctf_len;
      /*
      if(!FORM_PROC)
         headp->unode.hd_node.ctf_size+=tempp->unode.it_node.ctf_len;
      */

      labno=atoi(token[0]);
      /*printf("123in pic_idx!=0,labno=%d\n",labno);  */
      tempp->label_no=labno;
      if(labno==tempp->left->label_no)
      {
         w_ctf_node(tempp->left);
         rm_ctf_node(tempp->left);
      }

      /*printf(" search the ctf_node to check if have same label\n" );*/
      ptr=tempp->left;
      while(ptr!=headp)
          if(labno==ptr->label_no)
          {
              wrrmgp(ptr);        /* write & remove all group data */
              pop(labno);         /* pop the group len stack       */
              break;
          }
          else
              ptr=ptr->left;

      len_to_stk(0,tempp->unode.it_node.ctf_len);
   }
      
}
prn_node()
{
   int i;
   ctf_node *p1;
   ctf_node *p2;
   p1=headp;
   printf("/*-----------------------------------------------*/\n");
   printf("/* LISTING THE ALL CTF NODE                      */\n");
   printf("/*-----------------------------------------------*/\n");

   while(p1!=NULL)
   {
       if(p1->unode.hd_node.rec_head=='*')
       {
          printf("\n");
          printf("   rec_type is business head  \n");
          printf("   business type ------ %c \n",p1->unode.hd_node.busi_type);
          printf("   ctf length    ------ %d \n",p1->unode.hd_node.ctf_size);
          printf("   tot item      ------ %d \n",p1->unode.hd_node.tot_item);

          p1=p1->right;
       }
       else
       {
          printf("\n");
          printf("   rec_type is item type head  \n");
          printf("   ctf name      ------ %s \n",p1->unode.it_node.ctf_name);
          printf("   data type     ------ %c \n",p1->unode.it_node.dat_type);
          printf("   data length   ------ %d \n",p1->unode.it_node.dat_len);
          printf("   ctf length    ------ %d \n",p1->unode.it_node.ctf_len);
          printf("   ctf  offset   ------ %d \n",p1->unode.it_node.ctf_offs);
          printf("   ctf  relat    ------ %d \n",p1->unode.it_node.ctf_relat);
          printf("   dot  position ------ %d \n",p1->unode.it_node.dot_pos);
          printf("   initial value ------ %d \n",p1->unode.it_node.ini_value);

          p1=p1->right;
       }
       printf("/*------------------------------------------------*/\n");
   }
   printf("/*-----------------------------------------------*/\n");
   printf("/* LISTING THE GROUP LENGTH STACK                */\n");
   printf("/*-----------------------------------------------*/\n");
   printf("---the g_idx value             %d \n",g_idx);
   for(i=0;i<g_idx;i++)
   {
       printf("\n");
       printf("--------stack index        %d \n",i);
       printf("--------ctf_name is        %s \n",grp_len_stk[i].name);
       printf("--------label no is        %d \n",grp_len_stk[i].label_no);
       printf("--------grp flag is        %s \n",grp_len_stk[i].gp_flg);
   }
   printf("/*-----------------------------------------------*/\n");
   printf("/* LISTING THE VARIABLE                          */\n");
   printf("/*-----------------------------------------------*/\n");
   printf("-------ctf write count     %d \n",ctf_w_cnt);
   
}

/*-----------------------------------------------------------------*/
/* below is the functions for get input length                     */
/*-----------------------------------------------------------------*/
get_pic_len(str)
char *str;
{
      int n,i,j;

      switch(str[0])
      {
       case 'X':
          dtype_area[5]='x';
          n=x_type(str);
          break;
       case '9':
          dtype_area[0]='9';
          n=nine_type(str);
          break;
       case 'S':
          dtype_area[4]='s';
          dtype_area[0]='9';
          for(i=0,j=1;str[j]!='\0';i++,j++)
             str[i]=str[j];
          str[i]='\0';
          n=nine_type(str);
          break;
       default:
          prs_err("error PIC type!");
          return(-1);
      }
      return(n);
}

x_type(str)
char *str;
{
    int i,j;
    char num[6];

     for(i=0;i<6;i++)
       num[i]='\0';

    if(str[1]!='(')
    {
       if(str[1]=='X')
       {
         j=1;
         while(str[j]!='.'&&str[j]!='\0')
            j++;
         return(j);
       }
       else
         return(1);
    }
    else
    {
       for(i=2;str[i]!=')';i++)
       {
          if(str[i]>='0'&&str[i]<='9')
             num[i-2]=str[i];
          else
          {
             prs_err("error in x type ");
             return(-1);
          }
       }
       return(atoi(num));
    }
}

nine_type(str)
char *str;
{
   int digit_1,digit_2;
   int ch;
   int i=0;

   digit_1=digit_2=dot_posit=0;
   digit_1=scan_9(str,&i);
   ch=str[i-1];
   if(ch=='(')
   {
      digit_1=get_number(str,&i);
      i++;
      ch=str[i-1];
   }
   if(ch=='V'||ch=='v')
   {
      dtype_area[1]='v';
      digit_2=scan_9(str,&i);
      ch=str[i-1];
      if(ch=='(')
         digit_2=get_number(str,&i);
      dot_posit=digit_2;
   }
   return(digit_1+digit_2);
}

scan_9(str,idx)
char *str;
int  *idx;
{
   int i=0;
   char ch;

   while((ch=str[(*idx)++])=='9')
      i++;
   return(i);
}

get_number(str,idx)
char *str;
int  *idx;
{
    static char num_string[4];
    int ch;
    int i;
    int j;

    for(j=0;j<4;j++)
        num_string[j]='\0';
    i=0;
    if((ch=str[(*idx)++])=='.'||ch=='\0')
       return(1);
    else
    {
       if(ch>='0'&&ch<='9')
       do
       {
          num_string[i++]=ch;
       } while((ch=str[(*idx)++])!=')');
       return(atoi(num_string));
    }
}

/* ----------------------------------- */
/*   convert  character  to  integer   */
/* ----------------------------------- */
atoi(s)
char *s;
{
    int  n, i;
    n = 0;
    for(i = 0; *(s+i) != '\0' && *(s+i) != ' ' && *(s+i) != '\n'; i++) {
        n = n * 10 + *(s+i) - '0';
    }
    return(n);
}
/* ----------------------------------- */
/*   convert  integer to character     */
/* ----------------------------------- */
itoa(n,s)
char s[];
int  n;
{
   int i,sign;

   if((sign=n)<0)
       n = -n;
   i=0;
   do{
       s[i++]=n%10+'0';
   }  while((n/=10) > 0);
   if(sign<0)
      s[i++]='-';
   s[i]='\0';
   reverse(s);
}

reverse(s)
char s[];
{
    int c,i,j;

    for(i=0,j=strlen(s)-1;i<j;i++,j--);
    {
       c=s[i];
       s[i]=s[j];
       s[j]=c;
    }
}

get_next(cur_pos,str)
int  *cur_pos;
char *str;
{

   return(str[(*cur_pos)++]);
}
/* ----------------------------------------------------------------- */
/*    these functions is for calculate ctf_len and check data type   */
/*-------------------------------------------------------------------*/
cal_len(len)
int len;
{
   ctf_node *mptr;
   char found,cd;
   int i;
   int g_type();
   int b_type();
   int p_type();

    static struct dtype_st{
      char *d_str;
      char d_code;
      int  (*fun)();

   } dtype_tab[]={
    {"     x",'x',g_type},
    {"     y",'y',g_type},
    {"9     ",'9',g_type},
    {"9  b  ",'b',b_type},
    {"9 p   ",'p',p_type},
    {"9   s ",'i',g_type},
    {"9  bs ",'j',b_type},
    {"9 p s ",'k',p_type},
    {"9v    ",'f',g_type},
    {"9v b  ",'g',b_type},
    {"9vp   ",'h',p_type},
    {"9v  s ",'q',g_type},
    {"9v bs ",'r',b_type},
    {"9vp s ",'t',p_type},
    {"**    "},
     };
     found='n';
     for(i=0;dtype_tab[i].d_str[0]!='*';i++)
     {
        if(strcmp(dtype_area,dtype_tab[i].d_str)==0)
        {
           found='y';
           mptr=tempp;
           cd=dtype_tab[i].d_code;
           switch(cd){
              case 'x':
                mptr->unode.it_node.dat_type='x';
                mptr->unode.it_node.dat_len =len;
                mptr->unode.it_node.ctf_len =len;
                break;
              case 'y':
                mptr->unode.it_node.dat_type='y';
                mptr->unode.it_node.dat_len =len;
                mptr->unode.it_node.ctf_len =len;
                break;
              case '9':
                mptr->unode.it_node.dat_type='9';
                mptr->unode.it_node.dat_len =len;
                mptr->unode.it_node.ctf_len =(*dtype_tab[i].fun)(len);
                if(ini_value==' ')
                   mptr->unode.it_node.ini_value ='0';
                break;
              case 'b':
                mptr->unode.it_node.dat_type='b';
                mptr->unode.it_node.dat_len =len;
                mptr->unode.it_node.ctf_len =(*dtype_tab[i].fun)(len);
                if(ini_value==' ')
                   mptr->unode.it_node.ini_value ='0';
                break;
              case 'p':
                mptr->unode.it_node.dat_type='p';
                mptr->unode.it_node.dat_len =len;
                mptr->unode.it_node.ctf_len =(*dtype_tab[i].fun)(len);
                if(ini_value==' ')
                   mptr->unode.it_node.ini_value ='0';
                break;
              case 'i':
                mptr->unode.it_node.dat_type='i';
                mptr->unode.it_node.dat_len =len+1;
                mptr->unode.it_node.ctf_len =len;
                if(ini_value==' ')
                   mptr->unode.it_node.ini_value ='0';
                break;
              case 'j':
                mptr->unode.it_node.dat_type='j';
                mptr->unode.it_node.dat_len =len+1;
                mptr->unode.it_node.ctf_len =(*dtype_tab[i].fun)(len);
                if(ini_value==' ')
                   mptr->unode.it_node.ini_value ='0';
                break;
              case 'k':
                mptr->unode.it_node.dat_type='k';
                mptr->unode.it_node.dat_len =len+1;
                mptr->unode.it_node.ctf_len =(*dtype_tab[i].fun)(len);
                if(ini_value==' ')
                   mptr->unode.it_node.ini_value ='0';
                break;
              case 'f':
                mptr->unode.it_node.dat_type='f';
                mptr->unode.it_node.dat_len =len+1;
                mptr->unode.it_node.ctf_len =len;
                if(ini_value==' ')
                   mptr->unode.it_node.ini_value ='0';
                break;
              case 'g':
                mptr->unode.it_node.dat_type='g';
                mptr->unode.it_node.dat_len =len+1;
                mptr->unode.it_node.ctf_len =(*dtype_tab[i].fun)(len);
                if(ini_value==' ')
                   mptr->unode.it_node.ini_value ='0';
                break;
              case 'h':
                mptr->unode.it_node.dat_type='h';
                mptr->unode.it_node.dat_len =len+1;
                mptr->unode.it_node.ctf_len =(*dtype_tab[i].fun)(len);
                if(ini_value==' ')
                   mptr->unode.it_node.ini_value ='0';
                break;
              case 'q':
                mptr->unode.it_node.dat_type='q';
                mptr->unode.it_node.dat_len =len+2;
                mptr->unode.it_node.ctf_len =len;
                if(ini_value==' ')
                   mptr->unode.it_node.ini_value ='0';
                break;
              case 'r':
                mptr->unode.it_node.dat_type='r';
                mptr->unode.it_node.dat_len =len+2;
                mptr->unode.it_node.ctf_len =(*dtype_tab[i].fun)(len);
                if(ini_value==' ')
                   mptr->unode.it_node.ini_value ='0';
                break;
              case 't':
                mptr->unode.it_node.dat_type='t';
                mptr->unode.it_node.dat_len =len+2;
                mptr->unode.it_node.ctf_len =(*dtype_tab[i].fun)(len);
                if(ini_value==' ')
                   mptr->unode.it_node.ini_value ='0';
                break;
              default:
                mptr->unode.it_node.dat_type='x';
                mptr->unode.it_node.dat_len =len;
                mptr->unode.it_node.ctf_len =len;
                break;
          }
       }
   }
   if (found=='n')
      prs_err("data type not allowed!");

}
g_type(len)
int len;
{
   return(len);
}
b_type(len)
int len;
{
   if(len<5)
     return(2);
   if(len>=5&&len<10)
     return(4);
   if(len>=10)
     return(8);
}
p_type(len)
int len;
{
   len=len/2 +1;
   return(len);
}

len_to_stk(fun,ctf_len)
int fun;
int ctf_len;
{
    int i;

    if(fun==0)
    {
       for(i=0;i<g_idx;i++)
       {
          if(grp_len_stk[i].gp_flg==GROUP)
          {
              grp_len_stk[i].gp->unode.it_node.ctf_len += ctf_len;
              grp_len_stk[i].gp->unode.it_node.dat_len += ctf_len;
/*
              printf("grp_len_stk[%d].gp->unode.it_node.ctf_name=%s\n",
                      i,grp_len_stk[i].gp->unode.it_node.ctf_name);
              printf("grp_len_stk[%d].gp->unode.it_node.dat_len=%d\n",
                      i,grp_len_stk[i].gp->unode.it_node.dat_len);
              printf("grp_len_stk[%d].gp->unode.it_node.ctf_len=%d\n",
                      i,grp_len_stk[i].gp->unode.it_node.ctf_len);
*/
          }
          /*
          else if(grp_len_stk[i].gp_flg==BUSITYPE)
          {
              grp_len_stk[i].gp->unode.hd_node.ctf_size += len;
          }
          */
          
       }
    }
    if(fun==1)
    {
       for(i=0;i<g_idx;i++)
       {
          grp_len_stk[i].gp->unode.it_node.ctf_len -= ctf_len;
          if(grp_len_stk[i].gp_flg==GROUP)
              grp_len_stk[i].gp->unode.it_node.dat_len -= ctf_len;
       }
    }
}
/*-------------------------------------------------------------*/
/*    these functions handle the ctf node write and remove     */
/*-------------------------------------------------------------*/
wrrmgp(ptr)
ctf_node *ptr;
{
   int i;
   int cur_idx;

   while(ptr!=tempp)
   {
      w_ctf_node(ptr);
      rm_ctf_node(ptr);
      ptr=ptr->right;
   }
} 

w_allbusi()
{
   char done;
   ctf_node *ptr,*p1,*p2;
   long where;

   done='n';
   if((where=lseek(ctf_fp,0L,1))==-1) /* save file current position */
   {
      printf("lseek error ! \n");
      exit(0);
   }
   if(lseek(ctf_fp,busi_where,0)==-1) /* set file position to top of file */
   {
      printf("lseek error ! \n");
      exit(0);
   }
   w_ctf_node(headp);
   ptr=headp->right;
   if(lseek(ctf_fp,where,0)==-1) /* restore the file position */
   {
      printf("lseek error ! \n");
      exit(0);
   }
   while(ptr!=NULL)
   {
      done='y';
      w_ctf_node(ptr);
      ptr=ptr->right;
   };
   if(done=='y')               /* release all ctf node */
   {
      while(headp->right != NULL)
      {
         headp = headp->right;
         free(headp->left);
      };
      free(headp);
   
   }
}

w_ctf_node(ptr)
ctf_node *ptr;
{
   int n;
   int i;
 
   if(ptr->unode.hd_node.rec_head!='*')
   {
        ctf_w_cnt++;
        /*
        ptr->unode.it_node.ctf_relat=ctf_w_cnt;
        */
        if(n=write(ctf_fp,&(ptr->unode.it_node),sizeof(ctf_item))==-1)
      {
         printf("file write error!\n");
         exit(0);
      }
   }
   else
   {
        ptr->unode.hd_node.ctf_size=ctf_offs_cnt;
        if(n=write(ctf_fp,&(ptr->unode.hd_node),sizeof(ctf_head))==-1)
        {
           printf("file write error!\n");
           exit(0);
        }
   }
}

rm_ctf_node(ptr)
ctf_node *ptr;
{
    ptr->left->right=ptr->right;
    ptr->right->left=ptr->left;
    free(ptr);
}

file_open(pathname)
char *pathname;
{
   int flags;
   int fp;

   flags=O_WRONLY|O_CREAT|O_TRUNC;
   if((fp=open(pathname,flags,0666)) == NULL)
   {
       fprintf(stderr,"cant open file");
       exit(0);
   }
   return(fp);
}

pop(labno)
int labno;
{
   int cur_idx;

   for(cur_idx=g_idx;cur_idx>=0;cur_idx--)
      if(grp_len_stk[cur_idx].label_no==labno)
           g_idx=cur_idx;

   if(cur_idx==0)
     prs_err("label not found in stack ");
}

prs_err(msg)
char *msg;
{
   fprintf(err_fp,"Line %d -- %s\n",ctf_line,msg);
}

/*----------------------------------------------------------------*/

cget_rec(fp,string,fun)
FILE *fp;
char string[];
int fun;
{
   int i,j,flg;
   int c;
   int rec_len;
   char str[81];
   int  idx;

    if((rec_len=readln(fp,str)) != EOF)
    {
        if(rec_len==0)          /* record length is 0            */
           return(-2);          /* it is a null string           */
        if(str[0]=='%')         /* handle the busitype setting   */
        {
           strcpy(string,str);
           return(0);
        }
        if(str[5]!=' ')         /* handle the initia value setting  */
        {
           ini_value=str[5];
           str[5]=' ';
        }
        else if(str[5]==' ')
           ini_value=' ';

        if(str[6]=='*')         /* handle the remark line         */
            return(-2);

        idx=char_index(str,'8',FORWARD,0);
        if(idx!=-1 && str[idx+1]=='8' && str[idx+2]==' ')
        {
           flg=0;
           for(i=idx;i>0;i--)
           {
              if(str[i]!=' ')
                  flg=1;
              else
                  flg=0;
           }
           if(flg=1)
           {
             idx=char_index(str,'.',FORWARD,0);
             if(idx==-1)
             {
                do
                {
                   rec_len=readln(fp,str);
                   idx=char_index(str,'.',FORWARD,0);
                } while (idx==-1);
             }
             return(-2);
           }
        }     
           

        idx=char_index(str,'.',FORWARD,0);
        if(idx==-1)
        {
          strcpy(string,str);
          do
          {
              rec_len=readln(fp,str);
              strcat(string,str);
              idx=char_index(str,'.',FORWARD,0);
          } while (idx==-1);
        }
        else
          strcpy(string,str);
        return(0);
           
    }
    else
       return(EOF);
       
}

readln(fp,string)
FILE *fp;
char string[];
{
   int i;
   int c;
   int n_flag;      /* null string flag   */

    i=0;
    n_flag=0;
    while((c=fgetc(fp))!='\n')
    {
       if(c!=' ')        /* It is not a null string */
          n_flag=1;
       if(c==EOF)
          return(EOF);
       if(c=='\t')      /* if char is tab key , then skip it and */
          c=' ';        /* take it be space key                  */
       string[i++]=c;
    }
    string[i]='\0';
    if(n_flag==0)        /* Null string , return strlen is 0 */
      return(0);
    else
      return(i);
}


char_index(string,letter,fun,pos)
char string[];
char letter;
char fun;
int pos;
{
   int len;
   int index;
   
   switch(fun)
   {
      case(FORWARD):
        for(index=pos;string[index]!='\0';index++)
           if(string[index]==letter)
              return(index);
        return(-1);
      case(BACKWARD):
        for(index=pos;index>-1;index--)
           if(string[index]==letter)
              return(index);
        return(-1);
      default:
        return(-1);
   }
}
