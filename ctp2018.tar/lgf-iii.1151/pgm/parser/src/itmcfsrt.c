#include     <stdio.h>
#include     <memory.h>
#include     <fcntl.h>
#include     "itcflefm"
#include     "itctblof"
#include "file.def"

/*
#define  CTF_FILE       "../TABLE/ctf_file"
#define  CTF_FILE_SORT  "../TABLE/ctf_file_sort"
*/
#define  FILE_NAME_LEN          80
char  CTF_FILE[FILE_NAME_LEN];               
char  CTF_FILE_SORT[FILE_NAME_LEN];               

struct   ctf_item_def   ctf_table[500];
struct   ctf_item_def   ctf_sort_temp;
struct   ctf_item_def   ctf_rd_buf;
struct   ctf_item_def   ctf_wt_buf;

int      rcr, rcw, rc;
int      fp1, fp2;
int      rec_fd;
int      i;

main(argc,argv)
int argc;
char *argv[];
{
   char *tblpath;


   if (argc == 1) {
     tblpath = getenv("DBP_TDIR");
     sprintf(CTF_FILE,"%s/%s",tblpath,CF);
     sprintf(CTF_FILE_SORT,"%s/%s",tblpath,CFSORT);
   }
   else if (argc ==2) {
     sprintf(CTF_FILE,"%s/%s",argv[1],CF);
     sprintf(CTF_FILE_SORT,"%s/%s",argv[1],CFSORT);
   }
   else {
     printf("The input argument error!!\n");
     exit(-1);
   }

   fp1=open(CTF_FILE, O_RDONLY);
   if(fp1 < 0)
      {
       printf("\n ctf file can't open for input !");
       printf("\n file status = %d", fp1);
      }

   fp2=open(CTF_FILE_SORT, O_CREAT | O_APPEND | O_RDWR, 00666);
   if(fp2 < 0)
      {
       printf("\n ctf file sort can't open for input !");
       printf("\n file status = %d", fp2);
      }


   rcr = read(fp1, &ctf_rd_buf, sizeof(ctf_item));

   while(rcr > 0)
      {
       rcw = write(fp2, &ctf_rd_buf, sizeof(ctf_item));
       if (rcw <= 0)
          {
           printf(" can't write file !\n");
           printf(" file status = %d\n", rcw);
          }

       i = 0;
       rcr = read_file();

       while((rcr != '*') && (rcr > 0) && (i < 500))
          {
           memcpy(&ctf_table[i++], &ctf_rd_buf, sizeof(ctf_item));
           rcr = read_file();
          }

       ctf_table[i].ctf_relat = 9999;

       sort_table(i);

       for(i=0; ctf_table[i].ctf_relat != 9999; i++)
          {
           memcpy(&ctf_wt_buf, &ctf_table[i], sizeof(ctf_item));
           rcw = write(fp2, &ctf_wt_buf, sizeof(ctf_item));
           if (rcw <= 0)
              {
               printf("\n can't write file !");
               printf("\n file status = %d", rcw);
              }
           }
      }
   close(fp1);
   close(fp2);
/* added by alexwu on 19950412 BEGIN */
   exit(0);
/* added by alexwu on 19950412 END */
}

read_file()
{
   rc = read(fp1, &ctf_rd_buf, sizeof(ctf_item));
   if (rc < 0)
      return(rc);
   if (ctf_rd_buf.ctf_name[0] == '*')
      return('*');
   return(rc);
}

sort_table(n)
int   n;

{
   int  gap, i, j;

for (gap = n/2; gap > 0; gap /= 2)
for (i = gap; i < n; i++)
for (j=i-gap;j>=0 && ctf_table[j].ctf_relat>ctf_table[j+gap].ctf_relat; j-=gap)
   {
    memcpy(&ctf_sort_temp, &ctf_table[j], sizeof(ctf_item));
    memcpy(&ctf_table[j], &ctf_table[j+gap], sizeof(ctf_item));
    memcpy(&ctf_table[j+gap], &ctf_sort_temp, sizeof(ctf_item));
   }
}
