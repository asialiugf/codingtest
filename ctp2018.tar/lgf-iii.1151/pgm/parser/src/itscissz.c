/* ******************************************************************** */
/*      PROGRAM NAME : itscissz.c                                       */
/*      CREATE DATE  : 88/04/18                                         */
/*      MODIFY DATE  : 94/03/07                                         */
/*      DESCRIPTION  : compute size of iet share memory                 */
/* ******************************************************************** */
#include    <stdio.h>
#include    <fcntl.h>
#include    <errno.h>
#include    <sys/stat.h>
#include    "errlog.h"
#include    "sbcpgdef.h"
/*#include    "itcflefm"
#include    "itctblof" */
#include    "imctblld.def"
#include    "imctblld.str"
#include "diff.def"

#define  FILE_NAME_LEN          80
extern char  TXN_FILE[FILE_NAME_LEN];               
#define  MSG_STR g_caMsg

/* ******************************************************************** */
/*      itfcissz() : compute size of iet share memory                   */
/* ******************************************************************** */
int   itfcissz()
{
    int   i;
    int   rc;
    int   fd1;
    int   tot_idx_cnt;
    int   shm_size;
    struct  stat  fls;

    UCP_TRACE(P_itfcissz);

    fd1 = open(TXN_FILE, O_RDONLY); /*  open binary file from the parser */
    if  (fd1 < 0) {
        sprintf(MSG_STR,"itfcissz--txn_file can't be open for read");
        err_log(11000,MSG_STR,RPT_TO_LOG|RPT_TO_TTY,0,0);
        UCP_TRACE_OVER;
        return(-1);
    }
    rc = fstat(fd1, &fls);
    if (rc == -1) {
       sprintf(MSG_STR,"ctf_buld--get ctf_file size error,errno=%d!",errno);
       err_log(41000,MSG_STR,RPT_TO_LOG|RPT_TO_TTY,0,0);
    };

    tot_idx_cnt = fls.st_size/sizeof(busi_head) ;
    shm_size = fls.st_size ;
    shm_size += tot_idx_cnt * 10 ; /* 10 is TXN_KEY_LEN + 1  */
    shm_size += sizeof(int) ;     /*  the value of the data offset */

    UCP_TRACE_OVER;
    return(shm_size);
}
/* ***********************  END OF PROGRAM  *************************** */
