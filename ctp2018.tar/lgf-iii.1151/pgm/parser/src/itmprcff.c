#include    <stdio.h>
#include    <fcntl.h>
#include    "itcflefm"

#define     CTF_FILE      "iii/etc/tbl/ctf.bin"
#define     FILE_NAME_LEN    80
#define     M_CTF_HEAD    '*'

int         c_fd, rc;
int         line_cunt, page_limit;
char        var;

char        ctf_rd_buf[sizeof(ctf_item)];
char        char_buf[31];

ctf_head    *ctf_hd;
ctf_item    *ctf_im;

main(argc, argv)
int    argc;
char   *argv[];

{
    char  caFileName[FILE_NAME_LEN];               

    if (argc == 1)
       page_limit = 23;
    else
       if (*argv[1] == 'p')
          page_limit = 56;
       else
          page_limit = 23;

    sprintf(caFileName,"%s/%s",getenv("III_DIR"),CTF_FILE);
    c_fd = open(caFileName, O_RDONLY);
    if (c_fd < 0) {
       printf(" ctf file can't not open for input !\n");
       printf(" file status = %d\n", c_fd);
       exit(1);
    };

    line_cunt = 0;

    while((rc = read(c_fd, ctf_rd_buf, sizeof(ctf_head))) > 0) 
       if (ctf_rd_buf[0] == M_CTF_HEAD) {
          if((line_cunt != 0) && (line_cunt != page_limit))
             for(line_cunt++; line_cunt <= page_limit; line_cunt++)
                printf("\n");
          if((line_cunt != 0) && (page_limit == 23)) {
             printf("PRESS ENTER KEY TO CONTINUE ... ");
             scanf("%c", &var);
             if (var == 'q' || var == 'Q'){
                exit(0);
             }
          }
          printf("BUSINESS_TYPE     CTF_SIZE     TOTAL_ITEMS_NO\n");
          ctf_hd = (ctf_head *)ctf_rd_buf;
          printf("     %c",ctf_hd->rec_head);
          printf(" %c",ctf_hd->busi_type);
          fill_blk(ctf_hd->ctf_size,4,char_buf);
          printf("            %s",char_buf);
          fill_blk(ctf_hd->tot_item,4,char_buf);
          printf("            %s\n\n",char_buf);
          printf("REL_NO        CTF_NAME              TYPE INP_LEN CTF_LEN CTF_OFFS DOT_POS INI\n");
          line_cunt = 4;
       }
       else
       {
          if(line_cunt == page_limit) {
             if(page_limit == 23) {
                printf("PRESS ENTER KEY TO CONTINUE ... ");
                scanf("%c", &var);
                if (var == 'q' || var == 'Q'){
                   exit(0);
                }
             }
             printf("REL_NO        CTF_NAME              TYPE INP_LEN CTF_LEN CTF_OFFS DOT_POS INI\n");
             line_cunt = 1;
          }
          ctf_im = (ctf_item *)ctf_rd_buf;
          fill_blk(ctf_im->ctf_relat,4,char_buf);
          printf(" %s",char_buf);
          append_blk(ctf_im->ctf_name,30,char_buf);
          printf("  %s",char_buf);
          printf(" %c",ctf_im->dat_type);
          fill_blk(ctf_im->dat_len,3,char_buf);
          printf("    %s",char_buf);
/*
          printf("%.4d",ctf_im->dat_len);
          printf("%s",char_buf);
*/

          fill_blk(ctf_im->ctf_len,3,char_buf);
          printf("     %s",char_buf);
/*
          printf("%.4d",ctf_im->ctf_len);
          printf("%s",char_buf);
*/
          fill_blk(ctf_im->ctf_offs,4,char_buf);
          printf("     %s",char_buf);
          fill_blk(ctf_im->dot_pos,1,char_buf);
          printf("      %s",char_buf);
          printf("     %c\n",ctf_im->ini_value);
          line_cunt++;
       }
    if((line_cunt != 0) && (line_cunt != page_limit))
       for(line_cunt++; line_cunt <= page_limit; line_cunt++)
          printf("\n");
    close(c_fd);
}

fill_blk(n,dig,s)
char  s[];
int   n,dig;

{   
   int   i, j;
   
   i = 0;
   do {
      s[i++] = n % 10 + '0';
   } while ((n /= 10) > 0);
   s[i] = '\0';

   reverse(s);

   for(j = dig; j >= 0; i--, j--)
      if (i >= 0)
         s[j] = s[i];
      else
         s[j] = ' ';
}

reverse(s)
char s[];
{
   int c, i, j;

   for (i = 0, j = strlen(s)-1; i < j; i++, j--) {
      c = s[i];
      s[i] = s[j];
      s[j] = c;
   }
}

append_blk(s1, dig, s2)
char  s1[], s2[];
int   dig;
{
   int j;
   for(j = 0; j < strlen(s1); j++)
      s2[j] = s1[j];
   for(j = strlen(s1); j < dig; j++)
      s2[j] = ' ';
   s2[j] = '\0';
}
