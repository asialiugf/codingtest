#include "errlog.h"
#include "imctxnpr.def"
#include "lxcpgdef.def"
#include "imcenupr.def"
#include "diff.def"
#include "file.def"           	/* added by peng for PTM980514 */
#include <fcntl.h>


extern int errno;

/*Modify Miao 980901 for tu980514 begin*/
/*
extern struct map1 seq_map1[MAX_NODE];
extern struct map2 seq_map2[MAX_NODE];
*/
extern struct map1 *seq_map1;
extern struct map2 *seq_map2;
/*Modify Miao 980901 for tu980514 end*/

extern char   buff1[LINE_LEN],buff2[LINE_LEN],buff3[LINE_LEN];
extern char   buff4[LINE_LEN],buff5[LINE_LEN],buff6[LINE_LEN];
/* TCC */
extern char   priv[LINE_LEN];

extern struct token_type token_attr[7];
extern int    child_no;
extern int tot_node;
#define  FILE_NAME_LEN          80
extern char  MENU_DATAFILE[FILE_NAME_LEN];           
extern char  MENU_DATAFILE_BAK[FILE_NAME_LEN];           
extern char  MENU_FILE_ERR[FILE_NAME_LEN];               
extern char  MENU_FILE[FILE_NAME_LEN];               
extern char  MENU_FILE_TMP[FILE_NAME_LEN];             
extern char  MENU_CROSSCHK_FILE[FILE_NAME_LEN];          
extern char  CTF_FILE[FILE_NAME_LEN];      
extern char  ERR_FILE[FILE_NAME_LEN];      
#define INT long
struct menu_node {           /* copy from imcload.str */
       short child_no;
       INT   help_off;
       INT   gud_relat;
       char  main_menu;
       char  priviledge;
       char  txn_id[5];
       char  menu_id[MAX_LEV+1];
} menu_desc;

/* Add Miao 980901 for tu980514 begin*/
extern int txnnum;
extern int txnnode;
struct def_txn_st {
           char def_txn_id[10];
           char privilege[10];
         };
struct def_txn_st *t;
/* Add Miao 980901 for tu980514 end*/



/****************************************************************************/
/*                                                                          */
/*                                                                          */
/*                                                                          */
/****************************************************************************/
menu_par1()
{
  FILE   *f_fp,*f_fp1;
  int    i,k;
  int    err_occur;
  char   cmd_buff[256];

  UCP_TRACE(P_menu_par1);
  if ( (f_fp=fopen(MENU_DATAFILE,"r")) == NULL ) {
     printf("ERROR:open %s error ! errno=%d\n",MENU_DATAFILE,errno);
     UCP_TRACE_END(-1);
  }
  if ( (f_fp1=fopen(MENU_FILE_ERR,"w")) == NULL ) {
    printf("ERROR:menu data error file open error ! errno=%d\n",errno);
    UCP_TRACE_END(-1);
  }

  /*Add Miao 980901 for tu980514 begin*/
  t=(struct  def_txn_st *)malloc(txnnum * sizeof(struct def_txn_st));
  /*Add Miao 980901 for tu980514 end*/
  err_occur=0;
  while (1) {
    para_init();

    token_par(7,token_attr,f_fp);
    if (token_attr[0].rtn_code[0] == PSR_NODATA_ERR)
       break;
    /* TCC 
    fprintf(f_fp1,"%s %4d %s %s %s %s %s\n",buff1,child_no,buff2,buff3,buff4,
            buff5,buff6);
    */

    for (i=0;i<7;i++) {
     if (token_attr[i].rtn_code[0] != 0) {
        err_occur=1;
        switch(i) {
          case 0:fprintf(f_fp1,"ERROR:menu-id parsing error errno=%d\n",
                         token_attr[i].rtn_code[0]);
                 break;
          case 1:fprintf(f_fp1,"ERROR:child no parsing error errno=%d\n",
                         token_attr[i].rtn_code[0]);
                 break;
          case 2:fprintf(f_fp1,"ERROR:guide line no parsing error errno=%d\n",
                         token_attr[i].rtn_code[0]);
                 break;
          case 3:fprintf(f_fp1,"ERROR:main menu flag parsing error errno=%d\n",
                         token_attr[i].rtn_code[0]);
                 break;
          case 4:fprintf(f_fp1,"ERROR:privilege level parsing error errno=%d\n",
                         token_attr[i].rtn_code[0]);
                 break;
          case 5:fprintf(f_fp1,"ERROR:help id parsing error errno=%d\n",
                         token_attr[i].rtn_code[0]);
                 break;
          case 6:fprintf(f_fp1,"ERROR:txn-id parsing error errno=%d\n",
                         token_attr[i].rtn_code[0]);
                 break;
        }  /* for 'case' */
     }   /* for if statements */
    }  /* for for loop */

    if ( (token_attr[3].vt.char_loc[0] != '0') &&
         (token_attr[3].vt.char_loc[0] != '1') ) {
        fprintf(f_fp1,"ERROR:illegal main menu flag\n");
        err_occur=1;
    }

    /* TCC */
    if (child_no == 0) {
        /* TCC */
        if ( chk_txn_id(buff6, priv) != 0) {
          fprintf(f_fp1,"ERROR: undefined txn-id ! ****\n");
          err_occur=1;
        }
      /* TCC */
      token_attr[4].vt.char_loc = priv;
    }

    /* TCC */
    fprintf(f_fp1,"%s %4d %s %s %s %s %s\n", \
            buff1, child_no, buff2, buff3,\
            token_attr[4].vt.char_loc, buff5, buff6);

    if ( bit_to_int(token_attr[4].vt.char_loc) == -1 ) {
        fprintf(f_fp1,"ERROR:illegal privilege level declaration !\n");
        err_occur=1;
    }
  } /* for while(1) */
  /*Add Miao 980901 for tu980514 begin*/
   free(t);
  /*Add Miao 980901 for tu980514 end*/

  get_token(f_fp,token_attr,'E');  /* end of parsing the current file */
  fclose(f_fp);
  fclose(f_fp1);
  if (err_occur != 0) {
    printf("\nERROR:***** MENU definition parsing error !\n");
    printf("Please check %s !\n",MENU_FILE_ERR);
    UCP_TRACE_END(-1);
  }
  else {
      sprintf(cmd_buff,"sort -d < %s > %s",MENU_FILE_ERR,MENU_DATAFILE_BAK);
      system(cmd_buff);
      if ( chk_dup(MENU_DATAFILE_BAK,MENU_FILE_ERR) != 0 ) {
         printf("ERROR:MENU definition duplicated check %s, Pls!\n",MENU_FILE_ERR);
         UCP_TRACE_END(-1);
      }
  }
  printf("end of MENU-PARSER phase I !\n");
  UCP_TRACE_END(0);
}

/****************************************************************************/
/*                                                                          */
/*                                                                          */
/*                                                                          */
/****************************************************************************/
menu_par2()
{
  FILE   *f_fp,*f_fp1;
  int    f_fp2;
  int    i,k;
  int    err_occur;
  char   cmd_buff[256];
  int    rc;

  UCP_TRACE(P_menu_par2);
  if ( (f_fp=fopen(MENU_DATAFILE_BAK,"r")) == NULL ) {
     printf("ERROR:open %s error ! errno=%d\n",MENU_DATAFILE_BAK,errno);
     UCP_TRACE_END(-1);
  }
  if ( (f_fp1=fopen(MENU_FILE_ERR,"w")) == NULL ) {
    printf("ERROR:menu data error file open error ! errno=%d\n",errno);
    UCP_TRACE_END(-1);
  }
/*
  if ( (f_fp2=creat(MENU_FILE_TMP,0666)) == -1 ) {
*/
  if ( (f_fp2=open(MENU_FILE_TMP,O_CREAT|O_TRUNC|O_RDWR,0666)) == -1 ) {
    printf("ERROR:%s open error ! errno=%d\n",MENU_FILE_TMP,errno);
    UCP_TRACE_END(-1);
  }
  tot_node=0;
  err_occur=0;
  while (1) {
    para_init();
    token_par(7,token_attr,f_fp);
    if (token_attr[0].rtn_code[0] == PSR_NODATA_ERR)
       break;
    fprintf(f_fp1,"%s %4d %s %s %s %s %s\n",buff1,child_no,buff2,buff3,buff4,
            buff5,buff6);
    if (token_attr[0].rtn_code[0] == PSR_NODATA_ERR)
       break;
    for (i=0;i<7;i++) {
     if (token_attr[i].rtn_code[0] != 0) {
        err_occur=1;
        switch(i) {
          case 0:fprintf(f_fp1,"ERROR:menu-id parsing error errno=%d\n",
                         token_attr[i].rtn_code[0]);
                 break;
          case 1:fprintf(f_fp1,"ERROR:child no parsing error errno=%d\n",
                         token_attr[i].rtn_code[0]);
                 break;
          case 2:fprintf(f_fp1,"ERROR:guide line no parsing error errno=%d\n",
                         token_attr[i].rtn_code[0]);
                 break;
          case 3:fprintf(f_fp1,"ERROR:main menu flag parsing error errno=%d\n",
                         token_attr[i].rtn_code[0]);
                 break;
          case 4:fprintf(f_fp1,"ERROR:privilege level parsing error errno=%d\n",
                         token_attr[i].rtn_code[0]);
                 break;
          case 5:fprintf(f_fp1,"ERROR:help id parsing error errno=%d\n",
                         token_attr[i].rtn_code[0]);
                 break;
          case 6:fprintf(f_fp1,"ERROR:txn-id parsing error errno=%d\n",
                         token_attr[i].rtn_code[0]);
                 break;
        }  /* for 'case' */
     }   /* for if statements */
    }  /* for for loop */
    if ( (token_attr[3].vt.char_loc[0] != '0') &&
         (token_attr[3].vt.char_loc[0] != '1') ) {
        fprintf(f_fp1,"ERROR:illegal main menu flag\n");
        err_occur=1;
    }
    if ( bit_to_int(token_attr[4].vt.char_loc) == -1 ) {
        fprintf(f_fp1,"ERROR:illegal privilege level declaration !\n");
        err_occur=1;
    }
    if ( check_gud(buff2,&(menu_desc.gud_relat)) == -1 ) {
        fprintf(f_fp1,"ERROR: undefined gud_line no:%s ****\n",buff2);
        err_occur=1;
    }
    /*if ( tot_node > MAX_NODE ) {
        printf("ERROR: menu_description table overflow !\n");
        printf(" Please change the MAX_NODE definition in 'imcenupr.def' !\n");
        err_occur=1;
        break;
    }    Mark Miao 980901 for tu980514  */
    strncpy(seq_map1[tot_node].menu_id,buff1,MAX_LEV);
    seq_map1[tot_node].child_no=child_no;
    menu_desc.child_no=child_no;
    strcpy(menu_desc.menu_id,buff1);
    /* check_hlp return the record number of the help file */
    if ( (menu_desc.help_off=check_hlp(buff5)) == -2 ) {
        fprintf(f_fp1,"ERROR: undefined online help no:%s ****\n",buff5);
        UCP_TRACE_END(-1);
    }
    strcpy(menu_desc.txn_id,buff6);
    menu_desc.main_menu=buff3[0];
    menu_desc.priviledge= bit_to_int(token_attr[4].vt.char_loc);
/*
    strcpy(menu_desc.title_id,buff2);
*/
    tot_node++;
    rc = lseek(f_fp2,0L,1);
    rc = write(f_fp2,&menu_desc,sizeof(menu_desc));
    if (rc != sizeof(menu_desc) ) {
    printf("ERROR:menu data write file error!errno=%d,rc=%d\n",errno,rc);
    UCP_TRACE_END(-1);
    }

  } /* for while(1) */
  get_token(f_fp,token_attr,'E');  /* end of parsing the current file */
  fclose(f_fp);
  close(f_fp2);
  if (err_occur != 0) {
    printf("error occured please check %s for detail !\n",MENU_FILE_ERR);
    UCP_TRACE_END(-1);
  }
  else {
    imsmap(tot_node);
    fprintf(f_fp1,"-----------------------------------------------------\n");
    if ( imschkno(f_fp1,tot_node) != 0) {
       printf("ERROR:error occured please check %s for detail !\n",MENU_FILE_ERR);
       fclose(f_fp1);
       UCP_TRACE_END(-1);
    }
    else {
       fclose(f_fp1);
       gen_file(tot_node);
       printf("end of MENU-PARSER phase II !\n");
    }
  }
  UCP_TRACE_END(0);
}

/****************************************************************************/
/*                                                                          */
/*                                                                          */
/*                                                                          */
/****************************************************************************/
imsmap(tot_node)
int tot_node;
{
 int curr_node;
 int i,j,k;

 memcpy(seq_map2[0].menu_id,seq_map1[0].menu_id,MAX_LEV);
 seq_map2[0].child_no=seq_map1[0].child_no;
 seq_map2[0].orig_idx=0;
 seq_map2[0].child_add=1;
 seq_map2[0].level=0;
 j=1;

 for (i=1; i<MAX_LEV+1; i++) {
   for (k=1;k<tot_node;k++) {
     if ( (strncmp(seq_map1[k].menu_id+i,"0000000000000",MAX_LEV-i) == 0) &
          (seq_map1[k].menu_id[i-1] != '0') )  {
        memcpy(seq_map2[j].menu_id,seq_map1[k].menu_id,MAX_LEV);
        seq_map2[j].child_no=seq_map1[k].child_no;
        seq_map2[j].orig_idx=k;
        seq_map2[j].level=i;
        j++;
     }
   }
 }

 curr_node=1;

 for (i=seq_map2[curr_node].level;(i<MAX_LEV+1) && (curr_node < tot_node);) {
    seq_map2[curr_node].child_add=-1;
    for (j=curr_node+1; j<tot_node; j++) {
      if (seq_map2[j].level > i+1) {  /* no child found */
        break;
      }
      else {
         if (seq_map2[j].level == i+1) {
            if (strncmp(seq_map2[curr_node].menu_id,seq_map2[j].menu_id,i)==0) {
               seq_map2[curr_node].child_add=j;
               break;
            }
         }
      }  /* for 'if (seq_map2[j].level > i+1) '  no child found */
    }  /* for 'for (j=curr_node+1; j<tot_node; j++) { ' */
    curr_node++;
    i=seq_map2[curr_node].level;
  }
/*
 for (i=0;i<tot_node;i++) {
  printf("i=%d level=%d id=%s child=%d org_idx=%d child_add=%d\n",i,
         seq_map2[i].level,seq_map2[i].menu_id,seq_map2[i].child_no,
         seq_map2[i].orig_idx,seq_map2[i].child_add);
 }
*/
 return(0);
}


/****************************************************************************/
/*                                                                          */
/*                                                                          */
/*                                                                          */
/****************************************************************************/
gen_file(tot_node)
int    tot_node;
{
 int i;
 int fp1,fp2;
 long loc;
 char  cmd_buf[256];
 int rc;
 int menu_st_size;

  if ( (fp1=open(MENU_DATAFILE_BAK,O_CREAT|O_TRUNC|O_RDWR,0666)) == -1 ) {
    printf("ERROR:%s open error ! errno=%d\n",MENU_DATAFILE_BAK,errno);
    return(-1);
  }
  if ( (fp2=open(MENU_FILE_TMP,O_RDONLY)) == -1 ) {
    printf("ERROR:%s open error ! errno=%d\n",MENU_FILE_TMP,errno);
    return(-1);
  }
  for (i=0;i<tot_node;i++) {
    loc=(long)((seq_map2[i].orig_idx)*sizeof(struct menu_node));
    if ( lseek(fp2,loc,0) == -1 ) {
      printf("ERROR:%s locate error \n",MENU_FILE_TMP);
      close(fp1);
      close(fp2);
      return(-1);
    }
    menu_st_size= sizeof(menu_desc);
    if ((rc=read(fp2,&menu_desc,menu_st_size)) != menu_st_size ) {
      printf("ERROR:read %s error errno=%d \n",MENU_FILE_TMP,errno);
      close(fp1);
      close(fp2);
      return(-1);
    }
    if ( menu_desc.child_no != 0 ) {
      itoa(seq_map2[i].child_add,menu_desc.txn_id);
    }
    if ( write(fp1,&menu_desc,sizeof(menu_desc))!=sizeof(menu_desc) ) {
      printf("ERROR:write %s error\n",MENU_FILE);
      close(fp1);
      close(fp2);
      return(-1);
    }
  }
  close(fp1);
  close(fp2);
#ifdef DOS
  sprintf(cmd_buf,"copy %s %s \n",MENU_DATAFILE_BAK,MENU_FILE);
#else
  sprintf(cmd_buf,"mv %s %s \n",MENU_DATAFILE_BAK,MENU_FILE);
#endif
  system(cmd_buf);
  printf("%s has been generated !\n",MENU_FILE);
}

/****************************************************************************/
/*                                                                          */
/*                                                                          */
/*                                                                          */
/****************************************************************************/
para_init()
{
    token_attr[0].var_type=STR_TYPE;   /* get menu-id */
    token_attr[0].max_len=MAX_LEV;
    token_attr[0].fix_len='Y';
    token_attr[0].vt.char_loc=buff1;
    token_attr[0].delimit=' ';

    token_attr[1].var_type=DECI_TYPE;   /* get child no */
    token_attr[1].max_len=MAX_LEV;
    token_attr[1].fix_len='N';
    token_attr[1].vt.int_loc=&child_no;
    token_attr[1].delimit=' ';

    token_attr[2].var_type=STR_TYPE;   /* get guideline-id */
    token_attr[2].max_len=MAX_LEV;
    token_attr[2].fix_len='N';
    token_attr[2].vt.char_loc=buff2;
    token_attr[2].delimit=' ';

    token_attr[3].var_type=STR_TYPE;   /* get main-menu flag */
    token_attr[3].max_len=1;
    token_attr[3].fix_len='Y';
    token_attr[3].vt.char_loc=buff3;
    token_attr[3].delimit=' ';

    token_attr[4].var_type=STR_TYPE;   /* get priveledge level */
    token_attr[4].max_len=8;
    token_attr[4].fix_len='Y';
    token_attr[4].vt.char_loc=buff4;
    token_attr[4].delimit=' ';

    token_attr[5].var_type=STR_TYPE;   /* get help-id */
    token_attr[5].max_len=4;
    token_attr[5].fix_len='N';
    token_attr[5].vt.char_loc=buff5;
    token_attr[5].delimit=' ';

    token_attr[6].var_type=STR_TYPE;   /* get txn-id */
    token_attr[6].max_len=TXN_LEN;
    token_attr[6].fix_len='Y';
    token_attr[6].vt.char_loc=buff6;
    token_attr[6].delimit=' ';
}

/***************************************************************************/
/* check any duplicated menu declaration, if any return -1 else return 0   */
/* f1 --> sorted menu_file           f2 --> error message file             */
/***************************************************************************/
chk_dup(f1,f2)
char *f1,*f2;
{
  FILE *f_fp,*f_fp1;
/* modified by alexwu on 19950413
  char buff[LINE_LEN];
*/
  char buff[LINE_LEN+1];
  char token1[LINE_LEN],token2[LINE_LEN];
  char dup_flag='N';
/* added by alexwu 19950413 BEGIN */
  char *p;
/* added by alexwu 19950413 END */

  UCP_TRACE(P_chk_dup);
  if ( (f_fp=fopen(f1,"r")) == NULL ) {
    printf("ERROR:open menu data file open error ! errno=%d\n",errno);
    UCP_TRACE_END(-1);
  }
  if ( (f_fp1=fopen(f2,"w")) == NULL ) {
    printf("ERROR:menu data error file open error ! errno=%d\n",errno);
    UCP_TRACE_END(-1);
  }
  if ( fgets(buff,LINE_LEN,f_fp) == NULL ) {
      printf("ERROR:no data error errno=%d !\n",errno);
      UCP_TRACE_END(-2);
  }
  fprintf(f_fp1,"%s",buff);
/* modified by alexwu on 19950413
  strcpy(token1,strtok(buff," \t\"\n"));
*/
  if ((p=strtok(buff," \t\"\n")) != (char*) NULL)
	strcpy(token1,p);
  else
	token1[0] = '\0';

  if ( ((token1[0] == 'L') && (token1[1] ==1) && (token1[2] == 4)) ||
          (strlen(token1) == 0) ) {
      UCP_TRACE_END(-2); /* no more token */
  }
  while (1) {
     if ( fgets(buff,LINE_LEN,f_fp) == NULL ) {
         break;
     }
     fprintf(f_fp1,"%s",buff);
/* modified by alexwu on 19950413
     strcpy(token2,strtok(buff," \t\"\n"));
*/
     if ((p=strtok(buff," \t\"\n")) != (char*) NULL)
	strcpy(token2,p);
     else
	token2[0] = '\0';

     if ( ((token2[0] == 'L') && (token2[1] ==1) && (token2[2] == 4)) ||
             (strlen(token2) == 0) ) {
         break;
     }
     if ( strcmp(token1,token2) == 0 ) {
        dup_flag='Y';
        fprintf(f_fp1,"ERROR:menu-id:%s",token1);
        fprintf(f_fp1,"ERROR:********duplicated declaration !*******\n");
     }
     strcpy(token1,token2);
  }
  fclose(f_fp);
  fclose(f_fp1);
  if (dup_flag=='Y') {
     UCP_TRACE_END(-1);
  }
  else {
     UCP_TRACE_END(0);
  }
}

/***************************************************************************/
/* check if the number of children consisant and if txn-code existed       */
/*                                                                         */
/***************************************************************************/
imschkno(fp,total_node)
FILE *fp;
int total_node;
{
  int i,j;

  for (i=1;i<total_node;i++) {  /* check the children no. of root */
    if ( (strncmp(seq_map2[i].menu_id+1,"0000000000000",MAX_LEV-1) != 0) ) {
       break;
    }
  }
  if ( i != (seq_map2[0].child_add+seq_map2[0].child_no) ) {
      fprintf(fp,"ERROR:menu-id:%s inconsist children no !\n",seq_map2[0].menu_id);
      return(-1);
  }
  for (i=1;i<total_node;i++) {
    if (seq_map2[i].child_no !=0) {
      j=seq_map2[i].child_add;
/*
      printf("I-id=%s J-id=%s\n",seq_map2[i].menu_id,seq_map2[j].menu_id);
      printf("I-level=%d\n",seq_map2[i].level);
*/
      while( (strncmp(seq_map2[j].menu_id,seq_map2[i].menu_id,seq_map2[i].level)
               == 0 ) && (j < total_node) &&
            (strncmp(seq_map2[j].menu_id+seq_map2[i].level+1,"000000000000",
                     MAX_LEV-seq_map2[i].level-1) ==0 ) ) {
        /*fprintf(fp,"seq_map2[%d].menu_id=%.7s,seq_map2[%d].menu_id=%.7s,seq_map2[%d].level=%d\n"
         ,j,seq_map2[j].menu_id,i,seq_map2[i].menu_id,i,seq_map2[i].level);*/
         j++;
      }
      /*fprintf(fp,"j=%d,seq_map2[i].child_add=%d,seq_map2[i].child_no=%d\n",j
              ,seq_map2[i].child_add,seq_map2[i].child_no);*/
      if ( j != (seq_map2[i].child_add+seq_map2[i].child_no) ) {
         fprintf(fp,"ERROR:menu-id:%s inconsist children no !\n",seq_map2[i].menu_id);
         return(-1);
      }
    }
  }
  return(0);
}

/*#define TXN_REC_SIZE 700  Mark Miao 980901 for tu980514  */
/* TCC */
chk_txn_id(txn_id, priv)
char *txn_id;
char *priv;
{
  static int txn_count=0;
  /* TCC */
  /*Mark Miao 980901 for tu980514  
  struct def_txn_st {
           char def_txn_id[10];
           char privilege[10];
         };
  static struct def_txn_st t[TXN_REC_SIZE];
  */
  FILE *fp1;
  char buff[80];
  /* TCC */
  char txn_id_cro[80], prog[80], priv_cro[80];
  int  i;

  if ( txn_count==0) {  /* load txn_code from MENU_CROSSCHK_FILE */
     if ( (fp1=fopen(MENU_CROSSCHK_FILE,"r")) == NULL ) {
       printf("ERROR:menu parser %s open err! errno=%d\n",MENU_CROSSCHK_FILE,errno);
       return(-1);
     }

     /* TCC 
     while ( fgets(buff,80,fp1) != NULL ) {
     */
     /* Added by TCC */
     fscanf (fp1, "%s %s %s", txn_id_cro, prog, priv_cro);

     while (!feof(fp1))
     {
       /*if (txn_count > TXN_REC_SIZE) {
          printf("ERROR:too many txn_code, please increase the buffer reserved !\n");
          printf("Please check imsenupr.c (chk_txn_id()) !\n");
          fclose(fp1);
          return(-1);
       }       Mark Miao 980901 for tu980514   */
       /* TCC
       strcpy(t[txn_count].def_txn_id,buff);
       */
       /* Added by TCC */
       strcpy(t[txn_count].def_txn_id, txn_id_cro);
       strcpy(t[txn_count].privilege, priv_cro);

       txn_count++;
       fscanf (fp1, "%s %s %s", txn_id_cro, prog, priv_cro);
     }
     fclose(fp1);
  }
    /* check if txn_code existed */
  for ( i=0; i< txn_count; i++) {
    if (strncmp(txn_id,t[i].def_txn_id,strlen(txn_id)) == 0)  
    {
      /* TCC */
      strcpy(priv, t[i].privilege);
      return(0);
    }
  }
  return(-1);
}


/*******************************************************************/
/* txn_cal()     calculate txn num                                 */
/* Add Miao 980903 for tu980514                                    */
/*******************************************************************/
int txn_cal()
{
  int txn_num=0;
  FILE *fp1;
  char txn_id_cro[80], prog[80], priv_cro[80];
  char caFileName[80];    		/*added by peng for ptm980514*/
 
   /*  if ( (fp1=fopen(MENU_CROSSCHK_FILE,"r")) == NULL ) {
       printf("ERROR:menu parser %s open err! errno=%d\n",MENU_CROSSCHK_FILE,errno);
       return(-1);
  }    commented by peng */

  /*begin : added by peng for ptm980514*/
  strcpy(caFileName,getenv("PWD"));
  strcat(caFileName,"/");
  strcat(caFileName,MCF);
  if( (fp1=fopen(caFileName,"r"))== NULL){
	printf("ERROR:menu parser %s open err! errno=%d\n",caFileName,errno);
        return(-1);
  }	
  /*end : added by peng for ptm980514*/ 
  else
  {
       fscanf (fp1, "%s %s %s", txn_id_cro, prog, priv_cro);
       while (!feof(fp1))
       {
          txn_num++;
          fscanf (fp1, "%s %s %s", txn_id_cro, prog, priv_cro);
       }
       fclose(fp1);
  }
  return(txn_num); 
}

