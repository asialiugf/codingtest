#define MAIN_PROGRAM 1
#include "errlog.h"
#include "lxcpgdef.def"
#include "imctxnpr.def"
#include "imcenupr.def"
#include "diff.def"
#include "file.def"

extern int errno;
#define  MSG_STR g_caMsg
#define  FILE_NAME_LEN          80
char     DF_config[FILE_NAME_LEN];
char  GUD_FILE_DAT[FILE_NAME_LEN];           
char  MENU_DATAFILE[FILE_NAME_LEN];           
char  MENU_DATAFILE_BAK[FILE_NAME_LEN];           
char  MENU_FILE_ERR[FILE_NAME_LEN];               
char  MENU_FILE[FILE_NAME_LEN];               
char  MENU_FILE_TMP[FILE_NAME_LEN];             
char  MENU_CROSSCHK_FILE[FILE_NAME_LEN];          
char  CTF_FILE[FILE_NAME_LEN];      
char  ERR_FILE[FILE_NAME_LEN];      

/*Mark Miao 980901 for tu980514
struct map1 seq_map1[MAX_NODE];
struct map2 seq_map2[MAX_NODE];
*/

/*Add Miao 980901 for tu980514 begin*/
struct map1 *seq_map1;
struct map2 *seq_map2;
int txnnum=0;
int txnnode=0;
/*Add Miao 980901 for tu980514 end*/

char   buff1[LINE_LEN],buff2[LINE_LEN],buff3[LINE_LEN];
char   buff4[LINE_LEN],buff5[LINE_LEN],buff6[LINE_LEN];
/* TCC */
char   priv[LINE_LEN];
struct token_type token_attr[7];
int    child_no;
int    tot_node;

main(argc,argv)
int argc;
char *argv[];
{
  int  rc;
  char *tblpath;
  char *cmgpath;
  char caLogName[256];

  if (argc == 2) {
    tblpath = getenv("DBP_TDIR");
    cmgpath = getenv("DBP_CDIR");
    sprintf(GUD_FILE_DAT,"%s/%s",cmgpath,GFD);
    sprintf(MENU_DATAFILE,"%s/%s",tblpath,MDF);           
    sprintf(MENU_DATAFILE_BAK,"%s/%s",tblpath,MDB);           
    sprintf(MENU_FILE_ERR,"%s/%s",tblpath,MFE);
    sprintf(MENU_FILE,"%s/%s",tblpath,MFB);
    sprintf(MENU_FILE_TMP,"%s/%s",tblpath,MFT);
    sprintf(MENU_CROSSCHK_FILE,"%s/%s",tblpath,MCF);
    sprintf(CTF_FILE,"%s/%s",tblpath,CF);
    sprintf(ERR_FILE,"%s/%s",tblpath,EF);
  }
  else if (argc ==3) {
    sprintf(GUD_FILE_DAT,"%s/%s",argv[2],GFD);
    sprintf(MENU_DATAFILE,"%s/%s",argv[2],MDF);           
    sprintf(MENU_DATAFILE_BAK,"%s/%s",argv[2],MDB);           
    sprintf(MENU_FILE_ERR,"%s/%s",argv[2],MFE);
    sprintf(MENU_FILE,"%s/%s",argv[2],MFB);
    sprintf(MENU_FILE_TMP,"%s/%s",argv[2],MFT);
    sprintf(MENU_CROSSCHK_FILE,"%s/%s",argv[2],MCF);
    sprintf(CTF_FILE,"%s/%s",argv[2],CF);
    sprintf(ERR_FILE,"%s/%s",argv[2],EF);
  }
  else {
    printf("Usage:%s argument1 argument2\n",argv[0]);
    printf("      where argument1 is following value\n");
    printf("      1 : first  phase of the menu_file parser\n");
    printf("      2 : second phase of the menu_file parser\n");
    printf("      3 : first & second phase of the menu_file parser\n");
    printf("      where argument2 is optional\n");
    printf(" argument2 used whenever need a seperate AP business parser!\n");
    printf(" argument2 not used when a merging AP businesses parser!\n");
    exit(1);
  }

  if ((argc != 2) && (argc != 3)) {
    printf("Usage:%s argument1 argument2\n",argv[0]);
    printf("      where argument1 is following value\n");
    printf("      1 : first  phase of the menu_file parser\n");
    printf("      2 : second phase of the menu_file parser\n");
    printf("      3 : first & second phase of the menu_file parser\n");
    printf("      where argument2 is optional\n");
    printf(" argument2 used whenever need a seperate AP business parser!\n");
    printf(" argument2 not used when a merging AP businesses parser!\n");
    exit(1);
  }

/*Add Miao 980901 for tu980514 begin*/
  txnnum=txn_cal();
  txnnode=txnnum*2;
  seq_map1=(struct map1 *)malloc(txnnode * sizeof(struct map1));
  seq_map2=(struct map2 *)malloc(txnnode * sizeof(struct map2));
/*Add Miao 980901 for tu980514 end*/

  strcpy(DF_config    ,"../TABLE/config.dat");
  sig_hdl();
  sprintf(caLogName, "%s/iii/log/par_errlog", getenv("III_DIR") );
  ChgLog(LOG_CHG_MODE,"1");
  ChgLog(LOG_CHG_LOG,caLogName);
  rc=0;
  switch(argv[1][0]) {
    case '1':rc=menu_par1();
             break;
    case '2':if ( rc == 0 ) {
               rc = menu_par2();
             }
             break;
    case '3':
             rc=menu_par1();
             if ( rc == 0 ) {
               rc = menu_par2();
             }
             break;
    default :printf("Invalid arguments=%c\n",argv[1][0]);
             printf("Usage:%s argument1 argument2\n",argv[0]);
             printf("      where argument1 is following value\n");
             printf("      1 : first  phase of the menu_file parser\n");
             printf("      2 : second phase of the menu_file parser\n");
             printf("      3 : first & second phase of the menu_file parser\n");
             printf("      where argument2 is optional\n");
             printf(" argument2 used whenever need a seperate AP business parser!\n");
             printf(" argument2 not used when a merging AP businesses parser!\n");
            /*Add Miao 980901 for tu980514 begin*/
              free(seq_map1);
              free(seq_map2);
            /*Add Miao 980901 for tu980514 end*/
             exit(1);
  }
/*Add Miao 980901 for tu980514 begin*/
  free(seq_map1);
  free(seq_map2);
/*Add Miao 980901 for tu980514 end*/
  exit(rc);
}
