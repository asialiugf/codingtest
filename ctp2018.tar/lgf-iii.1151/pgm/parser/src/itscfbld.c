
/*  itscfbld.c   ------------------------ */
/* -------------------------------------- */
/*    ctf item table loading program      */
/* -------------------------------------- */
#include    <stdio.h>
#include    <errno.h>
#include    "errlog.h"
#include    "sbcpgdef.h"
#include    "imctblld.def"
#include    "itctblof.str"  /* used for porting              */
#include    "imctblld.str"
#include    "itctxnld.def"  /* new add 3 by Jess Wu 830308   */
#include "diff.def"

#define  INT long
#define  MSG_STR g_caMsg
extern int     CTF_SHM_KEY;
extern int     IET_SHM_KEY;
/*
#define  CTF_SHM_KEY   0x60
#define  IET_SHM_KEY   0x61
*/
#define  MAX_BUSI_NO            (10 + 26 + 26) /* (0-9),(a-z),(A-Z) */
#define  FILE_NAME_LEN          80
extern char  CTF_FILE[FILE_NAME_LEN];      

struct  Ctf_item_str {          /* ctf file data item format defined     */
   char dat_type;               /* type of data item                     */
   short  dat_len;                /* input item length                     */
   int  ctf_relat;              /* relative number to ctf table          */
   short  dot_pos;                /* floating point position from right    */
   char   ini_value;              /* initial value                         */
};
typedef struct Ctf_item_str Ctf_item_st;

ctf_buld()
{
    int     i;
    struct  stat fls;
/*
    char    fls_area[sizeof(struct stat)];
*/

    UCP_TRACE(P_ctf_buld);
/*
    fls = (struct stat *)fls_area;
*/

    /* ------------------- */
    /*    open ctf file    */
    /* ------------------- */
    c_fd = open(CTF_FILE, O_RDONLY);
    if (c_fd < 0) {
/*    printf("\n ctf file can't not open for input !");
      printf("\n file status = %d", c_fd);
      exit(1);*/
      err_log(41000,"ctf_buld--ctf file can't open",RPT_TO_LOG|RPT_TO_TTY,0,0);
    };

    /* ------------------------- */
    /*    check ctf file size    */
    /* ------------------------- */
    rc = fstat(c_fd, &fls);
    if (rc == -1) {
/*     printf("\n get ctf_file size error !");
       exit(1);*/
       sprintf(MSG_STR,"ctf_buld--get ctf_file size error,errno=%d!",errno);
       err_log(41000,MSG_STR,RPT_TO_LOG|RPT_TO_TTY,0,0);
    };

    /* ---------------------------------- */
    /*    create ctf item share memory    */
    /* ---------------------------------- */
    shmflg = 0;
    /*ctf_shm_id = shmget(CTF_SHM_KEY, fls.st_size, shmflg);*/
    ctf_shm_id = shmget(CTF_SHM_KEY, 
                        fls.st_size + 4 + MAX_BUSI_NO*sizeof(busi_ctf), shmflg);

    if (ctf_shm_id != -1) {
       /* ------------------------------------------------- */
       /*    remove original ctf item table share memory    */
       /* ------------------------------------------------- */
       shmflg = IPC_RMID;
       shmctl(ctf_shm_id, shmflg,0);
    };

    /* ---------------------------------- */
    /*    create ctf item share memory    */
    /* ---------------------------------- */
    shmflg = IPC_CREAT;
    /*ctf_shm_id = shmget(CTF_SHM_KEY, fls.st_size, shmflg);*/
    ctf_shm_id = shmget(CTF_SHM_KEY, 
                        fls.st_size + 4 + MAX_BUSI_NO*sizeof(busi_ctf), shmflg);

    /* ------------------------------------------------ */
    /*    set ctf item table share memory permission    */
    /* ------------------------------------------------ */
    cbuf.shm_perm.mode = CTF_SHM_MODE;
    cbuf.shm_perm.uid = getuid();
    cbuf.shm_perm.gid = getgid();
    rc = shmctl(ctf_shm_id, IPC_SET, &cbuf);
    if (rc != 0) {
/*     printf("\n ctf share memory permission setting error");
       exit(1);*/
       sprintf(MSG_STR,"ctf_file size=%d",fls.st_size);
       err_log(1000,MSG_STR,RPT_TO_LOG|RPT_TO_TTY,0,0);
       sprintf(MSG_STR,"ctf_buld--ctf share memory permission setting error");
       err_log(41000,MSG_STR,RPT_TO_LOG|RPT_TO_TTY,0,0);
    }

    ctf_itm_no = fls.st_size / sizeof(tbl_item);
/*  sprintf(MSG_STR,"ctf_buld:fls.st_size=%d,sizeofTbl_item=%d,ctf_itm_no=%d",
            fls.st_size,sizeof(tbl_item),ctf_itm_no);
    err_log(100,MSG_STR,RPT_TO_LOG,0,0);*/
    ctfbas = (char *)shmat(ctf_shm_id, 0, 0);
    ctfbusi = (char *)(ctfbas + 4); /* storing the busi_cnt */
    /*cadd   = (char *)(ctfbusi + BUS_TYPE_NO * sizeof(busi_ctf));*/
    cadd   = (char *)(ctfbusi + MAX_BUSI_NO * sizeof(busi_ctf));

/*   create the IET ,including (tot_idx_cnt,idx_array,txn_file image)  */
    iet_size = itfcissz();
    if (iet_size < 0) {
       sprintf(MSG_STR,"ctf_buld--get iet share memory size error!");
       err_log(41000,MSG_STR,RPT_TO_LOG|RPT_TO_TTY,0,0);
    };

    shmflg = 0;
    iet_shm_id = shmget(IET_SHM_KEY, iet_size, shmflg);

    if (iet_shm_id != -1) {
       /* ------------------------------------------------ */
       /*    remove original business node share memory    */
       /* ------------------------------------------------ */
       shmflg = IPC_RMID;
       shmctl(iet_shm_id, shmflg,0);
    };

    /* --------------------------------------- */
    /*    create business node share memory    */
    /* --------------------------------------- */
    shmflg = IPC_CREAT;
    iet_shm_id = shmget(IET_SHM_KEY, iet_size, shmflg);

    /* ----------------------------------------------- */
    /*    set business node share memory permission    */
    /* ----------------------------------------------- */
    bbuf.shm_perm.mode = BUS_SHM_MODE;
    bbuf.shm_perm.uid = getuid();
    bbuf.shm_perm.gid = getgid();
    rc = shmctl(iet_shm_id, IPC_SET, &bbuf);
    if (rc != 0) {
     sprintf(MSG_STR,"ctf_buld--busi_node share memory permission set error");
     err_log(41000,MSG_STR,RPT_TO_LOG|RPT_TO_TTY,0,0);
    }
    busi_cnt = 0;
    item_cnt = 0;
    cit_size = 0;
    /* ------------------------------------------------------------- */
    /*    establish business node and ctf item table share memory    */
    /* ------------------------------------------------------------- */
    tbl_crt();
    memcpy(ctfbas,&busi_cnt,4);  /* copy the total business cnt to the */
                                  /* header of the CTF                  */
/*  sprintf(MSG_STR,"Dump ctfbas busi_cnt=%d",busi_cnt);
    err_log(100, MSG_STR,RPT_TO_LOG, ctfbas, 300);
    err_log(100, MSG_STR,RPT_TO_LOG, ctfbas + 4, 300);*/
    /* -------------------- */
    /*    close ctf file    */
    /* -------------------- */
    close(c_fd);
    printf("%s", CTF_LOADED);
    UCP_TRACE_OVER;
}

tbl_crt()
{
    UCP_TRACE(P_tbl_crt);
    /* --------------------------- */
    /*    check ctf record type    */
    /* --------------------------- */

    while((rc = read(c_fd, ctf_rd_buf, sizeof(ctf_head))) > 0) {
       if (ctf_rd_buf[0] == M_CTF_HEAD) {
          busi_estl();       /*  calculate total CTF size for all businesses */
       }
       else {
          item_estl();
       };
    };
    UCP_TRACE_OVER;
}

busi_estl()
{
    int  i;

    UCP_TRACE(P_busi_estl);
    /* ----------------------------- */
    /*    establish business node    */
    /* ----------------------------- */
    ctf_hd = (ctf_head *)ctf_rd_buf;
    cur_busi_nd = (busi_ctf *)(ctfbusi+busi_cnt*sizeof(busi_ctf));
    i = 0;
    while(i < busi_cnt) {
       nxt_busi_nd = (busi_ctf *)(ctfbusi+i*sizeof(busi_ctf));

       if (nxt_busi_nd->busi_type == ctf_hd->busi_type) {
          err_log(41000,"busi_estl--dupl. busi_type",RPT_TO_LOG|RPT_TO_TTY,0,0);
          UCP_TRACE_OVER;
       }
       else {
             i++;
       }
    }  /*  end while(i < busi_cnt)  */

    busi_cnt++;

    /* ------------------------------------------------- */
    /*    add the ctf_size of each business to cit_size  */
    /* ------------------------------------------------- */
    cur_busi_nd->busi_type = ctf_hd->busi_type;
    cur_busi_nd->tot_item  = ctf_hd->tot_item;
    cur_busi_nd->ctf_size  = ctf_hd->ctf_size;

    cit_size += ctf_hd->ctf_size;

    /* -------------------------------------------- */
    /*    pointer to ctf item table share memory    */
    /* -------------------------------------------- */
    cur_busi_nd->tbl_idx = item_cnt;
    UCP_TRACE_OVER;
}

/*  create CTF item TABLE (CFT)   */
item_estl()
{
    UCP_TRACE(P_item_estl);
    ctf_im = (ctf_item *)ctf_rd_buf;

    /* ------------------------------- */
    /*    copy ctf_item to tbl_item    */
    /* ------------------------------- */
    tmp_tbl = (tbl_item *)(cadd + item_cnt * sizeof(tbl_item));
/*  sprintf(MSG_STR,"ctf_im:ctf_name=%.30s",ctf_im->ctf_name);
    err_log(100,MSG_STR,RPT_TO_LOG,0,0);
    sprintf(MSG_STR,"ctf_im:dat_type=%c,dat_len=%d,ctf_relat=%d,dot_pos=%d"
               ,ctf_im->dat_type, ctf_im->dat_len,
               ctf_im->ctf_relat, ctf_im->dot_pos);
    err_log(100,MSG_STR,RPT_TO_LOG,0,0);*/
    strncpy(tmp_tbl->ctf_name, ctf_im->ctf_name, CTF_NAME_LEN);
    tmp_tbl->dat_type = ctf_im->dat_type;
    tmp_tbl->dat_len = ctf_im->dat_len;
    tmp_tbl->ctf_len = ctf_im->ctf_len;
    tmp_tbl->ctf_offs = ctf_im->ctf_offs;
    tmp_tbl->ctf_relat = ctf_im->ctf_relat;
    tmp_tbl->dot_pos = ctf_im->dot_pos;
    tmp_tbl->ini_value = ctf_im->ini_value;
/*  sprintf(MSG_STR,"tmp_tbl:dat_type=%c,dat_len=%d,ctf_relat=%d,dot_pos=%d"
               ,tmp_tbl->dat_type, tmp_tbl->dat_len,
               tmp_tbl->ctf_relat, tmp_tbl->dot_pos);
    err_log(100,MSG_STR,RPT_TO_LOG,0,0);*/

    item_cnt++;
    UCP_TRACE_OVER;
}

srh_item(bus_type,ctf_name,Ctf_item_ptr)
char bus_type;
char *ctf_name;
Ctf_item_st  *Ctf_item_ptr;
{
  int i, j;
  int ctf_idx;

    UCP_TRACE(P_srh_item);
    memcpy(&busi_cnt, ctfbas, 4);
/*
    sprintf(MSG_STR,"srh_item:ctf_name=%.30s",ctf_name);
    err_log(100,MSG_STR,RPT_TO_LOG,0,0);
*/
    for(j=0;j<busi_cnt;j++) {
    cur_busi_nd = (busi_ctf *)(ctfbusi+j*sizeof(busi_ctf));
       if (cur_busi_nd->busi_type == bus_type) {
         i=0;
         ctf_idx=cur_busi_nd-> tbl_idx;
         while( i < cur_busi_nd->tot_item ) {
            tmp_tbl = (tbl_item *)(cadd + ctf_idx * sizeof(tbl_item));
/*
            sprintf(MSG_STR,"srh_item:ctf_name=%.30s,Tmp_ctf_name=%.30s",
                   ctf_name,tmp_tbl->ctf_name);
            err_log(1000,MSG_STR,RPT_TO_LOG,0,0);
*/
            if (strncmp(tmp_tbl->ctf_name,ctf_name,CTF_NAME_LEN) == 0) {
               Ctf_item_ptr->dat_type = tmp_tbl->dat_type;
               Ctf_item_ptr->dat_len  = tmp_tbl->dat_len;
               Ctf_item_ptr->ctf_relat= tmp_tbl->ctf_relat;
               Ctf_item_ptr->dot_pos  = tmp_tbl->dot_pos;
               Ctf_item_ptr->ini_value  = tmp_tbl->ini_value;
/*
       sprintf(MSG_STR,"srh_item:dat_type=%d,dat_len=%d,ctf_relat=%d,dot_pos=%d"
               ,Ctf_item_ptr->dat_type, Ctf_item_ptr->dat_len,
               Ctf_item_ptr->ctf_relat, Ctf_item_ptr->dot_pos);
       err_log(100,MSG_STR,RPT_TO_LOG,0,0);
*/
               UCP_TRACE_END(0);
            }
            else {
               i++;
               ctf_idx++;
            }    /* end if strncmp()  */
         }  /*  end while loop  */
         sprintf(MSG_STR,"srh_item:ctf item=%.30s not found",ctf_name);
         err_log(1000,MSG_STR,RPT_TO_LOG,0,0);
         UCP_TRACE_END(-1);
       }
       else {
	 continue;
       }  /*  endif (cur_busi_nd == busi_type) */
    }  /*  end for loop  */
    err_log(1000,"srh_item:business type does not be defined in CTF",
            RPT_TO_LOG|RPT_TO_TTY,0,0);
    UCP_TRACE_END(-1);
}
