#include "errlog.h"
#include "lxcpgdef.def"
#include "imctxnpr.def"
#include "diff.def"

#define  INT long
#define  MSG_STR g_caMsg
extern int errno;
/*Add Miao 980901 for tu980514 begin*/
int gudnum=0;
/*Add Miao 980901 for tu980514 end*/

#define  FILE_NAME_LEN          80
extern char  GUD_FILE_DAT[FILE_NAME_LEN];               
token_par(argc,para,fp)
int argc;
struct token_type para[];
FILE *fp;
{
   int i,j,k,tmp;
   char buff[LINE_LEN];

   UCP_TRACE(P_token_par);
   tmp=get_token(fp,buff,para[0].delimit);
   i=0;
   while ( i < argc ) {
     if ( tmp != 0 ) {
        para[i].rtn_code[0]=PSR_NODATA_ERR;
     }
     else {
        para[i].rtn_code[0]=PSR_NORMAL;
        switch (para[i].var_type) {
        case 's':
        case 'S':strcpy(para[i].vt.char_loc,buff);
                 break;
        case 'd':
        case 'D':
                 if ( isdcmnl(buff) != 0 ) {
                   para[i].rtn_code[0]=PSR_NODATA_ERR;
                 }
                 else {
                   tmp=atoi(buff);
                   memcpy((int *)(para[i].vt.int_loc),&tmp,sizeof(tmp));
                 }
                 break;
        default :para[i].rtn_code[0]=PSR_VAR_TYP_ERR;
                 break;
        }  /* for case */
        tmp=strlen(buff);
        if ( para[i].fix_len == 'Y' ) {
           if ( tmp != para[i].max_len ) {
              para[i].rtn_code[0] |= PSR_LEN_ERR;
           }
        }
        else {
           if ( tmp > para[i].max_len ) {
              para[i].rtn_code[0] |= PSR_LEN_ERR;
           }
        }
     } /* for if ( tmp != 0 ) */
     i++;
     if (i < argc)
        tmp=get_token(fp,buff,para[i].delimit);
   }  /* for while ( i < argc ) */
   UCP_TRACE_END(0);
}

/***************************************************************************/
/* if delimit == 'E' -> end of parsing the current file, next time call    */
/*                      this routine will parse the other file.            */
/* get a token from the file whoes file pointer is 'fp'.                   */
/* return 0 --> normal                                                     */
/* return -2 --> no more token                                             */
/***************************************************************************/
get_token(fp,token,delimit)
FILE *fp;
char *token;
char delimit;
{
  static char first='Y';
  static char buff[LINE_LEN];
  char delimit_str[20];
/* added by alexwu on 19950413 BEGIN */
  char *p;
/* added by alexwu on 19950413 END */

  UCP_TRACE(P_get_token);

  if ( delimit == 'E' ) {  /* reset the 'first' flag for the end of parsing
                              current input file */
     first='Y';
     UCP_TRACE_END(0);
  }
  if ( delimit == ' ' )
     strcpy(delimit_str," \t\n");
  else
     sprintf(delimit_str,"%c",delimit);

  if ( first=='Y' || first=='y' ) {
    first = 'N';
    if ( fgets(buff,LINE_LEN,fp) == NULL ) {
      UCP_TRACE_END(-2);
    }
/*
    strcpy(token,strtok(buff," \t\"\n"));
*/
/* modified by alexwu on 19950413
    strcpy(token,strtok(buff,delimit_str));
*/
    if ((p=strtok(buff,delimit_str)) != (char*) NULL)
        strcpy(token,p);
    else
        token[0] = '\0';

    if ( ((token[0] == 'L') && (token[1] ==1) && (token[2] == 4)) ||
            (strlen(token) == 0)  ) {
      UCP_TRACE_END(-2); /* no more token */
    }
    else {
      UCP_TRACE_END(0);
    }
  }   /* not first call get_token */
  else {
/*
      strcpy(token,strtok(NULL," \t\"\n"));
*/
/* modified by alexwu on 19950413
      strcpy(token,strtok(NULL,delimit_str));
*/
      if ((p=strtok(NULL,delimit_str)) != (char*) NULL)
        strcpy(token,p);
      else
        token[0] = '\0';

      if ( ((token[0] == 'L') && (token[1] ==1) && (token[2] == 4)) ||
        (strlen(token) == 0) ) {
        if ( fgets(buff,LINE_LEN,fp) == NULL ) {
          UCP_TRACE_END(-2);
        }
        else {
/*
          strcpy(token,strtok(buff," \t\"\n"));
*/
/* modified by alexwu on 19950413
          strcpy(token,strtok(buff,delimit_str));
*/
          if ((p=strtok(buff,delimit_str)) != (char*) NULL)
        	strcpy(token,p);
          else
        	token[0] = '\0';

          if ( ((token[0] == 'L') && (token[1] ==1) && (token[2] == 4)) ||
            (strlen(token) == 0) ) {
            UCP_TRACE_END(-2); /* no more token */
          }
          else {
            UCP_TRACE_END(0);
          }
        }  /* for if ( fgets(buff,LINE_LEN,f_fp) == NULL )  */
      }
      else {
        UCP_TRACE_END(0);
      }
  } /* for if ( first=='Y' || first=='y' ) */
}

/****************************************************************************/
/* convert a byte to an integer (YYYYYYYY) -> 255                           */
/*                              (YNNNNNNN) -> 128                           */
/*                              (NNNNNYYY) ->   7                           */
/****************************************************************************/
bit_to_int(s)
char *s;
{
  int i,j,temp;

  temp=0;
  j=2;
  for (i=7;i>=0;i--) {
     if ( (s[i]!='0') && (s[i]!='1') && (s[i]!='y') && (s[i]!='Y') &&
          (s[i]!='n') && (s[i]!='N') ){
       return(-1);
     }
     if ((s[i]=='1') || (s[i]=='y') || (s[i]=='Y')) {
         temp=temp+(j/2);
     }
     j*=2;
  }
  return(temp);
}

/* ******************************************************************** */
/*      check_gud() : fine out the relative number in the gud_file      */
/* ******************************************************************** */
/*#define GUD_REC_SIZE 3000  Mark Miao 980901 for tu980514 */
int   check_gud(gud_no,gud_rel)
char  *gud_no;
INT   *gud_rel;
{
    static gud_cnt=0;
    

    /* Modify Miao 980901 for tu980514 begin*/
    /*
    static struct gud_node {
                  char gud_no[5];
 * mark Dao      } gud_rec[600];  * 
                 } gud_rec[GUD_REC_SIZE];   * update Dao810722 * 
    */
    static iFirst=0;
    static struct gud_node {
                 char gud_no[5];
                 } *gud_rec;
    /* Modify Miao 980901 for tu980514 end*/
   
    struct  gud_rec_def {
        char gud_no[5];      /* guild number                    */
         /* marked by wjc 1994.12.16 char gud_line[51];*/
        char gud_line[81];  /* guild line description          */
    } gud_buf;
    FILE  *fd;
    INT   i;

   /*Add Miao 980901 for tu980514 begin*/
   if ( iFirst == 0 ){
      gudnum=gud_cal();
      gud_rec=(struct gud_node *)malloc(gudnum * sizeof(struct gud_node));
      iFirst++;
   }
   /*Add Miao 980901 for tu980514 end*/
    
    if (gud_cnt == 0) {
       fd = fopen(GUD_FILE_DAT,"r");
       if  (fd == NULL) {
         sprintf(MSG_STR,"check_gud:GUILD FILE OPEN ERROR errno=%d",errno);
         err_log(11000,MSG_STR,RPT_TO_LOG|RPT_TO_TTY,0,0);
         return(-1);
       }
       while ((fgets((char *)&gud_buf, sizeof(gud_buf), fd)) != NULL) {
         strncpy(gud_rec[gud_cnt].gud_no, gud_buf.gud_no,4);
         gud_rec[gud_cnt].gud_no[4]='\0';
         /* Modify Miao 980901 for tu980514 begin*/
         /*
         if ( ++gud_cnt > GUD_REC_SIZE) {
            printf("ERROR:gud_buffer overflow! in check_gud()! \n");
            return(-1);
         }
         */
         ++gud_cnt;
         /* Modify Miao 980901 for tu980514 end*/
       }
       fclose(fd);
    }
    if ( gud_no[0] == '*') {
      *gud_rel=-1L;
      return(0);
    }
    for (i=0;i<gud_cnt;i++) {
       if ( strncmp(gud_rec[i].gud_no,gud_no,4) == 0) {
         *gud_rel=i;
/*
         printf("gud_no=%.4s,rel=%u\n",gud_no,i);
*/  
         return(0);
       }
    }
    printf("gud_line not found !\n");
    return(-1);
}

/** ************************************************************************ */
/*& ROUTINE_NAME:check_hlp(hlp_no)                                           */
/*& hlp_no:pointer of char, the helpid which to be searched in the help file */
/*& return value:4-byte interger, the record no of the hlp_no in online help */
/*&              file.                                                       */
/*&              -1 -> no help field is needed, that is hlp_no="****"        */
/*&              -2 -> the specified help is not defined in the help file    */
/*& ************************************************************************ */
INT   check_hlp(hlp_no)
char  *hlp_no;
{
   return(atoi(hlp_no));
}

/* ******************************************************************** */
/*      gud_cal() :calculator gud no in the gud_file                    */
/*      Add by Miao on 19980903 for tu980514                            */
/* ******************************************************************** */
int   gud_cal()
{
    int gud_cnt=0;
    FILE  *fd;
    struct  gud_rec_def {
        char gud_no[5];      
        char gud_line[81];  
    } gud_buf;

    fd = fopen(GUD_FILE_DAT,"r");
    if  (fd == NULL) {
         sprintf(MSG_STR,"check_gud:GUILD FILE OPEN ERROR errno=%d",errno);
         err_log(11000,MSG_STR,RPT_TO_LOG|RPT_TO_TTY,0,0);
         return(-1);
    }
    while ((fgets((char *)&gud_buf, sizeof(gud_buf), fd)) != NULL) {
         gud_cnt++;
    }
    fclose(fd);
    return(gud_cnt);
}

