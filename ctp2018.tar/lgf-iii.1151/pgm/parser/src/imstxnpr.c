#include "errlog.h"
/* #include "itcflefm" */
#include "imctblld.def"
#include "imctblld.str"
#include "imctxnpr.def"
#include "lxcpgdef.def"
#include "diff.def"
#ifndef DOS
#include <sys/ipc.h>
#include <sys/shm.h>
#endif
#include <stdio.h>
#include <fcntl.h>
 
int     CTF_SHM_KEY = 0x1234567;
int     IET_SHM_KEY = 0x7654321;

#define  MSG_STR g_caMsg
#define  FILE_NAME_LEN          80

extern char curr_busi;        /* record the current business type parser read */
extern char curr_txnid[TXN_LEN+1];/* record the current txn-id parser read */
extern char curr_pgno[PG_LEN+1];  /* record the current page-no parser read */
extern char curr_row[ROW_LEN+1];  /* record the current row-no parser read */
extern char curr_col[COL_LEN+1];  /* record the current column-no parser read */
extern char err_buf[100];
extern int  item_cnt;         /* record the item count of a transaction */
extern int  curr_item_cnt;    /* record the current item count  */
extern int errno;
extern char  TXN_DATAFILE[FILE_NAME_LEN];           
extern char  TXN_FILE[FILE_NAME_LEN];               
extern char  TXN_ERR_FILE[FILE_NAME_LEN];               
extern char  TXN_FILE_TMP[FILE_NAME_LEN];             
extern char  MENU_CROSSCHK_FILE[FILE_NAME_LEN];          
extern char  ERR_FILE[FILE_NAME_LEN];      
FILE   *cross_chk;
char  TXN_ERR_FILE1[FILE_NAME_LEN];               
char  TXN_FILE_TMP1[FILE_NAME_LEN];             
/* for txn_proc() subroutine
*/
  char txn_id[LINE_LEN],txn_name[LINE_LEN],sec_lev[LINE_LEN];
  char txn_attr[LINE_LEN],txn_pgm[LINE_LEN],help_id[LINE_LEN];
  char pre_tri[LINE_LEN],post_tri[LINE_LEN];
/* for itm_proc() subroutine
*/
  char guide_line[LINE_LEN],itm_attr[LINE_LEN],ctf_field[LINE_LEN];
  char chk_rtn1[LINE_LEN],chk_rtn2[LINE_LEN],help_id[LINE_LEN];
txn_file_par(phase)
int phase;
{
  /* cross_chk is a temporary file for menu parser corss checking */
  FILE *f_fp,*f_fp1;
  int   f_fp2;
  struct token_type token_attr[2];
  int  i,j,k;
  char busi_type[MAX_BUSI];
  char buff1[LINE_LEN];
  char process_seq;
  int  tmp_id;
  FILE *f_fp3;

  UCP_TRACE(P_txn_file_par);
  if ( (phase != 1) && (phase !=2) ) {
      UCP_TRACE_END(-1);
  }
  if ( (f_fp=fopen(TXN_DATAFILE,"r")) == NULL ) {
    printf("ERROR:open txn data file open error ! errno=%d\n",errno);
    UCP_TRACE_END(-1);
  }
  if ( (f_fp1=fopen(TXN_ERR_FILE,"w")) == NULL ) {
    printf("ERROR:txn data error file open error ! errno=%d\n",errno);
    UCP_TRACE_END(-1);
  }

  TXN_ERR_FILE1[0]='\0';
  TXN_FILE_TMP1[0]='\0';
  strcpy(TXN_ERR_FILE1, TXN_ERR_FILE);
  TXN_ERR_FILE1[ strlen(TXN_ERR_FILE1) - 1 ] = '1';
  strcpy(TXN_FILE_TMP1, TXN_FILE_TMP);
  TXN_FILE_TMP1[ strlen(TXN_FILE_TMP1) - 1 ] = '1';

  if ( (f_fp3=fopen(TXN_ERR_FILE1,"w")) == NULL ) {
    printf("ERROR:txn data error file open error ! errno=%d\n",errno);
    UCP_TRACE_END(-1);
  }
  if (phase == 2) {
    if ( (cross_chk=fopen(MENU_CROSSCHK_FILE,"w")) == NULL ) {
    printf("ERROR:menu parser cross check temp file open err!errno=%d\n",errno);
      UCP_TRACE_END(-1);
    }
    printf("++++++ %s is renamed to %s\n",TXN_FILE,TXN_FILE_TMP);
#ifdef DOS
    sprintf(buff1,"copy %s  %s",TXN_FILE,TXN_FILE_TMP);
#else
    sprintf(buff1,"mv %s  %s",TXN_FILE,TXN_FILE_TMP);
#endif
    system(buff1);
    if ( (f_fp2=open(TXN_FILE,O_CREAT|O_TRUNC|O_RDWR,0666)) == -1 ) {
       printf("ERROR:txn file open error ! errno=%d\n",errno);
       printf("++++++ %s is renamed to %s\n",TXN_FILE_TMP,TXN_FILE_TMP);
#ifdef DOS
       sprintf(buff1,"copy %s  %s",TXN_FILE_TMP,TXN_FILE);
#else
       sprintf(buff1,"mv %s  %s",TXN_FILE_TMP,TXN_FILE);
#endif
       system(buff1);
       UCP_TRACE_END(-1);
    }
    if (ctf_buld() == -1) {
       err_log(1000,"load CTF error !",RPT_TO_LOG,0,0);
       UCP_TRACE_END(-1);
    }
  }
  for (i=0;i<MAX_BUSI;i++) busi_type[i]=0;
  process_seq='3';
  curr_item_cnt=item_cnt=0;
  token_attr[0].var_type=STR_TYPE;
  token_attr[0].max_len=LINE_LEN;
  token_attr[0].fix_len='N';
  token_attr[0].vt.char_loc=buff1;
  token_attr[0].delimit=' ';
  token_par(1,token_attr,f_fp);
  while (1) {
     switch(token_attr[0].rtn_code[0]) {
       case PSR_NODATA_ERR :
                            if (phase == 1) {
                                chk_itm_num(phase,f_fp,f_fp1,f_fp2);
                                get_token(f_fp,token_attr,'E');
                                fclose(f_fp);
                                fclose(f_fp1);
                                fclose(f_fp3);
                                printf("sorting %s file ...\n",TXN_DATAFILE);
                                sprintf(buff1,"sort <%s > %s",TXN_ERR_FILE,
                                        TXN_FILE_TMP);
                                system(buff1);
                                sprintf(buff1,"sort <%s > %s",TXN_ERR_FILE1,
                                        TXN_FILE_TMP1);
                                system(buff1);
/*
         system("copy ../TABLE/txn_file.tmp bbb");;
*/
                                printf("sorting O.K. ! \n",TXN_DATAFILE);
                                printf("begin to check any duplicated declaration ...\n");
                                if (chk_dup(TXN_FILE_TMP,TXN_ERR_FILE) == -1) {
/* Modified by Willy -- begin */
                                  printf("fatal error: duplicated declaration occured!\n");
                                  printf("==>please check error file %s\n",
                                         TXN_ERR_FILE);
/* Modified by Willy -- end */
/* Marked to check duplicated CTF item in the same txn 19961001 -- begin x/
                                  UCP_TRACE_END(-1);
/x Marked to check duplicated CTF item in the same txn 19961001 -- end */
                                }

/* Modified to check duplicated CTF item in the same txn 19961001 -- begin */
                                if (chk_dup_ctf(TXN_FILE_TMP1,TXN_ERR_FILE1) == -1) {
                                  printf("fatal error: ctf item duplicated in the same txn!\n");
                                  printf("==>please check error file %s\n",
                                         TXN_ERR_FILE1);
                                  UCP_TRACE_END(-1);
                                }
/* Modified to check duplicated CTF item in the same txn 19961001 -- end */
                                UCP_TRACE_END(0);
                            }
                            else {
                                fclose(f_fp);
                                fclose(f_fp1);
/* Modified to check duplicated CTF item in the same txn 19961001 -- begin */
                                fclose(f_fp3);
/* Modified to check duplicated CTF item in the same txn 19961001 -- end */
                                close(f_fp2);
                                fclose(cross_chk);
       /*************************************************************/
       /*   release CTF & IET shared memory here !                  */
       /*************************************************************/
                                tmp_id = shmget(CTF_SHM_KEY, 0, 0);
                                if  (tmp_id != -1)
                                    shmctl(tmp_id, IPC_RMID,0);
                                tmp_id = shmget(IET_SHM_KEY, 0, 0);
                                if  (tmp_id != -1)
                                   shmctl(tmp_id, IPC_RMID,0);
                                printf("IET.DAT PARSERED OVER !\n");
                            }
                            UCP_TRACE_END(0);
       case PSR_LEN_ERR    :
       case PSR_VAR_TYP_ERR:
                            sprintf(err_buf,"ERROR:token get error errno=%d ",
                                    token_attr[0].rtn_code[0]);
                            err_hdl(phase,f_fp,f_fp1,f_fp2,err_buf);
                            UCP_TRACE_END(-1);
       case PSR_NORMAL     :
       default             :break;
     }
     switch(rec_type(f_fp,buff1,&process_seq)) {
        case 0:
               chk_itm_num(phase,f_fp,f_fp1,f_fp2);
               strncpy(curr_txnid,STAR_STR,TXN_LEN);
               strncpy(curr_pgno,STAR_STR,PG_LEN);
               strncpy(curr_row,STAR_STR,ROW_LEN);
               strncpy(curr_col,STAR_STR,COL_LEN);
               j=-1;
               for (i=0;i<MAX_BUSI;i++) {
                 if (busi_type[i] == buff1[1]) {
                   err_hdl(phase,f_fp,f_fp1,f_fp2,
                           "business redeclaration error ! \n");
                   UCP_TRACE_END(-1);
                 }
                 else {
                   if (busi_type[i] == 0) {
                      curr_busi=busi_type[i]=buff1[1];
                      strncpy(curr_txnid,STAR_STR,TXN_LEN);
                      strncpy(curr_pgno,STAR_STR,PG_LEN);
                      strncpy(curr_row,STAR_STR,ROW_LEN);
                      strncpy(curr_col,STAR_STR,COL_LEN);
                      j=i;
                      break;
                   }
                 }
               }  /* for  for (i=0;i<MAX_BUSI;i++) */
               if (j == -1) {
                  err_hdl(phase,f_fp,f_fp1,f_fp2,
                          "too much business declaration error !\n");
                  UCP_TRACE_END(-1);
               }
               else {
                  fprintf(f_fp1,"%c%s%s%s%s %s \n",curr_busi,curr_txnid,
                          curr_pgno,curr_row,curr_col,token_attr[0].vt.char_loc);
               }
               break;
        case 1:
               strncpy(curr_txnid,DASH_STR,TXN_LEN);
               curr_txnid[0]=curr_busi;
               strncpy(curr_pgno,DASH_STR,PG_LEN);
               strncpy(curr_row,DASH_STR,ROW_LEN);
               strncpy(curr_col,DASH_STR,COL_LEN);
               if ( busi_proc(phase,f_fp,f_fp1,f_fp2) != 0 ) {
                  err_hdl(phase,f_fp,f_fp1,f_fp2,
                          "business declaration error !\n");
                  UCP_TRACE_END(-1);
               }
               break;
        case 2:
               chk_itm_num(phase,f_fp,f_fp1,f_fp2);
               curr_item_cnt=0;
               item_cnt=0;
               strncpy(curr_pgno,DOT_STR,PG_LEN);
               strncpy(curr_row,DOT_STR,ROW_LEN);
               strncpy(curr_col,DOT_STR,COL_LEN);
               if ( txn_proc(phase,f_fp,f_fp1,f_fp2,cross_chk) != 0 ) {
                  err_hdl(phase,f_fp,f_fp1,f_fp2,
                          "transaction declaration error !\n");
                  UCP_TRACE_END(-1);
               }
               break;
        case 3:
               if ( itm_proc(phase,f_fp,f_fp1,f_fp2) != 0 ) {
                  err_hdl(phase,f_fp,f_fp1,f_fp2,
                          "item declaration error !\n");
                  UCP_TRACE_END(-1);
               }
               if (phase == 1) {
                 fprintf(f_fp3,"%c%s%s%s\n",
                         curr_busi,curr_txnid,itm_attr,ctf_field);
               }
               break;
        case 4:
               if ( itm_proc(f_fp,f_fp1) != 0 )
                  {
                  err_hdl(phase,f_fp,f_fp1,f_fp2,
                          "comment processing error ! \n");
                  UCP_TRACE_END(-1);
                  }
               break;
        case -2:
                err_hdl(phase,f_fp,f_fp1,f_fp2,
                        "invalid declaration sequence ! \n");
                UCP_TRACE_END(-1);
        case -1:
        default:
                err_hdl(phase,f_fp,f_fp1,f_fp2,
                        "undefined record type error !\n");
                UCP_TRACE_END(-1);
     }  /* for switch() */
     token_attr[0].var_type=STR_TYPE;
     token_attr[0].max_len=LINE_LEN;
     token_attr[0].fix_len='N';
     token_attr[0].vt.char_loc=buff1;
     token_attr[0].delimit=' ';
     token_par(1,token_attr,f_fp);
   } /* for while(1) */
   UCP_TRACE_END(0);
}
/* ************************************************************************* */
/* Determine what kind of record read :                                      */
/* business delimit record     -> return 0                                   */
/* business description record -> return 1                                   */
/* txn description record      -> return 2                                   */
/* item description record     -> return 3                                   */
/* comment                     -> return 4                                   */
/* undefined record            -> return -1                                  */
/* invalid declaration seq.    -> return -2                                  */
/* ************************************************************************* */
rec_type(f_fp,s,process_seq)
FILE *f_fp;
char *s;
char *process_seq;
{
  struct token_type token_attr[1];
  char   buff[LINE_LEN];

  UCP_TRACE(P_rec_type);
/*
  sprintf(MSG_STR,"enter rec_type=%c",s[0]);
  err_log(1000,MSG_STR,RPT_TO_LOG,0,0);
*/

  switch(s[0]) {
   case '/':if (s[1] == '*') {
               UCP_TRACE_END(4);
            }
            else {
               UCP_TRACE_END(-1);
            }
   case '%':if ( isalnum(s[1]) != 0 ) {   /* '%' is followed by 0~9,a~z,A~Z */
            /* modify by WuChihLiang 1995/01/24 for %buss_type can following
               by txn node(for no data item case).
               if ( (process_seq[0] == '3') ) { */
               if ( ( process_seq[0] == '2') || ( process_seq[0] == '3')) {
                  process_seq[0] = '0';
                  UCP_TRACE_END(0);
               }
               else {
                  UCP_TRACE_END(-2);
               }
            }
            else {    /* read the business id after '%' */
               token_attr[0].var_type=STR_TYPE;
               token_attr[0].max_len=1;
               token_attr[0].fix_len='Y';
               token_attr[0].vt.char_loc=buff;
               token_attr[0].delimit=' ';
               token_par(1,token_attr,f_fp);
               if (token_attr[0].rtn_code[0] != 0) { /* invalid business id */
                  UCP_TRACE_END(-1);
               }
               else {
                  s[1]=buff[0];
                  s[2]='\0';
                  if ( process_seq[0] == '3') {
                     process_seq[0] = '0';
                     UCP_TRACE_END(0);
                  }
                  else {
                     UCP_TRACE_END(-2);  /* invalid declaration sequence ! */
                  }
               }
            }
   case '1':if (process_seq[0] != '0') {
              UCP_TRACE_END(-2);
            }
            else {
              process_seq[0] = '1';
              UCP_TRACE_END(1);
            }
   case '2':
/* 810826 HSU updated modify 7 */
/*
if ( (process_seq[0] != '1') && (process_seq[0] != '3') ) {
              UCP_TRACE_END(-2);
            }
            else {
              process_seq[0] = '2';
              UCP_TRACE_END(2);
            }
*/
              process_seq[0] = '2';
              UCP_TRACE_END(2);
   case '3':if ( (process_seq[0] != '2') && (process_seq[0] != '3') ) {
              UCP_TRACE_END(-2);
            }
            else {
              process_seq[0] = '3';
              UCP_TRACE_END(3);
            }
   default : UCP_TRACE_END(-1);
  }  /* for switch(s[0]) */
  UCP_TRACE_END(0);
}

busi_proc(phase,fp,fp1,fp2)
int  phase;
FILE *fp,*fp1;
int  fp2;
{
  struct token_type ta[3];
  char busi_type[LINE_LEN],busi_name[LINE_LEN],busi_dir[LINE_LEN];
  int i,j;
  busi_head busi_node;

  UCP_TRACE(P_busi_proc);

  ta[0].var_type=STR_TYPE;
  ta[0].max_len=1;
  ta[0].vt.char_loc=busi_type;
  ta[0].fix_len='Y';
  ta[0].delimit=' ';

  ta[1].var_type=STR_TYPE;
  ta[1].max_len=4;
  ta[1].vt.char_loc=busi_name;
  ta[1].fix_len='Y';
  ta[1].delimit=' ';

  ta[2].var_type=STR_TYPE;
  ta[2].max_len=2;
  ta[2].vt.char_loc=busi_dir;
  ta[2].fix_len='Y';
  ta[2].delimit=' ';
  token_par(3,ta,fp);
  fprintf(fp1,"%c%s%s%s%s 1 %s \"%s\" %s\n",curr_busi,curr_txnid,curr_pgno,
          curr_row,curr_col,ta[0].vt.char_loc,ta[1].vt.char_loc,ta[2].vt.char_loc);
  j=0;
  for (i=0;i<3;i++) {
     if (ta[i].rtn_code[0] != 0) {
        j=1;
        switch(i) {
          case 0:fprintf(fp1,"ERROR:business type parsing error errno=%d\n",
                         ta[i].rtn_code[0]);
                 break;
          case 1:fprintf(fp1,"ERROR:business name parsing error errno=%d\n",
                         ta[i].rtn_code[0]);
                 break;
          case 2:fprintf(fp1,"ERROR:business directory parsing error errno=%d\n",
                         ta[i].rtn_code[0]);
                 break;
        }
     }
  }
  if ( j == 1 ) {   /* error occured ! */
      UCP_TRACE_END(-1);
  }
  else {
     if ( ta[0].vt.char_loc[0] == curr_busi ) {
       if ( phase == 1 ) {  /* in phase 1 of parsing process */
          UCP_TRACE_END(0);
       }
       else {               /* phase 2 parsing process */
              /* move data from txn_file.dat to txn_file */
          busi_node.rec_head='1';
          busi_node.busi_type=curr_busi;
          /*
          strcpy(busi_node.busi_name,busi_name);
          */
          strcpy(busi_node.busi_dir,busi_dir);
/*
          if ( (busi_node.busi_title=check_gud(busi_name)) == -1 ) {
*/
          if ( check_gud(busi_name,&(busi_node.busi_title)) == -1 ) {
            fprintf(fp1,"ERROR: undefined gud_line no:%s ****\n",busi_name);
            UCP_TRACE_END(-1);
          }
/*
          printf("size=%d\n",sizeof(busi_node));
          err_log(100,"dump",RPT_TO_LOG,&busi_node,70);
*/
          if ( write(fp2,&busi_node,sizeof(busi_node))!=sizeof(busi_node) ) {
             sprintf(MSG_STR,"ERROR:write iet file error errno=%d",errno);
             err_log(1000,MSG_STR,RPT_TO_LOG,0,0);
             UCP_TRACE_END(-1);
          }
          else {
             UCP_TRACE_END(0);
          }
       }
     }
     else {
       fprintf(fp1,"ERROR:inconsistent business type declaration !\n");
       UCP_TRACE_END(-1);
     }
  }
}

txn_proc(phase,fp,fp1,fp2,cr_chk)
int  phase;
FILE *fp,*fp1;
int  fp2;
FILE *cr_chk;
{

  struct token_type ta[9]; /* 9 tokens to be retrieved in a txn descr. rec. */
/*
  char txn_id[LINE_LEN],txn_name[LINE_LEN],sec_lev[LINE_LEN];
  char txn_attr[LINE_LEN],txn_pgm[LINE_LEN],help_id[LINE_LEN];
  char pre_tri[LINE_LEN],post_tri[LINE_LEN];
*/
  int item_no;
  int i,j;
  txn_head txn_node;

  UCP_TRACE(P_txn_proc);
/*
  sprintf(MSG_STR,"enter txn_proc");
  err_log(1000,MSG_STR,RPT_TO_LOG,0,0);
*/
  ta[0].max_len=4;     /* get txn-id */
  ta[0].var_type=STR_TYPE;
  ta[0].vt.char_loc=txn_id;
  ta[0].fix_len='Y';
  ta[0].delimit=' ';

  ta[1].max_len=4;    /* get txn name */
  ta[1].var_type=STR_TYPE;
  ta[1].vt.char_loc=txn_name;
  ta[1].fix_len='Y';
  ta[1].delimit=' ';

  ta[2].max_len=8;     /* get security level */
  ta[2].var_type=STR_TYPE;
  ta[2].vt.char_loc=sec_lev;
  ta[2].fix_len='Y';
  ta[2].delimit=' ';

  ta[3].max_len=1;     /* get txn attribute */
  ta[3].var_type=STR_TYPE;
  ta[3].vt.char_loc=txn_attr;
  ta[3].fix_len='Y';
  ta[3].delimit=' ';

  ta[4].max_len=3;     /* get number of items */
  ta[4].var_type=DECI_TYPE;
  ta[4].vt.int_loc=&item_no;
  ta[4].fix_len='N';
  ta[4].delimit=' ';

  ta[5].max_len=10;    /* get txn program name */
  ta[5].var_type=STR_TYPE;
  ta[5].vt.char_loc=txn_pgm;
  ta[5].fix_len='N';
  ta[5].delimit=' ';

  ta[6].max_len=4;     /* get help id */
  ta[6].var_type=STR_TYPE;
  ta[6].vt.char_loc=help_id;
  ta[6].fix_len='Y';
  ta[6].delimit=' ';

  ta[7].max_len=4;     /* get pre-trigger routine id */
  ta[7].var_type=STR_TYPE;
  ta[7].vt.char_loc=pre_tri;
  ta[7].fix_len='Y';
  ta[7].delimit=' ';

  ta[8].max_len=4;     /* get post-trigger routine id */
  ta[8].var_type=STR_TYPE;
  ta[8].vt.char_loc=post_tri;
  ta[8].fix_len='Y';
  ta[8].delimit=' ';

  token_par(9,ta,fp);
  strcpy(curr_txnid,ta[0].vt.char_loc);
  fprintf(fp1,"%c%s%s%s%s 2 %s \"%s\" %s %s %d %s %s %s %s\n",curr_busi,curr_txnid,
          curr_pgno,curr_row,curr_col,ta[0].vt.char_loc,
          ta[1].vt.char_loc,ta[2].vt.char_loc,
          ta[3].vt.char_loc,item_no,ta[5].vt.char_loc,ta[6].vt.char_loc,
          ta[7].vt.char_loc,ta[8].vt.char_loc);
  j=0;
  for (i=0;i<9;i++) {
     if (ta[i].rtn_code[0] != 0) {
        j=1;
        switch(i) {
          case 0:fprintf(fp1,"ERROR:txn-id parsing error errno=%d\n",
                         ta[i].rtn_code[0]);
                 break;
          case 1:fprintf(fp1,"ERROR:txn-name parsing error errno=%d\n",
                         ta[i].rtn_code[0]);
                 break;
          case 2:fprintf(fp1,"ERROR:txn security level parsing error errno=%d\n",
                         ta[i].rtn_code[0]);
                 break;
          case 3:fprintf(fp1,"ERROR:txn attribute parsing error errno=%d\n",
                         ta[i].rtn_code[0]);
                 break;
          case 4:fprintf(fp1,"ERROR:number of item parsing error errno=%d\n",
                         ta[i].rtn_code[0]);
                 break;
          case 5:fprintf(fp1,"ERROR:txn processing pgm parsing error errno=%d\n",
                         ta[i].rtn_code[0]);
                 break;
          case 6:fprintf(fp1,"ERROR:txn help code parsing error errno=%d\n",
                         ta[i].rtn_code[0]);
                 break;
          case 7:fprintf(fp1,"ERROR:txn pre-trigger-id parsing error errno=%d\n",
                         ta[i].rtn_code[0]);
                 break;
          case 8:fprintf(fp1,"ERROR:txn post-trigger-id parsing error errno=%d\n",
                         ta[i].rtn_code[0]);
                 break;
        }  /* case switch(i) */
     }   /* for if (ta[i].rtn_code[0] != 0) */
  }   /* for 'for (i=0;i<6;i++)' */
  if ( j == 1 ) {   /* error occured ! */
      UCP_TRACE_END(-1);
  }
  else {
     if ( ta[0].vt.char_loc[0] != curr_busi ) {
       j=2;
       fprintf(fp1,"ERROR:invalid txn code !\n");
     }
     for (i=0;i<8;i++) {
       if ( (ta[2].vt.char_loc[i] != 'Y') && ( ta[2].vt.char_loc[i] != 'y') &&
            (ta[2].vt.char_loc[i] != '0') && ( ta[2].vt.char_loc[i] != '1') &&
            (ta[2].vt.char_loc[i] != 'N') && ( ta[2].vt.char_loc[i] != 'n')) {
          fprintf(fp1,"ERROR:invalid security level declaration !\n");
          j=3;
          break;
       }
     }
     if (j>0) {
       UCP_TRACE_END(-1);
     }
     else {
       item_cnt=item_no;
       if ( phase == 1 ) {  /* in phase 1 of parsing process */
         UCP_TRACE_END(0);
       }
       else {               /* phase 2 parsing process */
         /* TCC
         fprintf(cr_chk,"%s %s\n",txn_id,txn_pgm);
         */
         fprintf(cr_chk,"%s %s %s\n",txn_id,txn_pgm, sec_lev);

         txn_node.rec_head='2';
         strcpy(txn_node.txn_code,txn_id);
         /* check_hlp return the record number of the help file */
         if ( (txn_node.help_id=check_hlp(help_id)) == -2 ) {
            fprintf(fp1,"ERROR: undefined online help no:%s ****\n",help_id);
            UCP_TRACE_END(-1);
          }
         txn_node.sec=bit_to_int(sec_lev);
         txn_node.charc=txn_attr[0];
/*
         if ( (txn_node.txn_title=check_gud(txn_name)) == -1 ) {
*/
         if ( check_gud(txn_name,&(txn_node.txn_title)) == -1 ) {
            fprintf(fp1,"ERROR: undefined gud_line no:%s ****\n",txn_name);
            UCP_TRACE_END(-1);
          }
         strcpy(txn_node.txn_pgm,txn_pgm);
         txn_node.tot_item=item_no;
         strcpy(txn_node.trigger1_id,pre_tri);
         strcpy(txn_node.trigger2_id,post_tri);

/*
          printf("size=%d\n",sizeof(txn_node));
         err_log(1000,"dumptxn",RPT_TO_LOG,&txn_node,70);
*/
         if ( write(fp2,&txn_node,sizeof(txn_node))!=sizeof(txn_node) ) {
            sprintf(MSG_STR,"ERROR:write iet file error errno=%d",errno);
            err_log(1000,MSG_STR,RPT_TO_LOG,0,0);
            UCP_TRACE_END(-1);
         }
         else {
            UCP_TRACE_END(0);
         }
       }
     }
  }
}

itm_proc(phase,fp,fp1,fp2)
int  phase;
FILE *fp,*fp1;
int  fp2;
{
  struct token_type ta[12];
  int pg_no,row_no,col_no,bypass_flag,redisplay_flag;
/*
  char guide_line[LINE_LEN],itm_attr[LINE_LEN],ctf_field[LINE_LEN];
  char chk_rtn1[LINE_LEN],chk_rtn2[LINE_LEN],help_id[LINE_LEN];
*/
  txn_item item_node;
  int i,j;
  struct  Ctf_item_str {           /* ctf file data item format defined     */
     char  dat_type;               /* type of data item                     */
     short dat_len;                /* input item length                     */
     INT   ctf_relat;              /* relative number to ctf table          */
     short dot_pos;                /* floating point position from right    */
     char  ini_value;              /* initial value                         */
  };
  typedef struct Ctf_item_str Ctf_item_st;
  Ctf_item_st ctf_item;

  UCP_TRACE(P_itm_proc);
  if ( (++curr_item_cnt) > item_cnt )
    {
    err_hdl(phase,fp,fp1,fp2,"number of item in a txn inconsist !\n");
    UCP_TRACE_END(-1);
    }
  ta[0].max_len=2;     /* get page no */
  ta[0].var_type=DECI_TYPE;
  (ta[0].vt.int_loc) = &pg_no;
  ta[0].fix_len='N';
  ta[0].delimit=' ';

  ta[1].max_len=2;    /* get row no */
  ta[1].var_type=DECI_TYPE;
  (ta[1].vt.int_loc) = &row_no;
  ta[1].fix_len='N';
  ta[1].delimit=' ';

  ta[2].max_len=2;    /* get column no */
  ta[2].var_type=DECI_TYPE;
  ta[2].vt.int_loc=&col_no;
  ta[2].fix_len='N';
  ta[2].delimit=' ';

  ta[3].max_len=4;     /* get guide line id */
  ta[3].var_type=STR_TYPE;
  ta[3].vt.char_loc=guide_line;
  ta[3].fix_len='N';
  ta[3].delimit=' ';

  ta[4].max_len=1;     /* get item attribute */
  ta[4].var_type=STR_TYPE;
  ta[4].vt.char_loc=itm_attr;
  ta[4].fix_len='Y';
  ta[4].delimit=' ';

  ta[5].max_len=30;    /* get ctf-field name */
  ta[5].var_type=STR_TYPE;
  ta[5].vt.char_loc=ctf_field;
  ta[5].fix_len='N';
  ta[5].delimit=' ';

  ta[6].max_len=4;     /* get chk rtn-1 name */
  ta[6].var_type=STR_TYPE;
  ta[6].vt.char_loc=chk_rtn1;
  ta[6].fix_len='N';
  ta[6].delimit=' ';

  ta[7].max_len=4;     /* get chk rtn-2 name */
  ta[7].var_type=STR_TYPE;
  ta[7].vt.char_loc=chk_rtn2;
  ta[7].fix_len='N';
  ta[7].delimit=' ';

  ta[8].max_len=1;     /* get bypass flag */
  ta[8].var_type=DECI_TYPE;
  ta[8].vt.int_loc=&bypass_flag;
  ta[8].fix_len='Y';
  ta[8].delimit=' ';

  ta[9].max_len=4;     /* get help id */
  ta[9].var_type=STR_TYPE;
  ta[9].vt.char_loc=help_id;
  ta[9].fix_len='N';
  ta[9].delimit=' ';

  ta[10].max_len=1;     /* get bypass flag */
  ta[10].var_type=DECI_TYPE;
  ta[10].vt.int_loc=&redisplay_flag;
  ta[10].fix_len='Y';
  ta[10].delimit=' ';

  token_par(11,ta,fp);
  itoa1(pg_no,curr_pgno,PG_LEN);
  itoa1(row_no,curr_row,ROW_LEN);
  itoa1(col_no,curr_col,COL_LEN);
  fprintf(fp1,"%c%s%s%s%s 3 %d %d %d %s %s %30s %s %s %d %s %d\n",
          curr_busi,curr_txnid,curr_pgno,curr_row,curr_col,pg_no,row_no,col_no,
          ta[3].vt.char_loc,ta[4].vt.char_loc,ta[5].vt.char_loc,ta[6].vt.char_loc,
          ta[7].vt.char_loc,bypass_flag,ta[9].vt.char_loc,redisplay_flag);

  j=0;
  for (i=0;i<11;i++) {
     if (ta[i].rtn_code[0] != 0) {
        j=1;
        switch(i) {
          case 0:fprintf(fp1,"ERROR:page-no parsing error errno=%d\n",
                         ta[i].rtn_code[0]);
                 break;
          case 1:fprintf(fp1,"ERROR:row-no parsing error errno=%d\n",
                         ta[i].rtn_code[0]);
                 break;
          case 2:fprintf(fp1,"ERROR:col-no parsing error errno=%d\n",
                         ta[i].rtn_code[0]);
                 break;
          case 3:fprintf(fp1,"ERROR:guide-line number parsing error errno=%d\n",
                         ta[i].rtn_code[0]);
                 break;
          case 4:fprintf(fp1,"ERROR:item attribute parsing error errno=%d\n",
                         ta[i].rtn_code[0]);
                 break;
          case 5:fprintf(fp1,"ERROR:ctf-field name parsing error errno=%d\n",
                         ta[i].rtn_code[0]);
                 break;
          case 6:fprintf(fp1,"ERROR:check rtn 1 parsing error errno=%d\n",
                         ta[i].rtn_code[0]);
                 break;
          case 7:fprintf(fp1,"ERROR:check rtn 2 parsing error errno=%d\n",
                         ta[i].rtn_code[0]);
                 break;
          case 8:fprintf(fp1,"ERROR:bypass flag parsing error errno=%d\n",
                         ta[i].rtn_code[0]);
                 break;
          case 9:fprintf(fp1,"ERROR:field help id parsing error errno=%d\n",
                         ta[i].rtn_code[0]);
                 break;
          case 10:fprintf(fp1,"ERROR:redisplay flag parsing error errno=%d\n",
                         ta[i].rtn_code[0]);
                 break;
        }  /* for 'case' */
     }   /* for if statements */
  }   /* for for loop */
  if ( j == 1 ) {   /* error occured ! */
      UCP_TRACE_END(-1);
  }
  else {
      if (pg_no > MAX_PGNO) {
        j=2;
        fprintf(fp1,"ERROR:page-no:%d exceeds MAX-PG-NO:%d\n",pg_no,MAX_PGNO);
      }
      if (row_no > MAX_ROWNO) {
        j=3;
        fprintf(fp1,"ERROR:row-no:%d exceeds MAX-ROW-NO:%d\n",row_no,MAX_ROWNO);
      }
      if (col_no > MAX_COLNO) {
        j=4;
        fprintf(fp1,"ERROR:column-no:%d exceeds MAX-COL-NO:%d\n",col_no,MAX_COLNO);
      }
      if ( (bypass_flag !=0) && (bypass_flag !=1) )  {
        j=5;
        fprintf(fp1,"ERROR:invalid bypass flag:%d\n",bypass_flag);
      }
      if ( val_attr(itm_attr[0],bypass_flag,redisplay_flag) == 0 )  {
        j=6;
        fprintf(fp1,"ERROR:invalid item attribute:%c\n",itm_attr[0]);
      }
      if ( j > 0 ) {
        UCP_TRACE_END(-1);
      }
      else {
       if ( phase == 1 ) {  /* in phase 1 of parsing process */
          UCP_TRACE_END(0);
       }
       else {               /* phase 2 parsing process */
          item_node.rec_head='3';
/*
          if ( (item_node.gud_line=check_gud(guide_line)) == -1 ) {
*/
          if ( check_gud(guide_line,&(item_node.gud_line)) == -1 ) {
             fprintf(fp1,"ERROR: undefined gud_line no:%s ****\n",guide_line);
             UCP_TRACE_END(-1);
           }
          strcpy(item_node.init_id,chk_rtn1);
          strcpy(item_node.chk_id,chk_rtn2);
#ifdef NEWIO
          item_node.dat_attr=
                     (char) val_attr(itm_attr[0],bypass_flag,redisplay_flag);
#else
          item_node.dat_attr=itm_attr[0];
#endif
          item_node.page=pg_no;
          item_node.row=row_no;
          item_node.col=col_no;
          strcpy(item_node.ctf_name,ctf_field);
          /* check_hlp return the record number of the help file */
          if ( (item_node.help_id=check_hlp(help_id)) == -2 ) {
             fprintf(fp1,"ERROR: undefined online help no:%s ****\n",help_id);
             UCP_TRACE_END(-1);
           }
          if (itm_attr[0] == 'g') {
             item_node.ctf_relat == -1;
          }
          else {
             if(srh_item(curr_busi,ctf_field,&ctf_item) == -1)
               {
                fprintf(fp1,"ERROR:TXN-ID:%s  CTF-FIELDNAME:%s is undefined in ctf_file\n",curr_txnid,ctf_field);
                UCP_TRACE_END(-1);
               }
             else
               {
                item_node.ctf_relat = ctf_item.ctf_relat;
                item_node.input_len = ctf_item.dat_len;
                item_node.dot_post  = ctf_item.dot_pos;
                item_node.data_type = ctf_item.dat_type;
                item_node.ini_value = ctf_item.ini_value;
/*
                printf("imstxnpr:%.31s %c %d %d %d %c\n",
                      ctf_field,
                      item_node.data_type ,
                      item_node.input_len ,
                      item_node.ctf_relat ,
                      item_node.dot_post  ,
                      item_node.ini_value);
*/
               }
          }
/*
          printf("size=%d\n",sizeof(item_node));
         err_log(1000,"dumpitem",RPT_TO_LOG,&item_node,70);
*/
          if ( write(fp2,&item_node,sizeof(item_node))!=sizeof(item_node) ) {
             sprintf(MSG_STR,"ERROR:write iet file error errno=%d",errno);
             err_log(1000,MSG_STR,RPT_TO_LOG,0,0);
             UCP_TRACE_END(-1);
          }
          else {
             UCP_TRACE_END(0);
          }
       }  /* for if ( phase == 1 ) */
      }
  } /* for if ( j == 1 )  */
}

/***************************************************************************/
/* check any duplicated txn declaration, if any return -1 else return 0    */
/* f1 --> processed txn data file    f2 --> error message file             */
/***************************************************************************/
chk_dup(f1,f2)
char *f1,*f2;
{
  FILE *f_fp,*f_fp1;
/* modofied by alexwu on 19950413
  char buff[LINE_LEN];
*/
  char buff[LINE_LEN+1];
  char token1[LINE_LEN],token2[LINE_LEN];
  char temp = '%';
  char dup_flag='N';
/* added by alexwu on 19950413 BEGIN */
  char *p;
/* added by alexwu on 19950413 END */

  UCP_TRACE(P_chk_dup);
  if ( (f_fp=fopen(f1,"r")) == NULL ) {
    printf("ERROR:open txn data file open error ! errno=%d\n",errno);
    UCP_TRACE_END(-1);
  }
  if ( (f_fp1=fopen(f2,"w")) == NULL ) {
    printf("ERROR:txn data error file open error ! errno=%d\n",errno);
    UCP_TRACE_END(-1);
  }
  if ( fgets(buff,LINE_LEN,f_fp) == NULL ) {
      printf("ERROR:no data error errno=%d !\n",errno);
      UCP_TRACE_END(-2);
  }
  fprintf(f_fp1,"%s",buff);
/* modified by alexwu on 19950413
  strcpy(token1,strtok(buff," \t\"\n"));
*/
  if ((p=strtok(buff," \t\"\n")) != (char*) NULL)
        strcpy(token1,p);
  else
        token1[0] = '\0';

  if ( ((token1[0] == 'L') && (token1[1] ==1) && (token1[2] == 4)) ||
          (strlen(token1) == 0) ) {
      UCP_TRACE_END(-2); /* no more token */
  }
  while (1) {
     if ( fgets(buff,LINE_LEN,f_fp) == NULL ) {
         printf("eof encountered !\n");
         break;
     }
     fprintf(f_fp1,"%s",buff);
/* modified by alexwu on 19950413
     strcpy(token2,strtok(buff," \t\"\n"));
*/
     if ((p=strtok(buff," \t\"\n")) != (char*) NULL)
        strcpy(token2,p);
     else
        token2[0] = '\0';

     if ( ((token2[0] == 'L') && (token2[1] ==1) && (token2[2] == 4)) ||
             (strlen(token2) == 0) ) {
         break;
     }
     if ( strcmp(token1,token2) == 0 ) {
        dup_flag='Y';
        if (strcmp(token1+1,"0000000000") == 0) {
          fprintf(f_fp1,"ERROR:business delimit %c%c declaration duplicated !\n",temp,
                  token1[0]);
        }
        else {
           if (strcmp(token1+2,"000000000") == 0) {
             fprintf(f_fp1,"ERROR:business type -%c declaration duplicated !\n",
                     token1[0]);
           }
           else {
             if (strcmp(token1+5,"000000") == 0) {
               fprintf(f_fp1,"ERROR:txnid-%c%c%c%c: txn-id declaration duplicated !\n"
                       ,token1[1],token1[2],token1[3],token1[4]);
             }
             else {
               fprintf(f_fp1,"ERROR:txnid-%c%c%c%c: item position duplicated, ",
                       token1[1],token1[2],token1[3],token1[4]);
               fprintf(f_fp1,"page_no=%c%c rol_no=%c%c col_no=%c%c\n",token1[5],
                       token1[6],token1[7],token1[8],token1[9],token1[10]);
             }
           }
        }
        printf("ERROR:duplicated declaration token=%s !\n",token1);
     }
     strcpy(token1,token2);
  }
  fclose(f_fp);
  fclose(f_fp1);
  if (dup_flag=='Y') {
     UCP_TRACE_END(-1);
  }
  else {
     UCP_TRACE_END(0);
  }
}

/* Add to check duplicated CTF item in the same txn 19961001 -- begin */
/***************************************************/
/* check any duplicated ctf item in the same txn,  */
/* if any return -1 else return 0                  */
/* f1 --> processed txn data file                  */
/* f2 --> error message file                       */
/***************************************************/
chk_dup_ctf(f1,f2)
char *f1,*f2;
{
  FILE *f_fp,*f_fp1;
  char buff[LINE_LEN+1];
  char token1[LINE_LEN],token2[LINE_LEN];
  char temp = '%';
  char dup_flag='N';
  char *p;
  char ctf_field_buf[LINE_LEN];

  UCP_TRACE(P_chk_dup_ctf);
  if ( (f_fp=fopen(f1,"r")) == NULL ) {
    printf("ERROR:open txn data file open error ! errno=%d\n",errno);
    UCP_TRACE_END(-1);
  }
  if ( (f_fp1=fopen(f2,"w")) == NULL ) {
    printf("ERROR:txn data error file open error ! errno=%d\n",errno);
    UCP_TRACE_END(-1);
  }
  if ( fgets(buff,LINE_LEN,f_fp) == NULL ) {
      printf("ERROR:no data error errno=%d !\n",errno);
      UCP_TRACE_END(-2);
  }

  /* fprintf(f_fp1,"%s",buff); */
  if ((p=strtok(buff," \t\"\n")) != (char*) NULL)
        strcpy(token1,p);
  else
        token1[0] = '\0';

  if ( ((token1[0] == 'L') && (token1[1] ==1) && (token1[2] == 4)) ||
        (strlen(token1) == 0) ) {
      UCP_TRACE_END(-2); /* no more token */
  }

  while (1) {
     if ( fgets(buff,LINE_LEN,f_fp) == NULL ) {
         printf("eof encountered !\n");
         break;
     }

     /* fprintf(f_fp1,"%s",buff); */
     if ((p=strtok(buff," \t\"\n")) != (char*) NULL)
        strcpy(token2,p);
     else
        token2[0] = '\0';

     if ( ((token2[0] == 'L') && (token2[1] ==1) && (token2[2] == 4)) ||
           (strlen(token2) == 0) ) {
         break;
     }
     if ( strcmp(token1,token2) == 0 && token1[5] != 'g' ) {
       dup_flag='Y';
       strcpy(ctf_field_buf,token1+6);
       fprintf(f_fp1,
               "ERROR:ctf item (%s) duplicated in txn-id (%c%c%c%c)\n",
               ctf_field_buf,token1[1],token1[2],token1[3],token1[4]);
       printf("ERROR:duplicated declaration token=%s !\n",token1);
     }
     strcpy(token1,token2);
  }
  fclose(f_fp);
  fclose(f_fp1);
  if (dup_flag=='Y') {
     UCP_TRACE_END(-1);
  }
  else {
     UCP_TRACE_END(0);
  }
}
/* Add to check duplicated CTF item in the same txn 19961001 -- end */

err_hdl(phase,fp1,fp2,fp3,s)
int phase;
FILE *fp1,*fp2;
int fp3;
char *s;
{
  char buff1[80];
  int  tmp_id;

  fprintf(fp2,"    ERROR MESSAGE:%s\n",s);
  printf(" !!! ERROR OCCURED:%s\n",s);
  printf("     PLESAE CHECK iet.err for detail !\n");
  fclose(fp1);
  fclose(fp2);
  if (phase == 2) {  /* error handling for phase 2 parsing process only */
    printf("++++++ %s is renamed to %s\n",TXN_FILE_TMP,TXN_FILE);
#ifdef DOS
    sprintf(buff1,"copy %s  %s",TXN_FILE_TMP,TXN_FILE);
#else
    sprintf(buff1,"mv %s  %s",TXN_FILE_TMP,TXN_FILE);
#endif
    system(buff1);
    close(fp3);
    fclose(cross_chk);
    /*************************************************************/
    /*   release CTF & IET shared memory here !                  */
    /*************************************************************/
    tmp_id = shmget(CTF_SHM_KEY, 0, 0);
    if (tmp_id != -1)
       shmctl(tmp_id, IPC_RMID,0);
    tmp_id = shmget(IET_SHM_KEY, 0, 0);
    if (tmp_id != -1)
       shmctl(tmp_id, IPC_RMID,0);
  }
  UCP_TRACE_END(-1);
}

val_attr(itm_attr,by_pass,redisplay)
char itm_attr;
int  by_pass;
int  redisplay;
{
  char tmp;
  switch(itm_attr) {
    case 'o': /* optinal input field 00000011 */
              tmp=0x03;
              break;
    case 'r': /* required input field 00000111*/
              tmp=0x07;
              break;
    case 'g': /* guide line only field 00000001 */
              tmp=0x01;
              break;
    case 'a': /* guide line and item data, but input protected 00100011 */
              tmp=0x23;
              break;
    case 'd': /* no guide line but is an optional input field 00002010 */
              tmp=0x02;
              break;
    case 'e': /* no guide line but is a required input field 00000110 */
              tmp=0x06;
              break;
    case 'h': /* no guide line but display item data, and input protected */
              /* 00100010 */
              tmp=0x22;
              break;
    case 'p': /* an nonecho required input field 00010011*/
              tmp=0x13;
              break;
    case 'q': /* an nonecho optional input field 00010111 */
              tmp=0x17;
              break;
    case 'z': /* input data does not come from keyboard */
              tmp=0x83;
              break;
    default:  tmp=0;
              break;
  }
  if (by_pass == 0 && redisplay == 0) {
     return(tmp);
  }
  else {
       if ((by_pass !=1 && by_pass !=0) && (redisplay !=1 && redisplay!=0)) {
          return(0);
       }
       if (by_pass == 1) {
          tmp = tmp | 0x08;
       }
       if (redisplay == 1) {
          tmp = tmp | 0x40;
       }
   return(tmp);
 }
}

chk_itm_num(phase,fp1,fp2,fp3)
int phase;
FILE *fp1,*fp2;
int fp3;
{
  if (curr_item_cnt != item_cnt) {
     err_hdl(phase,fp1,fp2,fp3,"inconsist item number in a transaction !\n");
     sprintf(MSG_STR,"inconsist item number in a transaction !");
     err_log(40000,MSG_STR,RPT_TO_LOG,0,0);
  }
  else {
     return(0);
  }
}
