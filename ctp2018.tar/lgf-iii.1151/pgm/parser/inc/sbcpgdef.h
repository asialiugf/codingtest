
/* ----- sbbssbbs.c -----   */
#define P_main 		 10101
#define P_sbbs_online  	 10102
#define P_sbbs_batch     10103
#define P_sbbs_restart   10104
#define P_tty_check      10105
#define P_swa_check      10106
#define P_sbbs_init      10107
#define P_sbbs_exit      10108
#define P_sbbs_shut      10109
#define P_sbbs_backup    10110
#define P_sbbs_robacking 10111
#define P_sbbs_rsbkupf   10112
#define P_itfrmiet       10113
#define P_stop_tpu       10114
#define P_dbtfitbd       10115

/* ----- syskfun.c -----    */
#define P_shell_call     10201
#define P_system_call    10202
#define P_txn_date_check 10203
#define P_txn_date_input 10204
#define P_swa_save       10205
#define P_swa_load       10206
#define P_exce_hndl      10207
#define P_shm_creat      10208
#define P_sem_creat      10209
#define P_msg_creat      10210
#define P_sys_fault      10211
#define P_intv_init      10212
#define P_date_time      10213
#define P_one_sec        10214
#define P_get_raw        10215
#define P_get_wdata      10216
#define P_echo_dspl      10217
#define P_c_string       10218
#define P_d_string       10219
#define P_t_string       10220
#define P_date_conv      10221
#define P_date_vald      10222
#define P_pass_word      10223
#define P_pass_rest      10224
#define P_swa_init       10225
#define P_logf_creat     10226
#define P_load_tct       10227
#define P_get_token      10228
#define P_readln         10229
#define P_leagl_chk      10230
#define P_find_tct       10231
#define P_itoa           10232
#define P_reverse        10233
#define P_fcslogf_creat  10234
#define P_password_op    10235

/* ----- syswfun.c -----    */
#define P_wnd_creat      10301
#define P_wnd_dspl       10302
#define P_sysop_dspl     10303
#define P_Sub_Title      10304

/* ----- syssfun.c -----    */
#define P_null_func      10401
#define P_func_dsc       10402
#define P_sbbs_serv      10403
#define P_func_apl       10404
#define P_unix_cmmd      10405
#define P_cmmd_edit      10406
#define P_do_batch       10407
#define P_shut_down      10408
#define P_db_recovy      10409
#define P_db_backup      10410
#define P_shut_quck      10411
#define P_int_modf       10412
#define P_int_load       10413
#define P_bnb_date       10414
#define P_swa_inq        10415
#define P_tct_inq        10416
#define P_aci_inq        10417
#define P_txn_redo       10418
#define P_itfparsr       10419
#define P_itfietmn       10420
#define P_itfietld       10421
#define P_tsfiscim       10422
#define P_tty_code       10423

/* ----- itscfbld.c -----   */
#define P_ctf_buld       10501
#define P_tbl_crt        10502
#define P_busi_estl      10503
#define P_item_estl      10504
#define P_srh_item       10505

/* ----- itstxbld.c -----   */
#define P_txn_buld       10601
#define P_busi_etbl      10602
#define P_txn_etbl       10603
#define P_txn_add        10604
#define P_txn_copy       10605
#define P_itm_etb        10606
#define P_itm_add        10607
#define P_itm_copy       10608
#define P_itfpctxi       10609
#define P_ptr_gen        10610
#define P_txni_add       10611
#define P_err_fun        10612
#define P_shm_allc       10613
#define P_prt            10614

/* ----- itscrict.c -----   */
#define P_itfcrict       10701
#define P_itfpcerr       10702
#define P_itfictsz       10703
#define P_itfcitld       10704
#define P_itfgtict       10705
#define P_itfgdtld       10706
#define P_itfglgen       10707
#define P_msg_rtn        10708
#define P_itfmdtld       10709
       
/* ----- itscissz.c -----   */
#define P_itfcissz       10901
#define P_itfpccti       10902

/* ----- sbbsmstp.c -----   */
#define P_mst_load       11001
#define P_mst_creat      11002
#define P_get_msg        11003
#define P_mst_search     11004
#define P_main_mstp      11005

/* ----- sbbsswar.c -----   */
#define P_shm_attch      11101
#define P_sem_attch      11102
#define P_main_swar      11103

/* ----- sbbsswas.c -----   */
#define P_main_swas       11201

/* ----- sbbsmsgp.c -----   */
#define P_f_getc         11301
#define P_put_oct        11302
#define P_msg_creat1     11303
#define P_main_msgp      11304

/* ----- sbbsswai.c -----   */
#define P_main_swai      11401

/* ----- sysswai.c  -----   */
#define P_tct_read       11501
#define P_tct_writ       11502
#define P_tct_inq_1      11503
#define P_swa_inq_1      11504
#define P_swai_func      11505

/* ----- sbbsintf.c -----   */
#define P_main_intf      11601

/* ----- sysintf.c  -----   */
#define P_i_to_a         11701
#define P_B_swap         11702
#define P_B_sort         11703
#define P_cmp3_cnvs      11704
#define P_c_string_1     11705
#define P_date_valid     11706
#define P_date_conv_1    11707
#define P_date_check     11708
#define P_int_shifout    11709
#define P_g_field        11710
#define P_p_field        11711
#define P_db_read        11712
#define P_db_writ        11713
#define P_db_dele        11714
#define P_int_read       11715
#define P_int_writ       11716
#define P_int_acc        11717
#define P_int_dele       11718
#define P_int_modf_1     11719
#define P_int_copy       11720
#define P_K_swap         11721
#define P_K_sort         11722
#define P_int_sort       11723
#define P_int_load_1     11724
#define P_bnb_dset       11725
#define P_bnb_rep        11726
#define P_bnb_add        11727
#define P_int_func       11728

/* ----- syscaln.c  -----   */
#define P_caln_func      11801
#define P_leap_ckeck     11802
#define P_first_day      11803
#define P_index          11804
#define P_make_mtab      11805

/* ----- tpu_monitor.c --   */
#define P_main_monitor   11901
#define P_tpu_fork       11902
