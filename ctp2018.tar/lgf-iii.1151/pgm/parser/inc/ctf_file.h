

#define    GSK_LEN      200
/*
struct ctf_head_def {
   char rec_head;
   char busi_type;
   int ctf_len;
   int tot_item;
   char filler[33];
} ;
typedef struct ctf_head_def ctf_head;

struct ctf_item_def {
   char ctf_name[31];
   char dat_type;
   int  dat_len;
   int ctf_len;
   int ctf_offs;
   int ctf_relat;
   int dot_pos;
   char ini_value;
} ;
typedef struct ctf_item_def ctf_item;
*/

struct ctf_st {
   union {
        ctf_head hd_node;
        ctf_item it_node;
     } unode;
   int label_no;
   struct ctf_st *left;
   struct ctf_st *right;
 };
typedef struct ctf_st ctf_node;



struct grp_len_st {
   char name[31];
   ctf_node *gp;
   int  gp_flg;
   int  label_no;
} ;

#define GROUP         0
#define BUSITYPE      1
#define ABEND         999
#define TRUE          1
#define FALSE         0
#define FORWARD       'f'
#define BACKWARD      'b'
