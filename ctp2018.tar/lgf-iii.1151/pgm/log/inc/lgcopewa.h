#ifndef H_LGCOPEWA
#define H_LGCOPEWA

/* ------------------------------------ */
/* define per txn max log count         */
/* ------------------------------------ */
#define MAX_LOG_PER_TXN       10

/* ------------------------------------ */
/* define log max rec cnt               */
/* ------------------------------------ */
#define LG_MAX_REC_CNT        0

/* ------------------------------------ */
/* define log record ID                 */
/* ------------------------------------ */
#define  AP_WRT_LOG          '1'
#define  TPE_WRT_LOG         '2'

/* ------------------------------------ */
/* define rec cnt length                */
/* ------------------------------------ */
#define REC_CNT_SIZE          4

/* ------------------------------------ */
/* define data len limitation           */
/* ------------------------------------ */
#define LG_RVS_BUF_IDX       10
#define LG_KEY_LEN_SIZE      2
#define LG_KEY_VAL_SIZE      50

#define LG_RRN_SIZE          8
#define LG_REC_SIZE          1000
#define LG_SIF_LEN_SIZE      4
#define LG_TXN_SEQ_SIZE      5
#define LG_MAX_TXN_ID_SIZE   6
#define LG_MAX_BR_CODE_SIZE  10
#define LG_MAX_TM_CODE_SIZE  4
#define LG_AP_USER_SIZE      450
#define LG_SIF_SIZE          400

/* ------------------------------------ */
/* define operation kind                */
/* ------------------------------------ */
#define  LG_RANDOM_READ      '1'    /* read by key */
#define  LG_RANDOM_READ_U    '2'    /* read by key and lock */
#define  LG_READ_NEXT        '3'    /* read the next rec. of the current one */
#define  LG_READ_NEXT_U      '4'    /* read and lock the next rec. of the */
                                    /* current one */
#define  LG_REWRITE          '5'    /* rewrite the current one record */
#define  LG_APPEND           '7'    /* append a record in the last RRN */
#define  LG_READ_FIRST       '8'    /* read the first LOG record */
#define  LG_READ_FIRST_U     '9'    /* read and lock first Log record */
#define  LG_READ_LAST        'A'    /* read the last one record in the LOG */
#define  LG_READ_LAST_U      'B'    /* read and lock the last one record */
                                    /* in the LOG */
#define  LG_READ_PREV        'C'    /* read previous log */
#define  LG_READ_PREV_U      'D'    /* read previous log & lock */
#define  LG_DIRECT_UPDATE    'Y'    /* direct read and rewrite the current */
                                    /* one record */
#define  LG_OPEN             'O'
#define  LG_CLOSE            'Z'

#define  LG_READ_LOG         '1'    /* for TPERVSOP read LOG               */
#define  LG_START_REVERSE    '2'    /* for TPERVSOP start txn reverse flow */
/* ------------------------------------ */
/* define key type                      */
/* ------------------------------------ */
#define LG_BY_RRN            '1'
#define LG_BY_SEQNO          '2'

/* ------------------------------------ */
/* define log operation return code     */
/* ------------------------------------ */
#define LG_NORMAL             '0'
#define LG_NO_REC_FOUND       '1'
#define LG_REC_DUPLICATE      '2'
#define LG_WRONG_CALL_SEQ     '3'
#define LG_NO_MORE_REC        '4'
#define LG_INVALID_FUN        '5'
#define LG_IO_ERR             '6'
#define LG_SERVICE_ERR        '7'
#define LG_REC_LOCKED         '8'
#define LG_INVALID_KEY_TYPE   '9'
#define LG_GET_TCT_LAST_RRN_ERR   'A'
#define LG_PRE_RVS_LOG_ERR    'B'

/* ------------------------------------ */
/* define LOCK or not                   */
/* ------------------------------------ */
#define  FLAG_ON              '1'
#define  FLAG_OFF             '0'

/* ------------------------------------ */
/* define log low function code         */
/* ------------------------------------ */
#define  OPEN_LOG             'O'
#define  DIRECT_READ_LOG      '1'
#define  WRITE_UPDATE_LOG     '2'
#define  INSERT_LOG           '3'
#define  CLOSE_LOG            'C'
#define  CREATE_LOG           'R'


/* ----------------------- */
/* define Txn Return Code  */
/* ----------------------- */
#define  LG_AP_NORMAL         '0'
#define  LG_AP_REJECTED       '1'
#define  LG_AP_INQ            '2'
#define  LG_AP_REVERSED       '6'

/* ------------------------------------ */
/* define function api error code       */
/* for  MF COBOL                        */
/* ------------------------------------ */
#define  DUPLICATE_KEY        "22"
#define  NO_REC_FOUND         "23"

struct LogApiSt {
  char caOperKind[1];
  char caKeyType[1];
  char caKeyLen[LG_KEY_LEN_SIZE];
  char caKeyValue[LG_KEY_VAL_SIZE];
  char caReturnCd[1];
};
typedef struct LogApiSt LOGAPI;

struct LogFunCalSt {
   char  caFunCode[1];
   char  caLockMode[1];
   char  caRrn[LG_RRN_SIZE];
   char  caReturn[1];
};
typedef struct  LogFunCalSt  LOGFUNIF;

struct LogRrnHistSt {
  char caRrn[LG_RRN_SIZE];
} ;

#endif
