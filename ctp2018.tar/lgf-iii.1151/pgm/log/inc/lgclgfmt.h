/*** ********************************** ***/
/*** LOGF TOTAL LEN : 1000              ***/
/*** TPE            :   18              ***/
/*** CWA            :   27              ***/
/*** TMA            :   68              ***/
/*** FILLER         :   37              ***/
/*** AP USE         :  450              ***/
/*** SIF            :  400              ***/
/*** ********************************** ***/

#define   LG_M_ON_LINE           'O'
#define   LG_M_OFF_LINE          '1'
#define   LG_M_SUP_OFF           '0'
#define   LG_M_SUP_ON            '1'
#define   LG_M_NO_PB             '0'
#define   LG_M_WITH_PB           '0'
#define   LG_M_NOT_REENTRY       '0'
#define   LG_M_REENTRY           '1'
#define   LG_M_NOT_REVERSE       '0'
#define   LG_M_REVERSE           '1'
#define   LG_M_AP_NORMAL         '0'
#define   LG_M_AP_REJECTED       '1'
#define   LG_M_AP_INQ            '2'
#define   LG_M_AP_NORMAL_REVERSE '3'
#define   LG_M_AP_CHANGE_TM      '4'
#define   LG_M_AP_INQ_REVERSE    '5'
#define   LG_M_AP_REENTRY        '6'
#define   LG_M_NORMAL_TXN        '0'
#define   LG_M_APRQT_TXN         '1'

#ifndef H_LGCLGFMT
#define H_LGCLGFMT

#include "cwa.h"
#include "twa.h"
#include "lgcopewa.h"
struct LogFmtSt {
   char caReverse[2];
   char caCurrLogRrn[LG_RRN_SIZE];
   char caRecId[1];
   char caTaskNo[4];
   char caRecCnt[REC_CNT_SIZE];
   char caSifLen[LG_SIF_LEN_SIZE];
   char caSyncPointCd[1];
   char caNextAvBtefRrn[LG_RRN_SIZE];
   char caLastLogRecRrn[LG_RRN_SIZE];
   char caSystemTxnSeqNo[10];
   char caAccTxnSeqNo[LG_TXN_SEQ_SIZE];
   char caNonAccTxnSeqNo[LG_TXN_SEQ_SIZE];
   char caBatchTxnSeqNo[LG_TXN_SEQ_SIZE];
   char caTxnId[LG_MAX_TXN_ID_SIZE];
   char caBrCode[LG_MAX_BR_CODE_SIZE];
   char caTmCode[LG_MAX_TM_CODE_SIZE];
   char caTellerCd[4];
   char caTxnDate[8];
   char caNextDate[8];
   char caNextDayCnt[1];
   char caTxnTime[6];
   char caOriginBrStatus[1];
   char caTmType[1];
   char caSupKeyStatus[1];
   char caBookStatus[1];
   char caTxnStatus[1];
   char caApRqt[1];
   char caLineReentryStatus[1];
   char caTxnReturnCd[1];
   char caFiscSwitch[1];
   char caFiscApReturnCd[1];
   char caOverTime[1];
   char caFiller[27];
   char caApUserArea[LG_AP_USER_SIZE];
   char caSifArea[LG_SIF_SIZE];
};
typedef struct LogFmtSt LOGFMT;

struct LogCtlSt {
  char RtnCode;
};

struct LogTwaSt {
  struct SSA *pstSsa;
  struct TMA *pstTma;
  struct ApaSt *pstApa;
  struct TermArea *pstTerm;
};

#endif
