/*
 *&N& File : lgsfcall.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int           LOGFCALL
 *&N&    long          GetRrn
 *&N&    void          ErrClose
 */


/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include  "errlog.h"
#include  "lgcopewa.h"

/* -------------------- CONSTANT DEFINE  --------------------------- */
#define  P_LOGFCALL 		 52001
#define  P_GetRrn 		 52002
#define  LOG_FILE 	 "/iii/log/sbtxlogf"

/* -------------------- STATIC GLOBAL DECLARATION ------------------ */
static off_t g_offCurOffset;
static char  g_cLockFlag = FLAG_OFF;
static char sg_caLogFileName[80];
static long sg_lTotRrn;
static int  sg_iLogfDp=-1;
void ErrClose(); /* TCC: For compatiability with Tandem */

long GetRrn(int);
/*
 *&N& ROUTINE NAME: LOGFCALL()
 *&A& ARGUMENTS:
 *&A& ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D&
 */

int
LOGFCALL(pstCall,pcIO)
LOGFUNIF *pstCall;
char *pcIO;
{
  int iRc;
  char caRrn[LG_RRN_SIZE+1];
  long  lRrn,lLastRrn;
  static char s_cFirst='y';
  struct stat stStatus;
  off_t NewOffset;
  int iWriteSize = 0;
 
  UCP_TRACE(P_LOGFCALL);

  if( s_cFirst == 'y' ) { 
    memset(sg_caLogFileName, 0, 80);
    strcpy(sg_caLogFileName,(char*) getenv("III_DIR"));
    strcat(sg_caLogFileName, LOG_FILE);
    s_cFirst = 'n';
  }

  if (pstCall->caFunCode[0] == DIRECT_READ_LOG ||
      pstCall->caFunCode[0] == INSERT_LOG)  {
    memset(caRrn,'\0',LG_RRN_SIZE+1);
    memcpy(caRrn,pstCall->caRrn,LG_RRN_SIZE);
    lRrn = atol(caRrn);
  }

  switch(pstCall->caFunCode[0]) {
    case  OPEN_LOG   :
      if ((sg_iLogfDp = open(sg_caLogFileName,O_RDWR)) < 0) {
        pstCall->caReturn[0] = LG_SERVICE_ERR;
        sprintf(g_caMsg,"open(%s) Error =%d",sg_caLogFileName,errno);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END( -1 );
      }
      if (lseek(sg_iLogfDp,0,SEEK_SET) < 0) {
        pstCall->caReturn[0] = LG_SERVICE_ERR;
        sprintf(g_caMsg,"lseek : SET LOG FILE (%s) OFFSET Error =%d",
                         sg_caLogFileName,errno);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        ErrClose(sg_iLogfDp);
        UCP_TRACE_END( -1 );
      }
      if (fstat(sg_iLogfDp,&stStatus) < 0) {
        sprintf(g_caMsg,
                " Get Log File(%s) status Error =%d",sg_caLogFileName,errno);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        ErrClose(sg_iLogfDp);
        pstCall->caReturn[0] = LG_SERVICE_ERR;
        UCP_TRACE_END(-1);
      }
      /* check if the LOG file has redundant data
         (some record size is less than LG_REC_SIZE)
       */
      if ((stStatus.st_size % LG_REC_SIZE) != 0) {
      	  sprintf(g_caMsg,"WARNING! LOGFCALL(OPEN_LOG): %s has redundant data, file size=%d", sg_caLogFileName, stStatus.st_size);
    	  ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      }
      sg_lTotRrn = ((long) (stStatus.st_size / LG_REC_SIZE)) ;
      g_offCurOffset = 0;
      break;
    case  CLOSE_LOG  :
      g_offCurOffset = 0;
      if ((iRc = close(sg_iLogfDp)) < 0) {
        pstCall->caReturn[0] = LG_SERVICE_ERR;
        sprintf(g_caMsg,"Close : Log File(%s) Error =%d",sg_caLogFileName,errno);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END( -1 );
      }
      break;
    case  WRITE_UPDATE_LOG  :
      if (g_cLockFlag != FLAG_ON) {
        pstCall->caReturn[0] = LG_SERVICE_ERR;
        ErrLog(1000,"Before Write Log Must Lock Log",RPT_TO_LOG,0,0);
        ErrClose(sg_iLogfDp);
        UCP_TRACE_END( -1 );
      }
      if ((iRc=lseek(sg_iLogfDp,g_offCurOffset,SEEK_SET)) < 0) {
        pstCall->caReturn[0] = LG_SERVICE_ERR;
        sprintf(g_caMsg,"lseek : SET LOG FILE (%s) OFFSET Error =%d RRN=%d",
                sg_caLogFileName,errno,lRrn);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        ErrClose(sg_iLogfDp);
        UCP_TRACE_END( -1 );
      }
      if ( write(sg_iLogfDp,pcIO,LG_REC_SIZE) != LG_REC_SIZE) {
        pstCall->caReturn[0] = LG_IO_ERR;
        sprintf(g_caMsg,"Rewrite Log File(%s) Error =%d RRN=%d",
                sg_caLogFileName,errno,lRrn);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        ErrClose(sg_iLogfDp);
        UCP_TRACE_END( -1 );
      }
      if (lockf(sg_iLogfDp,F_ULOCK,LG_REC_SIZE) < 0) {
        pstCall->caReturn[0] = LG_SERVICE_ERR;
        sprintf(g_caMsg,"Unlock Log File(%s) Error =%d RRN=%d",
                sg_caLogFileName,errno,lRrn);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        ErrClose(sg_iLogfDp);
        UCP_TRACE_END( -1 );
      }
      g_cLockFlag == FLAG_OFF;
      break;
    case  DIRECT_READ_LOG  :
      g_offCurOffset = (off_t) ((lRrn - 1) * LG_REC_SIZE);
      if( lRrn <= 0 ) {
        pstCall->caReturn[0] = LG_WRONG_CALL_SEQ;
        sprintf(g_caMsg,"Direct Read : wrong RRN=%d",lRrn);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        ErrClose(sg_iLogfDp);
        UCP_TRACE_END( -1 );
      }

      if ( lRrn > sg_lTotRrn ) {
        pstCall->caReturn[0] = LG_NO_REC_FOUND;
        sprintf(g_caMsg,"Read Log File(%s) Error =%d RRN=%d",
                sg_caLogFileName,errno,lRrn);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
/* -----   AP will close LOG -------
        ErrClose(sg_iLogfDp);
*/
        UCP_TRACE_END( -1 );
      }

      if ((iRc=lseek(sg_iLogfDp,g_offCurOffset,SEEK_SET)) < 0) {
        pstCall->caReturn[0] = LG_SERVICE_ERR;
        sprintf(g_caMsg,"lseek : SET LOG FILE (%s) OFFSET Error =%d RRN=%d",
                sg_caLogFileName,errno,lRrn);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        ErrClose(sg_iLogfDp);
        UCP_TRACE_END( -1 );
      }

      if (pstCall->caLockMode[0] == FLAG_ON) {
        if (lockf(sg_iLogfDp,F_TLOCK,LG_REC_SIZE) < 0) {
          pstCall->caReturn[0] = LG_SERVICE_ERR;
          sprintf(g_caMsg,"lockf : LOCK LOG REC (%s) OFFSET Error =%d RRN=%d",
                sg_caLogFileName,errno,lRrn);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          ErrClose(sg_iLogfDp);
          UCP_TRACE_END( -1 );
        }
        g_cLockFlag = FLAG_ON;
      }

      if ((iRc = read(sg_iLogfDp,pcIO,LG_REC_SIZE)) != LG_REC_SIZE) {
	/* if any redundant data then also treat it as EOF */
        pstCall->caReturn[0] = LG_NO_REC_FOUND;
        /* if (iRc == 0) {
          pstCall->caReturn[0] = LG_NO_REC_FOUND;
        }
        else {
          pstCall->caReturn[0] = LG_IO_ERR;
        }*/
        sprintf(g_caMsg,"Read Log File(%s) Error =%d RRN=%d",
                sg_caLogFileName,errno,lRrn);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        ErrClose(sg_iLogfDp);
        UCP_TRACE_END( -1 );
      }
/*
      ErrLog(100,"LOGFCALL: direct read dump logdata=",
             RPT_TO_LOG,pcIO,LG_REC_SIZE);
*/
      break;
    case  INSERT_LOG :
      if ((lLastRrn = GetRrn(sg_iLogfDp)) < 0) {
        pstCall->caReturn[0] = LG_SERVICE_ERR;
        sprintf(g_caMsg,"Get Log File (%s) RRN Error = %d",
                sg_caLogFileName,lLastRrn);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        ErrClose(sg_iLogfDp);
        UCP_TRACE_END( -1 );
      }

      if ( (iRc = lRrn - lLastRrn) <= 0) {
        pstCall->caReturn[0] = LG_REC_DUPLICATE;
        sprintf(g_caMsg,"Insert Log File (%s) : duplicate RRN = %d",
                sg_caLogFileName,lRrn);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        ErrClose(sg_iLogfDp);
        UCP_TRACE_END( -1 );
      }

      if (iRc > 1) {
        pstCall->caReturn[0] = LG_SERVICE_ERR;
        sprintf(g_caMsg,"Insert Log File (%s) : RRN = %d Error",
                sg_caLogFileName,lRrn);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        ErrClose(sg_iLogfDp);
        UCP_TRACE_END( -1 );
      }

      NewOffset = (off_t) lLastRrn * LG_REC_SIZE;
      /*if ((g_offCurOffset =lseek(sg_iLogfDp,0,SEEK_END)) < 0) {*/
      if ((g_offCurOffset =lseek(sg_iLogfDp,NewOffset,SEEK_SET)) < 0) {
        pstCall->caReturn[0] = LG_SERVICE_ERR;
        sprintf(g_caMsg,"lseek : SET LOG FILE (%s) OFFSET Error =%d",
                sg_caLogFileName,errno);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        ErrClose(sg_iLogfDp);
        UCP_TRACE_END( -1 );
      }

      if (lockf(sg_iLogfDp,F_TLOCK,LG_REC_SIZE) < 0) {
        pstCall->caReturn[0] = LG_SERVICE_ERR;
        sprintf(g_caMsg,"Insert : Lock Record Error no = %d",errno);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        ErrClose(sg_iLogfDp);
        UCP_TRACE_END( -1 );
      }
      g_cLockFlag = FLAG_ON;

      if ((iWriteSize=write(sg_iLogfDp,pcIO,LG_REC_SIZE)) != LG_REC_SIZE) {
        pstCall->caReturn[0] = LG_IO_ERR;
        sprintf(g_caMsg,"ERROR: INSERT Log File(%s), wr_size=%d, errno=%d",
                sg_caLogFileName, iWriteSize, errno);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        ErrClose(sg_iLogfDp);
        UCP_TRACE_END( -1 );
      }

      if (lseek(sg_iLogfDp,g_offCurOffset,SEEK_SET) < 0) {
        pstCall->caReturn[0] = LG_SERVICE_ERR;
        sprintf(g_caMsg,"lseek : SET LOG FILE (%s) OFFSET Error =%d",
                sg_caLogFileName,errno);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        ErrClose(sg_iLogfDp);
        UCP_TRACE_END( -1 );
      }

      if (lockf(sg_iLogfDp,F_ULOCK,LG_REC_SIZE) < 0) {
        pstCall->caReturn[0] = LG_SERVICE_ERR;
        ErrClose(sg_iLogfDp);
        UCP_TRACE_END( -1 );
      }
      g_cLockFlag = FLAG_OFF;
      break;
    case  CREATE_LOG :
      if ((sg_iLogfDp = open(sg_caLogFileName,O_TRUNC|O_RDWR|O_CREAT ,0666)) < 0) {
        pstCall->caReturn[0] = LG_SERVICE_ERR;
        sprintf(g_caMsg,"creat : Log File(%s) Error =%d",
                sg_caLogFileName,errno);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END( -1 );
      }
      if (close(sg_iLogfDp) < 0) {
        pstCall->caReturn[0] = LG_SERVICE_ERR;
        sprintf(g_caMsg,"Creat Log : Close Log File(%s) Error =%d",
                sg_caLogFileName,errno);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END( -1 );
      }
      break;
    default :
      pstCall->caReturn[0] = LG_INVALID_FUN;
      sprintf(g_caMsg,"Function Code = %c Error",pstCall->caFunCode[0]);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END( -1 );
  }
  pstCall->caReturn[0] = LG_NORMAL;
  UCP_TRACE_END( 0 );
}


/*
 *&N& ROUTINE NAME: GetRrn()
 *&A& ARGUMENTS:
 *&A& ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D&
 */
long
GetRrn(iLogfDp)
int iLogfDp;
{
  struct stat stStatus;

  UCP_TRACE(P_GetRrn);
  if (fstat(iLogfDp,&stStatus) < 0) {
    sprintf(g_caMsg," Get Log File(%s) status Error =%d",sg_caLogFileName,errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    ErrClose(iLogfDp);
    UCP_TRACE_END(-1);
  }

  /* check if the LOG file has redundant data
     (some record size is less than LG_REC_SIZE)
   */
  if ((stStatus.st_size % LG_REC_SIZE) != 0) {
    	sprintf(g_caMsg,"WARNING! GetRrn(): %s has redundant data, file size=%d", sg_caLogFileName, stStatus.st_size);
    	ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
  }

  UCP_TRACE_END((long) (stStatus.st_size / LG_REC_SIZE)) ;
}


/*
 *&N& ROUTINE NAME: ErrClose()
 *&A& ARGUMENTS:
 *&A& ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D&
 */
void
ErrClose(iLogfDp)
int iLogfDp;
{
  g_offCurOffset = 0;
  g_cLockFlag = FLAG_OFF;
  close(iLogfDp);
  sg_iLogfDp=-1;
}
