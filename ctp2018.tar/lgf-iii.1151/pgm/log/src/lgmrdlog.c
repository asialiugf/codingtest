

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include "errlog.h"
#include "lgcopewa.h"
#include "lgclgfmt.h"

int g_iBrhCodeLen;
int g_iTmCodeLen;

main()
{
  
  void PrintLog(),RrnInput();
  char InqDisp();
  char caBrCode[LG_MAX_BR_CODE_SIZE + 1];
  char caTmCode[LG_MAX_TM_CODE_SIZE + 1];
  char caSeqNo[LG_TXN_SEQ_SIZE + 1];
  int iRecCnt;
  char cKeyType;
  long lRrn;
  LOGFUNIF stFun;
  LOGFMT   stLogFmt;
  
  
  if ( GetConfg() != 0 ){
    exit(1);
  }

  switch(cKeyType = InqDisp()) {
    case   LG_BY_SEQNO  :
      SeqInput(caBrCode,caTmCode,caSeqNo,&iRecCnt);
      lRrn = GetLastLog(caBrCode,caTmCode,caSeqNo);
      if (lRrn < 0) {
        printf("Get TCT Last Log Error\n");
        exit(-1);
      }
      break;
    case   LG_BY_RRN  :
      RrnInput(&lRrn,&iRecCnt); 
      break;
    default  :
      printf("INQ KEY TYPE = %c ERROR\n",cKeyType);
      exit(-1);
  }

  
  stFun.caFunCode[0] = OPEN_LOG;
  stFun.caReturn[0] = LG_NORMAL;
  LOGFCALL(&stFun,&stLogFmt);
  if (stFun.caReturn[0] != LG_NORMAL) {
    printf("Open Log Error = %c\n",stFun.caReturn[0]);
    exit(-1);
  }

  stFun.caFunCode[0] = DIRECT_READ_LOG;
  stFun.caLockMode[0] = FLAG_OFF;
  sprintf(stFun.caRrn,"%.*d",LG_RRN_SIZE,lRrn);
  stFun.caReturn[0] = LG_NORMAL;
  LOGFCALL(&stFun,&stLogFmt);
  printf("iRecCnt = %d\n",iRecCnt);
  while (stFun.caReturn[0] == LG_NORMAL && lRrn > 0 && iRecCnt > 0) {
    PrintLog(&stLogFmt);
    iRecCnt--;
    if (iRecCnt > 0) {
      stFun.caFunCode[0] = DIRECT_READ_LOG;
      stFun.caLockMode[0] = FLAG_OFF;
      if (cKeyType == LG_BY_SEQNO) {
        memcpy(stFun.caRrn,stLogFmt.caLastLogRecRrn,LG_RRN_SIZE);
      }
      else {
        sprintf(stFun.caRrn,"%.*d",LG_RRN_SIZE,++lRrn);
      }
      stFun.caReturn[0] = LG_NORMAL;
      LOGFCALL(&stFun,&stLogFmt);
      printf("read Return = %c\n",stFun.caReturn[0]);
    }
  }

  if (stFun.caFunCode[0] == LG_NORMAL) { 
    stFun.caFunCode[0] = CLOSE_LOG;
    stFun.caReturn[0] = LG_NORMAL;
    LOGFCALL(&stFun,&stLogFmt);
    if (stFun.caReturn[0] != LG_NORMAL) {
      printf("Close Log Error = %c\n",stFun.caReturn[0]);
      exit(-1);
    }
  }
}


char
InqDisp()
{
  char cKeyType;

  system("clear");
  printf("\n Inq Key Type (1. RRN 2.SEQNO) :");
  scanf("%c",&cKeyType);
  return(cKeyType);
}

void
RrnInput(plRrn,piRecCnt) 
long *plRrn;
int  *piRecCnt;
{

  printf("\n Inq RRN:");
  scanf("%d",plRrn);
  printf("\n RecCnt:");
  scanf("%d",piRecCnt);
}



int
SeqInput(pcBrCode,pcTmCode,pcSeqNo,piRecCnt)
char *pcBrCode,*pcTmCode,*pcSeqNo;
int *piRecCnt;
{

  int iBrCode;
  int iTmCode;
  int iSeqNo;
  int iRecCnt;
   

  printf("\n\nBrCode:");
  scanf("%d",&iBrCode);
  printf("TmCode:");
  scanf("%d",&iTmCode);
  printf("SeqNo:");
  scanf("%d",&iSeqNo);
  printf("InqCnt:");
  scanf("%d",&iRecCnt);
   
  sprintf(pcBrCode,"%.*d",g_iBrhCodeLen, iBrCode);
  sprintf(pcTmCode,"%.*d",g_iTmCodeLen, iTmCode);
  sprintf(pcSeqNo,"%.5d",iSeqNo);
  *piRecCnt = iRecCnt;

  return(0);
}


#define  LOG_FILE  "/iii/log/sbtxlogf"

int
GetLastLog(pcBrCode,pcTmCode,pcSeqNo)
char *pcBrCode,*pcTmCode,*pcSeqNo;
{
  char caLogF[80];
  char caRrn[LG_RRN_SIZE + 1];
  int iLogFd;
  long lRrn;
  struct stat stLgStatus;
  LOGFUNIF stFun;
  LOGFMT stLogFmt;

  strcpy(caLogF,(char *) getenv("III_DIR"));
  strcat(caLogF,LOG_FILE);

  iLogFd = open(caLogF,O_RDWR);
  if (iLogFd < 0) {
    printf("Open(%s) Error = %d\n",caLogF,errno);
    return(-3);
  }

  if (fstat(iLogFd,&stLgStatus) < 0) {
    printf("Call fstat() Error\n");
    close(iLogFd);
    return(-2);
  }

  lRrn =  stLgStatus.st_size/LG_REC_SIZE;

  close(iLogFd);

  stFun.caFunCode[0] = OPEN_LOG;
  stFun.caReturn[0] = LG_NORMAL;
  LOGFCALL(&stFun,&stLogFmt);
  if (stFun.caReturn[0] != LG_NORMAL) {
    printf("1111Open Log Error = %c\n",stFun.caReturn[0]);
    return(-1);
  }

  stFun.caFunCode[0] = DIRECT_READ_LOG;
  stFun.caLockMode[0] = FLAG_OFF;
  sprintf(stFun.caRrn,"%.*d",LG_RRN_SIZE,lRrn);
  stFun.caReturn[0] = LG_NORMAL;
  LOGFCALL(&stFun,&stLogFmt);
  while (stFun.caReturn[0] == LG_NORMAL && lRrn > 0) {
    if (memcmp(pcBrCode,stLogFmt.caBrCode,g_iBrhCodeLen) == 0 &&
        memcmp(pcTmCode,stLogFmt.caTmCode,g_iTmCodeLen) == 0 &&
        (memcmp(pcSeqNo,stLogFmt.caAccTxnSeqNo,LG_TXN_SEQ_SIZE) == 0 ||
         memcmp(pcSeqNo,stLogFmt.caNonAccTxnSeqNo,LG_TXN_SEQ_SIZE) == 0 ||
         memcmp(pcSeqNo,stLogFmt.caBatchTxnSeqNo,LG_TXN_SEQ_SIZE) == 0)) {
      memset(caRrn,'\0',LG_RRN_SIZE + 1);
      memcpy(caRrn,stLogFmt.caCurrLogRrn,LG_RRN_SIZE);
      break;
    }
    lRrn--;
    stFun.caFunCode[0] = DIRECT_READ_LOG;
    stFun.caLockMode[0] = FLAG_OFF;
    sprintf(stFun.caRrn,"%.*d",LG_RRN_SIZE,lRrn);
    stFun.caReturn[0] = LG_NORMAL;
    LOGFCALL(&stFun,&stLogFmt);
  }

  if (stFun.caReturn[0] != LG_NORMAL || lRrn <= 0) {
    printf("Rtn = %c lRrn = %d\n",stFun.caReturn[0],lRrn);
    stFun.caFunCode[0] = CLOSE_LOG;
    stFun.caReturn[0] = LG_NORMAL;
    if (stFun.caReturn[0] != LG_NORMAL) {
      printf("1111close Log Error = %c\n",stFun.caReturn[0]);
    }
    return(-1);
  }
  
  stFun.caFunCode[0] = CLOSE_LOG;
  stFun.caReturn[0] = LG_NORMAL;
  LOGFCALL(&stFun,&stLogFmt);
  if (stFun.caReturn[0] != LG_NORMAL) {
    printf("2222close Log Error = %c\n",stFun.caReturn[0]);
    return(-1);
  }
  return(lRrn);
}

void
PrintLog(pstLogFmt)
LOGFMT *pstLogFmt;
{
   char Buf[80];
   char cDump;
   sprintf(Buf,"caReverse->%.2s               caCurrLogRrn->%.*s",
                      pstLogFmt->caReverse,LG_RRN_SIZE,pstLogFmt->caCurrLogRrn);
   printf("%s \n",Buf);
   sprintf(Buf,"caRecId->%.1s                caTastNo->%.4s",
                                        pstLogFmt->caRecId,pstLogFmt->caTaskNo);
   printf("%s \n",Buf);
   sprintf(Buf,"caRecCnt->%.4s               caSifLen->%.4s",
                                       pstLogFmt->caRecCnt,pstLogFmt->caSifLen);
   printf("%s \n",Buf);
   sprintf(Buf,"caSuncPointCd->%.1s            caNextAvBtefRrn->%.*s",
            pstLogFmt->caSyncPointCd,LG_RRN_SIZE,pstLogFmt->caNextAvBtefRrn);
   printf("%s \n",Buf);
   sprintf(Buf,"caLastLogRecRrb->%.*s          caSystemTxnSeqNo=>%.10s",
           LG_RRN_SIZE,pstLogFmt->caLastLogRecRrn,pstLogFmt->caSystemTxnSeqNo);
   printf("%s \n",Buf);
   sprintf(Buf,"caAccTxnSeqNo->%.*s            caNonAccTxnSeqNo->%.*s",
                                   LG_TXN_SEQ_SIZE,pstLogFmt->caAccTxnSeqNo,
                                  LG_TXN_SEQ_SIZE,pstLogFmt->caNonAccTxnSeqNo);
   printf("%s \n",Buf);
   sprintf(Buf,"caBatchTxnSeqNo->%.*s           caTxnId->%.*s",
                                   LG_TXN_SEQ_SIZE,pstLogFmt->caBatchTxnSeqNo,
                                   LG_MAX_TXN_ID_SIZE,pstLogFmt->caTxnId);
   printf("%s \n",Buf);
   sprintf(Buf,"caBrCode->%.*s                   caTmCode->%.*s",
                                        g_iBrhCodeLen,pstLogFmt->caBrCode,
                                        g_iTmCodeLen,pstLogFmt->caTmCode);
   printf("%s \n",Buf);
   sprintf(Buf,"caTellerCd->%.4s                  caTxnDate->%.8s",
                                    pstLogFmt->caTellerCd,pstLogFmt->caTxnDate);
   printf("%s \n",Buf);
   sprintf(Buf,"caNextDate->%.8s                  caNextDayCnt->%.1s",
                                 pstLogFmt->caNextDate,pstLogFmt->caNextDayCnt);
   printf("%s \n",Buf);
   sprintf(Buf,"caTxnTime->%.6s                   caOriginBrStatus ->%.1s",
                              pstLogFmt->caTxnTime,pstLogFmt->caOriginBrStatus);
   printf("%s \n",Buf);
   sprintf(Buf,"caTmType->%.1s                     caSupKeyStatus->%.1s",
                                 pstLogFmt->caTmType,pstLogFmt->caSupKeyStatus);
   printf("%s \n",Buf);
   sprintf(Buf,"caBookStatus->%.1s                  caTxnStatus->%.1s",
                                pstLogFmt->caBookStatus,pstLogFmt->caTxnStatus);
   printf("%s \n",Buf);
   sprintf(Buf,"caApRqt->%.1s                       caLineReentryStatus->%.1s",
                             pstLogFmt->caApRqt,pstLogFmt->caLineReentryStatus);
   printf("%s \n",Buf);
   sprintf(Buf,"caTxnReturnCd->%.1s                   caFiscSwitch->%.1s",
                              pstLogFmt->caTxnReturnCd,pstLogFmt->caFiscSwitch);
   printf("%s \n",Buf);
   sprintf(Buf,"caFiscApReturnCd->%.1s                  caOverTime->%.1s",
                             pstLogFmt->caFiscApReturnCd,pstLogFmt->caOverTime);
   printf("%s \n\n\n",Buf);

   fflush(stdin);
   cDump = (char ) getchar();
}

/*
 *&N& ROUTINE NAME: GetConfg()
 *&A& ARGUMENTS:
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : Call InitCnfTbl() error.
 *&R&   -2      : Get branch code length error. 
 *&R&   -3      : Get terminal code length error.
 *&R&
 *&D& DESCRIPTION:
 *&D&   ����ƥΥH���o�t�ΰѼ��� config.dat ���Ҵy�z���t�ΰѼƭ�,�P�ɱN�ȳ]�w
 *&D&   ���۹����������ܼ�
 *&D&               �t�ΰѼ�                �����ܼ�
 *&D&       ----------------------------------------------
 *&D&        branch code length             g_iBrhCodeLen
 *&D&        terminal code length           g_iTmCodeLen
 *&D&   �U�C���Τ��@,�|�Ϧ���ư��楢��
 *&D&       1. �L�k�}�� config.dat ��
 *&D&       2. �Өt�ΰѼƤ��s�b
 *&D&       3. config.dat �ɤ����t�ΰѼƭӼƶW�X�̤j����
 *&d&          (�Ѧұ`�� MAX_PARA_NO ����)
 *&D&       4. �t�ΰѼƦW�٤����׶W�X�̤j����
 *&D&          (�Ѧұ`�� MAX_PARA_NAME_LEN ����)
 *&D&
 */

#define CONFIG_FILE  		"iii/etc/tbl/config.dat"
#define FILE_NAME_LEN 		80
#define P_GetConfg    		29901  

int
GetConfg()
{
  int iRc;
  char caFileName[ FILE_NAME_LEN + 1 ];

  UCP_TRACE( P_GetConfg );

  strcpy(caFileName, (char *)getenv( "III_DIR" ));
  strcat(caFileName, "/");
  strcat(caFileName, CONFIG_FILE);

  iRc = InitCnfTbl( caFileName );
  if ( iRc < 0 ) {
    sprintf(g_caMsg,"GetConfg: InitCnfTbl()=%d fails!",iRc);
    ErrLog(1000, g_caMsg, RPT_TO_LOG|RPT_TO_TTY, 0, 0);
    UCP_TRACE_END( -1 );
  }

  g_iBrhCodeLen = GetCnfValue( "BRH_NODE_LEN" );
  if ( (g_iBrhCodeLen < 0) || (g_iBrhCodeLen > 10) ){
    sprintf(g_caMsg,"GetConfg: Get g_iBrhCodeLen=%d error",g_iBrhCodeLen);
    ErrLog(1000, g_caMsg, RPT_TO_LOG|RPT_TO_TTY, 0, 0);
    UCP_TRACE_END( -2 );
  }

  g_iTmCodeLen = GetCnfValue( "TERM_NODE_LEN" );
  if ( (g_iTmCodeLen < 0) || (g_iTmCodeLen > 4)){
    sprintf(g_caMsg,"GetConfg: Get g_iTmCodeLen=%d error",g_iTmCodeLen);
    ErrLog(1000, g_caMsg, RPT_TO_LOG|RPT_TO_TTY, 0, 0);
    UCP_TRACE_END( -3 );
  }

  UCP_TRACE_END( 0 );
}

