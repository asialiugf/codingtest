
#include "errlog.h"
#include "ucp.h"
#include "lgcopewa.h"
#include "lgclgfmt.h"

#define   P_RvsLogRd     51010
#define   P_PreRvsLog    51011
#define   P_RvsRollback  51012
#define   P_GetRvsSif    51013
#define   P_HasMoreLog   51014
#define   P_GetPrevLog   51015
#define   P_ErrCloseLog  51016

extern int g_iBrhCodeLen;
extern int g_iTmCodeLen;
extern int g_iTxnCodeLen;


static LOGFMT g_staLogFmt[MAX_LOG_PER_TXN       ];
static int g_iIdx;
static int g_iLogCnt;
static char g_caPreTxnId[LG_MAX_TXN_ID_SIZE + 1];
void ErrCloseLog(); /* TCC: For compatiability with Tandem */

int
RvsLogRd(pcLogCtl,pcLogIOArea)
char *pcLogCtl;
char *pcLogIOArea;
{
  int iRc;
  int iIdx;
  long lRrn;
  char caRrn[LG_RRN_SIZE + 1 ];
  char caBrCode[LG_MAX_BR_CODE_SIZE+1];
  char caTmCode[LG_MAX_TM_CODE_SIZE+1];
  char caSeqNo[LG_TXN_SEQ_SIZE+1];
  LOGAPI stLogCtl,*pstLogCtl;
  LOGFMT stLogFmt;

  UCP_TRACE(P_RvsLogRd);

  pstLogCtl = (LOGAPI *) pcLogCtl;

  stLogCtl.caOperKind[0] = LG_OPEN;
  stLogCtl.caReturnCd[0] = LG_NORMAL;
  LOGOPERATION(&stLogCtl,&stLogFmt);
  if (stLogCtl.caReturnCd[0] != LG_NORMAL) {
    sprintf(g_caMsg,"Open Log Error = %c",stLogCtl.caReturnCd[0]);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstLogCtl->caReturnCd[0] = stLogCtl.caReturnCd[0];
    ErrCloseLog();
    UCP_TRACE_END(-1);
  }

  switch (pstLogCtl->caKeyType[0]) {
     case  LG_BY_RRN  :
       stLogCtl.caOperKind[0] = LG_RANDOM_READ;
       stLogCtl.caKeyType[0] = LG_BY_RRN;
       sprintf(stLogCtl.caKeyLen,"%.*d",LG_KEY_LEN_SIZE,LG_RRN_SIZE);
       memcpy(stLogCtl.caKeyValue,pstLogCtl->caKeyValue,LG_RRN_SIZE);
       stLogCtl.caReturnCd[0] = LG_NORMAL;
       LOGOPERATION(&stLogCtl,&stLogFmt);
       if (stLogCtl.caReturnCd[0] != LG_NORMAL) {
         sprintf(g_caMsg,"Read Log Error = %c",stLogCtl.caReturnCd[0]);
         ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
         pstLogCtl->caReturnCd[0] = stLogCtl.caReturnCd[0];
         ErrCloseLog();
         UCP_TRACE_END(-1);
       }
       memcpy(caBrCode,stLogFmt.caBrCode,g_iBrhCodeLen);
       memcpy(caTmCode,stLogFmt.caTmCode,g_iTmCodeLen);
/*--modified by wen for reverse NonAccount Txn by RRN on 970423 begin */
/*     memcpy(caSeqNo,stLogFmt.caAccTxnSeqNo,LG_TXN_SEQ_SIZE);   */
       memcpy(caSeqNo,&stLogFmt.caSystemTxnSeqNo[5],LG_TXN_SEQ_SIZE);   
/*--modified by wen for reverse NonAccount Txn by RRN on 970423 end */
       break;
     case LG_BY_SEQNO :
       memcpy(caBrCode,pstLogCtl->caKeyValue,g_iBrhCodeLen);
       memcpy(caTmCode,&(pstLogCtl->caKeyValue[g_iBrhCodeLen]),g_iTmCodeLen);
       memcpy(caSeqNo,&(pstLogCtl->caKeyValue[g_iBrhCodeLen+g_iTmCodeLen]),
                                                         LG_TXN_SEQ_SIZE);
       break;
     default         :
       sprintf(g_caMsg,"Key Type Error = %c",pstLogCtl->caKeyType[0]);
       ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
       pstLogCtl->caReturnCd[0] =  LG_INVALID_KEY_TYPE;
       ErrCloseLog();
       UCP_TRACE_END(-1);
   }
   iRc = GetTctLastRrn(caBrCode,caTmCode,&lRrn);
   if (iRc < 0) {
     sprintf(g_caMsg,"GetTctLastRrn() Error = %d",iRc);
     ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
     pstLogCtl->caReturnCd[0] = LG_GET_TCT_LAST_RRN_ERR;
     ErrCloseLog();
     UCP_TRACE_END(-1);
   }
   g_iIdx = 0;
   g_iLogCnt = 0;
   sprintf(caRrn,"%.*d",LG_RRN_SIZE,lRrn);
   sprintf(g_caMsg,"Log Call GetTctLastRrn() : %s",caRrn);
   ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
   iRc = PreRvsLog(caRrn,caBrCode,caTmCode,caSeqNo);
   if (iRc < 0) {
     sprintf(g_caMsg,"PreRvsLog() Error = %d",iRc);
     ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
     pstLogCtl->caReturnCd[0] =  LG_PRE_RVS_LOG_ERR;
     ErrCloseLog();
     UCP_TRACE_END(-1);
   }
   for (iIdx = 0;iIdx < g_iLogCnt       ;iIdx++) {
     if (memcmp(caRrn,g_staLogFmt[iIdx].caCurrLogRrn,LG_RRN_SIZE) == 0) {
       memcpy(pcLogIOArea,&g_staLogFmt[iIdx],LG_REC_SIZE);
       sprintf(g_caMsg,"PreRvsLog() Read Log=%.8s DUMP LOG=",
               g_staLogFmt[iIdx].caCurrLogRrn);
       ErrLog(100,g_caMsg,RPT_TO_LOG,&g_staLogFmt[iIdx],LG_REC_SIZE);
       break;
     }
   }
   pstLogCtl->caReturnCd[0] = LG_NORMAL; 
   memset(g_caPreTxnId,'\0',LG_MAX_TXN_ID_SIZE + 1);
   UCP_TRACE_END(0);
} /* RvsLogRd() */

int
PreRvsLog(pcRrn,pcBrCode,pcTmCode,pcSeqNo)
char *pcRrn;
char *pcBrCode;
char *pcTmCode;
char *pcSeqNo;
{
  LOGAPI stLogCtl;
  LOGFMT stLogFmt;

  int iIdx;
  int iFirstLog;
  int iLastLog;
  int iPreLog;
  int iTxnReturnCd;
  int iaIdx[MAX_LOG_PER_TXN       ];

  struct RrnBuf_st {
    char caRrn[LG_RRN_SIZE];
    char caRecCnt[REC_CNT_SIZE];
  } staRrn[MAX_LOG_PER_TXN       ];

  char caRecCnt[REC_CNT_SIZE+1];
  char caTxnReturnCd[2];
  char cFindFlag;

  UCP_TRACE(P_PreRvsLog);

/* ---------------------------------------------------- */
/* read all of logs which be belong to the reversed txn */
/* from last log to first log                           */
/* ---------------------------------------------------- */
  for (iIdx=0 ;iIdx < MAX_LOG_PER_TXN       ; iIdx++) {
    memset(&staRrn[iIdx],'\0',sizeof(struct RrnBuf_st));
  }

  iIdx = 0;
  cFindFlag = 'n';
  sprintf(caRecCnt,"%.*d",REC_CNT_SIZE,1);
  stLogCtl.caOperKind[0] = LG_RANDOM_READ;
  stLogCtl.caKeyType[0] = LG_BY_RRN;
  sprintf(stLogCtl.caKeyLen,"%.*d",LG_KEY_LEN_SIZE,LG_RRN_SIZE);
  memcpy(stLogCtl.caKeyValue,pcRrn, LG_RRN_SIZE );
  stLogCtl.caReturnCd[0] = LG_NORMAL;
  LOGOPERATION(&stLogCtl,&stLogFmt);
  if (stLogCtl.caReturnCd[0] == LG_NORMAL) {
    switch(*pcSeqNo) {
      case  '0'  : /* Account Txn Seq No */
        if (memcmp(pcSeqNo,stLogFmt.caAccTxnSeqNo,LG_TXN_SEQ_SIZE) > 0 ) {
          sprintf(g_caMsg," AccTxnSeqNo=%.*s is overflow! ",
                                                      LG_TXN_SEQ_SIZE,pcSeqNo);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          ErrCloseLog();
          UCP_TRACE_END(-1);
        }
        break;
      case  '1'  : /* NonAccount Txn Seq No */
        if (memcmp(pcSeqNo,stLogFmt.caNonAccTxnSeqNo,LG_TXN_SEQ_SIZE) > 0 ) {
          ErrCloseLog();
          sprintf(g_caMsg,"NonAccTxnSeqNo=%.*s is overflow! ",
                                                      LG_TXN_SEQ_SIZE,pcSeqNo);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          UCP_TRACE_END(-1);
        }
        break;
/* ------add for BRANCH to do TPERVSOP ---------begin---1995/04/03---*/
      case  '2'  : /* Account Txn Seq No */
        if (memcmp(pcSeqNo,stLogFmt.caAccTxnSeqNo,LG_TXN_SEQ_SIZE) > 0 ) {
          sprintf(g_caMsg," AccTxnSeqNo=%.*s is overflow! ",
                                                      LG_TXN_SEQ_SIZE,pcSeqNo);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          ErrCloseLog();
          UCP_TRACE_END(-1);
        }
        break;
      case  '3'  : /* NonAccount Txn Seq No */
        if (memcmp(pcSeqNo,stLogFmt.caNonAccTxnSeqNo,LG_TXN_SEQ_SIZE) > 0 ) {
          ErrCloseLog();
          sprintf(g_caMsg,"NonAccTxnSeqNo=%.*s is overflow! ",
                                                      LG_TXN_SEQ_SIZE,pcSeqNo);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          UCP_TRACE_END(-1);
        }
        break;
/* ------add for BRANCH to do TPERVSOP ---------begin---1995/04/03---*/
      case  '4'  : /* Batch Txn Seq No */
        if (memcmp(pcSeqNo,stLogFmt.caBatchTxnSeqNo,LG_TXN_SEQ_SIZE) > 0 ) {
          ErrCloseLog();
          sprintf(g_caMsg,"caBatchTxnSeqNo=%.*s is overflow! ",
                                                      LG_TXN_SEQ_SIZE,pcSeqNo);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          UCP_TRACE_END(-1);
        }
        break;
      default :
        ErrCloseLog();
        sprintf(g_caMsg,"Txn Seq No Type = %c Error",*pcSeqNo);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END(-1);
    }
  }
  while (stLogCtl.caReturnCd[0] == LG_NORMAL) {
    iIdx = (iIdx < MAX_LOG_PER_TXN       ) ? iIdx : 0;
    memcpy(staRrn[iIdx].caRrn,stLogFmt.caCurrLogRrn,LG_RRN_SIZE);
    memcpy(staRrn[iIdx].caRecCnt,stLogFmt.caRecCnt,REC_CNT_SIZE);

/* ---------------------------------------------- */
/* Searching match input data log                 */
/* ---------------------------------------------- */
    if (memcmp(pcBrCode,stLogFmt.caBrCode,g_iBrhCodeLen) == 0 &&
        memcmp(pcTmCode,stLogFmt.caTmCode,g_iTmCodeLen)  == 0 &&
        (memcmp(pcSeqNo,stLogFmt.caAccTxnSeqNo,LG_TXN_SEQ_SIZE) == 0 ||
         memcmp(pcSeqNo,stLogFmt.caNonAccTxnSeqNo,LG_TXN_SEQ_SIZE) == 0 ||
         memcmp(pcSeqNo,stLogFmt.caBatchTxnSeqNo,LG_TXN_SEQ_SIZE) == 0)) {
      memcpy(pcRrn,stLogFmt.caCurrLogRrn,LG_RRN_SIZE);
      cFindFlag = 'y';
    }

/* -------------------------------------- */
/* Searching the first log in reverse txn */
/* -------------------------------------- */
    if (cFindFlag == 'y') {
      if (memcmp(stLogFmt.caRecCnt,caRecCnt,REC_CNT_SIZE) == 0) {
        iFirstLog = iIdx;
        break;
      }
    }
    iIdx++;
    memcpy(stLogCtl.caKeyValue,stLogFmt.caLastLogRecRrn,LG_RRN_SIZE);
    LOGOPERATION(&stLogCtl,&stLogFmt);
  } /* while (stLogApi.caReturnCd[0] == LG_NORMAL)  */

  if (stLogCtl.caReturnCd[0] != LG_NORMAL) {
    sprintf(g_caMsg,"Read Log Data Error = %c",stLogCtl.caReturnCd[0]);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  } /* if (stLogApi.caReturnCd[0] != LG_NORMAL) */

  sprintf(g_caMsg,"iFirstLog = %d",iFirstLog);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
/* -------------------------------------------- */
/* setting log sequence idx  from first to last */
/* -------------------------------------------- */
  for (iIdx = 0; iIdx < MAX_LOG_PER_TXN       ;iIdx++) {
    iaIdx[iIdx] = -1;
  }

  iLastLog = iFirstLog;
  for (iIdx = 0; iIdx < MAX_LOG_PER_TXN       ;iIdx++) {
    iaIdx[iIdx] = iLastLog;
    sprintf(g_caMsg,"iaIdx[%d]=%d",iIdx,iaIdx[iIdx]);
    ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
    iPreLog = ((iLastLog - 1) < 0 )? (MAX_LOG_PER_TXN - 1) : (iLastLog - 1);
    if ( ( memcmp(staRrn[iPreLog].caRecCnt,caRecCnt,REC_CNT_SIZE) == 0) ||
       (staRrn[iPreLog].caRecCnt[0] == '\0') ) {
      sprintf(g_caMsg," find first iPreLog = %d",iPreLog);
      ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
      break;
    }
    iLastLog--;
    iLastLog = (iLastLog < 0 ? MAX_LOG_PER_TXN       - 1 : iLastLog);
  }

  g_iLogCnt = iIdx + 1;
  sprintf(g_caMsg,"g_iLogCnt = %d",g_iLogCnt);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

/* Lock all log                                 */
  for (iIdx = g_iLogCnt - 1;iIdx > -1; iIdx--)  {
    stLogCtl.caOperKind[0] = LG_RANDOM_READ_U;
    stLogCtl.caKeyType[0] = LG_BY_RRN;
    sprintf(stLogCtl.caKeyLen,"%.*d",LG_KEY_LEN_SIZE,LG_RRN_SIZE);
    memcpy(stLogCtl.caKeyValue,staRrn[iaIdx[iIdx]].caRrn,LG_RRN_SIZE);
    sprintf(g_caMsg,"staRrn[%d].caRrn=%.*s",iaIdx[iIdx],LG_RRN_SIZE,
                                           staRrn[iaIdx[iIdx]].caRrn);
    ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
    stLogCtl.caReturnCd[0] = LG_NORMAL;
    LOGOPERATION(&stLogCtl,&stLogFmt);
    if (stLogCtl.caReturnCd[0] != LG_NORMAL ) {
      sprintf(g_caMsg,"Read Lock LOG Error = %c",stLogCtl.caReturnCd[0]);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(-1);
    }
    memcpy(&g_staLogFmt[g_iLogCnt - (iIdx + 1)],&stLogFmt,LG_REC_SIZE);
  }

/* Mark all log */
  for (iIdx = 0;iIdx < g_iLogCnt;iIdx++) {
    memcpy(&stLogFmt,&g_staLogFmt[iIdx],LG_REC_SIZE);
    stLogCtl.caOperKind[0] = LG_DIRECT_UPDATE;
    stLogCtl.caKeyType[0] = LG_BY_RRN;
    sprintf(stLogCtl.caKeyLen,"%.*d",LG_KEY_LEN_SIZE,LG_RRN_SIZE);
    memcpy(stLogCtl.caKeyValue,stLogFmt.caCurrLogRrn,LG_RRN_SIZE);
    caTxnReturnCd[0] = stLogFmt.caTxnReturnCd[0];
    caTxnReturnCd[1] = '\0';

    sprintf(g_caMsg,"### Mark LOG: r_code in LOG= %s",caTxnReturnCd);
    ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

    iTxnReturnCd = atoi(caTxnReturnCd) + 3;
    /* added By WuChihLiang 19950914 for avoid caTxnReturnCd == '6' or '8' */ 
    if (iTxnReturnCd == 6 || iTxnReturnCd == 8 ){
      continue;
    }

    sprintf(caTxnReturnCd,"%.1d",iTxnReturnCd);
    stLogFmt.caTxnReturnCd[0] = caTxnReturnCd[0];
    stLogCtl.caReturnCd[0] = LG_NORMAL;
    LOGOPERATION(&stLogCtl,&stLogFmt);
    if (stLogCtl.caReturnCd[0] != LG_NORMAL ) {
      sprintf(g_caMsg,"Mark LOG Error = %c",stLogCtl.caReturnCd[0]);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(-1);
    }
  }
  stLogCtl.caOperKind[0] = LG_CLOSE;
  stLogCtl.caReturnCd[0] = LG_NORMAL;
  LOGOPERATION(&stLogCtl,&stLogFmt);
  if (stLogCtl.caReturnCd[0] != LG_NORMAL) {
    sprintf(g_caMsg,"Open Log Error = %c",stLogCtl.caReturnCd[0]);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  }
  UCP_TRACE_END(0);
} /* PreRvsLog() */


/* ---------------------------------- */
/* return : 0 -> no more              */
/*          1 -> more                 */
/*         -1 -> error                */
/* ---------------------------------- */


int
GetRvsSif(pcRev,pcSif)
char *pcRev;
char *pcSif;
{

  void ErrCloseLog();
  int iRc;
  int iIdx;
  int iMoreFlag;
  int iCatIdx;
  LOGAPI stLogCtl;
  
  UCP_TRACE(P_GetRvsSif)

  if (g_iIdx >= g_iLogCnt || g_staLogFmt[g_iIdx].caTxnId[0] == '\0') {
    ErrCloseLog();
    UCP_TRACE_END(-1);
  }

  iIdx = g_iIdx;
  if (memcmp(g_caPreTxnId,g_staLogFmt[iIdx].caTxnId,g_iTxnCodeLen) != 0) {
    iCatIdx = iIdx;
    iIdx++;
    iMoreFlag = HasMoreLog(iIdx);
  }
  else {
    iIdx++;
    while (iIdx < g_iLogCnt && g_staLogFmt[iIdx].caTxnId[0] != '\0' && 
          memcmp(g_staLogFmt[iIdx].caTxnId,g_staLogFmt[iIdx-1].caTxnId,
                                                            g_iTxnCodeLen)==0) {
      iIdx++;
    }
    if (iIdx >= g_iLogCnt || g_staLogFmt[iIdx].caTxnId[0] == '\0' ) {
      ErrCloseLog();
      UCP_TRACE_END(-1);
    } 
    else {
      iCatIdx = iIdx;
      iIdx++;
      iMoreFlag = HasMoreLog(iIdx);
    }
  }

  memcpy(pcRev,g_staLogFmt[iCatIdx].caApUserArea,LG_AP_USER_SIZE);
  memcpy(pcSif,g_staLogFmt[iCatIdx].caSifArea,LG_SIF_SIZE);
  memcpy(g_caPreTxnId,g_staLogFmt[iCatIdx].caTxnId,g_iTxnCodeLen);
  g_iIdx = iIdx;
  UCP_TRACE_END(iMoreFlag);
}


int
HasMoreLog(iIdx) 
int iIdx;
{
  UCP_TRACE(P_HasMoreLog);
  while(iIdx < g_iLogCnt  && memcmp(g_staLogFmt[iIdx].caTxnId,
                             g_staLogFmt[iIdx-1].caTxnId,g_iTxnCodeLen) == 0) {
      iIdx++;
  }
  if (iIdx < g_iLogCnt) {
    UCP_TRACE_END(1);
  }

  UCP_TRACE_END(0);
} /* HasMoreLog() */


int
GetPrevLog(pcRev)
char *pcRev;
{
  int iIdx;

  UCP_TRACE(P_GetPrevLog);

  iIdx = g_iIdx;
  sprintf(g_caMsg,"GetPrevLog: g_iIdx=%d, iIdx=%d",g_iIdx,iIdx);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  sprintf(g_caMsg,"GetPrevLog:g_staLogFmt[%d].caTxnId=%.*s"
          ,iIdx-1,g_iTxnCodeLen, g_staLogFmt[iIdx-1].caTxnId);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
  
  sprintf(g_caMsg,"GetPrevLog:g_staLogFmt[%d].caTxnId=%.*s",iIdx,g_iTxnCodeLen,
         g_staLogFmt[iIdx].caTxnId);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  if (iIdx < g_iLogCnt  && memcmp(g_staLogFmt[iIdx].caTxnId,
                             g_staLogFmt[iIdx-1].caTxnId,g_iTxnCodeLen) == 0) {
    memcpy(pcRev,g_staLogFmt[g_iIdx].caApUserArea,LG_AP_USER_SIZE);
    memcpy(g_caPreTxnId,g_staLogFmt[g_iIdx].caTxnId,g_iTxnCodeLen);
  }
  else {
/*
    ErrCloseLog();
*/
    UCP_TRACE_END(-1);
  }
  iIdx++;
  g_iIdx = iIdx;
  UCP_TRACE_END(0);
} /* GetPrevLog(pcRev) */

int
RvsRollback()
{
  int  iIdx;
  LOGFMT *pstLogFmt;
  LOGAPI stLogCtl;
  LOGFMT stLogFmt;

  UCP_TRACE(P_RvsRollback);

  sprintf(g_caMsg,"RvsRollback: begin,g_iLogCnt=%d",g_iLogCnt);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
  stLogCtl.caOperKind[0] = LG_OPEN;
  stLogCtl.caReturnCd[0] = LG_NORMAL;
  LOGOPERATION(&stLogCtl,&stLogFmt);
  if (stLogCtl.caReturnCd[0] != LG_NORMAL) {
    sprintf(g_caMsg,"Open Log Error = %c",stLogCtl.caReturnCd[0]);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  }
  iIdx = 0;
/*
  while (iIdx<MAX_LOG_PER_TXN && memcmp(g_stLogFmt[iIdx].caTxnId[0] != '\0'))){
*/
  while( iIdx < g_iLogCnt && g_staLogFmt[iIdx].caTxnId[0] != '\0'){
    sprintf(g_caMsg,"RvsRollback:iIdx=%d,%.*d",iIdx,
            LG_KEY_LEN_SIZE,LG_RRN_SIZE);
    ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
    stLogCtl.caOperKind[0] = LG_DIRECT_UPDATE;
    stLogCtl.caKeyType[0] = LG_BY_RRN;
    sprintf(stLogCtl.caKeyLen,"%.*d",LG_KEY_LEN_SIZE,LG_RRN_SIZE);
    memset(stLogCtl.caKeyValue,'\0',LG_KEY_VAL_SIZE);
    memcpy(stLogCtl.caKeyValue,g_staLogFmt[iIdx].caCurrLogRrn,LG_RRN_SIZE);
    stLogCtl.caReturnCd[0] = LG_NORMAL;
    LOGOPERATION(&stLogCtl,&g_staLogFmt[iIdx]);
    if (stLogCtl.caReturnCd[0] != LG_NORMAL) {
      sprintf(g_caMsg,"DIRECT UPDATE LOG ERROR =%c",stLogCtl.caReturnCd[0]);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(-1);
    }
    iIdx++;

  }

  stLogCtl.caOperKind[0] = LG_CLOSE;
  stLogCtl.caReturnCd[0] = LG_NORMAL;
  LOGOPERATION(&stLogCtl,&stLogFmt);
  if (stLogCtl.caReturnCd[0] != LG_NORMAL) {
    sprintf(g_caMsg,"CLOSE Log Error = %c",stLogCtl.caReturnCd[0]);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  }

  UCP_TRACE_END(0);

} /* RvsRollback() */

void
ErrCloseLog()
{
  LOGAPI stLogCtl;
  LOGFMT stLogFmt;

  UCP_TRACE(P_ErrCloseLog);
   
  stLogCtl.caOperKind[0] = LG_CLOSE;
  stLogCtl.caReturnCd[0] = LG_NORMAL;
  LOGOPERATION(&stLogCtl,&stLogFmt);
  if (stLogCtl.caReturnCd[0] != LG_NORMAL) {
    sprintf(g_caMsg,"CLOSE Log Error = %c",stLogCtl.caReturnCd[0]);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
  }


  UCP_TRACE_OVER;
}
