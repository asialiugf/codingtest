/*
 *&N& File : lgsbgned.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int          LogBegin()
 *&N&    int          LogEnd()
 *&N&    int          LogRollbk()
 */

/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include  "errlog.h"
#include  "twa.h"
#include  "tms.h"
#include  "lgcopewa.h"

/* -------------------- CONSTANT DEFINE  --------------------------- */
#define  P_LogBegin    50500
#define  P_LogEnd      50501
#define  P_LogRollbk   50502

#define  COMMIT_FLAG       '0'
#define  ROLLBACK_FLAG     '1'

/* -------------------- STATIC GLOBAL DECLARATION ------------------ */
int g_iTotLogCntPerTxn;

/* -------------------- EXTERN GLOBAL DECLARATION ------------------ */
extern struct LogRrnHistSt g_staLogRrnHist[ MAX_LOG_PER_TXN ];
extern struct APA  *g_pstApa;
extern struct TBA  *g_pstTba;
extern struct TMA  *g_pstTma;

/*
 *&N& ROUTINE NAME: LogBegin()
 *&A& ARGUMENTS:
 *&A& ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D&
 */
int
LogBegin()
{
  UCP_TRACE(P_LogBegin);
/*
  ErrLog(100,"Enter LogBegin()......",RPT_TO_LOG,0,0);
*/
  g_iTotLogCntPerTxn = 1;
  UCP_TRACE_END( 0 );
}


/*
 *&N& ROUTINE NAME: LogEnd()
 *&A& ARGUMENTS:
 *&A& ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D&
 */
LogEnd(char cType)
{
  int iRc;
  char caRtnRrn[LG_RRN_SIZE];

  UCP_TRACE(P_LogEnd);

/*
  ErrLog(100,"Enter LogEnd()......",RPT_TO_LOG,0,0);
*/
  switch( cType ) {
    case COMMIT_FLAG:
      g_iTotLogCntPerTxn = 1;
      break;
    case ROLLBACK_FLAG:
      ErrLog(1000,"Enter LogEnd() begin to rollback",RPT_TO_LOG,0,0);
      iRc = LogRollbk();
      if ( iRc < 0 ) {
        sprintf(g_caMsg,"LogEnd: LogRollbk() error rtn code=%d",iRc);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END( -1 );
      }
      break;
    default:
      sprintf(g_caMsg,"LogEnd: invalid cType=%c",cType);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END( -1 );
  }

  UCP_TRACE_END( 0 );
}


/*
 *&N& ROUTINE NAME: LogRollbk()
 *&A& ARGUMENTS:
 *&A& ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&
 *&D& DESCRIPTION:
 *&D& �N�Ҽg�J���Ҧ�LOG���R��, �pLOG�쥻���`, �hMARK���L��; 
 *&D& �pLOG�쥻�L��, �h��MARK������; 
 */
LogRollbk()
{
  int i;
  int iRc;

  UCP_TRACE(P_LogRollbk);
  
  if( g_pstTma->stTCFA.cRvsApRdLogFlag == TMS_RVSAP_HAS_BEEN_RD_LOG ) {
     iRc = RvsRollback();
     if ( iRc < 0 ) {
       sprintf(g_caMsg,"LogRollbk: RvsRollback() error rtn code=%d",iRc);
       ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
       UCP_TRACE_END( -1 );
     }
     g_pstTma->stTCFA.cRvsApRdLogFlag == TMS_RVSAP_HAS_NOT_BEEN_RD_LOG;
  }

  /* �p�G�R��AP�o�Ϳ��~,�h�����N�wMARK���L�Ī�LOG��MARK������,          */
  /*    �B�N�R��AP�γQ�R��AP ,�w�g�J��LOG ,MARK���L��                   */

  if ( g_iTotLogCntPerTxn > 1 ) {
     iRc = LogMarkOff(g_iTotLogCntPerTxn-1,g_staLogRrnHist);
     if ( iRc < 0 ) {
       sprintf(g_caMsg,"LogRollbk: LogMarkOff() error rtn code=%d",iRc);
       ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
       UCP_TRACE_END( -1 );
     }
  }
  else {
    /* Because txn does not record LOGs, we don't need to rollback any LOGs */
  }

  UCP_TRACE_END( 0 );
}
