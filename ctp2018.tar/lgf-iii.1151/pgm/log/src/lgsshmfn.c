
/*
 *&N& File : lgsshmfn.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&   int           ReadLockCwa
 *&N&   int           UnLockCwa
 *&N&   int           GetTctLastRrn
 *&N&   int           GetNextAvRrn
 *&N&
 */

/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include "errlog.h"
#include "cwa.h"
#include "twa.h"
#include "lgclgfmt.h"

/* -------------------- CONSTANT DEFINE  --------------------------- */
#define  P_ReadLockCwa      53001
#define  P_UnLockCwa        53002  
#define  P_GetTctLastRrn    53003
#define  P_GetNextAvRrn     53004

#define  ACCESS_CWA_ERR    -1
#define  DETCH_CWA_ERR     -2
#define  ACCESS_TWA_ERR    -3

/* -------------------- STATIC GLOBAL DECLARATION ------------------ */
extern int g_iTmCodeLen;        /* Term code real length         */
extern int g_iBrhCodeLen;       /* Branch code real length       */
extern struct TMA *g_pstTma;

/*
 *&N& ROUTINE NAME: ReadLockCwa()
 *&A& ARGUMENTS:
 *&A& ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& Ū��CWA.SSA �M TWA.TMA ���_�l��}
 *&D&
 */
int
ReadLockCwa(pstLogTwa)
struct LogTwaSt *pstLogTwa;
{
  struct CwaCtl stCwaCtl;
  struct TwaCtl stTwaCtl;
  char *pcDummy;
  char *pcTerm;
  int iRc;

  UCP_TRACE(P_ReadLockCwa);

  stCwaCtl.cFunCode = CWA_SEG_LOCK;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaCtlFac(&stCwaCtl , pcDummy);
  if(iRc != CWA_NORMAL){
    sprintf( g_caMsg, "LOCK CWA: CwaCtlFac() fails! iRc=%d", iRc );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( ACCESS_CWA_ERR );
  }

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&(pstLogTwa->pstSsa));
  if (iRc < 0) {
    sprintf( g_caMsg, "Get CWA : CwaLowCtlFac() fails! iRc=%d", iRc );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UnLockCwa();                   /*added by pjw for tu995003 1999 6 10*/
    UCP_TRACE_END( ACCESS_CWA_ERR );
  }
  
  stTwaCtl.cFunCode = TWA_GET_SEG_PTR;
  stTwaCtl.cSegCode = TWA_SEG_TMA;
  iRc = TwaLowCtlFac(&stTwaCtl,&(pstLogTwa->pstTma));
  if (iRc < 0) {
    sprintf( g_caMsg, "Get Twa : TwaLowCtlFac() fails! iRc=%d", iRc );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UnLockCwa();                   /*added by pjw for tu995003 1999 6 10*/
    UCP_TRACE_END( ACCESS_TWA_ERR );
  }

 /* ----------------------------- */
 /* read current tct last log rrn */
 /* ----------------------------- */
  stCwaCtl.cFunCode = CWA_GET_TERM_PTR;
  memcpy(stCwaCtl.caBrhId, g_pstTma->stTSSA.caBrCode, g_iBrhCodeLen);
  memcpy(stCwaCtl.caTermId, g_pstTma->stTSSA.caTmCode, g_iTmCodeLen);
  iRc = CwaLowCtlFac(&stCwaCtl, &(pstLogTwa->pstTerm)) ;
  if ( iRc < 0 ) {
    sprintf( g_caMsg, "ChkTerml: Terminal not registered in TCT" );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UnLockCwa();                   /*added by pjw for tu995003 1999 6 10*/
    UCP_TRACE_END( ACCESS_CWA_ERR );
  }

  UCP_TRACE_END( 0 );
}

/*
 *&N& ROUTINE NAME: UnLockCwa()
 *&A& ARGUMENTS:
 *&A& ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& Unlock CWA.
 *&D&
 */
int
UnLockCwa()
{
  struct CwaCtl stCwaCtl;
  char *pcDummy;
  int iRc;

  UCP_TRACE(P_UnLockCwa);

  stCwaCtl.cFunCode = CWA_SEG_UNLOCK;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaCtlFac(&stCwaCtl , pcDummy);
  if(iRc != CWA_NORMAL){
    sprintf( g_caMsg, "UNLOCK CWA : CwaCtlFac() fails! iRc=%d", iRc );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( ACCESS_CWA_ERR );
  } 

  UCP_TRACE_END( 0 );
} 

/*
 *&N& ROUTINE NAME: GetTctLastRrn()
 *&A& ARGUMENTS:
 *&A& ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& Ū���Ӳ׺ݾ����̫�@���O����RRN��
 *&D&
 */
int
GetTctLastRrn(pcBrCode,pcTmCode,plLastRrn)
char *pcBrCode;
char *pcTmCode;
long *plLastRrn;
{
  int iRc;
  struct CwaCtl stCwaCtl;
  struct TermArea *pstTerm;

  UCP_TRACE(P_GetTctLastRrn);

  memcpy(stCwaCtl.caBrhId, pcBrCode, g_iBrhCodeLen);
  memcpy(stCwaCtl.caTermId, pcTmCode, g_iTmCodeLen);
  stCwaCtl.cFunCode = CWA_GET_TERM_PTR;
  iRc = CwaLowCtlFac(&stCwaCtl, &pstTerm);
  if ( iRc < 0 ) {
    sprintf( g_caMsg, "ChkTerml: Terminal not registered in TCT" );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( ACCESS_CWA_ERR );
  }

  *plLastRrn = pstTerm->lLastOnlnRrn;
  UCP_TRACE_END( 0 );
} 

/*
 *&N& ROUTINE NAME: GetNextAvRrn()
 *&A& ARGUMENTS:
 *&A& ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& Ū���t�Τ��U�@�ӥi�Τ�RRN��
 *&D&
 */
int
GetNextAvRrn(plNextRrn)
long *plNextRrn;
{
  struct CwaCtl stCwaCtl;
  struct SSA  *pstSsa;
  int iRc;

  UCP_TRACE(P_GetNextAvRrn);

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);
  if (iRc < 0) {
    sprintf( g_caMsg, "GetNextAvRrn: Get SSA ptr fails! iRc=%d", iRc );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( ACCESS_CWA_ERR );
  }
  *plNextRrn = pstSsa->lNextAvLogRrn;

  UCP_TRACE_END( 0 );
} 
