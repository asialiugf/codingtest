/*
 *&N& File : lgsfnset.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int          LOGOPERATION()
 */

/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include  <errno.h>
#include  "errlog.h"
#include  "lgcopewa.h"
#include  "lgclgfmt.h"

/* -------------------- CONSTANT DEFINE  --------------------------- */
#define  P_LOGOPERATION  		 51001
#define  LOG_OPEN_STATUS 		 0x01
#define  LOG_RANDOM_READ_STATUS 	 0x02
#define  LOG_RANDOM_READ_U_STATUS 	 0x04
#define  LOG_READ_NEXT_STATUS 		 0x08
#define  LOG_READ_NEXT_U_STATUS 	 0x10

/* -------------------- STATIC GLOBAL DECLARATION ------------------ */
extern int g_iTmCodeLen;        /* Term code real length         */
extern int g_iBrhCodeLen;       /* Branch code real length       */

/*
 *&N& ROUTINE NAME: LOGOPERATION()
 *&A& ARGUMENTS:
 *&A& ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D&
 */

int
LOGOPERATION(pcOpArea,pcIOArea)
char *pcOpArea;
char *pcIOArea;
{
  int  iRc;
  long lRrn;
  static char s_cStatus = 0x00;
  static char s_caCurLogRrn[LG_RRN_SIZE+1];
  char caKeyLen[LG_KEY_LEN_SIZE+1];
  char caKeyValue[LG_KEY_VAL_SIZE+1];
  char caBrCode[LG_MAX_BR_CODE_SIZE+1];
  char caTmCode[LG_MAX_TM_CODE_SIZE+1];
  char caSeqNo[LG_TXN_SEQ_SIZE+1];
  char caRrn[LG_RRN_SIZE+1];
  char cFoundFlag = '0';
  LOGAPI *pstOpApi;
  LOGFUNIF stFunApi;
  LOGFMT *pstLogBuf,stLogDataBuf;

  UCP_TRACE(P_LOGOPERATION);

  pstOpApi = (LOGAPI *) pcOpArea;
  pstLogBuf = (struct LogFmtSt *) pcIOArea;

  if (pstOpApi->caOperKind[0] != LG_OPEN  &&
      pstOpApi->caOperKind[0] != LG_CLOSE ) {
    memset(caKeyLen,'\0',LG_KEY_LEN_SIZE+1);
    memset(caKeyValue,'\0',LG_KEY_VAL_SIZE+1);
    memcpy(caKeyLen,pstOpApi->caKeyLen,LG_KEY_LEN_SIZE);
    memcpy(caKeyValue,pstOpApi->caKeyValue,atoi(caKeyLen));
  } 

  switch(pstOpApi->caOperKind[0]) {
    case  LG_OPEN            :
      stFunApi.caFunCode[0] = OPEN_LOG;
      LOGFCALL(&stFunApi,pstLogBuf);
      if ( stFunApi.caReturn[0] != LG_NORMAL ) { 
        sprintf(g_caMsg,"Open Log File Error = %c",stFunApi.caReturn[0]);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        pstOpApi->caReturnCd[0] = stFunApi.caReturn[0];
        UCP_TRACE_END( -1 );
      }
      s_cStatus = s_cStatus | LOG_OPEN_STATUS;
      break;
    case  LG_RANDOM_READ     :
    case  LG_RANDOM_READ_U   :
      if ( !( s_cStatus & LOG_OPEN_STATUS ) ) {
        pstOpApi->caReturnCd[0] = LG_WRONG_CALL_SEQ;
        ErrLog(1000,"Random Read Function:wrong call sequence!",RPT_TO_LOG,0,0);
        UCP_TRACE_END( -1 );
      }
      stFunApi.caLockMode[0] = FLAG_OFF;
      stFunApi.caFunCode[0] = DIRECT_READ_LOG;
      switch (pstOpApi->caKeyType[0]) {
        case  LG_BY_SEQNO  :
          memset(caBrCode, 0, LG_MAX_BR_CODE_SIZE+1) ;
          memset(caTmCode, 0, LG_MAX_TM_CODE_SIZE+1) ;
          memset(caSeqNo, 0, LG_TXN_SEQ_SIZE+1) ;
          memcpy(caBrCode,caKeyValue,g_iBrhCodeLen);
          memcpy(caTmCode,&caKeyValue[g_iBrhCodeLen],g_iTmCodeLen);
          memcpy(caSeqNo,&caKeyValue[g_iBrhCodeLen+g_iTmCodeLen],
                 LG_TXN_SEQ_SIZE);
          iRc = GetTctLastRrn(caBrCode,caTmCode,&lRrn);
          if( iRc < 0 ) {
            sprintf(g_caMsg,"GetTctLastRrn() rtncode=%d",iRc);
            ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
            pstOpApi->caReturnCd[0] = LG_SERVICE_ERR;
            UCP_TRACE_END( -1 );
          }
          sprintf(stFunApi.caRrn,"%.*d",LG_RRN_SIZE,lRrn);
          LOGFCALL(&stFunApi,pstLogBuf);
          while (stFunApi.caReturn[0] == LG_NORMAL) {
            if (strncmp(pstLogBuf->caBrCode,caBrCode,g_iBrhCodeLen) == 0 &&
                strncmp(pstLogBuf->caTmCode,caTmCode,g_iTmCodeLen ) == 0) {
              if (strncmp(pstLogBuf->caAccTxnSeqNo,caSeqNo,
                                              LG_TXN_SEQ_SIZE) == 0  ||
                  strncmp(pstLogBuf->caNonAccTxnSeqNo,caSeqNo,
                                              LG_TXN_SEQ_SIZE) == 0 ) {
                cFoundFlag = '1';
                if (pstOpApi->caOperKind[0] == LG_RANDOM_READ_U) {
                  stFunApi.caLockMode[0] = FLAG_ON;
                  LOGFCALL(&stFunApi,pstLogBuf);
                }
                break;
              }
            }
            memcpy(stFunApi.caRrn,pstLogBuf->caLastLogRecRrn,LG_RRN_SIZE);
            LOGFCALL(&stFunApi,pstLogBuf);
          } 

          memset(caRrn,'0',LG_RRN_SIZE);
          if (memcmp(stFunApi.caRrn,caRrn,LG_RRN_SIZE) == 0) {
             sprintf(g_caMsg,"Read Log by Rrn. Rec not found! Error=%c",
                     stFunApi.caReturn[0]);
             ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
             pstOpApi->caReturnCd[0] = LG_NO_REC_FOUND;
             UCP_TRACE_END( -1 );
          }
          if ( stFunApi.caReturn[0] != LG_NORMAL ) { 
            sprintf(g_caMsg,"Read Log by Seq Error=%c",stFunApi.caReturn[0]);
            ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
            pstOpApi->caReturnCd[0] = stFunApi.caReturn[0];
            UCP_TRACE_END( -1 );
          }

          if (cFoundFlag == '1') {
            pstOpApi->caReturnCd[0] = LG_NORMAL;
          }
          break;
        case  LG_BY_RRN  :
          if (pstOpApi->caOperKind[0] == LG_RANDOM_READ_U) {
            stFunApi.caLockMode[0] = FLAG_ON;
          }
          else {
            stFunApi.caLockMode[0] = FLAG_OFF;
          }
          memcpy(stFunApi.caRrn,caKeyValue,LG_RRN_SIZE);
          LOGFCALL(&stFunApi,pstLogBuf);
          if ( stFunApi.caReturn[0] != LG_NORMAL ) { 
             sprintf(g_caMsg,"Read Log by Rrn Error=%c",stFunApi.caReturn[0]);
             ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
             pstOpApi->caReturnCd[0] = stFunApi.caReturn[0];
             UCP_TRACE_END( -1 );
          }
          break;
        default          :
          pstOpApi->caReturnCd[0] = LG_INVALID_KEY_TYPE;
          sprintf(g_caMsg,"Ranndom Read:key type error=%c",
                  pstOpApi->caKeyType[0]);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          UCP_TRACE_END( -1 );
      }

      if (pstOpApi->caOperKind[0] == LG_RANDOM_READ_U) {
        s_cStatus |= LOG_RANDOM_READ_U_STATUS;
      }
      else {
        s_cStatus |= LOG_RANDOM_READ_STATUS;
      }

      /* ----------------- keep the current record RRN ---------------- */
      memset(s_caCurLogRrn,0,10);
      memcpy(s_caCurLogRrn,stFunApi.caRrn,LG_RRN_SIZE);
      break;
    case   LG_READ_NEXT       :
    case   LG_READ_NEXT_U     :
      if ( !( s_cStatus & LOG_OPEN_STATUS ) ) {
        pstOpApi->caReturnCd[0] = LG_WRONG_CALL_SEQ;
        ErrLog(1000,"Read Next Function:wrong call sequence!",RPT_TO_LOG,0,0);
        UCP_TRACE_END( -1 );
      }

      if ( !( s_cStatus & LOG_RANDOM_READ_STATUS) && 
                           !( s_cStatus & LOG_RANDOM_READ_U_STATUS ) ) {
        pstOpApi->caReturnCd[0] = LG_WRONG_CALL_SEQ;
        ErrLog(1000,"Read Next Function:wrong call sequence!",RPT_TO_LOG,0,0);
        UCP_TRACE_END( -1 );
      }

      if (pstOpApi->caKeyType[0] == LG_BY_SEQNO) {
        pstOpApi->caReturnCd[0] = LG_WRONG_CALL_SEQ;
        ErrLog(1000,"Read Next Function Can't By Seq No",RPT_TO_LOG,0,0);
        UCP_TRACE_END( -1 );
      }
      stFunApi.caLockMode[0] =
      (pstOpApi->caOperKind[0] == LG_READ_NEXT ?  FLAG_OFF : FLAG_ON);
      stFunApi.caFunCode[0] = DIRECT_READ_LOG;
      memset(caRrn,0,LG_RRN_SIZE+1);
      memcpy(caRrn,s_caCurLogRrn,LG_RRN_SIZE);
      lRrn = atol(caRrn);
      lRrn++;
      sprintf(stFunApi.caRrn,"%.*d",LG_RRN_SIZE,lRrn);
      LOGFCALL(&stFunApi,pstLogBuf);
      if (stFunApi.caReturn[0] != LG_NORMAL ) {
        if(stFunApi.caReturn[0] == LG_NO_REC_FOUND ) {
          pstOpApi->caReturnCd[0] = LG_NO_MORE_REC;
          ErrLog(1000,"Read Next Log Error! NO MORE REC!" ,RPT_TO_LOG,0,0);
          UCP_TRACE_END( -1 );
        }
        else {
          pstOpApi->caReturnCd[0] = LG_SERVICE_ERR;
          ErrLog(1000,"Read Next Log Error! SERVICE ERROR!" ,RPT_TO_LOG,0,0);
          UCP_TRACE_END( -1 );
        }
      }
      if (pstOpApi->caOperKind[0] == LG_READ_NEXT_U) {
        s_cStatus |= LOG_READ_NEXT_U_STATUS;
      }
      else {
        s_cStatus |= LOG_READ_NEXT_STATUS;
      }
      /* ----------------- keep the current record RRN ---------------- */
      memset(s_caCurLogRrn,0,10);
      memcpy(s_caCurLogRrn,stFunApi.caRrn,LG_RRN_SIZE);
      break;
    case   LG_REWRITE         :
      if ( !( s_cStatus & LOG_OPEN_STATUS ) ) {
        pstOpApi->caReturnCd[0] = LG_WRONG_CALL_SEQ;
        ErrLog(1000,"Rewrite Function:wrong call sequence!",RPT_TO_LOG,0,0);
        UCP_TRACE_END( -1 );
      }

      if ( !(s_cStatus & LOG_RANDOM_READ_U_STATUS) && 
                                !(s_cStatus & LOG_READ_NEXT_U_STATUS) ) {
        pstOpApi->caReturnCd[0] = LG_WRONG_CALL_SEQ;
        ErrLog(1000,"Rewrite Function:wrong call sequence!",RPT_TO_LOG,0,0);
        UCP_TRACE_END( -1 );
      }
      stFunApi.caFunCode[0] = WRITE_UPDATE_LOG;
      LOGFCALL(&stFunApi,pstLogBuf);
      if ( stFunApi.caReturn[0] != LG_NORMAL ) { 
        sprintf(g_caMsg,"Rewrite Log Error=%c",stFunApi.caReturn[0]);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        pstOpApi->caReturnCd[0] = stFunApi.caReturn[0];
        UCP_TRACE_END( -1 );
      }
      break;
    case   LG_APPEND          :
      if ( !( s_cStatus & LOG_OPEN_STATUS ) ) {
        pstOpApi->caReturnCd[0] = LG_WRONG_CALL_SEQ;
        ErrLog(1000,"Append Function:wrong call sequence!",RPT_TO_LOG,0,0);
        UCP_TRACE_END( -1 );
      }

      stFunApi.caFunCode[0] = INSERT_LOG;
      memcpy(stFunApi.caRrn,caKeyValue,LG_RRN_SIZE);
      LOGFCALL(&stFunApi,pstLogBuf);
      if ( stFunApi.caReturn[0] != LG_NORMAL ) { 
        sprintf(g_caMsg,"Append Log Error=%c",stFunApi.caReturn[0]);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        pstOpApi->caReturnCd[0] = stFunApi.caReturn[0];
        UCP_TRACE_END( -1 );
      }
      break;
    case   LG_READ_FIRST      :
    case   LG_READ_FIRST_U    :
      if ( !( s_cStatus & LOG_OPEN_STATUS ) ) {
        pstOpApi->caReturnCd[0] = LG_WRONG_CALL_SEQ;
        ErrLog(1000,"Read First Function:wrong call sequence!",RPT_TO_LOG,0,0);
        UCP_TRACE_END( -1 );
      }

      stFunApi.caLockMode[0] =
      (pstOpApi->caOperKind[0] == LG_READ_FIRST ?  FLAG_OFF : FLAG_ON);
      stFunApi.caFunCode[0] = DIRECT_READ_LOG;
      sprintf(stFunApi.caRrn,"%.*d",LG_RRN_SIZE,1);
      LOGFCALL(&stFunApi,pstLogBuf);
      if ( stFunApi.caReturn[0] != LG_NORMAL ) { 
        sprintf(g_caMsg,"Read First Log Error=%c",stFunApi.caReturn[0]);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        pstOpApi->caReturnCd[0] = stFunApi.caReturn[0];
        UCP_TRACE_END( -1 );
      }
      break;
    case   LG_READ_LAST       :
    case   LG_READ_LAST_U     :
      if ( !( s_cStatus & LOG_OPEN_STATUS ) ) {
        pstOpApi->caReturnCd[0] = LG_WRONG_CALL_SEQ;
        ErrLog(1000,"Read Last Function:wrong call sequence!",RPT_TO_LOG,0,0);
        UCP_TRACE_END( -1 );
      }

      iRc = GetNextAvRrn(&lRrn);
      if (iRc < 0) {
        pstOpApi->caReturnCd[0] = LG_SERVICE_ERR;
        sprintf(g_caMsg,"Call GetNextAvRrn Error iRc =%d",iRc);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END( -1 );
      }
      stFunApi.caLockMode[0] =
      (pstOpApi->caOperKind[0] == LG_READ_LAST  ?  FLAG_OFF : FLAG_ON);
      stFunApi.caFunCode[0] = DIRECT_READ_LOG;
      sprintf(stFunApi.caRrn,"%.*d",LG_RRN_SIZE,lRrn - 1);
      LOGFCALL(&stFunApi,pstLogBuf);
      if ( stFunApi.caReturn[0] != LG_NORMAL ) { 
        sprintf(g_caMsg,"Read Last Log Error=%c",stFunApi.caReturn[0]);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        pstOpApi->caReturnCd[0] = stFunApi.caReturn[0];
        UCP_TRACE_END( -1 );
      }
      break;
    case   LG_DIRECT_UPDATE   :
      if ( !( s_cStatus & LOG_OPEN_STATUS ) ) {
        pstOpApi->caReturnCd[0] = LG_WRONG_CALL_SEQ;
        ErrLog(1000,"Direct Update Function:wrong call sequence!",
               RPT_TO_LOG,0,0);
        UCP_TRACE_END( -1 );
      }

      stFunApi.caLockMode[0] = FLAG_ON;
      stFunApi.caFunCode[0] = DIRECT_READ_LOG;
      memcpy(stFunApi.caRrn,caKeyValue,LG_RRN_SIZE);
      LOGFCALL(&stFunApi,&stLogDataBuf);
      if (stFunApi.caReturn[0] != LG_NORMAL) {
        pstOpApi->caReturnCd[0] = stFunApi.caReturn[0];
        ErrLog(1000,"DIRECT UPDATE : Read Log Error",RPT_TO_LOG,0,0);
        UCP_TRACE_END( -1 );
      }
      stFunApi.caFunCode[0] = WRITE_UPDATE_LOG;
      LOGFCALL(&stFunApi,pstLogBuf);
      if ( stFunApi.caReturn[0] != LG_NORMAL ) { 
        sprintf(g_caMsg,"Direct Update Log Error=%c",stFunApi.caReturn[0]);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        pstOpApi->caReturnCd[0] = stFunApi.caReturn[0];
        UCP_TRACE_END( -1 );
      }
      break;
    case   LG_READ_PREV:
    case   LG_READ_PREV_U:
      break;
    case   LG_CLOSE           :
      if ( !( s_cStatus & LOG_OPEN_STATUS ) ) {
        pstOpApi->caReturnCd[0] = LG_WRONG_CALL_SEQ;
        ErrLog(1000,"Close Function:wrong call sequence!",RPT_TO_LOG,0,0);
        UCP_TRACE_END( -1 );
      }

      stFunApi.caFunCode[0] = CLOSE_LOG;
      LOGFCALL(&stFunApi,pstLogBuf);
      if ( stFunApi.caReturn[0] != LG_NORMAL ) { 
        sprintf(g_caMsg,"Close Log File Error=%c",stFunApi.caReturn[0]);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        pstOpApi->caReturnCd[0] = stFunApi.caReturn[0];
        UCP_TRACE_END( -1 );
      }
      cFoundFlag='0';
      s_cStatus = 0x00;
      break;
    default                   :
      sprintf(g_caMsg,"INVALID FUNCTION CODE = %c",pstOpApi->caOperKind[0]);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      stFunApi.caReturn[0] = LG_INVALID_FUN;
      UCP_TRACE_END( -1 );
  }
  pstOpApi->caReturnCd[0] = stFunApi.caReturn[0];
  /* record the last operation code in order to reference it later */
  UCP_TRACE_END( 0 );
}
