
/*
 *&N& File : ucptxnlg.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int          UcpTxnLg()
 *&N&    int          PrepareLgData()
 */

/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include "errlog.h"
#include "lgclgfmt.h.old"
#include "lgcopewa.h"
#include "oldapa.h"

/* -------------------- CONSTANT DEFINE  --------------------------- */
#define         P_UcpTxnLg              54001
#define         P_PrepareLgData         54001
#define		TIME_LEN         	6
#define		DATE_LEN        	8

/* -------------------- STATIC GLOBAL DECLARATION ------------------ */
extern struct TMA *g_pstTma;	/* point TWA.TMA��ưϪ������ܼ� */
extern int g_iTxnCodeLen;       /* Txn code real length          */
extern int g_iTmCodeLen;        /* Term code real length         */
extern int g_iBrhCodeLen;       /* Branch code real length       */
extern int g_iTotLogCntPerTxn;  /* total log rec. cnt of per txn. */

struct LogRrnHistSt g_staLogRrnHist[ MAX_LOG_PER_TXN ];

/*
 *&N& ROUTINE NAME: UcpTxnLg()
 *&A& ARGUMENTS:
 *&A& ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& ����ƱqTMA��,�NAP�|�ϥΨ쪺��ƽƻs��APA��,�p:
 *&D&   �����ε{���g�O����API
 *&D&
 */

int
UcpTxnLg(cWhoWrtLog,pcApa,pcRtnRrn,pcApIo,pcSif)
char cWhoWrtLog;
char *pcApa;
char *pcRtnRrn;
char *pcApIo;
char *pcSif;
{
  int iRc;
  char *pcLogIo;
  char caRrnBuf[10];
  char caTmpBuf[10];
  struct ApaSt *pstApa;
  struct LogTwaSt stLogTwa;
  struct LogFmtSt stLogBuf;
  struct TMA *pstTma;
  LOGAPI stLogApi;

  UCP_TRACE(P_UcpTxnLg);

  pstApa = (struct ApaSt *) pcApa;
  stLogTwa.pstApa = pstApa;

 /* ------------------------------------ */
 /* read SSA & BIT & TMA Segment Address */
 /* ------------------------------------ */
  iRc = ReadLockCwa(&stLogTwa);
  if (iRc < 0) {
    UCP_TRACE_END( -1 );
  }

 /* ------------------------------------ */
 /* open log file                        */
 /* ------------------------------------ */
  stLogApi.caOperKind[0] = LG_OPEN;
  stLogApi.caReturnCd[0] = LG_NORMAL;
  iRc = LOGOPERATION(&stLogApi,&stLogBuf);
  if (stLogApi.caReturnCd[0] != LG_NORMAL) {
    UnLockCwa();
    UCP_TRACE_END( -1 );
  }

 /* ------------------------------------ */
 /* prepare log record data              */
 /* ------------------------------------ */
  iRc = PrepareLgData(cWhoWrtLog,&stLogBuf,&stLogTwa,pcApIo,pcSif);
  if ( iRc < 0 ) {
    UnLockCwa();
    UCP_TRACE_END( -1 );
  }

 /* ------------------------------------ */
 /* write log record data                */
 /* ------------------------------------ */
  if (stLogTwa.pstSsa->lNextAvLogRrn > LG_MAX_REC_CNT) {
    stLogApi.caOperKind[0] = LG_APPEND;
  }
  else {
    stLogApi.caOperKind[0] = LG_DIRECT_UPDATE;
  }

  stLogApi.caKeyType[0] = LG_BY_RRN;
  memset(caTmpBuf,0,10);
  sprintf(caTmpBuf,"%.*d",LG_KEY_LEN_SIZE,LG_RRN_SIZE);
  memcpy(stLogApi.caKeyLen,caTmpBuf,LG_KEY_LEN_SIZE);
  sprintf(stLogApi.caKeyValue,"%.*d",
          LG_RRN_SIZE,stLogTwa.pstSsa->lNextAvLogRrn);
  stLogApi.caReturnCd[0] = LG_NORMAL;
  iRc = LOGOPERATION(&stLogApi,&stLogBuf);
  if (stLogApi.caReturnCd[0] != LG_NORMAL) {
    UnLockCwa();
    UCP_TRACE_END( -1 );
  }
  
 /* ------------------------------------ */
 /* close log file                       */
 /* ------------------------------------ */
  stLogApi.caOperKind[0] = LG_CLOSE;
  stLogApi.caReturnCd[0] = LG_NORMAL;
  iRc = LOGOPERATION(&stLogApi,&stLogBuf);
  if (stLogApi.caReturnCd[0] != LG_NORMAL) {
    UnLockCwa();
    UCP_TRACE_END( -1 );
  }

 /* ------------------------------------ */
 /* copy current RRN to return buffer    */
 /* ------------------------------------ */
  memset(caRrnBuf,0,10);
  sprintf(caRrnBuf,"%.*d",LG_RRN_SIZE,stLogTwa.pstSsa->lNextAvLogRrn);
  memcpy(pcRtnRrn,caRrnBuf,LG_RRN_SIZE);  /* LG_RRN_SIZE (8) */

 /* ------------------------------------ */
 /* add 1 to next available log rrn      */
 /* ------------------------------------ */
  stLogTwa.pstSsa->lNextAvLogRrn++;

 /* ------------------------------------ */
 /* unlock cwa && tma                    */
 /* ------------------------------------ */
  iRc = UnLockCwa(&stLogTwa);
  if (iRc < 0) {
    UCP_TRACE_END( -1 );
  }

 /* ---------------------------------------------- */
 /* keep the RRN of log already been write to file */
 /* ---------------------------------------------- */
  memcpy(g_staLogRrnHist[g_iTotLogCntPerTxn-2].caRrn, caRrnBuf, LG_RRN_SIZE) ;

  UCP_TRACE_END( 0 );
}


/*
 *&N& ROUTINE NAME: PrepareLgData()
 *&A& ARGUMENTS:
 *&A& ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& ����ƱqTMA��,�NAP�|�ϥΨ쪺��ƽƻs��APA��,�p:
 *&D& �ǳƭn�g�J�O���ɤ����������
 *&D&
 */
int
PrepareLgData(cWhoWrtLog,pstLogBuf,pstLogTwa,pcApIo,pcSif)
char cWhoWrtLog;
struct LogFmtSt *pstLogBuf;
struct LogTwaSt *pstLogTwa;
char *pcApIo;
char *pcSif;
{
  char caTmp[10];

  UCP_TRACE(P_PrepareLgData);

  memset(caTmp,0,10);
  sprintf(caTmp,"%.7d",pstLogTwa->pstSsa->lNextAvLogRrn);
  memcpy( pstLogBuf->caCurLogRrn, Comp3Conv(caTmp,4), 4);

  pstLogBuf->caRecId[0] = cWhoWrtLog ;
  memcpy( pstLogBuf->caTxnDate, pstLogTwa->pstSsa->caTxnDate, DATE_LEN );

/* --------------------- not found in SSA -------------- */
  memcpy( pstLogBuf->caTxnTime, pstLogTwa->pstTma->stTSSA.caStartTxnTime,
          TIME_LEN );

/* -------------------   main   frame  task no   ------------ */
  memcpy( pstLogBuf->caTaskNo, "0000", 4 );

  pstLogBuf->caRecCnt[0] = (char) g_iTotLogCntPerTxn; 

  memset(caTmp, 0, 10);
  sprintf(caTmp,"%.*d",7,pstLogTwa->pstTerm->lLastOnlnRrn);
  memcpy( pstLogBuf->caLastRrn, Comp3Conv(caTmp), 4 );        

/* --------------------- TmIdNo is ( BrCode + TmCode )  --------------  */
  memcpy(pstLogBuf->caTmIdNo,pstLogTwa->pstTma->stTSSA.caBrCode,g_iBrhCodeLen);
  memcpy(&pstLogBuf->caTmIdNo[g_iBrhCodeLen],pstLogTwa->pstTma->stTSSA.caTmCode,
         g_iTmCodeLen);

/* --------------------------   Acc or Non-Acc  ----------------------- */
  if ( pstLogTwa->pstApa->cTxnReturnCode == '0' ||
                   pstLogTwa->pstApa->cTxnReturnCode == '4' ) {
    memcpy(pstLogBuf->caTxnSeqNo, pstLogTwa->pstApa->caAccTxnSeqNo,3);
  }
  else {
    if (pstLogTwa->pstApa->cTxnReturnCode == '2') {
      memcpy(pstLogBuf->caTxnSeqNo, pstLogTwa->pstApa->caNonAccTxnSeqNo,3);
    }
    else {
      memcpy(pstLogBuf->caTxnSeqNo, '0', 3 );
    }
  }
/* --------------------------   Acc or Non-Acc  ----------------------- */

/* -------------------   main   frame   ------------
  memcpy(pstLogBuf->caSifLen,"00",2);
  memcpy(pstLogBuf->caSifOffset,"00",2);
  memcpy( pstLogBuf->caAccIdNo, pstLogTwa->pstTct->caActiveAccNo, 16 );
  pstLogBuf->caSyncPointCd[0] = pstLogTwa->pstTct->cSyncPoint;
*/

  memset( caTmp , '\0' , 10 );
  sprintf( caTmp,"%.*d", 7, pstLogTwa->pstSsa->lNextAvLogRrn );
  memcpy( pstLogBuf->caNextAvLogRrn, Comp3Conv(caTmp), 4 );

/* -----------  not used in Unix Version -------------
  pstLogBuf->caNextAvBtefRrn[7];     
 */

  memset( caTmp, '\0', 10 );
  sprintf( caTmp, "%.*ld" ,7 ,pstLogTwa->pstSsa->lTotalTxnCnt );
  memcpy( pstLogBuf->caTotTxnSeqNo, Comp3Conv(caTmp), 4 );

  /* -----------------below belong to old twa------------------------- */
  memcpy(pstLogBuf->caBrCode, pstLogTwa->pstApa->caBrCode,
          g_iBrhCodeLen );
  memcpy(pstLogBuf->caTmCode, pstLogTwa->pstApa->caTmCode,
          g_iTmCodeLen );
  pstLogBuf->caTmType[0] = pstLogTwa->pstApa->cTmType;
  pstLogBuf->caBrStatus[0] = pstLogTwa->pstApa->cOriginBrStatus;
  memcpy(pstLogBuf->caLastBusiYy,pstLogTwa->pstTma->stTSSA.caNextTxnDate,
         DATE_LEN);
  pstLogBuf->caNextBusiDayCnt[0] = pstLogTwa->pstApa->cNextBusiDayCnt;
  memcpy(pstLogBuf->caTotSeqCnt,pstLogTwa->pstApa->caTotalTxnSeqNo,4);
  memcpy(pstLogBuf->caNormalTxnCnt,pstLogTwa->pstApa->caAccTxnSeqNo,3);
  memcpy(pstLogBuf->caSpecalTxnCnt,pstLogTwa->pstApa->caNonAccTxnSeqNo,3);
  memcpy( pstLogBuf->caBatchTxnCnt,pstLogTwa->pstApa->caBtchTxnSeqNo,3);
  memcpy(pstLogBuf->caTwTime,pstLogTwa->pstApa->caTxnTime,TIME_LEN);
  memcpy(pstLogBuf->caTwTxnId,pstLogTwa->pstApa->caTxnCode,g_iTxnCodeLen);
  memcpy(pstLogBuf->caTwTxnYy, pstLogTwa->pstApa->caTxnDate, DATE_LEN);

  pstLogBuf->caTwSupStatu[0] = pstLogTwa->pstApa->cSupKeyStatus;
  pstLogBuf->caTwDocStatu[0] =pstLogTwa->pstApa->cBookStatus;
  pstLogBuf->caTwTxnStatu[0] =pstLogTwa->pstApa->cTxnStatus;
  pstLogBuf->caTwReentryIndic[0] = pstLogTwa->pstApa->cReentryStatus;
  memcpy(pstLogBuf->caTwTellerId,pstLogTwa->pstApa->caTellId,2);
  pstLogBuf->caTwTxnReturnCd[0] = pstLogTwa->pstApa->cTxnReturnCode;
  /* -----------------below belong to old twa------------------------- */

  /* ----------------- belong BIT Area  ------------------------------ */
  memset(caTmp, 0, 10);
  sprintf(caTmp,"%.*d",7,pstLogTwa->pstTerm->lLastOnlnRrn);
  memcpy( pstLogBuf->caLastLogRecRrn, Comp3Conv(caTmp), 4);
  memset( pstLogBuf->caTmSaveArea, ' ', 39);
  /* ----------------- belong BIT Area  ------------------------------ */

  /* -----------------below belong to (AP REV AREA) ------------------ */
  if ( cWhoWrtLog == AP_WRT_LOG ) {
    memcpy(pstLogBuf->caApUseArea,pcApIo,400);
  }
  /* -----------------below belong to (AP REV AREA) ------------------ */

  /* -----------------below belong to (AP SIF AREA) ------------------ */
  memcpy(pstLogBuf->caSifArea,pcSif,400);
  pstLogBuf->caSifArea[399] = '\n';
  /* -----------------below belong to (AP SIF AREA) ------------------ */

  UCP_TRACE_END( 0 );
}
