
#define  COBOL_LOG_FILE_NAME   "/iii/log/sbtxlogf"

GETLGNAME(char *pcLogName)
{
  strcpy(pcLogName,(char *)getenv("III_DIR"));
  strcat(pcLogName,COBOL_LOG_FILE_NAME);
  return;
}

   
