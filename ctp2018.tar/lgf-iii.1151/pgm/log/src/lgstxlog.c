
/*
 *&N& File : lgstxlog.c
 *&N&
 *&N& ��ƲM��
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int          UcpTxnLg()
 *&N&    int          PrepareLgData()
 */

/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include "errlog.h"
#include "lgclgfmt.h"
#include "lgcopewa.h"
#include "apa.h"

/* -------------------- CONSTANT DEFINE  --------------------------- */
#define         P_UcpTxnLg              54001
#define         P_PrepareLgData         54002
#define         P_LogMarkoff            54003
#define		TIME_LEN         	6
#define		DATE_LEN        	8

/* -------------------- STATIC GLOBAL DECLARATION ------------------ */
extern struct TMA *g_pstTma;	/* point TWA.TMA��ưϪ������ܼ� */
extern int g_iTxnCodeLen;       /* Txn code real length          */
extern int g_iTmCodeLen;        /* Term code real length         */
extern int g_iBrhCodeLen;       /* Branch code real length       */
extern int g_iTotLogCntPerTxn;  /* total log rec. cnt of per txn. */

struct LogRrnHistSt g_staLogRrnHist[ MAX_LOG_PER_TXN ];

/*
 *&N& ROUTINE NAME: UcpTxnLg()
 *&A& ARGUMENTS:
 *&A& ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& ����ƱqTMA��,�NAP�|�ϥΨ쪺��ƽƻs��APA��,�p:
 *&D&   �����ε{���g�O����API
 *&D&
 */

int
UcpTxnLg(cWhoWrtLog,pcApa,pcRtnRrn,pcApIo,pcSif,iSifLen)
char cWhoWrtLog;
char *pcApa;
char *pcRtnRrn;
char *pcApIo;
char *pcSif;
int  iSifLen;
{
  int iRc;
  char *pcLogIo;
  char caRrnBuf[10];
  char caTmpBuf[10];
  struct ApaSt *pstApa;
  struct LogTwaSt stLogTwa;
  struct LogFmtSt stLogBuf;
  struct TMA *pstTma;
  LOGAPI stLogApi;

  UCP_TRACE(P_UcpTxnLg);

  pstApa = (struct ApaSt *) pcApa;
  stLogTwa.pstApa = pstApa;

 /* ------------------------------------ */
 /* read SSA & BIT & TMA Segment Address */
 /* ------------------------------------ */
  iRc = ReadLockCwa(&stLogTwa);
  if (iRc < 0) {
    UCP_TRACE_END( -1 );
  }

 /* ------------------------------------ */
 /* open log file                        */
 /* ------------------------------------ */
  stLogApi.caOperKind[0] = LG_OPEN;
  stLogApi.caReturnCd[0] = LG_NORMAL;
  iRc = LOGOPERATION(&stLogApi,&stLogBuf);
  if (stLogApi.caReturnCd[0] != LG_NORMAL) {
    UnLockCwa();
    UCP_TRACE_END( -1 );
  }

 /* ------------------------------------ */
 /* prepare log record data              */
 /* ------------------------------------ */
  iRc = PrepareLgData(cWhoWrtLog,&stLogBuf,&stLogTwa,pcApIo,pcSif,iSifLen);
  if ( iRc < 0 ) {
    UnLockCwa();
    UCP_TRACE_END( -1 );
  }

/* ErrLog(100,"UcpTxnLg: dump stLogBuf=",RPT_TO_LOG,&stLogBuf,LG_REC_SIZE); */

 /* ------------------------------------ */
 /* write log record data                */
 /* ------------------------------------ */
  if (stLogTwa.pstSsa->lNextAvLogRrn > LG_MAX_REC_CNT) {
    stLogApi.caOperKind[0] = LG_APPEND;
  }
  else {
    stLogApi.caOperKind[0] = LG_DIRECT_UPDATE;
  }

  stLogApi.caKeyType[0] = LG_BY_RRN;
  memset(caTmpBuf,0,10);
  sprintf(caTmpBuf,"%.*d",LG_KEY_LEN_SIZE,LG_RRN_SIZE);
  memcpy(stLogApi.caKeyLen,caTmpBuf,LG_KEY_LEN_SIZE);
  sprintf(stLogApi.caKeyValue,"%.*d",
          LG_RRN_SIZE,stLogTwa.pstSsa->lNextAvLogRrn);
  stLogApi.caReturnCd[0] = LG_NORMAL;
  iRc = LOGOPERATION(&stLogApi,&stLogBuf);
  if (stLogApi.caReturnCd[0] != LG_NORMAL) {
    UnLockCwa();
    UCP_TRACE_END( -1 );
  }
  
/*
  sprintf(caRrnBuf,"%.*d",LG_RRN_SIZE,stLogTwa.pstSsa->lNextAvLogRrn);
  sprintf(g_caMsg,"UcpTxnLg(): Before close() SSA.lNextAvLogRrn=%.8s",
          caRrnBuf);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
*/

 /* ------------------------------------ */
 /* close log file                       */
 /* ------------------------------------ */
  stLogApi.caOperKind[0] = LG_CLOSE;
  stLogApi.caReturnCd[0] = LG_NORMAL;
  iRc = LOGOPERATION(&stLogApi,&stLogBuf);
  if (stLogApi.caReturnCd[0] != LG_NORMAL) {
    UnLockCwa();
    UCP_TRACE_END( -1 );
  }

 /* ------------------------------------ */
 /* copy current RRN to return buffer    */
 /* ------------------------------------ */
  memset(caRrnBuf,0,10);
  sprintf(caRrnBuf,"%.*d",LG_RRN_SIZE,stLogTwa.pstSsa->lNextAvLogRrn);
  memcpy(pcRtnRrn,caRrnBuf,LG_RRN_SIZE);  /* LG_RRN_SIZE (8) */

/*
  sprintf(g_caMsg,"UcpTxnLg(): SSA.lNextAvLogRrn=%.8s",
          pcRtnRrn);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
*/

 /* ------------------------------------ */
 /* add 1 to next available log rrn      */
 /* ------------------------------------ */
  stLogTwa.pstTerm->lLastOnlnRrn = stLogTwa.pstSsa->lNextAvLogRrn;
  stLogTwa.pstSsa->lNextAvLogRrn++;

 /* ------------------------------------ */
 /* unlock cwa && tma                    */
 /* ------------------------------------ */
  iRc = UnLockCwa(&stLogTwa);
  if (iRc < 0) {
    UCP_TRACE_END( -1 );
  }

 /* ---------------------------------------------- */
 /* keep the RRN of log already been write to file */
 /* ---------------------------------------------- */
  memcpy(g_staLogRrnHist[g_iTotLogCntPerTxn-1].caRrn, caRrnBuf, LG_RRN_SIZE) ;

  UCP_TRACE_END( 0 );
}


/*
 *&N& ROUTINE NAME: PrepareLgData()
 *&A& ARGUMENTS:
 *&A& ---------  ---------------------    -------------------------
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D& ����ƱqTMA��,�NAP�|�ϥΨ쪺��ƽƻs��APA��,�p:
 *&D& �ǳƭn�g�J�O���ɤ����������
 *&D&
 */
int
PrepareLgData(cWhoWrtLog,pstLogBuf,pstLogTwa,pcApIo,pcSif,iSifLen)
char cWhoWrtLog;
struct LogFmtSt *pstLogBuf;
struct LogTwaSt *pstLogTwa;
char *pcApIo;
char *pcSif;
int  iSifLen;
{
  char caTmp[10];

  UCP_TRACE(P_PrepareLgData);

  memset(caTmp,0,10);
  memset(pstLogBuf,0,LG_REC_SIZE);
  memcpy( pstLogBuf->caReverse, "XX", 2 );
  pstLogBuf->caRecId[0] = cWhoWrtLog ;
  memcpy( pstLogBuf->caTaskNo, "XXXX", 4 );
/* sprintf(g_caMsg,"PrepareLgData: g_iTotLogCntPerTxn=%d",g_iTotLogCntPerTxn);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0); */
  memset(caTmp,0,10);
  sprintf(caTmp,"%.*d",REC_CNT_SIZE,g_iTotLogCntPerTxn);
  memcpy(pstLogBuf->caRecCnt,caTmp,REC_CNT_SIZE);
  sprintf(caTmp,"%.4d", iSifLen);
  memcpy(pstLogBuf->caSifLen,caTmp,4);

/* not found in TCT
 * pstLogBuf->caSyncPointCd[0] = pstLogTwa->pstTerm->cSyncPoint;
 */

  memset( caTmp , '\0' , 10 );
  sprintf( caTmp,"%.*d", LG_RRN_SIZE, pstLogTwa->pstSsa->lNextAvLogRrn );
  memcpy( pstLogBuf->caCurrLogRrn, caTmp, LG_RRN_SIZE );

/* not found in TWA
 * pstLogBuf->caNextAvBtefRrn[7];
 */

  /* modify 3-lines by WuChihLiang 19950523 for keep this LOG TXN SEQ NO-BEGIN*/
  /*memset( caTmp, '\0', 10 );
  sprintf( caTmp, "%.*d", LG_RRN_SIZE, pstLogTwa->pstSsa->lTotalTxnCnt );
  memcpy( pstLogBuf->caSystemTxnSeqNo, caTmp, LG_RRN_SIZE );*/
  memset( pstLogBuf->caSystemTxnSeqNo, '0', 10 );
  sprintf(g_caMsg,"PrepareLgData:dump caSystemTxnSeqNo-before set"); 
  ErrLog(100,g_caMsg,RPT_TO_LOG,pstLogBuf->caSystemTxnSeqNo,10); 
  sprintf(g_caMsg,
 "PrepareLgData: caBtchTxnSeqNo=%.5s,caAccTxnSeqNo=%.5s,caNonAccTxnSeqNo=%.5s",
    pstLogTwa->pstApa->caBtchTxnSeqNo, pstLogTwa->pstApa->caAccTxnSeqNo,
    pstLogTwa->pstApa->caNonAccTxnSeqNo);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0); 
  if ( pstLogTwa->pstTma->stTSSA.cTmType == '9'){/* Batch Terminal */
    memcpy( &pstLogBuf->caSystemTxnSeqNo[5], pstLogTwa->pstApa->caBtchTxnSeqNo, 
            LG_TXN_SEQ_SIZE);
  }else{
    if ( pstLogTwa->pstApa->cTxnReturnCode == '0'){/* Account Txn */
      sprintf(caTmp,"%.*d",LG_TXN_SEQ_SIZE,pstLogTwa->pstApa->caAccTxnSeqNo);
      memcpy(&pstLogBuf->caSystemTxnSeqNo[5], pstLogTwa->pstApa->caAccTxnSeqNo,
             LG_TXN_SEQ_SIZE);
    }else{ /* NonAccount Txn */
      sprintf(caTmp,"%.*d",LG_TXN_SEQ_SIZE,pstLogTwa->pstApa->caNonAccTxnSeqNo);
      memcpy(&pstLogBuf->caSystemTxnSeqNo[5],pstLogTwa->pstApa->caNonAccTxnSeqNo
             , LG_TXN_SEQ_SIZE);
    }
  }
  sprintf(g_caMsg,"PrepareLgData:dump caSystemTxnSeqNo is"); 
  ErrLog(100,g_caMsg,RPT_TO_LOG,pstLogBuf->caSystemTxnSeqNo,10); 
  /* modify 3-lines by WuChihLiang 19950523 for keep this LOG TXN SEQ NO-END  */

/* ------------------------      APA    DATA  ---------------------- */
  memcpy( pstLogBuf->caTxnId,pstLogTwa->pstTma->stTSSA.caTxnCode,
          g_iTxnCodeLen);
  memcpy(pstLogBuf->caBrCode, pstLogTwa->pstTma->stTSSA.caBrCode,
         g_iBrhCodeLen );
  memcpy(pstLogBuf->caTmCode, pstLogTwa->pstTma->stTSSA.caTmCode,
         g_iTmCodeLen );
  memcpy(pstLogBuf->caTellerCd,pstLogTwa->pstTma->stTSSA.caTellId,2);
  pstLogBuf->caOriginBrStatus[0] = pstLogTwa->pstTma->stTSSA.cOriginBrStatus;
  pstLogBuf->caTmType[0] = pstLogTwa->pstTma->stTSSA.cTmType;

  pstLogBuf->caSupKeyStatus[0] = pstLogTwa->pstApa->cSupKeyStatus;
  pstLogBuf->caBookStatus[0] =pstLogTwa->pstApa->cBookStatus;
  pstLogBuf->caTxnStatus[0] =pstLogTwa->pstApa->cTxnStatus;
  pstLogBuf->caApRqt[0] = pstLogTwa->pstApa->cAprqt;

  pstLogBuf->caLineReentryStatus[0] = pstLogTwa->pstTma->stTSSA.cReentryStatus;

pstLogBuf->caFiscSwitch[0]=pstLogTwa->pstTma->stTCFA.cFiscSwitch;
pstLogBuf->caFiscApReturnCd[0]=pstLogTwa->pstTma->stTCFA.cFiscApReturnCode;
pstLogBuf->caOverTime[0]=pstLogTwa->pstTma->stTCFA.cOverTime;

  memcpy(pstLogBuf->caTxnDate,pstLogTwa->pstTma->stTSSA.caTxnDate,DATE_LEN);
  memcpy(pstLogBuf->caNextDate,pstLogTwa->pstTma->stTSSA.caNextTxnDate,
         DATE_LEN);
  pstLogBuf->caNextDayCnt[0]=pstLogTwa->pstTma->stTSSA.sNextDayCnt;
  memcpy( pstLogBuf->caTxnTime, pstLogTwa->pstTma->stTSSA.caStartTxnTime,
          TIME_LEN);
/* <clwu> decides to delete this item on 11/3 
 * memcpy(pstLogBuf->caTotalSeqCnt,pstLogTwa->pstApa->caTotalTxnSeqNo,4);
 */
  memcpy(pstLogBuf->caAccTxnSeqNo,pstLogTwa->pstApa->caAccTxnSeqNo,5);
  memcpy(pstLogBuf->caNonAccTxnSeqNo,pstLogTwa->pstApa->caNonAccTxnSeqNo,5);
  memcpy( pstLogBuf->caBatchTxnSeqNo,pstLogTwa->pstApa->caBtchTxnSeqNo,5);
/* modify 1-line by WuChihLiang 19950407 -- BEGIN */
  /*pstLogBuf->caTxnReturnCd[0] = pstLogTwa->pstTma->stTCFA.cApReturnCode;*/
  pstLogBuf->caTxnReturnCd[0] = pstLogTwa->pstApa->cTxnReturnCode;
/* modify 1-line by WuChihLiang 19950407 -- END   */
/* ------------------------      APA    DATA  ---------------------- */

  /* ----------------- belong BIT Area  ------------------------------ */
  memset(caTmp, 0, 10);
  sprintf(caTmp,"%.*d",LG_RRN_SIZE,pstLogTwa->pstTerm->lLastOnlnRrn);
  memcpy( pstLogBuf->caLastLogRecRrn, caTmp, LG_RRN_SIZE );
  memset( pstLogBuf->caFiller, ' ', 27);
  /* ----------------- belong BIT Area  ------------------------------ */

  /* -----------------below belong to (AP REV AREA) ------------------ */
  if ( cWhoWrtLog == AP_WRT_LOG ) {
    memcpy(pstLogBuf->caApUserArea,pcApIo,450);
  }
  /* -----------------below belong to (AP REV AREA) ------------------ */

  /* -----------------below belong to (AP SIF AREA) ------------------ */
  memcpy(pstLogBuf->caSifArea,pcSif,400);
  pstLogBuf->caSifArea[399] = '\n';
  /* -----------------below belong to (AP SIF AREA) ------------------ */

  UCP_TRACE_END( 0 );
}


int
LogMarkOff(iCnt)
int iCnt;
{
  LOGAPI stLogCtl;
  LOGFMT stLogFmt;
  int iIdx;
  int iRc;
 
  UCP_TRACE(P_LogMarkoff);

/* sprintf(g_caMsg,"LogMarkOff: begin,iCnt=%d",iCnt);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0); */
  stLogCtl.caOperKind[0] = LG_OPEN;
  stLogCtl.caReturnCd[0] = LG_NORMAL;
  LOGOPERATION(&stLogCtl,&stLogFmt);
  if (stLogCtl.caReturnCd[0] != LG_NORMAL) {
    sprintf(g_caMsg,"LogMarkOff:Open Log Error = %c",stLogCtl.caReturnCd[0]);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  }

  for (iIdx = 0; iIdx < iCnt;iIdx++) {
    stLogCtl.caKeyType[0] = LG_BY_RRN;
    stLogCtl.caOperKind[0] = LG_RANDOM_READ_U;
    sprintf(stLogCtl.caKeyLen,"%.*d",LG_KEY_LEN_SIZE,LG_RRN_SIZE);
    memcpy(stLogCtl.caKeyValue,g_staLogRrnHist[iIdx].caRrn,LG_RRN_SIZE);
/*  sprintf(g_caMsg,"LogMarkOff:g_staLogRrnHist[%d] stLogCtl.caKeyValue=%.*s",
            iIdx,LG_RRN_SIZE,g_staLogRrnHist[iIdx].caRrn);
    ErrLog(100,g_caMsg,RPT_TO_LOG,0,0); */
    stLogCtl.caReturnCd[0] = LG_NORMAL;
    LOGOPERATION(&stLogCtl,&stLogFmt);
    if (stLogCtl.caReturnCd[0] == LG_NORMAL) {
      stLogCtl.caKeyType[0] = LG_BY_RRN;
      stLogCtl.caOperKind[0] = LG_REWRITE;
      sprintf(stLogCtl.caKeyLen,"%.*d",LG_KEY_LEN_SIZE,LG_RRN_SIZE);
      memcpy(stLogCtl.caKeyValue,g_staLogRrnHist[iIdx].caRrn,LG_RRN_SIZE);
      stLogFmt.caTxnReturnCd[0] = LG_AP_REJECTED;
      stLogCtl.caReturnCd[0] = LG_NORMAL;
      LOGOPERATION(&stLogCtl,&stLogFmt);
      if (stLogCtl.caReturnCd[0] != LG_NORMAL) {
        sprintf(g_caMsg,"Mark Rejected Txn Log Rewrite Error = %c",
                stLogCtl.caReturnCd[0]);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END(-1);
      }
    }
    else {
      sprintf(g_caMsg,"LogMarkOff:Read Rejected Txn Log Rewrite Error = %c",
                                                     stLogCtl.caReturnCd[0]);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(-1);
    }
  }

/* sprintf(g_caMsg,"LogMarkOff: end,iCnt=%d",iCnt);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0); */
  stLogCtl.caOperKind[0] = LG_CLOSE;
  stLogCtl.caReturnCd[0] = LG_NORMAL;
  LOGOPERATION(&stLogCtl,&stLogFmt);
  if (stLogCtl.caReturnCd[0] != LG_NORMAL) {
    sprintf(g_caMsg,"LogMarkOff:Close Log Error = %c",stLogCtl.caReturnCd[0]);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  }

  UCP_TRACE_END(0);

}

