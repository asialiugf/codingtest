#include "asscal.h"

ASDAYIN3(pstPara)
struct parASDAYIN3 *pstPara;
{
 struct calendar stCalData;
 int    iYear;
 int    iDate,iDayCnt;
 int    iNDayCnt, iNNDayCnt;
 char   caBrCode[15];
 int    iRc;
 int    i;  /* loop counter */
 char   caTmpBuffer[20];
 int    iNextDayCnt; 

  iYear=(pstPara->caStartDate[0]-'0')*1000+(pstPara->caStartDate[1]-'0')*100+
        (pstPara->caStartDate[2]-'0')*10+(pstPara->caStartDate[3]-'0');
  iDate=(pstPara->caStartDate[4]-'0')*1000+(pstPara->caStartDate[5]-'0')*100+
        (pstPara->caStartDate[6]-'0')*10+(pstPara->caStartDate[7]-'0');
  memcpy(caBrCode,pstPara->caBrCode,10);
  caBrCode[10]='\0';
  if ( (i=ChkDate(GETDATECNT, iYear, &iDate, &iDayCnt)) != 0 ) {
     pstPara->cReturn='2';
     return(-1);
  }
  iRc=iCalFileIo('R', caBrCode, &stCalData);
  switch(iRc) {
     case  0 :break;
     case -1 :pstPara->cReturn='4'; /*file open error */
              return(-1);
     case -2 :pstPara->cReturn='1'; /*branch calendar information not found */
              return(-1);
     case -3 :pstPara->cReturn='5'; /*file operation error */
              return(-1);
     case -4 :pstPara->cReturn='6'; /*other error*/
              return(-1);
     default :pstPara->cReturn='6'; /*other error*/
              return(-1);
  }
  ChkDate(GETDATECNT, iYear, &iDate, &iDayCnt);
  if ( (iDayCnt > 335) && (iYear == (stCalData.iYear+MAXNOYEAR-1)) ) {
    pstPara->cReturn='7'; /* txn date is about to out of range */  
  }
  else {
    pstPara->cReturn='0'; /* set the return code to normal first */  
  }
  iYear=iYear-stCalData.iYear;
  if ( (iYear<0) || (iYear >= MAXNOYEAR) ) {
     pstPara->cReturn='3';    /* out of calendar file's range */
     return(-1);
  }
  pstPara->cIsBusDate = stCalData.caDate[iYear][iDayCnt-1];
  if (stCalData.caDate[iYear][iDayCnt-1] == '1'){
    iNextDayCnt = 1;
  }else{
    iNextDayCnt = 0;
  }
  i=iDayCnt+1; /* set i to the nextday count */
  iNDayCnt=iNNDayCnt=-1;
  while ( ((i-1) <= 366) && (iYear < MAXNOYEAR) ) {
    if ( (i-1) == 366 ) {  /* search next year's business day, if any */
       iYear++;
       i=1;      /* reset the day counter to 1 */
       continue;
    }
    if (stCalData.caDate[iYear][(i-1)] == '0') { /* get an operation day */
      if (iNDayCnt == -1) {
        iNDayCnt=i;  /* begin the search next-next operation day */
        if (ChkDate(GETDATE,(iYear+stCalData.iYear),&iDate,&iNDayCnt) != 0) {
           pstPara->cReturn='6';
           return(-1);
        }
        sprintf(caTmpBuffer,"%.4d",iYear+stCalData.iYear);
        memcpy(pstPara->caNextDate,caTmpBuffer,4);
        sprintf(caTmpBuffer,"%.4d",iDate);
        memcpy((pstPara->caNextDate)+4,caTmpBuffer,4);
        sprintf(caTmpBuffer,"%.3d",iNextDayCnt);
        memcpy(pstPara->caNDayCnt,caTmpBuffer,3);
        i++;
      }
      else {
        iNNDayCnt=i;
        if (ChkDate(GETDATE,(iYear+stCalData.iYear),&iDate,&iNNDayCnt) != 0) {
           pstPara->cReturn='6';
           return(-1);
        }
        sprintf(caTmpBuffer,"%.4d",iYear+stCalData.iYear);
        memcpy(pstPara->caNNextDate,caTmpBuffer,4);
        sprintf(caTmpBuffer,"%.4d",iDate);
        memcpy((pstPara->caNNextDate)+4,caTmpBuffer,4);
        break;
      }
    }
    else {
      if (stCalData.caDate[iYear][i-1] == '1'){
        iNextDayCnt++;
      }
      i++;
    } /* for 'if (stCalData.caDate[iYear][(i-1)] == '0') ' */
  } /* for 'while ( ((i-1) < 366) && (iYear < MAXNOYEAR) ) ' */
  if ( iNNDayCnt == -1 ) {
    pstPara->cReturn='3';    /* out of calendar file's range */
    return(-1);
  }
  else {
    return(0);
  }
}
ASDAYIN2(pstPara)
struct parASDAYIN2 *pstPara;
{
 struct calendar stCalData;
 int    iYear;
 int    iDate;
 int    iMoonth, iDay;
 char   caBrCode[15];
 int    iRc;
 int    i;  /* loop counter */


  pstPara->cReturn='0';   /* set the return code to normal first */
  if ( (pstPara->caYear[0] < '0') || (pstPara->caYear[0] > '9') ||
       (pstPara->caYear[1] < '0') || (pstPara->caYear[1] > '9') ||
       (pstPara->caYear[2] < '0') || (pstPara->caYear[2] > '9') ||
       (pstPara->caYear[3] < '0') || (pstPara->caYear[3] > '9') ) {
     pstPara->cReturn='2';
     return(-1);
  }
  iYear=(pstPara->caYear[0]-'0')*1000+(pstPara->caYear[1]-'0')*100+
        (pstPara->caYear[2]-'0')*10+(pstPara->caYear[3]-'0');
  memcpy(caBrCode,pstPara->caBrCode,10);
  for (i=0;i<12;i++) {
    memset(pstPara->caDayInfo[i],'9',31);
  }
  caBrCode[10]='\0';
  iRc=iCalFileIo('R', caBrCode, &stCalData);
  switch(iRc) {
     case  0 :break;
     case -1 :pstPara->cReturn='4'; /*file open error */
              return(-1);
     case -2 :pstPara->cReturn='1'; /*branch calendar information not found */
              return(-1);
     case -3 :pstPara->cReturn='5'; /*file operation error */
              return(-1);
     case -4 :pstPara->cReturn='6'; /*other error*/
              return(-1);
     default :pstPara->cReturn='6'; /*other error*/
              return(-1);
  }
  if ((iYear >= (stCalData.iYear+MAXNOYEAR)) || (iYear < stCalData.iYear)) {
     pstPara->cReturn='3';
     return(-1);
  }
  for (i=1;i<367;i++) {
    if (ChkDate(GETDATE, iYear, &iDate, &i) != 0)  {
      if (i != 366) {
        pstPara->cReturn='6';   /* other error */
        return(-1);
      }
      else {
        break;
      }
    }
    iMoonth=iDate/100;
    iDay=iDate%100;
    pstPara->caDayInfo[iMoonth-1][iDay-1]=
       stCalData.caDate[iYear-stCalData.iYear][i-1];
  }
}

ASDAYUPD(pstPara)
struct parASDAYIN2 *pstPara;
{
 struct calendar stCalData;
 int    iYear;
 int    iDate;
 int    iMoonth, iDay;
 char   caBrCode[15];
 int    iRc;
 int    i,j;  /* loop counter */

  pstPara->cReturn='0'; /*other error*/
  if ( (pstPara->caYear[0] < '0') || (pstPara->caYear[0] > '9') ||
       (pstPara->caYear[1] < '0') || (pstPara->caYear[1] > '9') ||
       (pstPara->caYear[2] < '0') || (pstPara->caYear[2] > '9') ||
       (pstPara->caYear[3] < '0') || (pstPara->caYear[3] > '9') ) {
     pstPara->cReturn='2';
     return(-1);
  }
  iYear=(pstPara->caYear[0]-'0')*1000+(pstPara->caYear[1]-'0')*100+
        (pstPara->caYear[2]-'0')*10+(pstPara->caYear[3]-'0');
  memcpy(caBrCode,pstPara->caBrCode,10);
  for (i=0;i<MAXBRLEN;i++) {
    if ( (pstPara->caBrCode[i]=='\0') || (pstPara->caBrCode[i]==' ') ) {
       stCalData.caBrCode[i]=pstPara->caBrCode[i];
    }
  }
  stCalData.caBrCode[i]='\0';
  iRc=iCalFileIo('R', caBrCode, &stCalData);
  switch(iRc) {
     case  0 :break;
     case -1 :pstPara->cReturn='4'; /*file open error */
              return(-1);
     case -2 :pstPara->cReturn='1'; /*branch calendar information not found */
              return(-1);
     case -3 :pstPara->cReturn='5'; /*file operation error */
              return(-1);
     case -4 :pstPara->cReturn='6'; /*other error*/
              return(-1);
     default :pstPara->cReturn='6'; /*other error*/
              return(-1);
  }
  j=iYear-stCalData.iYear;
  for (i=1;i<367;i++) {
    if (ChkDate(GETDATE, iYear, &iDate, &i) != 0)  {
      if (i != 366) {
        pstPara->cReturn='6';   /* other error */
        return(-1);
      }
      else {
        break;
      }
    }
    iMoonth=iDate/100;
    iDay=iDate%100;
    stCalData.caDate[j][i-1]=
       pstPara->caDayInfo[iMoonth-1][iDay-1];
    if ( (stCalData.caDate[j][i-1]!='0') && (stCalData.caDate[j][i-1]!='1')
                        && (stCalData.caDate[j][i-1]!='9') ) {
        pstPara->cReturn='7';   /* input date status error */
        return(-1);
    }
  } /* for 'for (i=1;i<367;i++)' */
  iRc=iCalFileIo('U', caBrCode, &stCalData);
  switch(iRc) {
     case  0 :return(0);            /*normal return */
     case -1 :pstPara->cReturn='4'; /*file open error */
              return(-1);
     case -2 :pstPara->cReturn='1'; /*branch calendar information not found */
              return(-1);
     case -3 :pstPara->cReturn='5'; /*file operation error */
              return(-1);
     case -4 :pstPara->cReturn='6'; /*other error*/
              return(-1);
     default :pstPara->cReturn='6'; /*other error*/
              return(-1);
  }
}
ASDAYIN1(pstPara)
struct parASDAYIN1 *pstPara;
{
  struct parASDAYIN3 stPara3;

  memcpy(&stPara3,pstPara,sizeof(struct parASDAYIN1));
  ASDAYIN3(&stPara3);
  memcpy(pstPara,&stPara3,sizeof(struct parASDAYIN1));
}
