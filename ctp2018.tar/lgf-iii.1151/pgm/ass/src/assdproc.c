#include <stdio.h>
#include <string.h> 
#include <sys/types.h>
#include "asscal.h" 
#define  TMPDIR   "/tmp"
#define  TMPPRE   "XyZ"

/*************************************************************************/
/* get the branch code from the BIT file                                 */
/* return code: -1 ->                                                    */
/* return code: -2 ->                                                    */
/*************************************************************************/
iGetBrCode(paBitFile,piBrCount,caBitBrCode)
char *paBitFile,caBitBrCode[MAXBRNO][MAXBRLEN+1];
int  *piBrCount;
{
  char caTmpBuffer[80];
  char caTmpFileName[80];
  FILE *pFd;


  strcpy(caTmpFileName,tempnam(TMPDIR,TMPPRE));
  sprintf(caTmpBuffer,"sort -du < %s > %s",paBitFile,caTmpFileName);
  system(caTmpBuffer);
  if ( (pFd=fopen(caTmpFileName,"r")) == NULL) {
    printf("BIT:%s open error, errno=%d\n",paBitFile,errno);
    return(-1);
  }
  *piBrCount=0;
  while (fscanf(pFd,"%s",caTmpBuffer) != EOF) {
     if ( (caTmpBuffer[0]== 'B') || (caTmpBuffer[0]== 'b') ) {
        /* Add 4 lines for TPEUNIX980505 by Hu Chunlin */
        if(*piBrCount == MAXBRNO){
          printf("Branch numbers defined in bit.dat is out of limit.[%d]\n", MAXBRNO);
          exit(0);
        }
        fscanf(pFd,"%s",caTmpBuffer);
        strcpy(caBitBrCode[*piBrCount],caTmpBuffer);
        (*piBrCount)++;
     }
     else {
        fgets(caTmpBuffer,80,pFd);
     }
  }
  return(0);
}



/*************************************************************************/
/* generate calendar text file of one branch                             */
/* return code: -1 -> holiday file open error                            */
/* return code: -2 -> invalid date in holiday file                       */
/*************************************************************************/
GenCalTxtFile(fd,caBrCode,iYear,iNoOfYear,stHoliday,cSundayFlag,iPrefix)
FILE *fd;                  /* file descriptor of the output file */
char *caBrCode; /* generate the calendar information of the giving brcode */
int  iYear, iNoOfYear;     /* year & number of years to be generated */
struct holiday stHoliday;  /* holiday information */
int  cSundayFlag;          /* '1' -> Sunday is a holiday        */
                           /* '0' -> Sunday is an operation day */
int  iPrefix;
{
 int i,j,k; /* loop counter */
 int  iaMaxDays[13]
        = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31} ;
 int  iMonth, iDay, iWeekDate;
 char cIsHoliday;
 int  iTmpDay;
 int  iHolidayIndex;
 char caOutBuffer[80];
 char caPrefix[20];

 iHolidayIndex=0;
 if (iNoOfYear < 0 ) {
   return(-1) ; /* invalid number of year */
 }
 if (iPrefix == 1) {  /* generate prefix in BRANCH CODE */
    sprintf(caPrefix,"%s",caBrCode);
 }
 else {
    memset(caPrefix,'\0',20);
 }
 if ( iNoOfYear > 1 ) {
    fprintf(fd,"%s* ------------Branch:%s  Year:%d To %d\n", caPrefix,
				caBrCode, iYear, iYear+iNoOfYear-1);
 }
 else {
    fprintf(fd,"%s* ------------Branch:%s  Year:%d\n", caPrefix, caBrCode,
				iYear);
 }
 fprintf(fd,"%sB  %s\n",caPrefix,caBrCode);
 for (i=0; i<iNoOfYear; i++ ) {
   iHolidayIndex=0;
   if (LeapCheck(iYear) == 1) {
     iaMaxDays[2]=29;
   }
   else {
     iaMaxDays[2]=28;
   }
   iWeekDate = FirstWDay(iYear);  /* the week date of the 01/01 in the iYear */
   for (iMonth=1; iMonth <= 12; iMonth++) {
     for (iDay=1; iDay <= iaMaxDays[iMonth]; iDay++) {
       iTmpDay=iMonth*100+iDay;
       cIsHoliday = '0';   /* OPERATION DATE */
       if ( (stHoliday.iaHDate[iHolidayIndex] == 229) &&
            (iTmpDay > 229) ) {     /* 229 means 02/29 */
/*
          printf("iTmpday=%d holi(2/29) is %d\n",iTmpDay,
                  stHoliday.iaHDate[iHolidayIndex]);
*/
          iHolidayIndex++;
       }
       if ( iTmpDay == stHoliday.iaHDate[iHolidayIndex] ) {
          cIsHoliday='1'; /* non-OPERATION DATE : HOLIDAY */
          if (iHolidayIndex < stHoliday.iNoOfHday) {
            iHolidayIndex++;
          }
       }
       else {
          if (iWeekDate == 0 ) {   /* Sunday */
             cIsHoliday=cSundayFlag;
          }
       }
       sprintf(caOutBuffer,"%sD  %.4d%.4d  %c\n",caPrefix, iYear, iTmpDay,
					cIsHoliday);
       fprintf(fd,"%s",caOutBuffer);
       ++iWeekDate;
       iWeekDate%=7;
     } /* for 'for (iDay=1; iDay <= iaMaxDays[iMonth]; iDay++)' */
   } /* for 'for (iMonth=1; iMonth <= 12; iMonth++)' */
   iYear++;
 } /* for 'for (i=0; i<iNoOfYear; i++ )' */
}

/*************************************************************************/
/* Generate calendar BINARY file according to the calendar TEXT file     */
/* return code: -1 -> error                                              */
/*************************************************************************/
CalB2T(paTFile,paBFile,iStartYear,iNoOfYear,iPrefix,pcaDelBrh, iDelCount)
char *paTFile, *paBFile;
int  iStartYear, iNoOfYear;
int  iPrefix;
char pcaDelBrh[MAXBRNO][MAXBRLEN+1];
int iDelCount;
{
 FILE *fpTFile;
 int  ifpBFile;
 struct calBHeader stBinHeader;
 struct calendar stCalData;
 char caInputBuffer[80];
 char cTmp;
 struct calendar stTmpCal;
 char caBrCode[20];
 char caDate[10];
 char caHoliday[10];
 int  iTotalDay;
 int  iYear;
 int  iDate;
 int  i,j,k; /* loop count */
 char caPrefix[20];

 if ( (fpTFile=fopen(paTFile,"w+")) == NULL) {
   printf("TEXT file %s open error, errno=%d\n",paTFile,errno);
   return(-1);
 }
 if ( (ifpBFile=open(paBFile,O_RDONLY,0666)) == -1 ) {
   printf("BINARY file %s open error, errno=%d\n",paBFile,errno);
   return(-2);
 }
 /* read the header information from the calendar binary file */
 if ( read(ifpBFile,&stBinHeader,sizeof(stBinHeader))
      != sizeof(stBinHeader)) {
    printf("read %s header information error, errno=%d !\n",paBFile,errno);
    fclose(fpTFile);
    close(ifpBFile);
    return(-3);
 }
 if (iStartYear == 0) {
   iStartYear=stBinHeader.iStartYear;
 }
 if ( ((iStartYear+iNoOfYear-1)>(stBinHeader.iEndYear)) ||
      (iStartYear < stBinHeader.iStartYear) ) {
   fclose(fpTFile);
   close(ifpBFile);
   return(-4);
 }

 for (i=0; i < stBinHeader.iBrCount; i++) {
/*
   printf("begin to generate text file, brcode=%s\n",stBinHeader.caBrCode[i]);
*/
   if (iDelCount) {
      if (IsDelBranch(stBinHeader.caBrCode[i], pcaDelBrh, iDelCount)) 
		continue;
   }

   if (iPrefix == 1) {  /* generate prefix in BRANCH CODE */
      sprintf(caPrefix,"%s",stBinHeader.caBrCode[i]);
   }
   else {
      memset(caPrefix,'\0',20);
   }
   fprintf(fpTFile,"%s* ------------Branch:%s  Year:%.4d To %.4d\n",caPrefix,
                  stBinHeader.caBrCode[i],iStartYear,iStartYear+iNoOfYear-1);
   fprintf(fpTFile,"%sB  %s\n",caPrefix, stBinHeader.caBrCode[i]);
/*
   printf("after print B-type record\n");
*/
   /* read the calendar information from the calendar binary file */
   if (read(ifpBFile,&stCalData,sizeof(stCalData)) != sizeof(stCalData)) {
      printf("read %s calendar information error, errno=%d !\n",paBFile,errno);
      fclose(fpTFile);
      close(ifpBFile);
      return(-5);
   }
   iYear=stBinHeader.iStartYear;
/*
   printf("iStartYear-stBinHeader.iStartYear=%d;iStartYear+iNoOfYear-1=%d\n",
   (iStartYear-stBinHeader.iStartYear),(iStartYear+iNoOfYear-1));
*/
   for ( j=(iStartYear-stBinHeader.iStartYear); j<=(iStartYear-
				stBinHeader.iStartYear+iNoOfYear-1); j++) {
     for (k=1;k<367;k++) {
       if (ChkDate(GETDATE,iYear+j, &iDate, &k) != 0) {
         if ( k != 366) {
/*
            printf("error date count, k=%d\n",k);
*/
            fclose(fpTFile);
            close(ifpBFile);
            return(-6);
         }
/*
         printf("invalid day count, k=%d\n",k);
*/
       }
       else {
         fprintf(fpTFile,"%sD  %.4d%.4d  %c\n",caPrefix,(iYear+j),iDate,
                 stCalData.caDate[j][k-1]); /* the 1st is in the element-0 */
       }
     }  /* for 'for (k=1;k<367;k++)' */
   } /* for 'for (j=0;j<=(stBinHeader.iEndYear-stBinHeader.iBeginYear);j++)' */
 } /* for 'for (i=0; i < stBinHeader.iBrCount; i++)' */
 fclose(fpTFile);
 close(ifpBFile);
 return(0);
}

/*************************************************************************/
/* Generate calendar TEXT file according to the calendar BINARY file     */
/* return code: -1 -> holiday file open error                            */
/* caDate[MAXNOYEAR][366]; record the business day information,          */
/*                         element-0 represents 01/01's status, and      */
/*                         element-2 represents 01/03's startus.         */
/*                         '0' -> operation day                          */
/*                         '1' -> holiday                                */
/*                         '9' -> invalid date                           */
/*************************************************************************/
CalT2B(paTFile,paBFile,iNoOfYear,iPrefix)
char *paTFile, *paBFile;
int  iNoOfYear;
int  iPrefix;
{
 FILE *fpTFile;
 int  ifpBFile;
 struct calBHeader stBinHeader;
 char caInputBuffer[80];
 char cTmp;
 struct calendar stTmpCal;
 char caBrCode[20];
 char caDate[10];
 char caHoliday[10];
 int  iTotalDay;
 int  iYear;
 int  iDim;
 int  i; /* loop count */
 char caPrefix[30];

 if (iNoOfYear > MAXNOYEAR) {
   return(-1);
 }
 if ( (fpTFile=fopen(paTFile,"r")) == NULL) {
   printf("TEXT file %s open error, errno=%d\n",paTFile,errno);
   return(-2);
 }
 if ( (ifpBFile=open(paBFile,O_CREAT|O_TRUNC|O_RDWR,0666)) == -1 ) {
   printf("BINARY file %s open error, errno=%d\n",paBFile,errno);
   return(-3);
 }
 /* initialize the header of the calendar binary file */
 stBinHeader.iBrCount=0;
 stBinHeader.iStartYear=0;
 for (i=0;i<MAXBRNO;i++) {
  memset(stBinHeader.caBrCode[i],'\0',MAXBRLEN);
 }
 /* write header information into calendar binary file */
 if ( write(ifpBFile,&stBinHeader,sizeof(stBinHeader))
      != sizeof(stBinHeader)) {
    printf("write %s header information error, errno=%d !\n",paBFile,errno);
    fclose(fpTFile);
    close(ifpBFile);
    return(-4);
 }

 iTotalDay=0;
 iYear=0;
 iDim=0;
 while (fscanf(fpTFile,"%s",caPrefix) != EOF) {/* begin to read the TEXT file */
   cTmp=caPrefix[strlen(caPrefix)-1];
   switch (cTmp) {
     case '*':  /* read a comment line */
              fgets(caInputBuffer,80,fpTFile);
              break;
     case 'B':  /* read a BRANCH record type */
              if (iTotalDay !=0) {
                if ( iTotalDay == (365+ LeapCheck(iYear)) ) {
                   if ( write(ifpBFile,&stTmpCal,sizeof(stTmpCal))
                        != sizeof(stTmpCal)) {
                      printf("write %s error errno=%d !\n",paBFile,errno);
                      fclose(fpTFile);
                      close(ifpBFile);
                      printf("invalid RECORD TYPE,should be a D-type record\n");
                      return(-5);
                   }
                }
                else {
                   fclose(fpTFile);
                   close(ifpBFile);
                   printf("invalid RECORD TYPE, should be a D-type record\n");
                   return(-6);
                }
              } /* for 'if (iTotalDay != 0)' */
              memset(stTmpCal.caBrCode,'\0',MAXBRLEN);
              stTmpCal.iYear=0;
              for (i=0; i<iNoOfYear; i++) {
                memset(stTmpCal.caDate[i],'9',366);
              }
              iDim=0;
              iTotalDay=0;
              iYear=0;
              fscanf(fpTFile,"%s \n",caBrCode);
              memcpy(stTmpCal.caBrCode,caBrCode,strlen(caBrCode));
              memcpy(stBinHeader.caBrCode[stBinHeader.iBrCount],
                     caBrCode,strlen(caBrCode));
              stBinHeader.iBrCount++;
              break;
     case 'D':  /* read a DATE record type */
              if (stTmpCal.caBrCode[0] == '\0') {
                   fclose(fpTFile);
                   close(ifpBFile);
                   printf("invalid RECORD TYPE, should be a B-type record\n");
                   return(-7);
              }
              fscanf(fpTFile,"%s %s\n", caDate, caHoliday);
              if (iYear == 0) {
                 stTmpCal.iYear=(caDate[0]-'0')*1000+(caDate[1]-'0')*100+
                                (caDate[2]-'0')*10+(caDate[3]-'0');
                 stBinHeader.iStartYear=iYear=stTmpCal.iYear;
                 stBinHeader.iEndYear=iYear+iNoOfYear-1;
              }
              else {
                 iYear=(caDate[0]-'0')*1000+(caDate[1]-'0')*100+
                       (caDate[2]-'0')*10+(caDate[3]-'0');
              }
              if (iDim != (iYear-stTmpCal.iYear)) {
                 /* change the array's diamention */
/*
       printf("iDim=%d iYear=%d stiYear=%d\n",iDim,iYear,stTmpCal.iYear);
       printf("iTotalDay=%d\n",iTotalDay);
*/
                 if ( iTotalDay == (365+ LeapCheck(stTmpCal.iYear+iDim)) ) {
                   iTotalDay=0;
                   iDim=iYear-stTmpCal.iYear;
                 }
                 else {
/*
                   printf("day count(%d) error !\n",iTotalDay);
*/
                   fclose(fpTFile);
                   close(ifpBFile);
                   return(-8);
                 }
              }
/*
       printf("iDim=%d iYear=%d stiYear=%d\n",iDim,iYear,stTmpCal.iYear);
*/
              if ( iDim < iNoOfYear ) {
                 if ( caHoliday[0] == '0' ) {   /* operation date */
                   stTmpCal.caDate[iDim][iTotalDay]='0';
                 }
                 else {
                   stTmpCal.caDate[iDim][iTotalDay]='1';
                 }
                 iTotalDay++;
              }
              else {
                  /* skip the date out of loading range */
              }
              break;
     default:   /* invalid record type */
              fclose(fpTFile);
              close(ifpBFile);
              printf("invalid RECORD TYPE ! \n");
              return(-9);
   }  /* for 'switch(cTmp)' */
 } /* for 'while (fscanf(fpTFile,"%c",&cTmp) != EOF) {' */
 if ( write(ifpBFile,&stTmpCal,sizeof(stTmpCal)) != sizeof(stTmpCal)) {
    printf("write %s error errno=%d !\n",paBFile,errno);
    fclose(fpTFile);
    close(ifpBFile);
    printf("invalid RECORD TYPE,should be a D-type record\n");
    return(-10);
 }
 lseek(ifpBFile, 0, SEEK_SET);  /* set the file pointer to the beginning */
 /* write header information into calendar binary file */
 if ( write(ifpBFile,&stBinHeader,sizeof(stBinHeader))
      != sizeof(stBinHeader)) {
    printf("write %s header information error, errno=%d !\n",paBFile,errno);
    fclose(fpTFile);
    close(ifpBFile);
    return(-11);
 }
/*
 printf("iStartYear=%d\n",stBinHeader.iStartYear);
*/
 fclose(fpTFile);
 close(ifpBFile);
 return(0);
}

/*************************************************************************/
/* prepare holiday information according to the holiday file             */
/* return code: -1 -> holiday file open error                            */
/* return code: -2 -> invalid date in holiday file                       */
/*************************************************************************/
PreHoliday(hfile,pstHoliday)
char *hfile;
struct holiday *pstHoliday;
{
 FILE *fp;
 int  TmpDate;
 int  iDummy;

 pstHoliday->iNoOfHday = 0;
 if ( (fp=fopen(hfile,"r")) == NULL) {
   printf("Holiday file %s open error, errno=%d\n",hfile,errno);
   return(-1);
 }
 while (fscanf(fp,"%d",&TmpDate) != EOF) {  /* begin to read the holiday file */
 /*
   printf("prepare holiday ,  TmpDate=%d\n",TmpDate);
*/
   if ( ChkDate(GETDATECNT, 0, &TmpDate, &iDummy) != 0 ) {
/*
     printf("invalid date:%.4d in holiday file %s\n",TmpDate,hfile);
*/
     fclose(fp);
     return(-2);
   }
   pstHoliday->iaHDate[pstHoliday->iNoOfHday]=TmpDate;
   pstHoliday->iNoOfHday++;
 }
 fclose(fp);
 return(0);
}


IsDelBranch(caBrh, caDelBrh, DelCount)
char *caBrh, caDelBrh[MAXBRNO][MAXBRLEN+1];
int DelCount;
{
  int i;

  for (i=0; i<DelCount; i++) {
     if (strcmp(caBrh, caDelBrh[i]) == 0) return 1; 
  }
  return 0;
}
