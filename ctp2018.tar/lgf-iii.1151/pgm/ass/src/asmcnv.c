#include "./asscal.h"
#define  TMPDIR   "/tmp"
#define  TMPPRE   "XyZ"
main(argc,argv)
int argc;
char *argv[];
{
  char caFileName1[80],caFileName2[80];
  int  iRc;

  if (argc < 2) {
	 printf("Usage:asxcnv.x [B2T|T2B] [Binary-F-Name] [TEXT-F-Name]\n");
	 exit(1);
  }
  else {
    if (argc == 2) {
		sprintf(caFileName1,"%s/iii/etc/tbl/calendar.bin",
                        getenv("III_DIR"));
		sprintf(caFileName2,"%s/iii/etc/tbl/calendar.dat",
                        getenv("III_DIR"));
    }
    else {
      if (argc != 4) {
         printf("invalid number of arguments !\n");
         exit(-1);
      }
      else {
         strcpy(caFileName1,argv[2]);
         strcpy(caFileName2,argv[3]);
      }
    }
  }
  if ( strcmp(argv[1],"B2T") == 0 ) {
     if ( (iRc=CalB2T(caFileName2,caFileName1,0,MAXNOYEAR,0, (char**)NULL,0)) != 0 ) {
        printf("conversion error, iRc=%d\n",iRc);
        exit(-1);
     }
     else {
        printf("conversion successful !\n");
        printf("FROM BINARY FILE:%s\n",caFileName1);
        printf("TO TEXT FILE:%s\n",caFileName2);
	exit(0);
     }
  }
  if ( strcmp(argv[1],"T2B") == 0 ) {
     if ( (iRc=CalT2B(caFileName2,caFileName1,MAXNOYEAR,0)) != 0 ) {
        printf("conversion error, iRc=%d\n",iRc);
        exit(-1);
     }
     else {
        printf("conversion successful ! \n");
        printf("FROM TEXT FILE:%s\n",caFileName2);
        printf("TO BINARY FILE:%s\n",caFileName1);
	exit(0);
     }
  }
  printf("Invalid operation, not B2T nor T2B\n");
  exit(-1);
}
