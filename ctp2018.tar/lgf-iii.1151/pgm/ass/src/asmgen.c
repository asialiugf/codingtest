#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include "./asscal.h"
#define  TMPDIR   "/tmp"
#define  TMPPRE   "XyZ"
main(argc,argv)
int argc;
char *argv[];
{
 char caHFile[80];
 char caCalFile[80];
 char caBitFile[80];
 char caTmpFileT[20];    /* temporary file name for TEXT calendar file */
 char caTmpFileT1[20];   /* temporary file name for TEXT calendar file */
 char caTmpFileB[20];    /* temporary file name for BINARY calendar file */
 char caShellBuff[256];   /* shell command buffer */
 char caBitBrCode[MAXBRNO][MAXBRLEN+1];  /* to keep the br-code int the BIT */
 int  iBitBrCount;       /* record the number of the branch in the BIT */
 char caDelBrCode[MAXBRNO][MAXBRLEN+1];  /* keep the deleted Brcode */
 int  iDelBrCount;                       /* keep the # of the deleted BrCode */
 struct calBHeader stBinHeader;
 int  iTmpFd;
 int  ifpBFile;
 char cNewCreate;
 FILE *pFd;
 struct holiday a;
 int  i,j;
 int  iRc;
 char cFound;
 int  iYear;
 char cSameYear;
 char cYear1, cYear2, cYear3, cYear4;

 if ( argc < 3 ) {
   Usage();
   exit(-1);
 } else if ( (argc < 4) && (strcmp(argv[1], "IY")==0) ) {
   printf("No YEAR argument, try again !\n");
   Usage();
   exit(-1);
 }
   
 if ( (strcmp(argv[1], "IY") != 0) && (strcmp(argv[1], "NY") != 0) &&
      (strcmp(argv[1], "CY") != 0) ) {
   printf("Invalid OPERATION argument, try again !\n");
   Usage();
   exit(-1);
 }

 if ( (argv[2][0] != '0') && (argv[2][0] != '1') ) {
   printf("Invalid SUNDAY argument, try again !\n");
   Usage();
   exit(-1);
 }

 iYear = 0;

 if ( argc >= 4 && strcmp(argv[1], "IY")==0 ) {
   cYear1 = argv[3][0] - '0';
   cYear2 = argv[3][1] - '0';
   cYear3 = argv[3][2] - '0';
   cYear4 = argv[3][3] - '0';
   iYear = cYear1*1000 + cYear2*100 + cYear3*10 + cYear4;
   if ( cYear1 < 0 || cYear1 > 9 || cYear2 < 0 || cYear2 > 9 ||
        cYear3 < 0 || cYear3 > 9 || cYear4 < 0 || cYear4 > 9 ||
        iYear <= 0 ) {
     printf("Invalid YEAR argument, try again !\n");
     Usage();
     exit(-1);
   }
 }

 /* prepare relative data input files */
 sprintf(caHFile,"%s/iii/etc/tbl/holiday.dat",getenv("III_DIR"));
 sprintf(caCalFile,"%s/iii/etc/tbl/calendar.bin",getenv("III_DIR"));
 sprintf(caBitFile,"%s/iii/etc/tbl/bit.dat",getenv("III_DIR"));
 strcpy(caTmpFileT,tempnam(TMPDIR,TMPPRE));
 strcpy(caTmpFileT1,tempnam(TMPDIR,TMPPRE));
 strcpy(caTmpFileB,tempnam(TMPDIR,TMPPRE));
 for (i=0;i<MAXBRNO;i++) {
    memset(caBitBrCode[i],'\0',MAXBRLEN+1);
    memset(caDelBrCode[i],'\0',MAXBRLEN+1);
 }
 iDelBrCount=iBitBrCount=0;
 cNewCreate='N';
 /* check if BIT is existed or not */
 if ( (pFd=fopen(caBitFile,"r")) == NULL) {
   printf("BIT:%s open error, errno=%d\n",caBitFile,errno);
   return(-1);
 }
 else {
   fclose(pFd);
 }

 /* check if the files are existed or not */
 if ( (iTmpFd=open(caCalFile,O_RDONLY,0666)) == -1 ) {
   if ( errno==ENOENT ) {
      if (strcmp(argv[1],"IY") != 0) {
         printf("Calendar file %s not found, can't perform CY or NY !\n",
                caCalFile);
         exit(-1);
      }
      printf("Calendar file %s does not exist, create it ?(Y/N)",caCalFile);
      scanf("%c",&cNewCreate);
      if ( (cNewCreate != 'Y') && (cNewCreate !='y') ) {
         printf("Abort generating calendar data !\n");
         exit(-1);
      }
      else {
         stBinHeader.iBrCount = 0;
         cSameYear='Y';
      }		 
   }
   else {
      printf("Calendar file %s open fail, errno=%d\n",caCalFile,errno);
      return(-1);
   }
 }
 else {
   if ( read(iTmpFd,&stBinHeader,sizeof(stBinHeader))
        != sizeof(stBinHeader)) {
     printf("read %s header information error, errno=%d !\n",caTmpFileB,errno);
     close(iTmpFd);
     return(-1);
   }
   close(iTmpFd);

   printf("Current calendar data is from year %d to %d.\n",
         stBinHeader.iStartYear,stBinHeader.iEndYear);

   if (strcmp(argv[1],"CY") == 0) {
     printf("New     calendar data will be changed for %d to %d.\n",
         stBinHeader.iStartYear,stBinHeader.iEndYear);
     iYear=stBinHeader.iStartYear;
   }
   else {
     if (strcmp(argv[1],"NY") == 0) {
        printf("New     calendar data will be generated for %d to %d.\n",
              stBinHeader.iStartYear+1, stBinHeader.iEndYear+1);
        iYear=stBinHeader.iEndYear+1;
     }
     else {
        printf("Calendar file already exists, should not be initialized.\n");
        exit(-1);
     }
   }
/*
   if (iYear != stBinHeader.iStartYear) {
     if (strcmp(argv[1],"CY") ==0) {
		 iYear=stBinHeader.iStartYear;
     }
     else {
       if (strcmp(argv[1],"NY") == 0) {
          iYear=stBinHeader.iEndYear+1;
       }
       else {
         printf("the current calendar information is from %d to %d\n",
         stBinHeader.iStartYear,stBinHeader.iEndYear);
         printf("invalid argument ! %s\n", argv[1]);
         exit(-1);
       }
     }
   }
*/
   if ( iYear == stBinHeader.iStartYear ) {
     cSameYear='Y';
   }
   else {
     cSameYear='N';
   }
   /* copy calendar BINARY file to a temporary file */
   sprintf(caShellBuff,"cp %s %s",caCalFile,caTmpFileB);
   system(caShellBuff);
 }
 /* get the # of branches and their br-code from the BIT */
 if ( iGetBrCode(caBitFile,&iBitBrCount,caBitBrCode) != 0 ) {
   printf("BIT:%s not found or syntax error in BIT, Please check !\n");
   exit(0);
 }
 for (i=0; i < stBinHeader.iBrCount; i++) {
   cFound='N';
   for (j=0;j<iBitBrCount;j++) {
      if ( strncmp(stBinHeader.caBrCode[i],caBitBrCode[j],
           strlen(stBinHeader.caBrCode[i])) == 0 ) {
/*
         printf("BR:%s existed !\n",stBinHeader.caBrCode[i]);
*/
         memset(caBitBrCode[j],'\0',MAXBRLEN+1); /* need not generate again */
         cFound='Y';
         break;
      }
   }
   if ( cFound=='N' ) {
      printf("==> BRANCH %s is deleted !\n",stBinHeader.caBrCode[i]);
      strcpy(caDelBrCode[iDelBrCount],stBinHeader.caBrCode[i]);
      iDelBrCount++;
   }
 }
 if ( (i=PreHoliday(caHFile,&a)) != 0 ) {
   printf("generate holiday information error, rc=%d\n",i);
   exit(0);
 }
 if ( (pFd=fopen(caTmpFileT,"w+")) == NULL) {
   printf("tmp calendar file:%s open error, errno=%d\n",caTmpFileT,errno);
   return(-1);
 }
 /* generate the calendar information belong to the branch which is new */
 /* added to the BIT and has no calendar information in the current     */
 /* calendar file                                                       */
 for (i=0;i<iBitBrCount;i++) {
   if ( caBitBrCode[i][0] != '\0') {
      if (cNewCreate == 'N')
          printf("==> BRANCH %s is inserted !\n",caBitBrCode[i]);
      if ( cSameYear == 'N' ) {
         /* generate the new calendar information for the new branches */
         GenCalTxtFile(pFd,caBitBrCode[i],iYear-MAXNOYEAR,MAXNOYEAR,a,
							  argv[2][0],1);
      }
      else { 
         /* generate the current calendar infor. for the new branches */
         GenCalTxtFile(pFd,caBitBrCode[i],iYear,MAXNOYEAR,a,
							  argv[2][0],1);
      }
   }
 }
 fclose(pFd);

 if ( cNewCreate == 'N' ) {  /* a calendar.bin has been existed */
	 /* convert the current calendar file into a TEXT file */
    if ( cSameYear == 'Y' ) {
      if ( (iRc=CalB2T(caTmpFileT1,caTmpFileB,iYear,MAXNOYEAR,1, 
			caDelBrCode, iDelBrCount)) != 0 ) {
         printf("B2T error iRc=%d !\n",iRc);
         exit(-1);
      }
    }
    else {
      if ( (iRc=CalB2T(caTmpFileT1,caTmpFileB,iYear-MAXNOYEAR,MAXNOYEAR,1, 
			caDelBrCode, iDelBrCount)) != 0 ) {
         printf("B2T error iRc=%d !\n",iRc);
         exit(-1);
      }
    }
	 /* merge the current calendar TEXT file with the new generated one */
    sprintf(caShellBuff,"cat %s >> %s",caTmpFileT,caTmpFileT1);
    system(caShellBuff);
    sprintf(caShellBuff,"sort -du < %s > %s", caTmpFileT1, caTmpFileT);
    system(caShellBuff);
 }
	/* caTmpFileT contains the calendar information which belongs to the */
	/* existing branches and new branched                                */
	/* and the convert the TEXT calendar file into BINARY calendar file  */
 if ( (iRc=CalT2B(caTmpFileT,caTmpFileB,MAXNOYEAR,1)) != 0) {
	 printf("T2B error iRc=%d!!!\n",iRc);
    exit(-1);
 } 
 if ( cSameYear == 'Y' ) {
   if (cNewCreate == 'N') {
       sprintf(caShellBuff,"mv %s %s.BAK", caCalFile, caCalFile);
       system(caShellBuff);
   }
   sprintf(caShellBuff,"mv %s %s", caTmpFileB, caCalFile);
   system(caShellBuff);
   printf("Generate successfully !\n");
	exit(0);
 }
 /* stop here when generate the same year's calendar information          */
 /* --------------------------------------------------------------------- */
 /* begin to move the every year's calendar information to the front one  */ 
 /* EX: calendar file contains 1994, 1995 calendar information, and after */
 /* the following step, the new year's (1996) calendar info. will be      */  
 /* generated and move 1995 to 1994, so the calendar file will contain    */
 /* the calendar information of the 1995 and 1996.                        */

 /* convert the last MAXNOYEAR-1 year's calendar info. into a TEXT FILE   */
 if (CalB2T(caTmpFileT,caTmpFileB,iYear-MAXNOYEAR+1,MAXNOYEAR-1,1,
			(char**) NULL,0) != 0) {
	printf("Binary to Text conversion error !\n");
	return(-1);
 }

 /* generate the newest year's calendar information                       */
 if ( (pFd=fopen(caTmpFileT1,"w+")) == NULL) {
   printf("tmp calendar file:%s open error, errno=%d\n",caTmpFileT,errno);
   return(-1);
 }
 if ( iGetBrCode(caBitFile,&iBitBrCount,caBitBrCode) != 0 ) {
   printf("BIT:%s not found or syntax error in BIT, Please check !\n");
   exit(0);
 }
 for (i=0;i<iBitBrCount;i++) {
   if ( caBitBrCode[i][0] != '\0') {
      GenCalTxtFile(pFd,caBitBrCode[i],iYear,1,a,argv[2][0],1);
   }
 }
 fclose(pFd);

 /* merge the 2 calendar TEXT files into one calendar TEXT file */ 
 sprintf(caShellBuff,"cat %s >> %s",caTmpFileT,caTmpFileT1);
 system(caShellBuff);
 sprintf(caShellBuff,"sort -du < %s > %s", caTmpFileT1, caTmpFileT);
 system(caShellBuff);

 /* convert the TEXT file into Binary file */
 if (CalT2B(caTmpFileT,caTmpFileB,MAXNOYEAR,1) != 0) {
	 printf("T2B error !!!\n");
    exit(-1);
 } 
 sprintf(caShellBuff,"mv %s %s.BAK; mv %s %s", caCalFile, caCalFile,
			caTmpFileB, caCalFile);
 system(caShellBuff);
 printf("Generate successfully !\n");
}

Usage()
{
  printf("\n");
  printf("USAGE:        asxgen.x <OPERATION> <SUNDAY> [<YEAR>]\n");
  printf("<OPERATION>\n");
  printf("     IY:  initialize the calendar data\n");
  printf("     NY:  generate calendar data for next year\n");
  printf("     CY:  change calendar data after modifying bit.dat\n");
  printf("<SUNDAY>\n");
  printf("     0:   SUNDAY is a work day\n");
  printf("     1:   SUNDAY is not a work day\n"); 
  printf("<YEAR>\n");
  printf("     necessary for OPERATION=\'IY\'\n\n");
}
