#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include "ascacia.h"
#include "ascpgdef.h"
#include "errlog.h"

static int sg_iTestMode = -1;
static int sg_iAciaKey = -1;
static int sg_iInitAciaShmTbl = 0;
static struct AciaShmSt AciaShmTbl[MAX_ACIA_SHM_NO];

TPFACIA(char *pcArg0,char *pcArg1,char *pcArg2)
/*  pcArg0 -->  APA
    pcArg1 -->  AciaCtlSt structure
    pcArg2 -->  ACIA DATA  */
{
  int i;
  int iRc;
  int iAciaDataLen;
  int iAciaDataOffset;
  int iAciaKey;
  char caAciaDataLen[11];
  char caAciaDataOffset[11];
  char caAciaKey[11];
  struct AciaCtlSt *pstAciaCtl;

  UCP_TRACE(P_TPFACIA);

  /* Initial Output RETURN-CODE and ERROR-CODE */
  pstAciaCtl = (struct AciaCtlSt *) pcArg1;
  pstAciaCtl->cAciaRtnCode = ACIA_RTN_NORMAL;
  memset(pstAciaCtl->caAciaErrCode, '0', 2);

  if (sg_iTestMode < 0) {
    sg_iTestMode = GetTestMode();
    if (sg_iTestMode < 0) {
      sprintf( g_caMsg,
          "GetTestMode: TPFACIA get Test Mode from config.dat error! iRc=%d",
          sg_iTestMode);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);

      pstAciaCtl->cAciaRtnCode = ACIA_RTN_OTHER_ERR;
      if (sg_iTestMode == INIT_CNFTBL_ERR ) {
        memcpy(pstAciaCtl->caAciaErrCode, ACIA_ERR_INIT_CNFTBL, 2);
      }
      else if (sg_iTestMode == GET_TESTMODE_ERR ) {
        memcpy(pstAciaCtl->caAciaErrCode, ACIA_ERR_GET_TESTMODE, 2);
      }

      UCP_TRACE_END( -1 );
    }

    if (sg_iTestMode == 1) {
      ChgLog(LOG_CHG_MODE,"1");
    }
    else {
      ChgLog(LOG_CHG_MODE,"0");
    }
  }

  ErrLog(100,"<<<assacia>>> enter TPFACIA, dump ACIA-CTL=",
         RPT_TO_LOG,pstAciaCtl,sizeof(struct AciaCtlSt) );


  /* ---------------------------------------------------------------- */
  /*    check if ACIA-FUN-CODE is valid                               */
  /* ---------------------------------------------------------------- */
  if ( pstAciaCtl->cAciaFunCode != ACIA_FUN_CREATE &&
       pstAciaCtl->cAciaFunCode != ACIA_FUN_READ &&
       pstAciaCtl->cAciaFunCode != ACIA_FUN_WRITE &&
       pstAciaCtl->cAciaFunCode != ACIA_FUN_DELETE ) {
    sprintf( g_caMsg,"<<<assacia>>> TPFACIA invalid function code: %c",
             pstAciaCtl->cAciaFunCode );
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstAciaCtl->cAciaRtnCode = ACIA_RTN_FUN_ERR;
    UCP_TRACE_END( -2 );
  }

  /* ---------------------------------------------------------------- */
  /*    check if ACIA-DATA-LEN is valid                               */
  /* ---------------------------------------------------------------- */
  memset( caAciaDataLen, 0, 11);  /* one more character for '\0' */
  memcpy( caAciaDataLen, pstAciaCtl->caAciaDataLen, 10 );
  if (pstAciaCtl->cAciaFunCode == ACIA_FUN_CREATE ||
      pstAciaCtl->cAciaFunCode == ACIA_FUN_READ ||
      pstAciaCtl->cAciaFunCode == ACIA_FUN_WRITE) {
    for ( i=0; i<10; i++ ) {
      if ( !isdigit(caAciaDataLen[i]) ) {
        sprintf( g_caMsg,
                 "<<<assacia>>> TPFACIA argument type error: ACIA-DATA-LEN=");
        ErrLog(1000,g_caMsg,RPT_TO_LOG,caAciaDataLen,10);
        pstAciaCtl->cAciaRtnCode = ACIA_RTN_PAR_ERR;
        memcpy(pstAciaCtl->caAciaErrCode, ACIA_ERR_LEN_TYPE, 2);
        UCP_TRACE_END( -3 );
      }
    }
  }

  /* ---------------------------------------------------------------- */
  /*    check if ACIA-DATA-OFFSET is valid                            */
  /* ---------------------------------------------------------------- */
  memset( caAciaDataOffset, 0, 11);  /* one more character for '\0' */
  memcpy( caAciaDataOffset, pstAciaCtl->caAciaDataOffset, 10 );
  if (pstAciaCtl->cAciaFunCode == ACIA_FUN_READ ||
      pstAciaCtl->cAciaFunCode == ACIA_FUN_WRITE) {
    for ( i=0; i<10; i++ ) {
      if ( !isdigit(caAciaDataOffset[i]) ) {
        sprintf( g_caMsg,
               "<<<assacia>>> TPFACIA argument type error: ACIA-DATA-OFFSET=");
        ErrLog(1000,g_caMsg,RPT_TO_LOG,caAciaDataOffset,10);
        pstAciaCtl->cAciaRtnCode = ACIA_RTN_PAR_ERR;
        memcpy(pstAciaCtl->caAciaErrCode, ACIA_ERR_OFFSET_TYPE, 2);
        UCP_TRACE_END( -4 );
      }
    }
  }

  /* ---------------------------------------------------------------- */
  /*    check if ACIA-KEY-VALUE is valid                              */
  /* ---------------------------------------------------------------- */
  memset( caAciaKey, 0, 11);  /* one more character for '\0' */
  memcpy( caAciaKey, pstAciaCtl->caAciaKeyValue, 10 );
  for ( i=0; i<10; i++ ) {
    if ( !isdigit(caAciaKey[i]) ) {
      sprintf( g_caMsg,
               "<<<assacia>>> TPFACIA argument type error: ACIA-KEY-VALUE=");
      ErrLog(1000,g_caMsg,RPT_TO_LOG,caAciaKey,10);
      pstAciaCtl->cAciaRtnCode = ACIA_RTN_PAR_ERR;
      memcpy(pstAciaCtl->caAciaErrCode, ACIA_ERR_KEY_TYPE, 2);
      UCP_TRACE_END( -5 );
    }
  }
  
  iAciaDataLen = atoi(caAciaDataLen);
  iAciaDataOffset = atoi(caAciaDataOffset);
  iAciaKey = atoi(caAciaKey);
  if (iAciaKey == 0) {
    /* get ACIA-KEY-VALUE from $III_DIR/iii/etc/tbl/config.dat */
    if (sg_iAciaKey == -1) {
      sg_iAciaKey = GetAciaKey();
      if (sg_iAciaKey < 0) {
        sprintf( g_caMsg,
          "GetAciaKey: TPFACIA get key from config.dat error! iRc=%d",
          sg_iAciaKey);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);

        pstAciaCtl->cAciaRtnCode = ACIA_RTN_OTHER_ERR;
        memcpy(pstAciaCtl->caAciaErrCode, ACIA_ERR_GET_ACIA_SHM_KEY, 2);

        UCP_TRACE_END( -6 );
      }
    }

    iAciaKey = sg_iAciaKey; 

    sprintf( g_caMsg, "TPFACIA get key from config.dat: ACIA-KEY-VALUE=0x%x",
             iAciaKey);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
  }

  /* Initialize ACIA Shm Table */
  if (sg_iInitAciaShmTbl == 0) {
    InitAciaShmTbl();
    sg_iInitAciaShmTbl = 1;
  }

  switch (pstAciaCtl->cAciaFunCode) {
    case ACIA_FUN_CREATE:
         iRc = CreatAciaShm(iAciaKey, iAciaDataLen);
         if (iRc < 0) {
           if (iRc == ACIA_SHM_EXIST_ERR) {
             pstAciaCtl->cAciaRtnCode = ACIA_RTN_ACIA_EXIST;
           }
           else if (iRc == ACIA_SHM_TBL_EXCEED_ERR) {
             pstAciaCtl->cAciaRtnCode = ACIA_RTN_ACIA_TBL_OVERFLOW;
           }
           else {
             pstAciaCtl->cAciaRtnCode = ACIA_RTN_OTHER_ERR;
           }
           sprintf(g_caMsg,"CreatAciaShm: iAciaKey=0x%x iAciaDataLen=%d",
                   iAciaKey, iAciaDataLen);
           ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
           UCP_TRACE_END( -7 );
         }
         break;
    case ACIA_FUN_READ:
         iRc = AccessAciaShm(ACIA_FUN_READ, iAciaKey, iAciaDataLen,
                            iAciaDataOffset, pcArg2);
         if (iRc < 0) {
           if (iRc == ACIA_SHM_NOT_EXIST_ERR) {
             pstAciaCtl->cAciaRtnCode = ACIA_RTN_ACIA_NOT_EXIST;
             sprintf(g_caMsg, "AccessAciaShm(READ): iAciaKey=0x%x", iAciaKey);
             ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
           }
           else if (iRc == ACIA_SHM_SIZE_ERR) {
             pstAciaCtl->cAciaRtnCode = ACIA_RTN_SIZE_ERR;
             memcpy(pstAciaCtl->caAciaErrCode, ACIA_ERR_OVER_RANGE, 2);
             sprintf(g_caMsg,
       "AccessAciaShm(READ): iAciaKey=0x%x iAciaDataLen=%d iAciaDataOffset=%d",
              iAciaKey, iAciaDataLen, iAciaDataOffset);
             ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
           }
           else if (iRc == ACIA_SHM_TBL_EXCEED_ERR) {
             pstAciaCtl->cAciaRtnCode = ACIA_RTN_ACIA_TBL_OVERFLOW;
           }
           else {
             pstAciaCtl->cAciaRtnCode = ACIA_RTN_OTHER_ERR;
           }
           UCP_TRACE_END( -8 );
         }

         sprintf(g_caMsg, "AccessAciaShm(READ): iDataLen=%d dump ACIA-DATA=",
                 iAciaDataLen);
         ErrLog(100,g_caMsg,RPT_TO_LOG,pcArg2,iAciaDataLen );
         break;
    case ACIA_FUN_WRITE:
         iRc = AccessAciaShm(ACIA_FUN_WRITE, iAciaKey, iAciaDataLen,
                            iAciaDataOffset, pcArg2);
         if (iRc < 0) {
           if (iRc == ACIA_SHM_NOT_EXIST_ERR) {
             pstAciaCtl->cAciaRtnCode = ACIA_RTN_ACIA_NOT_EXIST;
             sprintf(g_caMsg, "AccessAciaShm(WRITE): iAciaKey=0x%x", iAciaKey);
             ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
           }
           else if (iRc == ACIA_SHM_SIZE_ERR) {
             pstAciaCtl->cAciaRtnCode = ACIA_RTN_SIZE_ERR;
             memcpy(pstAciaCtl->caAciaErrCode, ACIA_ERR_OVER_RANGE, 2);
             sprintf(g_caMsg,
       "AccessAciaShm(WRITE): iAciaKey=0x%x, iAciaDataLen=%d, iAciaDataOffset=%d",
              iAciaKey, iAciaDataLen, iAciaDataOffset);
             ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
           }
           else if (iRc == ACIA_SHM_TBL_EXCEED_ERR) {
             pstAciaCtl->cAciaRtnCode = ACIA_RTN_ACIA_TBL_OVERFLOW;
           }
           else {
             pstAciaCtl->cAciaRtnCode = ACIA_RTN_OTHER_ERR;
           }
           UCP_TRACE_END( -9 );
         }

         sprintf(g_caMsg, "AccessAciaShm(WRITE): iDataLen=%d dump ACIA-DATA=",
                 iAciaDataLen);
         ErrLog(100,g_caMsg,RPT_TO_LOG,pcArg2,iAciaDataLen );
         break;
    case ACIA_FUN_DELETE:
         iRc = RemoveAciaShm(iAciaKey);
         if (iRc < 0) {
           if (iRc == ACIA_SHM_NOT_EXIST_ERR) {
             pstAciaCtl->cAciaRtnCode = ACIA_RTN_ACIA_NOT_EXIST;
           }
           else if (iRc == ACIA_SHM_TBL_EXCEED_ERR) {
             pstAciaCtl->cAciaRtnCode = ACIA_RTN_ACIA_TBL_OVERFLOW;
           }
           else {
             pstAciaCtl->cAciaRtnCode = ACIA_RTN_OTHER_ERR;
           }
           sprintf(g_caMsg,"RemoveAciaShm: iAciaKey=0x%x", iAciaKey);
           ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
           UCP_TRACE_END( -10 );
         }
         break;
  } /* end of switch */


  ErrLog(100,"<<<assacia>>> exit TPFACIA, dump ACIA-CTL=",
         RPT_TO_LOG,pstAciaCtl,sizeof(struct AciaCtlSt) );

  UCP_TRACE_END(0);
}

int
CreatAciaShm(key_t iShmKey, int iShmSize)
{
  int i;
  int iRc;
  int iAciaShmId;
  struct shmid_ds stShmCtl;

  /* Search ACIA Shared Memory Table */
  for (i=0; i<MAX_ACIA_SHM_NO; i++) {
    if (AciaShmTbl[i].iShmKey == iShmKey) {
      sprintf(g_caMsg,
        "CreatAciaShm: ACIA shared memory is existing in ACIA Shm Table");
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      return(ACIA_SHM_EXIST_ERR);
    }
    else if (AciaShmTbl[i].iShmKey == -1 ) {
      break;  /* find an available entry */
    }
  }

  if (i == MAX_ACIA_SHM_NO) {
    sprintf(g_caMsg,"CreatAciaShm: ACIA shared memory table is overflow");
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    return(ACIA_SHM_TBL_EXCEED_ERR);
  }

  /* Get ACIA shared memory */
  iAciaShmId = shmget(iShmKey, iShmSize, IPC_CREAT | IPC_EXCL );
  if (iAciaShmId == -1) {
    if (errno == EEXIST) {
      sprintf(g_caMsg,"CreatAciaShm: ACIA shared memory is existing");
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      return(ACIA_SHM_EXIST_ERR);
    }
    sprintf(g_caMsg,"CreatAciaShm: shmget fail errno=%d",errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    return(ACIA_SHMGET_ERR);
  }

  /* Set ACIA access permission */
  stShmCtl.shm_perm.mode = 000660;
  stShmCtl.shm_perm.uid = getuid();
  stShmCtl.shm_perm.gid = getgid();
  iRc = shmctl(iAciaShmId, IPC_SET, &stShmCtl);
  if (iRc == -1) {
    sprintf(g_caMsg,"CreatAciaShm: shmctl fail errno=%d",errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    return(ACIA_SHMCTL_ERR);
  } 

  /* Save ACIA Shm's key, size and id to ACIA Shm Table */
  AciaShmTbl[i].iShmKey = iShmKey;
  AciaShmTbl[i].iShmSize = iShmSize;
  AciaShmTbl[i].iShmId = iAciaShmId;

  return(0);
}

int
RemoveAciaShm(key_t iShmKey)
{
  int i;
  int iRc;
  int iAciaShmId;
  struct shmid_ds stShmCtl;
  int iFound;

  /* Search ACIA Shared Memory Table */
  for (i=0; i<MAX_ACIA_SHM_NO; i++) {
    if (AciaShmTbl[i].iShmKey == iShmKey) {
      iFound = 1; /* find an existing entry */
      iAciaShmId = AciaShmTbl[i].iShmId;
      break;
    }
    else if (AciaShmTbl[i].iShmKey == -1 ) {
      iFound = 0;
      break;  /* find an available entry */
    }
  }

  if (i == MAX_ACIA_SHM_NO) {
    sprintf(g_caMsg,"RemoveAciaShm: ACIA shared memory table is overflow");
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    return(ACIA_SHM_TBL_EXCEED_ERR);
  }

  if (! iFound) {
    /* Get ACIA shared memory */
    iAciaShmId = shmget(iShmKey, 0, 0 );
    if (iAciaShmId == -1) {
      if (errno == ENOENT) {
        sprintf(g_caMsg,"RemoveAciaShm: ACIA shared memory doesn't exist");
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        return(ACIA_SHM_NOT_EXIST_ERR);
      }
      sprintf(g_caMsg,"RemoveAciaShm: shmget fail errno=%d",errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      return(ACIA_SHMGET_ERR);
    }
  }

  iRc = shmctl(iAciaShmId, IPC_RMID, &stShmCtl);
  if (iRc == -1) {
    sprintf(g_caMsg,"RemoveAciaShm: shmctl fail errno=%d",errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    return(ACIA_SHMCTL_ERR);
  }

  /* Delete the entry found in ACIA Shm Table and shift the following entries */
  if (iFound) {
    while ((AciaShmTbl[i].iShmKey != -1) && i < (MAX_ACIA_SHM_NO - 1)) {
      memcpy(&AciaShmTbl[i], &AciaShmTbl[i+1], sizeof(struct AciaShmSt));
      i++;
    }

    if ((i == MAX_ACIA_SHM_NO - 1) && (AciaShmTbl[i].iShmKey != -1)) {
      AciaShmTbl[i].iShmKey = -1;
      AciaShmTbl[i].iShmId = -1;
      AciaShmTbl[i].iShmSize = -1;
      AciaShmTbl[i].pcShm = NULL;
    }
  }
  
  return(0);
}

int
AccessAciaShm(cFun, iShmKey, iDataLen, iDataOffset, pcData)
char cFun;
key_t iShmKey;
int iDataLen;
int iDataOffset;
char *pcData;
{
  int i;
  int iRc;
  int iAciaShmId;
  char *pcAciaShm;
  struct shmid_ds stShmCtl;
  int iFound;

  /* Search ACIA Shared Memory Table */
  for (i=0; i<MAX_ACIA_SHM_NO; i++) {
    if (AciaShmTbl[i].iShmKey == iShmKey) {
      iFound = 1; /* find an existing entry */
      break;
    }
    else if (AciaShmTbl[i].iShmKey == -1 ) {
      iFound = 0;
      break;  /* find an available entry */
    }
  }

  if (i == MAX_ACIA_SHM_NO) {
    sprintf(g_caMsg,"AccessAciaShm: ACIA shared memory table is overflow");
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    return(ACIA_SHM_TBL_EXCEED_ERR);
  }

  if (! iFound) {
    /* Get ACIA shared memory */
    iAciaShmId = shmget(iShmKey, 0, 0 );
    if (iAciaShmId == -1) {
      if (errno == ENOENT) {
        sprintf(g_caMsg,"AccessAciaShm: ACIA shared memory doesn't exist");
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        return(ACIA_SHM_NOT_EXIST_ERR);
      }
      else if (errno != EEXIST) {
        sprintf(g_caMsg,"AccessAciaShm: shmget fail errno=%d",errno);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        return(ACIA_SHMGET_ERR);
      }
    }

    /* To get the shared memory size: stShmCtl.shm_segsz */
    iRc = shmctl(iAciaShmId, IPC_STAT, &stShmCtl);
    if (iRc == -1) {
      sprintf(g_caMsg,"AccessAciaShm(not found): shmctl fail errno=%d",errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      return(ACIA_SHMCTL_ERR);
    }

    if ((iDataLen + iDataOffset) > stShmCtl.shm_segsz) {
      sprintf(g_caMsg,
         "AccessAciaShm(not found): exceeds ACIA shared memory size");
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      return(ACIA_SHM_SIZE_ERR);
    }

    pcAciaShm = (char *)shmat(iAciaShmId, 0, 0);
    if (pcAciaShm == NULL) {
      sprintf(g_caMsg,"AccessAciaShm(not found): shmat fail errno=%d", errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      return(ACIA_SHMAT_ERR);
    }

    /* Save ACIA Shm's key, size, id and pcShm to ACIA Shm Table */
    AciaShmTbl[i].iShmKey = iShmKey;
    AciaShmTbl[i].iShmSize = stShmCtl.shm_segsz;
    AciaShmTbl[i].iShmId = iAciaShmId;
    AciaShmTbl[i].pcShm = pcAciaShm;
  }
  else { /* if iFound */
    if (AciaShmTbl[i].iShmSize == -1) {
      /* To get the shared memory size: stShmCtl.shm_segsz */
      iRc = shmctl(AciaShmTbl[i].iShmId, IPC_STAT, &stShmCtl);
      if (iRc == -1) {
        sprintf(g_caMsg,"AccessAciaShm(found): shmctl fail errno=%d",errno);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        return(ACIA_SHMCTL_ERR);
      }

      /* Save ACIA Shm's pcShm to ACIA Shm Table */
      AciaShmTbl[i].iShmSize = stShmCtl.shm_segsz;
    }

    if ((iDataLen + iDataOffset) > AciaShmTbl[i].iShmSize) {
      sprintf(g_caMsg,"AccessAciaShm(found): exceeds ACIA shared memory size");
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      return(ACIA_SHM_SIZE_ERR);
    }

    if (AciaShmTbl[i].pcShm == NULL) {
      pcAciaShm = (char *)shmat(AciaShmTbl[i].iShmId, 0, 0);
      if (pcAciaShm == NULL) {
        sprintf(g_caMsg,"AccessAciaShm(found): shmat fail errno=%d", errno);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        return(ACIA_SHMAT_ERR);
      }

      /* Save ACIA Shm's pcShm to ACIA Shm Table */
      AciaShmTbl[i].pcShm = pcAciaShm;
    }
    else {
      pcAciaShm = AciaShmTbl[i].pcShm;
    }
  }

  switch (cFun) {
    case ACIA_FUN_READ:
         memcpy( pcData, pcAciaShm + iDataOffset, iDataLen );
         break;
    case ACIA_FUN_WRITE:
         memcpy( pcAciaShm + iDataOffset, pcData, iDataLen );
         break;
  }

  return(0);
}

int
GetTestMode()
{
  int iRc;
  char caFileName[ 256 ];
  int iTestMode;

  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat((char *)caFileName, (char *)"/");
  strcat((char *)caFileName,  CONFIG_FILE);
  iRc = InitCnfTbl(caFileName);
  if ( iRc < 0 ){
    return( INIT_CNFTBL_ERR );
  }

  iTestMode = GetCnfValue( "TEST_MODE" );
  if (iTestMode < 0){
    ErrLog(1000, "GetCnfValue: TEST_MODE fails!", RPT_TO_LOG, 0, 0);
    return( GET_TESTMODE_ERR );
  }

  return(iTestMode);
}

int
GetAciaKey()
{
  int iAciaKey;

  iAciaKey = GetCnfValue( "ACIA_SHM_KEY" );
  if (iAciaKey < 0){
    ErrLog(1000, "GetCnfValue: ACIA_SHM_KEY fails!", RPT_TO_LOG, 0, 0);
    return( -1 );
  }

  return( iAciaKey );
}

int
InitAciaShmTbl()
{
  int i;

  for (i=0; i<MAX_ACIA_SHM_NO; i++) {
    AciaShmTbl[i].iShmKey = -1;
    AciaShmTbl[i].iShmId = -1;
    AciaShmTbl[i].iShmSize = -1;
    AciaShmTbl[i].pcShm = NULL;
  }
}
