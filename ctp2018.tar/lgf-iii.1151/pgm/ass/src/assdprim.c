#include "./asscal.h"

/*************************************************************************/
/* return code:-1:calendar open error                                    */
/*             -2:branch calendar information not found                  */
/*             -3:calendar file lseek, read, write error                 */
/*             -4:invalid iCalFileIo request                             */
/*************************************************************************/
iCalFileIo(cOperation, pcBrCode, pstCalData)
char cOperation;
char *pcBrCode;
struct calendar  *pstCalData;
{
  int    ifpBFile;
  char   caBFile[256];
  struct calBHeader stBinHeader;
  int    iBrOffset;
  int    i; /* loop counter */

  sprintf(caBFile,"%s/iii/etc/tbl/calendar.bin",getenv("III_DIR"));
  if ( (ifpBFile=open(caBFile,O_RDWR,0666)) == -1 ) {
    printf("BINARY file %s open error, errno=%d\n",caBFile,errno);
    return(-1);
  }
  /* read the header information from the calendar binary file */
  if ( read(ifpBFile,&stBinHeader,sizeof(stBinHeader))
       != sizeof(stBinHeader)) {
     printf("read %s header information error, errno=%d !\n",caBFile,errno);
     close(ifpBFile);
     return(-1);
  }
  iBrOffset=-1;
  for (i=0; i < stBinHeader.iBrCount; i++)  {
    if ( strncmp(pcBrCode, stBinHeader.caBrCode[i],
         strlen(stBinHeader.caBrCode[i])) == 0) {
       iBrOffset=i;
       break;
    }
  }
  if ( iBrOffset == -1 ) {
     close(ifpBFile);
     return(-2);   /* branch code not found */
  }
  if (lseek(ifpBFile,iBrOffset*sizeof(struct calendar),SEEK_CUR) == -1) {
     close(ifpBFile);
     return(-3);   /* file operation error */
  }
  switch(cOperation) {
     case 'R':/* read the calendar information from the calendar binary file */
              if (read(ifpBFile,pstCalData,sizeof(*pstCalData)) !=
                  sizeof(*pstCalData)) {
/*
                  printf("read %s calendar information error, errno=%d !\n",
                         caBFile,errno);
*/
                  close(ifpBFile);
                  return(-3);   /* file operation error */
              }
              else {
                  close(ifpBFile);
                  return(0);
              }
     case 'U':/* update the calendar information */
              if (write(ifpBFile,pstCalData,sizeof(*pstCalData)) !=
                  sizeof(*pstCalData)) {
/*
                  printf("write %s calendar information error, errno=%d !\n",
                         caBFile,errno);
*/
                  close(ifpBFile);
                  return(-3);   /* file operation error */
              }
              else {
                  close(ifpBFile);
                  return(0);
              }
     default :/* invalid command */
              close(ifpBFile);
              return(-4);   /* invalid command request */
  } /* for 'switch(cOperation)' */
  close(ifpBFile);
  return(0);
}

/* --------------------------------------------------------------------- */
/*************************************************************************/
/* return code: -1 -> invalid year                                       */
/* return code: -2 -> invalid month                                      */
/* return code: -3 -> invalid day or day count                           */
/* return code: -4 -> invalid operation                                  */
/* iDateCnt return the date count in the Year                            */
/* if iYear == 0 then do not check leap yaer                             */
/* if cOperation == 'D' -> input date, check it's validation & return    */
/*                         the date count(throuth ipDateCnt) in the year.*/
/* if cOperation == 'C' -> input date count in the year & return the     */
/*                         date (throuth ipDateCnt)                      */
/*************************************************************************/
ChkDate(cOperation, iYear, ipTmpDate, ipDateCnt)
char cOperation;
int iYear, *ipTmpDate, *ipDateCnt;
{
   int  iaMaxDays[14]
        = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31, 0} ;
   int  iMonth, iDay;
   int  i;  /* loop counter */
        int  iTmpDate,iDateCnt;


/*
   printf("year=%d tmpdate=%d\n",iYear,*ipTmpDate);
*/
   iTmpDate=*ipTmpDate;
   iDateCnt=*ipDateCnt;
   if ( (cOperation !=GETDATE) && (cOperation != GETDATECNT) ) {
     return(-4);
   }
   if (iYear < 0) {
     return(-1);
   }
   else {
     if (iYear != 0) {
       if (LeapCheck(iYear) == 1) {
         iaMaxDays[2]=29;
       }
       else {
         iaMaxDays[2]=28;
       }
     }
     else {
       iaMaxDays[2]=29;
     }
   }
   if (cOperation == GETDATECNT) {  /*date vali. check & return date count */
     iMonth=iTmpDate/100;   /* the first 2 digits is month */
     iDay=iTmpDate % 100;   /* the last 2 digits is day */
     if ( (iMonth < 1) || (iMonth > 12) ) {
        return(-2);
     }
     if ( (iDay <= 0) || (iDay > iaMaxDays[iMonth]) ) {
        return(-3);
     }
     iDateCnt=0;
     for (i=1; i<iMonth; i++) {
       iDateCnt+=iaMaxDays[i];
     }
     iDateCnt+=iDay;
     *ipDateCnt=iDateCnt;
   }
   else {  /* return date according to the date count */
     i=1;
     while ( (iDateCnt > iaMaxDays[i]) && (i <= 12) ) {
        iDateCnt-= iaMaxDays[i];
        i++;
     }
     if (iDateCnt > iaMaxDays[i]) {
/*
        printf("invalid date count %d !\n",iDateCnt);
*/
        return(-3);
     }
     else {
        *ipTmpDate=100*i+iDateCnt;
     }
   } /* for 'if (cOperation == GETDATECNT)' */
   return(0);
}
/*************************************************************************/
/* leap year checking                                                    */
/* return code: 0 -> nonleap year, 1-> leap year                         */
/*************************************************************************/
   int  LeapCheck(iYear)
   int  iYear;
   {
        return((iYear < 1800) ? (iYear % 4 == 0) :
               (iYear % 4 == 0 && iYear % 100 != 0 || iYear % 400 == 0)) ;
   }

/*************************************************************************/
/* return the week date of 01/01 of giving year.                         */
/* return code: 0 -> Sunday, 1->Monday, ...                              */
/*************************************************************************/
int FirstWDay(iYear)
int iYear ;
{
   int iLeapCunt ;
   if (iYear < 1800)
       return((iYear+5+(iYear-1)/4)%7) ;
   else {
       iLeapCunt = ((iYear+3+(iYear-1)/4-(iYear-1)/100+(iYear-1)/400)-
                    (1799/4-1799/100+1799/400) - 1800) % 7 ;
       return(iLeapCunt) ;
   }
}
