/* assacia.c */
#define  P_TPFACIA        60101
