/* ------------------------------------------------------ */
/* define constant of TPFACIA(Function & return)          */
/* ------------------------------------------------------ */
#define   ACIA_FUN_CREATE              'C'
#define   ACIA_FUN_READ                'R'
#define   ACIA_FUN_WRITE               'W'
#define   ACIA_FUN_DELETE              'D'

#define   ACIA_RTN_NORMAL              '0'
#define   ACIA_RTN_FUN_ERR             '1'
#define   ACIA_RTN_PAR_ERR             '2'
#define   ACIA_RTN_ACIA_NOT_EXIST      '3'
#define   ACIA_RTN_ACIA_EXIST          '4'
#define   ACIA_RTN_SIZE_ERR            '5'
#define   ACIA_RTN_ACIA_TBL_OVERFLOW   '6'
#define   ACIA_RTN_OTHER_ERR           '9'

#define   ACIA_ERR_LEN_TYPE            "01"
#define   ACIA_ERR_OFFSET_TYPE         "02"
#define   ACIA_ERR_KEY_TYPE            "03"
#define   ACIA_ERR_OVER_RANGE          "04"
#define   ACIA_ERR_INIT_CNFTBL         "05"
#define   ACIA_ERR_GET_TESTMODE        "06"
#define   ACIA_ERR_GET_ACIA_SHM_KEY    "07"

/* ------------------------------------------------------ */
/* define constant of TPFACIA(internal return code)       */
/* ------------------------------------------------------ */
#define ACIA_SHM_EXIST_ERR 		-1
#define ACIA_SHM_NOT_EXIST_ERR		-2
#define ACIA_SHM_SIZE_ERR		-3
#define ACIA_SHMGET_ERR			-4
#define ACIA_SHMCTL_ERR			-5
#define ACIA_SHMAT_ERR			-6
#define ACIA_SHM_TBL_EXCEED_ERR		-7

#define INIT_CNFTBL_ERR			-1
#define GET_TESTMODE_ERR		-2
#define GET_ACIAKEY_ERR			-1

#define  CONFIG_FILE  "iii/etc/tbl/config.dat"
#define  MAX_ACIA_SHM_NO		10

struct AciaCtlSt {
  char cAciaFunCode;
  char caAciaDataLen[10];
  char caAciaDataOffset[10];
  char caAciaKeyValue[10];
  char cAciaRtnCode;
  char caAciaErrCode[2];
};

/* for per entry in ACIA Shm Table */
struct AciaShmSt {
  key_t iShmKey;
  int iShmId;
  int iShmSize;
  char *pcShm;
};
