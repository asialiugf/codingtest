#include <errno.h>
#include <stdio.h>
#include <fcntl.h>
#define MAXBRLEN      10
#define MAXBRNO       1000     /* max. branch no in the calendar binary file */
#define MAXNOYEAR     2
#define GETDATE       'C'
#define GETDATECNT    'D'

struct holiday {
  int  iNoOfHday;              /* number of holiday in a year */
  int  iaHDate[366];           /* record the date of every holiday in a year */
};

struct calendar {
  char caBrCode[MAXBRLEN];     /* calendar information of the Branch Code */
  int  iYear;                  /* starting year */
  char caDate[MAXNOYEAR][366]; /* calendar information of the year */
};

struct calBHeader {      /* the header of the BINARY calendar file */
  int  iBrCount;
  int  iStartYear;
  int  iEndYear;
  char caBrCode[MAXBRNO][MAXBRLEN];
};
struct parASDAYIN1 {
       char  caBrCode[10];     /* branch code                            */
       char  caStartDate[8];   /* startingdate YYYY/MM/DD                */
       char  cReturn;          /* return code                            */
                               /* '0':normal return                      */
                               /* '1':no such branch code                */
                               /* '2':invalid starting date              */
                               /* '3':out of calendar file's range       */
                               /* '4':calendar file not found            */
                               /* '5':calendar file I/O error            */
                               /* '6':other error                        */
                               /* '7':normal return, but the txn date is */
                               /*     about to be out of calendar file's */
                               /*     range in 30 days                   */
       char  caNextDate[8];    /* next txn. date                         */
       char  caNNextDate[8];   /* next-next txn. date                    */
       char  caNDayCnt[3];     /* date count to the next txn. date       */
};
struct parASDAYIN2 {
       char  caBrCode[10];     /* branch code                            */
       char  caYear[4];        /* the year of the calendar infotmation   */
       char  cReturn;          /* return code                            */
                               /* '0':normal return                      */
                               /* '1':no such branch code                */
                               /* '2':invalid year                       */
                               /* '3':out of calendar file's range       */
                               /* '4':calendar file not found            */
                               /* '5':calendar file I/O error            */
                               /* '6':other error                        */
                               /* '7':input date status error             */
       char  caDayInfo[12][31];/* date status in one year                */
                               /* [0][30] -> 01/30 date status           */
                               /*  '0' -> operation date                 */
                               /*  '1' -> holiday                        */
                               /*  '9' -> invalid date                   */
};
struct parASDAYIN3 {
       char  caBrCode[10];     /* branch code                            */
       char  caStartDate[8];   /* startingdate YYYY/MM/DD                */
       char  cReturn;          /* return code                            */
                               /* '0':normal return                      */
                               /* '1':no such branch code                */
                               /* '2':invalid starting date              */
                               /* '3':out of calendar file's range       */
                               /* '4':calendar file not found            */
                               /* '5':calendar file I/O error            */
                               /* '6':other error                        */
                               /* '7':normal return, but the txn date is */
                               /*     about to be out of calendar file's */
                               /*     range in 30 days                   */
       char  caNextDate[8];    /* next txn. date                         */
       char  caNNextDate[8];   /* next-next txn. date                    */
       char  caNDayCnt[3];     /* date count to the next txn. date       */
       char  cIsBusDate;       /* '1':nonbusiness date                   */
                               /* '0':business date                      */
};
