#include <stdio.h>

extern int err_ind;
extern FILE *GetErrFile( void );

void ErrorMsg( line, errmsg, token )
int line;
char *errmsg;
char *token;
{
   FILE *err_file;

   err_file = GetErrFile();

   err_ind = 1;

   if (line == 0 && token == NULL)
   {
      fprintf( err_file, "error: %s\n", errmsg );
   }
   else if (token == NULL)
   {
      fprintf( err_file, "line %d: error: %s\n",
                        line,  errmsg );
   }
   else
   {
      fprintf( err_file, "line %d: error: %s: %s\n",
                        line,  errmsg, token );
   }
}
