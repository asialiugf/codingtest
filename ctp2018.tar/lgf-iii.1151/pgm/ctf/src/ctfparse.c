#include	<stdio.h>
#include	"err_msg.h"

extern FILE *yyin;

FILE *err_file;
FILE *ctf_file;
char *ovalue;
int foption;
int err_ind = 0;

extern void ErrorMsg( int line, char *errmsg, char *token );
extern int scf( char *options, char *optionargs, int *argc, char **argv[] );
extern void yyparse( void );
void usage( char *progname );

main(argc, argv)
int argc;
char *argv[];
{
   int i;
   int hoption, ioption, ooption, eoption;
   char *ivalue;
   char *evalue;

   foption = hoption = ioption = ooption = eoption = 0;

   if (scf( "fioeh", "ieo", &argc, &argv) == 0) {
      usage( argv[0] );
      exit ( 1 );
   }
   else {
      for (i = 1; strcmp(argv[i], "--"); i++) {
         switch (argv[i][1])
         {
            case 'h':
                     hoption = 1;
                     break;
            case 'f':
                     foption = 1;
                     break;
            case 'i':
                     ioption = 1;
                     ivalue = argv[++i];
                     break;
            case 'o':
                     ooption = 1;
                     ovalue = argv[++i];
                     break;
            case 'e':
                     eoption = 1;
                     evalue = argv[++i];
                     break;
         }
      }
   }

   /* set initial value of variable and tables */
   if (ioption == 0 && ooption == 0 && eoption == 0)
   {
       if (hoption == 1)
       {
          usage( argv[0] );
          exit( 0 );
       }
   }

   if (ioption == 0)
   {
      ivalue = "ctf.dat";
   }

   if (ooption == 0)
   {
      ovalue = "ctf.bin";
   }

   if (eoption == 0)
   {
      err_file = stderr;
   }
   else
   {
      if ((err_file = fopen(evalue, "w")) == NULL)
      {
          perror( ERRMSG23 );
          exit(1);
      }
   }

   if ((ctf_file = fopen ( ovalue, "w+b" )) == NULL)
   {
       ErrorMsg( 0, ERRMSG21, NULL );
       exit( err_ind );
   }

   if ((yyin = fopen(ivalue, "r")) == NULL)
   {
       ErrorMsg( 0, ERRMSG0, NULL );
       if (foption == 0)
       {
          remove( ovalue );
       }
       exit( err_ind );
   }

   fprintf(err_file, "** CTF parser begins...\n");

   yyparse();

   fprintf(err_file, "** Parsing is done.\n");

   if (fclose(yyin) == EOF)
   {
      ErrorMsg( 0, ERRMSG1, NULL );
   }

   if (fclose(ctf_file) == EOF)
   {
      ErrorMsg( 0, ERRMSG22, NULL );
   }

   if (foption == 0 && err_ind == 1)
   {
      remove( ovalue );
   }
   exit( err_ind );  /* 0: for normal exit; 1: for abnormal exit */
}

FILE *GetErrFile()
{
  return( err_file );
}

void
usage( progname )
char *progname;
{
   fprintf(stderr, 
         "usage: %s [-f] [-h] [-i input] [-o output] [-e errfile]\n", progname);
   fprintf(stderr, "      -f: force to output when error\n");
   fprintf(stderr, "      -h: usage\n");
   fprintf(stderr, "      -i: input file ( ctf.dat )\n");
   fprintf(stderr, "      -o: output file ( ctf.bin )\n");
   fprintf(stderr, "      -e: error file ( stderr )\n");
}
