/*
 * scf
 *    translate arguments in the Standard Command Format
 *    into a form easily manipulated by C lanhuage programs
 */

#include <stdio.h>
#include <ctype.h>
#include <string.h>

#define   DASH		'-'
#define   OPTEND	"--"
#define   CNULL		(char **)NULL
#define   CSTAR         (char *)
#define   error(f, x)   rc = 0; fprintf(stderr, f, (*argv)[0], x)

static char  **Nargv	=  CNULL;

int
scf(options, optionargs, argc, argv)
char *options, *optionargs, **argv[];
int *argc;
{
   int rc = 1, ai, ci, i;
   unsigned na = 0, nf = 0;
   char c, **nargv = CNULL, **files = CNULL;

   if ((nargv = (char **)malloc( sizeof CSTAR )) == CNULL) {
      error("%s: memory allocation error in scf\n", "");
   } else if (rc == goodargs(options, optionargs, (*argv)[0])) {
      nargv[na ++] = (*argv)[0];
      for (ai = 1; rc == 1 && ai < *argc && strcmp((*argv)[ai], OPTEND); ai++) {
        if ((*argv)[ai][0] == DASH && (*argv)[ai][1]) {
           for (ci = 1; rc == 1 && ci < (int)strlen((*argv)[ai]); ci ++) {
              c = (*argv)[ai][ci];
              if (strchr(options, c) == CSTAR NULL) {
                 error("%s: illegal option %c\n", c);
              }
              else if ((nargv = (char **)realloc( CSTAR nargv,
                                (na + 1) *sizeof CSTAR )) == CNULL) {
                 error("%s: memory allocation error in scf\n", "");
              }
              else if ((nargv[na] = (char *)malloc(3 * sizeof(char))) == CSTAR NULL) {
                 error("%s: memory allocation error in scf\n", "");
              }
              else {
                 nargv[na][0] = DASH;
                 nargv[na][1] = c;
                 nargv[na ++][2] = NULL;
                 if (strchr( optionargs, c ) == CSTAR NULL) {
		    continue;
                 } else if ((nargv = (char **)realloc(CSTAR nargv,
                                     (na + 1) * sizeof CSTAR )) == CNULL) {
                    error("%s: memory allocation error in scf\n", "");
                 } else if ((*argv)[ai][ci + 1] != NULL) {
                    error("%s: option %c not followed by white space\n", c);
                 } else if (ai + 1 < *argc) {
                    nargv[na ++] = (*argv)[++ai];
                    ci = strlen((*argv)[ai]);
                 } else {
                  error("%s: no option argument specified for %c option\n", c);
                 }
              }
           }
        } else if (nf == 0) {
          if ((files = (char **)malloc(sizeof CSTAR)) == CNULL) {
             error("%s: memory allocation error in scf\n", "");
          }        
          else {
           files[ nf ++ ] = (*argv)[ai];
          }        
        } else if ((files = (char **) realloc(CSTAR files,
                                  (nf + 1) * sizeof CSTAR )) == CNULL) {
             error("%s: memory allocation error in scf\n", "");
        } else {
           files[ nf ++ ] = (*argv)[ai];
        }
   }
   if (rc == 1) {
     if (ai < *argc && !strcmp((* argv)[ai], OPTEND)) {
        ai ++;
     }
     if ((nargv = (char **)realloc(CSTAR nargv,
              (na + nf + (*argc - ai) + 2) * sizeof CSTAR )) == CNULL) {
         error("%s: memory allocation error in scf\n", "");
     } else {
        nargv[na ++] = OPTEND;
        for (i = 0; i < nf; i++) {
           nargv[na ++] = files[i];
        }
        for (; ai < *argc; ai ++) {
           nargv[na ++] = (*argv)[ai];
        }
        nargv[na] = CSTAR NULL;
     }
   }
   if (files) {
      free(CSTAR files);
   }
 }
 if (rc == 1) {
    *argv = nargv;
    Nargv = nargv;
    *argc = na;
 } else if (nargv != CNULL) {
    free(CSTAR nargv);
 }
 return(rc);
}

scfend()
{
   if (Nargv != CNULL) {
      free( CSTAR Nargv);
   }
}

static int
goodargs(options, optionargs, name)
char *options, *optionargs, *name;
{
  register char *p;
  register int rc = 1;

  for (p = options; *p; p++) {
    if (!isalpha(*p)) {
       fprintf(stderr,"%s: option specifier %c is not a character\n", name, *p);
       rc = 0;
    }
  }
  for (p = optionargs; *p; p++) {
    if (!strchr(options, *p)) {
      fprintf(stderr,"%s: option argument specifier %c is not a legal option\n",
            name, *p);
      rc = 0;
    }
  }
  return (rc);
}
