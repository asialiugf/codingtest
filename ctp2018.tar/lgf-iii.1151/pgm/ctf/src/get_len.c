#include <stdio.h>

extern void ErrorXtype();

/*-----------------------------------------------------------------*/
/* below is the functions for get input length                     */
/*-----------------------------------------------------------------*/
int ProcessPicPattern(pic_pattern, dat_type, dat_len,
                      ctf_len, ini_value, dot_posit, dtype_area)
char *pic_pattern;
char *dat_type;
int *dat_len;
int *ctf_len;
char *ini_value;
int *dot_posit;
char dtype_area[];
{
   int n, i, j;
   int result;

   switch( pic_pattern[0] )
   {
       case 'X':
          dtype_area[5] = 'x';
          n = x_type(pic_pattern);
          break;
       case '9':
          dtype_area[0] = '9';
          n = nine_type(pic_pattern, dot_posit, dtype_area);
          break;
       case 'S':
          dtype_area[4] = 's';
          dtype_area[0] = '9';

          for(i=0,j=1; pic_pattern[j] != '\0'; i++,j++)
             pic_pattern[i] = pic_pattern[j];

          pic_pattern[i] = '\0';
          n = nine_type(pic_pattern, dot_posit, dtype_area);
          break;
       default:
          return(-1);
   }
   result = cal_len(n, dtype_area, dat_type, dat_len, ctf_len, ini_value);
   return(result);
}

int
x_type(str)
char *str;
{
    int i,j;
    char num[6];

     for(i=0; i<6; i++)
       num[i] = '\0';

    if (str[1] != '(')
    {
       if (str[1] == 'X')
       {
         j = 1;
         while (str[j] != '.' && str[j] != '\0')
            j++;
         return (j);
       }
       else
         return (1);
    }
    else
    {
       for (i=2; str[i] != ')'; i++)
       {
          if (str[i] >= '0' && str[i] <= '9')
             num[i-2] = str[i];
          else
          {
             ErrorXtype();
             return (-1);
          }
       }
       return( atoi(num) );
    }
}

int
nine_type(str, dot_posit, dtype_area)
char *str;
int *dot_posit;
char dtype_area[];
{
   int digit_1, digit_2;
   int ch;
   int i = 0;

   digit_1 = digit_2 = 0;
   *dot_posit = 0;
   digit_1 = scan_9(str, &i);
   ch = str[i-1];
   if ( ch == '(' )
   {
      digit_1 = get_number(str, &i);
      i ++;
      ch = str[i-1];
   }
   if ( ch == 'V' || ch == 'v' )
   {
      dtype_area[1] = 'v';
      digit_2 = scan_9(str, &i);
      ch = str[i-1];
      if ( ch == '(' )
         digit_2 = get_number(str, &i);
      *dot_posit = digit_2;
   }
   return ( digit_1 + digit_2 );
}

int
scan_9(str, idx)
char *str;
int  *idx;
{
   int i = 0;
   char ch;

   while ((ch = str[(*idx)++]) == '9')
      i ++;
   return (i);
}

int
get_number(str, idx)
char *str;
int  *idx;
{
    static char num_string[4];
    int ch;
    int i;
    int j;

    for (j=0; j<4; j++)
        num_string[j] = '\0';
    i = 0;
    if ((ch = str[(*idx)++]) == '.' || ch == '\0')
       return (1);
    else
    {
       if (ch >= '0' && ch <= '9')
       do
       {
          num_string[i++] = ch;
       }
       while ((ch = str[(*idx)++]) != ')');
       return ( atoi(num_string) );
    }
}

/* ----------------------------------- */
/*   convert  character  to  integer   */
/* ----------------------------------- */
int
atoi(s)
char *s;
{
    int  n, i;

    n = 0;
    for(i = 0; *(s+i) != '\0' && *(s+i) != ' ' && *(s+i) != '\n'; i++) 
    {
        n = n * 10 + *(s+i) - '0';
    }
    return(n);
}

/* ----------------------------------------------------------------- */
/*    these functions is for calculate ctf_len and check data type   */
/*-------------------------------------------------------------------*/
int cal_len(len, dtype_area, dat_type, dat_len, ctf_len, ini_value)
int len;
char *dtype_area;
char *dat_type;
int *dat_len;
int *ctf_len;
char *ini_value;
{
   char found, cd;
   int i;
   int g_type();
   int b_type();
   int p_type();

   static struct dtype_st {
           char *d_str;
           char d_code;
           int  (*fun)();
          } dtype_tab[] = {
                     {"     x", 'x', g_type},
                     {"     y", 'y', g_type},
                     {"9     ", '9', g_type},
                     {"9  b  ", 'b', b_type},
                     {"9 p   ", 'p', p_type},
                     {"9   s ", 'i', g_type},
                     {"9  bs ", 'j', b_type},
                     {"9 p s ", 'k', p_type},
                     {"9v    ", 'f', g_type},
                     {"9v b  ", 'g', b_type},
                     {"9vp   ", 'h', p_type},
                     {"9v  s ", 'q', g_type},
                     {"9v bs ", 'r', b_type},
                     {"9vp s ", 't', p_type},
                     {"**    "}
           };

     found = 'n';
     for (i=0; dtype_tab[i].d_str[0] != '*'; i++)
     {
        if (strcmp(dtype_area, dtype_tab[i].d_str) == 0)
        {
           found = 'y';
           cd = dtype_tab[i].d_code;
           switch (cd)
           {
              case 'x':
                *dat_type = 'x';
                *dat_len = len;
                *ctf_len = len;
                break;
              case 'y':
                *dat_type = 'y';
                *dat_len = len;
                *ctf_len = len;
                break;
              case '9':
                *dat_type = '9';
                *dat_len = len;
                *ctf_len = (*dtype_tab[i].fun) (len);
                if(*ini_value == ' ')
                   *ini_value = '0';
                break;
              case 'b':
                *dat_type = 'b';
                *dat_len = len;
                *ctf_len = (*dtype_tab[i].fun) (len);
                if(*ini_value == ' ')
                   *ini_value = '0';
                break;
              case 'p':
                *dat_type = 'p';
                *dat_len = len;
                *ctf_len = (*dtype_tab[i].fun) (len);
                if(*ini_value == ' ')
                   *ini_value = '0';
                break;
              case 'i':
                *dat_type = 'i';
                *dat_len = len + 1;
                *ctf_len = len;
                if(*ini_value == ' ')
                   *ini_value = '0';
                break;
              case 'j':
                *dat_type = 'j';
                *dat_len = len + 1;
                *ctf_len = (*dtype_tab[i].fun) (len);
                if(*ini_value == ' ')
                   *ini_value = '0';
                break;
              case 'k':
                *dat_type = 'k';
                *dat_len = len + 1;
                *ctf_len = (*dtype_tab[i].fun) (len);
                if(*ini_value == ' ')
                   *ini_value = '0';
                break;
              case 'f':
                *dat_type = 'f';
                *dat_len = len + 1;
                *ctf_len = len;
                if(*ini_value == ' ')
                   *ini_value = '0';
                break;
              case 'g':
                *dat_type = 'g';
                *dat_len = len + 1;
                *ctf_len = (*dtype_tab[i].fun) (len);
                if(*ini_value == ' ')
                   *ini_value = '0';
                break;
              case 'h':
                *dat_type = 'h';
                *dat_len = len + 1;
                *ctf_len = (*dtype_tab[i].fun) (len);
                if(*ini_value == ' ')
                   *ini_value = '0';
                break;
              case 'q':
                *dat_type = 'q';
                *dat_len = len + 2;
                *ctf_len = len;
                if(*ini_value == ' ')
                   *ini_value = '0';
                break;
              case 'r':
                *dat_type = 'r';
                *dat_len = len + 2;
                *ctf_len = (*dtype_tab[i].fun) (len);
                if(*ini_value == ' ')
                   *ini_value = '0';
                break;
              case 't':
                *dat_type = 't';
                *dat_len = len + 2;
                *ctf_len = (*dtype_tab[i].fun) (len);
                if(*ini_value == ' ')
                   *ini_value = '0';
                break;
              default:
                *dat_type = 'x';
                *dat_len = len;
                *ctf_len = len;
                break;
          }
       }
   }
   if (found == 'y')
   {
      return( *ctf_len );
   }
   else
      return( -1 );
}

int
g_type(len)
int len;
{
   return(len);
}

int
b_type(len)
int len;
{
   if (len < 5)
     return (2);
   if(len >= 5 && len < 10)
     return (4);
   if(len >= 10)
     return (8);
}

int
p_type(len)
int len;
{
   len = len / 2 + 1;
   return (len);
}
