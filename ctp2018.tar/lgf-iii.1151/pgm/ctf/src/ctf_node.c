#include	<stdio.h>
#include	"ctf_file.h"
#include	"ctf_node.h"
#include	"err_msg.h"
#include	"ucp.h"


extern void ErrorMsg();
extern int ProcessPicPattern();
extern void SetTotalItem();

/* recursively evaluate all ctf nodes */
int LengthOfCtfNode( root )
ctf_node *root;
{
   int ctf_len;
   ctf_node *ptr;

   if ( root->item_type == 'B' || root->item_type == 'D' )
   {
       ctf_len = root->unode.it_node.ctf_len;
   }
   else
   {
       ctf_len = 0;
       ptr = root->child;
       while (ptr != NULL)
       {
          ctf_len += LengthOfCtfNode( ptr );
          ptr = ptr->sibling;
       }
   }

   if (root->item_type == 'A' || root->item_type == 'C')
   {
       root->unode.it_node.ctf_len = ctf_len;
       root->unode.it_node.dat_len = ctf_len;
   }

   if (root->item_type == 'A' || root->item_type == 'B')
   {
       return (0);
   }
   else
   {
       return (ctf_len);
   }
}

void
OffsetOfCtfNode( ptr, bus_head, ctf_offs_cnt )
ctf_node *ptr;
ctf_node *bus_head;
int *ctf_offs_cnt;
{
   switch (ptr->item_type)
   {
      case 'A':
               *ctf_offs_cnt = 
               ptr->unode.it_node.ctf_offs = 
                           OffsetOfRedefinedItem( ptr, bus_head );
               break;
      case 'B':
               ptr->unode.it_node.ctf_offs = 
                           OffsetOfRedefinedItem( ptr, bus_head );
          /*     *ctf_offs_cnt += ptr->unode.it_node.ctf_len; */
               break;
      case 'C':
               ptr->unode.it_node.ctf_offs = *ctf_offs_cnt;
               break;
      case 'D':
               ptr->unode.it_node.ctf_offs = *ctf_offs_cnt;
               *ctf_offs_cnt += ptr->unode.it_node.ctf_len;
               break;
   } 
}

int OffsetOfRedefinedItem( redefine_ptr, bus_head )
ctf_node *redefine_ptr;
ctf_node *bus_head;
{
   ctf_node *ptr;

   ptr = (ctf_node *) FindCtfNode( redefine_ptr, bus_head ); 

   if (ptr == NULL)
   {
      ErrorMsg(redefine_ptr->line, ERRMSG2, redefine_ptr->redefined_item_name);
      return( 0 );
   }

   if (ptr->unode.it_node.ctf_len != redefine_ptr->unode.it_node.ctf_len)
   {
      ErrorMsg(redefine_ptr->line, ERRMSG3, redefine_ptr->redefined_item_name);
   }

/* For showing different level item redefines, Willy Tsui 19960109--Begin */
   if (ptr->level_no != redefine_ptr->level_no)
   {
      ErrorMsg(redefine_ptr->line, ERRMSG26, redefine_ptr->redefined_item_name);
   }
/* For showing different level item redefines, Willy Tsui 19960109--End */

   return (ptr->unode.it_node.ctf_offs);
}

ctf_node *FindCtfNode( redefine_ptr, root )
ctf_node *redefine_ptr;
ctf_node *root;
{
   ctf_node *found = NULL;

   if ( root == NULL)
   {
      found = NULL;
      return( found );
   }
   else if ( redefine_ptr == root)
   {
      found = NULL;
   }
   /* for SunOs , modified by Willy 1995/08/24 */
   else if (root->unode.it_node.ctf_name != NULL && 
            redefine_ptr->redefined_item_name != NULL)
   {
     if (strcmp( root->unode.it_node.ctf_name, 
                 redefine_ptr->redefined_item_name ) == 0)
     {
        found = root;
     }
   }

   if (found == NULL)
       found = FindCtfNode( redefine_ptr, root->child );
   if (found == NULL)
       found = FindCtfNode( redefine_ptr, root->sibling );

   return (found);
}

ctf_node *CreateHeadNode()
{
  ctf_node *ptr;
  int i;

/* For initialize allocated space to be zero, Willy Tsui 19960112 */
  ptr = (ctf_node *)calloc( sizeof( ctf_node ), 1 );
  if (ptr == NULL)
  {
     perror( "CreateHeadNode()" );
     exit( 1 );
  }

  ptr->unode.hd_node.rec_head	= '*';
  ptr->unode.hd_node.busi_type	= 0;
  ptr->unode.hd_node.ctf_size	= 0;
  ptr->unode.hd_node.tot_item	= 0;

/* For initialize filler to be 43 spaces, not only 27 spaces,
                                              Willy Tsui 19960112 */
  for  (i=0; i<43; i++)
      ptr->unode.hd_node.filler[i] = ' ';

  ptr->parent	= NULL;
  ptr->child	= NULL;
  ptr->sibling	= NULL;

  return( ptr );
}

ctf_node *CreateItemNode()
{
  ctf_node *ptr;
  int i;

/* For initialize allocated space to be zero, Willy Tsui 19960112 */
  ptr = (ctf_node *)calloc( sizeof( ctf_node ), 1 );
  if (ptr == NULL)
  {
     perror( "CreateItemNode()" );
     exit( 1 );
  }

/* For initialize ctf_name to be 31 spaces, not only 21 spaces,
                                              Willy Tsui 19960112 */
  for (i = 0; i < 31; i++)
      ptr->unode.it_node.ctf_name[i] = ' ';

  ptr->unode.it_node.dat_type	= ' ';
  ptr->unode.it_node.dat_len	= 0;
  ptr->unode.it_node.ctf_len	= 0;
  ptr->unode.it_node.ctf_offs	= 0;
  ptr->unode.it_node.ctf_relat	= 0;
  ptr->unode.it_node.dot_pos	= 0;
  ptr->unode.it_node.ini_value	= 0;
  ptr->parent			= NULL;
  ptr->child			= NULL;
  ptr->sibling			= NULL;
  ptr->level_no			= 0;
  ptr->line			= 0;

  return( ptr );
}

ctf_node *NewHeadNode( bus_type )
char bus_type;
{
   ctf_node *ptr;

   ptr = (ctf_node *)CreateHeadNode();
   ptr->unode.hd_node.busi_type	= bus_type;
   return( ptr );
}

ctf_node *NewItemNode( item_type, init_value, level_no,
                       item_name, redefined_item_name,
                       pic_pattern, item_seq, lineno, dtype_area )
	char item_type;
	int init_value;
	int level_no;
	char *item_name;
	char *redefined_item_name;
	char *pic_pattern;
	int item_seq;
        int lineno;
        char dtype_area[];
{
   ctf_node *ptr;
   char *ctf_name;
   char *dat_type;
   int *dat_len;
   int *ctf_len;
   int *ctf_relat;
   int *dot_pos;
   char *ini_value;
   int result;

   ptr = (ctf_node *) CreateItemNode();
   /* for ctf_node */
   /* for SunOs , modified by Willy 1995/08/24 */
   if (redefined_item_name != NULL) {
     ptr->redefined_item_name =
           (char *)calloc( strlen(redefined_item_name) + 1, 1);
   }
   else {
     ptr->redefined_item_name = NULL;
   }

   ptr->item_type = item_type;
   ptr->level_no = level_no;
   ptr->line = lineno;
   /* for SunOs , modified by Willy 1995/08/24 */
   if (redefined_item_name != NULL && ptr->redefined_item_name != NULL) {
     strcpy(ptr->redefined_item_name, redefined_item_name);
   }

   /* for ctf_node->unode.it_node */
   ctf_name	= ptr->unode.it_node.ctf_name;
   dat_type	= &(ptr->unode.it_node.dat_type);
   dat_len	= &(ptr->unode.it_node.dat_len);
   ctf_len	= &(ptr->unode.it_node.ctf_len);
   ctf_relat	= &(ptr->unode.it_node.ctf_relat);
   dot_pos	= &(ptr->unode.it_node.dot_pos);
   ini_value	= &(ptr->unode.it_node.ini_value);

   if (strlen( item_name ) + 1 > CTF_NAME_LEN )
   {
      item_name[CTF_NAME_LEN] = '\0';
      ErrorMsg( ptr->line, ERRMSG20, item_name );
   }

   /* for SunOs , modified by Willy 1995/08/24 */
   if (item_name != NULL && ctf_name != NULL) {
     strcpy(ctf_name, item_name);
   }
   *ctf_relat = item_seq;
   *ini_value = init_value;

   switch( item_type )
   {
      case 'A': /* redefine group item */
      case 'C': /* group item */
               *dat_type = 'y';
               break;

      case 'B': /* redefine element item */
      case 'D': /* element item */
               result = ProcessPicPattern( pic_pattern,
                                           dat_type, dat_len,
                                           ctf_len, ini_value,
                                           dot_pos, dtype_area );
               if (result == -1)
               {
		  ErrorMsg( ptr->line, ERRMSG6, NULL );
               }
               else if ( *dat_len > MAX_CTF_LEN )
               {
		  ErrorMsg( ptr->line, ERRMSG19, NULL );
	       }

               break;
   }
   return( ptr );
}

ctf_node *InsertItemNode( crnt_ctf_node, new_ctf_node )
ctf_node *crnt_ctf_node;
ctf_node *new_ctf_node;
{
   int new_level_no;
   int crnt_level_no;
   ctf_node *ptr;

   new_level_no = new_ctf_node->level_no;
   crnt_level_no = crnt_ctf_node->level_no;

   if (new_level_no > crnt_level_no)
   {
      crnt_ctf_node->child = new_ctf_node;
      new_ctf_node->parent = crnt_ctf_node;
   }
   else if (new_level_no == crnt_level_no)
   {
      crnt_ctf_node->sibling = new_ctf_node;
      new_ctf_node->parent = crnt_ctf_node->parent;
   }
   else
   {
      ptr = crnt_ctf_node->parent;
      while (ptr != NULL)
      {
         if (ptr->level_no == new_level_no)
         {
            ptr->sibling = new_ctf_node;
            new_ctf_node->parent = ptr->parent;
            break;   /* exit while loop */
         }
         ptr = ptr->parent;
      }
/* For showing an isolated level no. is detected, Willy Tsui 19960109--Begin */
      if (ptr == NULL) { /* new_ctf_node is an isolated node */
        ErrorMsg( new_ctf_node->line, ERRMSG27, 
                  new_ctf_node->unode.it_node.ctf_name );
        return( crnt_ctf_node );
      }
/* For showing an isolated level no. is detected, Willy Tsui 19960109--End */
   }
   return( new_ctf_node );
}

void PrintABusiness( fp, bus_start_pos, bus_head, ctf_offs_cnt )
FILE *fp;
long bus_start_pos;
ctf_node *bus_head;
int *ctf_offs_cnt;
{
   ctf_node *ptr;

   if (bus_head == NULL)
   {
      return;
   }
   PrintHeadNode(fp, bus_start_pos, bus_head);

   PrintItemTree(fp, bus_head->child, bus_head, ctf_offs_cnt);

   SetTotalLen();
   PrintHeadNode(fp, bus_start_pos, bus_head);
}

void PrintHeadNode( fp, where, bus_head )
FILE *fp;
long where;
ctf_node *bus_head;
{
  fseek( fp, where, SEEK_SET);
  if (fwrite(&(bus_head->unode.hd_node), sizeof(ctf_head), 1, fp) == 0)
  {
     perror( "PrintHeadNode()" );
     exit(1);
  }
}

void
PrintItemTree( fp, root, bus_head, ctf_offs_cnt )
FILE *fp;
ctf_node *root;
ctf_node *bus_head;
int *ctf_offs_cnt;
{
   if (root != NULL)
   {
      OffsetOfCtfNode( root, bus_head, ctf_offs_cnt );
      PrintItemNode( fp, root );
      PrintItemTree( fp, root->child, bus_head, ctf_offs_cnt );
      PrintItemTree( fp, root->sibling, bus_head, ctf_offs_cnt );
   }
}

void
PrintItemNode( fp, item )
FILE *fp;
ctf_node *item;
{
  if (fwrite(&(item->unode.it_node), sizeof(ctf_item), 1, fp) == 0)
  {
     perror( "PrintItemNode()" );
     exit(1);
  }
}

void ReleaseMemory( bus_head )
ctf_node *bus_head;
{
   if (bus_head != NULL)
   {
      ReleaseMemory( bus_head->child );
      ReleaseMemory( bus_head->sibling );
      if (bus_head->redefined_item_name != NULL )
         free( bus_head->redefined_item_name );
      free( bus_head );
      bus_head = NULL;
   }
}

void InitDtype( dtype_area )
char dtype_area[];
{
  int i;

  for (i=0; i<6; i++)
      dtype_area[i] = ' ';

  dtype_area[i] = '\0';
}

