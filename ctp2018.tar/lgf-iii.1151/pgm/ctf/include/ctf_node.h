#ifndef _CTF_NODE_H
#define _CTF_NODE_H

/*ctf_node *NewHeadNode( char bus_type ); */
/*ctf_node *NewItemNode( char item_type, int init_value,
		       int level_no, char *item_name,
	               char *redefined_item_name,
	               char *pic_pattern,
	               int item_seq, int lineno,
                       char dtype_area[] ); */
ctf_node *CreateHeadNode( void );
ctf_node *CreateItemNode( void );
ctf_node *InsertItemNode( ctf_node *crnt_ctf_node, ctf_node *new_ctf_node );
void PrintABusiness( FILE *fp, long bus_start_pos,
                     ctf_node *bus_head, int *ctf_offs_cnt );
void PrintHeadNode( FILE *fp, long where, ctf_node *bus_head );
void PrintItemTree( FILE *fp, ctf_node *root,
                    ctf_node *bus_head, int *ctf_offs_cnt );
void PrintItemNode( FILE *fp, ctf_node *item );
int LengthOfCtfNode( ctf_node *root );
void OffsetOfCtfNode( ctf_node *ptr, ctf_node *bus_head, int *ctf_offs_cnt );
int OffsetOfRedefinedItem( ctf_node *redefine_ptr, ctf_node *bus_head );
ctf_node *FindCtfNode( ctf_node *redefine_ptr, ctf_node *root );
void ReleaseMemory( ctf_node *bus_head );
void InitDtype( char dtype_area[] );

#endif
