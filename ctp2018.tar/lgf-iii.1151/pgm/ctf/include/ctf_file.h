#ifndef _CTF_PARSER_H
#define _CTF_PARSER_H

/* ............ ctf file rec. format description begins here  .......... */

#define		CTF_NAME_LEN	31

struct  ctf_head_def {	 	/* ctf file head rec. format defined	 */
   char rec_head;		/* rec. id(*: ctf_head; other: ctf_item) */
   char busi_type;		/* business type	  		 */
   int  ctf_size;		/* length of the ctf	  		 */
   int  tot_item;		/* total number of items of the business */ 
   char filler[43];		/* space		  		 */
};

typedef struct ctf_head_def ctf_head;
				/* type def of ctf head rec of ctf file  */

struct  ctf_item_def {		/* ctf file data item format defined 	 */
   char ctf_name[CTF_NAME_LEN];	/* ctf item name	 	 	 */
   char dat_type;		/* type of data item	  		 */
   int  dat_len;		/* input item length	   	 	 */
   int  ctf_len;		/* data length in ctf	   		 */
   int  ctf_offs;		/* offset relate to ctf		       	 */
   int  ctf_relat;		/* relative number to ctf table		 */
   int  dot_pos;		/* floating point position from right    */
   char ini_value;		/* initial value for item ( 0 or blank ) */ 
};

typedef struct ctf_item_def ctf_item;
				/* type def of ctf item rec of ctf file  */

struct ctf_st {
   int item_type;
   int line;
   int level_no;
   char *redefined_item_name;
   struct ctf_st *parent;
   struct ctf_st *child;
   struct ctf_st *sibling;
   union {
        ctf_head hd_node;
        ctf_item it_node;
   } unode;
};

typedef struct ctf_st ctf_node;

/* For showing duplicate business type warning,Willy Tsui 19960109 -- Begin */
struct bus_head_node {
  char bus_type;
  struct bus_head_node *next;
};
/* For showing duplicate business type warning,Willy Tsui 19960109 -- End */

#endif
