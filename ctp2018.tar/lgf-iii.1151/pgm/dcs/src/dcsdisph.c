/*     FUNCTION & SUBROUTINE DESCRIPTION
*&N&   
*&N& TYPE     NAME                 DESCRIPTION
*&N& ----- ------------- ----------------------------------------------------
*&N& int   DcsDispatch   �����A�Ȥl�t�Ϊ��D�{��, �����P�q�T��q������
*&N& int   DcsInitAll    �����A�Ȥl�t�� Initial All Protocol Server. &
*&N&                     Attach share memory of table array for each Protocol. &
*&N&                     Initial each table value.
*&N& int   DcsTermAll    �����A�Ȥl�t�� Terminate All Protocol.
*&N&
*/

/* -------------------- INCLUDE FILES DECLARATION ------------------- */
#include <errno.h>
#include "errlog.h"
#include "dcs.h"

#define MAX_PROTO_ARRAY 10
#define MAX_DATA_LEN	256

struct FuncArraySt { 	/* function array data struct */
  char cPotoType;	/* protocol type */
  int (*FuncPtr)();	/* function pointer */
};

/* ------------- dcsqueue.c function ���N�� ------------------------- */
#define P_DcsDispatch	42101
#define P_DcsInitAll	42102
#define P_DcsTermAll	42103
#define P_GetFileData   42104

/* -------------------- STATIC GLOBAL DECLARATION ------------------- */
#ifdef III_TOPEND_DCS
extern int DcsTopend();	/* Topend protocol main function */
#endif
#ifdef III_SOCKET_DCS
extern int DcsSocket();	/* Socket protocol main function */
#endif
#ifdef III_QUEUE_DCS
extern int DcsQueue();	/* Quue protocol main function */
#endif
#ifdef III_APPCLU62_DCS
extern int DcsLu62();	/* APPCLU62 protocol main function */
#endif

static struct FuncArraySt sg_staDcsFun[] = { 
#ifdef III_TOPEND_DCS
                                     'T',DcsTopend,
#endif
#ifdef III_SOCKET_DCS
                                     'S',DcsSocket,
#endif
#ifdef III_QUEUE_DCS
                                     'Q',DcsQueue, 
#endif
#ifdef III_APPCLU62_DCS
                                     'L',DcsLu62, 
#endif
                                   };       

static char sg_caProtoType[MAX_PROTO_ARRAY];	/* keep Protocol type */
static int sg_iMaxProtoType;		/* max Protocol type been keeped*/
static char sg_cFirst = '1';
static int  sg_iMaxFunArray;

/* ------ CALL FUNCTION & SUBROUTINE PROTOTYPE DECLARATIONS --------- */
int DcsDispatch(struct DcsBuf *pstDcsBuf);
int DcsInitAll();
int DcsTermAll();
 
/*
*&N& ROUTINE NAME:int DcsDispatch(struct DcsBuf *pstDcsBuf)
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------  -------------------------
*&A& pstDcsBuf       struct DcsBuf *   ����������Ʀ�}pointer
*&A& 
*&R& RETURN VALUE(S):
*&R&     0 : ���`.
*&R&    -1 : �M��q�T��q���~.
*&R&   iRc : �I�s���P�q�T��q�\���ƿ��~.
*&R&
*&D& DESCRIPTION:
*&D&   1.�M��q�T��q.
*&D&   2.�ˬd�O�_���q�T��q.
*&D&   3.���q�T��q�h, �I�s���P�q�T��q�\����.
*&D&
*/

int
DcsDispatch(struct DcsBuf *pstDcsBuf)
{
  int i;
  int iRc;

  UCP_TRACE(P_DcsDispatch);
  
  if (sg_cFirst == '1'){
    sg_cFirst = '0';
    sg_iMaxFunArray = sizeof(sg_staDcsFun) / sizeof(struct FuncArraySt);
  }

  PiReply(pstDcsBuf) = DCS_NORMAL;
  /* search server array */
  i=0;
  while((PcProto(pstDcsBuf) != sg_staDcsFun[i].cPotoType) &&
        (i < sg_iMaxFunArray)){
    i++;
  } /* end of while((PcProto(pstDcsBuf) != sg_staDcsFun[i].cPotoType) &&
                    (i < sg_iMaxFunArray)) */

  iRc = 0;
  if(i == sg_iMaxFunArray){
    /* protocol type not found */
    sprintf (g_caMsg,
             "<DCS> Failure to find protocol [%c] in protocol table",
             PcProto(pstDcsBuf));
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = DCS_ES_PROTOCOL;
    iRc = DCS_E_COMMAND; 
  }
  else{
    /* function call */
    iRc = (*sg_staDcsFun[i].FuncPtr)(pstDcsBuf);
    if(iRc != DCS_NORMAL){
      sprintf(g_caMsg,
              "<DCS> Function execution error! (reply:%d errno:%d)",
              PiReply(pstDcsBuf), PiErrno(pstDcsBuf));
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    } /* end of if(iRc != DCS_NORMAL) */
  } /* end of if(i == sg_iMaxFunArray) -- else */

  UCP_TRACE_END(iRc);
}

/*
*&N& ROUTINE NAME:int DcsInitAll()
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------  -------------------------
*&A&   �L
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&D& DESCRIPTION:
*&D&
*/

int
DcsInitAll()
{
  int i, iRc;
  struct DcsBuf stDcsBuf;

  UCP_TRACE(P_DcsInitAll);

  if (sg_cFirst == '1'){
    sg_cFirst = '0';
    sg_iMaxFunArray = sizeof(sg_staDcsFun) / sizeof(struct FuncArraySt);
  }

  McRqstCode(stDcsBuf) = DCSINITIAL;

  iRc = 0;
  for(i=0; i < sg_iMaxFunArray; i++){
    McProto(stDcsBuf) = sg_staDcsFun[i].cPotoType;
    iRc = DcsDispatch(&stDcsBuf);
  }

  UCP_TRACE_END(iRc);
}


/*
*&N& ROUTINE NAME:int DcsTermAll()
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------  -------------------------
*&A&   �L
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&D& DESCRIPTION:
*&D&
*/

int
DcsTermAll()
{
  int i, iRc;
  struct DcsBuf stDcsBuf;

  UCP_TRACE(P_DcsTermAll);

  McRqstCode(stDcsBuf) = DCSTERMINATE;

  iRc = 0;
  for(i=0; i < sg_iMaxProtoType; i++){
    McProto(stDcsBuf) = sg_caProtoType[i];
    iRc = DcsDispatch(&stDcsBuf);
  }

  UCP_TRACE_END(iRc);
}


/*
*&N& ROUTINE NAME:int GetFileData()
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------  -------------------------
*&A&   �L
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&D& DESCRIPTION:
*&D&
*/

int
GetFileData(FILE *pfFile, int iDataNo,char caDataType[], long* plDataVar[])
{
  int i;
  long lOffset;
  char caDataBuf[MAX_DATA_LEN];
  char cBypass,cDummy;

  UCP_TRACE(P_GetFileData);

  do {
    if(feof(pfFile)){
      UCP_TRACE_END(-1);
    }

    fgets(caDataBuf,MAX_DATA_LEN,pfFile);
    if (caDataBuf[0] != '#') {
      lOffset = (long) strlen(caDataBuf) * -1;
      fseek(pfFile,lOffset,SEEK_CUR);

      for(i=0; i < iDataNo ; i++){

        fscanf(pfFile,"%c",&cBypass);
        if( cBypass != '*') {

          fseek(pfFile,-1,SEEK_CUR);
          switch(caDataType[i]){
            case 't' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%d\n",(short *) plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%d ",(short *) plDataVar[i]);
              }
              break;
            case 'd' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%d\n",(int *) plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%d ",(int *) plDataVar[i]);
              }
              break;
            case 'D' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%ld\n",(long *) plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%ld ",(long *) plDataVar[i]);
              }
              break;
            case 'o' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%o\n",(int *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%o ",(int *)plDataVar[i]);
              }
              break;
            case 'O' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%lo\n",(long *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%lo ",(long *)plDataVar[i]);
              }
              break;
            case 'x' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%x\n",(int *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%x ",(int *)plDataVar[i]);
              }
              break;
            case 'X' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%lx\n",(long *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%lx ",(long *)plDataVar[i]);
              }
              break;
            case 'i' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%i\n",(int *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%i ",(int *)plDataVar[i]);
              }
              break;
            case 'I' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%li\n",(long *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%li ",(long *)plDataVar[i]);
              }
              break;
            case 's' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%s\n",(char *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%s ",(char *)plDataVar[i]);
              }
              break;
            case 'c' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%c\n",(char *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%c ",(char *)plDataVar[i]);
              }
              break;
            default :
              sprintf(g_caMsg,"GetFileData: data-type=%c error",caDataType[i]);
              ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
              UCP_TRACE_END(-2);
          }  /* end switch */
        }
        else {
          if( (i == iDataNo-1) && (cDummy == '\n') ) {
            fscanf(pfFile,"\n");
            UCP_TRACE_END(0);
          }
          else fscanf(pfFile," ");
        } /* end if '*' */
      }  /* end for */
    }  /* end if  '#' */
  } while(caDataBuf[0] == '#');

  UCP_TRACE_END(0);
}
