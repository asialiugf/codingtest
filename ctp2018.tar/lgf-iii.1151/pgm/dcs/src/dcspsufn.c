/* ***************************************************************** */
/* PROGRAM-NAME         : dcspsufn                                   */
/* PROGRAM-ID           : 63000                                      */
/* ***************************************************************** */
/* Program Abstract     :                                            */
/* ***************************************************************** */
#include        <errno.h>
#include        <fcntl.h>
#include        <stdio.h>
#ifdef CISAM
#include        <isam.h>
#endif
#ifdef UNIFY
$include        "../../dat/UNIFY/file.h"
#endif
#include        "errlog.h"	/* error log include file */
#include        "cwa.h"		/* common working area include file */
#include        "dcs.h"		/* dcs api include file */

#ifdef          FINGER_PASSWORD
#include        "fp_unix.h"          /* for FP-100 driver 821223 */
#endif

/* ***************************************************************** */
/* program id define                                                 */
/* ***************************************************************** */
/* dcspsufn.c */
#define P_ChkInit 		63201
#define P_GetName 		63202
#define P_SignOn 		63203
#define P_DbsOp			63204

/* ***************************************************************** */
/* constant define                                                   */
/* ***************************************************************** */
#define  BRCODE_LEN      3
#define  TMCODE_LEN      2
#define  SK_HEAD_LEN     8
#define  OUT_KIND_1      '1'       /* SOF */
#define  OUT_KIND_2      '2'       /* user authority data */
#define  OUT_KIND_9      '9'       /* error message */
#define  BATCH_MODE      0x0020

/* ******************************************************************** */
/*      structure define for teller file data used by input module      */
/* ******************************************************************** */
struct TellerSt {
   char caTelCode[2];
   char caTelPswd[6];
   char caDetail1[3];
   char cTelOp;
   char caDetail2[114];
};

struct PcTellerSt {	/*& teller structure for C-ISAM file */
  char caBrCode[3];	/*& Branch code       */
  char caTmCode[2];	/*& Terminal code     */
  char caUsrId[2];	/*& User ID           */
  char caPswd[6];	/*& Password          */
  char cAuth;		/*& Authority         */
  char caPswdSetDate[6];/*& password set date */
  char cUsrOp[1];	/*& teller operation indicator */
  char caFiller[141];	/*& teller operation indicator */
};			/*& teller structure  */

/* ***************************************************************** */
/* variable declaration                                              */
/* ***************************************************************** */
extern char g_caBrCode[4];
extern char g_caTmCode[3];
extern int SendSofToClient();

#ifdef OLD_SIGN_ON
/*========================================================================*/
/* suer request function                                                  */
/*========================================================================*/
/* ----------------------------------------------------------------- */
/*      communication    sign     on     process                     */
/* ----------------------------------------------------------------- */
/*   1. Receive user data from client PC.                            */
/*   2. Get system resource includes                                 */
/*     2.1 TCT of SWA.                                               */
/*   3. Get terminal code & branch code of the socket id             */
/*     3.1 TCT of SWA.                                               */
/*   4. According to branch code & user id to check whether the user */
/*      has the right password                                       */
/*      then return the user's profile                               */
/* ***************************************************************** */
SignOn(struct DcsBuf *pstDcsBuf)
{
  int iRc ;
  struct TellerSt stTelData;
  struct PcTellerSt stPcTelData;
  char caTelId[3], caTelPswd[7];
  char caFingrBuf[300];
  char cChkFlg; /* '0':password; '1':finger printe */
  int iSndSkLen;
  struct SSA stCwaSsaBuf;
  struct CwaCtl stCwaCtl;

  UCP_TRACE(P_SignOn);

  /* Read Lock CWA SSA Segment */
  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl, &stCwaSsaBuf);

  if(iRc != CWA_NORMAL){
    sprintf( g_caMsg, "SignOn: CwaLowCtlFac() fails! iRc=%d", iRc );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END(-1);
  }

  /* 1. Receive user data from socket buffer. */
  memcpy(caTelId,PcaData(pstDcsBuf),2);
  caTelId[2]='\0';
  cChkFlg=PcaData(pstDcsBuf)+2;
  switch (cChkFlg){
    case '0':
      memcpy(caTelPswd,PcaData(pstDcsBuf)+3,6);
      caTelPswd[6]='\0';
      break;
    case '1':
      memcpy(caFingrBuf,PcaData(pstDcsBuf)+3,256);
      caFingrBuf[256]='\0';
      break;
    default:
      sprintf(g_caMsg,"SignOn:undefined cChkFlg=0x%2x",cChkFlg);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(-6);
  }


  /* --------------------------------------------------------------- */
  /* 4. According to branch code & user id to check whether the user */
  /*    has the right password                                       */
  /*    then return the user's profile                               */
  /* --------------------------------------------------------------- */
  memcpy(stTelData.caTelCode,caTelId,2);
  memset(stTelData.caTelPswd,'\0',6);
  memset(stTelData.caDetail1,'\0',3);
  memset(stTelData.caDetail2,'\0',114);
  stTelData.cTelOp = '\0';
  sprintf(g_caMsg,"brh=%.3s id=%.2s pwd=%.6s",g_caBrCode,caTelId,caTelPswd);
  ErrLog(10,g_caMsg,RPT_TO_LOG,(char *)&stTelData,12);

  iRc = DbsOp(&stTelData,1);
  if (iRc  == 1) {  /* teller file is empty */
    UCP_TRACE_END(-9);
  }

  if ( iRc  == 0) {
    switch(cChkFlg) {
      case '0':
        if(strncmp(stTelData.caTelPswd,caTelPswd,6) == 0) {
          sprintf(g_caMsg,"SignOn -->after compare user data");
          ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
        }
        else {  /* password not matched */
          ErrLog(100,"caTelPswd=",RPT_TO_LOG,caTelPswd,6);
          ErrLog(100,"tel_file pswd=",RPT_TO_LOG,stTelData.caTelPswd,6);
          UCP_TRACE_END(-3);
        }
        break;
#ifdef FINGER_PASSWORD
      case '1': /* matching the finger print */
        ErrLog(1000,"begin to match the fp",RPT_TO_LOG,0,0);
        ErrLog(1000,"fp code from the teller file",RPT_TO_LOG,
               stTelData.usr_finger,256);
        ErrLog(1000,"fp code from the workstation",RPT_TO_LOG,
               caFingrBuf,256);
        if (recognize((unsigned char *)stTelData.usr_finger,
           (unsigned char *)caFingrBuf,SECURITY_D) == 0) {
          ErrLog(100,"recognize",RPT_TO_LOG,0,0);
        }
        else {  /* password not matched */
          ErrLog(1000,"fp not match",RPT_TO_LOG,0,0);
          UCP_TRACE_END(-3);
        }
        break;
#endif
    }   /* end of switch */
  }  /* for if ( iRc  == 0) */
  else {
    switch (iRc ) {
      case -18:
        UCP_TRACE_END(-18);  /* teller file open error */
      case -1:
        UCP_TRACE_END(-2);   /* teller code not found */
      case 1:
        stTelData.caDetail1[0] = '1';
/*
        memcpy(stPcTelData.caPswdSetDate,swa->txn_date,6);
*/
        memcpy(stPcTelData.caPswdSetDate, &stCwaSsaBuf.caTxnDate[2],6);
        break;
      default:
        UCP_TRACE_END(-19);  /* teller file operation error */
    }  /* for case */
  }  /* for if ( iRc  == 0) */

  memcpy(stPcTelData.caBrCode,g_caBrCode,BRCODE_LEN);
  memcpy(stPcTelData.caTmCode,g_caTmCode,TMCODE_LEN);
  memcpy(stPcTelData.caUsrId,caTelId,2);
  memcpy(stPcTelData.caPswd,caTelPswd,6);

  if (stTelData.caDetail1[0] == 'S') {
    stPcTelData.cAuth = '5';
  }
  else {
    if (stTelData.caDetail1[0] == '1') {
      stPcTelData.cAuth = '1';
    }
    else {
      stPcTelData.cAuth = '6';
    }
  }

  memcpy(stPcTelData.caPswdSetDate,"991231",6);
  stPcTelData.cUsrOp[0] = '0';
/*
  memcpy(stPcTelData.caFiller,swa->txn_date,6);
  memcpy(stPcTelData.caFiller+6,&swa->op_mode,1);
*/
  memcpy(stPcTelData.caFiller, &stCwaSsaBuf.caTxnDate[2], 6);

/*
  if ( stCwaSsaBuf.sSysStatus & BATCH_MODE ){
    stPcTelData.caFiller[6] = '2';
  }else{
    stPcTelData.caFiller[6] = '1';
  }
*/

  iRc = SendSofToClient(sizeof(struct PcTellerSt),&stPcTelData,
                        OUT_KIND_2,'0','0');

  UCP_TRACE_END(iRc);
} /* end of SignOn */
#endif /* end of ifdef OLD_SIGN_ON */


/* ----------------------------------------------------------------- */
/*      communication   check rtn init  process                      */
/* ----------------------------------------------------------------- */
/*   1. Receive check rtn data from client PC.                       */
/*   2. Get system resource includes                                 */
/*     2.1 TCT of SWA.                                               */
/*   3. Get terminal code & branch code of the socket id             */
/*     3.1 TCT of SWA.                                               */
/*   4. According to branch code & user id to check whether the user */
/*      has the right password                                       */
/*      then return the user's profile                               */
/* ***************************************************************** */
ChkInit(pstDcsBuf)
struct DcsBuf *pstDcsBuf;
{
  int iRc ;
  struct TellerSt stTelData;
  char caTelId[3], caTelPswd[7];
  char caFingrBuf[300];
  char cChkFlg; /* '0':password; '1':finger printe */
  char cMatchFlg; /* '0' : Not OK ; '1': OK          */
  int iSndSkLen;

  UCP_TRACE(P_SignOn);

  /* 1. Receive user data from socket buffer. */
  memcpy(caTelId,PcaData(pstDcsBuf),2);
  caTelId[2]='\0';

  cChkFlg=PcaData(pstDcsBuf)+2;
  switch (cChkFlg){
    case '0':
      memcpy(caTelPswd,PcaData(pstDcsBuf)+3,6);
      caTelPswd[6]='\0';
      break;
    case '1':
      memcpy(caFingrBuf,PcaData(pstDcsBuf)+3,256);
      caFingrBuf[256]='\0';
      break;
    default:
      sprintf(g_caMsg,"SignOn:undefined cChkFlg=0x%2x",cChkFlg);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(-6);
  }

  /*   4. According to branch code & user id to check whether the user */
  /*      has the right password                                       */
  /*      then return the user's profile                               */

  sprintf(g_caMsg,"brh=%.3s id=%.2s pwd=%.6s",g_caBrCode,caTelId,caTelPswd);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  memcpy(stTelData.caTelCode,caTelId,2);
  ErrLog(10,g_caMsg,RPT_TO_LOG,(char *)&stTelData,9);

  iRc = DbsOp(&stTelData,1);
  if (iRc  == 1) {  /* teller file is empty */
    UCP_TRACE_END(-9);
  }

  if ( iRc  == 0) {
    switch(cChkFlg) {
      case '0':
        if(memcmp(stTelData.caTelPswd,caTelPswd,6) == 0) {
          sprintf(g_caMsg,"SignOn -->after compare user data");
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          cMatchFlg = '0';
        }
        else {  /* password not matched */
          ErrLog(1000,"set cMatchFlg = 0",RPT_TO_LOG,0,0);
          cMatchFlg = '1';
          ErrLog(1000,"caTelPswd=",RPT_TO_LOG,caTelPswd,4);
          ErrLog(1000,"tel_file pswd=",RPT_TO_LOG,stTelData.caTelPswd,6);
        }
        break;
#ifdef FINGER_PASSWORD
      case '1': /* matching the finger print */
        ErrLog(10,"begin to match the fp",RPT_TO_LOG,0,0);
        ErrLog(10,"fp code from the teller file",RPT_TO_LOG,
                stTelData.usr_finger,256);
        ErrLog(10,"fp code from the workstation",RPT_TO_LOG,
                caFingrBuf,256);
        if (recognize((unsigned char *)stTelData.usr_finger,
                       (unsigned char *)caFingrBuf,SECURITY_D) == 0) {
          ErrLog(100,"recognize",RPT_TO_LOG,0,0);
          cMatchFlg = '0';
        }
        else {  /* finger code not matched */
          cMatchFlg = '1';
          ErrLog(1000,"fp not match",RPT_TO_LOG,0,0);
        }
        break;
#endif
    }   /* end of switch */
  }  /* for if ( iRc  == 0) */
  else {
    switch (iRc ) {
      case -18:
        UCP_TRACE_END(-18);  /* teller file open error */
      case -1:
        UCP_TRACE_END(-2);   /* teller code not found */
      default:
        UCP_TRACE_END(-19);  /* teller file operation error */
    }  /* for case */
  }

  if ((cMatchFlg == '0') && (stTelData.caDetail1[0] == 'S')){
    cMatchFlg = '2';
  }

  iRc = SendSofToClient(0,"\0",OUT_KIND_2,'0',cMatchFlg);

  UCP_TRACE_END(iRc);
}  /* end of SignOn */


#ifdef UNIFY
/* ----------------------------------------------------------------- */
/*      communication   check rtn init  process                      */
/* ----------------------------------------------------------------- */
/*   1. Receive check rtn data  (caAccNo)from client PC.              */
/*   2. Get system resource includes                                 */
/*     2.1 TCT of SWA.                                               */
/*   3. Get terminal code & branch code of the socket id             */
/*     3.1 TCT of SWA.                                               */
/*   4. According to branch code & user id to check whether the user */
/*      has the right password                                       */
/*      then return the user's profile                               */
/* ***************************************************************** */
GetName(pstDcsBuf)
struct DcsBuf *pstDcsBuf;
{
  int iRc ;
  int iSndSkLen;
  char caAccNo[12];
  char caIdNo[12];
  char caTaxNo[10];
  char caComName[30];
  char caPplName[10];
  char caKey[12];
  char caIoBuf[120];
  char caDataBuf[80];

  UCP_TRACE(P_GetName);

  memcpy(caAccNo,PcaData(pstDcsBuf),11);
  caAccNo[11]='\0';

  sprintf(g_caMsg,"enter get_name ");
  ErrLog(1000,g_caMsg,RPT_TO_LOG,caAccNo,12);

  iRc =acckey(lpbm,caAccNo);
  if (iRc  != 0) {
    /* teller code not found */
    sprintf(g_caMsg,"enter get_name acckey iRc =%d",iRc );
    ErrLog(1000,g_caMsg,RPT_TO_LOG,caAccNo,12);
    UCP_TRACE_END(-1);
  }

  iRc =gfield(lpb_id_c,caIoBuf);
  if (iRc  != 0) {
    /* teller's passwd get error */
    UCP_TRACE_END(-2);
  }

  memcpy(caIdNo,caIoBuf,11);
  caIdNo[11] = '\0';
  ErrLog(1000,"1000",RPT_TO_LOG,caIdNo,12);

  iRc = gfield(lpb_ta_c,caIoBuf);
  if (iRc  != 0) {
    /* teller's passwd get error */
    UCP_TRACE_END(-2);
  }

  memcpy(caTaxNo,caIoBuf,9);
  caTaxNo[9] = '\0';
  ErrLog(1000,"1001",RPT_TO_LOG,caTaxNo,10);
  if ((strncmp(caTaxNo,"         ",9) == 0 )){
    memset(caComName,0x20,30); 
    ErrLog(1000,"1999",RPT_TO_LOG,caIdNo,12);

    iRc = acckey(customer,caIdNo);
    if (iRc  != 0) {
      sprintf(g_caMsg,"enter customer acckey iRc=%d",iRc );
      ErrLog(1000,g_caMsg,RPT_TO_LOG,caIdNo,12);
      /* teller code not found */
      UCP_TRACE_END(-1);
    }

    iRc = gfield(cifm_nam,caIoBuf);
    if (iRc  != 0) {
      /* teller's passwd get error */
      UCP_TRACE_END(-2);
    }

    memcpy(caPplName,caIoBuf,10);
    iRc = gfield(cifm_cnm,caIoBuf);
    if (iRc  != 0) {
      /* teller's passwd get error */
      UCP_TRACE_END(-2);
    }
    memcpy(caComName,caIoBuf,30);
  }
  else {
    memset(caKey,0x20,12);
    memcpy(caKey,caTaxNo,9);
    caKey[11] = '\0';
    ErrLog(1000,"b4 acckey dump caKey",RPT_TO_LOG,caKey,12);

    iRc = acckey(customer,caKey);
    if (iRc != 0) {
      sprintf(g_caMsg,"enter 1customer key-acckey iRc=%d",iRc );
      ErrLog(1000,g_caMsg,RPT_TO_LOG,caKey,12);
      UCP_TRACE_END(-1); /* teller code not found */
    }

    /* get teller's passwd */
    iRc = gfield(cifm_nam,caIoBuf);
    if (iRc  != 0) {
      UCP_TRACE_END(-2); /* teller's passwd get error */
    }

    /* get teller's passwd */
    memcpy(caPplName,caIoBuf,10);
    iRc = gfield(cifm_cnm,caIoBuf);
    if (iRc  != 0) {
      UCP_TRACE_END(-2); /* teller's passwd get error */
    }
    memcpy(caComName,caIoBuf,30);
  } 

  memcpy(caDataBuf,caPplName,10);
  memcpy(caDataBuf+10," ",1);
  memcpy(caDataBuf+11,caComName,30);
  
  iSndSkLen=SK_HEAD_LEN + 56 ; 

  iRc = SendSofToClient(41,caDataBuf,OUT_KIND_2,'0','0');
  if (iRc != 0) {
    UCP_TRACE_END(-1);
  }

  UCP_TRACE_END(0);
}  /* end of GetName */




/*
*&N& ROUTINE NAME:int DbsOp()
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A&  �L
*&A& 
*&R& RETURN VALUE(S):
*&R&   0 : ���`.
*&R&  -1 : �Ѽƿ��~,�Υ\��N�����~.
*&R&
*&D& DESCRIPTION:
*&D&  1.
*&D&  2.
*&D&  3.
*&D&
*/
DbsOp(struct TellerSt *pstTelData,int iOp)
{
  int i;
  int iRc ;
  char caIoBuf[120];

  UCP_TRACE(P_DbsOp);

  sprintf(g_caMsg,"DbsOp:Begin OpCode=%d",iOp);
  ErrLog(1000,g_caMsg,RPT_TO_LOG,pstTelData,12);

  switch(iOp) {
    case 1:	/* using random read to read teller's password */
      iRc = acckey(tellerf,pstTelData->caTelCode);
      if (iRc  != 0) {
        UCP_TRACE_END(-1);	/* teller code not found */
       }
  
      iRc = gfield(tl_pawd,caIoBuf);
      if (iRc  != 0) {
        UCP_TRACE_END(-2);	/* teller's passwd get error */
      }
  
      memcpy(pstTelData->caTelPswd,caIoBuf,6);
      iRc = gfield(tl_det_1,caIoBuf);
      if (iRc  != 0) {
        UCP_TRACE_END(-3);	/* teller's detail1 get error */
      }
  
      memcpy(pstTelData->caDetail1,caIoBuf,4);
      iRc = gfield(tl_det_2,caIoBuf);
      if (iRc  != 0) {
        UCP_TRACE_END(-4);	/* teller's detail1 get error */
      }
      memcpy(pstTelData->caDetail2,caIoBuf,114);

      UCP_TRACE_END(0);
    case 2:      /* using write update to update teller file's content */
      iRc = acckey(tellerf,pstTelData->caTelCode);
      if (iRc  != 0) {
        UCP_TRACE_END(-1);	/* teller code not found */
      }
  
      if ( (iRc = lockrec(tellerf)) != 0) {
        UCP_TRACE_END(-2);
      }
      memcpy(caIoBuf,pstTelData->caDetail1,3);
      caIoBuf[3] = pstTelData->cTelOp;
      if ((iRc = pfield(tl_det_1,caIoBuf)) != 0) {
        ulockrec(tellerf);
        UCP_TRACE_END(-3);
      }
      UCP_TRACE_END(0);

    default:
      UCP_TRACE_END(-9); /* invalid operation code */
  }
}
#endif

#ifdef CISAM
DbsOp(struct TellerSt *pstTelData,int iOp)
{
  int i;
  int iFileId;
  char *getenv();
  char caFileName[256];
  struct keydesc stKeyDesc;
  struct TellerSt stTmpTelBuf;

  UCP_TRACE(P_DbsOp);

  strcpy(caFileName, getenv("CISAMPATH"));
  strcat(caFileName, "CCFTELF");
  sprintf(g_caMsg,"DbsOp -->enter DbsOp");
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  switch(iOp) {
    case 1 :        /* Read teller file */
      iFileId = isopen(caFileName, ISINOUT + ISMANULOCK);
      if (iFileId < SUCCESS) {
        sprintf(g_caMsg,"DbsOp -->open teller file error errno=%d",errno);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END(-18);   /* open error */
      }
      stKeyDesc.k_flags = ISNODUPS;
      stKeyDesc.k_nparts = 1;
      stKeyDesc.k_part[0].kp_start = 0;
      stKeyDesc.k_part[0].kp_leng = 5;
      stKeyDesc.k_part[0].kp_type = CHARTYPE;
      if (isread(iFileId, &stTmpTelBuf, ISFIRST) < SUCCESS) {
        pstTelData->cAuth = '1';
        isclose(iFileId);
        UCP_TRACE_END(1);   /* empty file */
      }
      if (isread(iFileId, pstTelData, ISEQUAL) < SUCCESS) {
        isclose(iFileId);
        UCP_TRACE_END(-1);  /* not found */
      }
      isclose(iFileId);
      UCP_TRACE_END(0);
    default :       /* Invalid operation code */
      UCP_TRACE_END(-9);
  }
}  /* end of DbsOp */
#endif

DbsOp(struct TellerSt *pstTelData,int iOp)
{
}
GetName(pstDcsBuf)
struct DcsBuf *pstDcsBuf;
{
}
