/*JSHEN:  2/9/95
Modification -- IBM PGM
1. DcsSend 
	if (g_lReqToSend== CM_REQ_TO_SEND_RECEIVED)
	if (g_lReqToSend == CM_REQ_TO_SEND_NOT_RECEIVED)
		cmptr();
2. DcsReceived
	if (CM_NO_DATA_RECEIVED && CM_OK) ...
	if (status == CM_SEND_RECEIVED) ...
	if (status == CM_INCOMPLETE_DATA_RECEIVED) ...
*/

#include <cmc.h>		/* CPI-C external definitions		*/
#include <errno.h>		/* global error numbers			*/
#include <fcntl.h>		/* for using file permissions		*/
#include <signal.h>		/* for using signal handler		*/
#include <stdio.h>		/* for using printf command		*/
#include <string.h>		/* for using strcpy, strcat commands    */
#include <malloc.h>		/* for using malloc command		*/
#include <sys/types.h>
#include <sys/signal.h>
#include "errlog.h"
#include "dcs.h"

#define MAX_LISTEN 5
#define MAX_NETWKTBL_ARRAY 30

#define SYMMAX		9		/* CPIC profile name len       */
#define FILEMAX		80		/* arbitrary max file name len */
#define BUFFERLEN	80		/* arbitrary max data rcv len  */
#define CONV_ID_LEN	8		/* length of conv id area      */
#define SENDMAX		32000		/* max # of bytes to send      */
#define TPN_LEN		50		/* RTPN name len	       */

struct Lu62Sess {
/*JSHEN*/
  char cLastAct;	/*dummy*/
  unsigned char ucaConverId[CONV_ID_LEN];
  char cStatus;
  char cMode;
};

struct Lu62Netwk {
  char caDesCode[SYMMAX];
  char caField[2][TPN_LEN];
};


#define P_DcsLu62Accept 		52001
#define P_DcsLu62Connect 		52002
#define P_DcsLu62Disconnect 		52003
#define P_DcsLu62Initial 		52004
#define P_DcsLu62Null   		52005
#define P_DcsLu62Receive 		52006
#define P_DcsLu62Send   		52007
#define P_DcsLu62Terminate 		52008
#define P_DcsLu62       		52009
#define P_GetHostServName 		52010
#define P_LoadLu62NetwkTbl 		52011
#define P_SrhLu62NetwkTbl 		52012

/* -------------------- STATIC GLOBAL DECLARATION ------------------- */
static int gs_iFirst=1; /* first flage 1=yes 0=no          */
static int gs_iResiLu62Id; /* socket id form resident passive, call dcs_initial */
static int gs_iMaxLoad;

struct servent *pstServEnt;
struct hostent *pstHostEnt;
struct Lu62Sess g_stLu62SesTbl[MAX_SESS];
struct Lu62Netwk g_stLu62NetTbl[MAX_NETWKTBL_ARRAY];

/* ------ CALL FUNCTION & SUBROUTINE PROTOTYPE DECLARATIONS --------- */
int DcsLu62(struct DcsBuf *pstDcsBuf);
int DcsLu62Initial(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess,
                   char cMode);
int DcsLu62Connect(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess);
int DcsLu62Accept(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess);
int DcsLu62Send(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess);
int DcsLu62Receive(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess);
int DcsLu62Disconnect(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess);
int DcsLu62Terminate(struct DcsBuf *pstDcsBuf);
int GetHostServName(char *pcDesCode,char *pcHostName,char *pcServName);
int SrhLu62NetwkTbl(char *pcDesCode,struct Lu62Netwk *pstNetTbl);
int LoadLu62NetwkTbl(struct Lu62Netwk *pstNetTbl);
void DcsLu62Null();


CM_PREPARE_TO_RECEIVE_TYPE     	g_lPrepareType;	/* prep to receive type	*/
CM_RECEIVE_TYPE		        g_lReceiveType;	/* receive type 	*/
CM_REQUEST_TO_SEND_RECEIVED     g_lReqToSend;	/* req to send indicator*/
CM_SYNC_LEVEL			g_lSyncLevel;	/* sync level for conv  */
CM_SEND_TYPE			g_lSendType;	/* send type		*/
CM_INT32			g_lLength;	/* data length          */
CM_INT32			g_lReceivedLength;/* how much data rcvd   */
CM_STATUS_RECEIVED		g_lStatusReceived;/* status from remote   */
CM_DATA_RECEIVED_TYPE		g_lDataReceived;  /* was of data rcvd?   */
CM_DEALLOCATE_TYPE		g_lDeallocateType;/* type of deallocate   */

CM_INT32                        g_lSecurType;
CM_INT32                        g_lSecurPasswdLen;
CM_INT32                        g_lSecurUseridLen;
unsigned char *                 g_ucaSecurUserid;
unsigned char *                 g_ucaSecurPasswd;
unsigned char *                 g_ucaTpName;
CM_INT32                        g_lTpNameLen;

static unsigned char			g_ucaConverId[CONV_ID_LEN];

int
DcsLu62(struct DcsBuf *pstDcsBuf)
{
  int iRc;
  struct Lu62Sess *pstSess;


  g_lStatusReceived = CM_NO_STATUS_RECEIVED;
  g_lDataReceived = CM_NO_DATA_RECEIVED;
  g_lReqToSend = CM_REQ_TO_SEND_NOT_RECEIVED;

  UCP_TRACE(P_DcsLu62);
  ErrLog(10,"DcsLu62:begin",RPT_TO_LOG,0,0);

  pstSess = g_stLu62SesTbl;
  iRc = 0;
  switch (PcRqstCode(pstDcsBuf)){
   case DCSINITIAL:
     if(gs_iFirst){
       iRc = DcsLu62Initial(pstDcsBuf,pstSess,'A');
       if(iRc != DCS_NORMAL){
         break;
       }
       gs_iFirst = 0;
     }
     break;
   case DCSCONNECT:
     /* do DcsLu62Initial when FIRST */
     if(gs_iFirst){
       iRc = DcsLu62Initial(pstDcsBuf,pstSess,'A');
       if(iRc != DCS_NORMAL){
         break;
       }
       gs_iFirst = 0;
     }
     iRc = DcsLu62Connect(pstDcsBuf,pstSess);
     break;
   case DCSACCEPT:
     /* do DcsLu62Initial when FIRST */
     if(gs_iFirst){
       iRc = DcsLu62Initial(pstDcsBuf,pstSess,'P');
       if(iRc != DCS_NORMAL){
         break;
       }
       gs_iFirst = 0;
     }
     iRc = DcsLu62Accept(pstDcsBuf,pstSess);
     break;
   case DCSCONNECTWRITE:
     /* do DcsLu62Initial when FIRST */

/*marked by eric
     if(gs_iFirst){
       iRc = DcsLu62Initial(pstDcsBuf,pstSess,'A');
       if(iRc != DCS_NORMAL){
         break;
       }
       gs_iFirst = 0;
     }
*/

     iRc = DcsLu62Initial(pstDcsBuf,pstSess,'A');
     if(iRc != DCS_NORMAL){
       break;
     }


     iRc = DcsLu62Connect(pstDcsBuf,pstSess);
     if(iRc != DCS_NORMAL){
       break;
     }
     iRc = DcsLu62Send(pstDcsBuf,pstSess);
     break;
   case DCSWRITE:
     iRc = DcsLu62Send(pstDcsBuf,pstSess);
     break;
   case DCSWRDISCONECT:
     iRc = DcsLu62Send(pstDcsBuf,pstSess);
     if(iRc == DCS_NORMAL){
       iRc = DcsLu62Disconnect(pstDcsBuf,pstSess);
     }
     break;
   case DCSACCEPTREAD:
     /* do DcsLu62Initial when FIRST */
     if(gs_iFirst){
       iRc = DcsLu62Initial(pstDcsBuf,pstSess,'P');
       if(iRc != DCS_NORMAL){
         break;
       }
       gs_iFirst = 0;
     }
     iRc = DcsLu62Accept(pstDcsBuf,pstSess);
     if(iRc != DCS_NORMAL){
       break;
     }
     iRc = DcsLu62Receive(pstDcsBuf,pstSess);
     break;
   case DCSREAD:
     iRc = DcsLu62Receive(pstDcsBuf,pstSess);
     break;
   case DCSDISCONNECT:
     iRc = DcsLu62Disconnect(pstDcsBuf,pstSess);
     break;
   case DCSTERMINATE:
     iRc = DcsLu62Terminate(pstDcsBuf);
     break;
   default:
     sprintf(g_caMsg,"DcsLu62:reguest error[%c]",PcRqstCode(pstDcsBuf));
     ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
     iRc = DCS_E_COMMAND;
     break;
  } /* end switch */

  PiReply(pstDcsBuf) = iRc;
  UCP_TRACE_END(iRc);
} /* end of sbdbs */


int
DcsLu62Initial(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess,char cMode)
{
  CM_RETURN_CODE  iCmRc;      /* ret code from CPI-C  */
  char	caSysDestName[SYMMAX];	/* symbolic name*/
  int iIdx;
  int iLu62Id;
  int iRc;
  struct Lu62Netwk *pstNetTbl;
  char caServName[20];
  char caHostName[20];    /* for socket dcs */

  UCP_TRACE(P_DcsLu62Initial);
  ErrLog(10,"DcsLu62Initial Begin.",RPT_TO_LOG,0,0);


  pstNetTbl = g_stLu62NetTbl;
  iRc = LoadLu62NetwkTbl(pstNetTbl);
  if(iRc != 0){
    ErrLog(10000,"DcsLu62Initial:load network table error",RPT_TO_LOG,0,0);
    PiErrno(pstDcsBuf) = iRc;
    UCP_TRACE_END(DCS_E_NETWORKTBL);
  }
  ErrLog(1000,"DcsLu62Initial:load network table ok!!",RPT_TO_LOG,0,0);


  for(iIdx=0; iIdx<MAX_SESS; iIdx++){
    memset(&pstSess[iIdx], 0x00 , sizeof(struct Lu62Sess) );
    pstSess[iIdx].cStatus = DCS_S_FREE ;
    strcpy(pstSess[iIdx].ucaConverId,"0000000");
  }

  memset(g_ucaConverId,0x00, CONV_ID_LEN);


  if(cMode == PASSIVE_MODE) {
    ErrLog(1000,"DcsLu62Initial:ok.",RPT_TO_LOG,0,0);
    UCP_TRACE_END(DCS_NORMAL);
  }
 
  GetHostServName(PcaDesCode(pstDcsBuf),caHostName,caServName);
  /* caHostName <= sna profile name */
  strcpy(caSysDestName, caHostName);

  cminit(g_ucaConverId,
        (unsigned char *)caSysDestName,
        &iCmRc);

  sprintf(g_caMsg,"cminit caSysDestName(sna profile)=%s",caSysDestName);
  ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
  ErrLog(1000,"cminit ucaConverId",RPT_TO_LOG,g_ucaConverId,20);

  if (iCmRc != CM_OK)
    {
      sprintf(g_caMsg,"DcsSkInitial(cminit):lu62 fail, errno=[%d]",(int)iCmRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
    }
  g_lSyncLevel = CM_NONE;

  cmssl(g_ucaConverId,
        &g_lSyncLevel,
        &iCmRc);

  if (iCmRc != CM_OK)
    {
      sprintf(g_caMsg,"DcsSkInitial(cmssl):lu62 fail, errno=[%d]",(int)iCmRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
    }
   
  g_lReceiveType = CM_RECEIVE_AND_WAIT;

  cmsrt(g_ucaConverId,
        &g_lReceiveType,
        &iCmRc);

  if (iCmRc != CM_OK)
    {
      sprintf(g_caMsg,"DcsSkInitial(cmsrt):lu62 fail, errno=[%d]",(int)iCmRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
    }
 
  g_lPrepareType = CM_PREP_TO_RECEIVE_FLUSH;

  cmsptr(g_ucaConverId,
         &g_lPrepareType,
         &iCmRc);

  if (iCmRc != CM_OK)
    {
      sprintf(g_caMsg,"DcsSkInitial(cmsptr):lu62 fail, errno=[%d]",(int)iCmRc );
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
    }

  g_lSendType = CM_SEND_AND_PREP_TO_RECEIVE;

/*JSHEN
  g_lSendType = CM_SEND_AND_FLUSH;
*/

  cmsst(g_ucaConverId,
        &g_lSendType,
        &iCmRc);


  if (iCmRc != CM_OK)
    {
      sprintf(g_caMsg,"DcsLu62Send(cmsst):write fail, errno=[%d]",iCmRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstSess[iIdx].cStatus = DCS_S_ERROR;
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iRc);
    }


      /********************************************************/
/*if SERVER=AS400 */
/*
  g_lSecurType = XC_SECURITY_PROGRAM;

  xcscst(g_ucaConverId,
	 &g_lSecurType,
	 &iCmRc);

  if (iCmRc != CM_OK)
    {
      sprintf(g_caMsg,"DcsSkInitial(xcscst):lu62 fail, errno=[%d]",(int)iCmRc );
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
    }


  g_ucaSecurUserid = malloc(6);
  g_lSecurUseridLen = 5;
  strcpy(g_ucaSecurUserid,"JSHEN");

  xcscsu(g_ucaConverId,
         g_ucaSecurUserid,
	 &g_lSecurUseridLen,
	 &iCmRc);

  if (iCmRc != CM_OK)
    {
      sprintf(g_caMsg,"DcsSkInitial(xcscsu):lu62 fail, errno=[%d]",(int)iCmRc );
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
    }

  g_ucaSecurPasswd = malloc(6);
  g_lSecurPasswdLen = 5;
  strcpy(g_ucaSecurPasswd,"JSHEN");

  xcscsp(g_ucaConverId,
         g_ucaSecurPasswd,
	 &g_lSecurPasswdLen,
	 &iCmRc);

  if (iCmRc != CM_OK)
    {
      sprintf(g_caMsg,"DcsSkInitial(xcscsp):lu62 fail, errno=[%d]",(int)iCmRc );
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
    }

*/
   g_ucaTpName = malloc(TPN_LEN);
   g_lTpNameLen = TPN_LEN - 1;

   strcpy(g_ucaTpName,caServName);
/* set remote tpn */
   cmstpn(g_ucaConverId,
          g_ucaTpName,
          &g_lTpNameLen,
          &iCmRc);

   if (iCmRc != CM_OK)
    {
      sprintf(g_caMsg,"DcsSkInitial(xcstpn):lu62 fail, errno=[%d]",(int)iCmRc );
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
    } 


/*JSHEN 2/17/95*/
  g_lDeallocateType = CM_DEALLOCATE_FLUSH;
  cmsdt(g_ucaConverId,
        &g_lDeallocateType,
	&iCmRc);

  if (iCmRc != CM_OK)
    {
      sprintf(g_caMsg,"DcsSkAccept:set dealloc. type fail, errno=[%d]",iCmRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
    }


  ErrLog(1000,"DcsLu62Initial:End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}



int
DcsLu62Connect(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess)
{
  CM_RETURN_CODE  iCmRc=CM_OK;      /* ret code from CPI-C  */
  int iRc;
  int iIdx;
  int iLu62Id;
 /* char caServName[20]; */
 /* char caHostName[20]; */   /* for socket dcs */
 
  UCP_TRACE(P_DcsLu62Connect);
  ErrLog(10,"DcsLu62Connect Begin.",RPT_TO_LOG,0,0);

  /* search a usable dialogue  */
  iIdx = 1;
  while(pstSess[iIdx].cStatus != DCS_S_FREE &&
        pstSess[iIdx].cStatus != DCS_S_ERROR &&
        pstSess[iIdx].cStatus != DCS_S_USABLE &&
        iIdx < MAX_SESS) iIdx++;

  if(iIdx == MAX_SESS){
    ErrLog(1000,"DcsLu62Connect:Sess over error",RPT_TO_LOG,0,0);
    PiErrno(pstDcsBuf) = DCS_ES_SESOVERFLW;
    UCP_TRACE_END(DCS_E_LOCALDCS);
  }

  memset(&pstSess[iIdx], 0x0, sizeof(struct Lu62Sess) );
/*
  GetHostServName(PcaDesCode(pstDcsBuf),caHostName,caServName);
*/

  ErrLog(1000,"cmalloc ucaConverId",RPT_TO_LOG,g_ucaConverId,20);

  cmallc(g_ucaConverId,
	 &iCmRc);

  ErrLog(1000,"cmalloc ucaConverId",RPT_TO_LOG,g_ucaConverId,20);

  if (iCmRc != CM_OK)
    {
      sprintf(g_caMsg,"DcsLu62Connect(cmalloc):connect fail, errno=[%d]",iCmRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
    }

     
  /* save the session information */
  pstSess[iIdx].cStatus  = DCS_S_USED ;
  pstSess[iIdx].cLastAct = DCSCONNECT;
  memcpy(pstSess[iIdx].ucaConverId , g_ucaConverId,CONV_ID_LEN);
  pstSess[iIdx].cMode = ACTIVE_MODE;

  /* fill DCS buff */
  PiSesIdx(pstDcsBuf) = iIdx;
  PiErrno(pstDcsBuf) = 0;
  PcProto(pstDcsBuf) = LU62_DCS;


  sprintf(g_caMsg,"DcsLu62Connect End.iIdx=%d ucaConverId=%s",
          iIdx,pstSess[iIdx].ucaConverId);
  ErrLog(10,g_caMsg,RPT_TO_LOG,pstSess[iIdx].ucaConverId,10);
  UCP_TRACE_END(DCS_NORMAL);
}


int
DcsLu62Accept(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess)
{
  CM_RETURN_CODE  iCmRc=CM_OK;      /* ret code from CPI-C  */
  int iAcepLu62Id,iIdx,iRc;
  int iServLen;

  UCP_TRACE(P_DcsLu62Accept);
  ErrLog(10,"DcsLu62Accept Begin.",RPT_TO_LOG,0,0);

  /* search a usable dialogue  */
  iIdx = 1;
  while(pstSess[iIdx].cStatus != DCS_S_FREE &&
        pstSess[iIdx].cStatus != DCS_S_USABLE &&
        pstSess[iIdx].cStatus != DCS_S_ERROR &&
        iIdx < MAX_SESS) iIdx++;

  if(iIdx == MAX_SESS){
    ErrLog(1000,"DcsLu62Accept:Sess over error",RPT_TO_LOG,0,0);
    PiErrno(pstDcsBuf) = DCS_ES_SESOVERFLW;
    UCP_TRACE_END(DCS_E_LOCALDCS);
  }
  /* initial sess */
  memset(&pstSess[iIdx], 0x0, sizeof(struct Lu62Sess) );

    
  cmaccp(g_ucaConverId,
         &iCmRc);

  if (iCmRc != CM_OK)
    {
      sprintf(g_caMsg,"DcsSkAccept(cmaccp):accept fail, errno=[%d]",iCmRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
    }


  pstSess[iIdx].cStatus  = DCS_S_USED ;
  pstSess[iIdx].cLastAct = DCSACCEPT ;
  memcpy(pstSess[iIdx].ucaConverId , g_ucaConverId,CONV_ID_LEN );
  pstSess[iIdx].cMode = PASSIVE_MODE;

  /* fill DCS buff */
  PiSesIdx(pstDcsBuf) = iIdx;
  PiErrno(pstDcsBuf) = 0;
  PcProto(pstDcsBuf) = LU62_DCS;

  sprintf(g_caMsg,"DcsLu62Accept End.iIdx=%d ucaConverId=%s",
          iIdx,pstSess[iIdx].ucaConverId);

  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}


int
DcsLu62Send(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess)
{
  CM_RETURN_CODE  iCmRc=CM_OK;      /* ret code from CPI-C  */
  int iIdx;
  unsigned char ucaWdLu62Id[CONV_ID_LEN];
  unsigned char ucaRdLu62Id[CONV_ID_LEN]; /*JSHEN -- dummy*/
  int iRc;
  int iMsgLen;
  unsigned char caDummy[10];
 
  UCP_TRACE(P_DcsLu62Send);
  ErrLog(10,"DcsLu62Send Begin.",RPT_TO_LOG,0,0);
  memset(ucaWdLu62Id , 0x00,CONV_ID_LEN);
  memset(ucaRdLu62Id , 0x00,CONV_ID_LEN);

  iIdx = PiSesIdx(pstDcsBuf);

  if(iIdx > 0){
    if(pstSess[iIdx].cStatus != DCS_S_USED || iIdx >= MAX_SESS){
      ErrLog(1000,"DcsLu62Send:unusable Session!",RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = DCS_ES_SESUNUSE;
      UCP_TRACE_END(DCS_E_COMMAND);
    }
    memcpy(ucaWdLu62Id , pstSess[iIdx].ucaConverId,CONV_ID_LEN);
    memcpy(ucaRdLu62Id , pstSess[iIdx].ucaConverId,CONV_ID_LEN);
  }
  else{
    strcpy(ucaWdLu62Id , "0000001");
    strcpy(ucaRdLu62Id , "0000001");
  }

  /* send a service reguest */
/*mod by JSHEN: real len = datalen - 8 */
  iMsgLen = PiDataLen(pstDcsBuf) -8;

  sprintf(g_caMsg,"DcsLu62Send:iIdx=%d ucaWdLu62Id=%s ",
          iIdx,ucaWdLu62Id);
  ErrLog(1000,g_caMsg,RPT_TO_LOG,ucaWdLu62Id,10);
  sprintf(g_caMsg,"DcsLu62Send:iMsgLen=%d ",iMsgLen);
  ErrLog(1000,g_caMsg,RPT_TO_LOG,PcaData(pstDcsBuf),iMsgLen);


  /**************************************************************/
  /* Send data to the target transaction program. This command  */
  /* will issue a packet of data of (length) bytes. The data    */
  /* going to the target can be found in the string send_buffer */
  /* Req_to_send indicates whether the remote program has made  */
  /* a request to send.		                                */
  /**************************************************************/
  g_lLength = (long) iMsgLen;
   
  cmsend(ucaWdLu62Id,
         PcaData(pstDcsBuf),
         &g_lLength,
         &g_lReqToSend,
         &iCmRc);

  if (iCmRc != CM_OK)
  {
        sprintf(g_caMsg,"DcsLu62Send(cmsend):write fail, errno=[%d]",iCmRc);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        pstSess[iIdx].cStatus = DCS_S_ERROR;
        PiErrno(pstDcsBuf) = errno;
        UCP_TRACE_END(iRc);
  }
  else
      ErrLog(1000,"DcsLu62Send:write ok.",RPT_TO_LOG,0,0);


/*JSHEN add 2/9/95*/
  /* test if remote side wants to send */
/*
  if (g_lReqToSend == CM_REQ_TO_SEND_NOT_RECEIVED) {
  	cmtrts(ucaWdLu62Id,
              &g_lReqToSend,
              &iCmRc);

  	if (iCmRc != CM_OK)
  	{
           sprintf(g_caMsg,"DcsLu62Send(cmrts) fail, errno=[%d]",iCmRc);
           ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
           pstSess[iIdx].cStatus = DCS_S_ERROR;
           PiErrno(pstDcsBuf) = errno;
           UCP_TRACE_END(iRc);
  	}
  }

*/
  /* if remote side requests to send     */
  /* this side issues prepare_to_receive */
/*
  if (g_lReqToSend == CM_REQ_TO_SEND_RECEIVED) {
  	cmptr(ucaWdLu62Id,
              &iCmRc);

  	if (iCmRc != CM_OK)
  	{
           sprintf(g_caMsg,"DcsLu62Send(cmptr) fail, errno=[%d]",iCmRc);
           ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
           pstSess[iIdx].cStatus = DCS_S_ERROR;
           PiErrno(pstDcsBuf) = errno;
           UCP_TRACE_END(iRc);
  	}
  }
*/

  /* update session */

  PiErrno(pstDcsBuf) = 0;
/*JSHEN*/
  pstSess[iIdx].cLastAct = DCSWRITE;

  if(iIdx == 0 && (pstSess[iIdx].cStatus == DCS_S_FREE ||
                  pstSess[iIdx].cStatus == DCS_S_USABLE)){
    pstSess[iIdx].cStatus = DCS_S_USED ;
    pstSess[iIdx].cMode = ACTIVE_MODE;
    PcProto(pstDcsBuf) = LU62_DCS;
  }

  ErrLog(10,"DcsLu62Send End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}


int
DcsLu62Receive(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess)
{
  CM_RETURN_CODE  iCmRc=CM_OK;      /* ret code from CPI-C  */
  unsigned char ucaRdLu62Id[CONV_ID_LEN];
  unsigned char ucaWdLu62Id[CONV_ID_LEN];	/*dummy*/
  int iIdx;
  int iRc;
  int iMsgLen;
  unsigned char caDummy[10];
  void DcsLu62Null();
  char caTmpBuf[10];
 
  UCP_TRACE(P_DcsLu62Receive);
  ErrLog(10,"DcsLu62Receive Begin.",RPT_TO_LOG,0,0);
  memset(ucaRdLu62Id , 0x00,CONV_ID_LEN);
  memset(ucaWdLu62Id , 0x00,CONV_ID_LEN);

  iIdx = PiSesIdx(pstDcsBuf);

  if(iIdx > 0){
    if(pstSess[iIdx].cStatus != DCS_S_USED || iIdx >= MAX_SESS){
      ErrLog(1000,"DcsLu62Receive:unusable Session!",RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = DCS_ES_SESUNUSE;
      UCP_TRACE_END(DCS_E_COMMAND);
    }
    memcpy(ucaRdLu62Id , pstSess[iIdx].ucaConverId,CONV_ID_LEN);
    memcpy(ucaWdLu62Id , pstSess[iIdx].ucaConverId,CONV_ID_LEN);
  }
  else{
    strcpy(ucaRdLu62Id , "0000001");
    strcpy(ucaWdLu62Id , "0000001");
  }




  g_lDataReceived = CM_INCOMPLETE_DATA_RECEIVED;
  while (g_lDataReceived == CM_INCOMPLETE_DATA_RECEIVED) {

  	signal(SIGALRM,DcsLu62Null)  ;
  	signal(SIGINT,SIG_DFL)  ;
  	alarm(PlWaiTime(pstDcsBuf)) ;

  	sprintf(g_caMsg,"DcsLu62Receive:iIdx=%d ucaRdLu62Id=%s.",
       		   iIdx,ucaRdLu62Id);
  	ErrLog(1000,g_caMsg,RPT_TO_LOG,ucaRdLu62Id,10);

  	iMsgLen = PiDataLen(pstDcsBuf);
  	g_lLength = (long) iMsgLen;
  	ErrLog(1000,"begin cmrcv",RPT_TO_LOG,0,0);

  	cmrcv(ucaRdLu62Id,
        	PcaData(pstDcsBuf),
        	&g_lLength,
		&g_lDataReceived,
		&g_lReceivedLength,
		&g_lStatusReceived,
		&g_lReqToSend,
		&iCmRc);

  	sprintf(g_caMsg,"cmrcv():status [%d] data_rcvd [%d] ",
                 (int)g_lStatusReceived,(int)g_lDataReceived);
  	ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);

  	sprintf(g_caMsg,"DcsLu62Received:g_lReceivedLength)=%d ",
		g_lReceivedLength);
  	ErrLog(1000,g_caMsg,RPT_TO_LOG,PcaData(pstDcsBuf),g_lReceivedLength);


/*JSHEN add 2/17/95*/
  	if ( iCmRc == CM_DEALLOCATED_ABEND 	|| 
	     iCmRc == CM_DEALLOCATED_ABEND_SVC  ||
	     iCmRc == CM_DEALLOCATED_ABEND_TIMER)
  	{
      	   sprintf(g_caMsg,"DcsLu62Receive(cmrcv):abend");
	   ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);

           pstSess[iIdx].cStatus = DCS_S_ERROR;
           PiErrno(pstDcsBuf) = DCS_ES_ABEND;
           if(errno == EINTR) UCP_TRACE_END(DCS_E_TIMEOUT);
           UCP_TRACE_END(DCS_ES_ABEND);
  	}

  	if ( (iCmRc != CM_OK) && (iCmRc != CM_DEALLOCATED_NORMAL) )
  	{
      	   sprintf(g_caMsg,"DcsLu62Receive(cmrcv):read fail, errno=[%d]",iCmRc);
	   ErrLog(1000,g_caMsg,RPT_TO_LOG,PcaData(pstDcsBuf),g_lReceivedLength);

           pstSess[iIdx].cStatus = DCS_S_ERROR;
           PiErrno(pstDcsBuf) = iCmRc;
           if(errno == EINTR) UCP_TRACE_END(DCS_E_TIMEOUT);
           UCP_TRACE_END(iCmRc);
  	}

  	if ( iCmRc == CM_DEALLOCATED_NORMAL)
  	{
      	 sprintf(g_caMsg,"DcsLu62Rec(cmrcv):Deallocate normally");
	 ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);

      	 sprintf(g_caMsg,"DcsLu62Rec(cmrcv):call DcsLuDisconnect will result abend");
	 ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
  	}

/*JSHEN 2/17*/
  	sprintf(g_caMsg,"DcsLu62Receive(cmrcv) ok, iCmRc=%d ", iCmRc);
  	ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);

  /*JSHEN add-- 2/9/95 */
  /* check Data_Received_Type */

  	if (g_lDataReceived == CM_NO_DATA_RECEIVED) {
      	    sprintf(g_caMsg,"DcsLu62Receive(cmrcv) errno: no_data_received");
            ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      	    pstSess[iIdx].cStatus = DCS_S_ERROR;
      	    PiErrno(pstDcsBuf) = g_lDataReceived;
      	    if(errno == EINTR) UCP_TRACE_END(DCS_E_TIMEOUT);
      	    UCP_TRACE_END(g_lDataReceived);
  	}


  /* check status_received */

  	if (g_lStatusReceived == CM_CONFIRM_RECEIVED || 
      		g_lStatusReceived == CM_CONFIRM_SEND_RECEIVED)
    	{
      	    cmcfmd(ucaRdLu62Id,
             	&iCmRc);
     
      	    if (iCmRc != CM_OK)
            {
             sprintf(g_caMsg,"DcsLu62Receive(cmcfmd) fail, errno=[%d]",iCmRc);
             ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
             pstSess[iIdx].cStatus = DCS_S_ERROR;
             PiErrno(pstDcsBuf) = iCmRc;
             UCP_TRACE_END(iCmRc);
            }
    	} 

  	sprintf(caTmpBuf,"%.5d",g_lReceivedLength);
  	memcpy(PcaDataLen(pstDcsBuf),caTmpBuf,5);

  	alarm(0) ;
  	iMsgLen = (int) g_lReceivedLength;

  	sprintf(g_caMsg,"DcsLu62Receive:read ok. len=%d\n ",iMsgLen);
  	ErrLog(1000,g_caMsg,RPT_TO_LOG,PcaData(pstDcsBuf),iMsgLen);

  /* save the session information */
  	PiDataLen(pstDcsBuf) = iMsgLen ;
  	PiErrno(pstDcsBuf) = 0;
  	pstSess[iIdx].cLastAct = DCSREAD;

  	if (iIdx == 0 && (pstSess[iIdx].cStatus == DCS_S_FREE ||
                  pstSess[iIdx].cStatus == DCS_S_USABLE))
	{
    	  pstSess[iIdx].cStatus = DCS_S_USED ;
    	  pstSess[iIdx].cMode = PASSIVE_MODE;
    	  PcProto(pstDcsBuf) = LU62_DCS;
  	}

  } /* while INCOMPLETE_DATA */

  ErrLog(10,"DcsLu62Receive End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}


int
DcsLu62Disconnect(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess)
{
  CM_RETURN_CODE  iCmRc=CM_OK;      /* ret code from CPI-C  */
  int iRc;
  int iIdx;
  unsigned char ucaConverId[CONV_ID_LEN];
 
  UCP_TRACE(P_DcsLu62Disconnect);
  ErrLog(1000,"DcsLu62Disconnect Begin.",RPT_TO_LOG,0,0);
  memset(ucaConverId , 0x00,CONV_ID_LEN);

  /* Is the dialogue usable */
  iIdx = PiSesIdx(pstDcsBuf);

  if(iIdx > 0){
    if(pstSess[iIdx].cStatus == DCS_S_FREE || iIdx >= MAX_SESS){
      ErrLog(1000,"DcsLu62Disconnect: unusable Session!",RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = DCS_ES_SESUNUSE;
      UCP_TRACE_END(DCS_E_COMMAND);
    }
    memcpy(ucaConverId , pstSess[iIdx].ucaConverId,CONV_ID_LEN);
  }
  else{
    strcpy(ucaConverId , "0000001");
  }


  sprintf(g_caMsg,"DcsLu62Disconnect(cmdeal), type=[%d]",
	g_lDeallocateType);
  ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);


  cmdeal(ucaConverId,
         &iCmRc);

  if (iCmRc != CM_OK) {
    sprintf(g_caMsg,"DcsLu62Disconnect(cmdeal) fail, errno=[%d]",iCmRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstSess[iIdx].cStatus = DCS_S_ERROR;
    PiErrno(pstDcsBuf) = iCmRc;
    UCP_TRACE_END(iCmRc);
  }

  /* save the session information */
  pstSess[iIdx].cStatus = DCS_S_FREE;
  strcpy(pstSess[iIdx].ucaConverId , "00000-1");

  /* fill DCS buff */
  PiSesIdx(pstDcsBuf) = -1;
  PiErrno(pstDcsBuf) = 0;
  PcProto(pstDcsBuf) = ' ';

  ErrLog(1000,"DcsLu62Disconnect End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}


int
DcsLu62Terminate(struct DcsBuf *pstDcsBuf)
{
  UCP_TRACE(P_DcsLu62Terminate);
  ErrLog(10,"DcsLu62Terminate Begin.",RPT_TO_LOG,0,0);

  ErrLog(10,"DcsLu62Terminate End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}



int
GetHostServName(char *pcDesCode,char *pcHostName,char *pcServName)
{
  int iRc;
  struct Lu62Netwk stNetwk;

  UCP_TRACE(P_GetHostServName);
  ErrLog(10,"GetHostServName:Begin",RPT_TO_LOG,0,0);

  iRc = 0;
  /* get protocol & server name by des_code */
  iRc = SrhLu62NetwkTbl(pcDesCode,&stNetwk);
  if(iRc != 0){
    sprintf(g_caMsg,"GetHostServName:search network table error iRc=%d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(iRc);
  }
  ErrLog(10,"GetHostServName:search network table ok.",RPT_TO_LOG,0,0);

  strcpy(pcHostName,stNetwk.caField[0]);
  strcpy(pcServName,stNetwk.caField[1]);

  sprintf(g_caMsg,"GetHostSeNa:End host=%s serv=%s\n",pcHostName,pcServName);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
  UCP_TRACE_END(0);
}


int
SrhLu62NetwkTbl(char *pcDesCode,struct Lu62Netwk *pstNetwk)
{
  int iIdx,iRc;
  struct Lu62Netwk *pstNetTbl;
 
  UCP_TRACE(P_SrhLu62NetwkTbl);
  sprintf(g_caMsg,"SrhLu62NetwkTbl:Begin,pcDesCode=%.10s",pcDesCode);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);

  pstNetTbl = g_stLu62NetTbl;
  iIdx = 1;
  /* find out in the net work table array */
  while((iRc = memcmp(pcDesCode,pstNetTbl[iIdx].caDesCode,10) != 0) &&
        (iIdx < gs_iMaxLoad)){
    iIdx++;
  }
  
  /* memory copy from net work table to working area of networktable struct */
  if(iIdx == gs_iMaxLoad){
    /* not found in table array, then set default protocol & server name */
    memcpy(pstNetwk,&pstNetTbl[0],sizeof(struct Lu62Netwk));
  }
  else{
    /* found */
    memcpy(pstNetwk,&pstNetTbl[iIdx],sizeof(struct Lu62Netwk));
  }

  sprintf(g_caMsg,"SrhLu62NetwkTbl End pstNetTbl[%d]=",iIdx);
  ErrLog(10,g_caMsg,RPT_TO_LOG,&pstNetTbl[iIdx],sizeof(struct Lu62Netwk));
  UCP_TRACE_END(0);
}


int
LoadLu62NetwkTbl(struct Lu62Netwk *pstNetTbl)
{
  int i,j,k;
  FILE *pfNetFd;
  char caFileName[100];

  UCP_TRACE(P_LoadLu62NetwkTbl);
  ErrLog(10,"LoadLu62NetwkTbl:Begin",RPT_TO_LOG,0,0);
/*JSHEN*/
  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat(caFileName, DCS_TABLE_PATH);
  strcat(caFileName, LU62TABLE);
  ErrLog(10,caFileName,RPT_TO_LOG,0,0);

  if((pfNetFd = fopen(caFileName,"r")) == (FILE *) 0){
    sprintf(g_caMsg,"LoadLu62NetwkTbl:open lu62tbl fail errno=%d",errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(DCS_ES_OPENTBLFILE);
  }
  ErrLog(10,"LoadLu62NetwkTbl:open netwktable ok",RPT_TO_LOG,0,0);

  i = 0;
  while(fscanf(pfNetFd,"%s %s %s", pstNetTbl[i].caDesCode,
                                   pstNetTbl[i].caField[0],
                                   pstNetTbl[i].caField[1]) != EOF){
    /*
    for(j=0; j<2; j++){
      for(k=0; k<20; k++){
        if(pstNetTbl[i].caField[j][k] == '*'){
           pstNetTbl[i].caField[j][k] = '\0';
           break;
        }
      }
    }
    */

    if(i++ > MAX_NETWKTBL_ARRAY){
      ErrLog(1000,"LoadLu62NetwkTbl:over table array",RPT_TO_LOG,0,0);
      fclose(pfNetFd);
      UCP_TRACE_END(DCS_ES_TBLARRAYOVERFLW);
    }
  }

  gs_iMaxLoad = i;
  ErrLog(10,"LoadLu62NetwkTbl End.",RPT_TO_LOG,0,0);
  fclose(pfNetFd);
  UCP_TRACE_END(0);
}

void
DcsLu62Null()
{
}



