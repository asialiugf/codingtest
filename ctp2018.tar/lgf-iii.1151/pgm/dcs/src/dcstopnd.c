

/*     FUNCTION & SUBROUTINE DESCRIPTION
*&N&   
*&N& TYPE      NAME                     DESCRIPTION
*&N& ------ ----------------- ---------------------------------------- 
*&N& int    DcsTopend         
*&N& int    DcsTpInit
*&N& int    DcsTpReinit
*&N& int    DcsTpConnect
*&N& int    DcsTpAccept
*&N& int    DcsTpSend
*&N& int    DcsTpSendDisc
*&N& int    DcsTpRcv
*&N& int    DcsTpDisconnect
*&N& int    DcsTpTerm
*&N& int    LoadProFunTbl
*&N& int    SrhProFunName
*&N& int    SpaceFill
*&N& void   DefServ
*&N& 
*/

/* -------------------- INCLUDE FILES DECLARATION ------------------- */
#include <fcntl.h>
#include <errno.h>
#include "aptm.h"	/* for transaction management */
#include "tp_csi.h"	/* for communication management */
#include "tp_na.h"	/* Remote client network agent protocol */
#include "xid.h"	/* XID transaction function call */
#include "errlog.h"
#include "dcs.h"

#define FUN_TOTAL	1L
#define	TXN_CODE_LEN	4
#define	AGENT_UID	"MBBHL"
#define	AGENT_PW	" "
#define	AGENT_ENDPT	"DCSTOPND"
#define	PROD_NAME_LEN	32
#define	FUNC_NAME_LEN	9
#define DUMMY_RCV_TIMEOUT  60

#define PiTpStat(p)	(p)->info->tp_extended_status

struct ProdFuncSt {
  char caTxnCode[5];
  char caProName[PROD_NAME_LEN];
  char caFunName[FUNC_NAME_LEN];
};

struct TpSessSt {
  char caDesAdd[10];
  char caSrcAdd[10];
  long lSeqNo;	
  char caProName[PROD_NAME_LEN];
  char caFunName[FUNC_NAME_LEN];
  char cStatus;
  char cLastAct;	
  char cMode; /* 'A' Active cMode 'P' Passive cMode */
};

/* ------------- dcstopnd.c function ���N�� ------------------------- */
#define P_DcsTopend 		53001
#define P_DcsTpAccept 		53002
#define P_DcsTpConnect 		53003
#define P_DcsTpDisconnect 	53004
#define P_DcsTpInit 		53005
#define P_DcsTpRcv 		53006
#define P_DcsTpReinit 		53007
#define P_DcsTpSend 		53008
#define P_DcsTpSendDisc 	53009
#define P_DcsTpTerm 		53010
#define P_DefServ 		53011
#define P_LoadProFunTbl 	53012
#define P_PiTpStat 		53013
#define P_SpaceFill 		53014
#define P_SrhProFunName 	53015

/* -------------------- STATIC GLOBAL DECLARATION ------------------- */
tp_dif_structs_t *g_pstDif;
tp_application_info_t g_stApInfo;
static char sg_cDoTopEndTerm = 'n';  /* If receive TP_SHUTDOWN then set 'y'.
                                      * DcsTpTerm() check this char to decide
                                      * to do tp_terminate() or not. */
static int gs_iMaxLoad;
static int gs_iFirst=1;              /* first flage 1=yes 0=no */
static tp_funct_struct_t gs_caFunArray[FUN_TOTAL];
static char gs_caProName[PROD_NAME_LEN];
struct ProdFuncSt g_stProFunTbl[MAX_NETWKTBL_ARRAY];
struct TpSessSt g_stTpSesTbl[MAX_SESS];

/* ------ CALL FUNCTION & SUBROUTINE PROTOTYPE DECLARATIONS --------- */
int DcsTopend(struct DcsBuf *pstDcsBuf);
int DcsTpInit(struct DcsBuf *pstDcsBuf,struct TpSessSt *pstSess,char cMode);
int DcsTpReinit(struct DcsBuf *pstDcsBuf,struct TpSessSt *pstSess,char cMode);
int DcsTpConnect(struct DcsBuf *pstDcsBuf,struct TpSessSt *pstSess);
int DcsTpAccept(struct DcsBuf *pstDcsBuf,struct TpSessSt *pstSess);
int DcsTpSend(struct DcsBuf *pstDcsBuf,struct TpSessSt *pstSess);
int DcsTpSendDisc(struct DcsBuf *pstDcsBuf,struct TpSessSt *pstSess);
int DcsTpRcv(struct DcsBuf *pstDcsBuf,struct TpSessSt *pstSess);
int DcsTpDisconnect(struct DcsBuf *pstDcsBuf,struct TpSessSt *pstSess);
int DcsTpTerm(struct DcsBuf *pstDcsBuf);
int LoadProFunTbl(struct ProdFuncSt *pstProFunTbl);
int SrhProFunName(char *pcTxnCode,char *pcProName,char *pcFunName);
int SpaceFill(char *pcS1,char *pcS2,int iLen);
void DefServ(char *);

/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   main program of interface between DCS and AP
*&D&
*/

int
DcsTopend(struct DcsBuf *pstDcsBuf)
{
  int iRc;
  char cMode;
  struct TpSessSt *pstSess;

  iRc = 0;
  UCP_TRACE(P_DcsTopend);
  ErrLog(10,"DcsTopend:Begin.",RPT_TO_LOG,0,0);

  pstSess = g_stTpSesTbl;

  switch (PcRqstCode(pstDcsBuf)){
    case DCSINITIAL:
      /* do DcsTpInit when gs_iFirst */
      if(gs_iFirst){
#ifdef III_TOPEND_SERVER
        iRc = DcsTpInit(pstDcsBuf,pstSess,'P');
#else
        iRc = DcsTpInit(pstDcsBuf,pstSess,'A');
#endif
        if(iRc != DCS_NORMAL){
           break;
        }
        gs_iFirst = 0;
      }
      break;
    case DCSCONNECT:
      /* do DcsTpInit when gs_iFirst */
      if(gs_iFirst){
        iRc = DcsTpInit(pstDcsBuf,pstSess,'A');
        if(iRc != DCS_NORMAL){
           break;
        }
        gs_iFirst = 0;
      }
      iRc = DcsTpConnect(pstDcsBuf,pstSess);
      break;
    case DCSCONNECTWRITE:
      /* do DcsTpInit when gs_iFirst */
      if(gs_iFirst){
        iRc = DcsTpInit(pstDcsBuf,pstSess,'A');
        if(iRc != DCS_NORMAL){
           break;
        }
        gs_iFirst = 0;
      }

      do { /* modify by liu for server shutdown must reinit */
         iRc = DcsTpConnect(pstDcsBuf,pstSess);
         if(iRc != DCS_NORMAL){
            break;
         }
         iRc = DcsTpSend(pstDcsBuf,pstSess);
     }while (iRc == -25);/* TP_SHUTDOWN = -25 */

      break;
#ifdef III_TOPEND_SERVER
    case DCSACCEPT:
      /* do DcsTpInit when gs_iFirst */
      if(gs_iFirst){
        iRc = DcsTpInit(pstDcsBuf,pstSess,'P');
        if(iRc != DCS_NORMAL){
           break;
        }
        gs_iFirst = 0;
      }
      iRc = DcsTpAccept(pstDcsBuf,pstSess);
      break;
    case DCSACCEPTREAD:
      /* do DcsTpInit when gs_iFirst */
      if(gs_iFirst){
        iRc = DcsTpInit(pstDcsBuf,pstSess,'P');
        if(iRc != DCS_NORMAL){
           break;
        }
        gs_iFirst = 0;
      }

      iRc = DcsTpAccept(pstDcsBuf,pstSess);
      if(iRc != DCS_NORMAL){
         break;
      }
      iRc = DcsTpRcv(pstDcsBuf,pstSess);
      break;
#endif
    case DCSWRITE:
      iRc = DcsTpSend(pstDcsBuf,pstSess);
      break;
    case DCSWRDISCONECT:
      iRc = DcsTpSendDisc(pstDcsBuf,pstSess);
      break;
    case DCSREAD:
      iRc = DcsTpRcv(pstDcsBuf,pstSess);
      break;
    case DCSDISCONNECT:
      iRc = DcsTpDisconnect(pstDcsBuf,pstSess);
      break;
    case DCSTERMINATE:
      iRc = DcsTpTerm(pstDcsBuf);
      break;
    case DCSABORT:
      iRc = 0;
      break;
    default:
      sprintf(g_caMsg,"DcsTopend:reguest error[%c]",PcRqstCode(pstDcsBuf));
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      iRc = DCS_E_COMMAND;
      break;
  } /* end of switch (PcRqstCode(pstDcsBuf)) */

  PiReply(pstDcsBuf) = iRc;

  ErrLog(10,"DcsTopend:End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(iRc);
} /* end of DcsTopend(struct DcsBuf *pstDcsBuf) */

/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   sign on to topend network agent
*&D&
*/

int
DcsTpInit(struct DcsBuf *pstDcsBuf,struct TpSessSt *pstSess,char cMode)
{
  int iRc,iIdx;
  struct ProdFuncSt *Prodfuntbl;
  
  UCP_TRACE(P_DcsTpInit);
  ErrLog(10,"DcsTpInit:Begin.",RPT_TO_LOG,0,0);

  /* load product name function name table */
  Prodfuntbl = g_stProFunTbl;
  iRc = LoadProFunTbl(Prodfuntbl);
  if(iRc != 0){
    ErrLog(1000,"DcsTpInit:load ProdFuncName table error",RPT_TO_LOG,0,0);
    PiErrno(pstDcsBuf) = errno;
    UCP_TRACE_END(iRc);
  } /* end of iRc = LoadProFunTbl(Prodfuntbl) */

  /* initial pstSession table */
  for(iIdx=0; iIdx<MAX_SESS; iIdx++){
    memset(&pstSess[iIdx], 0x0, sizeof(struct TpSessSt) );
    pstSess[iIdx].cStatus = DCS_S_FREE ;
  } /* end of for(iIdx=0; iIdx<MAX_SESS; iIdx++) */

  /* Active cMode initial */
  if(cMode == 'A'){
    iRc = tp_initialize(NULL,NULL,0);
    if(iRc != TP_OK){
       sprintf(g_caMsg,"DcsTpInit:Tp Init failed,iRc=%d,stat=%d",
               iRc,PiTpStat(g_pstDif));
       ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
       PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
       UCP_TRACE_END(iRc);
    } /* end of if(iRc != TP_OK) */
  } /* end of if(cMode == 'A') */

#ifdef III_TOPEND_SERVER
  /* Passive cMode initial */
  else{
     iRc=tp_daemonize(0);
     if(iRc != TP_OK ) {
        sprintf(g_caMsg,"DcsTpInit-p:tp_daemonize error,iRc=%d,stat=%d",
                iRc,PiTpStat(g_pstDif));
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
        UCP_TRACE_END(iRc);
     } /* end of if(iRc != TP_OK ) */
     sprintf(g_caMsg,"DcsTpInit:tp_daemonize,iRc=%d,stat=%d",
             iRc,PiTpStat(g_pstDif));
     ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
  
     /* Setup Information for available services. */
     strcpy((char *)gs_caProName, (char *)getenv("TP_PRODUCT"));
     DefServ(gs_caProName);
     
     /* SignOn to CSI to announcing available services. */
     iRc=tp_initialize(&g_stApInfo,gs_caFunArray,FUN_TOTAL);
     if(iRc != TP_OK ) {
       sprintf(g_caMsg,"DcsTpInit-p:tp_initialze error,iRc=%d,stat=%d",
               iRc,PiTpStat(g_pstDif));
       ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
       PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
       UCP_TRACE_END(iRc);
     } /* end of if(iRc != TP_OK ) */
     sprintf(g_caMsg,"DcsTpInit:tp_initialze,iRc=%d,stat=%d",
             iRc,PiTpStat(g_pstDif));
     ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
  } /* end of  /* end of if(cMode == 'A') -- else */
#endif

  /* allocate g_pstDif */
  g_pstDif = tp_csi_alloc(TP_DIF_ALL);
  if(g_pstDif == NULL){
    ErrLog(1000,"DcsTpInit:tp_csi_alloc failed",RPT_TO_LOG,0,0);
    PiErrno(pstDcsBuf) = iRc;
    iRc = tp_terminate();
    if(iRc != TP_OK){
      sprintf(g_caMsg,"DcsTpInit:Tp Term fail,iRc=%d,stat=%d",
              iRc,PiTpStat(g_pstDif));
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
    } /* end of if(iRc != TP_OK) */
    UCP_TRACE_END(iRc);
  } /* end of if(g_pstDif == NULL) */

#ifdef III_TOPEND_SERVER
   /* connect to oracle */
   iRc=oracle_connect(getenv("ORA_USER"), '1');
   if(iRc != 0) {
     sprintf(g_caMsg,"DcsTpInit:oracle_connect fail,iRc=%d,stat=%d",
             iRc,PiTpStat(g_pstDif));
     ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
     PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
     UCP_TRACE_END(iRc);
   } /* end of if(iRc != 0) */

  /* Open All Resource Managers */
  iRc=tx_open();
  if(iRc != TX_OK) {
    sprintf(g_caMsg,"DcsTpInit:tx_open fail,iRc=%d,stat=%d",
            iRc,PiTpStat(g_pstDif));
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
    UCP_TRACE_END(iRc);
  } /* end of   if(iRc != TX_OK) */
#endif
  ErrLog(10,"DcsTpInit:End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
} /* end of DcsTpInit() */
 
/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   reinitialize CSI in DcsTpConnect
*&D&
*/

int
DcsTpReinit(struct DcsBuf *pstDcsBuf,struct TpSessSt *pstSess,char cMode)
{
  int iRc,iIdx;

  UCP_TRACE(P_DcsTpReinit);
  ErrLog(10,"DcsTpReinit:Begin.",RPT_TO_LOG,0,0);

  /* initial pstSession table */
  for(iIdx=0; iIdx<MAX_SESS; iIdx++){
    memset(&pstSess[iIdx], 0x0, sizeof(struct TpSessSt) );
    pstSess[iIdx].cStatus = DCS_S_FREE ;
  } /* end of   for(iIdx=0; iIdx<MAX_SESS; iIdx++) */

  /* Active cMode */
  if(cMode == 'A') {
    iRc = tp_initialize(NULL,NULL,0);
    if(iRc != TP_OK){
      sprintf(g_caMsg,"DcsTpReinit:Tp Init failed iRc=%d,stat=%d",
              iRc,PiTpStat(g_pstDif));
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
      UCP_TRACE_END(iRc);
    } /* end of if(iRc != TP_OK) */
  } /* end of if(cMode == 'A') */

#ifdef III_TOPEND_SERVER
  /* Passive cMode initial */
  else{
    iRc=tp_daemonize(0);
    if(iRc != TP_OK ){
      sprintf(g_caMsg,"DcsTpReinit-p:tp_daemonize error,iRc=%d,stat=%d",
              iRc,PiTpStat(g_pstDif));
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
      UCP_TRACE_END(iRc);
    } /* end of if(iRc != TP_OK ) */
  
    /* Setup Information for available services. */
    strcpy((char *)gs_caProName, (char *)getenv("TP_PRODUCT"));
    DefServ(gs_caProName);
     
    /* SignOn to CSI to announcing available services. */
    iRc=tp_initialize(&g_stApInfo,gs_caFunArray,FUN_TOTAL);
    if(iRc != TP_OK ){ 
      sprintf(g_caMsg,"DcsTpReinit-p:Tp Init error,iRc=%d,stat=%d",
              iRc,PiTpStat(g_pstDif));
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
      UCP_TRACE_END(iRc);
    } /* end of if(iRc != TP_OK ) */
  } /* end of if(cMode == 'A') -- else */
#endif

  if(g_pstDif == NULL){
    g_pstDif = tp_csi_alloc(TP_DIF_ALL);
    if(g_pstDif == NULL){
      ErrLog(1000,"DcsTpReinit:tp_csi_alloc failed",RPT_TO_LOG,0,0);
      iRc = tp_terminate();
      if(iRc != TP_OK){
        sprintf(g_caMsg,"DcsTpReinit:Tp Term fail iRc=%d,stat=%d",
                iRc,PiTpStat(g_pstDif));
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
      } /* end of if(iRc != TP_OK) */
      UCP_TRACE_END(iRc);
    } /* end of if(g_pstDif == NULL) */
  } /* end of if(g_pstDif == NULL) */

  ErrLog(10,"DcsTpReinit:End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
} /* end of DcsTpReinit() */

/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   establish a dialogue to topend node manager
*&D&
*/

int
DcsTpConnect(struct DcsBuf *pstDcsBuf,struct TpSessSt *pstSess)
{
  int iIdx;
  int iRc, iMsgLen;
  char caTxnCode[5];
  char caProdName[PROD_NAME_LEN];
  char caFuncName[FUNC_NAME_LEN];
  char caTmpBuf[1024];
  int resignon; /* flags for resignon CSI 1:yes 0:no */

  UCP_TRACE(P_DcsTpConnect);
  ErrLog(10,"DcsTpConnect:Begin.",RPT_TO_LOG,0,0);

  /* search a usable dialogue  */
  iIdx = 1;
  while(pstSess[iIdx].cStatus != DCS_S_FREE &&
        pstSess[iIdx].cStatus != DCS_S_ERROR &&
        pstSess[iIdx].cStatus != DCS_S_USABLE &&
        iIdx < MAX_SESS) iIdx++;

  if(iIdx == MAX_SESS){
    PiErrno(pstDcsBuf) = DCS_ES_SESOVERFLW;
    UCP_TRACE_END(DCS_E_LOCALDCS);
  }

  if(pstSess[iIdx].cStatus == DCS_S_FREE ||
     pstSess[iIdx].cStatus == DCS_S_ERROR){
    memset(&pstSess[iIdx], 0x0, sizeof(struct TpSessSt) );
    pstSess[iIdx].cStatus = DCS_S_USED ;

    /* prepare data for sign on */
    /* set the user dialogue id, message id and system dialogue id */
    do{
      resignon = 0; /* set reinitialize off */
      g_pstDif->info->tp_user_dialogue_id = iIdx;
      g_pstDif->info->tp_user_message_id = 0L;
      g_pstDif->info->tp_system_dialogue_id.tp_sys_dialogue = 0L;
      g_pstDif->info->tp_flags = TP_NOFLAGS;
      /* set security parameters */
      SpaceFill(g_pstDif->client->tp_userid,AGENT_UID,TP_USERID_LEN);
      SpaceFill(g_pstDif->client->tp_password,AGENT_PW,TP_PASSWORD_LEN);
      SpaceFill(g_pstDif->client->tp_endpoint,AGENT_ENDPT,TP_ENDPOINT_LEN);
 
      /* establish a dialogue */
      iRc=tp_client_signon(g_pstDif->info,g_pstDif->client,
                           0L,NULL,NULL,0,NULL);
      if(iRc != TP_OK){
        sprintf(g_caMsg,"DcsTpConnect:Tp Signon fail iRc=%d,stat=%d",
                iRc,PiTpStat(g_pstDif));
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);

        /* if sign on function return TP_INIT than do reinitialize */
        if((iRc == TP_INIT)||(iRc == TP_DIFERR)||(iRc == TP_SHUTDOWN)){
          /* prepare data for sign on */
          /* set the user dialogue id, message id and system dialogue id */
          g_pstDif->info->tp_user_dialogue_id = iIdx;
          g_pstDif->info->tp_user_message_id = 0L;
          g_pstDif->info->tp_system_dialogue_id.tp_sys_dialogue = 0L;
          g_pstDif->info->tp_flags = TP_NOFLAGS;
        
          iRc=DcsTpReinit(pstDcsBuf,pstSess,'A');
          if(iRc != TP_OK){
            sprintf(g_caMsg,"DcsTpConnect:DcsTpReinit fail iRc=%d,stat=%d",
                    iRc,PiTpStat(g_pstDif));
            ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
            PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
            UCP_TRACE_END(iRc);
          }
          resignon = 1; /* reinitial success and set resignon on */
          continue;     /* added by WuChihLiang 19950317  for continue signon */
        } /*if((iRc == TP_INIT)||(iRc == TP_DIFERR))*/

        PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
        UCP_TRACE_END(iRc);
      } /* tp_client_signon != TP_OK */
    } while(resignon == 1);
   
    /*iMsgLen = 0;*/
    iMsgLen = DCS_MAX_DATA_LEN;
    iRc=tp_client_receive(g_pstDif->info,TP_BLOCK,g_pstDif->output_format,
                       /*g_pstDif->service,g_pstDif->location,&iMsgLen,NULL);*/
                       g_pstDif->service,g_pstDif->location,&iMsgLen,caTmpBuf);
    if(iRc != TP_OK){
      sprintf(g_caMsg,"DcsTpConnect:Client Rcv fail,iRc=%d,stat=%d",
              iRc,PiTpStat(g_pstDif));
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
      UCP_TRACE_END(iRc);
    }
  }
      
  /* get txn code from pstDcsBuf */
  memcpy(caTxnCode,PcaServCode(pstDcsBuf),TXN_CODE_LEN);
  
  /* search product name and function name */
  iRc=SrhProFunName(caTxnCode,caProdName,caFuncName);
  if(iRc != 0){
    ErrLog(1000,"DcsTpConnect:SrhProFunName fail",RPT_TO_LOG,0,0);
    PiErrno(pstDcsBuf) = iRc;
    UCP_TRACE_END(DCS_E_NETWORKTBL);
  }

  /* save the pstSession information */
  pstSess[iIdx].cStatus = DCS_S_USED ;
  pstSess[iIdx].cLastAct = DCSCONNECT;
  memcpy(pstSess[iIdx].caProName,caProdName,PROD_NAME_LEN);
  memcpy(pstSess[iIdx].caFunName,caFuncName,FUNC_NAME_LEN); 
  pstSess[iIdx].lSeqNo = g_pstDif->info->tp_user_message_id;
  pstSess[iIdx].cMode = ACTIVE_MODE;

  /* fill DCS buff */
  PiSesIdx(pstDcsBuf) = iIdx;
  PlSeqNo(pstDcsBuf) = pstSess[iIdx].lSeqNo;
  PiErrno(pstDcsBuf) = 0;
  PcProto(pstDcsBuf) = TOPEND_DCS;

  ErrLog(10,"DcsTpConnect:End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}

/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   establish a dialogue to topend node manager
*&D&
*/

#ifdef III_TOPEND_SERVER
int
DcsTpAccept(struct DcsBuf *pstDcsBuf,struct TpSessSt *pstSess)
{
  int iIdx;
  int iRc, iMsgLen;

  UCP_TRACE(P_DcsTpAccept);
  ErrLog(10,"DcsTpAccept:Begin.",RPT_TO_LOG,0,0);

  /* search a usable dialogue  */
  iIdx = 1;
  while(pstSess[iIdx].cStatus != DCS_S_FREE &&
        pstSess[iIdx].cStatus != DCS_S_ERROR &&
        pstSess[iIdx].cStatus != DCS_S_USABLE &&
        iIdx < MAX_SESS) iIdx++;

  if(iIdx == MAX_SESS){
    PiErrno(pstDcsBuf) = DCS_ES_SESOVERFLW;
    UCP_TRACE_END(DCS_E_LOCALDCS);
  }

  /* initial value of pstSession */
  if(pstSess[iIdx].cStatus == DCS_S_FREE ||
     pstSess[iIdx].cStatus == DCS_S_ERROR){
    memset(&pstSess[iIdx], 0x0, sizeof(struct TpSessSt) );
    pstSess[iIdx].cStatus = DCS_S_USED ;
  }

#ifdef LIU
  /* prepare to call tp_server_receive */
  g_pstDif->info->tp_flags=TP_NOFLAGS;
  PiTpStat(g_pstDif)=0;
  iMsgLen = PiDataLen(pstDcsBuf);

  /* call tp_server_receive */
  iRc=tp_server_receive(g_pstDif->info,TP_BLOCK,g_pstDif->service,
                        g_pstDif->input_format,g_pstDif->location,
                        g_pstDif->source_info,&iMsgLen,PunData(pstDcsBuf));
  switch(iRc) {
     case TP_OK:
        break;
     case TP_SHUTDOWN:
     case TP_CLEAN_SHUTDOWN:
        sg_cDoTopEndTerm = 'y';
        ErrLog(99999,"DcsTpAccept:receive SHUTDOWN",RPT_TO_LOG,0,0);
        break;
     case TP_RESET:
     case TP_DISSOLVED:
     case TP_PROTOERR:
     case TP_DISCONNECT:
     case TP_DISSOLVING:
     case TP_PARAMERR:
        sprintf(g_caMsg,"DcsTpAccept:Serv Rcv fail iRc=%d,stat=%d",
                iRc,PiTpStat(g_pstDif));
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        pstSess[iIdx].cStatus = DCS_S_ERROR;
        PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
        UCP_TRACE_END(iRc);
     default:
        sprintf(g_caMsg,"DcsTpAccept:Serv Rcv fail iRc=%d,stat=%d",
                iRc,PiTpStat(g_pstDif));
        ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
        pstSess[iIdx].cStatus = DCS_S_ERROR;
        PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
        UCP_TRACE_END(iRc);
  }   /* End of switch */
#endif

  /* save the pstSession information */
  pstSess[iIdx].cStatus = DCS_S_USED ;
  pstSess[iIdx].cLastAct = DCSACCEPT;
  pstSess[iIdx].cMode = PASSIVE_MODE;

  /* fill DCS buff */
  PiSesIdx(pstDcsBuf) = iIdx;
  PiErrno(pstDcsBuf) = 0;
  PcProto(pstDcsBuf) = TOPEND_DCS;

  ErrLog(10,"DcsTpAccept:End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}
#endif

/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   reguest a service to a server in host
*&D&
*/

int
DcsTpSend(struct DcsBuf *pstDcsBuf,struct TpSessSt *pstSess)
{
  int iIdx;
  int iRc;
  long iMsgLen;
  char caTmpBuf[1024];

  UCP_TRACE(P_DcsTpSend);
  ErrLog(10,"DcsTpSend:Begin.",RPT_TO_LOG,0,0);

  /* Is the dialogue usable */
  iIdx = PiSesIdx(pstDcsBuf);
  if(iIdx > 0){
    if(pstSess[iIdx].cStatus != DCS_S_USED || iIdx >= MAX_SESS){
      sprintf(g_caMsg,"DcsTpSend:unusable Session iIdx=%d!",iIdx);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = DCS_ES_SESUNUSE;
      UCP_TRACE_END(DCS_E_COMMAND);
    }

    /* Is the message id correct */
    if(PlSeqNo(pstDcsBuf) != pstSess[iIdx].lSeqNo &&
       pstSess[iIdx].cMode == ACTIVE_MODE){
      ErrLog(1000,"DcsTpSend:incorrect Msg id!",RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = DCS_ES_SEQNO;
      UCP_TRACE_END(DCS_E_COMMAND);
    }
  }

  /* Is the last operation`s flags "DCSWRITE" */
  if(pstSess[iIdx].cLastAct == DCSWRITE){
    /*iMsgLen = 0;*/
    iMsgLen = DCS_MAX_DATA_LEN;
    /* Active receive */
    if(pstSess[iIdx].cMode == ACTIVE_MODE){
      g_pstDif->info->tp_flags = TP_NOFLAGS;
      iRc=tp_client_receive(g_pstDif->info,DUMMY_RCV_TIMEOUT,g_pstDif->output_format,
                       g_pstDif->service,g_pstDif->location,&iMsgLen,caTmpBuf);
                       /*g_pstDif->service,g_pstDif->location,&iMsgLen,NULL);*/
      if(iRc != TP_OK){
        sprintf(g_caMsg,"DcsTpSend:Client Rcv fail,iRc=%d,stat=%d",
                iRc,PiTpStat(g_pstDif));
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
        if(iRc == TP_TIMEOUT) UCP_TRACE_END(DCS_E_TIMEOUT);
        pstSess[iIdx].cStatus = DCS_S_ERROR;
        UCP_TRACE_END(iRc);
      }
      pstSess[iIdx].cLastAct = DCSREAD;
    }

#ifdef III_TOPEND_SERVER
    /* Passive receive */
    else {
      g_pstDif->info->tp_flags = TP_NOFLAGS;
      PiTpStat(g_pstDif)=0;
      /*iMsgLen = 0;*/
      iMsgLen = DCS_MAX_DATA_LEN;
      iRc=tp_server_receive(g_pstDif->info,TP_BLOCK,g_pstDif->service,
                            g_pstDif->input_format,g_pstDif->location,
                            g_pstDif->source_info,&iMsgLen,caTmpBuf);
      switch(iRc) {
        case TP_OK:
          break;
        case TP_SHUTDOWN:
        case TP_CLEAN_SHUTDOWN:
          sg_cDoTopEndTerm = 'y';
          ErrLog(99999,"DcsTpSend-P:dummy recv SHUTDOWN",RPT_TO_LOG,0,0);
          break;
        default:
          sprintf(g_caMsg,"DcsTpSend-p:dummy Serv Rcv fail,iRc=%d,stat=%d",
                  iRc,PiTpStat(g_pstDif));
          ErrLog(4000,g_caMsg,RPT_TO_LOG,0,0);
          pstSess[iIdx].cStatus = DCS_S_ERROR;
          PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
          UCP_TRACE_END(iRc);
      } /* End of switch */
    }
#endif
  }

  /* Active cMode send */
  if(pstSess[iIdx].cMode == 'A'){
    /* prepare data for reguesting service */
    /* set the user dialogue id, message id */
    g_pstDif->info->tp_user_dialogue_id = iIdx;
    g_pstDif->info->tp_user_message_id++;
    g_pstDif->info->tp_flags = TP_NOFLAGS;
    /* Specify the service being reguest */
    SpaceFill(g_pstDif->service->tp_product_name,pstSess[iIdx].caProName,
               TP_PROD_NAME_LEN);
    SpaceFill(g_pstDif->service->tp_function_name,pstSess[iIdx].caFunName,
               TP_FUNC_NAME_LEN);
    g_pstDif->service->tp_function_qualifier = 0;
    memset(g_pstDif->input_format,' ',TP_FMT_NAME_LEN);
    PiTpStat(g_pstDif) = 0;
    iMsgLen = PiDataLen(pstDcsBuf);
     
    /* for debug dump send data */
    ErrLog(10,"DcsTpSend: Client Send Data=",RPT_TO_LOG,
           PunData(pstDcsBuf),iMsgLen);

    /* send a service reguest */
    iRc=tp_client_send(g_pstDif->info,g_pstDif->service,
                       g_pstDif->input_format,iMsgLen,PunData(pstDcsBuf));
    if(iRc != TP_OK){
      sprintf(g_caMsg,"DcsTpSend:Client Snd fail iRc=%d,stat=%d",
              iRc,PiTpStat(g_pstDif));
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstSess[iIdx].cStatus = DCS_S_ERROR;
      PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
      UCP_TRACE_END(iRc);
    }
  }

#ifdef III_TOPEND_SERVER
  /* Passive cMode send */
  else{
    /* prepare data for calling tp_server_send */
    SpaceFill(g_pstDif->output_format->tp_format_name," ",TP_FMT_NAME_LEN);
    g_pstDif->info->tp_flags=TP_APPL_CONTEXT;
    PiTpStat(g_pstDif)=0;
    iMsgLen = PiDataLen(pstDcsBuf);

    /* for debug dump send data */
    ErrLog(10,"DcsTpSend: Server Send Data=",RPT_TO_LOG,
           PunData(pstDcsBuf),iMsgLen);

    /* call topend tp_server_send */
    iRc=tp_server_send(g_pstDif->info,g_pstDif->output_format,
                       iMsgLen,PunData(pstDcsBuf));
    if(iRc != TP_OK){ 
      sprintf(g_caMsg,"DcsTpSend:Serv Snd fail,iRc=%d,stat=%d",
              iRc,PiTpStat(g_pstDif));
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstSess[iIdx].cStatus = DCS_S_ERROR;
      PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
      UCP_TRACE_END(iRc);
    }
  }
#endif
  
  /* save the pstSession information */
  pstSess[iIdx].cLastAct = DCSWRITE;
  memset(pstSess[iIdx].caProName,' ',TP_PROD_NAME_LEN);
  memset(pstSess[iIdx].caFunName,' ',TP_FUNC_NAME_LEN);

  /* fill DCS buf */
  PiErrno(pstDcsBuf) = 0;

  if(iIdx == 0 && (pstSess[iIdx].cStatus == DCS_S_FREE ||
                   pstSess[iIdx].cStatus == DCS_S_USABLE)){
     pstSess[iIdx].cStatus = DCS_S_USED ;
     pstSess[iIdx].cMode = PASSIVE_MODE;
     PcProto(pstDcsBuf) = TOPEND_DCS;
  }

  ErrLog(10,"DcsTpSend:End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}

/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   reguest a service to a server in host and disconnect
*&D&
*/

int
DcsTpSendDisc(struct DcsBuf *pstDcsBuf,struct TpSessSt *pstSess)
{
  int iIdx;
  int iRc, iMsgLen;
  char caTmpBuf[1024];

  UCP_TRACE(P_DcsTpSendDisc);
  ErrLog(10,"DcsTpSendDisc:Begin.",RPT_TO_LOG,0,0);

  /* Is the dialogue usable */
  iIdx = PiSesIdx(pstDcsBuf);
  if(iIdx > 0){
    if(pstSess[iIdx].cStatus != DCS_S_USED || iIdx >= MAX_SESS){
      sprintf(g_caMsg,"DcsTpSendDisc:unusable Session iIdx=%d",iIdx);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = DCS_ES_SESUNUSE;
      UCP_TRACE_END(DCS_E_COMMAND);
    }

    /* Is the message id correct */
    if(PlSeqNo(pstDcsBuf) != pstSess[iIdx].lSeqNo &&
       pstSess[iIdx].cMode == ACTIVE_MODE){
      ErrLog(1000,"DcsTpSendDisc:Msg id error!",RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = DCS_ES_SEQNO;
      UCP_TRACE_END(DCS_E_COMMAND);
    }
  }

  /* Is the last operation`s flags "DCSWRITE" */
  if(pstSess[iIdx].cLastAct == DCSWRITE){

    /* Active receive */
    /*iMsgLen = 0;*/
    iMsgLen = DCS_MAX_DATA_LEN;
    if(pstSess[iIdx].cMode == ACTIVE_MODE){
      g_pstDif->info->tp_flags=TP_NOFLAGS;
      iRc=tp_client_receive(g_pstDif->info,DUMMY_RCV_TIMEOUT,g_pstDif->output_format,
                       g_pstDif->service,g_pstDif->location,&iMsgLen,caTmpBuf);
                       /*g_pstDif->service,g_pstDif->location,&iMsgLen,NULL);*/
      if(iRc != TP_OK){
        sprintf(g_caMsg,"DcsTpSendDisc:dummy Client Rcv fail,iRc=%d,stat=%d",
                iRc,PiTpStat(g_pstDif));
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
        if(iRc == TP_TIMEOUT) UCP_TRACE_END(DCS_E_TIMEOUT);
        pstSess[iIdx].cStatus = DCS_S_ERROR;
        UCP_TRACE_END(iRc);
      }
      pstSess[iIdx].cLastAct = DCSREAD;
    }

#ifdef III_TOPEND_SERVER
    /* Passive receive */
    else {
      g_pstDif->info->tp_flags=TP_NOFLAGS;
      PiTpStat(g_pstDif)=0;
      /*iMsgLen = 0;*/
      iMsgLen = DCS_MAX_DATA_LEN;
      iRc=tp_server_receive(g_pstDif->info,TP_BLOCK,g_pstDif->service,
                            g_pstDif->input_format,g_pstDif->location,
                            g_pstDif->source_info,&iMsgLen,caTmpBuf);
      switch(iRc) {
        case TP_OK:
          break;
        case TP_SHUTDOWN:
        case TP_CLEAN_SHUTDOWN:
          sg_cDoTopEndTerm = 'y';
          ErrLog(99999,"DcsTpSendDisc-P:dummy receive SHUTDOWN",
                  RPT_TO_LOG,0,0);
          break;
        default:
          sprintf(g_caMsg,"DcsTpSendDisc-P:dummy Serv Rcv fail iRc=%d,stat=%d",
                  iRc,PiTpStat(g_pstDif));
          ErrLog(4000,g_caMsg,RPT_TO_LOG,0,0);
          pstSess[iIdx].cStatus = DCS_S_ERROR;
          PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
          UCP_TRACE_END(iRc);
      } /* End of switch */
    }
#endif
  }

  /* Active cMode send */
  if(pstSess[iIdx].cMode == 'A'){
    /* prepare data for reguesting service */
    /* set the user dialogue id, message id */
    g_pstDif->info->tp_user_dialogue_id = iIdx;
    g_pstDif->info->tp_user_message_id++;
    g_pstDif->info->tp_flags = TP_NOFLAGS;
    /* Specify the service being reguest */
    SpaceFill(g_pstDif->service->tp_product_name,pstSess[iIdx].caProName,
               TP_PROD_NAME_LEN);
    SpaceFill(g_pstDif->service->tp_function_name,pstSess[iIdx].caFunName,
               TP_FUNC_NAME_LEN);
    g_pstDif->service->tp_function_qualifier = 0;
    memset(g_pstDif->input_format,' ',TP_FMT_NAME_LEN);
    PiTpStat(g_pstDif) = 0;
    iMsgLen = PiDataLen(pstDcsBuf);
     
    /* for debug dump send data */
    ErrLog(10,"DcsTpSendDisc: Client Send Data=",RPT_TO_LOG,
           PunData(pstDcsBuf),iMsgLen);

    /* send a service reguest */
    iRc=tp_client_send(g_pstDif->info,g_pstDif->service,g_pstDif->input_format,
                       (long)iMsgLen,PunData(pstDcsBuf));
    if(iRc != TP_OK){
      sprintf(g_caMsg,"DcsTpSendDisc:Client Snd fail,iRc=%d,stat=%d",
              iRc,PiTpStat(g_pstDif));
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstSess[iIdx].cStatus = DCS_S_ERROR;
      PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
      UCP_TRACE_END(iRc);
    }
  }

#ifdef III_TOPEND_SERVER
  /* Passive cMode send */
  else{
    /* prepare data for calling tp_server_send */
    SpaceFill(g_pstDif->output_format->tp_format_name," ",TP_FMT_NAME_LEN);
    g_pstDif->info->tp_flags=TP_NOFLAGS;
    PiTpStat(g_pstDif)=0;
    iMsgLen = PiDataLen(pstDcsBuf);

    /* for debug dump send data */
    ErrLog(10,"DcsTpSendDisc: Server Send Data=",RPT_TO_LOG,
           PunData(pstDcsBuf),iMsgLen);

    /* call topend tp_server_send */
    iRc=tp_server_send(g_pstDif->info,g_pstDif->output_format,
                       iMsgLen,PunData(pstDcsBuf));
    if(iRc != TP_OK){ 
      sprintf(g_caMsg,"DcsTpSendDisc-P:Serv Snd fail iRc=%d,stat=%d",
              iRc,PiTpStat(g_pstDif));
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstSess[iIdx].cStatus = DCS_S_ERROR;
      PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
      UCP_TRACE_END(iRc);
    }
  }
#endif

  /* save the pstSession information */
  pstSess[iIdx].cLastAct = DCSWRDISCONECT;
  pstSess[iIdx].cStatus = DCS_S_USABLE;
  pstSess[iIdx].lSeqNo = 0;
  pstSess[iIdx].cMode = ' ';

  /* fill DCS buff */
  PiErrno(pstDcsBuf) = 0;
  
  ErrLog(10,"DcsTpSendDisc:End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(iRc);
}

/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   receive a responce from a server after a regueast
*&D&
*/

int
DcsTpRcv(struct DcsBuf *pstDcsBuf,struct TpSessSt *pstSess)
{
  int iIdx;
  int iRc, iMsgLen;

  UCP_TRACE(P_DcsTpRcv);
  ErrLog(10,"DcsTpRcv:Begin.",RPT_TO_LOG,0,0);

  /* Is the dialogue usable */
  iIdx = PiSesIdx(pstDcsBuf);
  if(iIdx > 0){
    if(pstSess[iIdx].cStatus != DCS_S_USED || iIdx >= MAX_SESS){
      sprintf(g_caMsg,"DcsTpRcv:unusable Session iIdx=%d",iIdx);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = DCS_ES_SESUNUSE;
      UCP_TRACE_END(DCS_E_COMMAND);
    }
  }

  /* Is the message id correct */
  if(PlSeqNo(pstDcsBuf) != pstSess[iIdx].lSeqNo &&
     pstSess[iIdx].cMode == ACTIVE_MODE){
    sprintf(g_caMsg,"DcsTpRcv:Msg id error!,iIdx=%d,lSeqNo=%d,PlSeqNo=%d"
            ,iIdx,pstSess[iIdx].lSeqNo,PlSeqNo(pstDcsBuf));
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    PiErrno(pstDcsBuf) = DCS_ES_SEQNO;
    UCP_TRACE_END(DCS_E_COMMAND);
  }

  /* Is the last operation`s flags "DCSREAD" */
  if(pstSess[iIdx].cLastAct == DCSREAD){
    /* Active cMode */
    if(pstSess[iIdx].cMode == ACTIVE_MODE){
      /* prepare data for reguesting a dummy service */
      /* set the user dialogue id, message id */
      g_pstDif->info->tp_user_dialogue_id = iIdx;
      g_pstDif->info->tp_user_message_id++;
      g_pstDif->info->tp_flags = TP_APPL_CONTEXT;
      /* Specify the service being reguest */
      SpaceFill(g_pstDif->service->tp_product_name," ",TP_PROD_NAME_LEN);
      SpaceFill(g_pstDif->service->tp_function_name," ",TP_FUNC_NAME_LEN);
      g_pstDif->service->tp_function_qualifier = 0;
   
      /* send a service reguest */
      iRc=tp_client_send(g_pstDif->info,g_pstDif->service,NULL,0L,NULL);
      if(iRc != TP_OK){
        sprintf(g_caMsg,"DcsTpRcv:Client Snd fail iRc=%d,stat=%d",
                iRc,PiTpStat(g_pstDif));
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        pstSess[iIdx].cStatus = DCS_S_ERROR;
        PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
        UCP_TRACE_END(iRc);
      }
      pstSess[iIdx].cLastAct = DCSWRITE;
    } 

#ifdef III_TOPEND_SERVER
    /* Passive cMode send */
    else{
      /* prepare data for calling tp_server_send */
      SpaceFill(g_pstDif->output_format->tp_format_name," ",TP_FMT_NAME_LEN);
      g_pstDif->info->tp_flags = TP_APPL_CONTEXT;
      PiTpStat(g_pstDif)=0;

      /* call topend tp_server_send */
      iRc=tp_server_send(g_pstDif->info,g_pstDif->output_format,0L,
                         PunData(pstDcsBuf));
      if(iRc != TP_OK){ 
        sprintf(g_caMsg,"DcsTpRcv-P:dummy Serv Snd fail iRc=%d,stat=%d",
                iRc,PiTpStat(g_pstDif));
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        pstSess[iIdx].cStatus = DCS_S_ERROR;
        PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
        UCP_TRACE_END(iRc);
      }
    }
#endif
  }

  /* Active receive */
  if(pstSess[iIdx].cMode == 'A'){
    /* prepare data for receive a responce from server */
    /* set the user dialogue id, message id */
    g_pstDif->info->tp_user_dialogue_id = iIdx;
    g_pstDif->info->tp_user_message_id++;
    g_pstDif->info->tp_flags = TP_NOFLAGS;
    iMsgLen = PiDataLen(pstDcsBuf);
    iRc=tp_client_receive(g_pstDif->info,PlWaiTime(pstDcsBuf),
                          g_pstDif->output_format,g_pstDif->service,
                          g_pstDif->location,&iMsgLen,PunData(pstDcsBuf));
    if(iRc != TP_OK){
      sprintf(g_caMsg,"DcsTpRcv:Client Rcv fail,iRc=%d,stat=%d",
              iRc,PiTpStat(g_pstDif));
       ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
       PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
       if(iRc == TP_TIMEOUT) UCP_TRACE_END(DCS_E_TIMEOUT);
       pstSess[iIdx].cStatus = DCS_S_ERROR;
       UCP_TRACE_END(iRc);
     }

   /*if((iMsgLen < 9) && (g_pstDif->info->tp_flags == TP_NOFLAGS)){
       ErrLog(1000,"DcsTpRcv:Client Rcv iMsgLen<9 & TP_NOFLAGS",
              RPT_TO_LOG,0,0);
       pstSess[iIdx].cStatus = DCS_S_ERROR;
       PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
       UCP_TRACE_END(DCS_E_RCV_DISCONNECT);
     }*/

     /* for debug dump send data */
     ErrLog(10,"DcsTpRcv: Client Rcv Data=",RPT_TO_LOG,
            PunData(pstDcsBuf),iMsgLen);

  }

#ifdef III_TOPEND_SERVER
  /* Passive receive */
  else {
    g_pstDif->info->tp_flags=TP_NOFLAGS;
    PiTpStat(g_pstDif)=0;
    iMsgLen = PiDataLen(pstDcsBuf);
    iRc=tp_server_receive(g_pstDif->info,PlWaiTime(pstDcsBuf),g_pstDif->service,
                          g_pstDif->input_format,g_pstDif->location,
                          g_pstDif->source_info,&iMsgLen,PunData(pstDcsBuf));
    switch(iRc) {
      case TP_OK:
        break;
      case TP_SHUTDOWN:
      case TP_CLEAN_SHUTDOWN:
        sg_cDoTopEndTerm = 'y';
        ErrLog(99999,"DcsTpRcv-P:receive SHUTDOWN",RPT_TO_LOG,0,0);
        break;
      case TP_RESET:
      case TP_DISSOLVED:
      case TP_PROTOERR:
      case TP_DISCONNECT:
      case TP_DISSOLVING:
      case TP_PARAMERR:
      case TP_TIMEOUT:
        sprintf(g_caMsg,"DcsTpRcv:Serv Rcv fail iRc=%d,stat=%d",
                iRc,PiTpStat(g_pstDif));
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
        if(iRc == TP_TIMEOUT) UCP_TRACE_END(DCS_E_TIMEOUT);
        pstSess[iIdx].cStatus = DCS_S_ERROR;
        UCP_TRACE_END(iRc);
      default:
        sprintf(g_caMsg,"DcsTpRcv-P:Serv Rcv fail iRc=%d,stat=%d",
                iRc,PiTpStat(g_pstDif));
        ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
        pstSess[iIdx].cStatus = DCS_S_ERROR;
        PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
        UCP_TRACE_END(iRc);
     } /* End of switch */

     /* for debug dump send data */
     ErrLog(10,"DcsTpRcv: Server Rcv Data=",RPT_TO_LOG,
            PunData(pstDcsBuf),iMsgLen);
  }

#endif

  /* save the pstSession information */
  pstSess[iIdx].cLastAct = DCSREAD;
  if(g_pstDif->info->tp_flags == TP_NOFLAGS && pstSess[iIdx].cMode == 'A'){
    pstSess[iIdx].cStatus = DCS_S_USABLE;
  }

  if(iIdx == 0 && (pstSess[iIdx].cStatus == DCS_S_FREE ||
                   pstSess[iIdx].cStatus == DCS_S_USABLE)){
    pstSess[iIdx].cStatus = DCS_S_USED ;
    pstSess[iIdx].cMode = PASSIVE_MODE;
    PcProto(pstDcsBuf) = TOPEND_DCS;
  }

  /* fill DCS buf */
  PiDataLen(pstDcsBuf) = iMsgLen;
  PiErrno(pstDcsBuf) = 0;

  ErrLog(10,"DcsTpRcv:End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}

/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   sign off to topend network agent
*&D&
*/

int
DcsTpDisconnect(struct DcsBuf *pstDcsBuf,struct TpSessSt *pstSess)
{
  int iIdx;
  int iRc, iMsgLen;
  char caTmpBuf[1024];

  UCP_TRACE(P_DcsTpDisconnect);
  ErrLog(10,"DcsTpDisconnect:Begin.",RPT_TO_LOG,0,0);

  /* Is the dialogue usable */
  iIdx = PiSesIdx(pstDcsBuf);
  sprintf(g_caMsg,"DcsTpDisconnect:pstSess[%d].cStatus=%d",iIdx,
          pstSess[iIdx].cStatus);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
  if(iIdx > 0){
    if(pstSess[iIdx].cStatus == DCS_S_FREE || iIdx >= MAX_SESS){
      sprintf(g_caMsg,"DcsTpDisconnect:unusable Session iIdx=%d",iIdx);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = DCS_ES_SESUNUSE;
      UCP_TRACE_END(DCS_E_COMMAND);
    }
  }

  /* prepare data for sign on */
  if(pstSess[iIdx].cMode == 'A'){
    if(pstSess[iIdx].cStatus == DCS_S_USED){
      /* a while loop tp_client_receive for clear some msg queue in network
         buf send by server */
      do{
        if(pstSess[iIdx].cLastAct == DCSREAD){
          /* prepare data for reguesting a dummy service */
          /* set the user dialogue id, message id */
          g_pstDif->info->tp_user_dialogue_id = iIdx;
          g_pstDif->info->tp_user_message_id++;
          g_pstDif->info->tp_flags = TP_NOFLAGS;
          /* Specify the service being reguest */
          SpaceFill(g_pstDif->service->tp_product_name," ",TP_PROD_NAME_LEN);
          SpaceFill(g_pstDif->service->tp_function_name," ",TP_FUNC_NAME_LEN);
          g_pstDif->service->tp_function_qualifier = 0;
       
          /* send a service reguest */
          iRc=tp_client_send(g_pstDif->info,g_pstDif->service,NULL,0L,NULL);
          if(iRc != TP_OK){
            sprintf(g_caMsg,
                    "DcsTpDisconnect:dummy Client Snd fail iRc=%d,stat=%d",
                    iRc,PiTpStat(g_pstDif));
            ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          }
          pstSess[iIdx].cLastAct = DCSWRITE;
        } 

        iMsgLen = DCS_MAX_DATA_LEN;
        iRc=tp_client_receive(g_pstDif->info,DUMMY_RCV_TIMEOUT,g_pstDif->output_format,
                              g_pstDif->service,g_pstDif->location,
                              &iMsgLen,caTmpBuf);
        if((iRc != TP_OK) && (iRc != TP_TIMEOUT)){
          sprintf(g_caMsg,"DcsTpDisconnect:Client Rcv fail,iRc=%d,stat=%d",
                  iRc,PiTpStat(g_pstDif));
          ErrLog(1000,g_caMsg,RPT_TO_LOG,caTmpBuf,iMsgLen);
        }
        pstSess[iIdx].cLastAct = DCSREAD;

        if(iRc == TP_TIMEOUT){
          sprintf(g_caMsg,"DcsTpDisconnect:Client Rcv fail,iRc=%d,stat=%d",
                  iRc,PiTpStat(g_pstDif));
          ErrLog(1000,g_caMsg,RPT_TO_LOG,caTmpBuf,iMsgLen);
        }
        sprintf(g_caMsg,"DcsTpDisconnect:Client Rcv ok,iRc=%d,stat=%d",
                iRc,PiTpStat(g_pstDif));
        ErrLog(100,g_caMsg,RPT_TO_LOG,caTmpBuf,iMsgLen);
      } while((iMsgLen > 8) && (iRc == TP_OK) &&
              (g_pstDif->info->tp_flags == TP_APPL_CONTEXT));
    }

    /* keep 2 dialogue for reuse don`t need signon & signoff */
    if((iIdx > 2) || (pstSess[iIdx].cStatus == DCS_S_ERROR)){
      /* add for receive server disconnect send a TP_NOFLAGS */
      /* set the user dialogue id, message id and system dialogue id */
      g_pstDif->info->tp_user_dialogue_id = iIdx;
      g_pstDif->info->tp_user_message_id = 0L;
      g_pstDif->info->tp_system_dialogue_id.tp_sys_dialogue = 0L;
      g_pstDif->info->tp_flags = TP_NOFLAGS;

      /* dissolve a dialogue */
      iRc=tp_client_signoff(g_pstDif->info);
      if(iRc != TP_OK){
        sprintf(g_caMsg,"DcsTpDisconnect:Tp Signoff fail iRc=%d,stat=%d",
                iRc,PiTpStat(g_pstDif));
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        pstSess[iIdx].cStatus = DCS_S_ERROR;
        PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
        UCP_TRACE_END(iRc);
      }

      /*iMsgLen = 0;*/
      iMsgLen = DCS_MAX_DATA_LEN;
      iRc=tp_client_receive(g_pstDif->info,TP_BLOCK,g_pstDif->output_format,
                            g_pstDif->service,g_pstDif->location,&iMsgLen,
                            caTmpBuf);
      if(iRc != TP_OK){
        sprintf(g_caMsg,"DcsTpDisconnect:Client Rcv fail,iRc=%d,stat=%d",
                iRc,PiTpStat(g_pstDif));
        ErrLog(1000,g_caMsg,RPT_TO_LOG,caTmpBuf,iMsgLen);
        pstSess[iIdx].cStatus = DCS_S_ERROR;
        PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
        UCP_TRACE_END(iRc);
      }
    }
  }

#ifdef III_TOPEND_SERVER
  /*else{*/
  if((pstSess[iIdx].cMode == 'P') && (pstSess[iIdx].cStatus == DCS_S_USED)){
    if(pstSess[iIdx].cLastAct == DCSWRITE){
      g_pstDif->info->tp_flags = TP_NOFLAGS;
      PiTpStat(g_pstDif)=0;
      /*iMsgLen = 0;*/
      iMsgLen = DCS_MAX_DATA_LEN;
      iRc=tp_server_receive(g_pstDif->info,TP_BLOCK,g_pstDif->service,
                            g_pstDif->input_format,g_pstDif->location,
                            g_pstDif->source_info,&iMsgLen,caTmpBuf);
      switch(iRc) {
        case TP_OK:
          break;
        case TP_SHUTDOWN:
        case TP_CLEAN_SHUTDOWN:
          sg_cDoTopEndTerm = 'y';
          ErrLog(99999,"DcsTpDisconnect-P:dummy recv SHUTDOWN",RPT_TO_LOG,0,0);
          break;
        default:
         sprintf(g_caMsg,"DcsTpDisconnect-p:dummy Serv Rcv fail,iRc=%d,stat=%d",
                  iRc,PiTpStat(g_pstDif));
          ErrLog(4000,g_caMsg,RPT_TO_LOG,0,0);
          pstSess[iIdx].cStatus = DCS_S_ERROR;
          PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
          /*UCP_TRACE_END(iRc);*/
      } /* End of switch */
    }

    /* prepare data for calling tp_server_send */
    SpaceFill(g_pstDif->output_format->tp_format_name," ",TP_FMT_NAME_LEN);
    g_pstDif->info->tp_flags = TP_NOFLAGS;
    PiTpStat(g_pstDif) = 0;
    iMsgLen = PiDataLen(pstDcsBuf) =  8;
    PcMoreByte(pstDcsBuf) = '0';
     
    /* call topend tp_server_send */
    iRc=tp_server_send(g_pstDif->info,g_pstDif->output_format,
                       iMsgLen,PunData(pstDcsBuf));
    if(iRc != TP_OK){ 
      sprintf(g_caMsg,"DcsTpDisconnect-P:Serv Snd fail iRc=%d,stat=%d",
              iRc,PiTpStat(g_pstDif));
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstSess[iIdx].cStatus = DCS_S_ERROR;
      PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
      UCP_TRACE_END(iRc);
    }
  }
#endif

  /* set sess status */
  if((iIdx < 3) && (pstSess[iIdx].cMode == 'A') &&
     (pstSess[iIdx].cStatus == DCS_S_USED ||
      pstSess[iIdx].cStatus == DCS_S_USABLE )){
    pstSess[iIdx].cStatus = DCS_S_USABLE;
  }
  else{
    pstSess[iIdx].cStatus = DCS_S_FREE;
  }

  /* clear Session information */
  pstSess[iIdx].cLastAct = DCSDISCONNECT;
  memset(pstSess[iIdx].caProName,' ',PROD_NAME_LEN);
  memset(pstSess[iIdx].caFunName,' ',FUNC_NAME_LEN); 
  pstSess[iIdx].lSeqNo = 0;
/*pstSess[iIdx].cMode = ' '; mark by WuChihLiang for don't clear session mode 
                             in case disconnect twice */

  /* fill DCS buff */
  PiSesIdx(pstDcsBuf) = -1;
  PlSeqNo(pstDcsBuf) = 0;
  PcProto(pstDcsBuf) = ' ';
  PiErrno(pstDcsBuf) = 0;

  ErrLog(10,"DcsTpDisconnect:End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}

/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   sign off to topend network agent
*&D&
*/

int
DcsTpTerm(struct DcsBuf *pstDcsBuf)
{
  int iRc;

  UCP_TRACE(P_DcsTpTerm);
  ErrLog(10,"DcsTpTerm:Begin.",RPT_TO_LOG,0,0);

  if (sg_cDoTopEndTerm == 'n'){ /*  set on('y') before call ErrLog(99999,...) */
    ErrLog(10,"DcsTpTerm:End.",RPT_TO_LOG,0,0);
    UCP_TRACE_END(DCS_NORMAL);
  }

#ifdef III_TOPEND_SERVER
  /* Close All Resource Managers */
  if ((iRc=tx_close()) != TX_OK ) {
    sprintf(g_caMsg,"DcsTpTerm:tx_close failed,iRc=%d,stat=%d",
            iRc,PiTpStat(g_pstDif));
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
    UCP_TRACE_END(iRc);
  }
#endif

  if(g_pstDif != NULL){
    iRc=tp_csi_free(g_pstDif);
    if(iRc != TP_OK){
      sprintf(g_caMsg,"DcsTpTerm:tp_csi_free failed,iRc=%d,stat=%d",
              iRc,PiTpStat(g_pstDif));
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
      UCP_TRACE_END(iRc);
    }
  }

  iRc = tp_terminate();
  if(iRc != TP_OK){
    sprintf(g_caMsg,"DcsTpTerm:Tp Term fail iRc=%d,stat=%d",
            iRc,PiTpStat(g_pstDif));
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    PiErrno(pstDcsBuf) = PiTpStat(g_pstDif);
    UCP_TRACE_END(iRc);
  }

  ErrLog(10,"DcsTpTerm:End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}

/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   load product name and function name table
*&D&
*/

int
LoadProFunTbl(struct ProdFuncSt *pstProFunTbl)
{
  int i,j,k;
  FILE *pfNetFd;
  char caFileName[80];

  UCP_TRACE(P_LoadProFunTbl);
  ErrLog(10,"LoadProFunTbl:Begin",RPT_TO_LOG,0,0);

  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat(caFileName, DCS_TABLE_PATH);
  strcat(caFileName,"topndtbl");

  pfNetFd = fopen(caFileName,"r");
  if(pfNetFd == (FILE *) 0){
    sprintf(g_caMsg,"LoadProFunTbl:open %s error=%d",caFileName,errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(DCS_ES_OPENTBLFILE);
  }

  i = 0;
  while(fscanf(pfNetFd,"%s %s %s", pstProFunTbl[i].caTxnCode,
                                   pstProFunTbl[i].caProName,
                                   pstProFunTbl[i].caFunName) != EOF){
    if(i++ > MAX_NETWKTBL_ARRAY){
      ErrLog(1000,"load_prod_func_table:over table array",RPT_TO_LOG,0,0);
      fclose(pfNetFd);
      UCP_TRACE_END(DCS_ES_TBLARRAYOVERFLW);
    }
  }

  gs_iMaxLoad = i;
  fclose(pfNetFd);
  ErrLog(10,"LoadProFunTbl:End",RPT_TO_LOG,0,0);
  UCP_TRACE_END(0);
}

/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   search producte name & function name
*&D&
*/

int
SrhProFunName(char *pcTxnCode,char *pcProName,char *pcFunName)
{
 int i;
 int iRc;
 struct ProdFuncSt *pstProFunTbl;

 UCP_TRACE(P_SrhProFunName);
 sprintf(g_caMsg,"SrhProFunName:Begin TxnCode=%.4s",pcTxnCode);
 ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);

 pstProFunTbl = g_stProFunTbl;

 i = 1;
 while((iRc=strncmp(pcTxnCode,pstProFunTbl[i].caTxnCode,1)) != 0 &&
       (i < gs_iMaxLoad)){
   i++;
 }
    
 if(i == gs_iMaxLoad){
   SpaceFill(pcProName,pstProFunTbl[0].caProName,PROD_NAME_LEN); 
   SpaceFill(pcFunName,pstProFunTbl[0].caFunName,FUNC_NAME_LEN); 
   sprintf(g_caMsg,"SrhProFunName:End [0].ProName=%.32s,[0].FunName=%.9s",
           pstProFunTbl[0].caProName,pstProFunTbl[0].caFunName);
 }
 else{
   SpaceFill(pcProName,pstProFunTbl[i].caProName,PROD_NAME_LEN); 
   SpaceFill(pcFunName,pstProFunTbl[i].caFunName,FUNC_NAME_LEN); 
   sprintf(g_caMsg,"SrhProFunName:End ProName=%.32s,FunName=%.9s",
           pstProFunTbl[i].caProName,pstProFunTbl[i].caFunName);
 }
 ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
 UCP_TRACE_END(0);
}

/*----------------------------------------------------------------------*/
/* define serveives function name                                       */
/*----------------------------------------------------------------------*/
void
DefServ(char *pcProName)
{
  SpaceFill(g_stApInfo.tp_format_file, " ",TP_FMTFILENAME_LEN);
  SpaceFill(gs_caFunArray[0].tp_function_name,pcProName,TP_FUNC_NAME_LEN);
  SpaceFill(g_stApInfo.tp_product_name,pcProName,TP_PROD_NAME_LEN);
}

/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   fill space to string up to len
*&D&
*/

int
SpaceFill(char *pcS1,char *pcS2,int iLen)
{
  int i;

  UCP_TRACE(P_SpaceFill);
  strncpy(pcS1,pcS2,iLen);

  for(i=0;i<iLen;i++){
    if(pcS1[i] == NULL) pcS1[i] = 0x20;
  }

  UCP_TRACE_END(0);
}
/*===========================================================================*/
