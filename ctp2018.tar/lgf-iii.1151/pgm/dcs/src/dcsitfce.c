
/*    dcsitfce.c FUNCTION & SUBROUTINE DESCRIPTION
*&N&   
*&N&    TYPE      NAME                 DESCRIPTION
*&N& --------- ------------ ---------------------------------------- 
*&N&   int     SbDcs        �����l�t�����ε{�������{���D�\����
*&N&   int     DcsStart     �Ұ� SERVER �����ε{���ëإ߷|�͸�ƥ\����
*&N&   int     DcsSend      �e��ƨ� SERVER �ݥ\����
*&N&   int     DcsSendDisc  �e��ƨ� SERVER �ݨõ����|�ͤ��\����
*&N&   int     DcsRcv       ���� SERVER �ݰe�X�����
*&N&   int     DcsRcvAll    �s�򱵦� SERVER �ݰe�X����ƪ���S����Ƥ��\����
*&N&   int     DcsStop      �������w���|�ͨä��_�P SERVER �ݤ��s�u
*&N&   int     DcsStopAll   ���������|�ͨä��_�P SERVER �ݤ��s�u
*&N&   int     DcsSrhPgId   �H SERVER �ݵ{���N���M��|�͸��
*&N&   int     DcsInitPrgId �]�w SERVER �ݵ{���N������
*&N&   char    DcsCnvErr    �ഫ�����l�t�Ω��h�Ǧ^�����~�N�X
*&N&   int     SrhProtoTbl  �H�ت��N�X�M��A�Τ��q�T��q
*&N&   int     LoadProtoTbl ���J�q�T��q����
*&N&
*/

/* -------------------- INCLUDE FILES DECLARATION ------------------- */
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/signal.h>
#include <fcntl.h>
#include <errno.h>

#include "errlog.h"
#include "dcs.h"
#include "ucp.h"

struct ProtoTblSt{		/* �q�T��q�P�ت��N�X����Ӹ�ƪ��� */
  char caDesCode[11];		/* �ت��N�X */
  char cProto;			/* �q�T��q�N�X */
};

/* ------------- dcsitfce.c function ���N�� ------------------------- */
#define P_DcsRcv 		41101
#define P_DcsRcvAll 		41102
#define P_DcsSend 		41103
#define P_DcsSendDisc 		41104
#define P_DcsSrhPgId 		41105
#define P_DcsStart 		41106
#define P_DcsStop 		41107
#define P_DcsStopAll 		41108
#define P_DcsCnvErr 		41109
#define P_DcsInitPrgId 		41110
#define P_SrhProtoTbl 		41111
#define P_LoadProtoTbl 		41112
#define P_SbDcs 		41113
#define P_GetProtoByDes 	41114
#define P_ApSifCnv		41115
#define P_DcsAcceptRead		41116
#define P_DcsStopAllApi		41117
#define P_RcvServerDataToFile   41118
#define P_NewApSifCnv		41115
#define P_CompWildDest		41116

/* ------------------------ CONSTANT DEFINE ------------------------- */
#define CENTER_DCS_TIMEOUT      30
#define BRANCH_DCS_TIMEOUT      90

/* -------------------- STATIC GLOBAL DECLARATION ------------------- */
extern struct Big2Nhost *pstCvtTbl;	/* ����N�X����X����,load �b CWA �� */
static int sg_iRmtFlg;			/* 1=remote txn ,0=local txn */
static int sg_iFirst=1;		        /* sg_iFirst flag 1=yes 0=no */
static struct DcsApi *sg_pstDcsApi;	/* cntl data between AP and TPU */
static struct DcsBuf sg_stDcsBuf;	/* dcs message buffer */
static struct DcsSiof sg_stDcsSiof;	/* dcs siof buffer */
struct TpuMap g_stPrgIdTbl[MAX_PROGRAM];/* SERVER �ݵ{���N�X���� */
static struct ProtoTblSt sg_stProtoTbl[MAX_NETWKTBL_ARRAY];
				/* �ت��N�X�P�q�T��q�N�X��Ӫ��� */

/* ------ CALL FUNCTION & SUBROUTINE PROTOTYPE DECLARATIONS --------- */
int SbDcs(int iArgc,char *pcaArgv[]);
int DcsStart(char *pcDataBuf);
int DcsSend(char *pcDataBuf);
int DcsSendDisc(char *pcDataBuf);
int DcsRcv(char *pcDataBuf);
int DcsRcvAll(char *pcDataBuf, char *pcRcvFileName);
int DcsStop();
int DcsStopAll();
int DcsSrhPgId(char *pcPrgId,char cFlag);
int CompWildDest(char *pcDesCode, char *pstTblDest, int num);
int SrhProtoTbl(char *pcDesCode,struct ProtoTblSt *pstNetwk);
int LoadProtoTbl(struct ProtoTblSt *pstNetTbl);
int DcsInitPrgId();
char DcsCnvErr();
int RcvServerDataToFile(char *, char *, char, int );

/*
*&N& ROUTINE NAME:int SbDcs(int iArgc,char *pcaArgv[])
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& iArgc           int                 �ѼƭӼ�
*&A& pcaArgv[0]      char *              reserve 
*&A& pcaArgv[1]      DcsApi *            DCS API control area 
*&A& pcaArgv[2]      char *              DCS API data    area 
*&A& pcaArgv[3]      char *              "0":TPEDCS type
*&A&                                     "1":RMTDCS type
*&A& pcaArgv[4]      char *              Receive data file name where 
*&A&                                     used in pcaArgv[3] = "1"
*&A& 
*&R& RETURN VALUE(S):
*&R&   0 : ���`.
*&R&  -1 : �Ѽƿ��~,�Υ\��N�����~.
*&R&
*&D& DESCRIPTION:
*&D&  1.�ˬd�ǤJ���ѼƭӼ�.
*&D&  2.�Y�O�Ĥ@���I�s�����,�h���J server �����ε{���N�X�P�q�T��q����Ӫ�,
*&D&    �ó]�w server �ݵ{���N�X�����ҩl��.
*&D&  3.�̥\��N�X���t�줣�P���\����.
*&D&
*/

int
SbDcs(int iArgc,char *pcaArgv[])
{
  int iRc,i;

  UCP_TRACE(P_SbDcs);

  ErrLog(10,"SbDcs:Begin",RPT_TO_LOG,0,0);

  /* �ˬd�ǤJ���ѼƭӼ� */
  if((iArgc > 5) || (iArgc <= 0)){
    sprintf(g_caMsg,"SbDcs:invalid argc=%d number.",iArgc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    sg_pstDcsApi->cRtnCode = DCS_M_SYSTEM_ERROR;
    UCP_TRACE_END(-1);
  } /* end of if((iArgc > 4) && (iArgc <= 0)) */

  ErrLog(10,"SbDcs:dump DcsApi",RPT_TO_LOG,pcaArgv[1],sizeof(struct DcsApi));

  /* if first call SbDcs then initial PrgId and load protocol table */
  if(sg_iFirst){
    iRc = DcsInitPrgId();
    if(iRc != 0){
      sg_pstDcsApi->cRtnCode = DCS_M_SYSTEM_ERROR;
      UCP_TRACE_END(-1);
    }
    sg_iFirst = 0;
  } /* end of  if(sg_iFirst) */

  sg_pstDcsApi = (struct DcsApi *)pcaArgv[1];
  sg_iRmtFlg = atoi(pcaArgv[3]);

  sg_pstDcsApi->cRtnCode = DCS_M_NORMAL;
  memcpy(sg_pstDcsApi->caErrCode, "00", 2);
 
#ifdef LOAD_CNV_TABLE
  /* pointer pstCvtTbl to EBCDIC/HOST and ASCII/BIG5 convert table of SWA  */
  pstCvtTbl = (struct table_array *)&(swa->cvt_tbl);
#endif

  /* �̥\��N�X���t�줣�P���\����.*/
  switch (sg_pstDcsApi->cFunCode){
    case DCS_M_RMT_START_PGM:
    case DCS_M_B_RMT_START_PGM:
      iRc = DcsStart(pcaArgv[2]);
      if(iRc == -1){
        ErrLog(1000,"SbDcs:DcsStart execute error",RPT_TO_LOG,0,0);
      }
      break;
    case DCS_M_ACCEPT:
      iRc = DcsAcceptRead(pcaArgv[2]);
      if(iRc == -1){
        ErrLog(1000,"SbDcs:DcsAcceptRead execute error",RPT_TO_LOG,0,0);
      }
      break;
    case DCS_M_SEND:
      iRc = DcsSend(pcaArgv[2]);
      if(iRc == -1){
        ErrLog(1000,"SbDcs:DcsSend execute error",RPT_TO_LOG,0,0);
      }
      break;
    case DCS_M_SEND_DISCONNECT:
      iRc = DcsSendDisc(pcaArgv[2]);
      if(iRc == -1){
        ErrLog(1000,"SbDcs:DcsSendDisc execute error",RPT_TO_LOG,0,0);
      }
      break;
    case DCS_M_RECEIVE:
      iRc = DcsRcv(pcaArgv[2]);
      if(iRc == -1){
        ErrLog(1000,"SbDcs:DcsRcv execute error",RPT_TO_LOG,0,0);
      }
      break;
    case DCS_M_RECEIVE_ALL:
      iRc = DcsRcvAll(pcaArgv[2],pcaArgv[4]);
      if(iRc == -1){
        ErrLog(1000,"SbDcs:DcsRcvAll execute error",RPT_TO_LOG,0,0);
      }
      break;
    case DCS_M_RMT_STOP_PGM:
      iRc = DcsStop();
      if(iRc == -1){
        ErrLog(1000,"SbDcs:DcsStop execute error",RPT_TO_LOG,0,0);
      }
      break;
    case DCS_M_DISCONNECT_ALL:
      iRc = DcsStopAll();
      if(iRc == -1){
        ErrLog(1000,"SbDcs:DcsStopAll execute error",RPT_TO_LOG,0,0);
      }
      break;
    default :
      sprintf(g_caMsg,"SbDcs:No such function code=%c",sg_pstDcsApi->cFunCode);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      sg_pstDcsApi->cRtnCode = DCS_M_COMMAND_ERROR;
      iRc = -1;
      break;
  } /* end switch */

 ErrLog(10,"SbDcs:End dump DcsApi",RPT_TO_LOG,pcaArgv[1],sizeof(struct DcsApi));

  UCP_TRACE_END(iRc);
} /* end of sbdbs */

/*
*&N& ROUTINE NAME:int DcsStart(char *pcDataBuf)
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------------------
*&A&  pcDataBuf      char *              �e�� server �ݪ���Ʀ�}����(pointer)
*&A& 
*&R& RETURN VALUE(S):
*&R&   0 : ���`.
*&R&  -1 : �e�� server �������X���~.
*&R&  -1 : �H�ت��X�M��q�T��q���~.
*&R&  -1 : �I�s dcs ���~.
*&R&  -1 : server �ݵ{���N�X���w�Χ������~.
*&R&  -1 : �e��Ƶ� server �ݿ��~.
*&R&
*&D& DESCRIPTION:
*&D&   1.SIF����Ʈ榡�ഫ.
*&D&   2.�I�s�����{�����s�� server �ݤ��{��.
*&D&   3.�ˬd�����{�����Ǧ^��, �ð��ഫ.
*&D&   4.�M��{���N�X���i�Τ��Ŷ�, �s��|�͸��.
*&D&   5.�e��Ƶ� server.
*&D&
*/

int
DcsStart(char *pcDataBuf)
{
  int i;
  int iRc;
  int iSendDataLen;
  char caTmpBuf[20];
  char caSif[MAX_SIF_LEN];
  char cProtoType;

  UCP_TRACE(P_DcsStart);

  ErrLog(10,"DcsStart:Begin.",RPT_TO_LOG,0,0);

  /* �r������ƪ����ഫ���Ʀr����ƫ��A */
  memcpy(caTmpBuf,sg_pstDcsApi->caDataLen,4);
  caTmpBuf[4] = '\0';
  iSendDataLen = atoi(caTmpBuf);

  /* translate AP-SIF or UNIX-SIF to IBM-SIF */
#ifdef OLD_UCPDCS
  if(g_iRmtFlg == 1){
    /* Liu 820824 marked 
    iSendDataLen = iosifcnv(pcDataBuf,caSif,"UCPU",0);
    ErrLog(10,"DcsStart:iosifcnv(),sif=",RPT_TO_LOG,caSif,iSendDataLen);
    */
  }
  else{
    if(sg_pstDcsApi->cFunCode == DCS_M_B_RMT_START_PGM){
      /* for reentry txn */
      iSendDataLen=NewApSifCnv(pcDataBuf,caSif,"UCP3","\x01\x00",iSendDataLen,1,
                    sg_pstDcsApi->caDesAddr,"9999999999","9999");
    }
    else{
      iSendDataLen=NewApSifCnv(pcDataBuf,caSif,"UCP4","\x02\x00",iSendDataLen,0,
                    sg_pstDcsApi->caDesAddr,"9999999999","9999");
    } /* end of if(sg_pstDcsApi->cFunCode == DCS_M_B_RMT_START_PGM)--else */
  } /* end of if(sg_iRmtFlg==1) --else  */
#else
  if(sg_iRmtFlg == 1){
    /* by pass TPEWRITE data */
    iSendDataLen=NewApSifCnv(pcDataBuf,caSif,sg_pstDcsApi->caTxnCode,"\x01\x00",
                   iSendDataLen, sg_pstDcsApi->caDesAddr,
                   sg_pstDcsApi->caTermCode,"9999", sg_pstDcsApi->cDataFmt);
  }else{
    /* COOPERATIVE TXN */
    iSendDataLen=NewApSifCnv(pcDataBuf,caSif,sg_pstDcsApi->caTxnCode,"\x02\x00",
                   iSendDataLen, sg_pstDcsApi->caDesAddr,
                   sg_pstDcsApi->caTermCode,"9999", sg_pstDcsApi->cDataFmt);
  }
#endif

  /* �ˬd sif �ഫ�ᤧ��ƪ��׬O�_�p�� 0 */
  if(iSendDataLen == -1){
    ErrLog(1000,"DcsStart:NewApSifCnv error",RPT_TO_LOG,0,0);
    sg_pstDcsApi->cRtnCode = DCS_M_CONVSIF_ERROR;
    UCP_TRACE_END(-1);
  } /* end of  if(iSendDataLen == -1) */
  sprintf(caTmpBuf,"%.4d",iSendDataLen);
  memcpy(sg_pstDcsApi->caDataLen,caTmpBuf,4);

  /* prepare data to connect to remote application */
  McRqstCode(sg_stDcsBuf) = DCSCONNECTWRITE;

  /* get des_code from API */
  /*memset(McaDesCode(sg_stDcsBuf),'0',10);*/
  memcpy(McaDesCode(sg_stDcsBuf),sg_pstDcsApi->caDesAddr,10);

  /* get protocol by destination code */
  iRc = GetProtoByDes(McaDesCode(sg_stDcsBuf),&cProtoType);
  if(iRc != 0){
    ErrLog(1000,"DcsStart:GetProtoByDes error",RPT_TO_LOG,0,0);
    sg_pstDcsApi->cRtnCode = DCS_M_DATA_ERROR;
    UCP_TRACE_END(-1);
  } /* end of if(iRc != 0) */
  McProto(sg_stDcsBuf) = cProtoType;

  MpstDcsSiof(sg_stDcsBuf) = &sg_stDcsSiof;

#ifdef OLD_UCPDCS
  /* set data length */
  memcpy(sg_stDcsSiof.caDataLen,"00008",5);
  MiDataLen(sg_stDcsBuf) = 0+8;
  /* set data */
  if(sg_iRmtFlg == 1){
    memcpy(McaServCode(sg_stDcsBuf),pcDataBuf+4,4);
  }
  else{
    memcpy(McaServCode(sg_stDcsBuf),caSif+4,4);
  } /* end of if(sg_iRmtFlg == 1) -- else */
#else
  sprintf(caTmpBuf,"%.5d",iSendDataLen+8);
  memcpy(sg_stDcsSiof.caDataLen,caTmpBuf,5);
  if(sg_iRmtFlg == 1){
    McKind(sg_stDcsBuf) = '1'; /* for dcxpsuio.x--TxnBridge() */ 
  }
  else{
    McKind(sg_stDcsBuf) = '2'; /* for dcxpsuio.x--DcsAgent() */ 
  }
  memcpy(McaData(sg_stDcsBuf),caSif,iSendDataLen);
  MiDataLen(sg_stDcsBuf) = iSendDataLen + 8;
  memcpy(McaServCode(sg_stDcsBuf),caSif+4,MAX_TXN_CODE_LEN);
#endif

  DcsDispatch(&sg_stDcsBuf);

  /* check return code after connect & write */
  sg_pstDcsApi->cRtnCode = DcsCnvErr();
  if(sg_pstDcsApi->cRtnCode != DCS_M_NORMAL){
    sprintf(g_caMsg,"DcsStart:Error Rtn Code = %c",sg_pstDcsApi->cRtnCode);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  } /* end of if(sg_pstDcsApi->cRtnCode != DCS_M_NORMAL) */
   
  /* program id = 0 reserve for txn in, set by tmsdcsfn.c(GetInput()) */

  for(i=1 ; i < MAX_PROGRAM ; i++){

    if(g_stPrgIdTbl[i].iSesIdx == -1){
      break;
    }
  } /* end of for(i=1 ; i < MAX_PROGRAM ; i++) */

  /* not found */
  if(i == MAX_PROGRAM){
    sprintf(g_caMsg,"DcsStart:TpuMap overflow,MAX_PROGRAM=%d",MAX_PROGRAM);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    sg_pstDcsApi->cRtnCode = DCS_M_SYSTEM_ERROR;
    UCP_TRACE_END(-1);
  } /* end of if(i == MAX_PROGRAM) */

  /* found */
  sprintf(caTmpBuf,"%.4d",i);
  memcpy(sg_pstDcsApi->caPrgId,caTmpBuf,4);

  /* put data to program id map */
  g_stPrgIdTbl[i].iSesIdx = MiSesIdx(sg_stDcsBuf);
  g_stPrgIdTbl[i].lCnvId  = MlSeqNo(sg_stDcsBuf);
  g_stPrgIdTbl[i].cProto = McProto(sg_stDcsBuf);

#ifdef OLD_UCPDCS
  /* send SIF to IBM host */
  if(sg_iRmtFlg == 1){
    iRc = DcsSend(pcDataBuf);
  }
  else{
    iRc = DcsSend(caSif);
  } /* end of if(sg_iRmtFlg == 1) */
#endif

  UCP_TRACE_END(iRc);
} /* end of DcsStart */

/*
*&N& ROUTINE NAME:int DcsAcceptRead(char *pcDataBuf)
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& pcDataBuf       char *              ���� client �ݤ���Ʀ�}
*&A& 
*&R& RETURN VALUE(S):
*&R&   0 : ���`.
*&R&  -1 : �H�ت��X�M��q�T��q���~.
*&R&  -1 : �I�s�����A�ȵ{���� accept ���\����~.
*&R&  -1 : �{���N�X��[0]�w�Q�ϥΤ����~, �Y���а� accept ���\��.
*&R&  -1 : ���� client �ݪ���ƿ��~.
*&R&
*&D& DESCRIPTION:
*&D&   1.�H�ت��X���o�q�T��q.
*&D&   2.�I�s�����A�ȵ{��, �� accept.
*&D&   3.�H�{���N�X[0], �s��|�͸��.
*&D&   4.���� client �ݪ����.
*&D&
*/

int
DcsAcceptRead(char *pcDataBuf)
{
  int i;
  int iRc;
  char caTmpBuf[20];
  char cProtoType;

  UCP_TRACE(P_DcsAcceptRead);
  ErrLog(10,"DcsAcceptRead:Begin.",RPT_TO_LOG,0,0);

  /* get des_code from API */
  /*memset(McaDesCode(sg_stDcsBuf),'0',10);*/
  memcpy(McaDesCode(sg_stDcsBuf),sg_pstDcsApi->caDesAddr,10);

  /* get protocol by destination code */
  iRc = GetProtoByDes(McaDesCode(sg_stDcsBuf),&cProtoType);
  if(iRc != 0){
    ErrLog(1000,"DcsStart:GetProtoByDes error",RPT_TO_LOG,0,0);
    sg_pstDcsApi->cRtnCode = DCS_M_DATA_ERROR;
    UCP_TRACE_END(-1);
  } /* end of if(iRc != 0) */
  McProto(sg_stDcsBuf) = cProtoType;

  /* prepare data to connect to remote application */
  McRqstCode(sg_stDcsBuf) = DCSACCEPT;

  /* set data length */
  memcpy(sg_stDcsSiof.caDataLen,"00008",5);
  MiDataLen(sg_stDcsBuf) = 0+8;
  MpstDcsSiof(sg_stDcsBuf) = &sg_stDcsSiof;
  DcsDispatch(&sg_stDcsBuf);

  /* check return code after connect */
  sg_pstDcsApi->cRtnCode = DcsCnvErr();
  if(sg_pstDcsApi->cRtnCode != DCS_M_NORMAL){
    sprintf(g_caMsg,"DcsStart:Error Rtn Code = %c",sg_pstDcsApi->cRtnCode);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  } /* end of if(sg_pstDcsApi->cRtnCode != DCS_M_NORMAL) */
   
  /* keep SessIdx in PrgId=0 */
  if(g_stPrgIdTbl[0].iSesIdx == -1){
    g_stPrgIdTbl[0].iSesIdx = MiSesIdx(sg_stDcsBuf);
    g_stPrgIdTbl[0].lCnvId = MlSeqNo(sg_stDcsBuf);
    g_stPrgIdTbl[0].cProto = McProto(sg_stDcsBuf);
  }
  else{ 
    ErrLog(1000,"DcsAcceptRead:PrgIdTbl[0] is used !!",RPT_TO_LOG,0,0);
    sg_pstDcsApi->cRtnCode = DCS_M_SYSTEM_ERROR;
    UCP_TRACE_END(-1);
  } /* end of if(g_stPrgIdTbl[0].iSesIdx == -1) -- else */

  /* pass program id to AP */
  sprintf(caTmpBuf,"%.4d",0);
  memcpy(sg_pstDcsApi->caPrgId,caTmpBuf,4);

  iRc = DcsRcv(pcDataBuf);

  ErrLog(10,"DcsAcceptRead:End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(iRc);
} /* end of DcsAcceptRead */

/*
*&N& ROUTINE NAME:int DcsSend(char *pcDataBuf)
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------------
*&A& pcDataBuf       char *              ���e�X����ƪ���}����(pointer)
*&A& 
*&R& RETURN VALUE(S):
*&R&    0 : ���`.
*&R&   -1 : �H�ت��N�X�M��q�T��q���~.
*&R&   -1 : �M��{���N�X���~.
*&R&   -1 : �I�s�����A�ȵ{��, ���e��ƪ��\����~.
*&R&
*&D& DESCRIPTION:
*&D&   1.�ˬd�O�_�O�{���N�X "0000" �B�L�|�͸��, 
*&D&       �O�h�H�ت��N�X�M��q�T��q, �N�s��|�͸�Ƥ� flag on .
*&D&       �_�h�H�{���N�X�M��|�͸��.
*&D&   2.�I�s�����A�ȵ{��, ���e��ƪ��\��.
*&D&   3.�Y�{���N�X[0]�L�|�͸�ƥB�s��|�͸�Ƥ� flag on ,
*&D&     �h�s��|�͸�ƨ�{���N�X[0]��.
*&D&
*/

int
DcsSend(char *pcDataBuf)
{
  int  iRc;
  int  iSendDataLen;
  char caTmpBuf[20];

  UCP_TRACE(P_DcsSend);

  ErrLog(10,"DcsSend:Begin.",RPT_TO_LOG,0,0);

  /* search session and conversation id for program id */ 
  iRc = DcsSrhPgId(sg_pstDcsApi->caPrgId,'0');
  if(iRc == -1){
    ErrLog(1000,"DcsSend:search prgid error",RPT_TO_LOG,0,0);
    sg_pstDcsApi->cRtnCode = DCS_M_PGM_ID_ERROR;
    UCP_TRACE_END(-1);
  } /* end of if(iRc == -1) */

  /* prepare data for call DcsDispatch()  */ 
  McRqstCode(sg_stDcsBuf) = DCSWRITE;
  MpstDcsSiof(sg_stDcsBuf) = &sg_stDcsSiof;
  McMoreByte(sg_stDcsBuf) = '1';
  McProtoType(sg_stDcsBuf) = ' ';

  if(sg_iRmtFlg == 1){
    McKind(sg_stDcsBuf) = '1'; /* for dcxpsuio.x--TxnBridge() */ 
  }
  else{
    McKind(sg_stDcsBuf) = '2'; /* for dcxpsuio.x--DcsAgent() */ 
  }

  /* set data length */
  memcpy(caTmpBuf,sg_pstDcsApi->caDataLen,4);
  caTmpBuf[4] = '\0';
  iSendDataLen = atoi(caTmpBuf);
  sprintf(caTmpBuf,"%.5d",iSendDataLen+8);
  memcpy(sg_stDcsSiof.caDataLen,caTmpBuf,5);

  /* set data */
  memcpy(McaData(sg_stDcsBuf),pcDataBuf,iSendDataLen);
  MiDataLen(sg_stDcsBuf) = 8+iSendDataLen;

  /* for debug dump send Data */
  ErrLog(10,"DcsSend:before call DcsDispatch, dump data=",RPT_TO_LOG,
         McaData(sg_stDcsBuf), MiDataLen(sg_stDcsBuf));

  DcsDispatch(&sg_stDcsBuf);

  /* check return code after call DCSWRITE */
  sg_pstDcsApi->cRtnCode = DcsCnvErr();
  if(sg_pstDcsApi->cRtnCode != DCS_M_NORMAL){
    sprintf(g_caMsg,"DcsSend:Error Rtn Code=%c",sg_pstDcsApi->cRtnCode);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  } /* end of if(sg_pstDcsApi->cRtnCode != DCS_M_NORMAL) */

  ErrLog(10,"DcsSend End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(0);
} /* end of DcsSend */

/*
*&N& ROUTINE NAME:int DcsSendDisc(char *pcDataBuf)
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& pcDataBuf       char *              ��ƪ���}
*&A& 
*&R& RETURN VALUE(S):
*&R&   0 : ���`.
*&R&   -1 : �H�ت��N�X�M��q�T��q���~.
*&R&   -1 : �M��{���N�X���~.
*&R&   -1 : �I�s�����A�ȵ{��, ���e��ƪ��\����~.
*&R&
*&D& DESCRIPTION:
*&D&   1.�ˬd�O�_�O�{���N�X "0000" �B�L�|�͸��, 
*&D&       �O�h�H�ت��N�X�M��q�T��q.
*&D&       �_�h�H�{���N�X�M��|�͸��.
*&D&   2.�I�s�����A�ȵ{��, ���e��ƥB�����|�ͪ��\��. more byte �]�� '0'.
*&D&
*/

int
DcsSendDisc(char *pcDataBuf)
{
  int  iRc;
  int  iSendDataLen;
  char caTmpBuf[20];

  UCP_TRACE(P_DcsSendDisc);
  ErrLog(10,"DcsSendDisc Begin.",RPT_TO_LOG,0,0);

  /* search session and conversation id for program id */ 
  iRc = DcsSrhPgId(sg_pstDcsApi->caPrgId,'0');
  if(iRc == -1){
    sprintf(g_caMsg,"DcsSendDisc:no such pgm id=%.4s",
            sg_pstDcsApi->caPrgId);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    sg_pstDcsApi->cRtnCode = DCS_M_PGM_ID_ERROR;
    UCP_TRACE_END(-1);
  } /* end of if(iRc == -1) */

  /* prepare data to dcscontrl */ 
  McRqstCode(sg_stDcsBuf) = DCSWRDISCONECT;
  MpstDcsSiof(sg_stDcsBuf) = &sg_stDcsSiof;
  McMoreByte(sg_stDcsBuf) = '0';
  McProtoType(sg_stDcsBuf) = ' ';

  if(sg_iRmtFlg == 1){
    McKind(sg_stDcsBuf) = '1'; /* for dcxpsuio.x--TxnBridge() */ 
  }
  else{
    McKind(sg_stDcsBuf) = '2'; /* for dcxpsuio.x--DcsAgent() */ 
  }

  /* set data length */
  memcpy(caTmpBuf,sg_pstDcsApi->caDataLen,4);
  caTmpBuf[4] = '\0';
  iSendDataLen = atoi(caTmpBuf);
  sprintf(caTmpBuf,"%.5d",iSendDataLen+8);
  memcpy(sg_stDcsSiof.caDataLen,caTmpBuf,5);

  /* set data */
  memcpy(McaData(sg_stDcsBuf),pcDataBuf,iSendDataLen);
  MiDataLen(sg_stDcsBuf) = 8+iSendDataLen;

  /* for debug dump send Data */
  ErrLog(10,"DcsSend:before call DcsDispatch, dump data=",RPT_TO_LOG,
         McaData(sg_stDcsBuf), MiDataLen(sg_stDcsBuf));

  DcsDispatch(&sg_stDcsBuf);

  /* check return code after call DCSWRITE */
  sg_pstDcsApi->cRtnCode = DcsCnvErr();
  if(sg_pstDcsApi->cRtnCode != DCS_M_NORMAL){
    sprintf(g_caMsg,"DcsSendDisc:Error Rtn code=%c",
            sg_pstDcsApi->cRtnCode);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  } /* end of   if(g_pstDcsApi->cRtnCode != DCS_M_NORMAL) */

  ErrLog(10,"DcsSendDisc End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(0);
} /* end of DcsSend */

/*
*&N& ROUTINE NAME:int DcsRcv(char *pcDataBuf)
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& pcDataBuf       char *              ��Ʀ�}�� pointer
*&A& 
*&R& RETURN VALUE(S):
*&R&    0 : ���`.
*&R&   -1 : �H�ت��N�X�M��q�T��q���~.
*&R&   -1 : �M��{���N�X���~.
*&R&   -1 : �I�s�����A�ȵ{��, ��������ƪ��\����~.
*&R&   -1 : ��������ƪ��פj�� DataBuf.
*&R&
*&D& DESCRIPTION:
*&D&   1.�ˬd�O�_�O�{���N�X "0000" �B�L�|�͸��, 
*&D&       �O�h�H�ت��N�X�M��q�T��q, �N�s��|�͸�Ƥ� flag on .
*&D&       �_�h�H�{���N�X�M��|�͸��.
*&D&   2.�I�s�����A�ȵ{��, ��������ƪ��\��.
*&D&   3.�Y�{���N�X[0]�L�|�͸�ƥB�s��|�͸�Ƥ� flag on ,
*&D&
*/

int
DcsRcv(char *pcDataBuf)
{
  int  iRc,i,iRcvDataLen,iRcvTimeout;
  int  iPrgId;
  char caTmpBuf[20];

  UCP_TRACE(P_DcsRcv);
  sprintf(g_caMsg,"DcsRcv Begin. PrgId=%.4s",sg_pstDcsApi->caPrgId);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);

  /* search session and conversation id for program id */ 
  iPrgId = DcsSrhPgId(sg_pstDcsApi->caPrgId,'0');
  if(iPrgId == -1){
    sprintf(g_caMsg,"DcsRcv:Srh PrgId=%.4s error",sg_pstDcsApi->caPrgId);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    sg_pstDcsApi->cRtnCode = DCS_M_PGM_ID_ERROR;
    UCP_TRACE_END(-1);
  } /* end of if(iPrgId == -1) */

  /* prepare data to call DCSREAD */
  MpstDcsSiof(sg_stDcsBuf) = &sg_stDcsSiof;
  memset(MpstDcsSiof(sg_stDcsBuf),0x0,sizeof(struct DcsSiof));
  McRqstCode(sg_stDcsBuf) = DCSREAD;

  /* timeout is specified by AP */
  memcpy(caTmpBuf,sg_pstDcsApi->caTimeOut,5);
  caTmpBuf[5] = '\0';
  iRcvTimeout = atoi(caTmpBuf);

  if (iRcvTimeout <= 0) {
    if ( memcmp(sg_pstDcsApi->caDesAddr,"0000000000",10) == 0 ){
      MlWaiTime(sg_stDcsBuf)=BRANCH_DCS_TIMEOUT; /* branch host ucpdcs time out */
    }else{
      MlWaiTime(sg_stDcsBuf)=CENTER_DCS_TIMEOUT; /* center host ucpdcs time out */
    }
  }
  else {
      MlWaiTime(sg_stDcsBuf)=iRcvTimeout;
  }

  sprintf(g_caMsg,"DcsRcv:before call DcsDispatch(), Timeout=%d",
                   MlWaiTime(sg_stDcsBuf));
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);

  memcpy(caTmpBuf,sg_pstDcsApi->caDataLen,4);
  caTmpBuf[4] = '\0';
  iRcvDataLen = atoi(caTmpBuf);
  MiDataLen(sg_stDcsBuf) = iRcvDataLen+8;
  sprintf(g_caMsg,"DcsRcv:before call DcsDispatch(),DataLen=%d",
          MiDataLen(sg_stDcsBuf));
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
  MpstDcsSiof(sg_stDcsBuf) = &sg_stDcsSiof;
  McMoreByte(sg_stDcsBuf) = '0';
  memcpy(McaDataLen(sg_stDcsBuf),"00000",5);

  DcsDispatch(&sg_stDcsBuf);

  /* check return code after call DCSREAD */
  sg_pstDcsApi->cRtnCode = DcsCnvErr();
  if(sg_pstDcsApi->cRtnCode != DCS_M_NORMAL){
    sprintf(g_caMsg,"DcsRcv:Error Rtn Code=%c",sg_pstDcsApi->cRtnCode);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  }
  else{
    sg_pstDcsApi->caErrCode[0]= McTxnStatus(sg_stDcsBuf);
  } /* end of if(sg_pstDcsApi->cRtnCode != DCS_M_NORMAL) -- else */

  /* �ˬd��������ƬO�j�� DataBuf */
  if(((MiDataLen(sg_stDcsBuf)-8)>iRcvDataLen) || ((MiDataLen(sg_stDcsBuf)-8)<0)){
    sprintf(g_caMsg,"DcsRcv:datalen=%d > iRcvDataLen=%d error",
           (MiDataLen(sg_stDcsBuf)-8),iRcvDataLen);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    sg_pstDcsApi->cRtnCode = DCS_M_SYSTEM_ERROR;
    UCP_TRACE_END(-1);
  }
  else{
    memcpy(pcDataBuf,McaData(sg_stDcsBuf),MiDataLen(sg_stDcsBuf)-8);
  } /* end of if(((MiDataLen(sg_stDcsBuf)-8) > iRcvDataLen) ||
                 ((MiDataLen(sg_stDcsBuf)-8) < 0)) -- else */

  /* pass data length to API */
  sprintf(caTmpBuf,"%.4d",(MiDataLen(sg_stDcsBuf)-8));
  memcpy(sg_pstDcsApi->caDataLen,caTmpBuf,4);

  ErrLog(10,"DcsRcv End: Rcv Data=",RPT_TO_LOG,pcDataBuf,
         (MiDataLen(sg_stDcsBuf)-8));
  UCP_TRACE_END(0);
} /* end of DcsRcv */

/*
*&N& ROUTINE NAME:int DcsRcvAll(char *pcDataBuf)
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& pcDataBuf       char *              ������Ƥ���}�� pointer
*&A& 
*&R& RETURN VALUE(S):
*&R&    0 : ���`.
*&R&   -1 : �H�ت��N�X�M��q�T��q���~.
*&R&   -1 : �M��{���N�X���~.
*&R&   -1 : �}�ұ�������ɿ��~.
*&R&   -1 : �I�s�����A�ȵ{��, ��������ƪ��\����~.
*&R&   -1 : �g����ɿ��~.
*&R&
*&D& DESCRIPTION:
*&D&   1.�ˬd�O�_�O�{���N�X "0000" �B�L�|�͸��, 
*&D&       �O�h�H�ت��N�X�M��q�T��q, �N�s��|�͸�Ƥ� flag on .
*&D&       �_�h�H�{���N�X�M��|�͸��.
*&D&   2.�}�ұ��������.
*&D&   3.�I�s�����A�ȵ{��, ��������ƪ��\��. ���� more byte = '0' ��
*&D&     ��������ƪ��׬� 0.
*&D&   4.�N������Ƽg�J�����.
*&D&   5.�Y�{���N�X[0]�L�|�͸�ƥB�s��|�͸�Ƥ� flag on ,
*&R&
*/

int
DcsRcvAll(char *pcDataBuf, char *pcRcvFileName)
{
  int  iRc,i;
  int  iPrgId;
  char caTmpBuf[20];
  char caMsgFileName[256];

  UCP_TRACE(P_DcsRcvAll);

  ErrLog(10,"DcsRcvAll Begin.",RPT_TO_LOG,0,0);

  /* search session and conversation id for program id */ 
  iPrgId = DcsSrhPgId(sg_pstDcsApi->caPrgId,'0');
  if(iPrgId == -1){
    sprintf(g_caMsg,"DcsRcvAll:no such pgm id=%.4s",
                    sg_pstDcsApi->caPrgId);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    sg_pstDcsApi->cRtnCode = DCS_M_PGM_ID_ERROR;
    UCP_TRACE_END(-1);
  } /* end of if(iPrgId == -1) */

  /* open message file for output */
  sprintf(caMsgFileName,"%s/iii/tmp/msgf%d",(char *)getenv("III_DIR"),getpid());
     
  iRc = RcvServerDataToFile(caMsgFileName,pcDataBuf,McProto(sg_stDcsBuf),
                            MiSesIdx(sg_stDcsBuf));

  /* check return code after call DCSREAD */
  switch(iRc){
    case  0:
      break;
    case -1:
      sg_pstDcsApi->cRtnCode = DCS_M_SYSTEM_ERROR;
      break;
    case -2:
      sg_pstDcsApi->cRtnCode = DCS_M_SYSTEM_ERROR;
      break;
    case -3:
      sg_pstDcsApi->cRtnCode = DCS_M_SYSTEM_ERROR;
      break;
    case -4:
      sg_pstDcsApi->cRtnCode = DcsCnvErr();
      sprintf(g_caMsg,"DcsRcvAll:Error Rtn Code=%c",sg_pstDcsApi->cRtnCode);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      break;
    default:
      sg_pstDcsApi->cRtnCode = DCS_M_SYSTEM_ERROR;
      break;
  }

  if (iRc != 0){
    UCP_TRACE_END(-1);
  }

  /* for debug dump rcv data */
  ErrLog(10,"DcsRcvAll:Rcv data=",RPT_TO_LOG,&McaData(sg_stDcsBuf),
         MiDataLen(sg_stDcsBuf)); 

  /* pass file name to AP */
  strcpy(pcRcvFileName,caMsgFileName);

  /* pass data length to API */
  sprintf(caTmpBuf,"%.4d",MiDataLen(sg_stDcsBuf) - 8);
  memcpy(sg_pstDcsApi->caDataLen,caTmpBuf,4);

  ErrLog(10,"DcsRcvAll End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(0);

} /* end of DcsRcv */

/*
*&N& ROUTINE NAME:int DcsStop()
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A&  �L
*&A& 
*&R& RETURN VALUE(S):
*&R&   0 : ���`.
*&R&  -1 : �H�{���N�X�M��|�͸�ƿ��~.
*&R&  -1 : �I�s�����A�ȵ{�����~.
*&R&
*&D& DESCRIPTION:
*&D&   1.�H�{���N�X�M��|�͸��.
*&D&   2.�M���{���N�X���O��.
*&D&   3.�I�s�����A�ȵ{��, �����u���\��, �åB�M���|�͸��.
*&D&
*/

int
DcsStop()
{
  int  iRc;

  UCP_TRACE(P_DcsStop);
  ErrLog(10,"DcsStop Begin.",RPT_TO_LOG,0,0);

  /* search session and conversation id for program id */ 
  iRc = DcsSrhPgId(sg_pstDcsApi->caPrgId,'0');
  if(iRc == -1){
    sprintf(g_caMsg,"DcsStop;Srh PrgId=%.4s error",sg_pstDcsApi->caPrgId);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    sg_pstDcsApi->cRtnCode = DCS_M_PGM_ID_ERROR;
    UCP_TRACE_END(-1);
  } /* end of   if(iRc == -1) */

  iRc = DcsSrhPgId(sg_pstDcsApi->caPrgId,'1');
  if(iRc == -1){
    ErrLog(1000,"DcsStop:Srh PrgId error",RPT_TO_LOG,0,0);
    sg_pstDcsApi->cRtnCode = DCS_M_PGM_ID_ERROR;
    UCP_TRACE_END(-1);
  } /* end of if(iRc == -1) */

#ifdef OLD_UCPDCS
  sg_pstDcsApi->cRtnCode = DCS_M_NORMAL; /* IBM Host deallocate the    */
                                            /* session,so do not stop the */
                                            /* session by AP or UCP       */
  UCP_TRACE_END(0);
#endif

  /* prepare data to call DCSDISCONNECT */
  McRqstCode(sg_stDcsBuf) = DCSDISCONNECT;
  MpstDcsSiof(sg_stDcsBuf) = &sg_stDcsSiof;
  DcsDispatch(&sg_stDcsBuf);

  /* check return code after call DISCONNECT */
  sg_pstDcsApi->cRtnCode = DcsCnvErr();
  if(sg_pstDcsApi->cRtnCode != DCS_M_NORMAL){
    sprintf(g_caMsg,"DcsStop:Error Rtn Code=%c",sg_pstDcsApi->cRtnCode);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  } /* end of if(sg_pstDcsApi->cRtnCode != DCS_M_NORMAL) */

  ErrLog(10,"DcsStop End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(0);
} /* end of DcsStop */

/*
*&N& ROUTINE NAME:int DcsStopAll()
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A&   �L
*&A& 
*&R& RETURN VALUE(S):
*&R&   0 : ���`.
*&R&
*&D& DESCRIPTION:
*&D&   call DcsStop()
*&D&
*/

int
DcsStopAll()
{
  int  i;
  int  iRc = 0;
  char caTmpBuf[20];

  UCP_TRACE(P_DcsStopAll);
  ErrLog(10,"DcsStopAll Begin.",RPT_TO_LOG,0,0);

  sg_pstDcsApi->cRtnCode = DCS_M_NORMAL;
  for(i=0 ; i < MAX_PROGRAM ; i++){
    if(g_stPrgIdTbl[i].iSesIdx != -1){
      sprintf(caTmpBuf,"%.4d",i);
      memcpy(sg_pstDcsApi->caPrgId,caTmpBuf,4);
      iRc = DcsStop();
    }
  } /* end of   for(i=0 ; i < MAX_PROGRAM ; i++) */

  ErrLog(10,"DcsStopAll End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(iRc);
}

/*
*&N& ROUTINE NAME:char DcsCnvErr()
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A&   �L
*&A& 
*&R& RETURN VALUE(S):
*&R&   '0' : DCS_M_NORMAL
*&R&   '1' : DCS_M_COMMAND_ERROR
*&R&   '2' : DCS_M_DATA_ERROR
*&R&   '3' : DCS_M_LOCAL_ERROR
*&R&   '4' : DCS_M_REMOTE_ERROR
*&R&   '5' : DCS_M_NETWORK_ERROR
*&R&   '6' : DCS_M_PGM_ID_ERROR
*&R&   '7' : DCS_M_UCPS_ERROR
*&R&   '8' : DCS_M_CONVSIF_ERROR
*&R&   '9' : DCS_M_CONVSOF_ERROR
*&R&   'A' : DCS_M_TIMEOUT_ERROR
*&R&   'B' : DCS_M_SYSTEM_ERROR
*&R&
*&D& DESCRIPTION:
*&D&   1.�H�����A�ȵ{�����Ǧ^��, �ഫ���r�������~�N��.
*&D&
*/

char
DcsCnvErr()
{
  UCP_TRACE(P_DcsCnvErr);
  switch (MiReply(sg_stDcsBuf)){
    case DCS_NORMAL :
      UCP_TRACE_END(DCS_M_NORMAL);
    case DCS_E_COMMAND :
      UCP_TRACE_END(DCS_M_COMMAND_ERROR);
    case DCS_E_NETWORKTBL :
      UCP_TRACE_END(DCS_M_DATA_ERROR);
    case DCS_E_LOCALDCS :
      UCP_TRACE_END(DCS_M_LOCAL_ERROR);
    case DCS_E_TIMEOUT :
      UCP_TRACE_END(DCS_M_TIMEOUT_ERROR);
    case DCS_E_NETWORK :
      UCP_TRACE_END(DCS_M_NETWORK_ERROR);
    default :
      UCP_TRACE_END(DCS_M_NETWORK_ERROR);
  }
} /* end of DcsCnvErr */

/*
*&N& ROUTINE NAME:int DcsSrhPgId(pcPrgId,cFlag)
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& pcPrgId         char *              �{���N�X�r���Ȫ�pointer
*&A& cFlag           char                �M��|�͸�ƩβM���|�͸�ƪ��N��
*&A&
*&R& RETURN VALUE(S):
*&R&    0 : ���`.
*&R&   -1 : �M����|�͸�ƿ��~.
*&R&   -1 : flag ���~.
*&R&
*&D& DESCRIPTION:
*&D&   1.flag = 0 : �H�{���N�X�M��|�͸��.
*&D&   2.flag = 1 : �M���|�͸��.
*&D&
char *pcPrgId;
char cFlag;
*/

int
DcsSrhPgId(char *pcPrgId,char cFlag)
{
  char caTmpPrgId[5];
  int  iPrgId;

  UCP_TRACE(P_DcsSrhPgId);
  sprintf(g_caMsg,"DcsSrhPgId Begin.pcPrgId=%.4s",pcPrgId);
  ErrLog(10, g_caMsg,RPT_TO_LOG,0,0);

  memcpy(caTmpPrgId,pcPrgId,4);
  caTmpPrgId[4] = '\0';
  iPrgId = atoi(caTmpPrgId);

  switch (cFlag){
  case '0' :
     if(g_stPrgIdTbl[iPrgId].iSesIdx == -1){
       UCP_TRACE_END(-1);
     } /* end of    if(g_stPrgIdTbl[iPrgId].iSesIdx == -1) */
     MiSesIdx(sg_stDcsBuf) = g_stPrgIdTbl[iPrgId].iSesIdx;
     MlSeqNo(sg_stDcsBuf) = g_stPrgIdTbl[iPrgId].lCnvId;
     McProto(sg_stDcsBuf) = g_stPrgIdTbl[iPrgId].cProto;

     /* for debug */
     sprintf(g_caMsg,"DcsSrhPrgId:SessIdx=%d,SeqNo=%d,Proto=%c",
             g_stPrgIdTbl[iPrgId].iSesIdx,g_stPrgIdTbl[iPrgId].lCnvId,
             g_stPrgIdTbl[iPrgId].cProto);
     ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
     break;
  case '1' :
     g_stPrgIdTbl[iPrgId].iSesIdx = -1;
     g_stPrgIdTbl[iPrgId].lCnvId  = -1;
     g_stPrgIdTbl[iPrgId].cProto = ' ';
     break;
  default:
     iPrgId = -1;
     break;
  }     

  ErrLog(10,"DcsSrhPgId End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(iPrgId);
}


/*
*&N& ROUTINE NAME:int GetProtoByDes(char *pcDesCode,char *pcProto)
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    ------------------------------------
*&A& pcDesCode       char *              �ت��N�X�r���}����(pointer)
*&A& pcProto         char *              �Ǧ^�q�T�N���r����}������(pointer)
*&A&
*&R& RETURN VALUE(S):
*&R&     0 : ���`.
*&R&    -1 : �M��q�T��q������~.
*&R&
*&D& DESCRIPTION:
*&D&   1.�M��q�T��q����.
*&D&
*/

int
GetProtoByDes(char *pcDesCode,char *pcProto)
{
  int iRc;
  struct ProtoTblSt stNetwk;

  UCP_TRACE(P_GetProtoByDes);
  ErrLog(10,"GetProtoByDes Begin",RPT_TO_LOG,0,0);

  iRc = 0;
  /* get protocol & server name by des_code */
  iRc = SrhProtoTbl(pcDesCode,&stNetwk);
  if(iRc != 0){
    sprintf(g_caMsg,"GetProtoByDes:Srh Network Table error iRc=%d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(iRc);
  } /* end of if(iRc != 0) */

  /* set dcs_buf protocol */
  *pcProto = stNetwk.cProto;

  ErrLog(10,"GetProtoByDes end",RPT_TO_LOG,0,0);
  UCP_TRACE_END(0);
}

/*
*&N& ROUTINE NAME:int SrhProtoTbl(char *pcDesCode,struct ProtoTblSt *pstNetwk)
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& pcDesCode       char *              �ت��N�X�r���}����(pointer)
*&A& pstNetwk        struct ProtoTblSt * �q�T��q�����}����(pointer)
*&A&
*&R& RETURN VALUE(S):
*&R&    0 : ���`.
*&R&
*&D& DESCRIPTION:
*&D&   1.����ت��N�X.
*&D&   2.�Ǧ^�q�T��q�N�X.
*&D&
*/

int
SrhProtoTbl(char *pcDesCode,struct ProtoTblSt *pstNetwk)
{
   int idx,iRc;
   struct ProtoTblSt *pstNetTbl;
 
   UCP_TRACE(P_SrhProtoTbl);
   sprintf(g_caMsg,"SrhProtoTbl Begin,descod=%.10s",pcDesCode);
   ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);

   pstNetTbl = sg_stProtoTbl;
   idx = 1;
   /* find out in the net work table array */
#ifdef OMIT_BY_WILDCARD
   while((iRc=memcmp(pcDesCode,pstNetTbl[idx].caDesCode,10)) != 0 &&
        idx < MAX_NETWKTBL_ARRAY){
#endif

   while((iRc=CompWildDest(pcDesCode,pstNetTbl[idx].caDesCode, 10)) != 0 &&
        idx < MAX_NETWKTBL_ARRAY){
     idx++;
   } /* end of while() */
   
   /* memory copy from net work table to working area of networktable struct */
   if(idx == MAX_NETWKTBL_ARRAY){
     /* not found in table array, then set default protocol & server name */
     idx = 0;
     memcpy(pstNetwk,&pstNetTbl[0],sizeof(struct ProtoTblSt));
     sprintf(g_caMsg,"SrhProtoTbl:End. Not Found pstNetTbl[0]=");
   }
   else{
     /* found */
     memcpy(pstNetwk,&pstNetTbl[idx],sizeof(struct ProtoTblSt));
     sprintf(g_caMsg,"SrhProtoTbl:End. Found pstNetTbl[%d]=",idx);
   } /* end of if(idx == MAX_NETWKTBL_ARRAY) -- else */

   ErrLog(10,g_caMsg,RPT_TO_LOG,&pstNetTbl[idx],sizeof(struct ProtoTblSt));
   UCP_TRACE_END(0);
}


/*
*&N& ROUTINE NAME: CompWildDest
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   Compare the specified destination code with the destcode in table.
*&D&   The table is in "wild-card" form, and the search is completed
*&D&   if the first entry is matched. 	 
*/
int
CompWildDest(char *pcDesCode, char *pstTblDest, int num)
{
    int i;

    UCP_TRACE(P_CompWildDest);

    for (i=0; i<num && pcDesCode[i] && pcDesCode[i]!=' '; i++) {
        if (pstTblDest[i] != '*') {
	    if (pcDesCode[i] != pstTblDest[i]) {
  		UCP_TRACE_END(-1);
	    }
	}
    }

    if (i<num) {
	if (pstTblDest[i] == '*' || pstTblDest[i] == 0
			|| pstTblDest[i] == ' ') {
	    UCP_TRACE_END(0);
	}
	else {
	    UCP_TRACE_END(-1);
	}
    } else {
	UCP_TRACE_END(0);
    }
}

/*
*&N& ROUTINE NAME:int LoadProtoTbl(struct ProtoTblSt *pstNetTbl)
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- --------------------  -----------------------------------
*&A& pstNetTbl       struct ProtoTblSt *   �ت��N�X�P�q�T��q��Ӫ���}����
*&A&                                       (pointer)
*&A& 
*&R& RETURN VALUE(S):
*&R&   0 : ���`.
*&R&  -1 : �}�ҥت��N�X�P�q�T��w�N������ɿ��~.
*&R&  -1 : ��Ƶ��Ƥj��}�C������~.
*&R&
*&D& DESCRIPTION:
*&D&   1.�}�ҥت��N�X�P�q�T��w�N�������.
*&D&   2.�N�q�T��w�N���ɸ�Ƹ��J��}�C��.
*&D&   3.�ˬd��Ƶ��ƬO�_�j��}�C������.
*&D&
*/

int
LoadProtoTbl(struct ProtoTblSt *pstNetTbl)
{
  int i,j,k;
  FILE *pfNetFd;
  char caFileName[80];

  UCP_TRACE(P_LoadProtoTbl);
  ErrLog(10,"LoadProtoTbl:Begin",RPT_TO_LOG,0,0);

  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat(caFileName, DCS_TABLE_PATH);
  strcat(caFileName,"prototbl");

  /* �}�ҥت��N�X�P�q�T��q�N������� */
  pfNetFd = fopen(caFileName,"r");
  if(pfNetFd == (FILE *) 0){
    sprintf(g_caMsg,"LoadProtoTbl:open %s error,errno=%d",caFileName, errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  } /* end of if(pfNetFd == (FILE *) 0) */

  i = 0;
  /* �N�q�T��q�N���ɸ�� load ��}�C�� */
  while(fscanf(pfNetFd,"%s %c",pstNetTbl[i].caDesCode,
        &pstNetTbl[i].cProto) != EOF){
    /* �ˬd��Ƶ��ƬO�_�j��}�C������ */
    if(i++ > MAX_NETWKTBL_ARRAY){
      ErrLog(1000,"LoadProtoTbl:Table array overflow!",RPT_TO_LOG,0,0);
      fclose(pfNetFd);
      UCP_TRACE_END(-1);
    } /* end of if(i++ > MAX_NETWKTBL_ARRAY) */
  } /* end of while(fscanf(pfNetFd,"%s %c",pstNetTbl[i].caDesCode,
                    &pstNetTbl[i].cProto) != EOF) */
  
  ErrLog(10,"LoadProtoTbl:End",RPT_TO_LOG,0,0);
  fclose(pfNetFd);
  UCP_TRACE_END(0);
}

/*
*&N& ROUTINE NAME:int DcsInitPrgId()
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A&   �L
*&A& 
*&R& RETURN VALUE(S):
*&R&   0 : ���`.
*&R&  -1 : load �q�T��q��ƿ��~.
*&R&
*&D& DESCRIPTION:
*&D&   1.�O�_�Ĥ@��, ���O�h�����U�����ʰ�.
*&D&   1.�]�w�{���N�X���椧�ҩl��.
*&D&   2.load �q�T��q���.
*&D&
*/

int
DcsInitPrgId()
{
  int iRc,i;
  
  UCP_TRACE(P_DcsInitPrgId);
  ErrLog(10,"DcsInitPrgId Begin.",RPT_TO_LOG,0,0);

  /* initial g_stPrgIdTbl */
  if(sg_iFirst){
    for(i=0 ; i < MAX_PROGRAM ; i++){
      g_stPrgIdTbl[i].iSesIdx = -1;
      g_stPrgIdTbl[i].lCnvId  = -1;
      if(g_stPrgIdTbl[i].iFileId >  0 ){
        close(g_stPrgIdTbl[i].iFileId);
      } /* end of if(g_stPrgIdTbl[i].iFileId >  0 ) */
    } /* end of for(i=0 ; i < MAX_PROGRAM ; i++) */
 
    /* initial network table */
    iRc = LoadProtoTbl(sg_stProtoTbl);
    if(iRc != 0){
      ErrLog(1000,"DcsInitPrgId:Load Network Table error",RPT_TO_LOG,0,0);
      UCP_TRACE_END(-1);
    } /* end of if(iRc != 0) */
    sg_iFirst = 0;
  } /* end of if(sg_iFirst) */

  ErrLog(10,"DcsInitPrgId End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(0);
}


/* #ifdef OLD_UCPDCS */
/***************************************************************************/
/* Receive the SIF data passed from the AP and translate it to the real    */
/* SIF format. The format of the sif data passed from AP is:               */
/*  TXN-ID(X(4)),DATA1(X(CTF_LEN1)),DATA2(X(CTF_LEN2)),...                 */
/* and the total length of the above data is passed througth 'total_len'.  */
/* BR-CODE,TM-CODE,TELLER-CODE and ctl-byte is depending on the value when */
/* the transaction is processed.                                           */
/***************************************************************************/

int
ApSifCnv(pcApSif,pcSif,pcTxnCode,pcCtlByte,iTotalLen,iOffLine,
         pcBrCode,pcTmCode,pcTelCode)
char *pcApSif;
char *pcSif;
char *pcTxnCode;
char *pcCtlByte;
int iTotalLen;
int iOffLine;
char *pcBrCode;
char *pcTmCode;
char *pcTelCode;
{
  int i,j,k;

  UCP_TRACE(P_ApSifCnv);
  ErrLog(10,"ApSifCnv Begin.",RPT_TO_LOG,0,0);

  memcpy(pcSif,pcTxnCode,SIF_FMT_LEN);  /* copy CICS txn-code to SIF*/
  memcpy(pcSif+TXN_CODE_OFFSET,pcApSif,4);/* copy txn-id to SIF*/
  memcpy(pcSif+BR_CODE_OFFSET,pcBrCode,3);
  memcpy(pcSif+TELLER_CODE_OFFSET,pcTelCode,2);
  memcpy(pcSif+CTL_BYTE_OFFSET,pcCtlByte,CTL_BYTE_LEN);

  /* for off-line txn, copy tm-code to SIF */ 
  if (iOffLine == 1){
    memcpy(pcSif+TM_CODE_OFFSET,pcTmCode,2 );
  }
  else{
    memcpy(pcSif+TM_CODE_OFFSET,pcTmCode,2 );
  } /* end of if (iOffLine == 1) -- else */
  
  j = SIF_HEAD_LEN;
  memcpy(pcSif+j,pcApSif+4,iTotalLen - 4);

  ErrLog(10,"ApSifCnv End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(j+iTotalLen - 4);
}
/* #endif */

/*
*&N& ROUTINE NAME:int NewApSifCnv()
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A&
*&A& 
*&R& RETURN VALUE(S):
*&R&  > 0 : �ഫ�᪺����.
*&R&
*&D& DESCRIPTION:
*&D&
*/
int
NewApSifCnv(pcApSif,pcSif,pcTxnCode,pcCtlByte,iTotalLen,
            pcBrCode,pcTmCode,pcTelCode,cDataFmt)
char *pcApSif;
char *pcSif;
char *pcTxnCode;
char *pcCtlByte;
int iTotalLen;
char *pcBrCode;
char *pcTmCode;
char *pcTelCode;
char cDataFmt;
{
  int iCnvLen;
  int iCurApOffset;
  int iSifOffset;
  char caDataLen[10];
  short sDataLen;
  char *pcCurSifPtr;

  UCP_TRACE(P_NewApSifCnv);
  ErrLog(10,"NewApSifCnv Begin.dump pcApSif",RPT_TO_LOG,pcApSif,iTotalLen);

  switch(cDataFmt){
    case '0': /* SIF */
      memcpy(pcSif,pcApSif,iTotalLen);
      memcpy(pcSif+CTL_BYTE_OFFSET,pcCtlByte,CTL_BYTE_LEN);
      iCnvLen = iTotalLen;
      break;
    case '1': /* data+data+... , where data is character type */
      memcpy(pcSif,SIF_FMT_1,SIF_FMT_LEN);  /* copy CICS txn-code to SIF*/
      memcpy(pcSif+TXN_CODE_OFFSET,pcTxnCode,MAX_TXN_CODE_LEN);/* copy txn-id */
      memcpy(pcSif+BR_CODE_OFFSET,pcBrCode,BR_CODE_LEN);
      memcpy(pcSif+TM_CODE_OFFSET,pcTmCode,TM_CODE_LEN);
      memcpy(pcSif+TELLER_CODE_OFFSET,pcTelCode,TELLER_CODE_LEN	);
      memcpy(pcSif+CTL_BYTE_OFFSET,pcCtlByte,CTL_BYTE_LEN);
      iCurApOffset = 0;
      pcCurSifPtr = pcSif + SIF_HEAD_LEN;
      while ( iCurApOffset < iTotalLen ) {
        memset(caDataLen, 0, 10);
        memcpy(caDataLen,(char *) (pcApSif+iCurApOffset), 4);
        sDataLen = (short) atoi( caDataLen );
        iCurApOffset += 4;
        if ( (iCurApOffset+sDataLen) > iTotalLen ) {
          sprintf(g_caMsg,"NewApSifCnv:AP SIF total data length=%d error!",
                  iTotalLen);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          UCP_TRACE_END( -1 );         
        }
        else {
          *(pcCurSifPtr) = (char) sDataLen/256;
          *(pcCurSifPtr+1) = (char) sDataLen%256;
          pcCurSifPtr +=  SIF_DATA_LEN_SIZE;
          memcpy(pcCurSifPtr, (char *) (pcApSif+iCurApOffset), sDataLen);
          pcCurSifPtr +=  sDataLen;
          iCurApOffset +=  sDataLen;
        }
      }
      iCnvLen = ( pcCurSifPtr  - pcSif );
      break;
    case '2': /* data+data+... , where data is COBOL     type */
      memcpy(pcSif,SIF_FMT_3,SIF_FMT_LEN);  /* copy CICS txn-code to SIF*/
      memcpy(pcSif+TXN_CODE_OFFSET,pcTxnCode,MAX_TXN_CODE_LEN);/* copy txn-id */
      memcpy(pcSif+BR_CODE_OFFSET,pcBrCode,BR_CODE_LEN);
      memcpy(pcSif+TM_CODE_OFFSET,pcTmCode,TM_CODE_LEN);
      memcpy(pcSif+TELLER_CODE_OFFSET,pcTelCode,TELLER_CODE_LEN	);
      memcpy(pcSif+CTL_BYTE_OFFSET,pcCtlByte,CTL_BYTE_LEN);
      memcpy(pcSif+SIF_HEAD_LEN,pcApSif,iTotalLen);
      iCnvLen = SIF_HEAD_LEN+iTotalLen;
      break;
    case '9': /* txn_code(X(4))+data+data+... , where data is COBOL type */
      memcpy(pcSif,SIF_FMT_3,SIF_FMT_LEN);  /* copy CICS txn-code to SIF*/
      memcpy(pcSif+TXN_CODE_OFFSET,pcApSif,4);/* copy txn-id to SIF*/
      memcpy(pcSif+BR_CODE_OFFSET,pcBrCode,BR_CODE_LEN);
      memcpy(pcSif+TM_CODE_OFFSET,pcTmCode,TM_CODE_LEN);
      memcpy(pcSif+TELLER_CODE_OFFSET,pcTelCode,TELLER_CODE_LEN	);
      memcpy(pcSif+CTL_BYTE_OFFSET,pcCtlByte,CTL_BYTE_LEN);
      memcpy(pcSif+SIF_HEAD_LEN,pcApSif+4,iTotalLen - 4);
      iCnvLen = SIF_HEAD_LEN+iTotalLen - 4;
      break;
    defaule:
      iCnvLen = -1;
  } 
  
  if (iCnvLen > 0){ 
    ErrLog(10,"NewApSifCnv End.dump converted SIF",RPT_TO_LOG,pcSif,iCnvLen);
  }

  UCP_TRACE_END(iCnvLen);
}

/*
*&N& ROUTINE NAME:int DcsStopAllApi()
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A&   �L
*&A& 
*&R& RETURN VALUE(S):
*&R&   0 : ���`.
*&R&
*&D& DESCRIPTION:
*&D&   call DcsStopAll()
*&D&
*/

int
DcsStopAllApi()
{
  int  iRc;
  int  iPargc;
  char *pacArgv[5];
  struct DcsApi stDcsCtlArea;

  UCP_TRACE(P_DcsStopAllApi);
  ErrLog(10,"DcsStopAllApi Begin.",RPT_TO_LOG,0,0);

  iPargc = 4;
  stDcsCtlArea.cFunCode = DCS_M_DISCONNECT_ALL;
  pacArgv[1] = (char *)&stDcsCtlArea;
  pacArgv[2] = "0";
  pacArgv[3] = "0";
  iRc = SbDcs(iPargc,pacArgv);

  ErrLog(10,"DcsStopAllApi End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(iRc);
}

/* -------------------- CONSTANT DEFINE  --------------------------- */
#define  RCV_SOF1_DCS_TIMEOUT           1800
#define  RCV_SOFN_DCS_TIMEOUT           10
#define  CTL_ON			        1
#define  CTL_OFF		        0
#define  LAST_MSG_MASK              	0x80
#define  TPEO_MSG_MASK              	0x02
#define  PRINT_MSG_MASK              	0x10
#define  IS_AP_ABEND              	& 0x08
#define  RCV_OK 			'1'
/* ----------------------------------------------------------------- */

/*
 *&N& ROUNTINE NAME : RcvServerDataToFile()
 *&A& ARGUMENTS: �L
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0.
 *&R&  -1: open  file  error.
 *&R&  -2: write file  error.
 *&R&  -3: close file  error.
 *&R&  -4: call  SbDcs error.
 *&R&
 *&D& DESCRIPTION:
 *&D&  ���� TPU ����X�����e��Ʀ�File.
 *&D&  2.Ū�� TPU �Ҷǰe����X��� SOF.
 *&D&  3.��e TPU �Ҷǰe����X��� SOF �� DBP.
 *&D&  4.�P�O TPU �Ҷǰe����X��� SOF �� status �O�_���� dbp �� ack
 *&D&    �Y�O�h���� DBP �� ack, ����e�� tpu.
 *&D&    �_�h��������.
 *&D&
 */
int
RcvServerDataToFile(char *pcaFileName,char *pcFirstSof,
                    char cProtoType, int iActSess)
{
  int   iRc;
  int   iFd;
  int   iReadSize;
  char  cMoreData;
  int   iCtlFlowFlag; 
  char  caAckBuf[80];
  char  cSofCtlData1;
  int   iSofCnt = 0;
  char  cFirstCtlDataFlag = '1';
  char  cFirstSofCtlData;
  char  caTmpBuf[10];
  char  caRtnCode;

  UCP_TRACE(P_RcvServerDataToFile);

  iCtlFlowFlag = CTL_ON;
  MpstDcsSiof(sg_stDcsBuf) = &sg_stDcsSiof;

  iFd = open(pcaFileName,O_CREAT|O_TRUNC|O_RDWR,0660);
  if ( iFd < 0 ) {
      sprintf(g_caMsg,"RcvServerDataToFile:open File=%s error!",pcaFileName);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      /* disconnect */
      McRqstCode(sg_stDcsBuf) = DCSDISCONNECT;
      McProto(sg_stDcsBuf) = cProtoType;
      MiSesIdx(sg_stDcsBuf) = iActSess ;
      DcsDispatch(&sg_stDcsBuf);
      UCP_TRACE_END(-1);
  }

  for (iSofCnt=0; ; iSofCnt++) {
    /* receive Sof From Remote Host TPU */
    McRqstCode(sg_stDcsBuf) = DCSREAD;
    if (cFirstCtlDataFlag == '1'){
      MlWaiTime(sg_stDcsBuf) = RCV_SOF1_DCS_TIMEOUT;
    }else{
      MlWaiTime(sg_stDcsBuf) = RCV_SOFN_DCS_TIMEOUT;
    }
    MiDataLen(sg_stDcsBuf) = DCS_MAX_DATA_LEN;
    McProto(sg_stDcsBuf) = cProtoType;
    MiSesIdx(sg_stDcsBuf) = iActSess ;
    DcsDispatch(&sg_stDcsBuf);
    if (MiReply(sg_stDcsBuf) != DCS_NORMAL) {
      sprintf(g_caMsg,
              "RcvServerDataToFile: sofCnt=%d,dcsreceive reply=%d,errno=%d",
              iSofCnt, MiReply(sg_stDcsBuf),MiErrno(sg_stDcsBuf));
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      /* disconnect */
      caRtnCode = MiReply(sg_stDcsBuf);
      McRqstCode(sg_stDcsBuf) = DCSDISCONNECT;
      DcsDispatch(&sg_stDcsBuf);
      MiReply(sg_stDcsBuf) = caRtnCode ;
      UCP_TRACE_END(-4);
    }
    iReadSize = MiDataLen(sg_stDcsBuf);

    sprintf(g_caMsg,"RcvServerDataToFile:iSofCnt=%d,iReadSize=%d,dump data is",
            iSofCnt,iReadSize);
    ErrLog(100, g_caMsg, RPT_TO_LOG, MpstDcsSiof(sg_stDcsBuf), iReadSize);

    /* access control byte from SOF header */
    cSofCtlData1 = McaData(sg_stDcsBuf)[SOF_CTL_CODE_OFFSET] ;

    /* bypass the CENTER host TPESDOUT data */
    if ( cSofCtlData1 & PRINT_MSG_MASK ){ /* AP call TPESDOUT API */
      cFirstCtlDataFlag = '1'; /* reset first control flag */
      continue; /* goto begin of while loop */
    }

    if ( iCtlFlowFlag == CTL_ON ) {

      if ( cFirstCtlDataFlag == '1'){
        cFirstSofCtlData = cSofCtlData1;
        memcpy(pcFirstSof, McaData(sg_stDcsBuf) , iReadSize - 8);
        sprintf(g_caMsg,"RcvServerDataToFile:dump pcFirstSof");
        ErrLog(100,g_caMsg,RPT_TO_LOG, pcFirstSof,iReadSize - 8);
        cFirstCtlDataFlag = '0';
      }

      /* write Data of Remote Host TPU Sof to File */
      iRc = write(iFd,McaData(sg_stDcsBuf),MiDataLen(sg_stDcsBuf)-8);
      if( iRc !=  (MiDataLen(sg_stDcsBuf)-8) ) {
        sprintf(g_caMsg,
        "RcvServerDataToFile:write() error! write size=%d,write() rtn size=%d",
                MiDataLen(sg_stDcsBuf)-8,iRc);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        /* disconnect */
        McRqstCode(sg_stDcsBuf) = DCSDISCONNECT;
        DcsDispatch(&sg_stDcsBuf);
        UCP_TRACE_END(-2);
      }

      if ( cSofCtlData1 & LAST_MSG_MASK ) {

        iCtlFlowFlag = CTL_OFF;
        if ( !(cFirstSofCtlData & TPEO_MSG_MASK) ){
          break; /* exit while loop */
        }

        /* send TPEO to Remote Host TPU */
        McRqstCode(sg_stDcsBuf) = DCSWRITE;
        sprintf(McaDataLen(sg_stDcsBuf),"%.5d",4 + 8);
        memcpy(McaData(sg_stDcsBuf), "TPEO", 4);
        MiDataLen(sg_stDcsBuf) = 4 + 8;
        DcsDispatch(&sg_stDcsBuf);
        if(MiReply(sg_stDcsBuf) != DCS_NORMAL){
          sprintf(g_caMsg,"RcvServerDataToFile:DCSWRITE reply=%d errno=%d",
                  MiReply(sg_stDcsBuf),MiErrno(sg_stDcsBuf));
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          caRtnCode = MiReply(sg_stDcsBuf);
          McRqstCode(sg_stDcsBuf) = DCSDISCONNECT;
          DcsDispatch(&sg_stDcsBuf);
          MiReply(sg_stDcsBuf) = caRtnCode ;
          UCP_TRACE_END(-4);
        }

      }/* end of "if ( cSofCtlData1 & LAST_MSG_MASK ) " */

    }
    else {

      /* write Data of Remote Host TPU Sof to File */
      iRc = write(iFd,McaData(sg_stDcsBuf),MiDataLen(sg_stDcsBuf)-8);
      if( iRc !=  (MiDataLen(sg_stDcsBuf)-8) ) {
        sprintf(g_caMsg,
        "RcvServerDataToFile:write() error! write size=%d,write() rtn size=%d",
                MiDataLen(sg_stDcsBuf)-8,iRc);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        /* disconnect */
        McRqstCode(sg_stDcsBuf) = DCSDISCONNECT;
        DcsDispatch(&sg_stDcsBuf);
        UCP_TRACE_END(-2);
      }

      if ( cSofCtlData1 & LAST_MSG_MASK ){
        break; /* exit while loop */
      }

      /* send ACK to Remote Host TPU */
      McRqstCode(sg_stDcsBuf) = DCSWRITE;
      sprintf(McaDataLen(sg_stDcsBuf),"%.5d",1 + 8);
      memcpy(McaData(sg_stDcsBuf), "\0", 1);
      MiDataLen(sg_stDcsBuf) = 1 + 8;
      DcsDispatch(&sg_stDcsBuf);
      if(MiReply(sg_stDcsBuf) != DCS_NORMAL){
        sprintf(g_caMsg,"RcvServerDataToFile:DCSWRITE reply=%d errno=%d",
                MiReply(sg_stDcsBuf),MiErrno(sg_stDcsBuf));
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        caRtnCode = MiReply(sg_stDcsBuf);
        McRqstCode(sg_stDcsBuf) = DCSDISCONNECT;
        DcsDispatch(&sg_stDcsBuf);
        MiReply(sg_stDcsBuf) = caRtnCode ;
        UCP_TRACE_END(-4);
      }

   }

  } /* while(cLoopFlag == 'y') */


  iRc = close(iFd);
  if ( iRc < 0 ) {
    sprintf(g_caMsg,"RcvServerDataToFile:close() File=%s error!",pcaFileName);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    /* disconnect */
    McRqstCode(sg_stDcsBuf) = DCSDISCONNECT;
    DcsDispatch(&sg_stDcsBuf);
    UCP_TRACE_END(-3);
  }

  /* disconnect TPU session */
  McRqstCode(sg_stDcsBuf) = DCSDISCONNECT;
  DcsDispatch(&sg_stDcsBuf);

  UCP_TRACE_END ( 0 );

}  /* RcvServerDataToFile() */
/*==========================================================================*/
