
/*     dcsqtool.c FUNCTION & SUBROUTINE DESCRIPTION
 *&N&   
 *&N&    TYPE      NAME                 DESCRIPTION
 *&N& --------- ---------- ---------------------------------------- 
 *&N& int       MsgqCreat 
 *&N& int       MsgqInit
 *&N& int       MsgqGet
 *&N& int       MsgqWrite
 *&N& int       MsgqRead
 *&N& int       MsgqRemove
 *&N&
 *&N&
 *&N&
 */

/* -------------------- INCLUDE FILES DECLARATION ------------------- */
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <fcntl.h>

#include "errlog.h"
#include "dccmsgq.h"

/* ------------------------------------------------------------------ */
/* dcsqtool.c */
#define P_MsgqCreat 		44201
#define P_MsgqInit 		44202
#define P_MsgqGet 		44203
#define P_MsgqWrite 		44204
#define P_MsgqRead 		44205
#define P_MsgqRemove 		44206
#define P_RmTmpFile 		44207
#define P_DspQuInfo 		44208

/* -------------------- STATIC GLOBAL DECLARATION ------------------- */

/* ------ CALL FUNCTION & SUBROUTINE PROTOTYPE DECLARATIONS --------- */
  
int MsgqCreat(int *iQuId,int iQuSize,int iQuKey);
int MsgqInit(int iQuId,long lQuType);
int MsgqGet(int *iQuId,int iQuKey);
int MsgqWrite(int iQuId,int iQuSize,struct MsgBuf *pstMsgBuf,
              int iIpcFlag,char *file_pre);
int MsgqRead(int iQuId,long lQuType,int *iMaxLen,struct MsgBuf *pstMsgBuf,
             int iIpcFlag);
int MsgqRemove(int iQuId);

extern int  errno;
extern char *sys_errlist[];

/*
 *&N& ROUTINE NAME:
 *&A& ARGUMENTS:
 *&A&   NAME            TYPE                 DESCRIPTION
 *&A& --------------- ----------------    -------------------------
 *&A& 
 *&A& 
 *&R& RETURN VALUE(S):
 *&R&
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D&
 */

int
MsgqCreat(int *iQuId,int iQuSize,int iQuKey)
{
  int iRc;
  struct msqid_ds stMsqIdBuf;

  UCP_TRACE(P_MsgqCreat);

  *iQuId = msgget((key_t)iQuKey, IPC_CREAT);
  if(*iQuId == -1) {
    sprintf(g_caMsg,
    "<DCS> Failure to create queue id with key [0x%0x]! (errno:%d==>%s)",
    iQuKey, errno, sys_errlist[errno]);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(MSGQ_ERROR);
  }

  stMsqIdBuf.msg_perm.mode = 000660;
  stMsqIdBuf.msg_perm.uid=getuid();
  stMsqIdBuf.msg_perm.cuid=getuid();
  stMsqIdBuf.msg_perm.gid=getgid();
  stMsqIdBuf.msg_qbytes = iQuSize; 
  iRc = msgctl((int) *iQuId, IPC_SET, &stMsqIdBuf);
  if(iRc == -1) {
    sprintf(g_caMsg,
    "<DCS> Failure to set message queue with queue id [%d]! (errno:%d==>%s)",
    *iQuId, errno, sys_errlist[errno]);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(MSGQ_ERROR);
  } 
  UCP_TRACE_END(MSGQ_NORMAL);
}

/*
 *&N& ROUTINE NAME:
 *&A& ARGUMENTS:
 *&A&   NAME            TYPE                 DESCRIPTION
 *&A& --------------- ----------------    -------------------------
 *&A& 
 *&A& 
 *&R& RETURN VALUE(S):
 *&R&
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D&
 */
int
MsgqInit(int iQuId,long lQuType)
{
  int iRc;
  struct MsgBuf stMsgBuf;
  struct MsgqHead stMsqHead;
  char   caMsgFileName[256];
  char   caTmpFname[256];

  UCP_TRACE(P_MsgqInit);

  errno=0;
  /*  clear MSGQ messages with key = msg_typ avoid reused old mesgs  */
  while((iRc = msgrcv(iQuId,&stMsgBuf,MSGQ_MAX_LEN,lQuType,IPC_NOWAIT)) > 0){ 
    /* for queue overflow management */
    memcpy(&stMsqHead,stMsgBuf.caText,sizeof(stMsqHead));
    if((stMsqHead.caFileName[0] != '\0') && 
       (memcmp(stMsqHead.caFileName,"             ",MSGQ_TMP_FNAME_LEN) != 0)){
      memcpy(caMsgFileName,stMsqHead.caFileName,9);
      caMsgFileName[9] = '\0';
      sprintf(caTmpFname, "%s/iii/tmp/%s",(char *)getenv("III_DIR"),
              caMsgFileName);
      RmTmpFile(caTmpFname);
    }
  }

  if(errno == ENOMSG){
    UCP_TRACE_END(MSGQ_EOF_ERROR);
  }
  else{
    if (errno != 0) {
      sprintf(g_caMsg,
      "<DCS> Failure to receive queue message with id [%d]! (errno:%d==>%s)", 
      iQuId, errno, sys_errlist[errno]);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(MSGQ_ERROR);
    }
  }

  UCP_TRACE_END(MSGQ_NORMAL);
}

/*
 *&N& ROUTINE NAME:
 *&A& ARGUMENTS:
 *&A&   NAME            TYPE                 DESCRIPTION
 *&A& --------------- ----------------    -------------------------
 *&A& 
 *&A& 
 *&R& RETURN VALUE(S):
 *&R&
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D&
 */
int
MsgqGet(int *iQuId,int iQuKey)
{
  UCP_TRACE(P_MsgqGet);

  /* get the q-id */
  *iQuId=msgget(iQuKey,0);
  if((int) *iQuId == -1 ) {
    sprintf(g_caMsg,
    "<DCS> Message queue key [0x%0x] is available for use! (errno:%d==>%s)",
    iQuKey, errno, sys_errlist[errno]);    
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(MSGQ_ERROR);
  }
  UCP_TRACE_END(MSGQ_NORMAL);
} 
  
/*
 *&N& ROUTINE NAME:
 *&A& ARGUMENTS:
 *&A&   NAME            TYPE                 DESCRIPTION
 *&A& --------------- ----------------    -------------------------
 *&A& 
 *&A& 
 *&R& RETURN VALUE(S):
 *&R&
 *&R&
 *&D& DESCRIPTION:
 *&D&   write a record with key = msg_typ to MSGQ 
 *&D&
 */
int
MsgqWrite(int iQuId,int iQuSize,struct MsgBuf *pstMsgBuf,
          int iIpcFlag,char *file_pre)
{ 
  int iRc;
  int iOverflow;
  int iMsgFd;
  int iErrCount=0;
  static int iMsgFnameSeq=0;
  struct MsgqHead stMsqHead;
  char caMsgFileName[256];
  char caTmpFname[256];

  UCP_TRACE(P_MsgqWrite);

  /* reset tmp f_name */
  ((struct MsgqHead *)(pstMsgBuf->caText))->caFileName[0]='\0';
  memcpy (&stMsqHead, pstMsgBuf->caText, sizeof(stMsqHead));
  if((iIpcFlag != IPC_NOWAIT) && (iIpcFlag != 0)) {
    sprintf (g_caMsg, "<DCS> Illegal IPCS flag [%d]", iIpcFlag);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END (MSGQ_ERROR);
  }

  /* reach the threshold of the Q */
  if(DspQuInfo(iQuId,0,iQuSize) == -1){
    iOverflow = 1;
  }
  else {
    iRc = msgsnd(iQuId,pstMsgBuf,iQuSize,iIpcFlag);
    if(iRc == -1 ){
      /* queue is overflow */
      if(errno == EAGAIN)
        iOverflow = 1;
      else{
        sprintf (g_caMsg,
        "<DCS> Failure to send queue message with qid:[%d] qtype:[%d] qsize:[%d]! (errno:%d==>%s)",
        iQuId, pstMsgBuf->lType, iQuSize, errno, sys_errlist[errno]);
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        DspQuInfo (iQuId,1, iQuSize);
        UCP_TRACE_END (MSGQ_ERROR);
      }
    }
    else {
      iOverflow = 0;
    }
  }

  /* for manage queue overflow. The length of the Msg File Name is 9, and */
  /* the length of the temp-file-name's prefix is 3. Therefore, the max.  */
  /* length of the seq-number can be 5. This is why, the max. digit of    */
  /* the sequence number is 5.                                            */
  if(iOverflow == 1){
    /*if sequential no. reaches the upper bound, reset it */
#ifdef OLD_GET_FILENAME
    if((++iMsgFnameSeq) == 99999){
      iMsgFnameSeq=0;
    }
    sprintf(caMsgFileName,"%s%d",file_pre,iMsgFnameSeq);
#else
    memset(caMsgFileName, '\0', sizeof(caMsgFileName));
    tmpnam(caTmpFname);
    sprintf(g_caMsg,"<DCS> Queue overflowed tmpnam(tmp_fname)=%s",caTmpFname);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);  /* for debugging */
    /* bypass P_tmpdir=/var/tmp/ define in stdio.h */
    strcpy(caMsgFileName,caTmpFname+strlen(P_tmpdir));
    caMsgFileName[9] = '\0';
#endif
    /* for debugging */
    sprintf(caTmpFname, "%s/iii/tmp/%s",(char *)getenv("III_DIR"),
            caMsgFileName);
    sprintf(g_caMsg, "<DCS> Queue overflow TmpFileName=%s",caTmpFname);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);

    if((iMsgFd = open(caTmpFname,O_WRONLY|O_EXCL|O_CREAT,0660)) < 0){
      /* opening an in-used temporary file, try next */
      /* seqential  no. reaches the upper bound, reset it. */
#ifdef OLD_GET_FILENAME
      if((++iMsgFnameSeq) == 99999){
        iMsgFnameSeq=0;
      }
      sprintf(caMsgFileName,"%s%d",file_pre,iMsgFnameSeq);
      if((++iErrCount) == 99999){
        sprintf (g_caMsg, "<DCS> Failure to open temp file! (errno:%d==>%s)",
                 caTmpFname, errno, sys_errlist[errno]);
        ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
        UCP_TRACE_END (MSGQ_ERROR);
      }
#endif
      sprintf (g_caMsg, "<DCS> Failure to open temp file! (errno:%d==>%s)",
               caTmpFname, errno, sys_errlist[errno]);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      UCP_TRACE_END(MSGQ_ERROR);
    }

    iRc = write(iMsgFd,pstMsgBuf->caText+sizeof(stMsqHead),
                iQuSize-sizeof(stMsqHead));
    if(iRc < iQuSize-sizeof(stMsqHead)){
      sprintf(g_caMsg,
      "<DCS> Failure to write message queue temp file [%s]! (errno:%d==>%s)",
      caTmpFname, errno, sys_errlist[errno]);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      close (iMsgFd);
      RmTmpFile (caTmpFname);
      UCP_TRACE_END (MSGQ_ERROR);
    } 
    close(iMsgFd);  /* close temporary file if write succefully */
    memcpy(stMsqHead.caFileName,caMsgFileName,9);
    memcpy(pstMsgBuf->caText,&stMsqHead,sizeof(stMsqHead));
    iRc = msgsnd(iQuId,pstMsgBuf,sizeof(stMsqHead),iIpcFlag);
    if(iRc == -1){
      sprintf(g_caMsg,
  "<DCS> Failure to send queue message with qid:[%d] qtype:[%d] qsize:[%d]! (errno:%d==>%s)",
      iQuId, pstMsgBuf->lType, iQuSize, errno, sys_errlist[errno]);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      RmTmpFile (caTmpFname);
      DspQuInfo (iQuId, 1, iQuSize);
      UCP_TRACE_END (MSGQ_ERROR);
    }
  } /* end of (iOverflow == 1) */

  UCP_TRACE_END(MSGQ_NORMAL);
}

/*
 *&N& ROUTINE NAME:
 *&A& ARGUMENTS:
 *&A&   NAME            TYPE                 DESCRIPTION
 *&A& --------------- ----------------    -------------------------
 *&A& 
 *&A& 
 *&R& RETURN VALUE(S):
 *&R&
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D&
 */

int
MsgqRead(int iQuId,long lQuType,int *iMaxLen,struct MsgBuf *pstMsgBuf,
         int iIpcFlag)
{
  int iRc;
  int iMsgFd;
  int iMsgLen;  /* for debugging only */
  int iQuMaxLen;
  struct MsgqHead stMsqHead;
  char caMsgFileName[256];
  char caTmpFname[256];

  UCP_TRACE(P_MsgqRead);

  if((iIpcFlag != IPC_NOWAIT) && (iIpcFlag != 0)) {
    sprintf(g_caMsg,"<DCS> Illegal queue message flag [%d]!", iIpcFlag);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(MSGQ_ERROR);
  }

  iQuMaxLen = *iMaxLen;
  iMsgLen = msgrcv(iQuId,pstMsgBuf,iQuMaxLen,lQuType,iIpcFlag);
  if(iMsgLen == -1){
    if(errno == ENOMSG){
      sprintf (g_caMsg,
      "<DCS> No message received from queue with qid [%d]", iQuId);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      UCP_TRACE_END (MSGQ_EOF_ERROR);
    }
    else {
      sprintf(g_caMsg,
      "<DCS> Failure to receive queue message with qid [%d]! (errno:%d==>%s)", 
      iQuId, errno, sys_errlist[errno]);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);

      if(errno == EINTR){ 
        UCP_TRACE_END(MSGQ_TIMEOUT);
      }

      if(errno != E2BIG){ 
        UCP_TRACE_END(MSGQ_ERROR);
      }
      else {
        /* iIpcFlag &= MSG_NOERROR; */
        iIpcFlag |= MSG_NOERROR;
        iQuMaxLen = *iMaxLen;
        iMsgLen = msgrcv(iQuId,pstMsgBuf,iQuMaxLen,lQuType,iIpcFlag);
        if (iMsgLen == -1) {
          sprintf(g_caMsg,
       "<DCS> Failure to receive queue message with qid [%d]! (errno:%d==>%s)", 
         iQuId, errno, sys_errlist[errno]);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          UCP_TRACE_END(MSGQ_ERROR);
        }
        else {
          sprintf(g_caMsg,
"<DCS> Queue message received with qid [%d] is not complete! (errno:%d==>%s)", 
          iQuId, errno, sys_errlist[errno]);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          UCP_TRACE_END(MSGQ_TRUN_ERROR);
        }
      }  /* for if (errno != E2BIG) */
    }  /* for if (errno == ENOMSG) */
  }

  /* for return realy msg_len */
  memcpy(&stMsqHead,pstMsgBuf->caText,sizeof(stMsqHead));
  if((stMsqHead.caFileName[0] == '\0') ||
     (memcmp(stMsqHead.caFileName,"             ",MSGQ_TMP_FNAME_LEN)==0)){
    *iMaxLen = iMsgLen;
    UCP_TRACE_END(MSGQ_NORMAL);
  }
  else {
    /* the content of the message is in the file */
    memcpy(caMsgFileName, stMsqHead.caFileName, 9);
    caMsgFileName[9] = '\0';
    sprintf(caTmpFname, "%s/iii/tmp/%s",(char *)getenv("III_DIR"),
            caMsgFileName);
    sprintf(g_caMsg,"<DCS> MsgqRead:Data in file:%s",caTmpFname);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    iMsgFd = open(caTmpFname,O_RDONLY);
    if(iMsgFd < 0) {
      sprintf(g_caMsg, "<DCS> MsgqRead:open %s fail,errno=%d", 
      caTmpFname, errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(MSGQ_ERROR);
    }

    iRc = read(iMsgFd,pstMsgBuf->caText+sizeof(stMsqHead),*iMaxLen);
    if(iRc <= 0 ){
      sprintf(g_caMsg,"<DCS> MsgqRead:Read %s fail,errno=%d", caTmpFname,errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      close(iMsgFd);
      RmTmpFile(caTmpFname);
      UCP_TRACE_END(MSGQ_ERROR);
    }
    *iMaxLen = iRc + sizeof(stMsqHead);
    close(iMsgFd);
    RmTmpFile(caTmpFname);
    UCP_TRACE_END(MSGQ_NORMAL);
  }
}


/*
 *&N& ROUTINE NAME:
 *&A& ARGUMENTS:
 *&A&   NAME            TYPE                 DESCRIPTION
 *&A& --------------- ----------------    -------------------------
 *&A& 
 *&A& 
 *&R& RETURN VALUE(S):
 *&R&
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D&
 */

int
MsgqRemove(int iQuId)
{
  int iRc;

  UCP_TRACE(P_MsgqRemove);
  iRc = msgctl(iQuId, IPC_RMID, 0);
  if(iRc == -1){
    sprintf(g_caMsg,
    "<DCS> Failure to remove message queue with qid [%d]! (errno:%d==>%s)",
    iQuId, errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END (MSGQ_ERROR);
  }
  UCP_TRACE_END (MSGQ_NORMAL);
}


/*
 *&N& ROUTINE NAME:
 *&A& ARGUMENTS:
 *&A&   NAME            TYPE                 DESCRIPTION
 *&A& --------------- ----------------    -------------------------
 *&A& 
 *&A& 
 *&R& RETURN VALUE(S):
 *&R&
 *&R&
 *&D& DESCRIPTION:
 *&D&   Modify by Dao-Ming  81/06/25
 *&D&   DspQuInfo(iQid,iDisp) 
 *&D&   DspQuInfo(iQid,iDisp,iDataSize)
 *&D&   iWaterLev=((((stMsqIdBuf.msg_cbytes*1000)/stMsqIdBuf.msg_qbytes)+5/10)
 *&D&   iWaterLev=((((stMsqIdBuf.msg_cbytes+iDataSize)*1000)/
 *&D&                 stMsqIdBuf.msg_qbytes)+5/10);
 */

int
DspQuInfo(int iQid,int iDisp,int iDataSize)
{
  int iWaterLev;
  struct msqid_ds stMsqIdBuf;

  msgctl(iQid,IPC_STAT,&stMsqIdBuf);

  /*if iDisp flag is 1 then show Q. information to log file*/
  if(iDisp == 1){
    sprintf(g_caMsg,"<DCS> number of byte on queue:%d",stMsqIdBuf.msg_cbytes);
    ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
    sprintf(g_caMsg,"<DCS> number of message on queue:%d",stMsqIdBuf.msg_qnum);
    ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
    sprintf(g_caMsg,"<DCS> max. number of bytes allowed on queue:%d",
            stMsqIdBuf.msg_qbytes);
    ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
    sprintf (g_caMsg,"<DCS> last process perform msgsnd:%d",
             stMsqIdBuf.msg_lspid);
    ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
    sprintf(g_caMsg,"<DCS> last process perform msgrcv:%d",
            stMsqIdBuf.msg_lrpid);
    ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
  }

  /* check if the occupied space in the queue reach the threshold */
  iWaterLev=((((stMsqIdBuf.msg_cbytes+iDataSize)*1000)/
                stMsqIdBuf.msg_qbytes+5)/10);
  if(iWaterLev >= MSGQ_THRESHOLD) {
    sprintf(g_caMsg,"<DCS> Q-id:%d  water-level=%d",iQid,iWaterLev);
    ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
    return(-1);
  }
  else{
    return(0);
  }
}


/*
 *&N& ROUTINE NAME:
 *&A& ARGUMENTS:
 *&A&   NAME            TYPE                 DESCRIPTION
 *&A& --------------- ----------------    -------------------------
 *&A& 
 *&A& 
 *&R& RETURN VALUE(S):
 *&R&
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D&
 */

int 
RmTmpFile(char *pcTmpFile)
{
  int  iRc;
  iRc = unlink(pcTmpFile);
  return(iRc);
}

/*
 *&N& ROUTINE NAME:
 *&A& ARGUMENTS:
 *&A&   NAME            TYPE                 DESCRIPTION
 *&A& --------------- ----------------    -------------------------
 *&A& iQuId           int                 queue ID 
 *&A& lQuType         long                queue type for initial
 *&A& lMyQuType       long                queue type for myself
 *&A& 
 *&R& RETURN VALUE(S):
 *&R&       0: Normal.
 *&R&      -4: Read queue error.
 *&R&     -99: No any lQuType message in queue.  
 *&R&          Read message queue type is not lMyQuType. 
 *&R&
 *&R&
 *&D& DESCRIPTION:
 *&D&   clear connect message.
 *&D&
 */
int
ConnectMsgqInit(int iQuId,long lQuType, long lMyQuType)
{
  int iRc;
  struct MsgBuf stMsgBuf;
  struct MsgqHead stMsqHead;
  char   caMsgFileName[256];
  char   caTmpFname[256];

  UCP_TRACE(P_MsgqInit);

  errno=0;
  /*  clear MSGQ messages with key = msg_typ avoid reused old mesgs  */
  iRc = msgrcv(iQuId,&stMsgBuf,MSGQ_MAX_LEN,lQuType,IPC_NOWAIT);
  /* for queue overflow management */
  if (iRc != -1) {
    memcpy(&stMsqHead,stMsgBuf.caText,sizeof(stMsqHead));
    if((stMsqHead.caFileName[0] != '\0') && 
       (memcmp(stMsqHead.caFileName,"             ",MSGQ_TMP_FNAME_LEN) != 0)){
      memcpy(caMsgFileName,stMsqHead.caFileName,9);
      caMsgFileName[9] = '\0';
      sprintf(caTmpFname, "%s/iii/tmp/%s",(char *)getenv("III_DIR"),
              caMsgFileName);
      RmTmpFile(caTmpFname);
    }
  
    if(stMsqHead.lExpType != lMyQuType){
      sprintf(g_caMsg,"<DCS> ConnectMsgqInit:error lExpType=%d,lMyQuType=%d",
              stMsqHead.lExpType, lMyQuType);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(-99);
    }
    UCP_TRACE_END(MSGQ_NORMAL);
  } 
  else {

    if(errno == ENOMSG){
     UCP_TRACE_END(-99);
    }
    else{
      sprintf(g_caMsg,
      "<DCS> Failure to receive queue message! (errno:%d==>%s)",
      errno, sys_errlist[errno]);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(MSGQ_ERROR);
    }
  }

}
