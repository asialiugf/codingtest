/*******************/
/* include library */
/*******************/
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <fcntl.h>
#include "errlog.h"
#include "dccmsgq.h"

struct dcs_msg_buf {
  struct MsgqHead q_head;
  char msg_cont[MSGQ_MAX_LEN    ];     /* max message length in INPUT-Q */
};   

main()
{ 
    int qkey;
    int qid;
    int rc;
    int msglen, data_len;
    struct MsgBuf msgp;
    struct dcs_msg_buf dcs_msg;
    size_t max_len=6400;
    char choice,dummy;
    static int nufirst=0;
    char caLogName[256];

    SignlHdl();
    sprintf(caLogName, "%s/iii/log/rdq_errlog", getenv("III_DIR") );
    ChgLog(LOG_CHG_MODE,"1");
    ChgLog(LOG_CHG_LOG,caLogName);
    while(1){

        system("clear");
        printf("\n\n\n\n1.Reading queue with queue_key.\n");
        printf("2.Reading queue with queue_id.\n");
        printf("3.Quit.\n");
        fscanf(stdin,"%c",&choice);

        switch (choice){
          case '1':
             printf("Please input queue key = ");
             fscanf(stdin,"%i", &qkey);
             qid=msgget((key_t)qkey,0);   /* get the q-id */
             if((int) qid == -1 ) {
               printf("get msgq error,errno = %d\n",errno);
               scanf("%c",&dummy);
               continue;
             }
             break;
          case '2':
             printf("Please input queue id = ");
             fscanf(stdin,"%i", &qid);
             break;
          case '3':
             exit(1);
          default:
             continue;
        }
        scanf("%c",&dummy);

        while(1){
           if((msglen=msgrcv(qid, &msgp, max_len, 0, IPC_NOWAIT)) == -1) {
              if (errno == ENOMSG){
                  printf("eof msg----\n");
                  scanf("%c",&dummy);
                  break;
              }
              else {
                  if ( errno == E2BIG ) { 
                     printf("received a truncated message !LEN=%d\n",msglen);
                     scanf("%c",&dummy);
                     break;
                  }
                  else{
                     printf("msgrcv errno=%d\n",errno);
                     scanf("%c",&dummy);
                     break;
                  } /* end if */
              } /* end else */
           } /* end if */

           /* set up msg queue data */
           ErrLog(0,"--------------- Message Information Begin ----------------"
                  ,RPT_TO_LOG,0,0);
           memcpy(&dcs_msg,msgp.caText,msglen); 
           sprintf(g_caMsg,"Message in Queue,type=%d,len=%d",msgp.lType,msglen);
           ErrLog(0,g_caMsg,RPT_TO_LOG,0,0);
           /* set up input queue data structure */
           sprintf(g_caMsg,"queue head,type =%d", dcs_msg.q_head.lExpType);
           ErrLog(0,g_caMsg,RPT_TO_LOG,0,0);
           sprintf(g_caMsg,"queue head,msg_len=%d",dcs_msg.q_head.iLen);
           ErrLog(0,g_caMsg,RPT_TO_LOG,0,0);
           sprintf(g_caMsg,"queue head,msg_kind=%d" ,dcs_msg.q_head.iKind);
           ErrLog(0,g_caMsg,RPT_TO_LOG,0,0);
           sprintf(g_caMsg,"queue head,filename=%.9s",
                                                dcs_msg.q_head.caFileName);
           ErrLog(0,g_caMsg,RPT_TO_LOG,0,0);
           sprintf(g_caMsg,"Dump message content");
           ErrLog(1000,g_caMsg,RPT_TO_LOG,msgp.caText,msglen);
           ErrLog(0,"--------------- Message Information End   ----------------"
                  ,RPT_TO_LOG,0,0);
        } /* end while */
    } /* end while */
} /* end main */
 
