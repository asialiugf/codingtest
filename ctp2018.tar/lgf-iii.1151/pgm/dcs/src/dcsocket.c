/*     FUNCTION & SUBROUTINE DESCRIPTION
*&N&   
*&N&    TYPE      NAME                 DESCRIPTION
*&N& --------- ---------- ---------------------------------------- 
*&N& 
*&N&
*&N&
*&N&
*&N&
*&N&
*&N&
*&N&
*&N&
*/

/* -------------------- INCLUDE FILES DECLARATION ------------------- */
#include <sys/types.h>
#include <sys/socket.h>
/* #include <sys/un.h> */
#include <sys/signal.h>
#include <netinet/in.h>
#include <netdb.h>
#include <fcntl.h>
#include <errno.h>
#include "errlog.h"
#include "dcs.h"

#define FORKED              0       /* fork flage 1=yes 0=no          */
#define MAX_LISTEN          5
#define MAX_NETWKTBL_ARRAY  30
#define SOCKET_TABLE        "socketbl"
/* ------------- dcsocket.c function ���N�� ------------------------- */
#define P_DcsSocket         43101
#define P_DcsSkInitial      43102
#define P_DcsSkAccept       43103
#define P_DcsSkConnect      43104
#define P_DcsSkDisconnect   43105
#define P_DcsSkReceive      43106
#define P_DcsSkSend         43107
#define P_DcsSkTerminate    43108
#define P_GetHostServName   43109
#define P_SrhSkNetwkTbl     43110
#define P_LoadSkNetwkTbl    43111
#define P_DcsSkNull         43112

struct SocketSess {
  char caDesAdd[10];
  char caSrcAdd[10];
  int iSocketId;
  char cStatus;
  char cLastAct;	
  char cMode;
};

struct SkNetwk {
  char caDesCode[11];
  char caField[2][20];
};

/* -------------------- STATIC GLOBAL DECLARATION ------------------- */
static int gs_iFirst=1; /* first flage 1=yes 0=no          */
static int gs_iResiSkId; /* socket id form resident passive, call dcs_initial */
static int gs_iMaxLoad;

struct sockaddr_in stServ;
struct servent *pstServEnt;
struct hostent *pstHostEnt;
struct SocketSess g_stSkSesTbl[MAX_SESS];
struct SkNetwk g_stSkNetTbl[MAX_NETWKTBL_ARRAY];

/* ------ CALL FUNCTION & SUBROUTINE PROTOTYPE DECLARATIONS --------- */
int DcsSocket(struct DcsBuf *pstDcsBuf);
int DcsSkInitial(struct DcsBuf *pstDcsBuf,struct SocketSess *pstSess,
                 char cMode);
int DcsSkConnect(struct DcsBuf *pstDcsBuf,struct SocketSess *pstSess);
int DcsSkAccept(struct DcsBuf *pstDcsBuf,struct SocketSess *pstSess);
int DcsSkSend(struct DcsBuf *pstDcsBuf,struct SocketSess *pstSess);
int DcsSkReceive(struct DcsBuf *pstDcsBuf,struct SocketSess *pstSess);
int DcsSkDisconnect(struct DcsBuf *pstDcsBuf,struct SocketSess *pstSess);
int DcsSkTerminate(struct DcsBuf *pstDcsBuf);
int GetHostServName(char *pcDesCode,char *pcHostName,char *pcServName);
int SrhSkNetwkTbl(char *pcDesCode,struct SkNetwk *pstNetTbl);
int LoadSkNetwkTbl(struct SkNetwk *pstNetTbl);
void DcsSkNull();

extern int  errno;
extern char *sys_errlist[];
  
/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   main program of interface between DCS and AP
*&D&
*/

int
DcsSocket(struct DcsBuf *pstDcsBuf)
{
  int iRc;
  struct SocketSess *pstSess;

  UCP_TRACE(P_DcsSocket);

  pstSess = g_stSkSesTbl;
  iRc = 0;
  switch (PcRqstCode(pstDcsBuf)){
   case DCSINITIAL:
     iRc = DcsSkInitial(pstDcsBuf,pstSess,'A');
     break;
   case DCSCONNECT:
     /* do DcsSkInitial when FIRST */
     if(gs_iFirst){
       iRc = DcsSkInitial(pstDcsBuf,pstSess,'A');
       if(iRc != DCS_NORMAL){
         break;
       }
       gs_iFirst = 0;
     }
     iRc = DcsSkConnect(pstDcsBuf,pstSess);
     break;
   case DCSACCEPT:
     /* do DcsSkInitial when FIRST */
     if(gs_iFirst){
       iRc = DcsSkInitial(pstDcsBuf,pstSess,'P');
       if(iRc != DCS_NORMAL){
         break;
       }
       gs_iFirst = 0;
     }
     iRc = DcsSkAccept(pstDcsBuf,pstSess);
     break;
   case DCSCONNECTWRITE:
     /* do DcsSkInitial when FIRST */
     if(gs_iFirst){
       iRc = DcsSkInitial(pstDcsBuf,pstSess,'A');
       if(iRc != DCS_NORMAL){
         break;
       }
       gs_iFirst = 0;
     }
     iRc = DcsSkConnect(pstDcsBuf,pstSess);
     if(iRc != DCS_NORMAL){
       break;
     }
     iRc = DcsSkSend(pstDcsBuf,pstSess);
     break;
   case DCSWRITE:
     iRc = DcsSkSend(pstDcsBuf,pstSess);
     break;
   case DCSWRDISCONECT:
     iRc = DcsSkSend(pstDcsBuf,pstSess);
     if(iRc == DCS_NORMAL){
       iRc = DcsSkDisconnect(pstDcsBuf,pstSess);
     }
     break;
   case DCSACCEPTREAD:
     /* do DcsSkInitial when FIRST */
     if(gs_iFirst){
       iRc = DcsSkInitial(pstDcsBuf,pstSess,'P');
       if(iRc != DCS_NORMAL){
         break;
       }
       gs_iFirst = 0;
     }
     iRc = DcsSkAccept(pstDcsBuf,pstSess);
     if(iRc != DCS_NORMAL){
       break;
     }
     iRc = DcsSkReceive(pstDcsBuf,pstSess);
     break;
   case DCSREAD:
     iRc = DcsSkReceive(pstDcsBuf,pstSess);
     break;
   case DCSDISCONNECT:
     iRc = DcsSkDisconnect(pstDcsBuf,pstSess);
     break;
   case DCSTERMINATE:
     iRc = DcsSkTerminate(pstDcsBuf);
     break;
   case DCSABORT:
     iRc = 0;
     break;
   default:
     sprintf(g_caMsg,"<DCS> Invalid reguest [%c]",PcRqstCode(pstDcsBuf));
     ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
     iRc = DCS_E_COMMAND;
     break;
  } /* end switch */

  PiReply(pstDcsBuf) = iRc;
  UCP_TRACE_END(iRc);
} /* end of sbdbs */

/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   This function is null
*&D&
*/

int
DcsSkInitial(struct DcsBuf *pstDcsBuf,struct SocketSess *pstSess,char cMode)
{
  int iIdx;
  int iSkId;
  int iRc;
  struct SkNetwk *pstNetTbl;
  char caServName[20];
  char caHostName[20];    /* for socket dcs */

  UCP_TRACE(P_DcsSkInitial);

  /* load socket network table */
  pstNetTbl = g_stSkNetTbl;
  iRc = LoadSkNetwkTbl(pstNetTbl);
  if(iRc != 0){
    ErrLog(10000,"<DCS> Failure to load socket table",RPT_TO_LOG,0,0);
    PiErrno(pstDcsBuf) = iRc;
    UCP_TRACE_END(DCS_E_NETWORKTBL);
  }

  /* initial session table */
  for(iIdx=0; iIdx<MAX_SESS; iIdx++){
    memset(pstSess[iIdx], 0x0, sizeof(struct SocketSess) );
    pstSess[iIdx].cStatus = DCS_S_FREE ;
    pstSess[iIdx].iSocketId = -1;
  }

  /* when mode=Active or mode=Passive and
    server be forked then return normal */
  if((cMode == ACTIVE_MODE) || (cMode == PASSIVE_MODE && FORKED)){
    UCP_TRACE_END(DCS_NORMAL);
  }
  
  /* get server name and host name from dcs_buf data */
  GetHostServName(PcaDesCode(pstDcsBuf),caHostName,caServName);

  /* get server by name */
  pstServEnt = getservbyname(caServName,"tcp");
  if (pstServEnt == 0) {
    sprintf (g_caMsg,
             "<DCS> Failure to get server by name [%s]! (errno:%d==>%s)",
             caServName, errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = errno;
    UCP_TRACE_END (DCS_E_NETWORKTBL);
  }

  /* get host by name */
  pstHostEnt = gethostbyname(caHostName);
  if (pstHostEnt == 0){
    sprintf (g_caMsg,
             "<DCS> Failure to get host by name [%s]! (errno:%d==>%s)",
             caHostName, errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = errno;
    UCP_TRACE_END (DCS_E_NETWORKTBL);
  }

  /* prepare server data */
  memset((char *)&stServ,0,sizeof(stServ));
  memcpy((char *)&stServ.sin_addr,pstHostEnt->h_addr,pstHostEnt->h_length);
  stServ.sin_family = pstHostEnt->h_addrtype;
  stServ.sin_port = pstServEnt->s_port;

  /* get socket id */
  iSkId = socket(AF_INET,SOCK_STREAM,0);
  if(iSkId < 0){
    sprintf (g_caMsg,
             "<DCS> Failure to perform socket system call! (errno:%d==>%s)",
             errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = errno;
    UCP_TRACE_END(iSkId);
  }

  /* bind name -- don't include null char in the name */
  iRc = bind (iSkId, (struct sockaddr *)&stServ, sizeof(stServ));
  if (iRc < 0){
    sprintf (g_caMsg,
             "<DCS> Failure to bind socket with id [%d]! (errno:%d==>%s)",
             iSkId, errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = errno;
    UCP_TRACE_END(iRc);
  }

  iRc = listen(iSkId, MAX_LISTEN);
  if (iRc < 0){
    sprintf (g_caMsg, 
             "<DCS> Failure to listen socket with id [%d]! (errno:%d==>%s)",
             iSkId, errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = errno;
    UCP_TRACE_END(iRc);
  }

  gs_iResiSkId = iSkId;
  UCP_TRACE_END(DCS_NORMAL);
}

/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   connect to host
*&D&
*/

int
DcsSkConnect(struct DcsBuf *pstDcsBuf,struct SocketSess *pstSess)
{
  int iRc;
  int iIdx;
  int iSkId;
  char caServName[20];
  char caHostName[20];    /* for socket dcs */
 
  UCP_TRACE(P_DcsSkConnect);

  /* search a usable dialogue  */
  iIdx = 1;
  while(pstSess[iIdx].cStatus != DCS_S_FREE &&
        pstSess[iIdx].cStatus != DCS_S_ERROR &&
        pstSess[iIdx].cStatus != DCS_S_USABLE &&
        iIdx < MAX_SESS) iIdx++;

  if (iIdx == MAX_SESS){
    sprintf (g_caMsg, "<DCS> No available session for socket connection");
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = DCS_ES_SESOVERFLW;
    UCP_TRACE_END(DCS_E_LOCALDCS);
  }
  /* initial sess */
  memset(&pstSess[iIdx], 0x0, sizeof(struct SocketSess) );

  /* get server name and host name from dcs_buf data */
  GetHostServName(PcaDesCode(pstDcsBuf),caHostName,caServName);

  /* get server by name */
  pstServEnt = getservbyname(caServName,"tcp");
  if(pstServEnt == 0){
    sprintf (g_caMsg,
             "<DCS> Failure to get server by name [%s]! (errno:%d==>%s)",
             caServName, errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = errno;
    UCP_TRACE_END(DCS_E_NETWORKTBL);
  }

  /* get host by name */
  pstHostEnt = gethostbyname(caHostName);
  if(pstHostEnt == 0){
    sprintf (g_caMsg,
             "<DCS> Failure to get host by name [%s]! (errno:%d==>%s)",
             caHostName, errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = errno;
    UCP_TRACE_END(DCS_E_NETWORKTBL);
  }

  /* prepare server data for socket */
  memset((char *)&stServ,0,sizeof(stServ));
  memcpy((char *)&stServ.sin_addr,pstHostEnt->h_addr,pstHostEnt->h_length);
  stServ.sin_family = pstHostEnt->h_addrtype;
  stServ.sin_port = pstServEnt->s_port;

  /* socket function */
  iSkId = socket(AF_INET,SOCK_STREAM,0);
  if(iSkId < 0){
    sprintf (g_caMsg,
             "<DCS> Failure to perform socket system call! (errno:%d==>%s)",
             errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = errno;
    /* TCC: 1996/01/17   
    UCP_TRACE_END(iSkId);
       TCC: 1996/01/17  */
    UCP_TRACE_END(DCS_E_NETWORK); 
  }
  
  /* connect to serv */
  iRc = connect(iSkId,(struct sockaddr *)&stServ,sizeof(stServ));
  if(iRc == -1){
    sprintf (g_caMsg,
    "<DCS> Failure to connect with socket id [%d]! (errno:[%d]==>%s)",
    iSkId, errno, sys_errlist[errno]);
    ErrLog (1000,g_caMsg,RPT_TO_LOG,0,0);
    PiErrno(pstDcsBuf) = errno;
    /* TCC: 1996/01/17   
    UCP_TRACE_END(iRc);
       TCC: 1996/01/17  */
    UCP_TRACE_END(DCS_E_NETWORK); 
  }
     
  /* save the session information */
  pstSess[iIdx].cStatus = DCS_S_USED ;
  pstSess[iIdx].iSocketId = iSkId;
  pstSess[iIdx].cLastAct = DCSCONNECT;
  pstSess[iIdx].cMode = ACTIVE_MODE;

  /* fill DCS buff */
  PiSesIdx(pstDcsBuf) = iIdx;
  PiErrno(pstDcsBuf) = 0;
  PcProto(pstDcsBuf) = SOCKET_DCS;

  sprintf (g_caMsg,
           "<DCS> Connect ok with session [%d] & socket id [%d]",
           iIdx,iSkId);
  ErrLog (10,g_caMsg,RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}

/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   accept
*&D&
*/

int
DcsSkAccept(struct DcsBuf *pstDcsBuf,struct SocketSess *pstSess)
{
  int iAcepSkId,iIdx,iRc;
  int iServLen;

  UCP_TRACE(P_DcsSkAccept);

  /* search a usable dialogue  */
  iIdx = 1;
  while(pstSess[iIdx].cStatus != DCS_S_FREE &&
        pstSess[iIdx].cStatus != DCS_S_USABLE &&
        pstSess[iIdx].cStatus != DCS_S_ERROR &&
        iIdx < MAX_SESS) iIdx++;

  if(iIdx == MAX_SESS){
    sprintf (g_caMsg, "<DCS> No available session for socket acception");
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = DCS_ES_SESOVERFLW;
    UCP_TRACE_END(DCS_E_LOCALDCS);
  }
  /* initial sess */
  memset(&pstSess[iIdx], 0x0, sizeof(struct SocketSess) );

  iServLen = sizeof(stServ);
  if(FORKED){
    /* mark no use now 
    iRc = getpeername(0,(struct sockaddr *)&stServ,&iServLen);
    if(iRc < 0){
      sprintf (g_caMsg,
               "<DCS> Failure to get peername! (errno:%d==>%s)",
               errno, sys_errlist[errno]);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = errno;
      UCP_TRACE_END(iRc);
    }
    */
  }
  else{
    iAcepSkId = accept(gs_iResiSkId,(struct sockaddr *)&stServ,&iServLen);
    if (iAcepSkId < 0){
      sprintf (g_caMsg,
      "<DCS> Failure to accept with socket id [%d]! (errno:[%d]==>%s)",
      gs_iResiSkId, errno, sys_errlist[errno]);
      ErrLog (1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = errno;
      UCP_TRACE_END(iAcepSkId);
    }
  }
     
  /* save the session information */
  pstSess[iIdx].cStatus = DCS_S_USED ;
  pstSess[iIdx].cLastAct = DCSACCEPT;
  pstSess[iIdx].iSocketId = iAcepSkId;
  pstSess[iIdx].cMode = PASSIVE_MODE;

  /* fill DCS buff */
  PiSesIdx(pstDcsBuf) = iIdx;
  PiErrno(pstDcsBuf) = 0;
  PcProto(pstDcsBuf) = SOCKET_DCS;

  sprintf (g_caMsg,
           "<DCS> Accept socket ok with session [%d] & socket id [%d]",
           iIdx, gs_iResiSkId);
  ErrLog (10, g_caMsg, RPT_TO_LOG, 0, 0);
  UCP_TRACE_END(DCS_NORMAL);
}

/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   reguest a service to a server in host
*&D&
*/

int
DcsSkSend(struct DcsBuf *pstDcsBuf,struct SocketSess *pstSess)
{
  int iIdx;
  int iWdSkId,iRdSkId;
  int iRc;
  int iMsgLen;
  char caDummy[20];
 
  UCP_TRACE(P_DcsSkSend);

  /* Is the dialogue usable */
  iIdx = PiSesIdx(pstDcsBuf);
  if(iIdx > 0){
    if(pstSess[iIdx].cStatus != DCS_S_USED || iIdx >= MAX_SESS){
      sprintf (g_caMsg, "<DCS> No available session for socket send");
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      PiErrno(pstDcsBuf) = DCS_ES_SESUNUSE;
      UCP_TRACE_END(DCS_E_COMMAND);
    }
    iWdSkId = pstSess[iIdx].iSocketId;
    iRdSkId = pstSess[iIdx].iSocketId;
  }
  else{
    iWdSkId = 1;
    iRdSkId = 0;
  }
  /*
  sprintf(g_caMsg,"<DCS> iIdx=%d iWdSkId=%d iRdSkId=%d.",
          iIdx,iWdSkId,iRdSkId);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
  */

#ifdef SYNC_PROTOCOL
  if(pstSess[iIdx].cLastAct == DCSWRITE){
    iMsgLen = 5;
    iRc = read(iRdSkId,caDummy,iMsgLen);  /* Passive mode & Forked read */
    if(iRc == -1){
      sprintf (g_caMsg,
               "<DCS> Failure to dummy read socket! (errno:%d==>%s)",
               errno, sys_errlist[errno]);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      pstSess[iIdx].cStatus = DCS_S_ERROR;
      PiErrno(pstDcsBuf) = errno;
      UCP_TRACE_END(iRc);
    }
    pstSess[iIdx].cLastAct = DCSREAD;
  }
#endif

  /* send a service reguest */
  iMsgLen = PiDataLen(pstDcsBuf);

  iRc = write(iWdSkId,PunData(pstDcsBuf),iMsgLen); /* Passive mode write */
  if(iRc == -1){
    sprintf (g_caMsg, 
    "<DCS> Failure to write socket with id[%d] & len[%d]! (errno:%d==>%s)",
    iWdSkId, iMsgLen, errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);

    pstSess[iIdx].cStatus = DCS_S_ERROR;
    PiErrno(pstDcsBuf) = errno;
    UCP_TRACE_END (iRc);
  }
  
  sprintf (g_caMsg,
           "<DCS> Write socket with socket id[%d] & message len[%d]", 
           iWdSkId, iMsgLen);
  ErrLog (10, g_caMsg, RPT_TO_LOG, PunData(pstDcsBuf), iMsgLen);

  /* update session */
  pstSess[iIdx].cLastAct = DCSWRITE;
  PiErrno(pstDcsBuf) = 0;

  if(iIdx == 0 && (pstSess[iIdx].cStatus == DCS_S_FREE ||
                  pstSess[iIdx].cStatus == DCS_S_USABLE)){
    pstSess[iIdx].cStatus = DCS_S_USED ;
    pstSess[iIdx].cMode = PASSIVE_MODE;
    PcProto(pstDcsBuf) = SOCKET_DCS;
  }

  UCP_TRACE_END(DCS_NORMAL);
}

/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   receive a response from a server after a regueast
*&D&
*/

int
DcsSkReceive(struct DcsBuf *pstDcsBuf,struct SocketSess *pstSess)
{
  int iIdx;
  int iWdSkId,iRdSkId;
  int iRc;
  int iMsgLen;
  char caDummy[10];
  char caSkLen[20];       /* added by YEN 1994/12/25 */
  int  iRecLen, iTotLen;  /* added by YEN 1994/12/25 */
  void DcsSkNull();
  int  iErrNo=0;
 
  UCP_TRACE(P_DcsSkReceive);

  /* Is the dialogue usable */
  iIdx = PiSesIdx(pstDcsBuf);
  if(iIdx > 0){
    if(pstSess[iIdx].cStatus != DCS_S_USED || iIdx >= MAX_SESS){
      sprintf (g_caMsg, 
               "<DCS> No available session for socket receive");
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      PiErrno(pstDcsBuf) = DCS_ES_SESUNUSE;
      UCP_TRACE_END(DCS_E_COMMAND);
    }
    iWdSkId = pstSess[iIdx].iSocketId;
    iRdSkId = pstSess[iIdx].iSocketId;
  }
  else{
    iWdSkId = 1;
    iRdSkId = 0;
  }
  /*
  sprintf (g_caMsg,
           "<DCS> iIdx=%d iWdSkId=%d iRdSkId=%d timeout=%ld",
           iIdx,iWdSkId,iRdSkId,PlWaiTime(pstDcsBuf));
  ErrLog (10, g_caMsg, RPT_TO_LOG, 0, 0);
  */

#ifdef SYNC_PROTOCOL
  iMsgLen = 5;
  if(pstSess[iIdx].cLastAct == DCSREAD){
    sprintf(caDummy,"dummy");
    iRc = write(iWdSkId,caDummy,iMsgLen);   /* Passive mode write */
    if(iRc == -1){
      sprintf (g_caMsg,
      "<DCS> Failure to write socket with id[%d] & len[%d]! (errno:%d==>%s)",
      iWdSkId, iMsgLen, errno, sys_errlist[errno]);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);

      pstSess[iIdx].cStatus = DCS_S_ERROR;
      PiErrno(pstDcsBuf) = errno;
      UCP_TRACE_END(iRc);
    }
    pstSess[iIdx].cLastAct = DCSWRITE;
  }
#endif

/* added by YEN 1994/12/25 begin */
  iRecLen=0;
  iTotLen=0;
  while(1) {
    /* set wait time */
    signal(SIGALRM,DcsSkNull)  ;
    alarm(PlWaiTime(pstDcsBuf)) ;
    /* iMsgLen=PiDataLen(pstDcsBuf); */

    if( iRecLen == 0 ) {
      iMsgLen=8;
    }
    else {
      iMsgLen=iTotLen-iRecLen;
    }

    /*Passive mode read*/
    iRc = recv(iRdSkId, PunData(pstDcsBuf)+iRecLen, iMsgLen, 0);

    iErrNo=errno;
    if(iRc <= 0){ 
     PiErrno(pstDcsBuf) = iErrNo;
     sprintf(g_caMsg,
     "<DCS> Failure to receive socket with id[%d] & len[%d]! (errno:%d==>%s)",
     iRdSkId, iMsgLen, errno, sys_errlist[errno]);
     ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);

     pstSess[iIdx].cStatus = DCS_S_ERROR;
     alarm(0) ;
     if(PiErrno(pstDcsBuf) == EINTR) UCP_TRACE_END(DCS_E_TIMEOUT);
     if ( iRc == 0 ) iRc=-1; /* when iRc=0, convert to -1 */
     UCP_TRACE_END(iRc);
    }
    alarm(0) ;

    if ( iRecLen == 0 ) {  /* read the 1st packet of the message */
      memcpy (caSkLen, PunData(pstDcsBuf)+3, 5);
      caSkLen[5]='\0';
      iTotLen=atoi(caSkLen);
    }
    iRecLen=iRecLen+iRc;

    /*
    sprintf (g_caMsg,"<DCS> iRecLen=%d iRc=%d iTotLen=%d",iRecLen,iRc,iTotLen);
    ErrLog (10, g_caMsg, RPT_TO_LOG, 0, 0);
    */

    if ( iRecLen == iTotLen ) { /* have no other package to be received */
       break;
    }
    else {
       if (iRecLen > iTotLen) { /*data length exceeds the len. in the header*/
         sprintf (g_caMsg,
         "<DCS> Failure to receive complete message! (RecLen:%d Totlen:%d)",
         iRecLen,iTotLen);
         ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);

         pstSess[iIdx].cStatus = DCS_S_ERROR;
         PiErrno(pstDcsBuf) = iErrNo;
         UCP_TRACE_END(-1);
       }
    }
  }  /* for while(1) */

  iMsgLen = iRecLen;
  sprintf (g_caMsg,
           "<DCS> Receive socket ok with id[%d] & len[%d]", 
           iRdSkId, iMsgLen);
  ErrLog (10, g_caMsg, RPT_TO_LOG, PunData(pstDcsBuf), iMsgLen);

  /* save the session information */
  pstSess[iIdx].cLastAct = DCSREAD;
  PiDataLen(pstDcsBuf) = iMsgLen;
  PiErrno(pstDcsBuf) = 0;

  if(iIdx == 0 && (pstSess[iIdx].cStatus == DCS_S_FREE ||
                  pstSess[iIdx].cStatus == DCS_S_USABLE)){
    pstSess[iIdx].cStatus = DCS_S_USED ;
    pstSess[iIdx].cMode = PASSIVE_MODE;
    PcProto(pstDcsBuf) = SOCKET_DCS;
  }

  UCP_TRACE_END(DCS_NORMAL);
}

/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   sign off to socket network agent
*&D&
*/

int
DcsSkDisconnect(struct DcsBuf *pstDcsBuf,struct SocketSess *pstSess)
{
  int iRc;
  int iIdx;
  int iSkId;
 
  UCP_TRACE(P_DcsSkDisconnect);

  /* Is the dialogue usable */
  iIdx = PiSesIdx(pstDcsBuf);
  if(iIdx > 0){
    if(pstSess[iIdx].cStatus == DCS_S_FREE || iIdx >= MAX_SESS){
      sprintf (g_caMsg, "<DCS> No available session!");
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      PiErrno(pstDcsBuf) = DCS_ES_SESUNUSE;
      UCP_TRACE_END (DCS_E_COMMAND);
    }
    iSkId = pstSess[iIdx].iSocketId;
  }
  else{
    iSkId = 1;
  }

  /* dissolve a dialogue */
  iRc = close(iSkId); /* Active mode close */
  if(iRc != 0){
    sprintf (g_caMsg,
             "<DCS> Failure to close socket! (errno:%d==>%s)",
             errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    pstSess[iIdx].cStatus = DCS_S_ERROR;
    PiErrno(pstDcsBuf) = errno;
    UCP_TRACE_END (iRc);
  }
  
  /* save the session information */
  pstSess[iIdx].cStatus = DCS_S_FREE;
  pstSess[iIdx].cLastAct = DCSDISCONNECT;
  pstSess[iIdx].iSocketId = -1;

  /* fill DCS buff */
  PiSesIdx(pstDcsBuf) = -1;
  PiErrno(pstDcsBuf) = 0;
  PcProto(pstDcsBuf) = ' ';

  UCP_TRACE_END(DCS_NORMAL);
}

/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   sign off to socket network agent
*&D&
*/

int
DcsSkTerminate(struct DcsBuf *pstDcsBuf)
{
  UCP_TRACE(P_DcsSkTerminate);
  /*
  ErrLog(10, "<DCS> Terminate socket", RPT_TO_LOG, 0, 0);
  */
  UCP_TRACE_END(DCS_NORMAL);
}


/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   This function is null
*&D&
*/

int
GetHostServName(char *pcDesCode,char *pcHostName,char *pcServName)
{
  int iRc;
  struct SkNetwk stNetwk;

  UCP_TRACE(P_GetHostServName);

  iRc = 0;
  /* get protocol & server name by des_code */
  iRc = SrhSkNetwkTbl(pcDesCode,&stNetwk);
  if(iRc != 0){
    sprintf (g_caMsg,
             "<DCS> Failure to find destination [%s] in socket table! (iRc:%d)",
             pcDesCode, iRc);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END(iRc);
  }

  strcpy(pcHostName,stNetwk.caField[0]);
  strcpy(pcServName,stNetwk.caField[1]);
  /*
  sprintf (g_caMsg,
           "<DCS> Find host[%s] & server[%s] in socket table",
           pcHostName, pcServName);
  ErrLog (10, g_caMsg, RPT_TO_LOG, 0, 0);
  */
  UCP_TRACE_END(0);
}

/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   search net work table to find out protocol & server name
*&D&
*/

int
SrhSkNetwkTbl(char *pcDesCode,struct SkNetwk *pstNetwk)
{
  int iIdx,iRc;
  struct SkNetwk *pstNetTbl;
 
  UCP_TRACE(P_SrhSkNetwkTbl);

  pstNetTbl = g_stSkNetTbl;
  iIdx = 1;
  /* find out in the net work table array */
#ifdef OMIT_BY_WILDCARD
  while((iRc = memcmp(pcDesCode,pstNetTbl[iIdx].caDesCode,10) != 0) &&
        (iIdx < gs_iMaxLoad)){
#endif
  while((iRc = CompWildDest(pcDesCode,pstNetTbl[iIdx].caDesCode,10)) != 0 &&
        (iIdx < gs_iMaxLoad)){
    iIdx++;
  }
  
  /* memory copy from net work table to working area of networktable struct */
  if(iIdx == gs_iMaxLoad){
    /* not found in table array, then set default protocol & server name */
    iIdx = 0;
    memcpy(pstNetwk,&pstNetTbl[0],sizeof(struct SkNetwk));
  }
  else{
    /* found */
    memcpy(pstNetwk,&pstNetTbl[iIdx],sizeof(struct SkNetwk));
  }

  UCP_TRACE_END(0);
}

/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   load network table
*&D&
*/

int
LoadSkNetwkTbl(struct SkNetwk *pstNetTbl)
{
  int i,j,k;
  FILE *pfNetFd;
  char caFileName[80];

  UCP_TRACE(P_LoadSkNetwkTbl);

  sprintf (caFileName, "%s%s%s", 
           (char *) getenv("III_DIR"),
           DCS_TABLE_PATH,
           SOCKET_TABLE);

  if ((pfNetFd = fopen(caFileName,"r")) == (FILE *) 0){
    sprintf (g_caMsg,
             "<DCS> Failure to open file [%s]! (errno:%d==>%s)",
             caFileName, errno, sys_errlist[errno]);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END (DCS_ES_OPENTBLFILE);
  }

  i = 0;
  while(fscanf(pfNetFd,"%s %s %s", pstNetTbl[i].caDesCode,
                                   pstNetTbl[i].caField[0],
                                   pstNetTbl[i].caField[1]) != EOF){
    i++;
    if(i >= MAX_NETWKTBL_ARRAY){
      sprintf (g_caMsg, 
               "<DCS> Socket table size [%d] exceeds the limit [%d]",
               i, MAX_NETWKTBL_ARRAY);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      fclose (pfNetFd);
      UCP_TRACE_END (DCS_ES_TBLARRAYOVERFLW);
    }
  }

  gs_iMaxLoad = i;
  fclose(pfNetFd);
  UCP_TRACE_END(0);
}

void
DcsSkNull()
{
  ErrLog (10,"<DCS> Socket receive timeout error", RPT_TO_LOG, 0, 0);
}
/*===========================================================================*/
