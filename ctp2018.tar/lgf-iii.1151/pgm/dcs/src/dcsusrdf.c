#ifdef DESKEY

#include "errlog.h"
/* -------------- Cut this segment when other use site ------------------*/
int 
GetDesKey(pcaBrhId,pcaBuf)
char  *pcaBrhId;
char  *pcaBuf;
{
  int  iRc;
  int  iOffset;
  unsigned char caRc[2];
  unsigned char caKeyBuf1[8];
  unsigned char caKeyBuf2[8];

  signal(SIGCLD, SIG_IGN);
  DESINIT(caRc);

  if ( strncmp(caRc,"00",2) != 0 ) {
    iRc = atoi(caRc);
    sprintf (g_caMsg,
             "<DCS> Failure to execute DESINIT function! (iRc:%d cRc:%.2s)", 
             iRc, caRc);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    return (iRc);
  }

  iOffset = 0;

  DESGETKY(caRc,caKeyBuf1,caKeyBuf2,"CDK",pcaBrhId);

  if ( strncmp(caRc,"00",2) != 0 ) {
    iRc = atoi(caRc);
    sprintf (g_caMsg,
      "<DCS> Failure to execute DESGETKY (CDK) function! (iRc:%d cRc:%.2s)", 
      iRc, caRc);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DESCLOSE(caRc);
    if ( strncmp(caRc, "00", 2) != 0 ) 
    {
      sprintf (g_caMsg,
        "<DCS> Failure to execute DESCLOSE (CDK) function! (iRc:%d cRc:%.2s)", 
        iRc, caRc);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    }
    return(iRc);
  }
  memcpy(pcaBuf,caKeyBuf1,8);
  iOffset += 8;
  
  DESGETKY(caRc,caKeyBuf1,caKeyBuf2,"MAC",pcaBrhId);

  if ( strncmp(caRc,"00",2) != 0 ) 
  {
    iRc = atoi(caRc);
    sprintf (g_caMsg,
      "<DCS> Failure to execute DESGETKY (MAC) function! (iRc:%d cRc:%.2s)", 
      iRc, caRc);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DESCLOSE(caRc);
    if ( strncmp(caRc, "00", 2) != 0 ) 
    {
      sprintf (g_caMsg,
        "<DCS> Failure to execute DESCLOSE (MAC) function! (iRc:%d cRc:%.2s)", 
        iRc, caRc);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    }
    return(iRc);
  }
  memcpy(pcaBuf+iOffset,caKeyBuf2,8);
  iOffset += 8;
  
  DESGETKY(caRc,caKeyBuf1,caKeyBuf2,"PPK",pcaBrhId);

  if ( strncmp(caRc,"00",2) != 0 ) 
  {
    iRc = atoi(caRc);
    sprintf (g_caMsg,
      "<DCS> Failure to execute DESGETKY (PPK) function! (iRc:%d cRc:%.2s)", 
      iRc, caRc);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DESCLOSE(caRc);
    if ( strncmp(caRc, "00", 2) != 0 ) 
    {
      sprintf (g_caMsg,
        "<DCS> Failure to execute DESCLOSE (PPK) function! (iRc:%d cRc:%.2s)", 
        iRc, caRc);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    }
    return(iRc);
  }
  memcpy(pcaBuf+iOffset,caKeyBuf2,8);
  
  DESCLOSE(caRc);

  if ( strncmp(caRc,"00",2) != 0 ) {
    iRc = atoi(caRc);
    return(iRc);
  }
 
  return(0);
}

#endif
