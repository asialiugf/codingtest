

/*     FUNCTION & SUBROUTINE DESCRIPTION
*&N&   
*&N&    TYPE      NAME                 DESCRIPTION
*&N& --------- ---------- ---------------------------------------- 
*&N& 
*&N&
*&N&
*&N&
*&N&
*&N&
*&N&
*&N&
*&N&
*/

/* -------------------- INCLUDE FILES DECLARATION ------------------- */
#include <fcntl.h>
#include <errno.h>
#include <sys/ipc.h>
#include <sys/signal.h>
#include "errlog.h"
#include "dccmsgq.h"
#include "dcs.h"

#define MAX_DCS_MSGQ_LEN    DCS_MAX_DATA_LEN 
#define MAX_NETWKTBL_ARRAY  100
#define QUEUE_TABLE         "queuetbl"

struct DcsMsg {
  struct MsgqHead stQuHead;
  char caMsg[MAX_DCS_MSGQ_LEN];	/* max message length in INPUT-Q */
};   

struct QuNetwk {
  char ucDesCode[10];
  char caField[2][20];
};

struct	QueSess{
  char caDesAddr[10];
  char caSrcAddr[10];
  int iQuId;
  long lWdType;
  long lRdType; 
  char ucStatus;
  char cMode;
};

/* ------------- dcsqueue.c function ���N�� ------------------------- */
/* dcsqueue.c */
#define P_DcsQueue 			44101
#define P_DcsQuInitial 			44102
#define P_DcsQuAccept 			44103
#define P_DcsQuConnect 			44104
#define P_DcsQuDisconnect 		44105
#define P_DcsQuReceive 			44106
#define P_DcsQuReceivefrom 		44107
#define P_DcsQuSend 			44108
#define P_DcsQuSendTo 			44109
#define P_DcsQuTerminate 		44110
#define P_DcsQuBasRcvFrom 		44111
#define P_DcsQuBasSendTo 		44112
#define P_GetQuKeyQuType 		44113
#define P_SrhQuNetwkTbl 		44114
#define P_LoadQuNetwkTbl 		44115
#define P_DcsQuNull 			44116
#define P_DcsQuAbort  			44117

/* ------------------------------------------------------------------ */

/* -------------------- STATIC GLOBAL DECLARATION ------------------- */
static int gs_iFirst=1;       /* first flage 0=no 1=yes          */
static int gs_iMaxLoad;
struct QueSess g_stQuSesTbl[MAX_SESS];
struct QuNetwk g_stNetwkTbl[MAX_NETWKTBL_ARRAY];

/* ------ CALL FUNCTION & SUBROUTINE PROTOTYPE DECLARATIONS --------- */
int DcsQueue(struct DcsBuf *pstDcsBuf);
int DcsQuInitial(struct DcsBuf *pstDcsBuf,struct QueSess *pstSess);
int DcsQuConnect(struct DcsBuf *pstDcsBuf,struct QueSess *pstSess);
int DcsQuAccept(struct DcsBuf *pstDcsBuf,struct QueSess *pstSess);
int DcsQuSend(struct DcsBuf *pstDcsBuf,struct QueSess *pstSess);
int DcsQuReceive(struct DcsBuf *pstDcsBuf,struct QueSess *pstSess);
int DcsQuDisconnect(struct DcsBuf *pstDcsBuf,struct QueSess *pstSess);
int DcsQuTerminate(struct DcsBuf *pstDcsBuf);
int DcsQuBasSendTo(int iQuId,long lQuType,struct DcsBuf *pstDcsBuf);
int DcsQuBasRcvFrom(int iQuId,long lQuType,struct DcsBuf *pstDcsBuf,
                    long *plExpQuType);
int LoadQuNetwkTbl(struct QuNetwk *pstNetwkTbl);
int SrhQuNetwkTbl(char *ucDesCode,struct QuNetwk *pstQuNet);
int GetQuKeyQuType(char *ucDesCode,int *iQuKey,long *lQuType);
void DcsQuNull();

extern int  errno;
extern char *sys_errlist[];
  
/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   main program of interface between DCS and AP
*&D&
*/

int
DcsQueue(struct DcsBuf *pstDcsBuf)
{
  int iRc;
  struct QueSess *pstSess;

  UCP_TRACE(P_DcsQueue);

  iRc = 0;
  pstSess = g_stQuSesTbl;

  switch (PcRqstCode(pstDcsBuf)){
   case DCSINITIAL:
     iRc = DcsQuInitial(pstDcsBuf,pstSess);
     break;
   case DCSCONNECT:
   case DCSCONNECTWRITE:
     /* do DcsQuInitial when gs_iFirst */
     if(gs_iFirst){
       iRc = DcsQuInitial(pstDcsBuf,pstSess);
       if(iRc != DCS_NORMAL){
         break;
       }
       gs_iFirst = 0;
     }
     iRc = DcsQuConnect(pstDcsBuf,pstSess);
     break;
   case DCSACCEPT:
   case DCSACCEPTREAD:
     /* do DcsQuInitial when gs_iFirst */
     if(gs_iFirst){
       iRc = DcsQuInitial(pstDcsBuf,pstSess);
       if(iRc != DCS_NORMAL){
         break;
       }
       gs_iFirst = 0;
     }
     iRc = DcsQuAccept(pstDcsBuf,pstSess);
     break;
   case DCSWRITE:
     iRc = DcsQuSend(pstDcsBuf,pstSess);
     break;
   case DCSWRITETO:
     iRc = DcsQuSendTo(pstDcsBuf,pstSess);
     break;
   case DCSWRDISCONECT:
     iRc = DcsQuSend(pstDcsBuf,pstSess);
     if(iRc == DCS_NORMAL){
       iRc = DcsQuDisconnect(pstDcsBuf,pstSess);
     }
     break;
   case DCSREAD:
     iRc = DcsQuReceive(pstDcsBuf,pstSess);
     break;
   case DCSREADFROM:
     iRc = DcsQuReceivefrom(pstDcsBuf,pstSess);
     break;
   case DCSDISCONNECT:
     iRc = DcsQuDisconnect(pstDcsBuf,pstSess);
     break;
   case DCSTERMINATE:
     iRc = DcsQuTerminate(pstDcsBuf);
     break;
   case DCSABORT:
     iRc = DcsQuAbort(pstDcsBuf,pstSess);
     break;
   default:
     sprintf(g_caMsg,"<DCS> Illegal reguest [%c]", PcRqstCode(pstDcsBuf));
     ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
     iRc = DCS_E_COMMAND;
     break;
  } /* end switch */

  PiReply(pstDcsBuf) = iRc;
  UCP_TRACE_END(iRc);
} /* end of sbdbs */

  
/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   sign on to queue network agent
*&D&
*/

int
DcsQuInitial(struct DcsBuf *pstDcsBuf,struct QueSess *pstSess)
{
  int iRc;
  int iIdx;
  struct QuNetwk *stQuNetTbl;

  UCP_TRACE(P_DcsQuInitial);

  /* load queue network table */
  stQuNetTbl = g_stNetwkTbl;
  iRc = LoadQuNetwkTbl(stQuNetTbl);
  if(iRc != 0){
    sprintf (g_caMsg, "<DCS> Failure to load queue table");
    ErrLog (1000,g_caMsg,RPT_TO_LOG,0,0);
    PiErrno(pstDcsBuf) = iRc;
    UCP_TRACE_END(DCS_E_NETWORKTBL);
  }

  /* initial session table */
  for(iIdx=0; iIdx<MAX_SESS; iIdx++){
    memset(&pstSess[iIdx], 0x0, sizeof(struct QueSess) );
    pstSess[iIdx].ucStatus = DCS_S_FREE ;
    pstSess[iIdx].iQuId = -1;
  }
  
  UCP_TRACE_END(DCS_NORMAL);
}

  
/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   establish a dialogue to queue node manager
*&D&
*/

int
DcsQuConnect(struct DcsBuf *pstDcsBuf,struct QueSess *pstSess)
{
  int iIdx;
  int iRc;
  int iRc1;
  int iQkey;
  int iQuId;
  long lWdType,lRdType;

  UCP_TRACE(P_DcsQuConnect);

  /* search a usable dialogue  */
  iIdx = 1;
  while(pstSess[iIdx].ucStatus != DCS_S_FREE &&
        pstSess[iIdx].ucStatus != DCS_S_ERROR &&
        pstSess[iIdx].ucStatus != DCS_S_USABLE &&
        iIdx < MAX_SESS) iIdx++;

  if(iIdx == MAX_SESS){
    PiErrno(pstDcsBuf) = DCS_ES_SESOVERFLW;
    UCP_TRACE_END(DCS_E_LOCALDCS);
  } 

  /* clear session buff */
  memset(&pstSess[iIdx], 0x0, sizeof(struct QueSess));

  /* get write queue key & queue type from pstDcsBuf */
  iRc = GetQuKeyQuType(PcaDesCode(pstDcsBuf),&iQkey,&lWdType);
  if(iRc != 0){
    sprintf (g_caMsg, 
             "<DCS> Failure to get queue key & type from queue table");
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = errno;
    UCP_TRACE_END(DCS_E_NETWORKTBL);
  }

  /* get write queue ID  */
  iRc = MsgqGet(&iQuId,iQkey);
  if(iRc != MSGQ_NORMAL){
    sprintf (g_caMsg, "<DCS> Failure to get queue id with key [0x%0x]", iQkey);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = iRc;
    UCP_TRACE_END(DCS_E_NETWORKTBL);
  } 

  /* get next read lQuType */
  lRdType = getpid();

  /* added By WuChihLiang 19951005 for clear lRdType message */
  MsgqInit(iQuId, lRdType);

  /* send next read lQuType to destination */
  iRc = DcsQuBasSendTo(iQuId,lWdType,pstDcsBuf);
  if(iRc != 0){
    sprintf (g_caMsg, 
    "<DCS> Failure to send queue message with id[%d] & write type[%ld]!",
    iQuId, lWdType);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = iRc;
    UCP_TRACE_END(DCS_E_NETWORK);
  }

  /* receive next write lQuType from */
  /* added By WuChihLiang 19951005 for setting TIMEOUT */
  PlWaiTime(pstDcsBuf) = 30;

  iRc = DcsQuBasRcvFrom(iQuId,lRdType,pstDcsBuf,&lWdType);
  if(iRc != 0){
    sprintf (g_caMsg,
    "<DCS> Failure to receive queue message with queue id[%d] & read type[%d]",
    iQuId, lRdType);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = iRc;

    iRc1 = ConnectMsgqInit(iQuId, lWdType, lRdType);
    if (iRc1 == -99){ /* TIMEOUT occur but server receive connect data, so
                         receive connect ACK again */
      iRc = DcsQuBasRcvFrom(iQuId,lRdType,pstDcsBuf,&lWdType);

      if(iRc != 0){
        UCP_TRACE_END(iRc);
      }
    }else{
      UCP_TRACE_END(iRc);
    }
    /* Modified 2 line -- END */
  }

  /* save the session information */
  pstSess[iIdx].ucStatus = DCS_S_USED;
  pstSess[iIdx].iQuId = iQuId;
  pstSess[iIdx].lWdType = lWdType;
  pstSess[iIdx].lRdType = lRdType;
  pstSess[iIdx].cMode = ACTIVE_MODE;

  /* fill DCS buff */
  PiSesIdx(pstDcsBuf) = iIdx;
  PcProto(pstDcsBuf) = QUEUE_DCS;
  PiErrno(pstDcsBuf) = 0;

  UCP_TRACE_END(DCS_NORMAL);
}

  
/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   establish a dialogue to queue node manager
*&D&
*/

int
DcsQuAccept(struct DcsBuf *pstDcsBuf,struct QueSess *pstSess)
{
  int iIdx;
  int iRc;
  int iQkey,iQuId;
  long lWdType,lRdType;

  UCP_TRACE(P_DcsQuAccept);

  /* search a usable dialogue  */
  iIdx = 1;
  while(pstSess[iIdx].ucStatus != DCS_S_FREE &&
        pstSess[iIdx].ucStatus != DCS_S_ERROR &&
        pstSess[iIdx].ucStatus != DCS_S_USABLE &&
        iIdx < MAX_SESS) iIdx++;

  if(iIdx == MAX_SESS){
    PiErrno(pstDcsBuf) = DCS_ES_SESOVERFLW;
    UCP_TRACE_END(DCS_E_LOCALDCS);
  } 
  /* clear session buff */
  memset(&pstSess[iIdx], 0x0, sizeof(struct QueSess));

  /* get write & read queue key & type from pstDcsBuf */
  iRc = GetQuKeyQuType(PcaDesCode(pstDcsBuf),&iQkey,&lRdType);
  if (iRc != 0)
  {
    sprintf (g_caMsg, 
             "<DCS> Failure to get queue key & type from queue table");
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = iRc;
    UCP_TRACE_END(DCS_E_NETWORKTBL);
  }

  /* get read queue ID  */
  iRc = MsgqGet(&iQuId,iQkey);
  if(iRc != MSGQ_NORMAL){
    sprintf (g_caMsg, "<DCS> Failure to get queue id with key [0x%0x]", iQkey);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = iRc;
    UCP_TRACE_END(DCS_E_NETWORKTBL);
  } 

  /* receive next Write lQuType from */
  iRc = DcsQuBasRcvFrom(iQuId,lRdType,pstDcsBuf,&lWdType);
  if(iRc != 0){
    sprintf (g_caMsg,
    "<DCS> Failure to receive queue message with queue id [%d] & type [%d]",
    iQuId, lRdType);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = iRc;
    UCP_TRACE_END(DCS_E_NETWORK);
  }

  /* next time receive q type */
  lRdType = getpid();

  /* clear the read queue type */
  iRc = MsgqInit(iQuId,lRdType);
  if((iRc != MSGQ_NORMAL) && (iRc != MSGQ_EOF_ERROR)){
    sprintf (g_caMsg, 
    "<DCS> Failure to initialize message queue with id [%d] & read type [%ld]",
    iQuId, lRdType);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = iRc;
    UCP_TRACE_END(DCS_E_NETWORK);
  } 

  /* send next read lQuType to destination */
  iRc = DcsQuBasSendTo(iQuId,lWdType,pstDcsBuf);
  if(iRc != 0){
    sprintf (g_caMsg, 
    "<DCS> Failure to send queue message with queue id [%d] & type [%ld]!",
    iQuId, lWdType);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = iRc;
    UCP_TRACE_END(DCS_E_NETWORK);
  }

  /* save the session information */
  pstSess[iIdx].ucStatus = DCS_S_USED;
  pstSess[iIdx].iQuId = iQuId;
  pstSess[iIdx].lWdType = lWdType;
  pstSess[iIdx].lRdType = lRdType;
  pstSess[iIdx].cMode = PASSIVE_MODE;

  /* fill DCS buff */
  PiSesIdx(pstDcsBuf) = iIdx;
  PcProto(pstDcsBuf) = QUEUE_DCS;
  PiErrno(pstDcsBuf) = 0;

  UCP_TRACE_END(DCS_NORMAL);
}

  
/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&  reguest a service to a server in host
*&D&
*/

int
DcsQuSend(struct DcsBuf *pstDcsBuf,struct QueSess *pstSess)
{
  int iRc;
  int iIdx;

  UCP_TRACE(P_DcsQuSend);

  /* Is the dialogue usable */
  iIdx = PiSesIdx(pstDcsBuf);
  if(pstSess[iIdx].ucStatus != DCS_S_USED || iIdx >= MAX_SESS){
    sprintf (g_caMsg,
             "<DCS> Unusable session [%d] to send queue message", iIdx);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = DCS_ES_SESUNUSE;
    UCP_TRACE_END(DCS_E_COMMAND);
  }

  iRc = DcsQuBasSendTo(pstSess[iIdx].iQuId,pstSess[iIdx].lWdType,pstDcsBuf);
  if (iRc != 0){
    sprintf (g_caMsg, 
    "<DCS> Failure to send queue message with queue id [%d] & type [%ld]!",
    pstSess[iIdx].iQuId, pstSess[iIdx].lWdType);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = iRc;
    UCP_TRACE_END(DCS_E_NETWORK);
  }

  PiErrno(pstDcsBuf) = 0;

  UCP_TRACE_END(DCS_NORMAL);
}

  
/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   recieve a response from a server after a regueast
*&D&
*/

int
DcsQuReceive(struct DcsBuf *pstDcsBuf,struct QueSess *pstSess)
{
  int iRc;
  int iIdx;
  long lWdType;

  UCP_TRACE(P_DcsQuReceive);

  /* Is the dialogue usable */
  iIdx = PiSesIdx(pstDcsBuf);
  if(pstSess[iIdx].ucStatus != DCS_S_USED || iIdx >= MAX_SESS){
    sprintf (g_caMsg,
             "<DCS> Unusable session [%d] to receive queue message",
             iIdx);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = DCS_ES_SESUNUSE;
    UCP_TRACE_END(DCS_E_COMMAND);
  }

  iRc = DcsQuBasRcvFrom(pstSess[iIdx].iQuId,pstSess[iIdx].lRdType,
                        pstDcsBuf,&lWdType);
  if (iRc != 0){
    sprintf (g_caMsg, 
    "<DCS> Failure to receive queue message with id[%d] & read type[%ld]!",
    pstSess[iIdx].iQuId, pstSess[iIdx].lRdType);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = iRc;
    UCP_TRACE_END(DCS_E_NETWORK);
  }

  if (lWdType != pstSess[iIdx].lWdType){
    sprintf (g_caMsg,"<DCS> protocol error Wqt=%d sessWqt=%d",
             lWdType, pstSess[iIdx].lWdType);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = DCS_ES_QTYPE;
    UCP_TRACE_END(DCS_E_NETWORK);
  }

  /* save the session information */
/* Mark ........... at 1994/09/18.......
  if(PcMoreByte(pstDcsBuf) == '0') pstSess[iIdx].ucStatus = DCS_S_USABLE;
  if(PiDataLen(pstDcsBuf) == 0) pstSess[iIdx].ucStatus = DCS_S_USABLE;
*/
  PiErrno(pstDcsBuf) = 0;
  UCP_TRACE_END(DCS_NORMAL);
}

  
/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   sign off to queue network agent
*&D&
*/

int
DcsQuDisconnect(struct DcsBuf *pstDcsBuf,struct QueSess *pstSess)
{
  int iRc;
  int iIdx;

  UCP_TRACE(P_DcsQuDisconnect);

  /* Is the dialogue usable */
  iIdx = PiSesIdx(pstDcsBuf);
  if(pstSess[iIdx].ucStatus == DCS_S_FREE || iIdx >= MAX_SESS){
    sprintf (g_caMsg, "<DCS> Unusable session [%d] to disconnect queue", iIdx);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = DCS_ES_SESUNUSE;
    UCP_TRACE_END(DCS_E_COMMAND);
  }

#ifdef CLWU
  if((PcRqstCode(pstDcsBuf) != DCSWRDISCONECT) && 
     (pstSess[iIdx].ucStatus == DCS_S_USED)){
    PiDataLen(pstDcsBuf) = 0;

    iRc = DcsQuBasSendTo(pstSess[iIdx].iQuId,pstSess[iIdx].lWdType,pstDcsBuf);
    if(iRc != 0){
      sprintf (g_caMsg, 
      "<DCS> Failure to send queue message with id[%d] & write type[%ld]!",
      pstSess[iIdx].iQuId, pstSess[iIdx].lWdType);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);

      PiErrno(pstDcsBuf) = iRc;
      UCP_TRACE_END(DCS_E_NETWORK);
    }
  }

  /* clear the write queue */
  iRc = MsgqInit(pstSess[iIdx].iQuId,pstSess[iIdx].lWdType);
  if(iRc != MSGQ_NORMAL){
    sprintf (g_caMsg, 
    "<DCS> Failure to initialize message queue with id [%d] & write type [%ld]",
    pstSess[iIdx].iQuId, pstSess[iIdx].lWdType);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = iRc;
    UCP_TRACE_END(DCS_E_NETWORK);
  } 

  /* clear the read queue */
  iRc = MsgqInit(pstSess[iIdx].iQuId,pstSess[iIdx].lRdType);
  if(iRc != MSGQ_NORMAL) {
    sprintf (g_caMsg, 
    "<DCS> Failure to initialize message queue with id [%d] & read type [%ld]",
    pstSess[iIdx].iQuId, pstSess[iIdx].lRdType);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = iRc;
    UCP_TRACE_END(DCS_E_NETWORK);
  } 
#endif

  /* save the session information */
  memset(&pstSess[iIdx], 0x0, sizeof(struct QueSess) );
  pstSess[iIdx].ucStatus = DCS_S_FREE;
  pstSess[iIdx].iQuId = -1;

  /* fill DCS buff */
  PiSesIdx(pstDcsBuf) = -1;
  PiErrno(pstDcsBuf) = 0;
  PcProto(pstDcsBuf) = ' ';

  UCP_TRACE_END(DCS_NORMAL);
}

  
/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   sign off to queue network agent
*&D&
*/

int
DcsQuTerminate(struct DcsBuf *pstDcsBuf)
{
  UCP_TRACE(P_DcsQuTerminate);
  /*
  ErrLog (1000, "<DCS> Terminate queue", RPT_TO_LOG, 0, 0);
  */
  UCP_TRACE_END(DCS_NORMAL);
}

  
/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   reguest a service to a server in host
*&D&
*/

int 
DcsQuBasSendTo(int iQuId,long lQuType,struct DcsBuf *pstDcsBuf)
{
  int iRc;
  int iDataLen,iMsgLen;
  struct MsgBuf stMsgp;
  struct DcsMsg stDcsMsg;
  char caTmpFile[10];

  UCP_TRACE(P_DcsQuBasSendTo);

  /* set up input queue data structure */
  stDcsMsg.stQuHead.lExpType = getpid();

  if((PcRqstCode(pstDcsBuf) == DCSWRDISCONECT) ||
     (PcRqstCode(pstDcsBuf) == DCSDISCONNECT)){
    stDcsMsg.stQuHead.iKind=0;
  }
  else{
    stDcsMsg.stQuHead.iKind=1;
  }

  iDataLen = PiDataLen(pstDcsBuf);
  stDcsMsg.stQuHead.iLen=iDataLen;
  memcpy(stDcsMsg.caMsg,PunData(pstDcsBuf),iDataLen); 
  memset(stDcsMsg.stQuHead.caFileName,' ',MSGQ_TMP_FNAME_LEN);
  iMsgLen = iDataLen + sizeof(struct MsgqHead);

  stMsgp.lType=lQuType;
  memcpy(stMsgp.caText,&stDcsMsg,iMsgLen); 
  sprintf(caTmpFile,"tmpfile");

  /* write a service reguest to input queue */

  iRc = MsgqWrite(iQuId,iMsgLen,&stMsgp,IPC_NOWAIT,caTmpFile);
  if(iRc != MSGQ_NORMAL){
    sprintf (g_caMsg,
             "<DCS> Failure to write message queue with id [%d]", iQuId);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = iRc;
    UCP_TRACE_END(DCS_E_NETWORK);
  }

  sprintf (g_caMsg, 
           "<DCS> Write message queue with id[%d] type[%ld] len[%d]",
           iQuId, lQuType, iMsgLen);
  ErrLog (10, g_caMsg, RPT_TO_LOG, stMsgp.caText, iMsgLen);

  UCP_TRACE_END(DCS_NORMAL);
}

  
/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   basic recieve a response from a server after a regueast
*&D&
*/

int
DcsQuBasRcvFrom(int iQuId,long lQuType,struct DcsBuf *pstDcsBuf,
                long *plExpQuType)
{
  int iRc;
  int iMsgLen, iDataLen;
  struct MsgBuf stMsgp;
  struct DcsMsg stDcsMsg;

  UCP_TRACE(P_DcsQuBasRcvFrom);

  /* set wait time */
  signal(SIGALRM,DcsQuNull);
  alarm(PlWaiTime(pstDcsBuf));

  iMsgLen = PiDataLen(pstDcsBuf)+sizeof(struct MsgqHead);

  iRc = MsgqRead(iQuId,lQuType,&iMsgLen,&stMsgp,0);
  alarm(0) ;
  if(iRc != MSGQ_NORMAL){
    PiErrno(pstDcsBuf) = iRc;
    sprintf (g_caMsg,
    "<DCS> Failure to read message queue with id[%d] type[%ld] iMsgLen[%d]", 
    iQuId, lQuType, iMsgLen);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    if(PiErrno(pstDcsBuf) == MSGQ_TIMEOUT) UCP_TRACE_END(DCS_E_TIMEOUT);
    UCP_TRACE_END(DCS_E_NETWORK);
  }

  /* set up msg queue data */
  memcpy(&stDcsMsg,stMsgp.caText,iMsgLen); 

  /* if rcv shutdown then go to ABEND_RTN */
  if(stDcsMsg.stQuHead.iKind == -1){
    sprintf (g_caMsg,
    "<DCS> Receive shutdown kind with id[%d] type[%ld]. Abend!",
    iQuId, lQuType);
    ErrLog (99999, g_caMsg, RPT_TO_LOG, 0, 0);
  }

  /* set up input queue data structure */
  *plExpQuType = stDcsMsg.stQuHead.lExpType;
  iDataLen = stDcsMsg.stQuHead.iLen;
  memcpy(PunData(pstDcsBuf),stDcsMsg.caMsg,iDataLen); 
  PiDataLen(pstDcsBuf) = iDataLen;
  if(stDcsMsg.stQuHead.iKind == 0){
    PcMoreByte(pstDcsBuf) = '0';
  }

  sprintf (g_caMsg,
           "<DCS> Read message queue with id[%d] type[%ld] len[%d]", 
           iQuId, lQuType, iMsgLen);
  ErrLog (10, g_caMsg, RPT_TO_LOG, stMsgp.caText, iMsgLen);

  UCP_TRACE_END(DCS_NORMAL);
}

DcsQuSendTo(pstDcsBuf,pstSess)
struct DcsBuf *pstDcsBuf;
struct QueSess *pstSess;
{
}

DcsQuReceivefrom(pstDcsBuf,pstSess)
struct DcsBuf *pstDcsBuf;
struct QueSess *pstSess;
{
}
/*===========================================================================*/
  
/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   Dispatch to Dcs function
*&D&
*/

int
GetQuKeyQuType(char *ucDesCode,int *iQuKey,long *lQuType)
{
  int iRc;
  char caTmpBuf[20];
  struct QuNetwk stNetwk;

  UCP_TRACE(P_GetQuKeyQuType);

  iRc = 0;
  /* get protocol & server name by des_code */
  iRc = SrhQuNetwkTbl(ucDesCode,&stNetwk);
  if(iRc != 0){
    UCP_TRACE_END(iRc);
  }

  strcpy(caTmpBuf,stNetwk.caField[0]);
  *iQuKey = atoi(caTmpBuf);
  strcpy(caTmpBuf,stNetwk.caField[1]);
  *lQuType = atoi(caTmpBuf);

  UCP_TRACE_END(0);
}

  
/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   search net work table to find out protocol & server name
*&D&
*/

int
SrhQuNetwkTbl(char *ucDesCode,struct QuNetwk *pstQuNet)
{
  int iIdx,iRc;
  struct QuNetwk *pstQuNetTbl;

  UCP_TRACE(P_SrhQuNetwkTbl);

  pstQuNetTbl = g_stNetwkTbl;
  iIdx = 1;
  /* find out in the net work table array */
  while((iRc = memcmp(ucDesCode,pstQuNetTbl[iIdx].ucDesCode,10) != 0) &&
        (iIdx < gs_iMaxLoad)){
    iIdx++;
  }
  
  /* memory copy from net work table to working area of networktable struct */
  if(iIdx == gs_iMaxLoad){
    /* not found in table array, then set default protocol & server name */
    memcpy(pstQuNet,&pstQuNetTbl[1],sizeof(struct QuNetwk));
    /* TCC */
    sprintf (g_caMsg, 
             "<DCS> Failure to find destination [%s] in queue table",
             ucDesCode );
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    sprintf (g_caMsg, 
             "<DCS> Replaced with default destination [%s]",
             pstQuNet);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
  }
  else{
    /* found */
    memcpy(pstQuNet,&pstQuNetTbl[iIdx],sizeof(struct QuNetwk));
  }

  UCP_TRACE_END(0);
}

  
/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&   load network table
*&D&
*/

int
LoadQuNetwkTbl(struct QuNetwk *pstNetwkTbl)
{
  int i,j,k;
  FILE *pfNetFd;
  char caFileName[256];

  UCP_TRACE(P_LoadQuNetwkTbl);

  sprintf (caFileName, "%s%s%s", 
           (char *)getenv("III_DIR"), 
           DCS_TABLE_PATH,
           QUEUE_TABLE);

  pfNetFd = fopen(caFileName,"r");
  if(pfNetFd == (FILE *) 0){
    sprintf (g_caMsg,
             "<DCS> Failure to open queue table [%s]! (errno:%d==>%s)",
             caFileName, errno, sys_errlist[errno]);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(DCS_ES_OPENTBLFILE);
  }

  i = 0;
  while(fscanf(pfNetFd,"%s %s %s", pstNetwkTbl[i].ucDesCode,
        pstNetwkTbl[i].caField[0], pstNetwkTbl[i].caField[1]) != EOF){
    i++;
    if(i >= MAX_NETWKTBL_ARRAY){
      sprintf (g_caMsg,
               "<DCS> Queue table size [%d] exceeds the limit [%d]",
               i, MAX_NETWKTBL_ARRAY);
      ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
      fclose (pfNetFd);
      UCP_TRACE_END (DCS_ES_TBLARRAYOVERFLW);
    }
  }

  gs_iMaxLoad = i;
  fclose(pfNetFd);

  UCP_TRACE_END(0);
}

void
DcsQuNull()
{
  ErrLog(10,"<DCS> Error: Queue Time-out occurs!",RPT_TO_LOG,0,0);
}

/*
*&N& ROUTINE NAME:
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& 
*&A& 
*&R& RETURN VALUE(S):
*&R&
*&R&
*&D& DESCRIPTION:
*&D&  clear prescribe session message in queue where queue_type is lRdType and 
*&D& lWrType.
*/

int
DcsQuAbort(struct DcsBuf *pstDcsBuf,struct QueSess *pstSess)
{
  int iRc;
  int iIdx;

  UCP_TRACE(P_DcsQuAbort);

  /* Is the dialogue usable */
  iIdx = PiSesIdx(pstDcsBuf);
  if(pstSess[iIdx].ucStatus == DCS_S_FREE || iIdx >= MAX_SESS){
    sprintf (g_caMsg,
             "<DCS> Unusable session [%d] to send queue message", iIdx);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = DCS_ES_SESUNUSE;
    UCP_TRACE_END(DCS_E_COMMAND);
  }

  /* clear the write queue */
  iRc = MsgqInit(pstSess[iIdx].iQuId,pstSess[iIdx].lWdType);
  if(iRc != MSGQ_NORMAL && iRc != MSGQ_EOF_ERROR){
    sprintf (g_caMsg, 
    "<DCS> Failure to initialize message queue with id [%d] & write type [%ld]",
    pstSess[iIdx].iQuId, pstSess[iIdx].lWdType);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = iRc;
    UCP_TRACE_END(DCS_E_NETWORK);
  } 

  /* clear the read queue */
  iRc = MsgqInit(pstSess[iIdx].iQuId,pstSess[iIdx].lRdType);
  if(iRc != MSGQ_NORMAL && iRc != MSGQ_EOF_ERROR){
    sprintf (g_caMsg, 
    "<DCS> Failure to initialize message queue with id [%d] & read type [%ld]",
    pstSess[iIdx].iQuId, pstSess[iIdx].lRdType);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    PiErrno(pstDcsBuf) = iRc;
    UCP_TRACE_END(DCS_E_NETWORK);
  } 

  UCP_TRACE_END(DCS_NORMAL);
}
/*===========================================================================*/
