/*  Access Cwa functions 
 FUNCTION & SUBROUTINE DESCRIPTION
*&N&   
*&N&    TYPE      NAME                 DESCRIPTION
*&N& --------- ------------ ---------------------------------------- 
*&N&  int      AccessCwa
*&N&  int      GetBrTmCode
*&N&  int      GetBrTmCodeLen
*&N&  int      ChkBrTmCode
*/

/* -------------------- INCLUDE FILES DECLARATION ------------------- */
#include        <sys/types.h>
#include        <errno.h>
#include        <fcntl.h>
#include        <stdio.h>

#include        "errlog.h"	
#include        "cwa.h"		/* common working area include file */
#include        "tms.h"

/* ------------- dcmpsuio.c function ���N�� ------------------------- */
#define P_AccessCwa 		47401
#define P_GetBrTmCodeLen	47402
#define P_ChkBrTmCode 		47403
#define P_GetBrTmCode 		47404
#define P_GetSystemStatus	47405
#define P_GetCwaKey 		47406
#define P_ChkTerml   		47407
#define P_ChkBrhTmName   	47408


#define  CONFIG_FILE	"iii/etc/tbl/config.dat"
#define  CWA_SHM_KEY	"CWA_SHM_KEY"
#define  REENTRY_TM             '9'  /* added by chi-fusong, 1995/03/26 */
/* ChkTerml() error message code */
#define CHK_TERML_ERR			-1
#define RENTRY_CK_ERR			-2
#define CHK_REENTRY_TM_ERR		-3

/* -------------------- EXTERN GLOBAL DECLARATION ------------------- */
extern int g_iBrhCodeLen;
extern int g_iTmCodeLen ;

/* ------ CALL FUNCTION & SUBROUTINE PROTOTYPE DECLARATIONS --------- */
int AccessCwa(int);
int GetBrTmCode(char *, char *, char *,int,int, char *);
int GetBrTmCodeLen(int *, int *);
int ChkBrTmCode(char *pcBrCode, char *pcTmCode,int,int);
int GetSystemStatus(char *brhcode,int brhLen,char *tmcode,int tmLen,char *txnDate);
int GetCwaKey();

/*****************************************************************
 *&N& ROUTINE NAME: AccessCwa()
 *&A& ARGUMENTS:
 *&A&           cwaKey : CWA Key
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D&   *�S�O�`�N*
 *&D&    ����� �I�s CwaCtlFac()
 *&D&
 */

int AccessCwa(cwaKey)
int cwaKey;
{
  int iRc;
  struct CwaCtl stCwaCtl;
  struct CwaCreatIobuf stCCBuf;

  UCP_TRACE(P_AccessCwa);

  /* Creat CWA */
  stCwaCtl.cFunCode = CWA_GET_ID;
  stCCBuf.iShmKey = cwaKey;
  stCCBuf.iSemKey = cwaKey;
  iRc = CwaCtlFac(&stCwaCtl , &stCCBuf);

  if(iRc != CWA_NORMAL){
    UCP_TRACE_END(-1);
  }

  /* Attach Cwa */
  stCwaCtl.cFunCode = CWA_ATTACH;
  stCCBuf.iShmKey = cwaKey;
  stCCBuf.iSemKey = cwaKey;

  iRc = CwaCtlFac(&stCwaCtl , &stCCBuf);
  if(iRc != CWA_NORMAL){
    UCP_TRACE_END(-2);
  }
  
  UCP_TRACE_END(0);
}

/*****************************************************************
 *&N& ROUTINE NAME: GetSystemStatus()
 *&A& ARGUMENTS:
 *&A& 
 *&R& RETURN VALUE(S):
 *&R&   -1      : ����ư��楢��
 *&R&    0      : Online mode
 *&R&    1      : Batch mode
 *&R&
 *&D& DESCRIPTION:
 *&D&        Get server status :online or batch
 *&D&
 */

int GetSystemStatus(brhcode,brhLen,tmcode,tmLen,txnDate)
char* brhcode;
int brhLen;
char* tmcode;
int tmLen;
char* txnDate;
{
  struct BrhArea *pstBrh;
  struct SSA *pstSsa;
  struct CwaCtl stCwaCtl;
  int iRc;

  UCP_TRACE("GetSystemStatus");
  stCwaCtl.cFunCode = CWA_GET_BRH_PTR;
  memcpy(stCwaCtl.caBrhId,brhcode,brhLen);
  memcpy(stCwaCtl.caTermId,tmcode,tmLen);
  iRc = CwaLowCtlFac(&stCwaCtl,&pstBrh);
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }
  memcpy(txnDate,pstBrh->caTxnDate,8);

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SSA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSsa);
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }

  if (pstSsa->sSysStatus & 0x04){
     UCP_TRACE_END(1); /*Batch mode*/
  }
  else{
     UCP_TRACE_END(0); /*Online mode*/
  }
}

/*****************************************************************
 *&N& ROUTINE NAME: GetBrTmCodeLen()
 *&A& ARGUMENTS:
 *&A&           int * brLen:buffer for brcode len 
 *&A&           int * tmLen:buffer for tmcode leN
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D&   
 *&D&  
 *&D&
 */

int GetBrTmCodeLen(brcodeLen,tmcodeLen)
int* brcodeLen;
int* tmcodeLen;
{
  struct SPA *pstSpa;
  struct CwaCtl stCwaCtl;
  int iRc;

  UCP_TRACE(P_GetBrTmCodeLen);
  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_SPA;
  iRc = CwaLowCtlFac(&stCwaCtl,&pstSpa);
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }

  *brcodeLen = (int) pstSpa->cBrCodeLen ;
  *tmcodeLen = (int) pstSpa->cTmCodeLen ;

  UCP_TRACE_END( 0 );
}

/***************************************************************
*&N& ROUTINE NAME:int GetBrTmCode()
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A&  pcHostName  : TTY name or Host Name of client 
*&A&  pcBrCode   
*&A&  pcTmCode   
*&A&  piBrLen   
*&A&  piTmLen   
*&A& 
*&R& RETURN VALUE(S):
*&R&   0 : ���`.
*&R&  -1 : �䤣��ۦP�� TTY name.
*&R&
*&D& DESCRIPTION:
*&D&  1.�M�� BIT table �� TTY name or Host name.
*&D&  2.�Y���h�����N�X�κݥ����N�X�s�b�Ƕi�Ӫ�buffer��.
*&D&
*/

int GetBrTmCode(pcHostName,pcBrCode,pcTmCode,brLen,tmLen,pcBrTxnDate)
char *pcHostName,*pcBrCode,*pcTmCode;
int brLen,tmLen;
char *pcBrTxnDate;
{
  int i;
  int iRc;
  struct BitBrhTermSt stBrhTerml;
  struct CwaCtl stCwaCtl;

  UCP_TRACE(P_GetBrTmCode);

  stCwaCtl.cFunCode = CWA_READ;
  stCwaCtl.cSegCode = CWA_SEG_BIT_TTYNAME ;
  memset(&stBrhTerml,'\0',sizeof(struct BitBrhTermSt));
  memcpy(stBrhTerml.stTerm.caLogicId, pcHostName, strlen(pcHostName));
  ErrLog(100,"dump logic id",RPT_TO_LOG,stBrhTerml.stTerm.caLogicId,10);
  iRc = CwaCtlFac(&stCwaCtl, &stBrhTerml);
  if ( iRc < 0 ) {
    /* the terminal has not been registered in BIT */
    UCP_TRACE_END( -1 );
  }
  sprintf(g_caMsg,"brlen=%d, termlen=%d",brLen,tmLen);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
  memcpy(pcBrCode,stBrhTerml.stBrh.caBrhId,brLen);
  memcpy(pcTmCode,stBrhTerml.stTerm.caTermId,tmLen);
  memcpy(pcBrTxnDate,stBrhTerml.stBrh.caTxnDate, 8);

  UCP_TRACE_END(0);
}

/*
*&N& ROUTINE NAME:int ChkBrTmCode(char *pcBrCode, char *pcTmCode)
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A&  pcBrCode        char *              pointer ����N�X
*&A&  pcTmCode        char *              pointer �ݥ����N�X
*&A& 
*&R& RETURN VALUE(S):
*&R&   0 : ���`.
*&R&  -1 : �䤣��ۦP�� Branch code & Terminal code.
*&R&
*&D& DESCRIPTION:
*&D&  1.According branch_code an terminal_code in SIF to search
*&D&    BIT and get terminal index.
*&D&
*/

int ChkBrTmCode(char *pcBrCode, char *pcTmCode,int brLen,int tmLen)
{
  int i;
  int iRc;
  struct BitBrhTermSt stBrhTerml;
  struct CwaCtl stCwaCtl;

  UCP_TRACE(P_ChkBrTmCode);

  stCwaCtl.cFunCode = CWA_SEG_BIT_BRHTM ;
  memcpy(stBrhTerml.stBrh.caBrhId, pcBrCode, brLen);
  memcpy(stBrhTerml.stTerm.caTermId, pcTmCode, tmLen);
  iRc = CwaLowCtlFac(&stCwaCtl, &stBrhTerml);
  if ( iRc < 0 ) {
    /* the terminal has not been registered in BIT */
    UCP_TRACE_END( -1 );
  }

  UCP_TRACE_END( 0 ) ;

}

/*
 *&N& ROUTINE NAME: GetCwaKey()
 *&A& ARGUMENTS:
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&   -2      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&   ����ƥΥH���o�t�ΰѼ��� config.dat ���Ҵy�z���t�ΰѼƭ�,�P�ɱN�ȶǦ^
 *&D&   ���۹������ϰ��ܼ�
 *&D&               �t�ΰѼ�                �ϰ��ܼ�
 *&D&       ----------------------------------------------
 *&D&        CWA Shared Memory Key          iCwaKey
 *&D&   �U�C���Τ��@,�|�Ϧ���ư��楢��
 *&D&       1. �L�k�}�� config.dat ��
 *&D&       2. �Өt�ΰѼƤ��s�b(CWA_SHM_KEY)
 *&D&       3. config.dat �ɤ����t�ΰѼƭӼƶW�X�̤j����C
 *&d&          (�Ѧұ`�� MAX_PARA_NO ����)
 *&D&       4. �t�ΰѼƦW�٤����׶W�X�̤j����C
 *&D&          (�Ѧұ`�� MAX_PARA_NAME_LEN ����)
 *&D&
 */

int
GetCwaKey()
{
  int iRc;
  char caFileName[80];

  UCP_TRACE(P_GetCwaKey);

  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat((char *)caFileName, (char *)"/");
  strcat((char *)caFileName,  CONFIG_FILE);
  iRc = InitCnfTbl(caFileName);
  if ( iRc < 0 ){
    UCP_TRACE_END( -1 );
  }

  iRc = GetCnfValue( CWA_SHM_KEY );
  if (iRc < 0){
    UCP_TRACE_END( -2 );
  }

  UCP_TRACE_END( iRc );
}

/*
 *&N& ROUTINE NAME: ChkTerml()
 *&A& ARGUMENTS:
 *&A&   NAME         TYPE                DESCRIPTION
 *&A& ------------------------------------------------------------------
 *&A& pcBrCode       char *              ����N��
 *&A& pcTmCode       char *              �׺ݾ��N��
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    int     : �Y�Ӳ׺ݾ��b BIT �����w�q,�h�Ǧ^�b BIT ���� index
 *&R&    -1      : �_�h,�Ǧ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D&    �ھ� SIF ������O�P�׺ݾ��N��,�ˮָӲ׺ݾ��O�_�b�t�Ϊ�
 *&D&    ����ݥ�����( BIT )�����w�q 
 */

int
ChkTerml( pcBrCode, pcTmCode , ppcTerm , cReentryStatus)
char *pcBrCode;
char *pcTmCode;
char **ppcTerm;
char cReentryStatus;
{
  int iRc;
  struct CwaCtl stCwaCtl;

  UCP_TRACE( P_ChkTerml );
  stCwaCtl.cFunCode = CWA_GET_TERM_PTR;
  memcpy(stCwaCtl.caBrhId, pcBrCode, g_iBrhCodeLen);
  memcpy(stCwaCtl.caTermId, pcTmCode, g_iTmCodeLen);
  iRc = CwaLowCtlFac(&stCwaCtl, ppcTerm);
  if ( iRc < 0 ) {
    /* the terminal has not been registered in BIT */
    sprintf( g_caMsg, "ChkTerml: Terminal not registered in BIT" );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    DetErrRpt( CHK_TERML_ERR, g_caMsg );
    UCP_TRACE_END( CHK_TERML_ERR );
  }
/*
  ErrLog(100,"ChkTerml: Terml struct=",RPT_TO_LOG,
         *ppcTerm, sizeof(struct TermArea) );
*/

  if ( ((struct TermArea *)(*ppcTerm))->cTermType != REENTRY_TM ) {
    sprintf(g_caMsg,
      "ChkTerml: Branch[%.*s] Terminal[%.*s] is not a Reentry TM in BIT",
      g_iBrhCodeLen,pcBrCode,g_iTmCodeLen,pcTmCode );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( CHK_REENTRY_TM_ERR );
  }

  UCP_TRACE_END( 0 ) ;
}


/*
 *&N& ROUTINE NAME: ChkBrhTmName()
 *&A& ARGUMENTS:
 *&A&   NAME         TYPE                DESCRIPTION
 *&A& ------------------------------------------------------------------
 *&A& pcBrCode       char *              ����N��
 *&A& pcTmCode       char *              �׺ݾ��W��
 *&A&
 *&R& RETURN VALUE(S):
 *&R&     0      : �Y�Ӳ׺ݾ��W�٦b BIT ���w�q���ҫ��w������ݪ��׺ݾ�,
 *&R&              �Ǧ^ 0
 *&R&    -1      : �_�h,�Ǧ^ < 0
 *&R&
 *&D& DESCRIPTION:
 *&D&    �ھ� SIF ������O�P�׺ݾ��W��,�ˮָӲ׺ݾ��O�_�b�t�Ϊ�
 *&D&    ����ݥ�����( BIT )�����w�q 
 */

int
ChkBrhTmName( pcBrCode, pcTmName , ppcBrh)
char *pcBrCode;
char *pcTmName;
char **ppcBrh;
{
  char   *pcaBitTbl;
  int iRc, i;
  struct CwaCtl stCwaCtl;
  struct BrhArea *pstBrhArea;
  struct TermArea  *pstTermArea;
  int iOffSet,iTotTmCnt;

  UCP_TRACE( P_ChkBrhTmName );

  stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
  stCwaCtl.cSegCode = CWA_SEG_BIT_START;
  iRc = CwaLowCtlFac(&stCwaCtl,&pcaBitTbl);
  if (iRc != 0) {
    UCP_TRACE_END(iRc);
  }

  stCwaCtl.cFunCode = CWA_GET_BRH_PTR;
  memcpy (stCwaCtl.caBrhId, pcBrCode, g_iBrhCodeLen);
  memcpy (stCwaCtl.caTermId, pcTmName, g_iTmCodeLen);
  iRc = CwaLowCtlFac (&stCwaCtl, &pstBrhArea);
  if ( iRc < 0 ) {
    /* the branch has not been registered in BIT */
    sprintf( g_caMsg, "<DCS> Illegal branch [%s] defined in BIT", pcBrCode);
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( -3 );
  }

  /*pstBrhArea = (struct BrhArea *) *ppcBrh;*/
  iTotTmCnt = pstBrhArea->iNoOfTerm;

  iOffSet = pstBrhArea->iTermOffset;
  pstTermArea= (struct TermArea *) (pcaBitTbl+iOffSet);

  for(i=0;i<iTotTmCnt;i++)  {

    int iLogicIdLen;

    iLogicIdLen = strlen(pstTermArea->caLogicId) > 14
                         ? 14 : strlen(pstTermArea->caLogicId);
    if ( iLogicIdLen < 14 ) {
      if ( strlen(pcTmName) > iLogicIdLen ) {
         iLogicIdLen = strlen(pcTmName);
      }
    }

    if (strncmp(pcTmName,pstTermArea->caLogicId, iLogicIdLen)== 0) {
      /*  *ppcIoBuf = pcaBitTbl+iOffset;  */
      break;
    }
    else  {
      iOffSet = pstTermArea->iNxtTmOffset;
      pstTermArea= (struct TermArea *) (pcaBitTbl+iOffSet);
    }
  }
  
  if (i == iTotTmCnt)  {
    sprintf (g_caMsg,"<DCS> Unable to find terminal [%s] in branch [%s]",
             pcTmName, pcBrCode);
    ErrLog (1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( -3 );
  }

  UCP_TRACE_END( 0 ) ;
}

