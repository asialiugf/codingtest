
/*------------------------------------------------------------------*/
/*		Define DCS constant 				    */
/*------------------------------------------------------------------*/
#define	MAX_SESS	10	/* Number of Session table in share memory */
#define	MAX_PROGRAM	5
#define MAX_NETWKTBL_ARRAY	30

#define DCS_TABLE_PATH "/iii/etc/dcd/"
#define BIT_TABLE_PATH "/iii/etc/tbl/"
#define LU0TABLE       "lu0tbl"
#define BITTABLE       "bit.dat"
#define DCS_ERROR	-1
#define DCS_MAX_DATA_LEN 6200
#define DCS_MAX_LENG	6400

#define DCS_NOMOREDATA   1


/*------------------------------*/
/* define DCS API dcs kind code */
/*------------------------------*/
#define  ACTIVE_MODE 'A'
#define  PASSIVE_MODE 'P'

/*-----------------------------------*/
/* define DCS API protocol type code */
/*-----------------------------------*/
#define  TOPEND_DCS	'T'
#define  SOCKET_DCS	'S'
#define  QUEUE_DCS	'Q'
#define  LU62_DCS	'L'
#define  LU0_DCS	'O'
#define  TPE_TERM_LEN	2
#define  TPE_BR_LEN	4
#define  TPE_BRH_LEN    10
#define  SIF_SIZE	2056
#define  SOF_SIZE	2056
#define  MAX_LEN	2400
#define  MAX_SOFLEN	2048
#define  MAX_SOF	300

#define	DCS_TIMEOUT	150 		/* sec wait time */
/*
#define LONG_MAX	2147483647    
*/
#define	DCS_BLOCK	(long)LONG_MAX	/* suspend, wait for message */

/*---------------------------------------------------------------------------*/
/* DCS states each connection has an associated state in the connection flow.*/
/*---------------------------------------------------------------------------*/
#define DCS_S_FREE		0x0
#define DCS_S_CONNECT		0x1
#define DCS_S_DISCONNECT	0x2
#define DCS_S_USED		0x3
#define DCS_S_ERROR		0x4
#define DCS_S_USABLE		0x5

/* ---------------------------------------- */
/* define AP API function code              */
/* ---------------------------------------- */
#define    DCS_M_RMT_START_PGM		'1'
#define    DCS_M_SEND			'2' 
#define    DCS_M_RECEIVE		'3' 
#define    DCS_M_RMT_STOP_PGM		'4' 
#define    DCS_M_DISCONNECT_ALL		'5' 
#define    DCS_M_SEND_DISCONNECT	'6' 
#define    DCS_M_RECEIVE_ALL		'9'
#define    DCS_M_B_RMT_START_PGM	'Z'
#define    DCS_M_ACCEPT			'A'

/*-------------------------------------------*/
/* define DCS API function code              */
/*-------------------------------------------*/
#define	DCSCONNECT         '1'
#define	DCSDISCONNECT      '2'
#define DCSWRITE           '3'
#define DCSREAD            '4'
#define DCSCONFIRM         '5'
#define DCSCONFIRMED       '6'
#define DCSSTART           '7'
#define DCSRESTART         '8'
#define DCSSHUTDOWN        '9'
#define DCSACCEPT          'A'
#define DCSWRDISCONECT     'B'
#define DCSWRITETO         'C'
#define DCSREADALL	   'D'
#define DCSINITIAL         'E'
#define DCSTERMINATE       'F'
#define DCSREADFROM        'G'
#define	DCSCONNECTWRITE    'H'
#define DCSACCEPTREAD      'I'

/* ---------------------------------------- */
/* define DCS return code to AP             */
/* ---------------------------------------- */
#define    DCS_M_NORMAL                '0'
#define    DCS_M_COMMAND_ERROR         '1'
#define    DCS_M_DATA_ERROR            '2'
#define    DCS_M_LOCAL_ERROR           '3'
#define    DCS_M_REMOTE_ERROR          '4'
#define    DCS_M_NETWORK_ERROR         '5'
#define    DCS_M_PGM_ID_ERROR          '6'
#define    DCS_M_UCPS_ERROR            '7'
#define    DCS_M_CONVSIF_ERROR         '8'
#define    DCS_M_CONVSOF_ERROR         '9'
#define    DCS_M_TIMEOUT_ERROR         'A'
#define    DCS_M_SYSTEM_ERROR          'B'

/*-------------------------------*/
/* Define DCS API error code     */
/*-------------------------------*/
#define DCS_NORMAL		0
#define	DCS_E_COMMAND		-1
#define DCS_E_NETWORKTBL	-2
#define DCS_E_LOCALDCS		-3
#define DCS_E_TIMEOUT		-4
#define DCS_E_NETWORK		-5
#define DCS_E_AP		-6
#define DCS_E_CONVSIF		-7
#define DCS_E_CONVSOF		-8
#define DCS_E_RCV_DISCONNECT    -9

/*----------------------------------------*/
/* Define DCS API extended error code     */
/*----------------------------------------*/
#define DCS_ES_SESOVERFLW	101
#define DCS_ES_SESUNUSE		102
#define DCS_ES_SEQNO		103
#define DCS_ES_PROTOCOL		104
#define DCS_ES_OPENTBLFILE	201
#define DCS_ES_TBLARRAYOVERFLW	202
#define DCS_ES_QTYPE		501

/*------------------------------*/
/* define AP API struct dcs_twa */
/*------------------------------*/
struct  DcsApi{
  char  caDesAddr[5];
  char  caPrgId[4];
  char  caDataLen[4];
  char  cFunCode;
  char  cRtnCode;
  char  caErrCode[2];
} ;

/*--------------------------------------------------------------------------*/
/*  TPU session id table each Prgid has one session table array index       */
/*--------------------------------------------------------------------------*/
struct TpuMap {
  int iSesIdx;	/* initial value must be -1(ERROR) */
  char cProto;	/* keep protocol pass by dcs service */
  long lCnvId;
  int iFileId;
  int iFiller;
};

/*-----------------------------------*/
/*  define DCS API infomation struct */
/*-----------------------------------*/
struct DcsInfo {
  char caDesCode[10];
  char caServCode[10];
  char caSrcCode[10];
  char cRqstCode;
  int iSesIdx;
  char cProto;  /*pass to Prgid table when call connect or accept*/
  int iReply;
  long lSeqNo;     /* in APPC will fill conversation id */
  int iErrno;
  char cTxnStatus; /* remote txn status normal='0';abnormal='1' */
  int iDataLen;   /* length of dcs_siof */
  long lWaiTime;   /* waiting time */
};

#define DCS_MAX_DATA_LEN 6200
/*-----------------------------------------*/
/* define DCS API input output data struct */
/*-----------------------------------------*/
struct DcsSiof {
  char cMoreByte;
  char cKind;
  char cProtoType;
  char caDataLen[5];
  char caData[DCS_MAX_DATA_LEN];
};

/*-----------------------*/
/* define DCS API struct */
/*-----------------------*/
struct DcsBuf {
  struct DcsInfo stDcsInfo;
  union unData {
    char *pcaData;
    struct DcsSiof *pstDcsSiof;
  } unData;
};

/*--------------------------------------------*/
/* define macro for simple use DCS API struct */
/*--------------------------------------------*/
/* p : must be union DcsBuf variable */
#define		McaDesCode(p)		(p).stDcsInfo.caDesCode
#define		McaServCode(p)		(p).stDcsInfo.caServCode
#define		McaSrcCode(p)		(p).stDcsInfo.caSrcCode
#define		McRqstCode(p)	 	(p).stDcsInfo.cRqstCode
#define		MiSesIdx(p)		(p).stDcsInfo.iSesIdx
#define		McProto(p)		(p).stDcsInfo.cProto
#define		MiReply(p)		(p).stDcsInfo.iReply
#define		MlSeqNo(p)		(p).stDcsInfo.lSeqNo
#define		MiErrno(p)		(p).stDcsInfo.iErrno
#define		McTxnStatus(p)		(p).stDcsInfo.cTxnStatus
#define		MiDataLen(p)		(p).stDcsInfo.iDataLen
#define		MlWaiTime(p)		(p).stDcsInfo.lWaiTime
#define		MunData(p)		(p).unData.pcaData
#define         MpstDcsSiof(p)		(p).unData.pstDcsSiof
#define		McMoreByte(p)		(p).unData.pstDcsSiof->cMoreByte
#define		McKind(p)		(p).unData.pstDcsSiof->cKind
#define		McProtoType(p)		(p).unData.pstDcsSiof->cProtoType
#define		McaDataLen(p)		(p).unData.pstDcsSiof->caDataLen
#define		McaData(p) 		(p).unData.pstDcsSiof->caData

/* p : must be union DcsBuf pointer variable */
#define		PcaDesCode(p)		(p)->stDcsInfo.caDesCode
#define		PcaServCode(p)		(p)->stDcsInfo.caServCode
#define		PcaSrcCode(p)		(p)->stDcsInfo.caSrcCode
#define		PcRqstCode(p) 		(p)->stDcsInfo.cRqstCode
#define		PiSesIdx(p)		(p)->stDcsInfo.iSesIdx
#define		PcProto(p)		(p)->stDcsInfo.cProto
#define		PiReply(p)		(p)->stDcsInfo.iReply
#define		PlSeqNo(p)		(p)->stDcsInfo.lSeqNo
#define		PiErrno(p)		(p)->stDcsInfo.iErrno
#define		PcTxnStatus(p)		(p)->stDcsInfo.cTxnStatus
#define		PiDataLen(p)		(p)->stDcsInfo.iDataLen
#define		PlWaiTime(p)		(p)->stDcsInfo.lWaiTime
#define		PunData(p)		(p)->unData.pcaData
#define         PpstDcsSiof(p)		(p)->unData.pstDcsSiof
#define		PcMoreByte(p)		(p)->unData.pstDcsSiof->cMoreByte
#define		PcKind(p)		(p)->unData.pstDcsSiof->cKind
#define		PcProtoType(p)		(p)->unData.pstDcsSiof->cProtoType
#define		PcaDataLen(p)		(p)->unData.pstDcsSiof->caDataLen
#define		PcaData(p) 		(p)->unData.pstDcsSiof->caData

/* ----------------------------------------------------------------- */

