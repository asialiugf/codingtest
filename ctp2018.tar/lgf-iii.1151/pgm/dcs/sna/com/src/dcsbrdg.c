
/* FUNCTION & SUBROUTINE DESCRIPTION
 *&N&   TYPE      NAME                     DESCRIPTION
 *&N&-------- -------------  ----------------------------------------------
 *&N& int     AttQue()       attach the queue
 *&N& int     RdQue()
 *&N& int     WrQue()
 *&N& int     GetFileData()
*/

#include <fcntl.h>
#include <errno.h>
#include <sys/ipc.h>
#include <sys/signal.h>
#include "errlog.h"
#include "msgqop.h"
#include "dcs.h"


#define  MAX_DATA_LEN	256
#define  ALIMENT        8
#define  DCSCMDOK       '0'

#define P_AttQue        67001
#define P_RdQue         67002
#define P_WrQue         67003
#define P_GetFileData	67004

#define DCSLDPRC        'O'        


static int sg_iaQuId[MAX_NETWKTBL_ARRAY];	/* keep QuId array */
static int sg_iMaxQuId;				/* max creat queue */
static struct DcsBuf  gs_stDcsBuf;

static int gs_iQueKey;
static int gs_iQuId;

struct Siof {
  char cDcsCmd;
  int  iSiofLen;
  unsigned char ucaSiofData[ MAX_SOFLEN ];
};

extern char gs_caTmCode[20];    /* 5 -> 20 by YEN 950531 */
extern char gs_caBrCode[20];    /* 5 -> 20 by YEN 950531 */
static long gs_iWrQueType;
static long gs_iRdQueType;


/**********************************************************************
 *&N& ROUTINE NAME:AttQue()
 *&A& ARGUMENTS:NONE
 *&R& RETURN VALUE(S):
 *&R&            0:normal return
 *&R&           -1:rmtquetbl open error
 *&R&           -2:the queue size is undefined in the rmtquetbl 
 *&R&           -3:get queue error 
 *&D& DESCRIPTION:
 *&D&           This subprogram will be called to attach the queue which
 *&D&           is used to communicate with the TPU.
 *&D&           1. Attach the queue according the speification of the
 *&D&              "rmtquetbl"
 *&D&           2. the dcxdaemon.x reads the queue in type BR_CODE+TM_CODE  
 *&D&              ex:the dcxdaemon.x serves the txn comes from the branch
 *&D&                 1001 terminal:02 therefore the message it read is
 *&D&                 100102
 *&D&           3. the dcxdaemon.x writes the queue in type      
 *&D&              1+0+BR_CODE+TM_CODE
 *&D&              ex:as the above example, it will write in type 10100102
 **********************************************************************/
int
AttQue()
{
  int i, iRc=0;
  char caFileName[80];
  char *pcFoundFlg;
  /* for get data */
  char caDataType[5];
  long *plDataVar[5];
  /* input data variable for queuetbl */
  char caDesCode[20];
  long lQuSize;
  long lQuType;
  int iLastQuKey;	/* keep last queue key */
  FILE *pfQueFile;
  char caQueType[20];

  UCP_TRACE(P_AttQue);

  strcpy(caQueType,gs_caBrCode);
  strcat(caQueType,gs_caTmCode);

  gs_iRdQueType = atol(caQueType);              /* assign queue type */
  gs_iWrQueType = gs_iRdQueType + 1000*10000;   /* assign queue type */

  /* get the path name */
  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat(caFileName, DCS_TABLE_PATH);
  strcat(caFileName,"rmtquetbl");

  /* read rmtquetbl */
  pfQueFile = fopen(caFileName,"rt");

  if( pfQueFile == NULL) {
      sprintf("DcsAttQue:fopen %s fail errno=%d",caFileName,errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(-1);
  }

  strcpy(caDataType,"sdD");
  plDataVar[0] = (long *) caDesCode;
  plDataVar[1] = &gs_iQueKey;
  plDataVar[2] = &lQuType;

  i = 0;
  sg_iMaxQuId = 0;
  iLastQuKey = -1;	/* initial iLastQuKey */ 
  lQuSize = -1;         /* initial iQuSize = 0 */
  while((iRc = GetFileData(pfQueFile,3,caDataType,plDataVar)) == 0){
    if(lQuSize < 0){
      iRc = strncmp(caDesCode,"QUEUE_SIZE",10);
      if(iRc == 0){
        lQuSize = lQuType;
      }
      else{	/* no queue size data error */
        fclose(pfQueFile);
        ErrLog(1000,"AttQue: Queue Size no define error!",RPT_TO_LOG,0,0);
        UCP_TRACE_END(-2);
      } /* end of if(iRc == 0) -- else */
    }
    else{
      if((lQuSize > 0) && ((gs_iQueKey != iLastQuKey) ||
         (iLastQuKey == -1))){
        iRc = MsqGet(&gs_iQuId,gs_iQueKey);
        if(iRc != 0){	/* creat queue error */
          UCP_TRACE_END(-3);
        } /* end of if(iRc != 0) */
        iLastQuKey = gs_iQueKey;
      } /* end of if((lQuSize > 0) && ((gs_iQueKey != iLastQuKey) ||
                       (iLastQuKey == -1))) */
    } /* end of if(lQuSize < 0) -- else */ 
  } /* end of while((iRc = GetFileData(3,caDataType,plDataVar)) == 0) */
  fclose(pfQueFile);
  ErrLog(100,"DcsAttQue End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(0);
}


int RdQue(char *pcCmd,char *pcaData,int *iLen) 
{
  int  iRc,i;
  int iSiofLen=MAX_LEN;
  struct MsgBuf stMsgp;
  struct Siof stSiof;

  UCP_TRACE(P_RdQue);

  memset(&stSiof,0x00,sizeof(struct Siof) );
  memset(&stMsgp,0x00,sizeof(struct MsgBuf) );
  iRc = MsqRead(gs_iQuId,gs_iRdQueType,&iSiofLen,&stMsgp,0);
  memcpy(&stSiof,stMsgp.caText,iSiofLen); 

  if( iRc  != MSGQ_NORMAL ) {
    UCP_TRACE_END( MSGQ_ERROR );
  }

  *iLen = stSiof.iSiofLen;
  *pcCmd = stSiof.cDcsCmd;
  memcpy(pcaData,stSiof.ucaSiofData,*iLen);
  UCP_TRACE_END( MSGQ_NORMAL );
}



int WrQue(char *pcRc,char *pcaData,int *iSiofLen) 
{

  int  iRc,i;
  int iTmpLen;
  struct MsgBuf stMsgp;
  struct Siof stSiof;
  unsigned char caTmpFile[10];


  UCP_TRACE(P_WrQue);  

  memset(&stSiof,0x00,sizeof(struct Siof) );

  stSiof.cDcsCmd=*pcRc;
  stSiof.iSiofLen=*iSiofLen;

  memset(stSiof.ucaSiofData,0x00,*iSiofLen); 
  memcpy(stSiof.ucaSiofData,pcaData,*iSiofLen); 
  strcpy(caTmpFile,"tmpfile");

  iTmpLen = *iSiofLen + ALIMENT;

  stMsgp.lType=gs_iWrQueType;

  memcpy(stMsgp.caText,&stSiof,iTmpLen); 
  iRc = MsqWrite(gs_iQuId,iTmpLen,&stMsgp,IPC_NOWAIT,caTmpFile);

  if( iRc  != MSGQ_NORMAL ) {
    UCP_TRACE_END( MSGQ_ERROR );
  }

  UCP_TRACE_END( MSGQ_NORMAL );
}



int
GetFileData(FILE *pfFile, int iDataNo,char caDataType[], long* plDataVar[])
{
  int i;
  long lOffset;
  char caDataBuf[MAX_DATA_LEN];
  char cBypass,cDummy;

  UCP_TRACE(P_GetFileData);

  do {
    if(feof(pfFile)){
      UCP_TRACE_END(-1);
    }

    fgets(caDataBuf,MAX_DATA_LEN,pfFile);
    if (caDataBuf[0] != '#') {
      lOffset = (long) strlen(caDataBuf) * -1;
      fseek(pfFile,lOffset,SEEK_CUR);

      for(i=0; i < iDataNo ; i++){

        fscanf(pfFile,"%c",&cBypass);
        if( cBypass != '*') {

          fseek(pfFile,-1,SEEK_CUR);
          switch(caDataType[i]){
            case 't' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%d\n",(short *) plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%d ",(short *) plDataVar[i]);
              }
              break;
            case 'd' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%d\n",(int *) plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%d ",(int *) plDataVar[i]);
              }
              break;
            case 'D' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%ld\n",(long *) plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%ld ",(long *) plDataVar[i]);
              }
              break;
            case 'o' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%o\n",(int *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%o ",(int *)plDataVar[i]);
              }
              break;
            case 'O' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%lo\n",(long *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%lo ",(long *)plDataVar[i]);
              }
              break;
            case 'x' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%x\n",(int *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%x ",(int *)plDataVar[i]);
              }
              break;
            case 'X' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%lx\n",(long *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%lx ",(long *)plDataVar[i]);
              }
              break;
            case 'i' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%i\n",(int *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%i ",(int *)plDataVar[i]);
              }
              break;
            case 'I' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%li\n",(long *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%li ",(long *)plDataVar[i]);
              }
              break;
            case 's' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%s\n",(char *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%s ",(char *)plDataVar[i]);
              }
              break;
            case 'c' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%c\n",(char *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%c ",(char *)plDataVar[i]);
              }
              break;
            default :
              sprintf(g_caMsg,"GetFileData: data-type=%c error",caDataType[i]);
              ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
              UCP_TRACE_END(-2);
          }  /* end switch */
        }
        else {
          if( (i == iDataNo-1) && (cDummy == '\n') ) {
            fscanf(pfFile,"\n");
            UCP_TRACE_END(0);
          }
          else fscanf(pfFile," ");
        } /* end if '*' */
      }  /* end for */
    }  /* end if  '#' */
  } while(caDataBuf[0] == '#');

  UCP_TRACE_END(0);
}
