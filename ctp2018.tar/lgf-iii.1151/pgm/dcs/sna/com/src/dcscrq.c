#include <errno.h>
#include "errlog.h"

#define MAX_DATA_LEN	256

#define P_GetFileData	67004

#ifdef NO_DELETE
int
GetFileData(FILE *pfFile, int iDataNo,char caDataType[], long* plDataVar[])
{
  int i;
  long lOffset;
  char caDataBuf[MAX_DATA_LEN];
  char cBypass,cDummy;

  UCP_TRACE(P_GetFileData);

  do {
    if(feof(pfFile)){
      UCP_TRACE_END(-1);
    }

    fgets(caDataBuf,MAX_DATA_LEN,pfFile);
    if (caDataBuf[0] != '#') {
      lOffset = (long) strlen(caDataBuf) * -1;
      fseek(pfFile,lOffset,SEEK_CUR);

      for(i=0; i < iDataNo ; i++){

        fscanf(pfFile,"%c",&cBypass);
        if( cBypass != '*') {

          fseek(pfFile,-1,SEEK_CUR);
          switch(caDataType[i]){
            case 't' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%d\n",(short *) plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%d ",(short *) plDataVar[i]);
              }
              break;
            case 'd' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%d\n",(int *) plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%d ",(int *) plDataVar[i]);
              }
              break;
            case 'D' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%ld\n",(long *) plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%ld ",(long *) plDataVar[i]);
              }
              break;
            case 'o' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%o\n",(int *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%o ",(int *)plDataVar[i]);
              }
              break;
            case 'O' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%lo\n",(long *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%lo ",(long *)plDataVar[i]);
              }
              break;
            case 'x' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%x\n",(int *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%x ",(int *)plDataVar[i]);
              }
              break;
            case 'X' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%lx\n",(long *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%lx ",(long *)plDataVar[i]);
              }
              break;
            case 'i' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%i\n",(int *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%i ",(int *)plDataVar[i]);
              }
              break;
            case 'I' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%li\n",(long *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%li ",(long *)plDataVar[i]);
              }
              break;
            case 's' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%s\n",(char *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%s ",(char *)plDataVar[i]);
              }
              break;
            case 'c' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%c\n",(char *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%c ",(char *)plDataVar[i]);
              }
              break;
            default :
              sprintf(g_caMsg,"GetFileData: data-type=%c error",caDataType[i]);
              ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
              UCP_TRACE_END(-2);
          }  /* end switch */
        }
        else {
          if( (i == iDataNo-1) && (cDummy == '\n') ) {
            fscanf(pfFile,"\n");
            UCP_TRACE_END(0);
          }
          else fscanf(pfFile," ");
        } /* end if '*' */
      }  /* end for */
    }  /* end if  '#' */
  } while(caDataBuf[0] == '#');

  UCP_TRACE_END(0);
}
#endif
