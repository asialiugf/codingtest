#include  <errno.h>
#include  "big2host.h"
#include  "errlog.h"
#include  "dccpgdef.h"
#include  "dcs.h"
/*********************************************************************/
/* PROGRAM-NAME:dcsoftxf.c                                           */
/*********************************************************************/

#define  SOF_HEAD_LEN     27  /* the length of the SOF header */
#define  SOF_DEVICE_OFFS  24  /* the offset of the device field in the SOF */
#define  SOF_CTL_OFFS     25  /* the offset of the ctl-byte in the SOF */
#define  SOF_MSGLEN_OFFS  27  /* the offset of the msg-len in the SOF */
#define  SOF_MSGDATA_OFFS 29  /* the offset of the msg-data in the SOF */
#define  SI               0x0e
#define  SO               0x0f

#define  P_SofConvt        10000
#define  P_SofCodeConvt    10000
#define  P_ReinputSofConvt 10001 

extern struct table_array cnv_tbl;
extern struct table_array *cnv_ptr;

/* TPE SOF FORMAT */
struct TPESOF {          
  char fmh[3];
  char br_id[10];
  char tm_id[4];
  char out_dev;
  char form_id[7];
  char status[2];
  char lendata[493];
  } ;

/**********************************************************************
 *&N& ROUTINE NAME:SofConvt()
 *&A& ARGUMENTS:*pcaHostSof:SOF received from the Host
 *&A&           *pcaTpeSof :TPE SOF after convertion 
 *&A&           *iSofLen   :the lenght of the SOF after converion
 *&R& RETURN VALUE(S):-2 -> code convert error
 *&D& DESCRIPTION:
 *&D&
 **********************************************************************/
int 
SofConvt(char *pcaHostSof,char *pcaTpeSof, int *iSofLen)
{
 int iRc;
 int iTpeSofLen;
 unsigned char caHostTpeSof[ MAX_LEN +8 ];

  UCP_TRACE(P_SofConvt);

  iTpeSofLen = *iSofLen;
  memcpy(pcaTpeSof,pcaHostSof,iTpeSofLen);

  /* convert the SOF FORMAT first, if needed */
  /* In this case there is no need to REFORMAT the SOF */
  
  /* convert the CODE of the TPE SOF, from EBCDIC to ASCII ... */
  sprintf(g_caMsg,"BEFORE SofCodeConvt():SOF-LEN=%d,INPUT-SOF:",iTpeSofLen);
  ErrLog(100,g_caMsg,RPT_TO_LOG,pcaTpeSof,iTpeSofLen);
  if( (iRc=SofCodeConvt(pcaTpeSof ,&iTpeSofLen )) ==  DCS_NORMAL) {
    *iSofLen = iTpeSofLen;
    sprintf(g_caMsg,"AFTER SofCodeConvt() SOF-LEN=%d,OUTPUT-SOF:",iTpeSofLen);
    ErrLog(100,g_caMsg,RPT_TO_LOG,pcaTpeSof,iTpeSofLen);
    UCP_TRACE_END(0);
  }
  else { 
    ErrLog(1000,"Tpu Tpe Sof error",RPT_TO_LOG,pcaTpeSof,iTpeSofLen);
    UCP_TRACE_END(-2);
  }
  UCP_TRACE_END(0);
} 

int
SofCodeConvt(unsigned char *pucaHstSof,int *iHstSofLen)
{
 unsigned char  ucaUnxSof[2048];
 short sShtLen;
 int i,j,iRtLen;
 int iLen_Pt=0;
 short sSofLen;

 UCP_TRACE(P_SofCodeConvt);

 
 if ((i=host_big5(pucaHstSof,ucaUnxSof,SOF_HEAD_LEN-2,cnv_ptr))
     !=SOF_HEAD_LEN-2) {
   sprintf(g_caMsg,"SOF head code conversion error len=%d !",i);
   ErrLog(2000,g_caMsg,RPT_TO_LOG,0,0);
   UCP_TRACE_END(-1);
 }

 memcpy(ucaUnxSof+SOF_CTL_OFFS,pucaHstSof+SOF_CTL_OFFS,2);  

 if((i=*iHstSofLen-SOF_HEAD_LEN) > 0) {
   /* temporary solution begin YEN 0607 */
   if (*iHstSofLen == 29) {
     memcpy( pucaHstSof, ucaUnxSof, *iHstSofLen );
     memset(&pucaHstSof[SOF_MSGLEN_OFFS],0,2);
     UCP_TRACE_END(0);
   }
   /* temporary solution end YEN 0607 */
   sShtLen=(unsigned char)pucaHstSof[ SOF_MSGLEN_OFFS ] * 256 
           + (unsigned char)pucaHstSof[ SOF_MSGLEN_OFFS +1 ]; 
   memcpy((char *)(ucaUnxSof+SOF_MSGLEN_OFFS),&pucaHstSof[ SOF_MSGLEN_OFFS],2);
/* ----------- Add by Ellen for converting the packed SOF ------ start ---- */
/* unpacked SOF   header + sof_len(2) + sof                                 */
/* packed SOF     header + sof_len(2) + header + sof_len(2) + sof1 + header */
/*                + sof_len(2) + sof2 ....                                  */
/* ------------------------------------------------------------------------ */

   sSofLen=sShtLen;
   for (;sShtLen > iLen_Pt;) {
     if ( ucaUnxSof[ SOF_DEVICE_OFFS ] == '@' ) {
       iLen_Pt=iLen_Pt+SOF_MSGDATA_OFFS;
       if ((i=host_big5(pucaHstSof+iLen_Pt,ucaUnxSof+iLen_Pt,
           SOF_HEAD_LEN-2,cnv_ptr))!=SOF_HEAD_LEN-2) {
         sprintf(g_caMsg,"SOF head code conversion error len=%d !",i);
         ErrLog(2000,g_caMsg,RPT_TO_LOG,0,0);
         UCP_TRACE_END(-1);
       }
       memcpy(ucaUnxSof+SOF_CTL_OFFS+iLen_Pt,pucaHstSof+SOF_CTL_OFFS+iLen_Pt,
              2);  
       sSofLen = (unsigned char)pucaHstSof[ SOF_MSGLEN_OFFS+iLen_Pt ] * 256 
                 + (unsigned char)pucaHstSof[ SOF_MSGLEN_OFFS+iLen_Pt +1 ]; 
       memcpy((char *)(ucaUnxSof+SOF_MSGLEN_OFFS+iLen_Pt),
              &pucaHstSof[ SOF_MSGLEN_OFFS+iLen_Pt],2);
     } /* for 'if ( ucaUnxSof[ SOF_DEVICE_OFFS ] == '@' )' */ 
     for (i=SOF_MSGDATA_OFFS+iLen_Pt; i<sSofLen+SOF_MSGDATA_OFFS+iLen_Pt; ){
       if (pucaHstSof[i] == SI) {
         j=i;
         while ((pucaHstSof[i] != SO)&&(i<sSofLen+SOF_MSGDATA_OFFS+iLen_Pt)) {
           i++;
         }
         if ( i == sShtLen+SOF_MSGDATA_OFFS ) {
           ErrLog(2000,"SOF DATA NO SHIFT-OUT ERROR !",RPT_TO_LOG,0,0);
           UCP_TRACE_END(-1);
         }
         i++; 
         iRtLen=host_big5(pucaHstSof+j,ucaUnxSof+j,i-j,cnv_ptr);
         /* iRtLen does not include the length of SI & SO, so if the data is */
         /* chinese code, then stuff with the 2 SPACE char in the tail of    */
         /* the data                                                         */
         memcpy(ucaUnxSof+j+iRtLen,"  ",2);
         ucaUnxSof[j+iRtLen+2]='\0';
       } /* for 'if (pucaHstSof[i] == SI)' */
       else  {             
         j=i;
         while ((pucaHstSof[i] != SI) &&
                (i < sSofLen+SOF_MSGDATA_OFFS+iLen_Pt) ) {
           i++;
         }
         if ( host_big5(pucaHstSof+j,ucaUnxSof+j,i-j,cnv_ptr) != (i-j) ) {
           ErrLog(2000,"SOF English data code conversion error !",
                  RPT_TO_LOG,0,0);
           UCP_TRACE_END(-1);
         }
       } /* for 'if (pucaHstSof[i] == SI)' */
    }
    iLen_Pt=iLen_Pt+sSofLen;
 }  

/* ----------- Add by Ellen for converting the packed SOF ------  end  -----*/

 *iHstSofLen = sShtLen + SOF_MSGDATA_OFFS;
 memcpy( pucaHstSof, ucaUnxSof, *iHstSofLen );
 UCP_TRACE_END(0);
}

 memcpy( pucaHstSof, ucaUnxSof, *iHstSofLen );

 UCP_TRACE_END(0);
}
  


int
ReinputSofConvt(unsigned char *pucaHstSof,int *iHstSofLen)
{
 unsigned char  ucaUnxSof[2048];
 unsigned char  ucaTmpBuf[2048];
 unsigned char  ucaReinBuf[2048];
 short sShtLen;
 int i,j,iRtLen;
 int iLen;

 UCP_TRACE(P_ReinputSofConvt);

 sprintf(g_caMsg,"dcsoftxf reinput :iHstSofLen=%d,pucaHstSof",*iHstSofLen);
 ErrLog(100,g_caMsg,RPT_TO_LOG,pucaHstSof,*iHstSofLen);
 
 if((i=host_big5(pucaHstSof,ucaUnxSof,SOF_HEAD_LEN-2,cnv_ptr))!=SOF_HEAD_LEN-2)
 {
   sprintf(g_caMsg,"SOF head code conversion error len=%d !",i);
   ErrLog(2000,g_caMsg,RPT_TO_LOG,0,0);
   UCP_TRACE_END(-1);
 }

 memcpy(ucaUnxSof+SOF_CTL_OFFS,pucaHstSof+SOF_CTL_OFFS,4);  
 
 iLen = *iHstSofLen - SOF_MSGDATA_OFFS;
 memcpy(ucaTmpBuf,pucaHstSof+SOF_MSGDATA_OFFS,iLen);  


 iRtLen = HostSifConvt(ucaTmpBuf,ucaReinBuf,&iLen);
 
 if (iRtLen != 0)
 {
   sprintf(g_caMsg,"REINPUT code conversion error len=%d !",iRtLen);
   ErrLog(2000,g_caMsg,RPT_TO_LOG,0,0);
   UCP_TRACE_END(-1);
 }
   
 memcpy(ucaUnxSof+SOF_MSGDATA_OFFS,ucaReinBuf,iLen);  
 *iHstSofLen = iLen + SOF_MSGDATA_OFFS;
 memcpy( pucaHstSof, ucaUnxSof, *iHstSofLen );
 UCP_TRACE_END(0);
}
  
