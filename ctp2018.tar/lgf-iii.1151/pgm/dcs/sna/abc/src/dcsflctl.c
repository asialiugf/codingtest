#include <fcntl.h>
#include <errno.h>
#include <sys/ipc.h>
#include <sys/signal.h>
#include "errlog.h"
#include "msgqop.h"
#include "dcs.h"
#define  CONTROL_BYTE    25
#define  FORM_ID         9
#define  OUT_DEVICE      17
#define  STATUS_BYTE     25
#define  SIF_HEADER_LEN  51

#define  LAST_MSG_MASK   0x80
#define  TPEO_MSG_MASK   0x02
#define  ALIMENT         8
#define  DCSCMDOK        '0'
#define  TMS_AP_ABEND    '5'
#define  TPE_BR_ID       10
#define  TPE_TERM_ID     20

#define  P_TxnStart      67001
#define  P_DcsTpeo       1000
#define  P_GetQueueKey	 67002
#define  P_RcvFromQueue  67003

struct HostSof {
  int  iLen;
  unsigned char ucaData[ MAX_SOFLEN ];
};
static struct HostSof  staHostSof[ MAX_SOF ];

struct HostEj {
  int  iLen;
  unsigned char ucaData[ MAX_SOFLEN ];
};
static struct HostEj staHostEj[ MAX_SOF ];

struct Siof {
  char cDcsCmd;
  int  iSiofLen;
  unsigned char ucaSiofData[ MAX_SOFLEN ];
};


static unsigned char g_ucaUcpu[] = { 0xE4 , 0xC3, 0xD7, 0xE4 };/*"UCPU" ebcdic*/
static unsigned char g_ucaUcps[] = { 0xE4 , 0xC3, 0xD7, 0xE2 };/*"UCPS" ebcdic*/
static unsigned char g_ucaOK[]   = { 0xD6 , 0xD2 };            /*"OK"   ebcdic*/

static unsigned char g_ucaTpei[] = { 0xE3 , 0xD7, 0xC5, 0xC9 };/*"TPEI" ebcdic*/
static unsigned char g_ucaTpeo[] = { 0xE3 , 0xD7, 0xC5, 0xD6 };/*"TPEO" ebcdic*/
static unsigned char g_uca00[]   = { 0x00 };            /*0x00   ebcdic*/


static struct DcsSiof gs_stDcsSiof;
static struct DcsBuf  gs_stDcsBuf;

static int gs_iFirst=1;       /* first flage 0=no 1=yes          */
static int gs_iQueKey;
static int gs_iQuId;
static long gs_lWrQueType;
static long gs_lRdQueType;
static char gs_caTermId[TPE_TERM_LEN + 1];
static char gs_caBrId[TPE_BR_LEN + 1];
static char gs_caQueType[20];
static int gs_iSofDx=0;
static int gs_iEjDx=0;

extern int g_iTmin;
extern int g_iToffset;

/**********************************************************************
 *&N& ROUTINE NAME:TxnStart
 *&A& ARGUMENTS:pucaHostSif:SIF after format & code convertion
 *&A&           iHostSifLen:length of the SIF to be sent to the HOST 
 *&A&           pcRmtApFlg:record the status of the txn processing status
 *&A&           pucaTmpSif:SIF before format & code convertion
 *&R& RETURN VALUE(S):pcRmtApFlg:record the status of the txn processing status
 *&R& RETURN VALUE(S):0 -> normal end
 *&R&                -1 -> SIF FORMAT CONVERTION ERROR
 *&R&                -2 -> CODE CONVERTION ERROR
 *&R&                -3 -> GET SERVER NAME ERROR
 *&R&                -4 -> SEND SIF TO HOST ERROR
 *&R&                -5 -> RECEIVE SOF ERROR
 *&D& DESCRIPTION:
 *&D&
 **********************************************************************/
int
TxnStart(unsigned char *pucaHostSif, int  iHostSifLen, char *pcRmtApFlg,
        unsigned char *pucaTmpSif)
{
  int  iSofCnt=0;
  int  iRc,i;
  int iSiofLen = MAX_LEN;
  struct MsgBuf stMsgp;
  struct Siof stSiof;
  unsigned char ucaServName[4];
  unsigned char caTmpFile[10]; 

  UCP_TRACE(P_TxnStart);

  ErrLog(100,"TxnStart,Begin",RPT_TO_LOG,pucaHostSif,iHostSifLen);

  if(gs_iFirst){
    /* get the Queue key from the rmtquetbl */
    iRc = GetQueueKey(&gs_iQueKey);
    if(iRc != DCS_NORMAL){
      ErrLog(1000,"Get Que Key error",RPT_TO_LOG,0,0);
      UCP_TRACE_END(-4);  /* send SIF error */
    }
    /* Get the queue-id with the queue-key */
    iRc = MsqGet(&gs_iQuId,gs_iQueKey);
    if(iRc != MSGQ_NORMAL) {
      ErrLog(4000,"dcsflctl.c:Queue id get fail",RPT_TO_LOG,0,0);
      UCP_TRACE_END(-4);  /* send sif error */
    } 
    gs_iFirst = 0;
  }

  gs_iSofDx=0;
  gs_iEjDx=0;
  for( i=0;i< MAX_SOF;i++) {
    staHostSof[i].iLen = 0;
    memset(staHostSof[i].ucaData,0x00,MAX_SOFLEN);
  }

  /* determine the READ queue type & WRITE queue type */
  memset(&gs_caQueType[0],0x00,20);
  memcpy(gs_caQueType,&pucaTmpSif[TPE_BR_ID+3],TPE_BR_LEN);
  memcpy(&gs_caQueType[TPE_BR_LEN],&pucaTmpSif[TPE_TERM_ID],TPE_TERM_LEN);
  gs_lWrQueType = atol(gs_caQueType);
  gs_lRdQueType = gs_lWrQueType + 1000*10000;

  sprintf(g_caMsg,"gs_QueType=%s WR-TYPE=%d RD-TYPE=%d",gs_caQueType,
          (int)gs_lWrQueType,(int)gs_lRdQueType);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  MsqInit(gs_iQuId, gs_lRdQueType); /* clear the msg queue first */

  GetServName(ucaServName);

  /* send the Transaction data to HOST through CONNECT-&-WRITE DCS command */
  stSiof.cDcsCmd=DCSCONNECTWRITE;
  stSiof.iSiofLen=iHostSifLen;
  memset(stSiof.ucaSiofData,0x00,iHostSifLen); 
  memcpy(stSiof.ucaSiofData,pucaHostSif,iHostSifLen); 
  memcpy(stSiof.ucaSiofData, ucaServName, sizeof( g_ucaTpei ) );
  strcpy(caTmpFile,"tmpfile");
  iSiofLen = iHostSifLen + ALIMENT;
  stMsgp.lType=gs_lWrQueType;
  memcpy(stMsgp.caText,&stSiof,iSiofLen); 

  ErrLog(100,"CONNECT&WRITE:SIF=",RPT_TO_LOG,stMsgp.caText,iSiofLen);

  iRc = MsqWrite(gs_iQuId,iSiofLen,&stMsgp,IPC_NOWAIT,caTmpFile);

  if( iRc  != MSGQ_NORMAL ) {
    sprintf(g_caMsg,"TxnStart:Write TPEI(conn&wrt) to Queue error iRc=%d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-4);  /* send SIF error */
  }


  memset(&stMsgp,0x00,sizeof(struct MsgBuf) );

  iSiofLen = MAX_LEN;
  /* read the return code of CONNECT&WRITE-DCS-COMMAND from the QUEUE */
  iRc = RcvFromQueue(gs_iQuId,gs_lRdQueType,&iSiofLen,&stMsgp,
                     g_iTmin+g_iToffset);
  if ( iRc == MSGQ_NORMAL ) {
    memcpy(&stSiof,stMsgp.caText,iSiofLen); 
  }
  if( (iRc  != MSGQ_NORMAL) || (stSiof.cDcsCmd != DCSCMDOK) ) {
    sprintf(g_caMsg,"TxnStart:READ Queue error iRc=%d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    sprintf(g_caMsg,"TxnStart:Dcxdaemon(conn&wrt) return error Rc=%c",
            stSiof.cDcsCmd);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-4); /* send SIF error */
  }
  /* begin to read the txn output from the HOST */
  while(1) {   /* read the output msg untile the LAST-MSG-FLAG is on */
    stSiof.cDcsCmd=DCSREAD;
    stSiof.iSiofLen=sizeof(g_ucaTpeo);
    memset(stSiof.ucaSiofData, 0x00, sizeof( g_ucaTpeo ) );
    strcpy(caTmpFile,"tmpfile");
    iSiofLen = sizeof(g_ucaTpeo)+ ALIMENT;
    stMsgp.lType=gs_lWrQueType;
    memcpy(stMsgp.caText,&stSiof,iSiofLen); 
    iRc = MsqWrite(gs_iQuId,iSiofLen,&stMsgp,IPC_NOWAIT,caTmpFile);
    if( iRc  != MSGQ_NORMAL ) {
      sprintf(g_caMsg,"TxnStart:Write TPEI(rcv) to Queue error iRc=%d",iRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(-5);  /* RECEIVE SOF error */
    }
    iSiofLen = MAX_LEN;
    /* read the return code of READ-DCS-COMMAND from the QUEUE */
    iRc = RcvFromQueue(gs_iQuId,gs_lRdQueType,&iSiofLen,&stMsgp,
                       g_iTmin+g_iToffset);
    if ( iRc == MSGQ_NORMAL ) {
      memcpy(&stSiof,stMsgp.caText,iSiofLen); 
    }
    if( (iRc  != MSGQ_NORMAL) || (stSiof.cDcsCmd != DCSCMDOK) ) {
      sprintf(g_caMsg,"TxnStart:READ Queue error iRc=%d",iRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      sprintf(g_caMsg,"TxnStart:Dcxdaemon(read) return error Rc=%c",
              stSiof.cDcsCmd);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(-5);   /* receive SOF error */
    }
    if( iSiofLen >= 20 ) {
      staHostSof[ iSofCnt ].iLen  =  iSiofLen-ALIMENT;
      memcpy(staHostSof[iSofCnt].ucaData, stSiof.ucaSiofData, iSiofLen-ALIMENT);
      iSofCnt++; 
      sprintf(g_caMsg,"Read the TPEI return msg, SOFCNT=%d",iSofCnt);
      ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
      if( stSiof.ucaSiofData[CONTROL_BYTE] & LAST_MSG_MASK ) {
        if ( !( stSiof.ucaSiofData[CONTROL_BYTE] & TPEO_MSG_MASK ) ) {
          /* do not need to send the TPEO to the HOST */
          ErrLog(100,"Txn. Process error !!!",RPT_TO_LOG,0,0);
          UCP_TRACE_END(0);
        }
        else {
          if ( (iRc=DcsTpeo(iSofCnt,pucaHostSif,iHostSifLen)) != 0) {
            UCP_TRACE_END(-5);   /* receive SOF error */
          }
          else {
            UCP_TRACE_END(0);
          }
        }
      } /* for 'if( stSiof.ucaSiofData[CONTROL_BYTE] & LAST_MSG_MASK )' */
      else {
        continue;   /* continue to read the next output msg */
      }
    }
    else {
      ErrLog(1000,"AFTER CONNECT&WRITE, READ a SHORT MSG",RPT_TO_LOG,0,0);
      UCP_TRACE_END(-5);  /*receive a short message,it means a non-TPE msg*/
    } /* for 'if( iSiofLen >= 20)' */
  }  /* for while(1) */
  UCP_TRACE_END(0);
}


DcsTpeo(int iDx,unsigned char *pucaSif,int iSifLen)
{
  int    iRc,iTmpDx,iEjDx=0;
  int    iSiofLen;
  struct MsgBuf stMsgp;
  struct Siof stSiof;
  unsigned char caTmpFile[10]; 


  UCP_TRACE(P_DcsTpeo);
  stSiof.cDcsCmd=DCSCONNECTWRITE;
  /* mark by HWC, 96/06/25 */
  /* stSiof.iSiofLen=sizeof(g_ucaTpeo); */
  stSiof.iSiofLen=SIF_HEADER_LEN;
  memset(stSiof.ucaSiofData,0x00,iSifLen); 
  memcpy(stSiof.ucaSiofData,pucaSif,iSifLen); 
  memcpy(stSiof.ucaSiofData, g_ucaTpeo, sizeof( g_ucaTpeo ) );

  strcpy(caTmpFile,"tmpfile");

  iSiofLen = iSifLen + ALIMENT;

  stMsgp.lType=gs_lWrQueType;
  memcpy(stMsgp.caText,&stSiof,iSiofLen); 

  iRc = MsqWrite(gs_iQuId,iSiofLen,&stMsgp,IPC_NOWAIT,caTmpFile);

  if( iRc  != MSGQ_NORMAL ) {
    UCP_TRACE_END( MSGQ_ERROR );
  }


  iSiofLen = MAX_LEN;
  iRc = RcvFromQueue(gs_iQuId,gs_lRdQueType,&iSiofLen,&stMsgp,
                     g_iTmin+g_iToffset);

  if ( iRc== MSGQ_NORMAL ) {
    memcpy(&stSiof,stMsgp.caText,iSiofLen); 
  }

  if( (iRc  != MSGQ_NORMAL) || (stSiof.cDcsCmd != DCSCMDOK) ) {
    UCP_TRACE_END( MSGQ_ERROR );
  }

  ErrLog(100,"BEGIN TPEO",RPT_TO_LOG,0,0);

  do {
    stSiof.cDcsCmd=DCSREAD;
    stSiof.iSiofLen=sizeof(g_ucaTpeo);
    memcpy(stSiof.ucaSiofData, 0x00, sizeof( g_ucaTpeo ) );
    strcpy(caTmpFile,"tmpfile");
    iSiofLen = sizeof(g_ucaTpeo)+ ALIMENT;
    stMsgp.lType=gs_lWrQueType;
    memcpy(stMsgp.caText,&stSiof,iSiofLen); 
    iRc = MsqWrite(gs_iQuId,iSiofLen,&stMsgp,IPC_NOWAIT,caTmpFile);
    if( iRc  != MSGQ_NORMAL ) {
      UCP_TRACE_END( MSGQ_ERROR );
    }
    iSiofLen = MAX_LEN;
    iRc = RcvFromQueue(gs_iQuId,gs_lRdQueType,&iSiofLen,&stMsgp,
                       g_iTmin+g_iToffset);
    if ( iRc== MSGQ_NORMAL ) {
      memcpy(&stSiof,stMsgp.caText,iSiofLen); 
    }
/*
    ErrLog(100,"TPEO do while READ MSQ DATA",RPT_TO_LOG,&stSiof,iSiofLen);
*/
    if( (iRc  != MSGQ_NORMAL) || (stSiof.cDcsCmd != DCSCMDOK) ) {
      ErrLog(1000,"TPEO send error",RPT_TO_LOG,0,0);
      UCP_TRACE_END( MSGQ_ERROR );
    }

    if( iSiofLen >= ALIMENT  &&  iRc  == MSGQ_NORMAL ) {
      if( (unsigned char) stSiof.ucaSiofData[OUT_DEVICE]
           == (unsigned char) 0xf1 ) {  /*E.J. OUTPUT */
        staHostEj[ iEjDx ].iLen  =  iSiofLen-ALIMENT;
        memcpy( staHostEj[iEjDx].ucaData, stSiof.ucaSiofData, 
                iSiofLen-ALIMENT);
        iEjDx = iEjDx + 1 ;
        staHostSof[ iDx ].iLen  =  iSiofLen-ALIMENT ;
        memcpy( staHostSof[iDx].ucaData, stSiof.ucaSiofData, 
                iSiofLen-ALIMENT);
        iTmpDx = iDx;
        iDx++;
      }
      else {
        staHostSof[ iDx ].iLen  =  iSiofLen-ALIMENT ;
        memcpy( staHostSof[iDx].ucaData, stSiof.ucaSiofData, 
                iSiofLen-ALIMENT);
        iTmpDx = iDx;
        iDx++;
      } 

      /* ??? what situation will occure this kind of error ??? */
/* This if shall never be executed MARK begin 
      if( (unsigned char) stSiof.ucaSiofData[CONTROL_BYTE]
           == (unsigned char)0x88 ) {
        memcpy( staHostSof[iTmpDx].ucaData, "\x40\x40\xf1" ,3);
        ErrLog(100,"Rcv Host Sof ctl byte 88 ",RPT_TO_LOG,0,0);
        break;
      }
*/

      if( (unsigned char) stSiof.ucaSiofData[CONTROL_BYTE]
           != (unsigned char) LAST_MSG_MASK ) {
   /* Send the ACK. msg to the host TPE if the msg is not the last one */
        stSiof.cDcsCmd=DCSWRITE;
        stSiof.iSiofLen=sizeof(g_uca00);  /* send binary 0 to host for ACK */
        memcpy(stSiof.ucaSiofData, g_uca00, sizeof( g_uca00 ) );
        strcpy(caTmpFile,"tmpfile");
        iSiofLen = sizeof(g_uca00)+ ALIMENT;
        stMsgp.lType=gs_lWrQueType;
        memcpy(stMsgp.caText,&stSiof,iSiofLen); 

        ErrLog(100," WRITE 00",RPT_TO_LOG,stMsgp.caText,iSiofLen);

        iRc = MsqWrite(gs_iQuId,iSiofLen,&stMsgp,IPC_NOWAIT,caTmpFile);

        if( iRc  != MSGQ_NORMAL ) {
          UCP_TRACE_END( MSGQ_ERROR );
        }

        iSiofLen = MAX_LEN;
        iRc = RcvFromQueue(gs_iQuId,gs_lRdQueType,&iSiofLen,&stMsgp,
                           g_iTmin+g_iToffset);

        if ( iRc== MSGQ_NORMAL ) {
         memcpy(&stSiof,stMsgp.caText,iSiofLen); 
        }
/*
        ErrLog(100,"AFTER SEND 00, READ MSQ DATA",RPT_TO_LOG,&stSiof,iSiofLen);
*/
        if( (iRc  != MSGQ_NORMAL) || (stSiof.cDcsCmd != DCSCMDOK) ) {
            UCP_TRACE_END( MSGQ_ERROR );
        }
      }
      else { /* cntl mesg == 80 */
        /* using the last output-msg as the EJ data if AP doesn't send EJ */
        /* output.                                                        */
        if( iEjDx == 0 ) {
          staHostEj[ iEjDx ].iLen  =  iSiofLen-ALIMENT;
          memcpy( staHostEj[iEjDx].ucaData, stSiof.ucaSiofData, 
                  iSiofLen-ALIMENT);
          iEjDx++;
        }
        break;
      } /* for 'if( .. caSiofData[CONTROL_BYTE] != (unsigned char)0x80 ..'*/
    }
    else {
      UCP_TRACE_END(-5);   /* receive a short message */
    } /* for 'if( iSiofLen >= ALIMENT  &&  iRc  == MSGQ_NORMAL )' */
  } while( iRc  ==  DCS_NORMAL );

  UCP_TRACE_END(0);
}


int
GetHostSof(unsigned char *pucaSof,int *piLen)
{

  if( staHostSof[ gs_iSofDx ].iLen   == 0 ) {
    gs_iSofDx  =  0;
    *piLen  =   0;
    return( 0 );
  }
  *piLen  =   staHostSof[ gs_iSofDx ].iLen ;
  memcpy( pucaSof, staHostSof[ gs_iSofDx ].ucaData,
          staHostSof[gs_iSofDx ].iLen );
  gs_iSofDx++;
  return( 0 );
}


int
GetHostEj(unsigned char *pucaSof,int *piLen)
{

  if( staHostEj[ gs_iEjDx ].iLen   == 0x00 ) {
    gs_iEjDx  =  0;
    *piLen  =   0;
    return( 0 );
  }
  *piLen  =   staHostEj[ gs_iEjDx ].iLen ;
  memcpy( pucaSof, staHostEj[ gs_iEjDx ].ucaData, staHostEj[ gs_iEjDx ].iLen );
  gs_iEjDx++;
  return( 0 );
}

int
GetServName(char *pcaServName)
{
 memcpy(pcaServName,g_ucaTpei,4);
 return(0);
}

int
GetQueueKey(int *pgs_iQueKey)
{
  int i, iRc=0;
  char caFileName[80];
  /* for get data */
  char caDataType[5];
  long *plDataVar[5];
  /* input data variable for queuetbl */
  char caDesCode[20];
  long lQuSize;
  long lQuType;
  int iQuId;
  int iLastQuKey;	/* keep last queue key */
  FILE *pfQueFile;

  UCP_TRACE(P_GetQueueKey);
  ErrLog(100,"GetQueueKey Begin.",RPT_TO_LOG,0,0);
  
    /* get file name */
  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat(caFileName, DCS_TABLE_PATH);
  strcat(caFileName,"rmtquetbl");

    /* open file queue table */
  pfQueFile = fopen(caFileName,"rt");
  if( pfQueFile == NULL) {
    sprintf("GetQueueKey:fopen %s fail errno=%d",caFileName,errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(DCS_E_NETWORKTBL);
  }

  strcpy(caDataType,"sdD");
  plDataVar[0] = (long *)caDesCode;
  plDataVar[1] = pgs_iQueKey;
  plDataVar[2] = &lQuType;

  i = 0;
  iLastQuKey = -1;	/* initial iLastQuKey */ 
  lQuSize = -1;	/* initial iQuSize = 0 */
  while((iRc = GetFileData(pfQueFile,3,caDataType,plDataVar)) == 0){
    /* first record is queue size data */
    if (lQuSize < 0) {
      iRc = strncmp(caDesCode,"QUEUE_SIZE",10);
      if (iRc == 0) {
        lQuSize = lQuType;
      }
      else {	/* no queue size data error */
        fclose(pfQueFile);
        ErrLog(1000,"GetQueueKey: Queue Size no define error!",RPT_TO_LOG,0,0);
        UCP_TRACE_END(DCS_E_NETWORKTBL);
      } /* end of if(iRc == 0) -- else */
    }
    else {
      if((lQuSize > 0) && ((*pgs_iQueKey != iLastQuKey) ||
         (iLastQuKey == -1))){
        iLastQuKey = *pgs_iQueKey;
      } /* end of if((lQuSize > 0) && ((*pgs_iQueKey != iLastQuKey) ... */ 
    } /* end of if(lQuSize < 0) -- else */ 
  } /* end of while((iRc = GetFileData(3,caDataType,plDataVar)) == 0) */
  fclose(pfQueFile);
  ErrLog(100,"GetQueueKey End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}


extern int DcsQuNull();
int
RcvFromQueue(int iQuId,long lQuType,int *piSiofLen,struct MsgBuf *pstMsgBuf,
             int iTimeout)
{
  int iRc;

  UCP_TRACE(P_RcvFromQueue);
  /* marked 19960812 */
  /* signal(SIGALRM,DcsQuNull); */
  sprintf(g_caMsg,"RcvFromQueue: timeout=%d", iTimeout);
  ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
  alarm(iTimeout);
  iRc = MsqRead(iQuId,lQuType,piSiofLen,pstMsgBuf,0);
  /* if((iRc != MSGQ_NORMAL) || (errno == EINTR)){ */
  if( iRc != MSGQ_NORMAL ){
    alarm(0);
    ErrLog(1000,"RcvFromQueue:MsqRead fail",RPT_TO_LOG,0,0);
    MsqInit(iQuId, gs_lWrQueType);  /* remove the message sent before */
    UCP_TRACE_END(iRc);
  }
  alarm(0) ;

  UCP_TRACE_END(MSGQ_NORMAL);
}
