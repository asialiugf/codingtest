#include        <sys/types.h>
#include        <errno.h>
#include        <fcntl.h>
#include        <stdio.h>
#include        <malloc.h>

#include        "errlog.h"	/* error log include file */
#include        "dcs.h"		/* dcs api include file */
#include        "twa.h"		/* dcs api include file */
#include  "big2host.h"
#include  "dccpgdef.h" 

#define  USIF_HEAD_LEN               17
#define  SIF_HEAD_LEN                51
#define  STATUS                      25 
#define  USOF_HEAD_LEN               15
#define  START_PGM_ERR			-4
#define   SIFHEADLEN  51
#define   FILE_OVER  -9
#define FORMAT_CONV_ERROR  -1
#define CODE_CONV_ERROR    -2
#define GET_SERV_NAME_ERROR  -3
#define SND_SIF_TO_SERV_ERROR -4
#define RCV_SOF_FRM_SERV_ERROR -5
 
#define  OUTPT_PREFIX  "iii/log/output"


#define  _MAIN_PROGRAM 1

 char       *g_pcCtf;
 struct TMA *g_pstTma;
 struct TBA *g_pstTba;
 struct APA *g_pstApa;
 int    g_iBrhCodeLen;
 int    g_iTmCodeLen;

#ifdef OMIT

extern char       *g_pcCtf;
extern struct TMA *g_pstTma;
extern struct TBA *g_pstTba;
extern struct APA *g_pstApa;
extern int    g_iBrhCodeLen;
extern int    g_iTmCodeLen;

#endif

char g_cRcvRmtDataFlag; /* indicate rcv rmt data OK or not?     */

  struct PB_UCPSIF {
  char txn_code[4];
  char txt_id[4];
  char br_id[3];
  char tm_id[2];
  char tell_id[2];
  char line_no;
  char ctl_byte;
  char batlen[2];
  char lendata[511];
  } ;

  struct PB_TPESIF {
  char txn_code[4];
  char txt_id[6];
  char br_id[10];
  char tm_id[4];
  char tell_id[4];
  char user_data[20];
  char line_no;
  char ctl_byte[2];
  char lendata[469];
  } ;


  struct PB_UCPSOF {
  char fmh[3];
  char br_id[3];
  char tm_id[2];
  char out_dev;
  char form_id[4];
  char status;
  char ctl_byte;
  char lendata[505];
  } ;

  struct PB_TPESOF {
  char fmh[3];
  char br_id[10];
  char tm_id[4];
  char out_dev;
  char form_id[7];
  char status[2];
  char lendata[493];
  } ;


struct TpuSof {
  int  iLen;
  unsigned char ucaData[ SOF_SIZE ];
  };
struct TpuSof  g_staTpuSof[ MAX_SOF ];


struct TpuEj {
  int  iLen;
  unsigned char ucaData[ SOF_SIZE ];
  };
struct TpuEj  g_staTpuEj[ MAX_SOF ];


struct table_array cnv_tbl;
struct table_array *cnv_ptr;

extern struct DcsApi *g_pstDcsApi;
extern struct DcsBuf g_stDcsBuf;

static int   g_iSofTolCnt = 0;
static int   g_iEjTolCnt = 0;
static int   g_iReinput = 0;

static  FILE *g_pzSif;

main()
{
  int fp,iRc;
  int iTpeSifLen;
  int i, iFirst = 1;
  int iSifLen,iCnt = 0;
  unsigned char *caSifTmpBuf;
  char *pcRmtApFlg;
  char caSif[SIF_SIZE];
  char caLogName[256];


  sprintf(caLogName, "%s/iii/log/tms_errlog", getenv("III_DIR") );
  ChgLog(LOG_CHG_MODE,"1");
  ChgLog(LOG_CHG_LOG,caLogName);

#ifdef OMIT

printf("111\n");

  if( iFirst )
  {
    cnv_ptr  =  &cnv_tbl;
    Init_Cvt_Table(cnv_ptr);
    iFirst = 0;
  }

printf("222\n");
#endif


  caSifTmpBuf = malloc (SIF_SIZE);


#ifdef OMIT 

  if ( ( fp = open("sif1561new.dat",O_CREAT | O_RDONLY) ) == NULL ) {
    exit( -1 );
  }
  iTpeSifLen = read (fp,caSifTmpBuf,sizeof(struct PB_TPESIF));
  close ( fp ); 

    RmtProc(caSifTmpBuf,iTpeSifLen,pcRmtApFlg);

printf("333\n");

    for(i=0;i<g_iSofTolCnt;i++){
    ErrLog(1000,"RcvSofAll.dbpsof",RPT_TO_LOG,g_staTpuSof[i].ucaData,
             g_staTpuSof[i].iLen );
    }

#endif

#ifdef OMIT
  if((g_pzSif = fopen("/u/kbs01/KBS/ge2/lu/testsif.dat","r")) == NULL )
#endif

  if((g_pzSif = fopen("testsif.dat","r")) == NULL )
    {
      printf("open error\n");
    }


  while(1)
  {
    memset(caSif,0x00,sizeof(caSif));
    if(( iRc=crtsif(caSif,&iSifLen)) == FILE_OVER)
    { 
      printf("\n....file over\n");
      break;
    }
    ErrLog(1000,"main test sif data",RPT_TO_LOG,caSif,iSifLen);

    RmtProc(caSif,iSifLen,pcRmtApFlg);

printf("..........................DAO GOOD\n");

    for(i=0;i<g_iSofTolCnt;i++){
      sprintf(g_caMsg,"RcvSofAll dbp SofCnt %d",i);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,g_staTpuSof[i].ucaData,
                  g_staTpuSof[i].iLen );
    }

    for(i=0;i<g_iEjTolCnt;i++){
/*
      sprintf(g_caMsg,"RcvEjAll EjCnt %d",i);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,g_staTpuEj[i].ucaData,
                  g_staTpuEj[i].iLen );
*/
    }

  }

}




int
RmtProc(unsigned char *caSifTmpBuf,int iTpeSifLen,char *pcRmtApFlg)
{
  int i,iFd;
  int iRc;
  int iTpeTmpSifLen ;
  char   caFileName[80];
  unsigned char caSifBuf[ SIF_SIZE ];

#ifdef OMIT
  cnv_ptr  =  &cnv_tbl;
  if( CheckCvtTbl() )
  {
    ErrLog(1000,"SendSifToServ.Init_Cvt_Table",RPT_TO_LOG,0,0);
    Init_Cvt_Table(cnv_ptr);
  }
 #endif

  iTpeTmpSifLen = iTpeSifLen;
/*
  caSifTmpBuf = malloc (SIF_SIZE);
*/

  ErrLog(1000,"From Tpu Sif",RPT_TO_LOG,caSifTmpBuf,iTpeTmpSifLen);

  TpeToUcpSif(caSifTmpBuf, caSifBuf, &iTpeTmpSifLen);

  sprintf(g_caMsg,"xxxx SendSifToServ Ucp Sif Len %d",iTpeTmpSifLen);
  ErrLog(1000,g_caMsg,RPT_TO_LOG,caSifBuf,iTpeTmpSifLen);
  
  if( (iRc  =  DcsTpei(caSifBuf, iTpeTmpSifLen, pcRmtApFlg,caSifTmpBuf) ) < 0 )
  {
    sprintf(g_caMsg,"<RemoteTxn>: send data to RMT HOST error!");
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END( START_PGM_ERR );
  }
  else
    ErrLog(1000,"End DcsUcpu",RPT_TO_LOG,0,0);

  iRc = RcvSofAll(&g_iSofTolCnt);

  iRc = RcvEjAll(&g_iEjTolCnt);


  sprintf(caFileName,"%s/%s%.*s.%.*s",getenv("III_DIR"),OUTPT_PREFIX,
          g_iTmCodeLen, g_pstTma->stTSSA.caTmCode,
          g_iBrhCodeLen, g_pstTma->stTSSA.caBrCode);


  iFd = open("sof.dat",O_CREAT|O_TRUNC|O_RDWR,0660);
  if ( iFd < 0 ) {
      sprintf(g_caMsg,"<RcvHostDataToFile>: open File=sof.dat error!");
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      /* disconnect */
      UCP_TRACE_END(-1);
  }

  for(i=0;i<g_iSofTolCnt;i++){
      iRc = write(iFd,g_staTpuSof[i].ucaData,g_staTpuSof[i].iLen);
      if( iRc !=  g_staTpuSof[i].iLen ) {
        sprintf(g_caMsg,
        "write() sof error! write size=%d,write() rtn size=%d",
                g_staTpuSof[i].iLen,iRc);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END(-1);
      }
  }

  iRc = close(iFd);
  if ( iRc < 0 ) {
    sprintf(g_caMsg,"<RcvHostDataToFile>: close() File=sof.dat error!");
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  }

/*
  sprintf(caFileName,"%s/%s%.*s.%.*s",getenv("III_DIR"),OUTPT_PREFIX,
          g_iTmCodeLen, g_pstTma->stTSSA.caTmCode,
          g_iBrhCodeLen, g_pstTma->stTSSA.caBrCode);
*/


  iFd = open("ej.dat",O_CREAT|O_TRUNC|O_RDWR,0660);
  if ( iFd < 0 ) {
      sprintf(g_caMsg," open Ej File=ej.dat error");
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(-1);
  }

  for(i=0;i<g_iEjTolCnt;i++){
      iRc = write(iFd,g_staTpuEj[i].ucaData,g_staTpuEj[i].iLen);
      if( iRc !=  g_staTpuEj[i].iLen ) {
        sprintf(g_caMsg,
        "write() Ej error! write size=%d,write() rtn size=%d",
                g_staTpuEj[i].iLen,iRc);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END(-1);
      }
  }

  iRc = close(iFd);
  if ( iRc < 0 ) {
    sprintf(g_caMsg,"<RcvHostDataToFile>: close() File=ej.dat error!");
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  }

#ifdef OMIT
  sprintf(g_caMsg,"in SendSifToServ:iEjTolCnt=%d",g_iSofTolCnt);
  ErrLog(1000, g_caMsg, RPT_TO_LOG,0,0);
#endif

  return(iRc);

}




int
RcvSofAll(int *iSofCnt)
{
  int iDx=0;
  int iUcpSofLen = 33;
  unsigned char caSofTmpBuf[ SOF_SIZE ];
  unsigned char caSofBuf[ SOF_SIZE ];

#ifdef  OMIT
  caSofTmpBuf = malloc (SOF_SIZE);
  caSofBuf = malloc (SOF_SIZE);
#endif

  ErrLog(1000,"start RcvSofAll",RPT_TO_LOG,0,0);

  for( GetHostSof(caSofTmpBuf,&iUcpSofLen);
       iUcpSofLen > 0; GetHostSof(caSofTmpBuf,&iUcpSofLen))
  {
    memset(caSofBuf,0x00,iUcpSofLen);

    ErrLog(1000,"RcvSofAll() HostSof data",RPT_TO_LOG,caSofTmpBuf,iUcpSofLen);

    if(g_iReinput == 1)
    {
      TpeSofToTpuReinput(caSofTmpBuf, caSofBuf, &iUcpSofLen);
      g_iReinput = 0;
    }
    else
    {
      TpeSofToTpu(caSofTmpBuf, caSofBuf, &iUcpSofLen);
    }

    if( caSofTmpBuf[STATUS] == 0x22 )
        g_iReinput = 1;


    g_staTpuSof[ iDx ].iLen = iUcpSofLen;
    memcpy( g_staTpuSof[ iDx ].ucaData, caSofBuf, g_staTpuSof[ iDx ].iLen );

/*
    sprintf(g_caMsg,"RcvSofAll() iDx %d",iDx);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,
           g_staTpuSof[iDx].ucaData,g_staTpuSof[iDx].iLen);
*/
    iDx++;
  }

  *iSofCnt = iDx;  
  printf("\nRcv Sof All %d\n",*iSofCnt);

  return(0);

}


int
RcvEjAll(int *iEjCnt)
{
  int iDx=0;
  int iUcpEjLen = 33;
  unsigned char caSofTmpBuf[ SOF_SIZE ];
  unsigned char caSofBuf[ SOF_SIZE ];

  ErrLog(1000,"start RcvEjAll",RPT_TO_LOG,0,0);

  for( GetHostEj(caSofTmpBuf,&iUcpEjLen);
       iUcpEjLen > 0; GetHostEj(caSofTmpBuf,&iUcpEjLen))
  {
    memset(caSofBuf,0x00,iUcpEjLen);
/*
    ErrLog(1000,"RcvSofAll() HostSof data",RPT_TO_LOG,caSofTmpBuf,iUcpSofLen);
*/
    TpeSofToTpu(caSofTmpBuf, caSofBuf, &iUcpEjLen);

    g_staTpuEj[ iDx ].iLen = iUcpEjLen;
    memcpy( g_staTpuEj[ iDx ].ucaData, caSofBuf, g_staTpuEj[ iDx ].iLen );
    
    iDx++;
  }

  *iEjCnt = iDx;  

/*
  printf("\nRcv Ej All %d\n",*iEjCnt);
*/

  return(0);

}



int 
TpeToUcpSif(unsigned char *pcaTpeSif,unsigned char *pcaUcpSif, int *iSifLen)
{
  int iRc;
  int iTpeSifLen,iUcpSifLen;
  unsigned char caHostTpeSif[ MAX_LEN +8 ];
  unsigned char caHostUcpSif[ MAX_LEN +8 ];


  iTpeSifLen = *iSifLen; 

  if((iRc  =  Big5ToHostSif( pcaTpeSif, caHostTpeSif , &iTpeSifLen ))
      ==  DCS_NORMAL)
  {

    ErrLog(1000,"Tpe Sif ok ",RPT_TO_LOG,caHostTpeSif,iTpeSifLen);

  }
  else { 
    ErrLog(1000,"Tpe Sif error",RPT_TO_LOG,caHostTpeSif,iTpeSifLen);
    return ( CODE_CONV_ERROR);
  }

/* Add for TPE format */

  *iSifLen = iTpeSifLen;
  memcpy(pcaUcpSif,caHostTpeSif,iTpeSifLen);

/* end add */


#ifdef OMIT

  iUcpSifLen = iTpeSifLen;

  if((iRc  =  SifReFmt( caHostTpeSif , caHostUcpSif , &iUcpSifLen))
      ==  DCS_NORMAL)
  {
/*
    ErrLog(1000,"Ucp Sif ok",RPT_TO_LOG,caHostUcpSif,iUcpSifLen);
*/
  }
  else { 
    ErrLog(1000,"Ucp Sif error",RPT_TO_LOG,caHostUcpSif,iUcpSifLen);
    return ( FORMAT_CONV_ERROR);
  }  
/* 
  ErrLog(1000,"zzz after SifReFmt",RPT_TO_LOG,caHostUcpSif,iUcpSifLen+5);
*/

  *iSifLen = iUcpSifLen;
  memcpy(pcaUcpSif,caHostUcpSif,iUcpSifLen);

#endif

  return(0);

} 



int 
TpeSofToTpu(char *pcaUcpSof,char *pcaTpeSof, int *iSofLen)
{
int iRc;
int iTpeSofLen,iUcpSofLen;
unsigned char caHostTpeSof[ MAX_LEN +8 ];
unsigned char caHostUcpSof[ MAX_LEN +8 ];


#ifdef OMIT

  iUcpSofLen = *iSofLen; 

  if((iRc  =  SofReFmt( pcaUcpSof , caHostTpeSof , &iUcpSofLen))
      ==  DCS_NORMAL)
  {

    ErrLog(1000,"Tpe Sof refmt ebcdic ok ",RPT_TO_LOG,caHostTpeSof,iUcpSofLen);

  }
  else { 
    ErrLog(1000,"Tpe Sof refmt error",RPT_TO_LOG,caHostTpeSof,iUcpSofLen);
    return ( FORMAT_CONV_ERROR);
  }  

#endif


  iTpeSofLen = *iSofLen;

  memcpy(pcaTpeSof,pcaUcpSof,iTpeSofLen);

  if((iRc  =  HostToBig5Sof( pcaTpeSof , &iTpeSofLen ))
      ==  DCS_NORMAL)
  {
    *iSofLen = iTpeSofLen;

    sprintf(g_caMsg,"HostToBig5Sof() iTpeSofLen %d ",iTpeSofLen);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,pcaTpeSof,iTpeSofLen);

  }
  else { 
    ErrLog(1000,"Tpu Tpe Sof error",RPT_TO_LOG,pcaTpeSof,iTpeSofLen);
    return ( CODE_CONV_ERROR);
  }

  return(0);
} 





#ifdef OMIT

int 
TpeToUcpSif(unsigned char *pcaTpeSif,unsigned char *pcaUcpSif, int *iSifLen)
{
  int iRc;
  int iTpeSifLen,iUcpSifLen;
  unsigned char caHostTpeSif[ MAX_LEN +8 ];
  unsigned char caHostUcpSif[ MAX_LEN +8 ];


  iTpeSifLen = *iSifLen; 

  if((iRc  =  Big5ToHostSif( pcaTpeSif, caHostTpeSif , &iTpeSifLen ))
      ==  DCS_NORMAL)
  {
/*
    ErrLog(1000,"Tpe Sif ok ",RPT_TO_LOG,caHostTpeSif,iTpeSifLen);
*/
  }
  else { 
    ErrLog(1000,"Tpe Sif error",RPT_TO_LOG,caHostTpeSif,iTpeSifLen);
  }


  iUcpSifLen = iTpeSifLen;
/*
  ErrLog(1000,"yyy before SifReFmt",RPT_TO_LOG,caHostTpeSif,iUcpSifLen+5);
*/
  if((iRc  =  SifReFmt( caHostTpeSif , caHostUcpSif , &iUcpSifLen))
      ==  DCS_NORMAL)
  {
/*
    ErrLog(1000,"Ucp Sif ok",RPT_TO_LOG,caHostUcpSif,iUcpSifLen);
*/
  }
  else { 
    ErrLog(1000,"Ucp Sif error",RPT_TO_LOG,caHostUcpSif,iUcpSifLen);
  }  
/* 
  ErrLog(1000,"zzz after SifReFmt",RPT_TO_LOG,caHostUcpSif,iUcpSifLen+5);
*/

  *iSifLen = iUcpSifLen;
  memcpy(pcaUcpSif,caHostUcpSif,iUcpSifLen);

return(0);

} 



int 
TpeSofToTpu(char *pcaUcpSof,char *pcaTpeSof, int *iSofLen)
{
int iRc;
int iTpeSofLen,iUcpSofLen;
unsigned char caHostTpeSof[ MAX_LEN +8 ];
unsigned char caHostUcpSof[ MAX_LEN +8 ];

  iUcpSofLen = *iSofLen; 

  if((iRc  =  SofReFmt( pcaUcpSof , caHostTpeSof , &iUcpSofLen))
      ==  DCS_NORMAL)
  {

    ErrLog(1000,"Tpe Sof refmt ebcdic ok ",RPT_TO_LOG,caHostTpeSof,iUcpSofLen);

  }
  else { 
    ErrLog(1000,"Tpe Sof refmt error",RPT_TO_LOG,caHostTpeSof,iUcpSofLen);
  }  


  iTpeSofLen = iUcpSofLen;

  memcpy(pcaTpeSof,caHostTpeSof,iTpeSofLen);

  if((iRc  =  HostToBig5Sof( pcaTpeSof , &iTpeSofLen ))
      ==  DCS_NORMAL)
  {

    *iSofLen = iTpeSofLen;

    sprintf(g_caMsg,"HostToBig5Sof() iTpeSofLen %d ",iTpeSofLen);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,caHostTpeSof,iTpeSofLen);

  }
  else { 
    ErrLog(1000,"Tpu Tpe Sof error",RPT_TO_LOG,caHostTpeSof,iTpeSofLen);
  }

/*
  *iSofLen = iTpeSofLen;
  memcpy(pcaTpeSof,caHostTpeSof,iTpeSofLen);
*/
return(0);

} 

#endif



int 
TpeSofToTpuReinput(char *pcaUcpSof,char *pcaTpeSof, int *iSofLen)
{
int iRc;
int iTpeSofLen,iUcpSofLen;
unsigned char caHostTpeSof[ MAX_LEN +8 ];
unsigned char caHostUcpSof[ MAX_LEN +8 ];


#ifdef OMIT

  iUcpSofLen = *iSofLen; 

  if((iRc  =  SofReFmt( pcaUcpSof , caHostTpeSof , &iUcpSofLen))
      ==  DCS_NORMAL)
  {

    ErrLog(1000,"Tpe Sof refmt ebcdic ok ",RPT_TO_LOG,caHostTpeSof,iUcpSofLen);

  }
  else { 
    ErrLog(1000,"Tpe Sof refmt error",RPT_TO_LOG,caHostTpeSof,iUcpSofLen);
    return ( FORMAT_CONV_ERROR);
  }  

#endif


  iTpeSofLen = *iSofLen;

  memcpy(pcaTpeSof,pcaUcpSof,iTpeSofLen);

  if((iRc  =  HostToGbRein( pcaTpeSof , &iTpeSofLen ))
      ==  DCS_NORMAL)
  {
    *iSofLen = iTpeSofLen;

    sprintf(g_caMsg,"HostToBig5Sof() iTpeSofLen %d ",iTpeSofLen);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,pcaTpeSof,iTpeSofLen);

  }
  else { 
    ErrLog(1000,"Tpu Tpe Sof error",RPT_TO_LOG,pcaTpeSof,iTpeSofLen);
    return ( CODE_CONV_ERROR);
  }

  return(0);
} 




int
SifReFmt(struct PB_TPESIF *pstHostTpeSif,struct PB_UCPSIF *pstHostUcpSif,
         int *iSifLen)
{
int iRc,i;

  memcpy(pstHostUcpSif->txn_code,pstHostTpeSif->txn_code,4);
  memcpy(pstHostUcpSif->txt_id,pstHostTpeSif->txt_id,4);
  memcpy(pstHostUcpSif->br_id,pstHostTpeSif->br_id,3);
  memcpy(pstHostUcpSif->tm_id,pstHostTpeSif->tm_id,2);
  memcpy(pstHostUcpSif->tell_id,pstHostTpeSif->tell_id,2);
  pstHostUcpSif->line_no = pstHostTpeSif->line_no;
  pstHostUcpSif->ctl_byte = pstHostTpeSif->ctl_byte[0];

  if( (i=*iSifLen-SIF_HEAD_LEN) > 0){
    memset(pstHostUcpSif->batlen,0x00,2);
    memcpy(pstHostUcpSif->lendata,pstHostTpeSif->lendata,
           *iSifLen-SIF_HEAD_LEN);
    *iSifLen = *iSifLen-(SIF_HEAD_LEN - USIF_HEAD_LEN - 2); 
  } else
  {
    memset(pstHostUcpSif->batlen,0x00,2);
    *iSifLen = *iSifLen-(SIF_HEAD_LEN - USIF_HEAD_LEN - 2); 
  }

  return (DCS_NORMAL);
}


int
SofReFmt(struct PB_UCPSOF *pstHostUcpSof,struct PB_TPESOF *pstHostTpeSof,
         int *iSofLen)
{
int iRc;
int i;

  memset(pstHostTpeSof,0x00,*iSofLen+12);

  memcpy(pstHostTpeSof->fmh,pstHostUcpSof->fmh,3);
  memcpy(pstHostTpeSof->br_id,pstHostUcpSof->br_id,3);
  memcpy(pstHostTpeSof->tm_id,pstHostUcpSof->tm_id,2);
  pstHostTpeSof->out_dev = pstHostUcpSof->out_dev;
  memcpy(pstHostTpeSof->form_id,pstHostUcpSof->form_id,4);
  pstHostTpeSof->status[0] = pstHostUcpSof->status;

if((i=*iSofLen-USOF_HEAD_LEN) > 0)
  memcpy(pstHostTpeSof->lendata,pstHostUcpSof->lendata,*iSofLen-USOF_HEAD_LEN);

  *iSofLen = *iSofLen+12; 

  return (DCS_NORMAL);
}

int  CheckCvtTbl()
{
unsigned char caBigWord[8];
unsigned char caHstWord[8];
int      iRc, iLen;

  caBigWord[0] = 0xb1;
  caBigWord[1] = 0x69;
  caHstWord[0] = 0xb1;
  caHstWord[1] = 0x69;

  big5_host( caBigWord, caHstWord,2,cnv_ptr);

  if( (unsigned char)caHstWord[1] == (unsigned char)0x57 &&
       (unsigned char)caHstWord[2] == (unsigned char)0x4f )
    return(0);
  return( -1 );
}


int
crtsif(char *pcSif, int *iSifLen)
{
  int iRc;
  int iOffset=0;
  short sDataLen;
  char caTmp[300];
  char caTmp2[50];
  char *pcTmp;
  struct PB_TPESIF stSif;

  pcTmp = malloc(100);
  memset(&stSif,0x30,sizeof(struct PB_TPESIF));

  while(1)
  {
    if ((pcTmp = fgets(caTmp,sizeof(caTmp),g_pzSif)) == NULL){
	fclose(g_pzSif);
	printf("total component missing in entry \n");
  	return(-1);
    }

    pcTmp = strtok(caTmp, " |\t") ;

    if( strncmp(pcTmp,"###",3) == 0)  {
      fclose(g_pzSif);
      return(FILE_OVER);
    }

    if( strncmp(pcTmp,"#",1) == 0)  continue;

    if( strncmp(pcTmp,"%",1) == 0){

      iOffset=0;

  printf("\n");
      pcTmp = strtok(NULL, " |\t") ;
  printf("%s ",pcTmp);
      memcpy(stSif.txn_code,pcTmp,strlen(pcTmp));

      pcTmp = strtok(NULL, " |\t") ;
  printf("%s ",pcTmp);
      memcpy(stSif.txt_id,pcTmp,strlen(pcTmp));

      pcTmp = strtok(NULL, " |\t") ;
  printf("%s ",pcTmp);
      memcpy(stSif.br_id,pcTmp,strlen(pcTmp));

      pcTmp = strtok(NULL, " |\t") ;
  printf("%s ",pcTmp);
      memcpy(stSif.tm_id,pcTmp,strlen(pcTmp));

      pcTmp = strtok(NULL, " |\t") ;
  printf("%s ",pcTmp);
      memcpy(stSif.tell_id,pcTmp,strlen(pcTmp));

      pcTmp = strtok(NULL, " |\t") ;
  printf("%s ",pcTmp);
      memcpy(stSif.user_data,pcTmp,strlen(pcTmp));

      pcTmp = strtok(NULL, " |\t") ;

      if( strncmp(pcTmp,"0",1) == 0){
        stSif.line_no = 0x00;
      }
      else
        stSif.line_no = pcTmp[0];
    
  printf("%c ",stSif.line_no);

      pcTmp = strtok(NULL, " |\t") ;

      if( strncmp(pcTmp,"sb",2) == 0){
        memcpy(stSif.ctl_byte,"\x18\x00",2);
      }
      else if( strncmp(pcTmp,"*b",2) == 0){
        memcpy(stSif.ctl_byte,"\x08\x00",2);
      }
      else if( strncmp(pcTmp,"s*",2) == 0){
        memcpy(stSif.ctl_byte,"\x10\x00",2);
      }
      else {
        memcpy(stSif.ctl_byte,"\x00\x00",2);
      }

      memcpy(caTmp2,stSif.ctl_byte,2);
  printf("%s ",caTmp2);


      while( strncmp(pcTmp,"@",1) != 0 )
      {
        pcTmp = strtok(NULL, " |\t") ;

        if( strncmp(pcTmp,"@",1) != 0 )
        {
          sDataLen = strlen(pcTmp);
    printf("%s ",pcTmp);
          memcpy(&stSif.lendata[iOffset],&sDataLen,2);
          iOffset =iOffset + 2;
          memcpy(&stSif.lendata[iOffset],pcTmp,strlen(pcTmp) );
          iOffset =iOffset + strlen(pcTmp);
        }
      } 

      *iSifLen = iOffset + SIF_HEAD_LEN ; 
      memcpy(pcSif,&stSif,*iSifLen);
/*
      ErrLog(1000,"test sif data",RPT_TO_LOG,&stSif,*iSifLen);
*/
      return(0);
   }

  } 

}

