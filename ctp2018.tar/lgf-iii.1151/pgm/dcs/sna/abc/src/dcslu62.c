
//#include <cmc.h>                /* CPI-C external definitions           */
#include <errno.h>              /* global error numbers                 */
#include <fcntl.h>              /* for using file permissions           */
#include <signal.h>             /* for using signal handler             */
#include <stdio.h>              /* for using printf command             */
#include <string.h>             /* for using strcpy, strcat commands    */
#include <malloc.h>             /* for using malloc command             */
#include <sys/types.h>
#include <sys/signal.h>
#include "errlog.h"
#include "dcs.h"
#include "rabbit.h"
#include "pimLU62.h"
#include "pimCOPR.h"
#include "cmcconst.h"

#define MAX_LISTEN 5
#define MAX_NETWKTBL_ARRAY 30

#define SYMMAX          9               /* maxlen of sym dest name +1  */
#define FILEMAX         80              /* arbitrary max file name len */
#define BUFFERLEN       80              /* arbitrary max data rcv len  */
#define CONV_ID_LEN     8               /* length of conv id area      */
#define SENDMAX         32000           /* max # of bytes to send      */
#define CICSMAP_NUMBER   51

struct CicsMap {
    char caBusiCode[3];
    char caCicsCode[3];
    char caRluCode[9];
} stCicsMapTbl[CICSMAP_NUMBER];

static int g_iCicsMapNum=-1;

struct Lu62Sess {
  unsigned char ucaConverId[CONV_ID_LEN];
  char cStatus;
  char cMode;
};

struct Lu62Netwk {
  char caDesCode[SYMMAX];
  char caField[2][20];
};


#define P_DcsLUAccept                 52001
#define P_DcsLUConnect                52002
#define P_DcsLUDisconnect             52003
#define P_DcsLUInitial                52004
#define P_DcsLUNull                   52005
#define P_DcsLUReceive                52006
#define P_DcsLUSend                   52007
#define P_DcsLUTerminate              52008
#define P_DcsLU                       52009
#define P_GetHostServName               52010
#define P_LoadLu62NetwkTbl              52011
#define P_SrhLu62NetwkTbl               52012

/* -------------------- STATIC GLOBAL DECLARATION ------------------- */
static int gs_iFirst=1; /* first flage 1=yes 0=no          */
static int gs_iResiLu62Id; /* socket id form resident passive, call dcs_initial */
static int gs_iMaxLoad;

struct servent *pstServEnt;
struct hostent *pstHostEnt;
struct Lu62Sess g_stLu62SesTbl[MAX_SESS];
struct Lu62Netwk g_stLu62NetTbl[MAX_NETWKTBL_ARRAY];

/* ------ CALL FUNCTION & SUBROUTINE PROTOTYPE DECLARATIONS --------- */
int DcsLU(struct DcsBuf *pstDcsBuf);
int DcsLUInitial(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess,
                   char cMode);
int DcsLUConnect(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess);
int DcsLUAccept(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess);
int DcsLUSend(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess);
int DcsLUReceive(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess);
int DcsLUDisconnect(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess);
int DcsLUTerminate(struct DcsBuf *pstDcsBuf);
int GetHostServName(char *pcDesCode,char *pcHostName,char *pcServName);
int SrhLu62NetwkTbl(char *pcDesCode,struct Lu62Netwk *pstNetTbl);
int LoadLu62NetwkTbl(struct Lu62Netwk *pstNetTbl);
int GetCicsMap();
int SrhCicsMap(char *pcaBusiCode, char *pcaCicsCode, char *pcaRluCode);
int HostToBig5(char *pcaHstData, char *pcaUnxData);
void DcsLUNull();


CM_PREPARE_TO_RECEIVE_TYPE      g_lPrepareType; /* prep to receive type */
CM_RECEIVE_TYPE                 g_lReceiveType; /* receive type         */
CM_REQUEST_TO_SEND_RECEIVED     g_lReqToSend;   /* req to send indicator*/
CM_SYNC_LEVEL                   g_lSyncLevel;   /* sync level for conv  */
CM_SEND_TYPE                    g_lSendType;    /* send type            */
CM_INT32                        g_lLength;      /* data length          */
CM_INT32                        g_lReceivedLength;/* how much data rcvd   */
CM_STATUS_RECEIVED              g_lStatusReceived;/* status from remote   */
CM_DATA_RECEIVED_TYPE           g_lDataReceived;  /* was of data rcvd?   */
CM_DEALLOCATE_TYPE              g_lDeallocateType;/* type of deallocate   */

CM_INT32                        g_lSecurType;
CM_INT32                        g_lSecurPasswdLen;
CM_INT32                        g_lSecurUseridLen;
/* marked on 19960813, do not use malloc() for them
unsigned char *                 g_ucaSecurUserid;
unsigned char *                 g_ucaSecurPasswd;
unsigned char *                 g_ucaTpName;
*/
unsigned char                  g_ucaSecurUserid[5];
unsigned char                  g_ucaSecurPasswd[5];
unsigned char                  g_ucaTpName[20];
CM_INT32                        g_lTpNameLen;

static unsigned char                    g_ucaConverId[CONV_ID_LEN];

PIP_Var     pimPIP;                 /* pip block         */
LU62_PIM_CB  pimCB;
COPR_PIM_CB  CtlBlk;
char        mapname[256];
int         status=0;

/* modified by YEN 950630 */
/* for abc
*/
static  char  lluname[80]={' ',' '};
static  char  rluname[80]={' ',' '};
static  char  modename[80]={' ',' '};

/* for III
static  char  lluname[]={"LLU2"};
static  char  rluname[]={"RLU1"};
static  char  modename[]={"LU62"};
*/

int isspace(char ch)
{
    if ( ch == ' ' )
        return TRUE;
    else
        return FALSE;
}

int
DcsLU(struct DcsBuf *pstDcsBuf)
{
  int iRc;
  struct Lu62Sess *pstSess;
  static struct Lu62Sess stAryPreviousSess[MAX_SESS];
  static struct DcsBuf   stPreviousBuf;
  static struct Lu62Sess *pstPreviousSess;
  static int connect_ok = 0;
  
  pstPreviousSess = stAryPreviousSess;
  g_lStatusReceived = CM_NO_STATUS_RECEIVED;
  g_lDataReceived = CM_NO_DATA_RECEIVED;
  g_lReqToSend = CM_REQ_TO_SEND_NOT_RECEIVED;

  UCP_TRACE(P_DcsLU);
  ErrLog(10,"DcsLU:begin",RPT_TO_LOG,0,0);
  pstSess = g_stLu62SesTbl;
  iRc = 0;


  /* because g_iCicsMapNum is initialized to -1,
     GetCicsMap() will be executed only once.
   */
  GetCicsMap();

  switch (PcRqstCode(pstDcsBuf)){
   case DCSINITIAL:
     if(gs_iFirst){
       iRc = DcsLUInitial(pstDcsBuf,pstSess,'A');
       if(iRc != DCS_NORMAL){
         break;
       }
       gs_iFirst = 0;
     }
     break;
   case DCSCONNECT:
     /* do DcsLUInitial when FIRST */
     if(gs_iFirst){
       iRc = DcsLUInitial(pstDcsBuf,pstSess,'A');
       if(iRc != DCS_NORMAL){
         break;
       }
       gs_iFirst = 0;
     }
     iRc = DcsLUConnect(pstDcsBuf,pstSess);
     break;
   case DCSACCEPT:
     /* do DcsLUInitial when FIRST */
     if(gs_iFirst){
       iRc = DcsLUInitial(pstDcsBuf,pstSess,'P');
       if(iRc != DCS_NORMAL){
         break;
       }
       gs_iFirst = 0;
     }
     iRc = DcsLUAccept(pstDcsBuf,pstSess);
     break;
   case DCSCONNECTWRITE:
     /* do DcsLUInitial when FIRST */

/* for abc
     if(gs_iFirst){
       iRc = DcsLUInitial(pstDcsBuf,pstSess,'A');
       if(iRc != DCS_NORMAL){
         break;
       }
       gs_iFirst = 0;
     }
*/
     /* if connect ok last time, then 
        DISCONNECT it before connect a new one */
     if (connect_ok) {
       ErrLog(10,">>>> Do DcsLUDisconnect before DcsLUInitial.",
	      RPT_TO_LOG,0,0);
       DcsLUDisconnect(&stPreviousBuf,pstPreviousSess);
     }

     ErrLog(10,">>>> DcsLUInitial start ",RPT_TO_LOG,0,0);

     iRc = DcsLUInitial(pstDcsBuf,pstSess,'A');
     if(iRc != DCS_NORMAL){
       break;
     }
 
     ErrLog(10,">>>> DcsLUConnect start ",RPT_TO_LOG,0,0);

     iRc = DcsLUConnect(pstDcsBuf,pstSess);
     if(iRc != DCS_NORMAL){
       connect_ok = 0;
       break;
     } else {
       connect_ok = 1;
       memcpy((char *)pstPreviousSess, (char *)pstSess,
	      sizeof(struct Lu62Sess)*MAX_SESS);
       memcpy((char *)&stPreviousBuf, (char *)pstDcsBuf,
	      sizeof(struct DcsBuf));
     }

     ErrLog(10,">>>> DcsLUSend start ",RPT_TO_LOG,0,0);

     iRc = DcsLUSend(pstDcsBuf,pstSess);

     ErrLog(10,">>>> DcsLUSend end ",RPT_TO_LOG,0,0);
     break;
   case DCSWRITE:
     iRc = DcsLUSend(pstDcsBuf,pstSess);
     break;
   case DCSWRDISCONECT:
     iRc = DcsLUSend(pstDcsBuf,pstSess);
     if(iRc == DCS_NORMAL){
       iRc = DcsLUDisconnect(pstDcsBuf,pstSess);
     }
     break;
   case DCSACCEPTREAD:
     /* do DcsLUInitial when FIRST */
     if(gs_iFirst){
       iRc = DcsLUInitial(pstDcsBuf,pstSess,'P');
       if(iRc != DCS_NORMAL){
         break;
       }
       gs_iFirst = 0;
     }
     iRc = DcsLUAccept(pstDcsBuf,pstSess);
     if(iRc != DCS_NORMAL){
       break;
     }
     iRc = DcsLUReceive(pstDcsBuf,pstSess);
     break;
   case DCSREAD:
     iRc = DcsLUReceive(pstDcsBuf,pstSess);
     break;
   case DCSDISCONNECT:
     iRc = DcsLUDisconnect(pstDcsBuf,pstSess);
     break;
   case DCSTERMINATE:
     iRc = DcsLUTerminate(pstDcsBuf);
     break;
   default:
     sprintf(g_caMsg,"DcsLU:reguest error[%c]",PcRqstCode(pstDcsBuf));
     ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
     iRc = DCS_E_COMMAND;
     break;
  } /* end switch */

  PiReply(pstDcsBuf) = iRc;
  UCP_TRACE_END(iRc);
} /* end of sbdbs */

static int CoprShutD()
{
   printf("\nSystem shutdown detected -- exiting\n");
   exit(1);
}

int
DcsLUInitial(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess,char cMode)
{
  CM_RETURN_CODE  iCmRc=CM_OK;      /* ret code from CPI-C  */
  char  caSysDestName[SYMMAX];  /* symbolic name*/
  int iIdx;
  int iLu62Id;
  int iRc;
  struct Lu62Netwk *pstNetTbl;
  char caServName[20];
  char caHostName[20];    /* for socket dcs */

  UCP_TRACE(P_DcsLUInitial);
  ErrLog(10,"DcsLUInitial Begin.",RPT_TO_LOG,0,0);
#ifdef PETER
  pstNetTbl = g_stLu62NetTbl;
  iRc = LoadLu62NetwkTbl(pstNetTbl);
  if(iRc != 0){
    ErrLog(10000,"DcsLUInitial:load network table error",RPT_TO_LOG,0,0);
    PiErrno(pstDcsBuf) = iRc;
    UCP_TRACE_END(DCS_E_NETWORKTBL);
  }
  ErrLog(10,"DcsLUInitial:load network table ok!!",RPT_TO_LOG,0,0);
#endif


  for(iIdx=0; iIdx<MAX_SESS; iIdx++){
    memset(&pstSess[iIdx], 0x00 , sizeof(struct Lu62Sess) );
    pstSess[iIdx].cStatus = DCS_S_FREE ;
    strcpy(pstSess[iIdx].ucaConverId,"0000000");
  }

  memset(g_ucaConverId,0x00,8);


  if(cMode == PASSIVE_MODE) {
    ErrLog(10,"DcsLUInitial:ok.",RPT_TO_LOG,0,0);
    UCP_TRACE_END(DCS_NORMAL);
  }
#ifdef PETER
  GetHostServName(PcaDesCode(pstDcsBuf),caHostName,caServName);
  strcpy(caSysDestName, caHostName);
#endif
  ErrLog(10,"cminit ucaConverId",RPT_TO_LOG,g_ucaConverId,8);

  if (iCmRc != CM_OK)
    {
      sprintf(g_caMsg,"DcsSkInitial(cminit):lu62 fail, errno=[%d]",(int)iCmRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
    }
  g_lSyncLevel = CM_NONE;

  if (iCmRc != CM_OK)
    {
      sprintf(g_caMsg,"DcsSkInitial(cmssl):lu62 fail, errno=[%d]",(int)iCmRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
    }
   
  g_lReceiveType = CM_RECEIVE_AND_WAIT;

  if (iCmRc != CM_OK)
    {
      sprintf(g_caMsg,"DcsSkInitial(cmsrt):lu62 fail, errno=[%d]",(int)iCmRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
    }
 
  g_lPrepareType = CM_PREP_TO_RECEIVE_FLUSH;

  if (iCmRc != CM_OK)
    {
      sprintf(g_caMsg,"DcsSkInitial(cmsptr):lu62 fail, errno=[%d]",(int)iCmRc );
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
    }


  g_lSendType = CM_SEND_AND_PREP_TO_RECEIVE;

  if (iCmRc != CM_OK)
    {
      sprintf(g_caMsg,"DcsLUSend(cmsst):write fail, errno=[%d]",iCmRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstSess[iIdx].cStatus = DCS_S_ERROR;
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iRc);
    }


      /********************************************************/

  g_lSecurType = XC_SECURITY_PROGRAM;
  
  if (iCmRc != CM_OK)
    {
      sprintf(g_caMsg,"DcsSkInitial(xcscst):lu62 fail, errno=[%d]",(int)iCmRc );
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
    }


  /* g_ucaSecurUserid = malloc(5); */
  g_lSecurUseridLen = 4;
  strcpy(g_ucaSecurUserid,"LIAN");
  
  if (iCmRc != CM_OK)
    {
      sprintf(g_caMsg,"DcsSkInitial(xcscsu):lu62 fail, errno=[%d]",(int)iCmRc );
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
    }

  /* g_ucaSecurPasswd = malloc(5); */
  g_lSecurPasswdLen = 4;
  strcpy(g_ucaSecurPasswd,"LIAN");
  
  if (iCmRc != CM_OK)
    {
      sprintf(g_caMsg,"DcsSkInitial(xcscsp):lu62 fail, errno=[%d]",(int)iCmRc );
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
    }

   /* g_ucaTpName = malloc(20); */
   g_lTpNameLen = 19;

   /* marked on 19960813, since caServName is useless
      and this statement may cause problem:
      strcpy from a non-initialized variable!!!!!!
    */ 
   /* strcpy(g_ucaTpName,caServName); */
   
   if (iCmRc != CM_OK)
    {
      sprintf(g_caMsg,"DcsSkInitial(xcstpn):lu62 fail, errno=[%d]",(int)iCmRc );
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
    } 

  DetachLU62();
  iRc = AttachLU62(0, pNULL, NULLRES, &pimCB, atFOREGND,
            shNULLFUNC, pNULL);
  sprintf(g_caMsg,"AttachLu62 iRc = %d ",iRc);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);

  iCmRc = pimCB.RetCode;

  ErrLog(10,"DcsLUInitial:End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}



int
DcsLUConnect(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess)
{
  CM_RETURN_CODE  iCmRc=CM_OK;      /* ret code from CPI-C  */
  int iRc;
  int iIdx;
  int iLu62Id;
  int iTermPt;
  char caServName[20];
  char caCicsName[20];
  char caHostName[20];    /* for socket dcs */
  char cTermUnix[4];
  char cTermCics[4];
  char cBrhCics[10];
  char cBrhUnix[10];
  static char caProLLU[10];
  static char caProRLU[10];
  static int iFirstCon = 1;
 
  UCP_TRACE(P_DcsLUConnect);
  ErrLog(10,"DcsLUConnect Begin.",RPT_TO_LOG,0,0);

  /* search a usable dialogue  */
  iIdx = 1;
  while(pstSess[iIdx].cStatus != DCS_S_FREE &&
        pstSess[iIdx].cStatus != DCS_S_ERROR &&
        pstSess[iIdx].cStatus != DCS_S_USABLE &&
        iIdx < MAX_SESS) iIdx++;

  if(iIdx == MAX_SESS){
    ErrLog(1000,"DcsLUConnect:Sess over error",RPT_TO_LOG,0,0);
    PiErrno(pstDcsBuf) = DCS_ES_SESOVERFLW;
    UCP_TRACE_END(DCS_E_LOCALDCS);
  }
  /* initial sess */
  memset(&pstSess[iIdx], 0x0, sizeof(struct Lu62Sess) );

#ifdef PETER
  GetHostServName(PcaDesCode(pstDcsBuf),caHostName,caServName);
#endif
  GetCicsName(PcaData(pstDcsBuf),caCicsName);
  strcpy(g_ucaTpName,caCicsName);

  /* branch id */
  memcpy(cBrhCics,&PcaData(pstDcsBuf)[10],TPE_BRH_LEN);
  ErrLog(10,"DUMP BRH-CODE",RPT_TO_LOG,&PcaData(pstDcsBuf)[10],10);

  for (iTermPt=0;iTermPt<TPE_BRH_LEN;iTermPt++)
    cBrhUnix[iTermPt]=cBrhCics[iTermPt] - 0xf0 + 0x30;

  ErrLog(10,"DUMP cBrhUnix",RPT_TO_LOG,cBrhUnix,10);

  /* terminal id */
  memcpy(cTermCics,&PcaData(pstDcsBuf)[20],TPE_TERM_LEN);
  ErrLog(10,"DUMP TM-CODE",RPT_TO_LOG,&PcaData(pstDcsBuf)[20],2);

  for (iTermPt=0;iTermPt<TPE_TERM_LEN;iTermPt++)
    cTermUnix[iTermPt]=cTermCics[iTermPt] - 0xf0 + 0x30;

  ErrLog(10,"DUMP cTermUnix",RPT_TO_LOG,cTermUnix,2);

  /* --- when TPEI coming, it must need to fill global variable lluname --- */ 
  /* --- add by chi-fusong, 1995/04/13                                  --- */
  if ( (unsigned char)PcaData(pstDcsBuf)[3] == 0xC9 ) {

    int iBrhPt = 0;

    /* added by YEN 950630 begin */
    /*if ( lluname[0] == ' ' ) {*/  /* have to get environment variable */
    if ( iFirstCon == 1 ) {


      lluname[0]='\0';
      rluname[0]='\0';
      modename[0]='\0';

      /*strcpy(rluname,(char *)getenv("RLUNAME"));*/
      strcpy(modename,(char *)getenv("MODENAME"));

    }

      /* if cicsmap exists then LLUNAME=   CICS_REGION (at most 2 bytes)
				         + BRANCH
					 + TERMINAL
       */
      if (g_iCicsMapNum > 0) {
        int irc;
        char caBusiCics[2], caBusiUnix[2];
	char caCicsCode[3];
	char caRluCode[9];

        memcpy(caBusiCics,&PcaData(pstDcsBuf)[4],1);
        HostToBig5(caBusiCics, caBusiUnix);
        caBusiUnix[1]=0;

        irc = SrhCicsMap(caBusiUnix, caCicsCode, caRluCode);
        if (irc >= 0) {
	  strcpy(lluname, caCicsCode);
          strcpy(rluname, caRluCode);
	} else {
	  strcpy(lluname, "??");
          strcpy(rluname, "????????");
	  sprintf(g_caMsg,"CICSMAP error: %s not found in cicsmap file, set REGION to %s", caBusiUnix, lluname);
 	  ErrLog(1999,g_caMsg,RPT_TO_LOG,0,0);
        }
      } else {
        if (iFirstCon == 1) {
          strcpy(lluname,(char *)getenv("LLUNAME"));
          strcpy(caProLLU, lluname);
          strcpy(rluname,(char *)getenv("RLUNAME"));
          strcpy(caProRLU, rluname);
        } else {
          strcpy(lluname, caProLLU);
          strcpy(rluname, caProRLU);
        }
      }

      iBrhPt=strlen(lluname);
      memcpy(&lluname[iBrhPt], cBrhUnix + 3, 4);
      iTermPt=iBrhPt + 4;
      memcpy(&lluname[iTermPt],cTermUnix,TPE_TERM_LEN);
      lluname[iTermPt+TPE_TERM_LEN]='\0';
    /* added by YEN 950630 end */
  }

  sprintf(g_caMsg,"lluname = --%s-- ",lluname);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
  sprintf(g_caMsg,"rluname = --%s-- ",rluname);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
  sprintf(g_caMsg,"modename = --%s-- ",modename);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);

  iRc = mcAllocate(lutOTHER,lluname,rluname,modename,g_ucaTpName,
                  rcWHEN_ALLOC,syNONE,&pimPIP,&pimCB);
  sprintf(g_caMsg,"mcAllocate iRc = %d ",iRc);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
  sprintf(g_caMsg,"TP Name = %s",g_ucaTpName);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
/*
  ErrLog(10,"mcAllocate iRc",RPT_TO_LOG,&iRc,sizeof(iRc));
  ErrLog(10,"TP Name",RPT_TO_LOG,g_ucaTpName,sizeof(g_ucaTpName));
*/
  iCmRc = pimCB.RetCode;

  ErrLog(10,"cmalloc ucaConverId",RPT_TO_LOG,g_ucaConverId,8);

  if (iCmRc != CM_OK)
    {
      sprintf(g_caMsg,"DcsLUConnect(cmalloc):connect fail, errno=[%d]",iCmRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
    }

     
  /* save the session information */
  pstSess[iIdx].cStatus = DCS_S_USED ;
  memcpy(pstSess[iIdx].ucaConverId , g_ucaConverId,CONV_ID_LEN);
  pstSess[iIdx].cMode = ACTIVE_MODE;

  /* fill DCS buff */
  PiSesIdx(pstDcsBuf) = iIdx;
  PiErrno(pstDcsBuf) = 0;
  PcProto(pstDcsBuf) = LU62_DCS;

  iFirstCon = 0;

  sprintf(g_caMsg,"DcsLUConnect End.iIdx=%d ucaConverId=%s",
          iIdx,pstSess[iIdx].ucaConverId);
  ErrLog(10,g_caMsg,RPT_TO_LOG,pstSess[iIdx].ucaConverId,8);
  UCP_TRACE_END(DCS_NORMAL);
}


int
DcsLUAccept(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess)
{
  CM_RETURN_CODE  iCmRc=CM_OK;      /* ret code from CPI-C  */
  int iAcepLu62Id,iIdx,iRc;
  int iServLen;

  UCP_TRACE(P_DcsLUAccept);
  ErrLog(10,"DcsLUAccept Begin.",RPT_TO_LOG,0,0);

  /* search a usable dialogue  */
  iIdx = 1;
  while(pstSess[iIdx].cStatus != DCS_S_FREE &&
        pstSess[iIdx].cStatus != DCS_S_USABLE &&
        pstSess[iIdx].cStatus != DCS_S_ERROR &&
        iIdx < MAX_SESS) iIdx++;

  if(iIdx == MAX_SESS){
    ErrLog(1000,"DcsLUAccept:Sess over error",RPT_TO_LOG,0,0);
    PiErrno(pstDcsBuf) = DCS_ES_SESOVERFLW;
    UCP_TRACE_END(DCS_E_LOCALDCS);
  }
  /* initial sess */
  memset(&pstSess[iIdx], 0x0, sizeof(struct Lu62Sess) );

  if (iCmRc != CM_OK)
    {
      sprintf(g_caMsg,"DcsSkAccept(cmaccp):accept fail, errno=[%d]",iCmRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
    }


  /**********************************************************/
  /* set the deallocate type so that this side will ask for */
  /* confirmation from the source when making a deallocate  */
  /* call.                                                  */
  /**********************************************************/

  g_lDeallocateType = CM_DEALLOCATE_SYNC_LEVEL;
  
  if (iCmRc != CM_OK)
    {
      sprintf(g_caMsg,"DcsSkAccept:set dealloc. type fail, errno=[%d]",iCmRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
    }
 
  /* save the session information */
  pstSess[iIdx].cStatus = DCS_S_USED ;
  memcpy(pstSess[iIdx].ucaConverId , g_ucaConverId,CONV_ID_LEN );
  pstSess[iIdx].cMode = PASSIVE_MODE;

  /* fill DCS buff */
  PiSesIdx(pstDcsBuf) = iIdx;
  PiErrno(pstDcsBuf) = 0;
  PcProto(pstDcsBuf) = LU62_DCS;

  sprintf(g_caMsg,"DcsLUAccept End.iIdx=%d ucaConverId=%s",
          iIdx,pstSess[iIdx].ucaConverId);

  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}


int
DcsLUSend(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess)
{
  CM_RETURN_CODE  iCmRc=CM_OK;      /* ret code from CPI-C  */
  int iIdx;
  unsigned char ucaWdLu62Id[CONV_ID_LEN];
  int iRc;
  int iMsgLen;
  char caDummy[20];
 
  UCP_TRACE(P_DcsLUSend);
  ErrLog(10,"DcsLUSend Begin.",RPT_TO_LOG,0,0);
  memset(ucaWdLu62Id , 0x00,CONV_ID_LEN);

  iIdx = PiSesIdx(pstDcsBuf);


  if(iIdx > 0){
    if(pstSess[iIdx].cStatus != DCS_S_USED || iIdx >= MAX_SESS){
      ErrLog(1000,"DcsLUSend:unusable Session!",RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = DCS_ES_SESUNUSE;
      UCP_TRACE_END(DCS_E_COMMAND);
    }
    memcpy(ucaWdLu62Id , pstSess[iIdx].ucaConverId,CONV_ID_LEN);
  }
  else{
    strcpy(ucaWdLu62Id , "0000001");
  }
  sprintf(g_caMsg,"DcsLUSend:iIdx=%d ucaWdLu62Id=%s ",
          iIdx,ucaWdLu62Id);
  ErrLog(10,g_caMsg,RPT_TO_LOG,ucaWdLu62Id,8);


  /* send a service reguest */
/*mod by eric */
  iMsgLen = PiDataLen(pstDcsBuf);

  sprintf(g_caMsg,"DCSLU62SEND:iMsgLen=%d ",iMsgLen);
  ErrLog(10,g_caMsg,RPT_TO_LOG,PcaData(pstDcsBuf),iMsgLen);

/*
  g_lSendType = CM_BUFFER_DATA;

  cmsst(ucaWdLu62Id,
        &g_lSendType,
        &iCmRc);


  if (iCmRc != CM_OK)
    {
      sprintf(g_caMsg,"DcsLUSend(cmsst):write fail, errno=[%d]",iCmRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstSess[iIdx].cStatus = DCS_S_ERROR;
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iRc);
    }
*/

  /**************************************************************/
  /* Send data to the target transaction program. This command  */
  /* will issue a packet of data of (length) bytes. The data    */
  /* going to the target can be found in the string send_buffer */
  /* Req_to_send indicates whether the remote program has made  */
  /* a request to send.                                         */
  /**************************************************************/
  g_lLength = (long) iMsgLen;

  sprintf(g_caMsg," ResState = %d Req to send = %d WhatRcvd=%d",  pimCB.ResState, pimCB.RqToSndRcvd,pimCB.WhatRcvd);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);


  if ( pimCB.ResState == 3  )
  {
/*
   mcSnd_Error(pimCB.Resource);
*/
  mcRequest_To_Send(pimCB.Resource);
  iCmRc = pimCB.RetCode;
    if (iCmRc != CM_OK)
      {
        sprintf(g_caMsg,"mcRequest_To_Send fail, errno=[%d]",iCmRc);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        pstSess[iIdx].cStatus = DCS_S_ERROR;
        PiErrno(pstDcsBuf) = errno;
        UCP_TRACE_END(iRc);
      }
  sprintf(g_caMsg," AfterRq ResState = %d Req to send = %d ",  pimCB.ResState, pimCB.RqToSndRcvd);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
  mcReceive_And_Wait(pimCB.Resource,PcaData(pstDcsBuf),g_lLength,&g_lReceivedLength, NULL);
  sprintf(g_caMsg," AfterRe ResState = %d Req to send = %d ",  pimCB.ResState, pimCB.RqToSndRcvd);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);

  }


  mcSend_Data(pimCB.Resource,PcaData(pstDcsBuf),g_lLength,NULL ,0 );
  iCmRc = pimCB.RetCode;

    if (iCmRc != CM_OK)
      {
        sprintf(g_caMsg,"DcsLUSend(cmsend):write fail, errno=[%d]",iCmRc);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        pstSess[iIdx].cStatus = DCS_S_ERROR;
        PiErrno(pstDcsBuf) = errno;
        UCP_TRACE_END(iRc);
      }
      else
        ErrLog(10,"DcsLUSend:write ok.",RPT_TO_LOG,0,0);


  /* update session */
  PiErrno(pstDcsBuf) = 0;

  if(iIdx == 0 && (pstSess[iIdx].cStatus == DCS_S_FREE ||
                  pstSess[iIdx].cStatus == DCS_S_USABLE)){
    pstSess[iIdx].cStatus = DCS_S_USED ;
    pstSess[iIdx].cMode = ACTIVE_MODE;
    PcProto(pstDcsBuf) = LU62_DCS;
  }

  ErrLog(10,"DcsLUSend End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}


int
DcsLUReceive(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess)
{
  CM_RETURN_CODE  iCmRc=CM_OK;      /* ret code from CPI-C  */
  unsigned char ucaRdLu62Id[CONV_ID_LEN];
  int iIdx;
  int iRc;
  int iMsgLen;
  char caDummy[10];
  void DcsLUNull();
  char caTmpBuf[10];
  int  i;
 
  UCP_TRACE(P_DcsLUReceive);
  ErrLog(10,"DcsLUReceive Begin.",RPT_TO_LOG,0,0);
  memset(ucaRdLu62Id , 0x00,CONV_ID_LEN);

  iIdx = PiSesIdx(pstDcsBuf);

  if(iIdx > 0){
    if(pstSess[iIdx].cStatus != DCS_S_USED || iIdx >= MAX_SESS){
      ErrLog(1000,"DcsLUReceive:unusable Session!",RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = DCS_ES_SESUNUSE;
      UCP_TRACE_END(DCS_E_COMMAND);
    }
    memcpy(ucaRdLu62Id , pstSess[iIdx].ucaConverId,CONV_ID_LEN);
  }
  else{
    strcpy(ucaRdLu62Id , "0000001");
  }
  sprintf(g_caMsg,"DcsLUReceive:iIdx=%d ucaRdLu62Id=%s.",
          iIdx,ucaRdLu62Id);
  ErrLog(10,g_caMsg,RPT_TO_LOG,ucaRdLu62Id,8);


  signal(SIGALRM,DcsLUNull)  ;
  signal(SIGINT,SIG_DFL)  ;
/*
  signal(SIGSEGV,Dcsigsegv)  ;
*/
  alarm(PlWaiTime(pstDcsBuf)) ;


  iMsgLen = PiDataLen(pstDcsBuf);
  g_lLength = (long) iMsgLen;

  sprintf(g_caMsg,"MaxLen=%d\n ",g_lLength);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);

  ErrLog(10,"begin cmrcv",RPT_TO_LOG,0,0);
/*
  iCmRc = mcPrep_To_Rcv(pimCB.Resource,ptFLUSH,lkSHORT);
*/

  mcReceive_And_Wait(pimCB.Resource,PcaData(pstDcsBuf),g_lLength,&g_lReceivedLength, NULL/*mapname*/);

  sprintf(g_caMsg,"mcReceive_And_Wait : Retcode = %d Retsubcode = %d ResState = %d Req to send = %d WhatRcvd = %d", pimCB.RetCode, pimCB.RetSubCode, pimCB.ResState, pimCB.RqToSndRcvd, pimCB.WhatRcvd);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);

  iCmRc = pimCB.RetCode;
  g_lStatusReceived = iCmRc;
  g_lDataReceived = pimCB.WhatRcvd;


  sprintf(g_caMsg,"cmrcv():status [%d] data_rcvd [%d] len[%d]",
 (int)g_lStatusReceived,(int)g_lDataReceived,(int)g_lReceivedLength);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
  iMsgLen = g_lReceivedLength;
  sprintf(g_caMsg,"DcsLUReceive:read ok. len=%d\n ",iMsgLen);
  ErrLog(10,g_caMsg,RPT_TO_LOG,PcaData(pstDcsBuf),iMsgLen);
  if ( (iCmRc != CM_OK) && (iCmRc != CM_DEALLOCATED_NORMAL) )
    {
      sprintf(g_caMsg,"DcsLUReceive(cmrcv):read fail, errno=[%d]",iCmRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,PcaData(pstDcsBuf),g_lReceivedLength);
      pstSess[iIdx].cStatus = DCS_S_ERROR;
      PiErrno(pstDcsBuf) = iCmRc;
      if(errno == EINTR) UCP_TRACE_END(DCS_E_TIMEOUT);
      UCP_TRACE_END(iCmRc);
    }

  sprintf(caTmpBuf,"%.5d",g_lReceivedLength);
  memcpy(PcaDataLen(pstDcsBuf),caTmpBuf,5);


  if (g_lStatusReceived == CM_CONFIRM_RECEIVED || 
      g_lStatusReceived == CM_CONFIRM_SEND_RECEIVED)
    {
      mcCnfirmed( pimCB.Resource );
      iCmRc = pimCB.RetCode;
     
      if (iCmRc != CM_OK)
        {
          sprintf(g_caMsg,"DcsLUReceive(cmcfmd) fail, errno=[%d]",iCmRc);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          pstSess[iIdx].cStatus = DCS_S_ERROR;
          PiErrno(pstDcsBuf) = iCmRc;
          UCP_TRACE_END(iCmRc);
        }

      /***********************************************************/
      /* issue the request to send command to request permission */
      /* from the source program to enter send state. Only do    */
      /* this before the send token has arrived from the other   */
      /* side of the conversation.                           */
      /***********************************************************/
/*
      if (g_lStatusReceived == CM_CONFIRM_RECEIVED) 
        {
          cmrts(ucaRdLu62Id,
                &iCmRc);
          if (iCmRc != CM_OK)
            {
              sprintf(g_caMsg,"DcsLUReceive:cmrts fail, errno=[%d]",iCmRc);
              ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
              pstSess[iIdx].cStatus = DCS_S_ERROR;
              PiErrno(pstDcsBuf) = iCmRc;
              UCP_TRACE_END(iCmRc);
            }
        }
*/


    } 

/*

  mcRequest_To_Send(pimCB.Resource);
  iCmRc = pimCB.RetCode;
    if (iCmRc != CM_OK)
      {
        sprintf(g_caMsg,"mcRequest_To_Send fail, errno=[%d]",iCmRc);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        pstSess[iIdx].cStatus = DCS_S_ERROR;
        PiErrno(pstDcsBuf) = errno;
        UCP_TRACE_END(iRc);
      }

  mcReceive_And_Wait(pimCB.Resource,PcaData(pstDcsBuf),g_lLength,&g_lReceivedLength, NULL);
*/


  alarm(0) ;
  iMsgLen = (int) g_lReceivedLength;


  /* save the session information */
  PiDataLen(pstDcsBuf) = iMsgLen ;
  PiErrno(pstDcsBuf) = 0;

  if(iIdx == 0 && (pstSess[iIdx].cStatus == DCS_S_FREE ||
                  pstSess[iIdx].cStatus == DCS_S_USABLE)){
    pstSess[iIdx].cStatus = DCS_S_USED ;
    pstSess[iIdx].cMode = PASSIVE_MODE;
    PcProto(pstDcsBuf) = LU62_DCS;
  }

  ErrLog(10,"DcsLUReceive End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}




int
DcsLUDisconnect(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess)
{
  CM_RETURN_CODE  iCmRc=CM_OK;      /* ret code from CPI-C  */
  int iRc;
  int iIdx;
  unsigned char ucaConverId[CONV_ID_LEN];
 
  UCP_TRACE(P_DcsLUDisconnect);
  ErrLog(10,"DcsLUDisconnect Begin.",RPT_TO_LOG,0,0);
  memset(ucaConverId , 0x00,CONV_ID_LEN);

  /* Is the dialogue usable */
  iIdx = PiSesIdx(pstDcsBuf);

  if(iIdx > 0){
    if(pstSess[iIdx].cStatus == DCS_S_FREE || iIdx >= MAX_SESS){
      ErrLog(1000,"DcsLUDisconnect: unusable Session!",RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = DCS_ES_SESUNUSE;
      UCP_TRACE_END(DCS_E_COMMAND);
    }
    memcpy(ucaConverId , pstSess[iIdx].ucaConverId,CONV_ID_LEN);
  }
  else{
    strcpy(ucaConverId , "0000001");
  }

  mcDeallocate(pimCB.Resource,tyABND);
  /*mcDeallocate(pimCB.Resource,tyLOCAL);*/
  iCmRc = pimCB.RetCode;

  if (iCmRc != CM_OK) {
    sprintf(g_caMsg,"DcsLUDisconnect(cmdeal) fail, errno=[%d]",iCmRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstSess[iIdx].cStatus = DCS_S_ERROR;
    PiErrno(pstDcsBuf) = iCmRc;
    UCP_TRACE_END(iCmRc);
  }

  /* save the session information */
  pstSess[iIdx].cStatus = DCS_S_FREE;
  strcpy(pstSess[iIdx].ucaConverId , "00000-1");

  /* fill DCS buff */
  PiSesIdx(pstDcsBuf) = -1;
  PiErrno(pstDcsBuf) = 0;
  PcProto(pstDcsBuf) = ' ';

  ErrLog(10,"DcsLUDisconnect End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}


int
DcsLUTerminate(struct DcsBuf *pstDcsBuf)
{
  UCP_TRACE(P_DcsLUTerminate);
  ErrLog(10,"DcsLUTerminate Begin.",RPT_TO_LOG,0,0);

  DetachLU62();
  ErrLog(10,"DcsLUTerminate End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}



int
GetHostServName(char *pcDesCode,char *pcHostName,char *pcServName) {
  int iRc;
  struct Lu62Netwk stNetwk;

  UCP_TRACE(P_GetHostServName);
  ErrLog(10,"GetHostServName:Begin",RPT_TO_LOG,0,0);

  iRc = 0;
  /* get protocol & server name by des_code */
  iRc = SrhLu62NetwkTbl(pcDesCode,&stNetwk);
  if(iRc != 0){
    sprintf(g_caMsg,"GetHostServName:search network table error iRc=%d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(iRc);
  }
  ErrLog(10,"GetHostServName:search network table ok.",RPT_TO_LOG,0,0);

  strcpy(pcHostName,stNetwk.caField[0]);
  strcpy(pcServName,stNetwk.caField[1]);

  sprintf(g_caMsg,"GetHostSeNa:End host=%s serv=%s\n",pcHostName,pcServName);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
  UCP_TRACE_END(0);
}


int
SrhLu62NetwkTbl(char *pcDesCode,struct Lu62Netwk *pstNetwk)
{
  int iIdx,iRc;
  struct Lu62Netwk *pstNetTbl;
 
  UCP_TRACE(P_SrhLu62NetwkTbl);
  sprintf(g_caMsg,"SrhLu62NetwkTbl:Begin,pcDesCode=%.10s",pcDesCode);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);

  pstNetTbl = g_stLu62NetTbl;
  iIdx = 1;
  /* find out in the net work table array */
  while((iRc = memcmp(pcDesCode,pstNetTbl[iIdx].caDesCode,10) != 0) &&
        (iIdx < gs_iMaxLoad)){
    iIdx++;
  }
  
  /* memory copy from net work table to working area of networktable struct */
  if(iIdx == gs_iMaxLoad){
    /* not found in table array, then set default protocol & server name */
    memcpy(pstNetwk,&pstNetTbl[0],sizeof(struct Lu62Netwk));
  }
  else{
    /* found */
    memcpy(pstNetwk,&pstNetTbl[iIdx],sizeof(struct Lu62Netwk));
  }

  sprintf(g_caMsg,"SrhLu62NetwkTbl End pstNetTbl[%d]=",iIdx);
  ErrLog(10,g_caMsg,RPT_TO_LOG,&pstNetTbl[iIdx],sizeof(struct Lu62Netwk));
  UCP_TRACE_END(0);
}


int
LoadLu62NetwkTbl(struct Lu62Netwk *pstNetTbl)
{
  int i,j,k;
  FILE *pfNetFd,*pfNetFd2;
  char caFileName[80];

  UCP_TRACE(P_LoadLu62NetwkTbl);
  ErrLog(10,"LoadLu62NetwkTbl:Begin",RPT_TO_LOG,0,0);
/*
  strcpy((char *)caFileName, (char *)getenv("UCP_DIR"));
  strcat(caFileName, DCS_TABLE_PATH);
*/
  memset(caFileName,'\0',80);
  strcpy(caFileName,(char *) getenv("III_DIR"));
  strcat(caFileName,(char *) "/iii/etc/dcd/");
  strcat(caFileName,"lu62tbl");
  ErrLog(10,caFileName,RPT_TO_LOG,0,0);

#ifdef ELLEN
  if((pfNetFd = fopen(caFileName,"r")) == (FILE *) 0){
    sprintf(g_caMsg,"LoadLu62NetwkTbl:open lu62tbl fail errno=%d",errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(DCS_ES_OPENTBLFILE);
  }
  ErrLog(10,"LoadLu62NetwkTbl:open netwktable ok",RPT_TO_LOG,0,0);

  i = 0;
  while(fscanf(pfNetFd,"%s %s %s", pstNetTbl[i].caDesCode,
                                   pstNetTbl[i].caField[0],
                                   pstNetTbl[i].caField[1]) != EOF){
    /*
    for(j=0; j<2; j++){
      for(k=0; k<20; k++){
        if(pstNetTbl[i].caField[j][k] == '*'){
           pstNetTbl[i].caField[j][k] = '\0';
           break;
        }
      }
    }
    */

    if(i++ > MAX_NETWKTBL_ARRAY){
      ErrLog(1000,"LoadLu62NetwkTbl:over table array",RPT_TO_LOG,0,0);
      fclose(pfNetFd);
      UCP_TRACE_END(DCS_ES_TBLARRAYOVERFLW);
    }
  }
#endif

/*
  memset(caFileName,'\0',80);
  strcpy(caFileName,(char *) getenv("III_DIR"));
  strcat(caFileName,(char *) "/iii/etc/dcd/");
  strcat(caFileName,"cgdlu62tbl");
  ErrLog(10,caFileName,RPT_TO_LOG,0,0);

  if((pfNetFd2 = fopen(caFileName,"r")) == (FILE *) 0){
    sprintf(g_caMsg,"Load Cgd Lu62NetwkTbl:open lu62tbl fail errno=%d",errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(DCS_ES_OPENTBLFILE);
  }
  ErrLog(10,"Load CGD Lu62NetwkTbl:open netwktable ok",RPT_TO_LOG,0,0);

  j = 0;
  while(fscanf(pfNetFd,"%s %s %s", lluname,
                                   rluname ,
                                   modename) != EOF){

    if(j++ > MAX_NETWKTBL_ARRAY){
      ErrLog(1000,"LoadLu62NetwkTbl:over table array",RPT_TO_LOG,0,0);
      fclose(pfNetFd);
      UCP_TRACE_END(DCS_ES_TBLARRAYOVERFLW);
    }
  }
*/

  gs_iMaxLoad = i;
  ErrLog(10,"LoadLu62NetwkTbl End.",RPT_TO_LOG,0,0);
  fclose(pfNetFd);
/*
  fclose(pfNetFd2);
*/
  UCP_TRACE_END(0);
}

void
DcsLUNull()
{
}


Dcsigsegv()
{
  ErrLog(1000,"SIGSEGV .............",RPT_TO_LOG,0,0);
  exit(0);
}


GetCicsName(unsigned char *pcaData,char *pcaCicsName)
{
int iRc;


  switch (pcaData[3]){
   case 0xC9:
     strcpy(pcaCicsName,"TPEI");
     break;

   case 0xD6:
     strcpy(pcaCicsName,"TPEO");
     break;

   default:
     strcpy(pcaCicsName,"TPEO");
     break;
  } /* end switch */

}


int
GetCicsMap()
{
    char caMapFileName[300];
    char caStr[256];
    char caBusinessCode[10];
    char caCicsCode[10];
    char caRluCode[10];
    FILE *zFp;

    if (g_iCicsMapNum >= 0) return 0;

    g_iCicsMapNum = 0;

    strcpy((char *)caMapFileName, (char *)getenv("III_DIR"));
    strcat(caMapFileName, DCS_TABLE_PATH);
    strcat(caMapFileName,"cicsmap");

    if((zFp = fopen(caMapFileName,"r")) == (FILE *) 0) {
      sprintf(g_caMsg,"GetCicsMap:file cicsmap not found. SO, 1 CICS.");
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      return -1;
    }

    g_iCicsMapNum = 0;
    while( fgets(caStr, 256, zFp) != (char *)NULL) {
      int iScan;

      if (caStr[strlen(caStr)-1] != '\n') { /* LINE exceeds 256 */
         sprintf(g_caMsg,"GetCicsMap:Line OverFlow 256 in cicsmap");
         ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
         fclose(zFp);
	 g_iCicsMapNum = 0;
         return -2;
      }

      if (caStr[0] == '#') continue; /* comment */

      memset(caBusinessCode,0x00,10);
      memset(caCicsCode,0x00,10);
      memset(caRluCode,0x00,10);

      iScan = sscanf(caStr, "%s %s %s", caBusinessCode, caCicsCode, caRluCode);
      if (iScan < 3) {
        continue;
      }

      if (g_iCicsMapNum > CICSMAP_NUMBER) {
         sprintf(g_caMsg,"GetCicsMap:LINE NUMBER over %d", CICSMAP_NUMBER);
         ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
         break;
      }

      memcpy(stCicsMapTbl[g_iCicsMapNum].caBusiCode, caBusinessCode, 1);
      memcpy(stCicsMapTbl[g_iCicsMapNum].caCicsCode, caCicsCode, 2);
      memcpy(stCicsMapTbl[g_iCicsMapNum].caRluCode, caRluCode, 8);

      g_iCicsMapNum ++;
    }

    fclose(zFp);

    if (g_iCicsMapNum <= 0) return -3;
    return 0;
}


int
SrhCicsMap(char *pcaBusiCode, char *pcaCicsCode, char *pcaRluCode)
{
  int i, ret;

  for (i=0; i<g_iCicsMapNum; i++) {
     if (strcmp(pcaBusiCode, stCicsMapTbl[i].caBusiCode) == 0) {
       break;
     }
  }

  /* if not found, then return the first (default) one */
  if (i == g_iCicsMapNum) ret = 0;
  else ret = i;

  strcpy(pcaCicsCode, stCicsMapTbl[ret].caCicsCode);
  strcpy(pcaRluCode, stCicsMapTbl[ret].caRluCode);

  return ret;
}


int
HostToBig5(char *pcaHstData, char *pcaUnxData)
{
 int i;
 char cnv_ptr;

 if ((i=host_big5(pcaHstData,pcaUnxData,1,&cnv_ptr))
     !=1) {
   sprintf(g_caMsg,"Convert Business Code Error, rc=%d",i);
   ErrLog(2000,g_caMsg,RPT_TO_LOG,0,0);
   return -1;
 }
}
