

#include <errno.h>
#include "errlog.h"
#include "dcs.h"

#define MAX_DATA_LEN	256

/* ------------- dcsqueue.c function ���N�� ------------------------- */
#define P_DcsCreat	67002
#define P_DcsRemove	67003
#define P_GetFileData	67004
#define P_IsUseQuType	67005

/* -------------------- STATIC GLOBAL DECLARATION ------------------- */
static int sg_iaQuId[MAX_NETWKTBL_ARRAY];	/* keep QuId array */
static int sg_iMaxQuId;				/* max creat queue */

int gs_iQueKey;
 
int DcsCreat();
int DcsRemove();
 
testmain(int iArgc, char *pcArgv[])
{
  int iRc;

  printf("pcArgv[1]=%c\n",*pcArgv[1]);
  switch(*pcArgv[1]){
    case 'c':
    case 'C':
      iRc = DcsCreat();
      if(iRc != 0){
        ErrLog(1000,"dcmcrenv.c:DcsCreat error!",RPT_TO_LOG,0,0);
        exit(-2);
      }
      break;
    case 'r':
    case 'R':
      iRc = DcsRemove();
      if(iRc != 0){
        ErrLog(1000,"dcmcrenv.c:DcsRemove error!",RPT_TO_LOG,0,0);
        exit(-3);
      }
      break;
    default:
      printf("Parameters error!!\n Use dcxcrenv.x C/R\n");
      sprintf(g_caMsg,"dcmcrenv.c: Argv[1]=%.1s",pcArgv[1]);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      exit(-1);
  }
  exit(0);
}


int
DcsCreat()
{
  int i, iRc=0;
  char caFileName[80];
  char *pcFoundFlg;
  /* for get data */
  char caDataType[5];
  long *plDataVar[5];
  /* input data variable for queuetbl */
  char caDesCode[20];
  int iQuFlag;
  long lQuSize;
  long lQuType;
  int iQuId;
  int iLastQuKey;	/* keep last queue key */
  FILE *pfQueFile;

  UCP_TRACE(P_DcsCreat);
  ErrLog(100,"DcsCreat Begin.",RPT_TO_LOG,0,0);
  
  iQuFlag = IsUseQuType();
  if(iQuFlag < 0){
    ErrLog(1000,"DcsCreat: IsUseQuType error!",RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  }

  /* if use queue protocol than read queuetbl to Creat Quue */
  if(iQuFlag){
    /* get file name */
/*
    strcpy((char *)caFileName, (char *)getenv("III_DIR"));
    strcat(caFileName, DCS_TABLE_PATH);
*/
    strcpy(caFileName,"queuetbl");

    /* open file queue table */
    pfQueFile = fopen(caFileName,"rt");
    if( pfQueFile == NULL) {

 printf("open queuetbl error\n");
      sprintf("DcsCreat:fopen %s fail errno=%d",caFileName,errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(DCS_E_NETWORKTBL);
    }

    strcpy(caDataType,"sdD");
    plDataVar[0] = (long *)caDesCode;
    plDataVar[1] = &gs_iQueKey;
    plDataVar[2] = &lQuType;

    i = 0;
    sg_iMaxQuId = 0;
    iLastQuKey = -1;	/* initial iLastQuKey */ 
    lQuSize = -1;	/* initial iQuSize = 0 */
    while((iRc = GetFileData(pfQueFile,3,caDataType,plDataVar)) == 0){
  
      /* first record is queue size data */
      if(lQuSize < 0){
        iRc = strncmp(caDesCode,"QUEUE_SIZE",10);
        if(iRc == 0){
          lQuSize = lQuType;
        }
        else{	/* no queue size data error */
          fclose(pfQueFile);
          ErrLog(1000,"DcsCreat: Queue Size no define error!",RPT_TO_LOG,0,0);
          UCP_TRACE_END(DCS_E_NETWORKTBL);
        } /* end of if(iRc == 0) -- else */
      }
      else{
        if((lQuSize > 0) && ((gs_iQueKey != iLastQuKey) ||
           (iLastQuKey == -1))){
          iRc = MsqCreat(&iQuId,lQuSize,gs_iQueKey);
          if(iRc != 0){	/* creat queue error */
printf("111\n");
            UCP_TRACE_END(DCS_E_LOCALDCS);
          } /* end of if(iRc != 0) */
          iLastQuKey = gs_iQueKey;
        } /* end of if((lQuSize > 0) && ((gs_iQueKey != iLastQuKey) ||
                       (iLastQuKey == -1))) */
      } /* end of if(lQuSize < 0) -- else */ 
    } /* end of while((iRc = GetFileData(3,caDataType,plDataVar)) == 0) */

    fclose(pfQueFile);

  } /* end of if(iQuFlag) */


  ErrLog(100,"DcsCreat End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}



int
DcsRemove(cMode)
char cMode;
{
  int i, iRc=0;
  char caFileName[80];
  char *pcFoundFlg;
  /* for get data */
  char caDataType[5];
  long *plDataVar[5];
  /* input data variable for queuetbl */
  char caDesCode[20];
  int iQuFlag;
  long lQuSize;
  long lQuType;
  int iQuId;
  int iLastQuKey;	/* keep last queue key */
  FILE *pfQueFile;

  UCP_TRACE(P_DcsRemove);
  ErrLog(10,"DcsRemove Begin.",RPT_TO_LOG,0,0);

  iQuFlag = IsUseQuType();
  if(iQuFlag < 0){
    ErrLog(1000,"DcsCreat: IsUseQuType error!",RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  }

  /* if use queue protocol than read queuetbl to Creat Quue */
  if(iQuFlag){
    /* get file name */
/*
    strcpy((char *)caFileName, (char *)getenv("III_DIR"));
    strcat(caFileName, DCS_TABLE_PATH);
*/
    strcpy(caFileName,"queuetbl");
  
    /* open file */
    pfQueFile = fopen(caFileName,"rt");
    if( pfQueFile == NULL) {
      sprintf("DcsCreat:fopen %s fail errno=%d",caFileName,errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(DCS_E_NETWORKTBL);
    }
  
    strcpy(caDataType,"sdD");
    plDataVar[0] = (long *) caDesCode;
    plDataVar[1] = &gs_iQueKey;
    plDataVar[2] = &lQuType;
  
    i = 0;
    sg_iMaxQuId = 0;
    iLastQuKey = -1;	/* initial iLastQuKey */ 
    lQuSize = -1;	/* initial iQuSize = 0 */
    while((iRc = GetFileData(pfQueFile,3,caDataType,plDataVar)) == 0){
  
      /* first record is queue size data */
      if(lQuSize < 0){
        iRc = strncmp(caDesCode,"QUEUE_SIZE",10);
        if(iRc == 0){
          lQuSize = lQuType;
        }
        else{	/* no queue size data error */
          fclose(pfQueFile);
          ErrLog(1000,"DcsCreat: Queue Size no define error!",RPT_TO_LOG,0,0);
          UCP_TRACE_END(DCS_E_NETWORKTBL);
        } /* end of if(iRc == 0) -- else */
      }
      else{
        if((lQuSize > 0) && ((gs_iQueKey != iLastQuKey) ||
           (iLastQuKey == -1))){

          iRc = MsqGet(&iQuId,gs_iQueKey);
          if(iRc != 0){	/* creat queue error */
            UCP_TRACE_END(DCS_E_LOCALDCS);
          } /* end of if(iRc != 0) */

          iRc = MsqRemove(iQuId);
          if(iRc != 0){	/* creat queue error */
            UCP_TRACE_END(DCS_E_LOCALDCS);
          } /* end of if(iRc != 0) */

          iLastQuKey = gs_iQueKey;
        } /* end of if((lQuSize > 0) && ((gs_iQueKey != iLastQuKey) ||
                       (iLastQuKey == -1))) */
      } /* end of if(lQuSize < 0) -- else */ 
    } /* end of while((iRc = GetFileData(3,caDataType,plDataVar)) == 0) */
  
    fclose(pfQueFile);

  }

  ErrLog(10,"DcsRemove End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(0);
}

/*============================================================================*/

int
IsUseQuType()
{
  int i;
  int iRc=0;
  char caFileName[80];
  char *pcFoundFlg;
  /* for get data */
  char caDataType[5];
  long *plDataVar[5];
  /* input data variable for prototbl */
  char caDesCode[20];
  char cProtoType;
  /* input data variable for queuetbl */
  int iQuFlag;
  FILE *pfProtoFile;

  UCP_TRACE(P_IsUseQuType);
  ErrLog(100,"IsUseQuType Begin.",RPT_TO_LOG,0,0);
  
  /* open input Data file */
/*
  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat(caFileName, DCS_TABLE_PATH);
*/
  strcpy(caFileName,"prototbl");

  pfProtoFile = fopen(caFileName,"rt");
  if( pfProtoFile == NULL) {
    sprintf("IsUseQuType:fopen %s fail errno=%d",caFileName,errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  }

  strcpy(caDataType,"sc");
  plDataVar[0] = (long *) caDesCode;
  plDataVar[1] = (long *) &cProtoType;

  /* read prototbl to check that is queue protocol used ? */
  iQuFlag = 0;
  while((iRc = GetFileData(pfProtoFile,2,caDataType,plDataVar)) == 0){
    if(cProtoType == 'Q'){
      iQuFlag = 1;
      break;
    }
  } /* end of while((iRc = GetFileData(2,caDataType,plDataVar)) == 0) */

  fclose(pfProtoFile);

  ErrLog(100,"IsUseQuType End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(iQuFlag);
}



#ifdef  NODELETE
int
GetFileData(FILE *pfFile, int iDataNo,char caDataType[], long* plDataVar[])
{
  int i;
  long lOffset;
  char caDataBuf[MAX_DATA_LEN];
  char cBypass,cDummy;

  UCP_TRACE(P_GetFileData);

  do {
    if(feof(pfFile)){
      UCP_TRACE_END(-1);
    }

    fgets(caDataBuf,MAX_DATA_LEN,pfFile);
    if (caDataBuf[0] != '#') {
      lOffset = (long) strlen(caDataBuf) * -1;
      fseek(pfFile,lOffset,SEEK_CUR);

      for(i=0; i < iDataNo ; i++){

        fscanf(pfFile,"%c",&cBypass);
        if( cBypass != '*') {

          fseek(pfFile,-1,SEEK_CUR);
          switch(caDataType[i]){
            case 't' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%d\n",(short *) plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%d ",(short *) plDataVar[i]);
              }
              break;
            case 'd' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%d\n",(int *) plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%d ",(int *) plDataVar[i]);
              }
              break;
            case 'D' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%ld\n",(long *) plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%ld ",(long *) plDataVar[i]);
              }
              break;
            case 'o' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%o\n",(int *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%o ",(int *)plDataVar[i]);
              }
              break;
            case 'O' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%lo\n",(long *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%lo ",(long *)plDataVar[i]);
              }
              break;
            case 'x' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%x\n",(int *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%x ",(int *)plDataVar[i]);
              }
              break;
            case 'X' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%lx\n",(long *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%lx ",(long *)plDataVar[i]);
              }
              break;
            case 'i' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%i\n",(int *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%i ",(int *)plDataVar[i]);
              }
              break;
            case 'I' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%li\n",(long *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%li ",(long *)plDataVar[i]);
              }
              break;
            case 's' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%s\n",(char *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%s ",(char *)plDataVar[i]);
              }
              break;
            case 'c' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%c\n",(char *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%c ",(char *)plDataVar[i]);
              }
              break;
            default :
              sprintf(g_caMsg,"GetFileData: data-type=%c error",caDataType[i]);
              ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
              UCP_TRACE_END(-2);
          }  /* end switch */
        }
        else {
          if( (i == iDataNo-1) && (cDummy == '\n') ) {
            fscanf(pfFile,"\n");
            UCP_TRACE_END(0);
          }
          else fscanf(pfFile," ");
        } /* end if '*' */
      }  /* end for */
    }  /* end if  '#' */
  } while(caDataBuf[0] == '#');

  UCP_TRACE_END(0);
}
#endif
