
   #define ERR_OK                0x00000000  /* Everything was OK */
   #define ERR_FUNCTION_SUPP     0x01005031  /* Function not supported */
   #define ERR_INVALID_LENGTH    0x01005032  /* Invalid Parameter length */
   #define FUN_FAILD             0x0001
   #define FUN_OK                0x0000
 /*----------------------*/
/* Function definitions */
/*----------------------*/
   #define ES     0x4553    /* End of Service request */
   #define AS     0x4153    /* Workstation connection request */
   #define AM     0x414D    /* Workstation disconnection request */
   #define GD     0x4744    /* Get Date request */
   #define QS     0x5153    /* Get query request */
   #define SF     0x5346    /* Get share file request */
   #define IN     0x494E
   #define GF     0x4746                        /* Grant Function            */
   #define RF     0x5246                        /* Revoke Function           */
   #define OQ     0x4F51                        /* Open Query mode           */
   #define CQ     0x4351                        /* Close Query mode          */
   #define SQ     0x5351                        /* Structured Query          */
   #define CW     0x4357                        /* Commit Work               */
   #define IR     0x4952                        /* Insert Row                */
   #define SP     0x5350                        /* Set Parameters            */
   #define DT     0x4454                        /* Describe Table            */
   #define FR     0x4652                        /* Fetch Row                 */
   #define RW     0x5257
   #define EQ     0x4551
   #define RR     0x5252
   #define DR     0x4452
   #define OO     0x4F4F
   #define BT     0x4254
   #define DD     0x4444
   #define DI     0x4449
   #define DP     0x4450
   #define IS     0x4953
   #define GU     0x4755
   #define GN     0x474E
   #define GP     0x4750
   #define ED     0x4544
   #define CO     0x434F
   #define EP     0x4550
   #define EX     0x4558
   #define ET     0x4554
   #define RB     0x5242
   #define TX     0x5458
   #define CN     0x434E
   #define RH     0x5248
   #define OP     0x4F50
   #define CL     0x434C
   #define GS     0x4753
   #define SH     0x5348
   #define RL     0x524C
   #define WM     0x574D

/*---------------------*/
/* Server Return Codes */
/*---------------------*/
   #define EXTENDED_ERROR    0x01004545         /* 'EE' Extended error       */

/*-------------*/
/* Field types */
/*-------------*/
   #define timestamp_null    393                /* timestamp nulls allowed   */

/*----------------*/
/* SQL statements */
/*----------------*/
   #define create_table "\
create table landptable (col1 datetime year to fraction (5), col2 char(15) NOT NULL)"

   #define select_stmt "\
select * from landptable where col1 matches \"*ZZZZZ*\"" 

   #define drop_table "\
drop table landptable"

   #define beginwork"\
begin work"

   #define rollback"\
rollback work"

   #define table_qname  "landptable"

   #define charsample      "Query Server   "

   #define table_name  "landpsfile          "

   #define pcb001      "  pcb001"
   #define column_name "col001              "
   #define com_op_ge   "ge"

   #define REV          0x0000
   #define NUMF         0x0001
   #define CTYP         0x01c4
   #define FLEN         0x000a  

   #define replacedata "AAAAAAAAAA00015"
   #define timestampsample "AAAAAAAAAA00015"
   #define nulltimestamp   "BBBBBBBBBB00015"
   #define shfdata         "EEEEE00012"
   #define shfkey          "DDDDD00011"


   #define Shffile        "landpsfile"
   #define ShfFileid      "  pcb001"
   #define ShfWrbuf       "GGGGG00002"
   #define ShfFilekey     "FFFFF     "
   #define COBAPNAME      "cobap"

