/*******************************************************************************
 *                                                                             *
 * Program name : EHCDEFC.H                                                    *
 *                                                                             *
 * Release :      LANDP/6000 Rel. 1.0                                          *
 *                                                                             *
 * Copyright :    5765-076 Version 1.0  (C) IBM Corp. 1993                     *
 *                Licensed Material - Program Property of IBM                  *
 *                                                                             *
 * Description :  Include file to declare:                                     *
 *                   - The CPRB.                                               *
 *                   - The routines:                                           *
 *                      . RMTREQ                                               *
 *                      . RMTAREQ                                              *
 *                      . GETREQ                                               *
 *                      . RMTRPLY                                              *
 *                      . SRVINIT                                              *
 *                   - Several general-purpose constants.                      *
 *                                                                             *
 ******************************************************************************/

/* The CPRB definition */
typedef struct {
   unsigned char  ehc_reserved1[4];         /*                                        */
   unsigned long  ehcretcode;               /* Router return code                     */
   unsigned char  ehcverb_type;             /* Verb type                              */
   unsigned char  ehc_reserved2;            /*                                        */
   unsigned short ehcfunct;                 /* Function ID                            */
   unsigned short ehctimeout;               /*                                        */
   unsigned short ehcqparml;                /* Request parameter length               */
   void     *     ehcqparmad;               /* Request parameter address              */
   unsigned short ehcqdatal;                /* Request data length                    */
   void     *     ehcqdataad;               /* Request data address                   */
   unsigned short ehcrparml;                /* Reply parameter length                 */
   void     *     ehcrparmad;               /* Reply parameter address                */
   unsigned short ehcrdatal;                /* Reply data length                      */
   void     *     ehcrdataad;               /* Reply data address                     */
   unsigned char  ehc_reserved4[2];         /*                                        */
   unsigned long  ehcservrc;                /* Server return code                     */
   unsigned short ehcrepldplen;             /* Replied parameter length               */
   unsigned short ehcreplddlen;             /* Replied data length                    */
   unsigned char  ehcpc_id[2];              /* Requesting PC. Set by router.          */
   unsigned char  ehcresource_origin[8];    /* Resource origin. Reserved for servers. */
   unsigned char  ehcdest_pc_id[2];         /* Destination PC. Reserved for servers   */
   unsigned char  ehc_reserved5[6];         /*                                        */
   unsigned char  ehcfirst_pc_origin[2];    /* First PC origin on server to server    */
   unsigned char  ehcfirst_res_origin[8];   /* First resource origin on ser.to ser.   */
   unsigned char  ehcfields_meaningful;     /* !0 If ser.to ser. fields meaningful    */
   unsigned char  ehc_reserved6[1];         /*                                        */
   unsigned short ehcfirst_pid_origin;      /* First PID origin on server to server   */
   unsigned char  ehc_reserved7[4];         /*                                        */
   unsigned short ehcpid_origin;            /* PID of the origin process              */
   unsigned short ehcpid_dest;              /* PID of the destination process         */
   unsigned char  ehc_reserved8[6];         /*                                        */
   unsigned short ehcservnamlen;            /* Number of bytes for server name.       */
   char           ehcserver[8];             /* Destination server name.               */
} EHC_CPRB;
typedef EHC_CPRB     * EHC_CPRBP;

/***************************************************************/
/*                     Return Codes                            */
/***************************************************************/

/****************************************************************
* The return code constants, their hexadecimal values and       *
* their meanings are as follows:                                *
*                                                               *
* UERERROK      0x00000000  Successful                          *
* UERERRT1START 0x01000402  not started                         *
* UERERRT1LOAD  0x01000404  not loaded                          *
* UERERRT1BUSY  0x01000408  busy                                *
* UERERRT1VER   0x0100040A  Unsupported version ID              *
* UERERRT1EMU   0x0100040C  PC 3270 Emulation not loaded        *
* UERERRT1QPLEN 0x01000602  Request parameters length too large *
* UERERRT1RPLEN 0x01000604  Reply parameters length too large   *
* UERERRT1VERB  0x01000606  Invalid verb type                   *
* UERERRT1SERV  0x01000608  Invalid server name                 *
* UERERRT1QPAD  0x0100060C  Invalid request parameters address  *
* UERERRT1QDAD  0x0100060E  Invalid request data address        *
* UERERRT1RPAD  0x01000610  Invalid reply parameters address    *
* UERERRT1RDAD  0x01000612  Invalid reply data address          *
* UERERRT1TOPV  0x01000616  TOPVIEW not supported               *
* UERERRT1CNCL  0x01000802  Cancelled by host                   *
* UERERRT1CONV  0x01000C00  Unable to maintain conversation     *
* UERERRT1ISE   0x01000C02  Internal software error             *
* UERERRT1PROT  0x01000C04  Protocol violation                  *
* UERERRT1SYIN  0x01000C06  System inconsistency                *
*                                                               *
* UERERRT2      0x02        Error Type 2 - acknowledge sent     *
* UERERRT3      0x03        Error Type 3 - acknowledge received *
****************************************************************/
#define UERERROK       0x00000000
/* Type 1 Errors */
#define UERERRT1START  0x01000402
#define UERERRT1LOAD   0x01000404
#define UERERRT1BUSY   0x01000408
#define UERERRT1VER    0x0100040A
#define UERERRT1EMU    0x0100040C
#define UERERRT1QPLEN  0x01000602
#define UERERRT1RPLEN  0x01000604
#define UERERRT1VERB   0x01000606
#define UERERRT1SERV   0x01000608
#define UERERRT1QPAD   0x0100060C
#define UERERRT1QDAD   0x0100060E
#define UERERRT1RPAD   0x01000610
#define UERERRT1RDAD   0x01000612
#define UERERRT1TOPV   0x01000616
#define UERERRT1CNCL   0x01000802
#define UERERRT1CONV   0x01000C00
#define UERERRT1ISE    0x01000C02
#define UERERRT1PROT   0x01000C04
#define UERERRT1SYIN   0x01000C06

/****************************************************************
* For type 2 and type 3 errors the most significant byte of     *
* the return code is 0x02 and 0x03 respectively.  The 3 remain- *
* ing bytes are the Exception Class, Exception Code, and        *
* Exception Object sent or received in the Acknowledge.         *
****************************************************************/
#define UERERRT2 0x02
#define UERERRT3 0x03

/* The constant wich defines the reserved variables */
   #define EHC_RESERVED 0L

  typedef struct {
    long  struc_size;                          /* Size of this structure.    */
    char * service_name_list;                  /* pointer to service names   */
  } EHC_SRVINIT_OPTS;

  typedef EHC_SRVINIT_OPTS  *EHC_SRVINIT_OPTSP;

/*****************************/
/* LANDP function prototypes */
/*****************************/

   int RMTREQ  (EHC_CPRBP, unsigned long);
   int GETREQ  (EHC_CPRBP, unsigned long);
   int RMTRPLY (EHC_CPRBP, unsigned long);
   int RMTAREQ (EHC_CPRBP, unsigned long);
   int SRVINIT (int, int, void *, EHC_SRVINIT_OPTSP);
