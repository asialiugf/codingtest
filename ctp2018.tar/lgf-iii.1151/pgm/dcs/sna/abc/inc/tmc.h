#ifndef H_TMC
#define H_TMC
/* ---------------------- CONSTANT DEFINITION -----------------------------*/
#define  WHITE " \t\n"
#define  ALL_IDX 999
#define  MON_RCV_TYPE 20
#define  MON_RCV_TIMEOUT 5
#define  MON_TXN_CODE "8888"

/* limit for configuration file */
#define  MAX_FORK_PROC	50	/* maxmun process can be forked a time */
#define  MAX_PARAS	30	/* maxmun parameters per process to pass */
#define  MAX_CONF_LINE_LEN	300	/* max line length in config file */
#define  MAX_PRG_NAME_LEN	20	/* max length of forked program name */
#define  MAX_PARA_LEN	250	/* maxmun length of total parameters */
#define  MAX_EXEC_PATH_LEN	80	/* maxmun exec path length */
#define  MAX_TABLE_ARRAY	30	/* max config entry */
#define  MAX_FORK_PERTIME	10	/* a program can be forked a time */

/* forked process status */
#define  PRC_NORMAL	'0'	/* process normal */
#define  PRC_FORK_OK	'1'	/* process fork ok */
#define  PRC_FORK_ERR	'a'	/* process fork error */
#define  PRC_EXEC_OK	'2'	/* process execv ok */
#define  PRC_EXEC_ERR	'b'	/* process execv error */
#define  PRC_KILL_OK	'3'	/* process killed ok */
#define  PRC_KILL_ERR	'c'	/* process killed error */
#define  PRC_SHUTDOWN_OK	'4'	/* process shutdown ok */
#define  PRC_SHUTDOWN_ERR	'd'	/* process shutdown error */
#define  PRC_RESTART_OK	'5'	/* process restart ok */
#define  PRC_RESTART_ERR	'e'	/* process restart error */
#define  PRC_DEAD	'f'	/* process dead */
#define  PRC_UNFORK	'g'	/* process no fork */
#define  PRC_RCV_PASS	'p'	/* process rcv to do nothing & pass back */

/* command of monitor process accepted */
#define  TPE_SHUTDOWN 	'1'	/* shutdown down the EMS */
#define  TPE_QUCKSHUT 	'2'	/* abnormal shutdown down the EMS */
#define  TPE_DOBATCH  	'3'	/* Online -> Batch     */
#define  TPE_SERV_MG    '4'     /* tpe server management  */
#define  TPE_TOOLS      '5'     /* tpe tools main menu entry   */
#define  MON_QURY 	'6'	/* control process queray all forked process
				   status from monitor */
#define  MON_RESTART	'7'	/* forked process request monitor to restart
                                   itself again */
#define  MON_FORK	'8'	/* control process request monitor to fork a
				   process */
#define  MON_SHUTDOWN	'9'	/* request monitor to shutdown a process or all
                                   process */
#define  MON_KILL	'A'	/* control process request monitor to kill
                                   a process */
#define  TPE_DUMPCWA  	'B'	/* dump the cwa core      */
#define  TPE_DUMPBIT  	'C'	/* dump the bit core      */
#define  TPE_DOCHRON  	'D'	/* Run the Chron program  */
#define  MON_STOP  	'E'	/* temp for test shutdown  */

/* monitor error code */
#define MON_NORMAL		0	/* monitor process normal */
#define MON_READ_FILE_ERR	1	/* read configuration file or tmp file
					   error */
#define MON_LOAD_OVERFLOW	2	/* table array is overflow */
#define MON_CP_CFG_FILE_ERR	3	/* cp tmp file error */
#define MON_FORK_ERR		4	/* fork process error */
#define MON_EXEC_ERR		5	/* execv process error */
#define MON_RCV_STAT_ERR	6	/* recv response from forked process
					   error */
#define MON_OPEN_Q_ERR		7	/* open iq error */
#define MON_READ_Q_ERR		8	/* read queue error */
#define MON_READ_Q_TIMEOUT_ERR	9	/* read iq timeout error */
#define MON_WRITE_Q_ERR		10	/* write queue error */
#define MON_COMM_ERR		11	/* command code error */
#define MON_KILL_ERR		12	/* kill forked process error */
#define MON_SHUTDOWN_ERR	13	/* shutdown forked process error */
#define MON_DCS_ERR		14	/* call dcs module error */
#define MON_GETOKEN_ERR		15	/* get token for execv argv error */
#define MON_CMD_ERR		16	/* wait cmd dcs rcv data error */
#define MON_PROC_OVERFLOW	17	/* table array is overflow */
#define MON_PARA_OVERFLOW	18
#define MON_CNFG_ERR		19
#define MON_PROC_OVERLIMIT	20	/* table array is overflow */
#define MON_UNWK_OVERFLOW	21
#define MON_RESTART_LIMIT_ERR	22

#define  CFGTBL_SIZE (sizeof(struct CfgTbl) * MAX_TABLE_ARRAY)
#define  CRNTBL_SIZE (sizeof(struct ChronTbl) * MAX_TABLE_ARRAY)
#define  FOKTBL_SIZE (sizeof(struct FokTbl) * (MAX_FORK_PROC+1))
#define  MDA_SHM_SIZE    (CFGTBL_SIZE + CRNTBL_SIZE + FOKTBL_SIZE)
#define  SHM_KEY 0x99

#define MCfg(i)	pstMda->stCfgTbl[(i)]
#define MFok(i)	pstMda->stFokTbl[(i)]
#define MCrn(i)	pstMda->stChronTbl[(i)]
/* ---------------------- CONSTANT DEFINITION -----------------------------*/
struct CfgTbl{
         int  iFkLimitPerTime;	/* can fork max process per time */
         int  iForkprc;	/* fork time of this programm */
         int  iUnWorkno;	/* now work process number */
         int  piaUnWkidx[MAX_FORK_PERTIME];/* unwork proc idx in fork table */
         int  iFstFokNo;	/* the first fork number */
         int  iRestartno;	/* can be restarted times unmber */
         char cProtocolType;	/* forked process' protocol type */
         char caDesCode[10];	/* forked process' destination code */
         char caPrgname[MAX_PRG_NAME_LEN];	/* program name */
         char caPara[MAX_PARA_LEN];	/* parameters for forked process */
       };
 
struct ChronTbl{ 
         int  iFkLimitPerTime;	/* can fork max process per time */
         int  iForkprc;	/* fork time of this programm */
         int  iUnWorkno;	/* now work process number */
         int  piaUnWkidx[MAX_FORK_PERTIME];/* unwork proc idx in fork table */
         int  iFstFokNo;	/* the first fork number */
         int  iRestartno;	/* can be restarted times unmber */
         char caPrgname[MAX_PRG_NAME_LEN];	/* program name */
         char caPara[MAX_PARA_LEN];	/* parameters for forked process */
 	 int  iChronType;       /* defined (AT) type or period type */
 	 char caMonth[2];       /* invoke month ** means every month */
	 char caWeek[3];        /* invoke weekday (0-6)=(Sunday-Saturday)*/
	 char caDay[2];         /* invoke day   ** means everyday  */
	 char caTime[4];        /* invoke time hhmm (AT)           */
         int  iPeriod;   	/* invoke period ,the unit is 10 sec.  */
	 int  iRestTime;        /* invoke rest time, the unit is 10 sec. */
	};


struct FokTbl{ /* load fork programm configuration file structuer */
         int  iServType;        /* server process type:0(Normal);1(Chron) */
         int  iTblidx;	        /* index in CfgTbl or ChronTbl */
         int  iProcid;	/* process id */
         int  iForktime;	/* fork time of this programm */
         char cStatus;	/* process status */
         int  iMonerr;	/* monitor error no */
         int  iErrno;	/* errno */
       };

struct MonCmd{	/* monitor accepted command structur */
         char caTblidx[5];/* number in table array of forked process */
         char cCmd;	/* commmand to monitor process */
       };

struct FkdStat{	/* monitor & forked process pass status structur */
         char caTblidx[5];/* number in table array of forked process */
         char cStatus;/* commmand to monitor process */
       };

struct CtlStat{	/* monitor & control pass status structur */
         char caTblidx[5];/* number in table array of forked process */
         char cStatus;	/* process status */
         int  iMonerr;	/* monitor error no */
         int  iErrno;	/* errno */
       };
#endif
