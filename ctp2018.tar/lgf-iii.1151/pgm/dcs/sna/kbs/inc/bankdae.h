/*
#define III_DIR		"/home/iii/tpe"
*/
#define EXE_PATH	"/iii/bin/exe/"
#define EXE_FILE	"dcxpsuio.x"
#define PRINT_TMP
#define TMP_PRINT_PATH  "/iii/log"
#define TMP_PRINT_FILE  "Prn"

#define MAXFD           64 /* Maxmum connection */
#define SESSION_PORT    7880
#define SUPER_PORT      7890
#define HEADER_LEN      8

#define KIND_SIGNON     'S' /* DBP sign on */
/********
	4 byres     1 byte      3 bytes       2 bytes
+-----------+----------+-------------+---------------+
| Teller ID | Priority | Branch Code | Terminal Code |
+-----------+----------+-------------+---------------+
********/

#define KIND_SIGNOFF		's'
/********
No data
********/

#define KIND_CNFRQ      'M' /* Teller request manager */
#define KIND_CNFACK     'T' /* Manager confirm teller */

/********
   4 byte      4 bytes         4 bytes       1 byte
+-----------+------------+----------------+----------+---------
| Teller ID | Manager ID | Transaction ID | Priority | Data
+-----------+------------+----------------+----------+---------
********/

#define KIND_BROAD      'B' /* Brodacast request */
/********
+------------
| Message
+------------
********/

#define KIND_TOKEN      'O' /* Token for send data to DBP */
#define MODE_LOCK       'L' /* Lock mode: Nothing can send to DBP */
#define MODE_FREE       'F' /* Free mode: Any data can send to DBP */
/********
 1 byte
+------+
| Mode |
+------+
********/

#define KIND_DAEMON     't' /* Daemon send ACK. to DBP */
#define STATE_BUSY      'B' /* Manager is busy */
#define STATE_NOTFIND   'N' /* Manager not sign on */
#define STATE_WAITCNF   'W' /* Wait confirm from manager */
#define STATE_NOPV      'X' /* No privage to confirm */
#define DAEMON_ACKLEN   HEADER_LEN + 5
/********
   4 bytes     1 byte
+------------+--------+
| Manager ID | Status |
+------------+--------+
********/

#define KIND_PSWDRQ     'I' /* Password check request */
/********
   4 byte      4 bytes      8 bytes
+-----------+------------+----------+
| Teller ID | Manager ID | Password |
+-----------+------------+----------+
********/

#define KIND_PSWDACK    'i' /* Password check Ack. */
#define PSWD_YES        'Y' /* Password is correct */
#define PSWD_NO         'N' /* Password is wrong */
#define PSWD_MAN	'R' /* not a manager */
/********
   4 byte      4 bytes    1 bytes
+-----------+------------+--------+
| Teller ID | Manager ID | Status |
+-----------+------------+--------+
********/

#define KIND_PRINT      'P' /* Remote print request */
#define CMD_BEGIN       'B' /* Beginning of print package */
#define CMD_PRINT       'P' /* Print data package(s) */
#define CMD_END         'E' /* Ending of print package */
/********
   1 byte   1 byte   0 to 255 bytes
+---------+--------+------------
| Command | Length | Data
+---------+--------+------------
********/

#define KIND_LU0        'L' /* LU0 status return from dcxdaemon.x */
#define LU0_BROKEN      'B' /* LU0 line broken */
#define LU0_ON          'R' /* LU0 line recovery */
/********
	 3 bytes        2 bytes      1 byte
+-------------+---------------+--------+
| Beanch Code | Terminal Code | Status |
+-------------+---------------+--------+
********/

#define KIND_LU0CON		'C'
/********
    3 bytes        2 bytes
+-------------+---------------+
| Beanch Code | Terminal Code |
+-------------+---------------+
********/

#define KIND_KILLDAE    'K' /* Kill daebank.x request */

/*
#define CONFIRM_TABLE   "/iii/etc/tbl/confirm.tbl"
#define PRIORITY_TABLE  "/iii/etc/tbl/priority.tbl"
#define TMP_PRINT_PATH  "/iii/log"
#define CONFIRM_TABLE   "/confirm.tbl"
#define PRIORITY_TABLE  "/priority.tbl"
*/

#define SOCKSIZE        8192
#define BUFSIZE         16384

#define DATA_MORE       0  /* Identify packet's headre 'more' */
#define DATA_KIND       1  /* Identify packet's header 'kind' */
#define DATA_TYPE       2  /* Identify packet's header 'type' */
#define DATA_LENGTH     3  /* Identify packet's header 'length' */
#define DATA_BODY       4  /* Identify packet's data body */

#define TYPE_DBP	'D'
#define	TYPE_LU0	'L'

char		III_DIR[256];
char            sess_errmsg[256];
int             show_flag;
int             port_flag,session_port;

int             remote_sock,local_super_sock;
int             monitor_sock[MAXFD];

/*
int             local_erg_sock[2];
*/

struct {
        int     r_fd;
        int     l_fd[2];
        char    id[5];
        char    bcode[4];
	char    tcode[3];
        char    power;
        char    mode;
        FILE    *prn;
        char    file[256];
	char	type;
	int	cid;
        } fileset[MAXFD];

struct {
	char    tid[5];
        char    mid1[5];
        char    mid2[5];
        } confirm[MAXFD];

struct {
        char    id[5];
        double  total;
        double  ratio;
        char    pswd[32];
        } manager[MAXFD];

int             remote_read_length[MAXFD],remote_read_off[MAXFD];
int             remote_read_type[MAXFD],remote_data_length[MAXFD];
int             r_resend_off[MAXFD],r_resend_length[MAXFD];
char            r_resend[MAXFD];
char            *remote_read_buf[MAXFD],*local_read_buf[MAXFD];;
