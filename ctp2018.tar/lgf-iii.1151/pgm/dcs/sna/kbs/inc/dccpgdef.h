/*****************************************************************/
/*
*		UCP_TRACE function code
*/
#define	P_DcmS_R		61101		/* source : dcmappc.c */
#define P_DcsMrg		61102
#define P_ChkSess		61103
#define P_writeinfo		61104
#define P_MrgStart		61105
#define	P_MrgConn		61106
#define	P_MrgWrite		61107
#define P_MrgRead               61108
#define P_longnull              61109
#define P_sendOKtpu             61110
#define P_writeiqueqe           61111

#define	P_DcsStart		61201		/* source : dcsfunc.c */
#define	P_DcsConnect		61202
#define	P_DcsWrite		61203
#define	P_DcsRead		61204
#define	P_DcsDisConnect		61205
#define	P_DcsUcps		61206
#define P_display_log           61207
#define P_write_qf              61208
#define P_SendOK                61209
#define P_DcsStop               61210
#define P_Esnaopen              61211
#define P_Esnalloc              61212
#define P_Esnawrite             61213
#define P_Esnaread              61214
#define P_set_pu_lu_value       61215
#define P_get_pu_lu_parm        61216
#define P_dependOnUser          61217
#define P_Ucpu                  61218

#define	P_str_parser		61301		/* program : dcsinit.c */
#define P_ProfToken		61302
#define	P_GetShmEntry		61303
#define P_ipcinit		61304

/* dcsitfce.c */
#define P_dcsrecve 		61401
#define P_dcsrecveall 		61402
#define P_dcssend 		61403
#define P_dcssendisconect 	61404
#define P_dcssrses 		61405
#define P_dcsstart 		61406
#define P_dcsstop 		61407
#define P_dcsstopa 		61408
#define P_dcsswerr 		61409
#define P_dcs_display_log	61410
#define P_dsp_dcs_twa 		61411
#define P_get_proto_by_des 	61412
#define P_load_proto_table 	61413
#define P_null 			61414
#define P_sbdcs 		61415
#define P_srh_proto_table 	61416

#define  P_upsifcnv             61501           /* program : dcsifcnv.c */
#define  P_apsifcnv             61502
#define  P_iosifcnv             61503

#define  P_dcsofcnv             61601           /* program : dcsofcnv.c */
#define  P_apsofcnv             61602

/* dcstopnd.c */
#define P_dcs_topend 		64001
#define P_dcs_tp_accept 	64002
#define P_dcs_tp_connect 	64003
#define P_dcs_tp_disconnect 	64004
#define P_dcs_tp_initial 	64005
#define P_dcs_tp_receive 	64006
#define P_dcs_tp_reinitial 	64007
#define P_dcs_tp_send 		64008
#define P_dcs_tp_send_disconnect	64009
#define P_dcs_tp_terminate 	64010
#define P_def_services 		64011
#define P_space_fill 		64012
#define P_srh_prod_fun_name 	64013
#define P_load_prodfun_table	64014

/* dcsocket.c */
#define P_dcs_sk_accept 	65001
#define P_dcs_sk_connect 	65002
#define P_dcs_sk_disconnect 	65003
#define P_dcs_sk_initial 	65004
#define P_dcs_sk_receive 	65005
#define P_dcs_sk_send 		65006
#define P_dcs_sk_terminate 	65007
#define P_dcs_socket 		65008
#define P_get_host_serv_name 	65009
#define P_load_sk_network_table		65010
#define P_srh_sk_netwktbl 	65011

/* dcsqueue.c */
#define P_dcs_qu_accept 	66001
#define P_dcs_qu_b_recfrom 	66002
#define P_dcs_qu_b_sendto 	66003
#define P_dcs_qu_connect 	66004
#define P_dcs_qu_disconnect 	66005
#define P_dcs_qu_initial 	66006
#define P_dcs_qu_receive 	66007
#define P_dcs_qu_receivefrom 	66008
#define P_dcs_qu_send 		66009
#define P_dcs_qu_sendto 	66010
#define P_dcs_qu_terminate 	66011
#define P_dcs_queue 		66012
#define P_get_qkey_qtype 	66013
#define P_load_qu_network_table 	66014
#define P_srh_qu_netwktbl 	66015

/* dcserver.c */
#define P_srh_netwktable 		67001
#define P_get_poto_serv_by_des 		67002
#define P_put_serv_name_to_data 	67003
#define P_dcs_server			67005

/* largtest.c */
#define P_Mlargtest 		69001
#define P_get_sif 		69002
#define P_output_errmsg 	69003
#define P_remote_tst 		69004
#define P_RMTDCS                69005

/* dcsq_tool.c */
#define P_dsp_q_info 		69901
#define P_dcs_msgq_creat 	69902
#define P_dcs_msgq_get 		69903
#define P_dcs_msgq_init 	69904
#define P_dcs_msgq_read 	69905
#define P_dcs_msgq_remove 	69906
#define P_dcs_msgq_write 	69907
#define P_rm_tmpfile 		69908
