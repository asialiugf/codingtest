#include  "big2host.h"
#include  "errlog.h"
#include  "dccpgdef.h" 
#include "dcs.h"
/*********************************************************************/
/* PROGRAM-NAME:dcsifcnv.c                                           */
/* PROGRAM-ID:                                                       */
/* LAST-UPDATE-DATE:                                                 */
/* AUTHOR :Ta-Wei YEN  801221                                        */
/* THE MAN WHO MOFIDIED: Chih-Liang WU                               */
/*********************************************************************/
/*
#define  SIF_TTYPE_LEN               4
#define  SIF_TCODE_LEN               4
#define  SIF_BRCODE_LEN              3
#define  SIF_TMCODE_LEN              2
#define  SIF_TLCODE_LEN              2
#define  SIF_TCODE_OFF               4
#define  SIF_BR_OFF                  8
#define  SIF_TM_OFF                 11
#define  SIF_TELL_OFF               13
#define  SIF_HEAD_LEN               15
#define  SIF_NO_OFFS                15
#define  SIF_CTL_OFFS               16
#define  SIF_SEQ_OFFS               16
#define  SIF_DATA_OFFS              19
#define  OFFLINE_TM_CODE            "51"
*/


#define  SIF_TTYPE_LEN               4
#define  SIF_TCODE_LEN               6
#define  SIF_BRCODE_LEN              10
#define  SIF_TMCODE_LEN              4
#define  SIF_TLCODE_LEN              4

#define  SIF_TCODE_OFF               4
#define  SIF_BR_OFF                  10
#define  SIF_TM_OFF                  20
#define  SIF_TELL_OFF                24

#define  SIF_HEAD_LEN                51
#define  SIF_NO_OFFS                 48
#define  SIF_CTL_OFFS                49

#define  SIF_SEQ_OFFS                51
#define  SIF_DATA_OFFS               53
#define  OFFLINE_TM_CODE             "51"

#define err_log   ErrLog
#define MSG_STR g_caMsg

#define  swapshort(X)              X=((X>>8)&0x00FF)|((X<<8)&0xFF00)
#ifdef  OMIT
#define  swapshort(X)              X=X
#endif

extern struct table_array cnv_tbl;
extern struct table_array *cnv_ptr;


int
Big5ToHostSif(unsigned char *pbaUnixSif,unsigned char *pbaHostSif,
              int *piSifLen)
{
  short data_len,cnv_len;
  int   i,iUnixSifNo,iHostSifNo;
  static int iFirst = 1;

  char  txn_code[5];

  UCP_TRACE(10000);
/*
  sprintf(MSG_STR,"CONV BIG5 CODE Big5ToHostSif.Start");
  err_log(100,MSG_STR,RPT_TO_LOG,pbaUnixSif,*piSifLen);
*/
/*
  err_log(100,"BigToHost(Init_Cvt_Table):dump",RPT_TO_LOG,cnv_ptr,200);
*/
/*mark by eric 830923
  memcpy( &pbaUnixSif[0], "UCPU",4);
*/
  memcpy(txn_code,pbaUnixSif+4,4);
  txn_code[4] = '\0';


  if ( (i = big5_host(pbaUnixSif,pbaHostSif,SIF_HEAD_LEN,cnv_ptr))
        !=SIF_HEAD_LEN )
  {
    sprintf(MSG_STR,"SIF head code conversion error len=%d !",i);
    err_log(2000,MSG_STR,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  }

  memcpy(pbaHostSif+SIF_NO_OFFS,pbaUnixSif+SIF_NO_OFFS,3); 

/*marked by eric 830924
  pbaHostSif[ SIF_NO_OFFS ]  =  0x00;       
  memcpy(pbaHostSif+SIF_NO_OFFS+1,pbaUnixSif+SIF_NO_OFFS,2); 
 */

   /* begin to convert the SIF data part */
/*marked by eric 830924
  pbaHostSif[ SIF_NO_OFFS + 2 ] = 0x00 ;
  pbaHostSif[ SIF_NO_OFFS + 3 ] = 0x00 ;
*/

  for ( iUnixSifNo = SIF_SEQ_OFFS,iHostSifNo = SIF_SEQ_OFFS ; 
        iUnixSifNo < *piSifLen; )
  {

    data_len = pbaUnixSif[ iUnixSifNo ] * 256
             + pbaUnixSif[ iUnixSifNo + 1 ];

    if( data_len == 999 )
      break;

    if ( (data_len + iUnixSifNo + 2) > *piSifLen) {
      sprintf(MSG_STR,"sif item length error, final offset=%d",
              data_len + iUnixSifNo + 2);
      err_log(1001,MSG_STR,RPT_TO_LOG,0,0);
      UCP_TRACE_END(-1);
    }

#ifdef OMIT
   err_log(10,"dcsiftxf.big5_host",RPT_TO_LOG,pbaUnixSif+iUnixSifNo+2,data_len);
#endif

    cnv_len  =  big5_host(pbaUnixSif+iUnixSifNo+2,pbaHostSif+iHostSifNo+2,
                          data_len,cnv_ptr);

#ifdef OMIT
   err_log(10,"dcsiftxf.big5_host",RPT_TO_LOG,pbaHostSif+iHostSifNo+2,cnv_len);
#endif

    pbaHostSif[ iHostSifNo ]  =  cnv_len / 256;
    pbaHostSif[ iHostSifNo + 1 ]  =  cnv_len % 256;

    iUnixSifNo  =  iUnixSifNo+2 + data_len;
    iHostSifNo  =  iHostSifNo+2 + cnv_len;
  }

  *piSifLen  =  iHostSifNo ;
/*
  sprintf(MSG_STR,"Big5ToHostSif.NormalEnd");
  err_log(100,MSG_STR,RPT_TO_LOG,pbaHostSif,*piSifLen);
*/
  UCP_TRACE_END(0);
}



int
HostToGbSif(unsigned char *pbaUnixSif,unsigned char *pbaHostSif,
              int *piSifLen)
{
  short data_len,cnv_len;
  int   i,iUnixSifNo,iHostSifNo;
  static int iFirst = 1;

  char  txn_code[5];

  UCP_TRACE(10000);

  sprintf(MSG_STR,"CONV BIG5 CODE HostToGb.Start");
  err_log(100,MSG_STR,RPT_TO_LOG,pbaUnixSif,*piSifLen);

/*
  err_log(100,"BigToHost(Init_Cvt_Table):dump",RPT_TO_LOG,cnv_ptr,200);
*/
/*mark by eric 830923
  memcpy( &pbaUnixSif[0], "UCPU",4);
*/
  memcpy(txn_code,pbaUnixSif+4,4);
  txn_code[4] = '\0';


  if ( (i = host_big5(pbaUnixSif,pbaHostSif,SIF_HEAD_LEN,cnv_ptr))
        !=SIF_HEAD_LEN )
  {
    sprintf(MSG_STR,"SIF head code conversion error len=%d !",i);
    err_log(2000,MSG_STR,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  }

  memcpy(pbaHostSif+SIF_NO_OFFS,pbaUnixSif+SIF_NO_OFFS,3); 

/*marked by eric 830924
  pbaHostSif[ SIF_NO_OFFS ]  =  0x00;       
  memcpy(pbaHostSif+SIF_NO_OFFS+1,pbaUnixSif+SIF_NO_OFFS,2); 
 */

/*marked by eric 830924
  pbaHostSif[ SIF_NO_OFFS + 2 ] = 0x00 ;
  pbaHostSif[ SIF_NO_OFFS + 3 ] = 0x00 ;
*/

  for ( iUnixSifNo = SIF_SEQ_OFFS,iHostSifNo = SIF_SEQ_OFFS ; 
        iUnixSifNo < *piSifLen; )
  {

    data_len = pbaUnixSif[ iUnixSifNo ] * 256
             + pbaUnixSif[ iUnixSifNo + 1 ];

    if( data_len == 999 )
      break;

    if ( (data_len + iUnixSifNo + 2) > *piSifLen) {
      sprintf(MSG_STR,"sif item length error, final offset=%d",
              data_len + iUnixSifNo + 2);
      err_log(1001,MSG_STR,RPT_TO_LOG,0,0);
      UCP_TRACE_END(-1);
    }

#ifdef OMIT
   err_log(10,"dcsiftxf.big5_host",RPT_TO_LOG,pbaUnixSif+iUnixSifNo+2,data_len);
#endif

    cnv_len  =  host_big5(pbaUnixSif+iUnixSifNo+2,pbaHostSif+iHostSifNo+2,
                          data_len,cnv_ptr);

    memset(pbaHostSif+iHostSifNo+2+cnv_len,' ',data_len-cnv_len);  

#ifdef OMIT
   err_log(10,"dcsiftxf.big5_host",RPT_TO_LOG,pbaHostSif+iHostSifNo+2,cnv_len);
#endif

    pbaHostSif[ iHostSifNo ]  =  data_len / 256;
    pbaHostSif[ iHostSifNo + 1 ]  =  data_len % 256;

    iUnixSifNo  =  iUnixSifNo+2 + data_len;
    iHostSifNo  =  iHostSifNo+2 + data_len;
  }

  *piSifLen  =  iHostSifNo ;
/*
  sprintf(MSG_STR,"Big5ToHostSif.NormalEnd");
  err_log(100,MSG_STR,RPT_TO_LOG,pbaHostSif,*piSifLen);
*/
  UCP_TRACE_END(0);
}





