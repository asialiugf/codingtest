#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <memory.h>
#include <string.h>
#include <malloc.h>
#include <sys/types.h>
#include <sys/time.h>
/*
#include <sys/select.h>
*/
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include "bankdae.h"
#include "bankdae.err"

int	ConnectToBankDae(bcode,tcode)
char*	bcode;
char*	tcode;
{
        int			fd;
        struct sockaddr_in      srv;
	char			buf[256];

        if ((fd = socket(AF_INET,SOCK_STREAM,0)) < 0)
                return(SOCKET_ERR);

	srv.sin_family = AF_INET;
	srv.sin_port = htons(SUPER_PORT);
	srv.sin_addr.s_addr = inet_addr("127.0.0.1");
	if (connect(fd,(struct sockaddr *)&srv,sizeof(srv))<0)
        {
                close(fd);
                return(CONNECT_ERR);
        }

	memset(buf,'0',sizeof(buf));

	/* Define DCS header (8 bytes) */
	buf[0] = '0';
	buf[1] = KIND_LU0CON;
	buf[2] = 'S';
	buf[3] = buf[4] = buf[5] = '0';
	buf[6] = '1';
	buf[7] = '3';
	memcpy(buf+HEADER_LEN,bcode,3);
	memcpy(buf+HEADER_LEN+3,tcode,2);

	if (write(fd,buf,13) < 13)
	{
		close(fd);
		return (SEND_ERR);
	}
	return (fd);
}

int	StatusToBankDae(fd,bcode,tcode,status)
int	fd;
char	*bcode;
char	*tcode;
char	status;
{
	char	buf[256];

	memset(buf,'0',sizeof(buf));

	/* Define DCS header (8 bytes) */
	buf[0] = '0';
	buf[1] = KIND_LU0;
	buf[2] = 'S';
	buf[3] = buf[4] = buf[5] = '0';
	buf[6] = '1';
	buf[7] = '4';
	memcpy(buf+HEADER_LEN,bcode,3);
	memcpy(buf+HEADER_LEN+3,tcode,2);
	buf[HEADER_LEN+5] = status;

	if (write(fd,buf,14) < 14)
		return (SEND_ERR);

	return (SUCCESS);
}

int	StatusFromBankDae(fd)
int	fd;
{
	fd_set		rmask;
	struct timeval	wtime;

	if (fd < 0)
		return (FD_ERR);

	FD_ZERO(&rmask);
	FD_SET(fd,&rmask);

	wtime.tv_sec = 0L;
	wtime.tv_usec = 0L;

	switch (select(fd+1,&rmask,0,0,&wtime))
	{
		case 0:
			return 0;
		case 1:
		{
			char	buf[32];

			memset(buf,0,sizeof(buf));
			if (read(fd,buf,1) < 1)
				return (PIPE_ERR);
			if (*buf == '2')
				return (2);
			else
				return (1);
		}
		default:
			return (SELECT_ERR);
	}
}
