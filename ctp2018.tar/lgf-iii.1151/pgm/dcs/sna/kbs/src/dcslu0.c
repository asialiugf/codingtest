/*Stanley CHAO: 2/13/95 */
#define iDEBUG

/********
#define NAUTOLOGON
#define AUTOLOGON
********/

#include <eicon/snadef.h>       /* SNA FUNCTION external definitions    */
#include <eicon/snarc.h>        /* SNA FUNCTION return codes            */
#include <errno.h>              /* global error numbers                 */
#include <fcntl.h>              /* for using file permissions           */
#include <signal.h>             /* for using signal handler             */
#include <stdio.h>              /* for using printf command             */
#include <string.h>             /* for using strcpy, strcat commands    */
#include <malloc.h>             /* for using malloc command             */
#include <sys/types.h>
#include <sys/signal.h>
#include "errlog.h"
#include "dcs.h"

extern void check_routine();
extern char gs_caTmCode[];
extern char gs_caBrCode[];
extern int  fd ;
extern int DISP_FLAG ;
#define EICONRETRY    5
#define iEICONDISP
#define TIMESIGNAL
#define time_val 30

#define MAX_LISTEN 5
#define MAX_NETWKTBL_ARRAY 30
#define LU0_BIND        0x1

#define SYMMAX          9               /* maxlen of sym dest name +1  */
#define FILEMAX         80              /* arbitrary max file name len */
#define BUFFERLEN       80              /* arbitrary max data rcv len  */
#define CONV_ID_LEN     8               /* length of conv id area      */
#define SENDMAX         32000           /* max # of bytes to send      */


struct Lu0Sess {
/*Stanley CHAO: 2/13/95 */
  char cLastAct;        /*dummy*/
  /*
  unsigned char ucaConverId[CONV_ID_LEN];
  */
  word ucaConverId ;
  char cStatus;
  char cMode;
};

struct Lu0Netwk {
  char caDesCode[SYMMAX];
  char caField[2][20];
};

/*Stanley CHAO: 2/13/95 */
/* change prefix code 52 to 62 */
#define P_DcsLu0Accept                  62001
#define P_DcsLu0Connect                 62002
#define P_DcsLu0Disconnect              62003
#define P_DcsLu0Initial                 62004
#define P_DcsLu0Null                    62005
#define P_DcsLu0Receive                 62006
#define P_DcsLu0Send                    62007
#define P_DcsLu0Terminate               62008
#define P_DcsLu0                        62009
#define P_GetHostServName               62010
#define P_LoadLu0NetwkTbl               62011
#define P_SrhLu0NetwkTbl                62012
#define P_DcsLu0Reset                   62013

/* -------------------- STATIC GLOBAL DECLARATION ------------------- */
static int gs_iFirst=1; /* first flage 1=yes 0=no          */
static int gs_iResiLu0Id;
static int gs_iMaxLoad;

struct servent *pstServEnt;
struct hostent *pstHostEnt;
struct Lu0Sess g_stLu0SesTbl[MAX_SESS];
struct Lu0Netwk g_stLu0NetTbl[MAX_NETWKTBL_ARRAY];

/* ------ CALL FUNCTION & SUBROUTINE PROTOTYPE DECLARATIONS --------- */
int DcsLu0(struct DcsBuf *pstDcsBuf);
int DcsLu0Initial(struct DcsBuf *pstDcsBuf,struct Lu0Sess *pstSess,
                   char cMode);
int DcsLu0Connect(struct DcsBuf *pstDcsBuf,struct Lu0Sess *pstSess);
int DcsLu0Accept(struct DcsBuf *pstDcsBuf,struct Lu0Sess *pstSess);
int DcsLu0Send(struct DcsBuf *pstDcsBuf,struct Lu0Sess *pstSess);
int DcsLu0Receive(struct DcsBuf *pstDcsBuf,struct Lu0Sess *pstSess);
int DcsLu0Disconnect(struct DcsBuf *pstDcsBuf,struct Lu0Sess *pstSess);
int DcsLu0Terminate(struct DcsBuf *pstDcsBuf);
int GetHostServName(char *pcDesCode,char *pcHostName,char *pcServName);
int SrhLu0NetwkTbl(char *pcDesCode,struct Lu0Netwk *pstNetTbl);
int LoadLu0NetwkTbl(struct Lu0Netwk *pstNetTbl);
dword lu0_confirmed(word session_id);
int   lu0_state();
int   lu0_end();
int   lu0_init();
int   lu0_connect();
int   lu0_setup();
int   lu0_disconnect();
void  DcsLu0Null();

word g_lPrepareType;
word g_lReceiveType;
word g_lReqToSend;
word g_lSyncLevel;
word g_lSendType;
word g_lLength;
word g_lReceivedLength;
word g_lStatusReceived;
word g_lDataReceived;
word g_lDeallocateType;
word g_lu0maxsize;
byte g_lu0state;          /* conv_state   */

word g_ucaConverId ;
word g_lu0flag;
int  signonflag;

byte gs_caPuName[9];
byte gs_caPortNo[9];
byte g_luname   [9];
byte g_mode     [9];
int  g_nPrgCount;
int  AUTOLOGON;

int
DcsLu0(struct DcsBuf *pstDcsBuf)
{
  int iRc;
  struct Lu0Sess *pstSess;

  g_lu0flag = 0;
  UCP_TRACE(P_DcsLu0);
  ErrLog(10,"DcsLu0:begin",RPT_TO_LOG,0,0);

  pstSess = g_stLu0SesTbl;
  iRc = 0;
  switch (PcRqstCode(pstDcsBuf)){
   case DCSINITIAL:
     if(gs_iFirst)
       {
         lu0_sendstatus ('D');
         iRc = DcsLu0Initial(pstDcsBuf,pstSess,'A');
         if(iRc != DCS_NORMAL)
           break;
         iRc = DcsLu0Connect(pstDcsBuf,pstSess);
         if ( iRc >= 0 )
            lu0_sendstatus ('C');
         gs_iFirst = 0;
       }
     break;
   case DCSCONNECT:
     /* do DcsLu0Initial when FIRST */
     if(gs_iFirst)
       {
         iRc = DcsLu0Initial(pstDcsBuf,pstSess,'A');
         if(iRc != DCS_NORMAL)
           break;
         gs_iFirst = 0;
         iRc = DcsLu0Connect(pstDcsBuf,pstSess);
       }
     break;
   case DCSCONNECTWRITE:
/*
     if(gs_iFirst)
       {
          iRc = DcsLu0Initial(pstDcsBuf,pstSess,'A');
          if(iRc != DCS_NORMAL)
            break;
          iRc = DcsLu0Connect(pstDcsBuf,pstSess);
          if(iRc != DCS_NORMAL)
            break;
          lu0_sendstatus ('C');
          gs_iFirst = 0;
       }
     else
       {
        iRc = DcsLu0Connect(pstDcsBuf,pstSess);
        if(iRc != DCS_NORMAL)
          break;
       }
     lu0_sendstatus ('S');
     iRc = DcsLu0Send(pstDcsBuf,pstSess);
     break;
*/
   case DCSWRITE:
     if ( lu0_Estate() < 0 )
        {
         iRc = -2 ;
         break;
        }

     lu0_sendstatus ('S');
     iRc = DcsLu0Send(pstDcsBuf,pstSess);
     break;
/*
   case DCSWRDISCONECT:
     lu0_sendstatus ('S');
     if ( lu0_Estate() < 0 )
        {
         iRc = -2 ;
         break;
        }
     iRc = DcsLu0Send(pstDcsBuf,pstSess);
     if(iRc == DCS_NORMAL){
       iRc = DcsLu0Disconnect(pstDcsBuf,pstSess);
       lu0_sendstatus ('D');
     }
     break;
*/
   case DCSACCEPTREAD:
     /* do DcsLu0Initial when FIRST */
     if(gs_iFirst){
       iRc = DcsLu0Initial(pstDcsBuf,pstSess,'P');
       if(iRc != DCS_NORMAL)
         break;
       gs_iFirst = 0;
     }
     iRc = DcsLu0Accept(pstDcsBuf,pstSess);
     if(iRc != DCS_NORMAL)
       break;
     iRc = DcsLu0Receive(pstDcsBuf,pstSess);
     break;
   case DCSREAD:
     if ( lu0_Estate() < 0 )
        {
         if ( DISP_FLAG == 1 )
            fprintf (stderr," DCSREAD ERROR 111111 \n");
         iRc = -2 ;
         break;
        }
     lu0_sendstatus ('R');
     iRc = DcsLu0Receive(pstDcsBuf,pstSess);
     break;
   case DCSDISCONNECT:
     iRc = DcsLu0Disconnect(pstDcsBuf,pstSess);
     break;
   case DCSTERMINATE:
     iRc = DcsLu0Terminate(pstDcsBuf);
     break;
   default:
     sprintf(g_caMsg,"DcsLu0:reguest error[%c]",PcRqstCode(pstDcsBuf));
     ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
     iRc = DCS_E_COMMAND;
     break;
  } /* end switch */

  PiReply(pstDcsBuf) = iRc;
/*
  if ( iRc !=  DCS_NORMAL )
     {
      lu0_sendstatus ( 'D') ;
      lu0_disconnect() ;
     }
*/
  UCP_TRACE_END(iRc);
} /* end of sbdbs */


int
DcsLu0Initial(struct DcsBuf *pstDcsBuf,struct Lu0Sess *pstSess,char cMode)
{
  dword  iCmRc;
  char  caSysDestName[SYMMAX];  /* symbolic name*/
  int iIdx;
  int iLu0Id;
  int iRc;
  struct Lu0Netwk *pstNetTbl;
  char caServName[20];
  char caHostName[20];

  UCP_TRACE(P_DcsLu0Initial);
  ErrLog(10,"DcsLu0Initial Begin.",RPT_TO_LOG,0,0);

  pstNetTbl = g_stLu0NetTbl;
  iRc = LoadLu0NetwkTbl(pstNetTbl);
  iRc=0;
  if(iRc != 0){
    ErrLog(10000,"DcsLu0Initial:load network table error",RPT_TO_LOG,0,0);
    PiErrno(pstDcsBuf) = iRc;
    UCP_TRACE_END(DCS_E_NETWORKTBL);
  }
  ErrLog(100,"DcsLu0Initial:load network table ok!!",RPT_TO_LOG,0,0);

  for(iIdx=0; iIdx<MAX_SESS; iIdx++){
    memset(&pstSess[iIdx], 0x00 , sizeof(struct Lu0Sess) );
    pstSess[iIdx].cStatus = DCS_S_FREE ;
    pstSess[iIdx].ucaConverId = 0;
  }

  if(cMode == PASSIVE_MODE) {
    ErrLog(100,"DcsLu0Initial:ok.",RPT_TO_LOG,0,0);
    UCP_TRACE_END(DCS_NORMAL);
  }
/*
  GetHostServName(PcaDesCode(pstDcsBuf),caHostName,caServName);
  strcpy(caSysDestName, caHostName);
*/
  iCmRc = SnaInitialize2(1, 0L);
  if (iCmRc != RC_OK)
     {
      sprintf(g_caMsg,"pid [%d] DcsLu0Initial(SnaInitialize2):Lu0 fail,getpid(),errno=[%d]",iCmRc );
      ErrLog(1000,g_caMsg,RPT_TO_LOG,(char*)&iCmRc,sizeof(iCmRc));
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
     }
  ErrLog(100,"DcsLu0Initial:End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}



int lu0_init ()
{
  dword  iCmRc;
  iCmRc = SnaInitialize2(1, 0L);
  if (iCmRc != RC_OK)
     return ( -1 ) ;
  return ( 0 ) ;
}


int
DcsLu0Connect(struct DcsBuf *pstDcsBuf,struct Lu0Sess *pstSess)
{
  dword  iCmRc=0;
  int iRc;
  int iIdx;
  int iLu0Id;
  char caServName[20];
  char caHostName[20];    /* for socket dcs */
  byte puname [9];
  byte tmpbuf[1024];
  word len;
  byte daf = 0x2;
/*
  strcpy(puname,"3270    ");
  extern char gs_caTmCode[];
  extern char gs_caBrCode[];
*/
  daf = (byte) atoi (gs_caTmCode);
  UCP_TRACE(P_DcsLu0Connect);
  ErrLog(10,"DcsLu0Connect Begin.",RPT_TO_LOG,0,0);

  /* search a usable dialogue  */
  iIdx = 1;
  while(pstSess[iIdx].cStatus != DCS_S_FREE &&
        pstSess[iIdx].cStatus != DCS_S_ERROR &&
        pstSess[iIdx].cStatus != DCS_S_USABLE &&
        iIdx < MAX_SESS) iIdx++;

  if(iIdx == MAX_SESS){
    ErrLog(1000,"DcsLu0Connect:Sess over error",RPT_TO_LOG,0,0);
    PiErrno(pstDcsBuf) = DCS_ES_SESOVERFLW;
    UCP_TRACE_END(DCS_E_LOCALDCS);
  }
  /* initial sess */
  memset(&pstSess[iIdx], 0x0, sizeof(struct Lu0Sess) );

/*
  GetHostServName(PcaDesCode(pstDcsBuf),caHostName,caServName);

  ErrLog(1000,"cmalloc ucaConverId",RPT_TO_LOG,g_ucaConverId,20);
*/
/*
byte gs_caPuName[9];
byte gs_caPortNo;
*/
  sprintf(g_caMsg,"pid [%d] DcsLu0Connect , Physical port  [%d]\n",
  getpid(), (word) atoi(gs_caPortNo)) ;
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
  sprintf(g_caMsg,"pid [%d] DcsLu0Connect pu [%s] lu [%x]\n",
  getpid(),gs_caPuName, daf) ;
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  iCmRc= SnaAttachLu2
     (NULL,                             /* Gateway                          */
      (word) atoi(gs_caPortNo),         /* Physical port                    */
      gs_caPuName,                      /* PU name                          */
      &daf,                             /* Number of LU                     */
      0,                                /* SNA LU type of the device        */
      &g_ucaConverId,                   /* LU session identifier         */
      NULL);                            /* ACR: Wait                        */
      sprintf(g_caMsg,"DcsLu0Connect(SnaAttachLu2):Lu0, errno=[%x]",(int)iCmRc);
      ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
  if (iCmRc != RC_OK)
    {
       sprintf(g_caMsg,"pid [%d]lu_no [%x] DcsLu0Connect(SnaAttachLu2):Lu0 fail, getpid(),daf,errno=[%x]",(int)iCmRc);
       ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
       PiErrno(pstDcsBuf) = iCmRc;
       UCP_TRACE_END(iCmRc);
      }
  len =1023;
  iRc = lu0_read(g_ucaConverId,RCV_SDT,tmpbuf,&len );
  if (iRc != 0)
    {
       sprintf(g_caMsg,"DcsLu0Connect(lu0_post):Lu0 fail, errno=[%d]",(int)iRc);
       ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
       PiErrno(pstDcsBuf) = iRc;
       UCP_TRACE_END(iCmRc);
      }
       sprintf(g_caMsg,"pid [%d]lu_no [%x] DcsLu0Connect(SnaAttachLu2):Lu0 ok, getpid(),daf,errno=[%x]",(int)iCmRc);
       ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  /* save the session information */
  pstSess[iIdx].cStatus  = DCS_S_USED ;
  pstSess[iIdx].cLastAct = DCSCONNECT;
  pstSess[iIdx].ucaConverId = g_ucaConverId ;
  pstSess[iIdx].cMode = ACTIVE_MODE;

  /* fill DCS buff */
  PiSesIdx(pstDcsBuf) = iIdx;
  PiErrno(pstDcsBuf) = 0;
  PcProto(pstDcsBuf) = LU0_DCS;


  sprintf(g_caMsg,"DcsLu0Connect End.iIdx=%d ucaConverId=%d",
          iIdx,pstSess[iIdx].ucaConverId);
  ErrLog(10,g_caMsg,RPT_TO_LOG,pstSess[iIdx].ucaConverId,10);
  UCP_TRACE_END(DCS_NORMAL);
}
int
lu0_connect ()
{
  dword  iCmRc=0;
  byte daf = 0x2;
  byte tmpbuf [1024];
  word len ;
  int  iRc;
  daf = (byte) atoi (gs_caTmCode);
  iCmRc= SnaAttachLu2
     (NULL,                             /* Gateway                          */
      (word) atoi(gs_caPortNo),         /* Physical port                    */
      gs_caPuName,                      /* PU name                          */
      &daf,                             /* Number of LU                     */
      0,                                /* SNA LU type of the device        */
      &g_ucaConverId,                   /* LU session identifier         */
      NULL);                            /* ACR: Wait                        */
/*
#ifdef DEBUG
*/
  if ( DISP_FLAG == 1 )  
     fprintf(stderr,"lu0_connect rc [%x]",iCmRc);
/*
#endif
*/
  if (iCmRc != RC_OK)
     return ( -1 ) ;
  len =1023;
if (AUTOLOGON)
{
  iRc = lu0_read(g_ucaConverId,RCV_SDT,tmpbuf,&len );
}
else
{
  iRc = lu0_read(g_ucaConverId,RCV_LU_UP,tmpbuf,&len );
}
  if (iRc != 0)
    {
/*
#ifdef DEBUG
*/
  if ( DISP_FLAG == 1 )  
     fprintf(stderr,"lu0_connect [lu0_read] fail, errno=[%d]",(int)iRc);
/*
#endif
*/

if (AUTOLOGON)
{
     lu0_disconnect();
}
else
{
     lu0_deact();
}
     return (-1);
    }
  lu0_sendstatus ('C');
  return ( 0 ) ;
}

int
lu0_setup ()
{
  int rc ;
/*
  rc=lu0_info();
#ifdef DEBUG
   if ( rc != 0 )
   printf ("lu0_info  rc [%d]\n",rc);
#endif
*/
  for (;;)
      {
        if ( lu0_init () == 0 )
          break ;
        lu0_end ();
      }
  for (;;)
      {
       if ( lu0_connect () == 0 )
         break ;
      }
#ifdef DEBUG
 printf ("LU0_SETUP ok\n");
#endif
  return ( 0 ) ;
}

void strupr(buffer)
char *buffer;
{
   int   c, i;

   for (i = 0; i < strlen(buffer) ;i++)
      if (islower(buffer[i]))
         buffer[i] = toupper(buffer[i]);
   return;
}  /* strupr */

int
DcsLu0Accept(struct DcsBuf *pstDcsBuf,struct Lu0Sess *pstSess)
{
  word  iCmRc=RC_OK;
  int iAcepLu0Id,iIdx,iRc;
  int iServLen;

  UCP_TRACE(P_DcsLu0Accept);
  ErrLog(10,"DcsLu0Accept Begin.",RPT_TO_LOG,0,0);

  /* search a usable dialogue  */
  iIdx = 1;
  while(pstSess[iIdx].cStatus != DCS_S_FREE &&
        pstSess[iIdx].cStatus != DCS_S_USABLE &&
        pstSess[iIdx].cStatus != DCS_S_ERROR &&
        iIdx < MAX_SESS) iIdx++;

  if(iIdx == MAX_SESS){
    ErrLog(1000,"DcsLu0Accept:Sess over error",RPT_TO_LOG,0,0);
    PiErrno(pstDcsBuf) = DCS_ES_SESOVERFLW;
    UCP_TRACE_END(DCS_E_LOCALDCS);
  }
  /* initial sess */
  memset(&pstSess[iIdx], 0x0, sizeof(struct Lu0Sess) );

  UCP_TRACE_END(DCS_NORMAL);
}


int
DcsLu0Send(struct DcsBuf *pstDcsBuf,struct Lu0Sess *pstSess)
{
  word iCmRc=RC_OK;      /* ret code from CPI-C  */
  int iIdx;
  word ucaWdLu0Id;
  word ucaRdLu0Id; /* stanley chao -- dummy*/
  int iRc;
  int iMsgLen;
  unsigned char caDummy[10];

  UCP_TRACE(P_DcsLu0Send);
  ErrLog(10,"DcsLu0Send Begin.",RPT_TO_LOG,0,0);
  ucaWdLu0Id=0;
  ucaRdLu0Id=0;
  iIdx = PiSesIdx(pstDcsBuf);

  if(iIdx > 0){
    if(pstSess[iIdx].cStatus != DCS_S_USED || iIdx >= MAX_SESS){
      ErrLog(1000,"DcsLu0Send:unusable Session!",RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = DCS_ES_SESUNUSE;
      UCP_TRACE_END(DCS_E_COMMAND);
    }
    ucaWdLu0Id=pstSess[iIdx].ucaConverId;
    ucaRdLu0Id=pstSess[iIdx].ucaConverId;
  }
  else{
    ucaWdLu0Id=1;
    ucaRdLu0Id=1;
  }
/*mod by eric */
/*mod by JSHEN: real len = datalen - 8 */
/*mod by stanley and fuck you !!*/
/*
  iMsgLen = PiDataLen(pstDcsBuf) -8;
*/
  iMsgLen = PiDataLen(pstDcsBuf) ;

  sprintf(g_caMsg,"DcsLu0Send:iIdx=%d ucaWdLu0Id=%d ",
          iIdx,ucaWdLu0Id);
  ErrLog(100,g_caMsg,RPT_TO_LOG,ucaWdLu0Id,10);
  sprintf(g_caMsg,"pid [%d] DcsLu0Send:iMsgLen=%d ",getpid(),iMsgLen);
  ErrLog(100,g_caMsg,RPT_TO_LOG,PcaData(pstDcsBuf),iMsgLen);


  g_lLength = (long) iMsgLen;
  lu0_tosend(ucaWdLu0Id);
  if ((iRc=lu0_send(ucaWdLu0Id,PcaData(pstDcsBuf),g_lLength))!= 0)
    {
      sprintf(g_caMsg,"pid [%d] DcsLu0Send(cmsend):write fail,errno=[%d]",getpid(),iRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstSess[iIdx].cStatus = DCS_S_ERROR;
      PiErrno(pstDcsBuf) = errno;
      UCP_TRACE_END(iRc);
    }
    else
      ErrLog(100,"DcsLu0Send:write ok.",RPT_TO_LOG,0,0);
  /* update session */
/*
  lu0_toreceive(ucaWdLu0Id);
  {
  int   len = 512;
  char  buf[1024];
  lu0_read(ucaWdLu0Id,RCV_DEALLOCATE,buf,&len);
  }
*/
  PiErrno(pstDcsBuf) = 0;
/*JSHEN*/
  pstSess[iIdx].cLastAct = DCSWRITE;

  if(iIdx == 0 && (pstSess[iIdx].cStatus == DCS_S_FREE ||
                  pstSess[iIdx].cStatus == DCS_S_USABLE)){
    pstSess[iIdx].cStatus = DCS_S_USED ;
    pstSess[iIdx].cMode = ACTIVE_MODE;
    PcProto(pstDcsBuf) = LU0_DCS;
  }

  ErrLog(10,"DcsLu0Send End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}


int
DcsLu0Receive(struct DcsBuf *pstDcsBuf,struct Lu0Sess *pstSess)
{
  word  iCmRc=0;
  word ucaRdLu0Id;
  word ucaWdLu0Id;
  int iIdx;
  int iRc;
  int iMsgLen;
  word len;
  unsigned char caDummy[10];
  void DcsLu0Null();
  char caTmpBuf[10];

  UCP_TRACE(P_DcsLu0Receive);
  ErrLog(10,"DcsLu0Receive Begin.",RPT_TO_LOG,0,0);
  ucaRdLu0Id = 0;
  ucaWdLu0Id = 0;

  iIdx = PiSesIdx(pstDcsBuf);

  if(iIdx > 0){
    if(pstSess[iIdx].cStatus != DCS_S_USED || iIdx >= MAX_SESS){
      ErrLog(1000,"DcsLu0Receive:unusable Session!",RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = DCS_ES_SESUNUSE;
      UCP_TRACE_END(DCS_E_COMMAND);
    }
    ucaRdLu0Id = pstSess[iIdx].ucaConverId ;
    ucaWdLu0Id = pstSess[iIdx].ucaConverId ;
  }
  else{
    ucaWdLu0Id=1;
    ucaRdLu0Id=1;
  }
  sprintf(g_caMsg,"DcsLu0Receive:iIdx=%d ucaRdLu0Id=%d.",
          iIdx,ucaRdLu0Id);
  ErrLog(100,g_caMsg,RPT_TO_LOG,ucaRdLu0Id,10);

  iMsgLen = PiDataLen(pstDcsBuf);
  g_lLength = (long) iMsgLen;


  ErrLog(100,"begin cmrcv",RPT_TO_LOG,0,0);
  lu0_toreceive( ucaRdLu0Id );
  len = 1024;
  iRc = lu0_read (ucaRdLu0Id,RCV_DEALLOCATE,(byte *)PcaData(pstDcsBuf),
/*
        &((word) PiDataLen(pstSess)) );
*/
        &len);
  PiDataLen(pstDcsBuf) = (int)len;
  g_lReceivedLength    = (int)len;
  sprintf(g_caMsg,"lu0_post():status [%d] data_rcvd [%d] ",
                 (int)g_lStatusReceived,(int)g_lDataReceived);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  sprintf(g_caMsg,"DcsLu0Received:g_lReceivedLength)=%d ",g_lReceivedLength);
  ErrLog(100,g_caMsg,RPT_TO_LOG,PcaData(pstDcsBuf),g_lReceivedLength);

  if (iRc != 0)
    {
      sprintf(g_caMsg,"DcsLu0Receive(lu0_post):read fail, errno=[%d]",iRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,PcaData(pstDcsBuf),g_lReceivedLength);
      pstSess[iIdx].cStatus = DCS_S_ERROR;
      PiErrno(pstDcsBuf) = iCmRc;
      if(errno == EINTR) UCP_TRACE_END(DCS_E_TIMEOUT);
      UCP_TRACE_END(iRc);
    }

  sprintf(caTmpBuf,"%.5d",g_lReceivedLength);
  memcpy(PcaDataLen(pstDcsBuf),caTmpBuf,5);
  /*
  alarm(0) ;
  */
  iMsgLen = (int) g_lReceivedLength;

  /* save the session information */
  PiDataLen(pstDcsBuf) = iMsgLen ;
  PiErrno(pstDcsBuf) = 0;
  pstSess[iIdx].cLastAct = DCSREAD;

  if(iIdx == 0 && (pstSess[iIdx].cStatus == DCS_S_FREE ||
                  pstSess[iIdx].cStatus == DCS_S_USABLE)){
    pstSess[iIdx].cStatus = DCS_S_USED ;
    pstSess[iIdx].cMode = PASSIVE_MODE;
    PcProto(pstDcsBuf) = LU0_DCS;
  }

  ErrLog(10,"DcsLu0Receive End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}


int
DcsLu0Disconnect(struct DcsBuf *pstDcsBuf,struct Lu0Sess *pstSess)
{
  word  iCmRc=RC_OK;      /* ret code from CPI-C  */
  int iRc;
  int iIdx;
  word ucaConverId;

  UCP_TRACE(P_DcsLu0Disconnect);
  ErrLog(100,"DcsLu0Disconnect Begin.",RPT_TO_LOG,0,0);
  ucaConverId  = 0;

  /* Is the dialogue usable */
  iIdx = PiSesIdx(pstDcsBuf);

  if(iIdx > 0){
    if(pstSess[iIdx].cStatus == DCS_S_FREE || iIdx >= MAX_SESS){
      ErrLog(1000,"DcsLu0Disconnect: unusable Session!",RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = DCS_ES_SESUNUSE;
      UCP_TRACE_END(DCS_E_COMMAND);
    }
    ucaConverId = pstSess[iIdx].ucaConverId ;
  }
  else{
    ucaConverId = 1;
  }
  iCmRc = SnaDetachLu
      (g_ucaConverId,
      NULL);
  /* save the session information */
  pstSess[iIdx].cStatus = DCS_S_FREE;
  pstSess[iIdx].ucaConverId = 0;

  /* fill DCS buff */
  PiSesIdx(pstDcsBuf) = -1;
  PiErrno(pstDcsBuf) = 0;
  PcProto(pstDcsBuf) = ' ';

  ErrLog(100,"DcsLu0Disconnect End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}


int
DcsLu0Terminate(struct DcsBuf *pstDcsBuf)
{
  UCP_TRACE(P_DcsLu0Terminate);
  ErrLog(10,"DcsLu0Terminate Begin.",RPT_TO_LOG,0,0);
  lu0_end();
  ErrLog(10,"DcsLu0Terminate End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}



int
GetHostServName(char *pcDesCode,char *pcHostName,char *pcServName)
{
  int iRc;
  struct Lu0Netwk stNetwk;

  UCP_TRACE(P_GetHostServName);
  ErrLog(10,"GetHostServName:Begin",RPT_TO_LOG,0,0);

  iRc = 0;
  /* get protocol & server name by des_code */
  iRc = SrhLu0NetwkTbl(pcDesCode,&stNetwk);
  if(iRc != 0){
    sprintf(g_caMsg,"GetHostServName:search network table error iRc=%d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(iRc);
  }
  ErrLog(10,"GetHostServName:search network table ok.",RPT_TO_LOG,0,0);

  strcpy(pcHostName,stNetwk.caField[0]);
  strcpy(pcServName,stNetwk.caField[1]);

  sprintf(g_caMsg,"GetHostSeNa:End host=%s serv=%s\n",pcHostName,pcServName);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
  UCP_TRACE_END(0);
}


int
SrhLu0NetwkTbl(char *pcDesCode,struct Lu0Netwk *pstNetwk)
{
  int iIdx,iRc;
  struct Lu0Netwk *pstNetTbl;

  UCP_TRACE(P_SrhLu0NetwkTbl);
  sprintf(g_caMsg,"SrhLu0NetwkTbl:Begin,pcDesCode=%.10s",pcDesCode);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);

  pstNetTbl = g_stLu0NetTbl;
  iIdx = 1;
  /* find out in the net work table array */
  while((iRc = memcmp(pcDesCode,pstNetTbl[iIdx].caDesCode,10) != 0) &&
        (iIdx < gs_iMaxLoad)){
    iIdx++;
  }

  /* memory copy from net work table to working area of networktable struct */
  if(iIdx == gs_iMaxLoad){
    /* not found in table array, then set default protocol & server name */
    memcpy(pstNetwk,&pstNetTbl[0],sizeof(struct Lu0Netwk));
  }
  else{
    /* found */
    memcpy(pstNetwk,&pstNetTbl[iIdx],sizeof(struct Lu0Netwk));
  }

  sprintf(g_caMsg,"SrhLu0NetwkTbl End pstNetTbl[%d]=",iIdx);
  ErrLog(10,g_caMsg,RPT_TO_LOG,&pstNetTbl[iIdx],sizeof(struct Lu0Netwk));
  UCP_TRACE_END(0);
}


int
LoadLu0NetwkTbl(struct Lu0Netwk *pstNetTbl)
{
  int i,j,k;
  FILE *pfNetFd;
  char caFileName[80];

  UCP_TRACE(P_LoadLu0NetwkTbl);
  ErrLog(10,"LoadLu0NetwkTbl:Begin",RPT_TO_LOG,0,0);
/*JSHEN*/
  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat(caFileName, DCS_TABLE_PATH);
  strcat(caFileName, LU0TABLE);
  ErrLog(10,caFileName,RPT_TO_LOG,0,0);

  if((pfNetFd = fopen(caFileName,"r")) == (FILE *) 0){
    sprintf(g_caMsg,"LoadLu0NetwkTbl:open Lu0tbl fail errno=%d",errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(DCS_ES_OPENTBLFILE);
  }
  ErrLog(10,"LoadLu0NetwkTbl:open netwktable ok",RPT_TO_LOG,0,0);

  i = 0;
  while(fscanf(pfNetFd,"%s %s %s", pstNetTbl[i].caDesCode,
                                   pstNetTbl[i].caField[0],
                                   pstNetTbl[i].caField[1]) != EOF){

    if(i++ > MAX_NETWKTBL_ARRAY){
      ErrLog(1000,"LoadLu0NetwkTbl:over table array",RPT_TO_LOG,0,0);
      fclose(pfNetFd);
      UCP_TRACE_END(DCS_ES_TBLARRAYOVERFLW);
    }
  }

  gs_iMaxLoad = i;
  ErrLog(10,"LoadLu0NetwkTbl End.",RPT_TO_LOG,0,0);
  fclose(pfNetFd);
  UCP_TRACE_END(0);
}
int
lu0_disconnect ()
{
  dword iCmRc;
  iCmRc = SnaDetachLu ( g_ucaConverId, NULL);
#ifdef DEBUG
  printf("pid [%d] SnaDetachLu [%d] rc [%x]\n",getpid(),g_ucaConverId,iCmRc);
#endif
  if ( iCmRc != RC_OK )
     return ( -1 ) ;
  return ( 0 ) ;
}

void
DcsLu0Null()
{
  dword iCmRc;
  byte  daf ;
  byte  tmpbuf[1024];
  word  len;
  int   iRc;
  long  sense;

  lu0_sendstatus ('T');

  if (AUTOLOGON == 0)
	lu0_deact();
  lu0_disconnect ();
  lu0_end () ;

/*
  sense = 8090000;
  iCmRc = SnaSendError ( g_ucaConverId,sense, NULL);
#ifdef DEBUG
  printf("pid [%d] SnaSendError [%d] rc [%x]\n",getpid(),g_ucaConverId,iCmRc);
#endif
*/
  g_lu0flag = 1 ;
{
  char cmdbuf[256];
  char caOutData[DCS_MAX_DATA_LEN];
  char cRc;
  int  iMsgLen;

  cRc = '1';
  iMsgLen = 0;
  WrQue(&cRc,caOutData,&iMsgLen);
  sleep(3);
  if (AUTOLOGON)
  	sprintf(cmdbuf,"nohup dcxdaemon.x %s %s %s %s %d 1 %d 1>NULL 2>NULL&",gs_caBrCode,gs_caTmCode,gs_caPuName,gs_caPortNo,signonflag,g_nPrgCount); 
  else
  	sprintf(cmdbuf,"nohup dcxdaemon.x %s %s %s %s %d 0 %d %s %s 1>NULL 2>NULL&",gs_caBrCode,gs_caTmCode,gs_caPuName,gs_caPortNo,signonflag,g_nPrgCount,g_luname,g_mode); 
  if (fork() == 0)
  {
  sleep(3);
  system(cmdbuf);
  }
}
  exit (-1);
}

lu0_send(session_id,buf,len)
word session_id;
byte *buf;
word len;
{
 word i,rts;
 dword iCmRc;
/*
#ifdef TIMESIGNAL
  g_lu0flag = 0 ;
  signal(SIGALRM,DcsLu0Null)  ;
  alarm((unsigned int) time_val);
#endif
*/
 alarm ( 0 ) ;
 iCmRc = SnaSendData
      (session_id,
       1,
       buf,
       len,
       &g_lReqToSend,
       NULL);
#ifdef DEBUG
  printf("pid [%d] lu0_send iCmRc=[%x]\n",getpid(),iCmRc);
#endif
/*
#ifdef TIMESIGNAL
 alarm(0);
 signal(SIGALRM,check_routine)  ;
 alarm((unsigned int) 5);
 if ( g_lu0flag == 1 )
    {
      g_lu0flag = 0 ;
      return ( -5 ) ;
    }
#endif
*/
  alarm ( 5 ) ;
  if (iCmRc != RC_OK)
     return(-6);
/*
  iCmRc = SnaFlush(session_id,NULL);
  if (iCmRc != RC_OK)
     return(-1);
*/
  return(0);
}
int
lu0_end()
{
  dword iCmRc;
  iCmRc = SnaEnd();

#ifdef DEBUG
 printf("pid [%d] lu0_end rc [%x] !!\n",getpid(),iCmRc);
#endif
  if (iCmRc != RC_OK)
     return(-1);

  return(0);
}

lu0_toreceive(session_id)
word session_id;
{
 dword iCmRc;
#ifdef DEBUG
 printf("toreceive !!\n");
#endif
 iCmRc = SnaPrepareToReceive
       (session_id,
        0,
        0,
        0);
#ifdef DEBUG
  printf("toreceive end [%x] !!\n",iCmRc);
#endif
  if (iCmRc != RC_OK)
     return(-1);
}


lu0_tosend(session_id)
word session_id;
{
  dword iCmRc;
  iCmRc = SnaRequestToSend
       (session_id,
        NULL);
  if (iCmRc != RC_OK)
     return(-1);
}


dword lu0_confirmed (word session_id)
{
  return( (dword) SnaConfirmed (session_id,NULL));
}

lu0_read(session_id,exit_code,bufptr,bufcnt)
 word session_id;
 word exit_code;
 byte *bufptr;
 word *bufcnt;
{
 word   what,oldwhat;
 word   rts;
 dword  iCmRc;
 word   len;
 byte   *abc;
 int    eicon_count ;
 void   DcsLu0Null();
 what = 0;
 len = 0;
 *bufcnt=0;
 abc = bufptr;
#ifdef DEBUG
       printf ( "pid[%d] LU0_read exit_code [%d]\n",getpid(), exit_code );
#endif
if ( exit_code != RCV_SDT  && exit_code != RCV_LU_UP)
   {
#ifdef TIMESIGNAL
    alarm ( 0 ) ;
    signal(SIGALRM,DcsLu0Null)  ;
    alarm((unsigned int)time_val);
#else
    alarm ( 0 ) ;
#endif
   }
else
   alarm ( 0 ) ;
 oldwhat = 0x0;
 for(eicon_count=0;;)
    {
#ifdef EICONRETRY
        if ( eicon_count == EICONRETRY )
           {
/*
#ifdef DEBUG
*/
            if ( DISP_FLAG == 1)
               fprintf(stderr,"pid[%d] LU0_RECV 148 retry 3 times \n",getpid());
/*
#endif
*/
            lu0_disconnect();
/*
            lu0_end();
            lu0_setup();
S
*/
#ifdef TIMESIGNAL
          alarm(0);
          signal(SIGALRM,check_routine)  ;
          alarm((unsigned int) 5);
#endif
            return ( -1 ) ;
           }
#endif
/*
      memset  (bufptr , 0 , *bufcnt );
*/
      iCmRc = SnaReceiveAndWait
              (session_id,
               &what,
              &rts,
               abc,
             1024,
               bufcnt,
              NULL);
      if (iCmRc != RC_OK)
         {
/*
#ifdef DEBUG
*/
            if ( DISP_FLAG == 1)
               fprintf(stderr,"pid[%d] LU0_RECV ERROR [%x]\n",getpid(),iCmRc);
/*
#endif
*/
#ifdef TIMESIGNAL
          alarm(0);
 signal(SIGALRM,check_routine)  ;
 alarm((unsigned int) 5);
#endif
/*
#ifdef DEBUG
*/
          if ( DISP_FLAG == 1)
             fprintf (stderr,"pid[%d] LU0_read rc [%x] what[%x]\n",getpid(),iCmRc,what );
/*
#endif
*/
          return ( -1 );
         }
      if ( g_lu0flag == 1 )
         {
/*
#ifdef DEBUG
*/
          if ( DISP_FLAG == 1)
             fprintf(stderr,"pid [%d] RECV TIMEOUT \n",getpid());
/*
#endif
*/
#ifdef TIMESIGNAL
           g_lu0flag = 0 ;
           alarm(0);
           signal(SIGALRM,check_routine)  ;
           alarm((unsigned int) 5);
#endif
           return ( -9 ) ;
         }
      len = len + *bufcnt;
      abc = bufptr + len;
/*
#ifdef DEBUG
*/
      if ( DISP_FLAG == 1)
         fprintf(stderr,"pid [%d] what == [%d] len [%d]\n",getpid(),what,*bufcnt);
/*
#endif
*/
      if ( what == exit_code)
           break;
      if ( what == RCV_SDT)
           break;
      if (what == RCV_DEALLOCATE)
           break;
      if (what == RCV_DATA_COMPLETE)
           break;
      if (what == RCV_SEND)
           break;
      if (what == RCV_DEALLOCATE_CONFIRM)
           break;
      if (what == RCV_LINK_DOWN)
           eicon_count ++ ;
    }
#ifdef TIMESIGNAL
    alarm(0);
    signal(SIGALRM,check_routine)  ;
    alarm((unsigned int) 5);
#endif
/*
#ifdef DEBUG
*/
    if ( DISP_FLAG == 1)
       fprintf (stderr,"pid [%d] LU0_read rc [%x] what[%d]\n",getpid(), iCmRc,what );
/*
#endif
*/
 if ( what == exit_code || what == RCV_DATA_COMPLETE || what == RCV_SEND ||
      what == RCV_DEALLOCATE_CONFIRM)
    {
      *bufcnt = len;
      return(0);
    }
 if ( exit_code == RCV_SDT )
    {
/*
#ifdef DEBUG
*/
      if ( DISP_FLAG == 1)
         fprintf (stderr,"pid[%d] what [%d] exit code [%d]\n",getpid(),what,exit_code);
/*
#endif
*/
     return(-3);
    }
 return ( -4 ) ;
}

int
DcsLu0Reset()
{
  dword iCmRc;
  byte  daf ;
  byte  tmpbuf[1024];
  word  len;
  int   iRc;

  daf = (byte) atoi (gs_caTmCode);
  sprintf(g_caMsg,"pid [%d] DcsLu0RESET , Physical port  [%d]\n",
  getpid(), (word) atoi(gs_caPortNo)) ;
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
  sprintf(g_caMsg,"pid [%d] DcsLu0Connect pu [%s] lu [%x]\n",
  getpid(),gs_caPuName, daf) ;
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  lu0_sendstatus ('D');

  iCmRc = SnaAttachLu2
     (NULL,                             /* Gateway                          */
      (word) atoi(gs_caPortNo),         /* Physical port                    */
      gs_caPuName,                      /* PU name                          */
      &daf,                             /* Number of LU                     */
      0,                                /* SNA LU type of the device        */
      &g_ucaConverId,                   /* LU session identifier            */
      NULL);                            /* ACR: Wait                        */
#ifdef DEBUG
  printf ("LU0_RESET ATT rc [%x]\n",iCmRc);
#endif
  len = 1023;
  iRc = lu0_read(g_ucaConverId,RCV_SDT,tmpbuf,&len );
#ifdef DEBUG
  printf("DcsLu0Reset read rc [%d]\n",iRc);
#endif
  if ( iRc >= 0 )
     lu0_sendstatus ('C');
  return (-1);
}

int
lu0_sendstatus ( data)
char data ;
{
 if ( lu0_state () >= 0 )
    StatusToBankDae (fd , gs_caBrCode , gs_caTmCode , data ) ;
 return ( 0 ) ;
}
int
lu0_state ()
{
  if ( fd < 0 )
  {
     fd = ConnectToBankDae (gs_caBrCode , gs_caTmCode);
/*
     printf("ConnectToBankDae [%d] --------------------\n",fd);
*/
  }
  return (fd) ;
}

lu0_Estate()
{
 dword  rc ;
 struct DisplayLuInfo info;
 memset((char *)&info,0,sizeof(struct DisplayLuInfo));
 rc = SnaDisplayLu
      (g_ucaConverId,                   /* LU session identifier            */
       &info,
       NULL);                           /* ACR: Wait                        */
#ifdef DEBUG
 printf ( " STATE rc [%x] state[%x] \n",rc, info.session_count );
#endif
 if (rc != RC_OK)
    return (-1);
/*
#ifdef EICONDISP
*/
 if ( DISP_FLAG == 1 )
    { 
       fprintf(stderr,"pid [%d] , lu_num        [%x]\n",getpid(),info.lu_num);
       fprintf(stderr,"pid [%d] , line_state    [%x]\n",getpid(),info.line_state);
       fprintf(stderr,"pid [%d] , link_state    [%x]\n",getpid(),info.link_state);
       fprintf(stderr,"pid [%d] , pu_state      [%x]\n",getpid(),info.pu_state);
       fprintf(stderr,"pid [%d] , lu_state      [%x]\n",getpid(),info.lu_state);
       fprintf(stderr,"pid [%d] , session_count [%x]\n",getpid(),info.session_count);
       fprintf(stderr,"pid [%d] , session_state [%x]\n",getpid(),info.session_state);
       fprintf(stderr,"pid [%d] , conv_state    [%x]\n",getpid(),info.conv_state);
       fprintf(stderr,"Program count [%d] ------\n",g_nPrgCount);
     }
/*
#endif
*/

if (info.session_count == 1
&& info.session_state == 6
&& info.conv_state == 10)
{
        lu0_deact();
        lu0_disconnect();
        lu0_end();
        lu0_setup();
}

if (info.line_state > LINE_CONNECTED )
   return ( -2 ) ;

if (info.link_state > LLC_OPENED )
   return ( -3 ) ;

if ( info.pu_state  == INACTIVE )
   return ( -4 ) ;

if ( info.lu_state  == INACTIVE )
   return ( -5 ) ;

if ( signonflag == 0 )
   return ( 0 ) ;
if ( info.session_count == 0 )
   return ( -6 ) ;
if ( info.session_state < HS_ACTIVE )
   return ( -7 ) ;
if ( info.session_state > HS_ACTIVE )
   return ( -1 ) ;

if ( info.conv_state == 2 )
   return ( 2) ;
if ( info.conv_state == 3 )
   return ( 3) ;
 return ( 0 )  ;
}

lu0_act()
{
  dword  iCmRc;
  word len ;
  int iRc  ;
  byte recvbuf [2049];
/*
  printf ("LUNAME   [%s]\n",g_luname);
  printf ("MODENAME [%s]\n",g_mode);
*/
  iCmRc = SnaActivateSession ( g_ucaConverId , g_luname , g_mode,NULL);
#ifdef DEBUG
     printf ("pid[%d] lu0_act [%x]\n",getpid(),iCmRc);
#endif
  len = 2048;
  iRc = lu0_read(g_ucaConverId,RCV_SDT,recvbuf,&len );
  if (iRc != 0)
     return ( -2 );
  return ( 0 ) ;
}

lu0_deact ()
{
  dword  iCmRc;
  int iRc  ;
  word len ;
  byte recvbuf [2049];
  char aaa[5];

  iCmRc = SnaDeactivateSession ( g_ucaConverId , NULL);
#ifdef DEBUG
     printf ("pid[%d] lu0_deact  2 [%x]\n",getpid(),iCmRc);
#endif
/*
  iCmRc = SnaDeallocate ( g_ucaConverId , 1 , NULL);
#ifdef DEBUG
     printf ("pid[%d] lu0_deact  1 [%x]\n",getpid(),iCmRc);
#endif
*/
/*
  len = 2048;
  iRc = lu0_read(g_ucaConverId,RCV_UNBIND,recvbuf,&len );
*/
  if (iRc != 0)
     return ( -2 );
return ( 0 ) ;
}

disp_msg ( prompt1,prompt2 , rc ,  type )
char *prompt1, *prompt2 ;
dword rc     ;
char type    ;
{
#ifdef DEBUG
  if ( type == 'H' )
     printf("download pid [%d] , %s %s rc [%x]\n" , getpid() , prompt1,prompt2,rc);
  else
     printf("download pid [%d] , %s %s rc [%d]\n" , getpid() , prompt1,prompt2,rc);
#endif
  return ( 0 ) ;
}
