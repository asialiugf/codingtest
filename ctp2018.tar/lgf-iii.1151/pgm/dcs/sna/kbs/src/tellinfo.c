#include <isam.h>

#define TELL_FILE_PATH "/iii/dat/CISAM/CCFTELF"

typedef struct tellerinfo{
  char brcode[3];
  char usercode[2];
  char passwd[4];
  char empcode[7];
  char empname[10];
  char empdate[7];
  char telcode[10];  /* telephone code */
  char auth;
  char cdate[7];
  char sup1[2];
  char sup2[2];
  char build[2];
  char filler[103];
}TellInfo;

int GetTelPasswd(brcode,telcode,passwd,power)
char *brcode;
char *telcode;
char *passwd;
char *power;
{

  int fd;
  struct dictinfo info;
  TellInfo tel;
  char buf[30];
  int rc;
  char loc[256];
  char *tmp,lpstrFname[256];

  prnmsg("GetTelPasswd(): begin !!\n");
/*
  if ((tmp = getenv("III_DIR")) == NULL)
  {
    prnmsg("GetTelPasswd(): III_DIR not defined !!\n");
    return (-1);
  }
  sprintf(lpstrFname,"%s%s",tmp,TELL_FILE_PATH);
*/
  sprintf(lpstrFname,"%s%s",III_DIR,TELL_FILE_PATH);

  fd = isopen(lpstrFname,ISINOUT+ISMANULOCK);
  if(fd < 0){
    sprintf(loc,"GetTelPasswd(): open [%s] fail [%d]!!\n",lpstrFname,iserrno);
    prnmsg(loc);
    return(-1);
  }
  /*
  isindexinfo(fd,&info,0);
  printf("record size = %d \n",info.di_recsize);
  printf("record num = %d \n",info.di_nrecords);
  */
  memcpy(tel.usercode,telcode,2);
  memcpy(tel.brcode,brcode,3);
  rc = isread(fd,&tel,ISEQUAL);
  if(rc < 0){
     prnmsg("GetTelPsswd(): isam record not found !!\n");
     return(-1);
  }
  else{
     memcpy(passwd,tel.passwd,4);
     passwd[4]=0;
     *power = tel.auth;
  }
  isclose(fd);
  prnmsg("GetTelPasswd(): end !!\n");
  return(1);
}

int GetTelSup(brcode,telcode,sup1,sup2)
char *brcode;
char *telcode;
char *sup1;
char *sup2;
{

  int fd;
  struct dictinfo info;
  TellInfo tel;
  char buf[30];
  int rc;
  char loc[256];
  char *tmp,lpstrFname[256];

  prnmsg("GetTelSup(): begin !!\n");
/*
  if ((tmp = getenv("III_DIR")) == NULL)
  {
    prnmsg("GetTelSup(): III_DIR not defined !!\n");
    return (-1);
  }	
  sprintf(lpstrFname,"%s%s",tmp,TELL_FILE_PATH);
*/
  sprintf(lpstrFname,"%s%s",III_DIR,TELL_FILE_PATH);

  fd = isopen(lpstrFname,ISINOUT+ISMANULOCK);
  if(fd < 0){
    sprintf(loc,"GetTelSup(): open [%s] fail !!\n",lpstrFname);
    return(-1);
  }
  /*
  isindexinfo(fd,&info,0);
  printf("record size = %d \n",info.di_recsize);
  printf("record num = %d \n",info.di_nrecords);
  */
  memcpy(tel.usercode,telcode,2);
  memcpy(tel.brcode,brcode,3);
  rc = isread(fd,&tel,ISEQUAL);
  if(rc < 0){
     prnmsg("GetTelSup(): isam record not found !!\n");
     return(-1);
  }
  else{
     memcpy(sup1,tel.sup1,2);
     sup1[2]=0;
     memcpy(sup2,tel.sup2,2);
     sup2[2]=0;
  }
  isclose(fd);
  prnmsg("GetTelSup(): end !!\n");
  return(1);
}
