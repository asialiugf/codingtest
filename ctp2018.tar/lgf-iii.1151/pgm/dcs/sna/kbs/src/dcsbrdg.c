

#include <fcntl.h>
#include <errno.h>
#include <sys/ipc.h>
#include <sys/signal.h>
#include "errlog.h"
#include "msgqop.h"
#include "dcs.h"


#define MAX_DATA_LEN	256
#define ALIMENT    8
#define  DCSCMDOK     '0'

#define P_DcsAttQue	67002
#define P_DcsRemove	67003
#define P_GetFileData	67004
#define P_IsUseQuType	67005
#define P_WrQue         67006
#define P_RdQue         67007

#define  DCSLDPRC     'O'        
#ifdef OMIT
  #define  QUETYPE      2 
#endif 


static int sg_iaQuId[MAX_NETWKTBL_ARRAY];	/* keep QuId array */
static int sg_iMaxQuId;				/* max creat queue */
static struct DcsBuf  gs_stDcsBuf;

static int gs_iQueKey;
int gs_iQuId;
/*   modify for chao by YEN 19950428
static int gs_iQuId;
*/

struct Siof {
  char cDcsCmd;
  int  iSiofLen;
  unsigned char ucaSiofData[ MAX_SOFLEN ];
};

char gs_caTmCode[5];
char gs_caBrCode[5];
static long gs_iWrQueType;
static long gs_iRdQueType;


#ifdef OMIT
main(int argc,char *argv[])
{
 char caData[600];
 int iLen;
 char *cCmd='X';
 
memcpy(gs_caTmCode,argv[1],2);
memset(&gs_caTmCode[2],0x00,1);
printf("gs_caTmCode-----%s---\n",gs_caTmCode);

  AttQue();

  RdQue(cCmd,caData,&iLen) ;

printf("iLen %d\n",iLen);
printf("iCmd %c\n",cCmd);
ErrLog(100,"dcm read data",RPT_TO_LOG,caData,iLen);

  WrQue(cCmd,caData,&iLen);

printf("iLen %d\n",iLen);
printf("iCmd %c\n",cCmd);
ErrLog(100,"dcm write data",RPT_TO_LOG,caData,iLen);

}
#endif



int
AttQue()
{
  int i, iRc=0;
  char caFileName[80];
  char *pcFoundFlg;
  /* for get data */
  char caDataType[5];
  long *plDataVar[5];
  /* input data variable for queuetbl */
  char caDesCode[20];
  int iQuFlag;
  long lQuSize;
  long lQuType;
  int iLastQuKey;	/* keep last queue key */
  FILE *pfQueFile;
  char caQueType[20];

  UCP_TRACE(P_DcsAttQue);
  ErrLog(100,"AttQue Begin.",RPT_TO_LOG,0,0);

  strcpy(caQueType,gs_caBrCode);
  strcat(caQueType,gs_caTmCode);

  gs_iRdQueType = atol(caQueType);
  gs_iWrQueType = gs_iRdQueType + 1000*10000;

/*
  gs_iRdQueType = atoi(gs_caTmCode);
  gs_iWrQueType = gs_iRdQueType + 100;
*/  
  iQuFlag = IsUseQuType();
  if(iQuFlag < 0){
    ErrLog(1000,"DcsAttQue: IsUseQuType error!",RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  }

  if(iQuFlag){
    strcpy((char *)caFileName, (char *)getenv("III_DIR"));
    strcat(caFileName, DCS_TABLE_PATH);
    strcat(caFileName,"rmtquetbl");

    pfQueFile = fopen(caFileName,"rt");
    if( pfQueFile == NULL) {

#ifdef OMIT
 printf("open queuetbl error\n");
#endif
      sprintf("DcsAttQue:fopen %s fail errno=%d",caFileName,errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(DCS_E_NETWORKTBL);
    }

    strcpy(caDataType,"sdD");
    plDataVar[0] = (long *) caDesCode;
    plDataVar[1] = &gs_iQueKey;
    plDataVar[2] = &lQuType;

    i = 0;
    sg_iMaxQuId = 0;
    iLastQuKey = -1;	/* initial iLastQuKey */ 
    lQuSize = -1;	/* initial iQuSize = 0 */
    while((iRc = GetFileData(pfQueFile,3,caDataType,plDataVar)) == 0){
  
      if(lQuSize < 0){
        iRc = strncmp(caDesCode,"QUEUE_SIZE",10);
        if(iRc == 0){
          lQuSize = lQuType;
        }
        else{	/* no queue size data error */
          fclose(pfQueFile);
          ErrLog(1000,"AttQue: Queue Size no define error!",RPT_TO_LOG,0,0);
          UCP_TRACE_END(DCS_E_NETWORKTBL);
        } /* end of if(iRc == 0) -- else */
      }
      else{
        if((lQuSize > 0) && ((gs_iQueKey != iLastQuKey) ||
           (iLastQuKey == -1))){
          iRc = MsqGet(&gs_iQuId,gs_iQueKey);

#ifdef OMIT
printf("111 quekey %d queid %d\n",gs_iQueKey,gs_iQuId);
#endif

          if(iRc != 0){	/* creat queue error */
            UCP_TRACE_END(DCS_E_LOCALDCS);
          } /* end of if(iRc != 0) */
          iLastQuKey = gs_iQueKey;
        } /* end of if((lQuSize > 0) && ((gs_iQueKey != iLastQuKey) ||
                       (iLastQuKey == -1))) */
      } /* end of if(lQuSize < 0) -- else */ 
    } /* end of while((iRc = GetFileData(3,caDataType,plDataVar)) == 0) */

    fclose(pfQueFile);

  } /* end of if(iQuFlag) */


  ErrLog(100,"DcsAttQue End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}


int RdQue(char *pcCmd,char *pcaData,int *iLen) 
{
  int  iRc,i;
  long lQuType;
  int iSiofLen=MAX_LEN;
  struct MsgBuf stMsgp;
  struct Siof stSiof;
  unsigned char caTmp[600];

  UCP_TRACE(P_RdQue);
  memset(&stSiof,0x00,sizeof(struct Siof) );

  lQuType = gs_iRdQueType;
  memset(&stMsgp,0x00,sizeof(struct MsgBuf) );
  iRc = MsqRead(gs_iQuId,lQuType,&iSiofLen,&stMsgp,0);
  memcpy(&stSiof,stMsgp.caText,iSiofLen); 
/*
ErrLog(100,"DCS MAIN READ MSQ DATA",RPT_TO_LOG,&stSiof,iSiofLen);
*/
#ifdef OMIT
printf("iSiofLen %d Rdtype %d\n",iSiofLen-ALIMENT,gs_iRdQueType);
#endif

  if( iRc  != MSGQ_NORMAL )
    UCP_TRACE_END( MSGQ_ERROR );

  *iLen = stSiof.iSiofLen;
  *pcCmd = stSiof.cDcsCmd;
  memcpy(pcaData,stSiof.ucaSiofData,*iLen);


  UCP_TRACE_END( MSGQ_NORMAL );

}



int WrQue(char *pcRc,char *pcaData,int *iSiofLen) 
{

  int  iRc,i;
  long lQuType;
  int iTmpLen;
  struct MsgBuf stMsgp;
  struct Siof stSiof;
  unsigned char caTmp[600];
  unsigned char caTmpFile[10];


  UCP_TRACE(P_WrQue);  
  ErrLog(10,"WrQue.Begin ",RPT_TO_LOG,0,0);

  memset(&stSiof,0x00,sizeof(struct Siof) );

  stSiof.cDcsCmd=*pcRc;
  stSiof.iSiofLen=*iSiofLen;

  memset(stSiof.ucaSiofData,0x00,*iSiofLen); 
  memcpy(stSiof.ucaSiofData,pcaData,*iSiofLen); 
  strcpy(caTmpFile,"tmpfile");

  iTmpLen = *iSiofLen + ALIMENT;

  stMsgp.lType=gs_iWrQueType;

#ifdef OMIT
printf("write iMsgLen %d wrtype %d\n",*iSiofLen,gs_iWrQueType);
#endif
  memcpy(stMsgp.caText,&stSiof,iTmpLen); 
/*
ErrLog(100,"DCSMAIN WRITE MSQ DATA",RPT_TO_LOG,stMsgp.caText,iTmpLen);
*/
  iRc = MsqWrite(gs_iQuId,iTmpLen,&stMsgp,IPC_NOWAIT,caTmpFile);

  if( iRc  != MSGQ_NORMAL )
    UCP_TRACE_END( MSGQ_ERROR );

  UCP_TRACE_END( MSGQ_NORMAL );

}



int
IsUseQuType()
{
  int i;
  int iRc=0;
  char caFileName[80];
  char *pcFoundFlg;
  /* for get data */
  char caDataType[5];
  long *plDataVar[5];
  /* input data variable for prototbl */
  char caDesCode[20];
  char cProtoType;
  /* input data variable for queuetbl */
  int iQuFlag;
  FILE *pfProtoFile;

  UCP_TRACE(P_IsUseQuType);
  ErrLog(100,"IsUseQuType Begin.",RPT_TO_LOG,0,0);
  
  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat(caFileName, DCS_TABLE_PATH);
  strcat(caFileName,"rmtprototbl");

  pfProtoFile = fopen(caFileName,"rt");
  if( pfProtoFile == NULL) {
    sprintf("IsUseQuType:fopen %s fail errno=%d",caFileName,errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  }

  strcpy(caDataType,"sc");
  plDataVar[0] = (long *) caDesCode;
  plDataVar[1] = (long *) &cProtoType;

  /* read prototbl to check that is queue protocol used ? */
  iQuFlag = 0;
  while((iRc = GetFileData(pfProtoFile,2,caDataType,plDataVar)) == 0){
    if(cProtoType == 'Q'){
      iQuFlag = 1;
      break;
    }
  } /* end of while((iRc = GetFileData(2,caDataType,plDataVar)) == 0) */

  fclose(pfProtoFile);

  ErrLog(100,"IsUseQuType End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(iQuFlag);
}




int
GetFileData(FILE *pfFile, int iDataNo,char caDataType[], long* plDataVar[])
{
  int i;
  long lOffset;
  char caDataBuf[MAX_DATA_LEN];
  char cBypass,cDummy;

  UCP_TRACE(P_GetFileData);

  do {
    if(feof(pfFile)){
      UCP_TRACE_END(-1);
    }

    fgets(caDataBuf,MAX_DATA_LEN,pfFile);
    if (caDataBuf[0] != '#') {
      lOffset = (long) strlen(caDataBuf) * -1;
      fseek(pfFile,lOffset,SEEK_CUR);

      for(i=0; i < iDataNo ; i++){

        fscanf(pfFile,"%c",&cBypass);
        if( cBypass != '*') {

          fseek(pfFile,-1,SEEK_CUR);
          switch(caDataType[i]){
            case 't' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%d\n",(short *) plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%d ",(short *) plDataVar[i]);
              }
              break;
            case 'd' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%d\n",(int *) plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%d ",(int *) plDataVar[i]);
              }
              break;
            case 'D' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%ld\n",(long *) plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%ld ",(long *) plDataVar[i]);
              }
              break;
            case 'o' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%o\n",(int *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%o ",(int *)plDataVar[i]);
              }
              break;
            case 'O' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%lo\n",(long *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%lo ",(long *)plDataVar[i]);
              }
              break;
            case 'x' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%x\n",(int *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%x ",(int *)plDataVar[i]);
              }
              break;
            case 'X' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%lx\n",(long *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%lx ",(long *)plDataVar[i]);
              }
              break;
            case 'i' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%i\n",(int *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%i ",(int *)plDataVar[i]);
              }
              break;
            case 'I' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%li\n",(long *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%li ",(long *)plDataVar[i]);
              }
              break;
            case 's' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%s\n",(char *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%s ",(char *)plDataVar[i]);
              }
              break;
            case 'c' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%c\n",(char *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%c ",(char *)plDataVar[i]);
              }
              break;
            default :
              sprintf(g_caMsg,"GetFileData: data-type=%c error",caDataType[i]);
              ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
              UCP_TRACE_END(-2);
          }  /* end switch */
        }
        else {
          if( (i == iDataNo-1) && (cDummy == '\n') ) {
            fscanf(pfFile,"\n");
            UCP_TRACE_END(0);
          }
          else fscanf(pfFile," ");
        } /* end if '*' */
      }  /* end for */
    }  /* end if  '#' */
  } while(caDataBuf[0] == '#');

  UCP_TRACE_END(0);
}
