#include        <sys/types.h>
#include        <errno.h>
#include        <fcntl.h>
#include        <stdio.h>
#include        <malloc.h>

#include        "errlog.h"	/* error log include file */
#include        "dcs.h"		/* dcs api include file */
#include        "twa.h"		/* dcs api include file */
#include        "cwa.h"
#include  "big2host.h"
#include  "dccpgdef.h" 

#define  USIF_HEAD_LEN               17
#define  SIF_HEAD_LEN                51
#define  USOF_HEAD_LEN               15
#define  STATUS                      25 
#define  START_PGM_ERR			-4
#define   SIFHEADLEN  51
#define   FILE_OVER  -9
#define FORMAT_CONV_ERROR  -1
#define CODE_CONV_ERROR    -2
#define GET_SERV_NAME_ERROR  -3
#define SND_SIF_TO_SERV_ERROR -4
#define RCV_SOF_FRM_SERV_ERROR -5
 
#define  OUTPT_PREFIX  "iii/log/output"
#define  OUTPT_EJ  "iii/log/ej"
#define  RCV_OK 			'1'
#define  RCV_ERR			'0'

#ifdef OMIT
  #define  _MAIN_PROGRAM 1
#endif

#ifdef OMIT
 char       *g_pcCtf;
 struct TMA *g_pstTma;
 struct TBA *g_pstTba;
 struct APA *g_pstApa;
 int    g_iBrhCodeLen;
 int    g_iTmCodeLen;
#endif

extern char       *g_pcCtf;
extern struct TMA *g_pstTma;
extern struct TBA *g_pstTba;
extern struct APA *g_pstApa;
extern int    g_iBrhCodeLen;
extern int    g_iTmCodeLen;

char           g_cRcvRmtDataFlag; /* indicate rcv rmt data OK or not?     */

char g_cRcvRmtDataFlag; /* indicate rcv rmt data OK or not?     */

  struct PB_UCPSIF {
  char txn_code[4];
  char txt_id[4];
  char br_id[3];
  char tm_id[2];
  char tell_id[2];
  char line_no;
  char ctl_byte;
/*                    modified by YEN 950510 for reentry transaction
  char batlen[2];
  char lendata[511];
*/
  char lendata[513];
  } ;

  struct PB_TPESIF {
  char txn_code[4];
  char txt_id[6];
  char br_id[10];
  char tm_id[4];
  char tell_id[4];
  char user_data[20];
  char line_no;
  char ctl_byte[2];
  char lendata[469];
  } ;


  struct PB_UCPSOF {
  char fmh[3];
  char br_id[3];
  char tm_id[2];
  char out_dev;
  char form_id[4];
  char status;
  char ctl_byte;
  char lendata[505];
  } ;

  struct PB_TPESOF {
  char fmh[3];
  char br_id[10];
  char tm_id[4];
  char out_dev;
  char form_id[7];
  char status[2];
  char lendata[493];
  } ;


struct TpuSof {
  int  iLen;
  unsigned char ucaData[ SOF_SIZE ];
  };
struct TpuSof  g_staTpuSof[ MAX_SOF ];


struct TpuEj {
  int  iLen;
  unsigned char ucaData[ SOF_SIZE ];
  };
struct TpuEj  g_staTpuEj[ MAX_SOF ];


struct table_array cnv_tbl;
struct table_array *cnv_ptr;
struct Big2Nhost *pstCnvPtr;

extern struct DcsApi *g_pstDcsApi;
extern struct DcsBuf g_stDcsBuf;

static int   g_iSofTolCnt = 0;
static int   g_iEjTolCnt = 0;

static  FILE *g_pzSif;


/* ----- add by chi-fusong ----for Time out Adjustment -----begin ------ */
/* *********************************************************** */
/* g_caMemBuf contain MemBufCtl MSGP + REINPUT SIF + remote reverse txn SIF + 
   POST + SOF_HEAD_LEN_PLUS_2*2 (for control) + g_stHostToBrhInfo(100 bytes) */
extern char g_caMemBuf[MAX_MSGP_LEN + MAX_SIF_LEN * 2 + 2000 + 300 ];
struct  MemBufCtlSt{
  short sMsgCnt;
  short sNextOffset;
};
/* ----- add by chi-fusong ----for Time out Adjustment -----end   ------ */



int
RmtProc(unsigned char *caSifTmpBuf,int iTpeSifLen,char *pcRmtApFlg)
{
  int i,iFd,iEjFd;
  int iFirst = 1;
  int iRc;
  int iTpeTmpSifLen ;
  char   caFileName[80];
  unsigned char caSifBuf[ SIF_SIZE ];
  struct CwaCtl stCwaCtl;
  char caLogName[256];
  struct MemBufCtlSt *pstMemBufCtl;


  memset(g_pstTba->caPara,0,MAX_TBA_PARA_LEN);  /* added by YEN 0322 */
  sprintf(caLogName, "%s/iii/log/tms_errlog", getenv("III_DIR") );
  /*ChgLog(LOG_CHG_MODE,"1");*/
  ChgLog(LOG_CHG_LOG,caLogName);

  if (iFirst) 
  { 
    stCwaCtl.cFunCode = CWA_GET_SEG_PTR;
    stCwaCtl.cSegCode = CWA_SEG_B2N;

    iRc = CwaLowCtlFac(&stCwaCtl,&pstCnvPtr);
    if (iRc != 0) {
      return(-1);
    }
    iFirst = 0;
  }


  cnv_ptr  = (struct table_array *) pstCnvPtr;
  if( CheckCvtTbl() )
  {
    ErrLog(1000," error SendSifToServ.Init_Cvt_Table",RPT_TO_LOG,0,0);
    Init_Cvt_Table(cnv_ptr);
  }

  iTpeTmpSifLen = iTpeSifLen;

  ErrLog(100,"From Tpu Sif",RPT_TO_LOG,caSifTmpBuf,iTpeTmpSifLen);

  if((iRc=TpeToUcpSif(caSifTmpBuf, caSifBuf, &iTpeTmpSifLen))<0)
    return(iRc);

  sprintf(g_caMsg,"xxxx SendSifToServ Ucp Sif Len %d",iTpeTmpSifLen);
  ErrLog(100,g_caMsg,RPT_TO_LOG,caSifBuf,iTpeTmpSifLen);
  
  if( (iRc  =  DcsUcpu(caSifBuf, iTpeTmpSifLen, pcRmtApFlg,caSifTmpBuf) ) < 0 )
  {
    sprintf(g_caMsg,"<RemoteTxn>: send data to HOST error! iRc=%d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    return(SND_SIF_TO_SERV_ERROR  );
  }
  else {
    ErrLog(100,"End DcsUcpu",RPT_TO_LOG,0,0);
  }

  iRc = RcvSofAll(&g_iSofTolCnt);

  iRc = RcvEjAll(&g_iEjTolCnt);


#ifdef OMIT
  sprintf(caFileName,"%s/%s%.*s.%.*s",getenv("III_DIR"),OUTPT_PREFIX,
          g_iTmCodeLen, g_pstTma->stTSSA.caTmCode,
          g_iBrhCodeLen, g_pstTma->stTSSA.caBrCode);


  iFd = open(caFileName,O_CREAT|O_TRUNC|O_RDWR,0660);
  if ( iFd < 0 ) {
      sprintf(g_caMsg,"<RcvHostDataToFile>: open File=sof.dat error!");
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      /* disconnect */
      return(-1);
  }
#endif

  /* Clear  g_caMemBuf */
  memset(g_caMemBuf, '\0', sizeof(g_caMemBuf));
  pstMemBufCtl = (struct MemBufCtlSt *)g_caMemBuf;
  pstMemBufCtl->sNextOffset = sizeof(struct MemBufCtlSt);
  pstMemBufCtl->sMsgCnt     = 0;

  for(i=0;i<g_iSofTolCnt;i++){

    if( (unsigned char) g_staTpuSof[i].ucaData[STATUS]
         ==(unsigned char)0x08 )
    {
      g_staTpuSof[i].ucaData[STATUS] = (unsigned char) 0x88 ;
      iRc = MemWrite(g_staTpuSof[i].ucaData,g_staTpuSof[i].iLen, 1);

      g_iSofTolCnt = i+1;
      sprintf(g_caMsg,"after write output file dbp SofCnt %d",g_iSofTolCnt);
      ErrLog(100,g_caMsg,RPT_TO_LOG,g_staTpuSof[i].ucaData,
                  g_staTpuSof[i].iLen );

      if( iRc !=  g_staTpuSof[i].iLen ) {
        sprintf(g_caMsg,
        "write() 0x88 sof error! write size=%d,write() rtn size=%d",
                g_staTpuSof[i].iLen,iRc);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        return(-1);
      }

      break;
    }

      if (g_staTpuSof[i].iLen < STATUS + 4) {
        g_staTpuSof[i].iLen = STATUS +4 ;
        iRc = MemWrite(g_staTpuSof[i].ucaData,g_staTpuSof[i].iLen, 1);
      }
      else 
        iRc = MemWrite(g_staTpuSof[i].ucaData,g_staTpuSof[i].iLen, 1);


      sprintf(g_caMsg,"after write output file dbp SofCnt %d",g_iSofTolCnt);
      ErrLog(100,g_caMsg,RPT_TO_LOG,g_staTpuSof[i].ucaData,
                  g_staTpuSof[i].iLen );

      if( iRc !=  g_staTpuSof[i].iLen ) {
        sprintf(g_caMsg,
        "write() sof error! write size=%d,write() rtn size=%d",
                g_staTpuSof[i].iLen,iRc);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        return(-1);
      }
  }

#ifdef OMIT
  iRc = close(iFd);
  if ( iRc < 0 ) {
    sprintf(g_caMsg,"<RcvHostDataToFile>: close() File=sof.dat error!");
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    return(-1);
  }
#endif

  g_cRcvRmtDataFlag = RCV_OK;

#ifdef OMIT
  sprintf(caFileName,"%s/%s%.*s.%.*s",getenv("III_DIR"),OUTPT_EJ,
          g_iTmCodeLen, g_pstTma->stTSSA.caTmCode,
          g_iBrhCodeLen, g_pstTma->stTSSA.caBrCode);


  iEjFd = open(caFileName,O_CREAT|O_TRUNC|O_RDWR,0660);
  if ( iEjFd < 0 ) {
      sprintf(g_caMsg," open Ej File=ej.dat error");
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      return(-1);
  }

  for(i=0;i<g_iEjTolCnt;i++){
      iRc = write(iEjFd,g_staTpuEj[i].ucaData,g_staTpuEj[i].iLen);
      if( iRc !=  g_staTpuEj[i].iLen ) {
        sprintf(g_caMsg,
        "write() Ej error! write size=%d,write() rtn size=%d",
                g_staTpuEj[i].iLen,iRc);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        return(-1);
      }
  }

  iRc = close(iEjFd);
  if ( iRc < 0 ) {
    sprintf(g_caMsg,"<RcvHostDataToFile>: close() File=ej.dat error!");
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    return(-1);
  }
#endif

#ifdef OMIT
  sprintf(g_caMsg,"in SendSifToServ:iEjTolCnt=%d",g_iSofTolCnt);
  ErrLog(1000, g_caMsg, RPT_TO_LOG,0,0);
#endif

  return( 0 );

}




int
RcvSofAll(int *iSofCnt)
{
  int iDx=0;
  int iUcpSofLen = 33;
  unsigned char caSofTmpBuf[ SOF_SIZE ];
  unsigned char caSofBuf[ SOF_SIZE ];

#ifdef  OMIT
  caSofTmpBuf = malloc (SOF_SIZE);
  caSofBuf = malloc (SOF_SIZE);
#endif

  ErrLog(100,"start RcvSofAll",RPT_TO_LOG,0,0);

  for( GetHostSof(caSofTmpBuf,&iUcpSofLen);
       iUcpSofLen > 0; GetHostSof(caSofTmpBuf,&iUcpSofLen))
  {
    memset(caSofBuf,0x00,iUcpSofLen);

    ErrLog(100,"RcvSofAll() HostSof data",RPT_TO_LOG,caSofTmpBuf,iUcpSofLen);

    TpeSofToTpu(caSofTmpBuf, caSofBuf, &iUcpSofLen);


    memset( g_staTpuSof[ iDx ].ucaData, 0x00, SOF_SIZE );

    g_staTpuSof[ iDx ].iLen = iUcpSofLen;
    memcpy( g_staTpuSof[ iDx ].ucaData, caSofBuf, g_staTpuSof[ iDx ].iLen );

/*
    sprintf(g_caMsg,"RcvSofAll() iDx %d",iDx);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,
           g_staTpuSof[iDx].ucaData,g_staTpuSof[iDx].iLen);
*/
    iDx++;
  }

  *iSofCnt = iDx;  

  return(0);

}


int
RcvEjAll(int *iEjCnt)
{
  int iDx=0;
  int iUcpEjLen = 33;
  unsigned char caSofTmpBuf[ SOF_SIZE ];
  unsigned char caSofBuf[ SOF_SIZE ];

  ErrLog(100,"start RcvEjAll",RPT_TO_LOG,0,0);

  for( GetHostEj(caSofTmpBuf,&iUcpEjLen);
       iUcpEjLen > 0; GetHostEj(caSofTmpBuf,&iUcpEjLen))
  {
    memset(caSofBuf,0x00,iUcpEjLen);
/*
    ErrLog(1000,"RcvSofAll() HostSof data",RPT_TO_LOG,caSofTmpBuf,iUcpSofLen);
*/
    TpeSofToTpu(caSofTmpBuf, caSofBuf, &iUcpEjLen);

    g_staTpuEj[ iDx ].iLen = iUcpEjLen;
    memcpy( g_staTpuEj[ iDx ].ucaData, caSofBuf, g_staTpuEj[ iDx ].iLen );
    
    iDx++;
  }

/* added by YEN 0322-1995 begin  */
  ErrLog(100,"EJ1234",RPT_TO_LOG,0,0);
  if (g_staTpuEj[0].iLen >= 29 ) {
    memcpy(g_pstTba->caPara,&(g_staTpuEj[0].ucaData[29]),g_staTpuEj[0].iLen-29);
    ErrLog(100,"postdata1=",RPT_TO_LOG,g_pstTba->caPara,g_staTpuEj[0].iLen-29);
    *iEjCnt = iDx;  
  }
/* added by YEN 0322-1995 end  */

  return(0);

}



int 
TpeToUcpSif(unsigned char *pcaTpeSif,unsigned char *pcaUcpSif, int *iSifLen)
{
  int iRc;
  int iTpeSifLen,iUcpSifLen;
  unsigned char caHostTpeSif[ MAX_LEN +8 ];
  unsigned char caHostUcpSif[ MAX_LEN +8 ];


  iTpeSifLen = *iSifLen; 

  if((iRc  =  Big5ToHostSif( pcaTpeSif, caHostTpeSif , &iTpeSifLen ))
      ==  DCS_NORMAL)
  {

    ErrLog(100,"Tpe Sif ok (to ebcdic) ",RPT_TO_LOG,caHostTpeSif,iTpeSifLen);

  }
  else { 
    ErrLog(1000,"Tpe Sif error",RPT_TO_LOG,caHostTpeSif,iTpeSifLen);
    return ( CODE_CONV_ERROR);
  }


  iUcpSifLen = iTpeSifLen;

  if((iRc  =  SifReFmt( caHostTpeSif , caHostUcpSif , &iUcpSifLen))
      ==  DCS_NORMAL)
  {
/*
    ErrLog(1000,"Ucp Sif ok",RPT_TO_LOG,caHostUcpSif,iUcpSifLen);
*/
  }
  else { 
    ErrLog(1000,"Ucp Sif error",RPT_TO_LOG,caHostUcpSif,iUcpSifLen);
    return ( FORMAT_CONV_ERROR);
  }  
/* 
  ErrLog(1000,"zzz after SifReFmt",RPT_TO_LOG,caHostUcpSif,iUcpSifLen+5);
*/

  *iSifLen = iUcpSifLen;
  memcpy(pcaUcpSif,caHostUcpSif,iUcpSifLen);

return(0);


} 


int 
TpeSofToTpu(char *pcaUcpSof,char *pcaTpeSof, int *iSofLen)
{
int iRc;
int iTpeSofLen,iUcpSofLen;
unsigned char caHostTpeSof[ MAX_LEN +8 ];
unsigned char caHostUcpSof[ MAX_LEN +8 ];

  iUcpSofLen = *iSofLen; 

  if((iRc  =  SofReFmt( pcaUcpSof , caHostTpeSof , &iUcpSofLen))
      ==  DCS_NORMAL)
  {

    ErrLog(100,"Tpe Sof refmt ebcdic ok ",RPT_TO_LOG,caHostTpeSof,iUcpSofLen);

  }
  else { 
    ErrLog(1000,"Tpe Sof refmt error",RPT_TO_LOG,caHostTpeSof,iUcpSofLen);
    return ( FORMAT_CONV_ERROR);
  }  


  iTpeSofLen = iUcpSofLen;

  memcpy(pcaTpeSof,caHostTpeSof,iTpeSofLen);

  if((iRc  =  HostToBig5Sof( pcaTpeSof , &iTpeSofLen ))
      ==  DCS_NORMAL)
  {

    *iSofLen = iTpeSofLen;
    sprintf(g_caMsg,"TpeSofToTpu.HostToBig5Sof():OK,iTpeSofLen %d ",iTpeSofLen);
    ErrLog(100,g_caMsg,RPT_TO_LOG,caHostTpeSof,iTpeSofLen);

  }
  else { 
    ErrLog(1000,"Tpu Tpe Sof error",RPT_TO_LOG,caHostTpeSof,iTpeSofLen);
    return ( CODE_CONV_ERROR);
  }

return(0);

} 


int
SifReFmt(struct PB_TPESIF *pstHostTpeSif,struct PB_UCPSIF *pstHostUcpSif,
         int *iSifLen)
{
int iRc,i;

  memcpy(pstHostUcpSif->txn_code,pstHostTpeSif->txn_code,4);
  memcpy(pstHostUcpSif->txt_id,pstHostTpeSif->txt_id,4);
  memcpy(pstHostUcpSif->br_id,pstHostTpeSif->br_id,3);
  memcpy(pstHostUcpSif->tm_id,pstHostTpeSif->tm_id,2);
  memcpy(pstHostUcpSif->tell_id,pstHostTpeSif->tell_id,2);
  pstHostUcpSif->line_no = pstHostTpeSif->line_no;
  pstHostUcpSif->ctl_byte = pstHostTpeSif->ctl_byte[0];

  if( (i=*iSifLen-SIF_HEAD_LEN) > 0){
    if ( pstHostUcpSif->ctl_byte & 0x01 ) { /* reentry txn SIF */
       memcpy(pstHostUcpSif->lendata,pstHostTpeSif->lendata,
              *iSifLen-SIF_HEAD_LEN);
       *iSifLen = *iSifLen-(SIF_HEAD_LEN - USIF_HEAD_LEN ); 
    }
    else {   /* normal txn SIF */
       memset(pstHostUcpSif->lendata,0x00,2);
       memcpy(pstHostUcpSif->lendata+2,pstHostTpeSif->lendata,
              *iSifLen-SIF_HEAD_LEN);
       *iSifLen = *iSifLen-(SIF_HEAD_LEN - USIF_HEAD_LEN - 2); 
    }
  } 
  else {
    memset(pstHostUcpSif->lendata,0x00,2);
    *iSifLen = *iSifLen-(SIF_HEAD_LEN - USIF_HEAD_LEN - 2); 
  }

  return (DCS_NORMAL);
}


int
SofReFmt(struct PB_UCPSOF *pstHostUcpSof,struct PB_TPESOF *pstHostTpeSof,
         int *iSofLen)
{
int iRc;
int i;

  memset(pstHostTpeSof,0x00,*iSofLen+12);

  memcpy(pstHostTpeSof->fmh,pstHostUcpSof->fmh,3);
  memcpy(pstHostTpeSof->br_id,pstHostUcpSof->br_id,3);
  memcpy(pstHostTpeSof->tm_id,pstHostUcpSof->tm_id,2);
  pstHostTpeSof->out_dev = pstHostUcpSof->out_dev;
  memcpy(pstHostTpeSof->form_id,pstHostUcpSof->form_id,4);
  pstHostTpeSof->status[0] = pstHostUcpSof->status;

  i = *iSofLen-USOF_HEAD_LEN;

 if(i > 0)
   memcpy(pstHostTpeSof->lendata,pstHostUcpSof->lendata,*iSofLen-USOF_HEAD_LEN);
 else if (i == 0)
  {
    memset(pstHostTpeSof->lendata,0x00,2);
    *iSofLen = *iSofLen + 2 ;
  }
  else
  {
  }

  *iSofLen = *iSofLen+12; 

  return (DCS_NORMAL);

}


int  CheckCvtTbl()
{
unsigned char caBigWord[8];
unsigned char caHstWord[8];
int      iRc, iLen;

  caBigWord[0] = 0xb1;
  caBigWord[1] = 0x69;
  caHstWord[0] = 0xb1;
  caHstWord[1] = 0x69;

  big5_host( caBigWord, caHstWord,2,cnv_ptr);

  if( (unsigned char)caHstWord[1] == (unsigned char)0x57 &&
       (unsigned char)caHstWord[2] == (unsigned char)0x4f )
    return(0);
  return( -1 );
}

/******************************/
/*  useless function !        */
/******************************/
int
crtsif(char *pcSif, int *iSifLen)
{
  int iRc;
  int iOffset=0;
  short sDataLen;
  char caTmp[300];
  char caTmp2[50];
  char caTmpx[100];
  char *pcTmp;
  struct PB_TPESIF stSif;

  /*pcTmp = malloc(100);*/
  pcTmp = caTmpx;
  memset(&stSif,0x30,sizeof(struct PB_TPESIF));

  while(1)
  {
    if ((pcTmp = fgets(caTmp,sizeof(caTmp),g_pzSif)) == NULL){
	fclose(g_pzSif);
  	return(-1);
    }

    pcTmp = strtok(caTmp, " |\t") ;

    if( strncmp(pcTmp,"###",3) == 0)  {
      fclose(g_pzSif);
      return(FILE_OVER);
    }

    if( strncmp(pcTmp,"#",1) == 0)  continue;

    if( strncmp(pcTmp,"%",1) == 0){

      iOffset=0;

      pcTmp = strtok(NULL, " |\t") ;
      memcpy(stSif.txn_code,pcTmp,strlen(pcTmp));

      pcTmp = strtok(NULL, " |\t") ;
      memcpy(stSif.txt_id,pcTmp,strlen(pcTmp));

      pcTmp = strtok(NULL, " |\t") ;
      memcpy(stSif.br_id,pcTmp,strlen(pcTmp));

      pcTmp = strtok(NULL, " |\t") ;
      memcpy(stSif.tm_id,pcTmp,strlen(pcTmp));

      pcTmp = strtok(NULL, " |\t") ;
      memcpy(stSif.tell_id,pcTmp,strlen(pcTmp));

      pcTmp = strtok(NULL, " |\t") ;
      memcpy(stSif.user_data,pcTmp,strlen(pcTmp));

      pcTmp = strtok(NULL, " |\t") ;

      if( strncmp(pcTmp,"0",1) == 0){
        stSif.line_no = 0x00;
      }
      else
        stSif.line_no = pcTmp[0];
    

      pcTmp = strtok(NULL, " |\t") ;

      if( strncmp(pcTmp,"sb",2) == 0){
        memcpy(stSif.ctl_byte,"\x18\x00",2);
      }
      else if( strncmp(pcTmp,"*b",2) == 0){
        memcpy(stSif.ctl_byte,"\x08\x00",2);
      }
      else if( strncmp(pcTmp,"s*",2) == 0){
        memcpy(stSif.ctl_byte,"\x10\x00",2);
      }
      else {
        memcpy(stSif.ctl_byte,"\x00\x00",2);
      }

      memcpy(caTmp2,stSif.ctl_byte,2);


      while( strncmp(pcTmp,"@",1) != 0 )
      {
        pcTmp = strtok(NULL, " |\t") ;

        if( strncmp(pcTmp,"@",1) != 0 )
        {
          sDataLen = strlen(pcTmp);
          memcpy(&stSif.lendata[iOffset],&sDataLen,2);
          iOffset =iOffset + 2;
          memcpy(&stSif.lendata[iOffset],pcTmp,strlen(pcTmp) );
          iOffset =iOffset + strlen(pcTmp);
        }
      } 

      *iSifLen = iOffset + SIF_HEAD_LEN ; 
      memcpy(pcSif,&stSif,*iSifLen);
/*
      ErrLog(1000,"test sif data",RPT_TO_LOG,&stSif,*iSifLen);
*/
      return(0);
   }

  } 

}

