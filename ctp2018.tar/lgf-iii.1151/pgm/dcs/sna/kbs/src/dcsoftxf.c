#include  <errno.h>
#include  "big2host.h"
#include  "errlog.h"
#include  "dccpgdef.h"
#include  "dcs.h"
/*********************************************************************/
/* PROGRAM-NAME:dcsofcnv.c                                           */
/* PROGRAM-ID:                                                       */
/* LAST-UPDATE-DATE:                                                 */
/* THE MAN WHO MOFIDIED:                                             */
/*********************************************************************/
/*  for TPE format  */
#define  SOF_HEAD_LEN               27
#define  SOF_CTL_OFFS               25
#define  SOF_MSGLEN_OFFS            27
#define  SOF_MSGDATA_OFFS           29
#define  SI                         0x0e
#define  SO                         0x0f


/*  for UCP format   
#define  SOF_HEAD_LEN               13
#define  SOF_CTL_OFFS               13
#define  SOF_MSGLEN_OFFS            15
#define  SOF_MSGDATA_OFFS           17
#define  SI                         0x0e
#define  SO                         0x0f
*/

#define err_log   ErrLog
#define  MSG_STR g_caMsg

#define  swapshort(X)              X=((X>>8)&0x00FF)|((X<<8)&0xFF00)
#ifdef  OMIT
#define  swapshort(X)              X=X
#endif

extern struct table_array cnv_tbl;
extern struct table_array *cnv_ptr;
  
int
HostToBig5Sof(unsigned char *pucaHstSof,int *iHstSofLen)
{
 unsigned char  ucaUnxSof[2048];
 short sShtLen;
 int i,j,rt_len;
 int iUnxSofLen;
 int rc;

 UCP_TRACE(P_dcsofcnv);

 sprintf(g_caMsg,"dcsoftxf:iHstSofLen=%d,pucaHstSof",*iHstSofLen);
 err_log(100,g_caMsg,RPT_TO_LOG,pucaHstSof,*iHstSofLen);
 
 if((i=host_big5(pucaHstSof,ucaUnxSof,SOF_HEAD_LEN+2,cnv_ptr))!=SOF_HEAD_LEN+2)
{
   sprintf(MSG_STR,"SOF head code conversion error len=%d !",i);
   err_log(2000,MSG_STR,RPT_TO_LOG,0,0);
   UCP_TRACE_END(-1);
 }


 memcpy(ucaUnxSof+SOF_CTL_OFFS,pucaHstSof+SOF_CTL_OFFS,1);  

   /* convert the txn status byte of SOF */
/*marked by eric 830926
 if ( host_big5(pucaHstSof+SOF_CTL_OFFS,ucaUnxSof+SOF_CTL_OFFS,2,cnv_ptr) !=1 ) {
   err_log(2000,"dcsofcnv.host_big5:SOF[14]convert error!",RPT_TO_LOG,0,0);
   UCP_TRACE_END(-1);
}
*/


if((i=*iHstSofLen-SOF_HEAD_LEN) > 0) {

 sShtLen  = pucaHstSof[ SOF_MSGLEN_OFFS ] * 256 
          + pucaHstSof[ SOF_MSGLEN_OFFS +1 ]; 

 memcpy((char *)(ucaUnxSof+SOF_MSGLEN_OFFS),&pucaHstSof[ SOF_MSGLEN_OFFS],2);

 for (i=SOF_MSGDATA_OFFS; i<sShtLen+SOF_MSGDATA_OFFS; ) {
   if (pucaHstSof[i] == SI) {   
     j=i;
     while ( (pucaHstSof[i] != SO) && (i < sShtLen+SOF_MSGDATA_OFFS) ) {
        i++;
     }
     if ( i == sShtLen+SOF_MSGDATA_OFFS ) {
        err_log(2000,"SOF DATA NO SHIFT-OUT ERROR !",RPT_TO_LOG,0,0);
        UCP_TRACE_END(-1);
     }
     i++; 
     rt_len=host_big5(pucaHstSof+j,ucaUnxSof+j,i-j,cnv_ptr);

     memset(ucaUnxSof+j+rt_len,' ',(i-j)-rt_len);  
   }
   else  {             
     j=i;
     while ( (pucaHstSof[i] != SI) && (i < sShtLen+SOF_MSGDATA_OFFS) )
        i++;
     if ( host_big5(pucaHstSof+j,ucaUnxSof+j,i-j,cnv_ptr) != (i-j) ) {
        err_log(2000,"SOF English data code conversion error !",RPT_TO_LOG,0,0);
        UCP_TRACE_END(-1);
     }
   }
 }  

 iUnxSofLen = sShtLen + SOF_MSGDATA_OFFS;
 *iHstSofLen = iUnxSofLen;

}  /* if iHstSofLen > HEAD_LEN */ 
 memcpy( pucaHstSof, ucaUnxSof, *iHstSofLen );

/*
 sprintf(MSG_STR,"dcsofcnv over=%d,pucaHstSof",*iHstSofLen);
 err_log(100,MSG_STR,RPT_TO_LOG,pucaHstSof,*iHstSofLen);
*/
 UCP_TRACE_END(0);
}
  


int
HostToGbRein(unsigned char *pucaHstSof,int *iHstSofLen)
{
 unsigned char  ucaUnxSof[2048];
 unsigned char  ucaTmpBuf[2048];
 unsigned char  ucaReinBuf[2048];
 short sShtLen;
 int i,j,rt_len;
 int iUnxSofLen;
 int rc;
 int iLen;

 UCP_TRACE(P_dcsofcnv);

 sprintf(g_caMsg,"dcsoftxf reinput :iHstSofLen=%d,pucaHstSof",*iHstSofLen);
 err_log(100,g_caMsg,RPT_TO_LOG,pucaHstSof,*iHstSofLen);
 
 if((i=host_big5(pucaHstSof,ucaUnxSof,SOF_HEAD_LEN-2,cnv_ptr))!=SOF_HEAD_LEN-2)
 {
   sprintf(MSG_STR,"SOF head code conversion error len=%d !",i);
   err_log(2000,MSG_STR,RPT_TO_LOG,0,0);
   UCP_TRACE_END(-1);
 }

 memcpy(ucaUnxSof+SOF_CTL_OFFS,pucaHstSof+SOF_CTL_OFFS,4);  
 
 iLen = *iHstSofLen - SOF_MSGDATA_OFFS;
 memcpy(ucaTmpBuf,pucaHstSof+SOF_MSGDATA_OFFS,iLen);  


 rt_len = HostToGbSif(ucaTmpBuf,ucaReinBuf,&iLen);
 
 if (rt_len != 0)
 {
   sprintf(MSG_STR,"REINPUT code conversion error len=%d !",rt_len);
   err_log(2000,MSG_STR,RPT_TO_LOG,0,0);
   UCP_TRACE_END(-1);
 }
   
 memcpy(ucaUnxSof+SOF_MSGDATA_OFFS,ucaReinBuf,iLen);  


 iUnxSofLen = iLen + SOF_MSGDATA_OFFS;

 *iHstSofLen = iUnxSofLen;
 memcpy( pucaHstSof, ucaUnxSof, *iHstSofLen );


 UCP_TRACE_END(0);
}
  
