/*
dcmpsuio.c FUNCTION & SUBROUTINE DESCRIPTION
*&N&   
*&N&    TYPE      NAME                 DESCRIPTION
*&N& --------- ------------ ---------------------------------------- 
*&N&  int      TxnBridge
*&N&  int      SetupPsuioEnv
*&N&  int      GetCwaKey
*&N&  int      GetSrcName
*&N&  int      SendSofToClient
*&N&  int      SendErrToClient
*&N&  int      TransSofToClient
*&N&  int      SendSifToServ
*&N&  void     StopRtn
*&N&
*/

/* -------------------- INCLUDE FILES DECLARATION ------------------- */
#include        <sys/types.h>
#include        <sys/socket.h>
#include        <netinet/in.h>
#include        <netdb.h>
#include        <errno.h>
#include        <fcntl.h>
#include        <stdio.h>

#include        "errlog.h"	/* error log include file */
#include        "ucp.h"	        /* define SIF, SOF constant, etc */
#include        "cwa.h"		/* common working area include file */
#include        "dcs.h"		/* dcs api include file */

/* --------------------- constant define ------------------------------ */
#define  DCS_HAS_MORE_DATA	'1'
/* define in ucp.h
#define  SOF_HEAD_LEN	15
#define  BRCODE_LEN	3
#define  TMCODE_LEN	2
#define  ON_LINE_MODE	0x02
*/
#define  SK_HEAD_LEN	8
#define  ENV_VAR_LEN    80
#define  CONFIG_FILE	"iii/etc/tbl/config.dat"
#define  CWA_SHM_KEY	"CWA_SHM_KEY"

#define         TEL_FILLER_LEN     50
#define         TXNDATE_LEN         8

/* ----begin -----add for PTT random BIF scanning ----- 1995/01/05 ------- */
#define         PTT_DCS_TIMEOUT     40
/* ----end   -----add for PTT random BIF scanning ----- 1995/01/05 ------- */

/*& ----------------------------------------------------------------- */
/*&      structure define for teller file data used by input module   */
/*& ----------------------------------------------------------------- */
struct  tel_st
        {
        char    caBrCode[BR_CODE_LEN];      /*&Branch code       */
        char    caTmCode[TM_CODE_LEN];      /*&Terminal Code     */
        char    caTxnDate[TXNDATE_LEN];     /*&txn day*/
        char    cTxnMode;                   /*&'1':online or '2':batch*/
        char    caUsrId[TELLER_CODE_LEN];    /*&Teller ID         */
        char    cUsrAuth;                   /*&Authority         */
        char    caUsrFiller[TEL_FILLER_LEN];/*reserved*/
        };

/* ---------------------- data struct define --------------------------- */
struct FuncArraySt { 	/* function array data struct */
  char cKind;		/* protocol type */
  int (*FuncPtr)();	/* function pointer */
};


/* ------------- dcmpsuio.c function ���N�� ------------------------- */
#define P_PsuioMain		47101
#define P_SetupPsuioEnv 	47102
#define P_StopRtn          	47103
#define P_TxnBridge 		47104
#define P_GetSrcName  		47105
#define P_SendSifToServ 	47106
#define P_TransSofToClient 	47107
#define P_GetCwaKey 		47108
#define P_SendErrToClient 	47109
#define P_SendSofToClient 	47110
#define P_SystemSignOn     	47111
#define P_SystemSignOff    	47112
#define P_GetTxnDate 		47113

#define PASSIVE_SESSION_IDX     0 	/* keep passive Session idx */
#define CTL_OFF                 0
#define CTL_ON                  1
#define LAST_MSG_MASK       0x80
#define REINPUT_MSG_MASK    0x20
#define PRINT_MSG_MASK      0x10
#define ERROR_MSG_MASK      0x08
#define TPEO_MSG_MASK       0x02
#define ONLINE_MODE         '1'   
#define BATCH_MODE          '2'   

/* error message constant define */
#define RCV_DATA_FROM_CLIENT_ERR     1 	
#define RCV_DATA_LEN_ERR            -99 
#define GET_PEEE_NAME_ERR           -99 
#define GET_HOST_BY_ADDR_ERR        -17 
#define GET_BR_TM_CODE_LEN_ERR      -99 
#define GET_CWA_KEY_ERR             -99 
#define GET_CWA_SHM_ERR             -2 
#define GET_HOST_NAME_BY_BIT_ERR    -1 
#define GET_SYSTEM_STATUS_ERR       -99 
#define ILLEGAL_DATA_KIND_ERR       -8

#define PSU_CLT_TM_OUT              10   /* added by YEN 950408 */
/* -------------------- STATIC GLOBAL DECLARATION ------------------- */
int g_iActSess;		/* keep active Session idx */
char g_cKind;		/* keep function kind */
char g_cProtoType;	/* keep protocol type */
int g_iBrhCodeLen;
int g_iTmCodeLen ;
char g_caBrCode[MAX_BR_LEN   +1];	/* keep Branch code of peer */
char g_caTmCode[MAX_TM_LEN    +1];	/* keep Terminal code of peer */
char g_caBrTxnDate[TXNDATE_LEN+1];	/* keep Terminal code of peer */
/*struct BIT *g_pstTctTbl;	/* Tct Table of CWA pointer */

/* for env variabel use */
static char sg_caIiiPath[ENV_VAR_LEN];	/* UCP path */
static char sg_caIiiProtocol[ENV_VAR_LEN];	/* UCP path */
static char sg_caIiiDir[ENV_VAR_LEN];	/* UCP dir */
static char sg_caExePath[ENV_VAR_LEN];	/* exec path */
static char sg_caCisamPath[ENV_VAR_LEN];/* cisam data file path */
static char sg_caUnifyPath[ENV_VAR_LEN];/* unify data file path */
static char sg_caDefsize[ENV_VAR_LEN];	/* defsize */

/* for communication data sutruct */
struct DcsBuf g_stDcsBuf;
struct DcsSiof g_stDcsSiof;

/* ------ CALL FUNCTION & SUBROUTINE PROTOTYPE DECLARATIONS --------- */
int TxnBridge(struct DcsBuf *pstDcsBuf);
int GetTxnDate(struct DcsBuf *pstDcsBuf);
int SetupPsuioEnv(char *pcIiiDir, char *pcIiiProtocol);
int GetCwaKey();
int GetSrcName(char *pcHostName);
int SendSofToClient();
int SendErrToClient(int iErrCode);
int TransSofToClient();
int SendSifToServ(char *pcSifBuf,int iSifLen);
void StopRtn(int iRtnVal);

/* --------------------------- access cwa function --------------------- */
extern int AccessCwa(int);
extern int GetBrTmCodeLen(int*,int*);
extern int GetBrTmCode(char *, char *, char *,int ,int, char *);
extern int ChkBrTmCode(char *pcBrCode, char *pcTmCode,int,int);
/* --------------------------- function array --------------------------- */
extern int SystemSignOn();	/* TxnBridge function */
extern int SystemSignOff();
extern int GetName();	/* GetName function */
extern int ChkInit();	/* ChkInit function */

static struct FuncArraySt sg_staDcsFun[] = { '1',TxnBridge,
                                             '0',SystemSignOn,
                                             '3',SystemSignOff,
                                             '7',GetName,
                                             '8',GetTxnDate,
                                             '4',ChkInit };

/**********************************************************************
*&N& ROUTINE NAME: main
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& pcaArgv[1]      char *              socket descriptor
*&A& pcaArgv[2]      char *              client ip address
*&A& 
*&R& RETURN VALUE(S):
*&R&    0 : ���`.
*&R&    1 : Recieve data from Client error.
*&R&   -1 : Check Rcv Data length is equal to Data len of Client Sended.
*&R&   -2 : Get peer ip address error.
*&R&   -3 : Host name isn't defined in /etc/hosts.
*&R&   -4 : Get br_code or terminalcode length error.
*&R&   -5 : Get CWA key error.
*&R&   -6 : Get CWA shared memory error.
*&R&   -7 : Host name not defined in bit.dat.
*&R&  -99 : illegal data kind

       ----- old error code -----
*&R&   -2 : illegal user
*&R&   -3 : password error
*&R&   -4 : termial name not defined
*&R&   -5 : termial name not defined
*&R&   -8 : ems isn't open
*&R&   -9 : teller file is empty
*&R&  -18 : teller file open error
*&R&  -19 : teller file operation error
*&R&  -99 : illegal kind
*&R&
*&D& DESCRIPTION:
*&D&  1.�O���}�l�ɶ�.
*&D&  2.�T���]�w(Setting signal handle routing).
*&D&  3.�������ҳ]�w(Setup Environment) 
*&D&    3.1 �����ܼƪ��]�w�p:
*&D&        III_DIR,III_PROCOTOL, CISAM_PATH, UNIFY �������ܼơC
*&D&  4.���� Client �ݰe�Ӫ����.
*&D&  5.�ˬd���쪺��ƬO�_���T.
*&D&  6.Ū�� Client �� host name �� IP address.
*&D&  7.Ū�� CWA ���_�l��}�C
*&D&  8.�ˬd host name �b BIT table �O�_���w�q.
*&D&  9.�����Ƥ��t:�� function kind �M�� function �ð��椧.
*&D& 10.�����B�z. ( �����~����椧):
*&D&
*/

main(int iArgc,char *pcArgv[])
{
  int i;
  int iRc;
  char caTmpBuf[6];
  char caHostName[20];	/* keep tty name */
  long lCurTime,lTLoc1,lTLoc2;	/* keep start & end time */
  int iRcvLen;	/* data len of Rcv form client */
  int iMaxFunArray;
  int iCwaKey;
  char caLogName[256];
  char cResident = 'y';


/* Add Ann 84/2/16 change standard I/O to pipe */
  {
     int pipe[2];
     char str[20];

     pipe[0] = atoi(pcArgv[4]);
     pipe[1] = atoi(pcArgv[5]);
     close(0);
     dup(pipe[0]);
     close(1);
     dup(pipe[1]);
     close(pipe[0]);
     close(pipe[1]);
     sprintf(str,"income pipe %d output pipe %d ",pipe[0],pipe[1]);
     ErrLog(10,str,RPT_TO_LOG,0,0);
  } 
/* Add Ann 84/2/16 end */

  /* get & log starting time */
  (lCurTime) = time(&lTLoc1) ;

  /* set signal handl */
  SignlHdl();

  /* Get system resource CWA shared memory */
  SetupPsuioEnv(pcArgv[1],pcArgv[2]);
  sprintf(caLogName, "%s/iii/log/psu_errlog", getenv("III_DIR") );
  ChgLog(LOG_CHG_MODE,"0");
  ChgLog(LOG_CHG_LOG,caLogName);
  sprintf(g_caMsg,"PsuioMain: Begin IiiDir=%s", pcArgv[1]);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);

while(cResident == 'y'){

  cResident = pcArgv[3][0];

  sprintf(g_caMsg,"PsUiO pid=%d enter TIME=%s",getpid(),ctime(&lCurTime));
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  /* initial DcsBuf & DcsSiof */
  memset(&g_stDcsBuf,0x00,sizeof(struct DcsBuf));
  memset(&g_stDcsSiof,0x00,sizeof(struct DcsSiof));

  /* receive data from client  */
  McRqstCode(g_stDcsBuf) = DCSREAD;
/*  MlWaiTime(g_stDcsBuf) = PTT_DCS_TIMEOUT;
*/
  MlWaiTime(g_stDcsBuf) = 1800;
  MiDataLen(g_stDcsBuf) = DCS_MAX_DATA_LEN;
  McProto(g_stDcsBuf) = SOCKET_DCS;
  MiSesIdx(g_stDcsBuf) = PASSIVE_SESSION_IDX;
  MpstDcsSiof(g_stDcsBuf) = &g_stDcsSiof;
  DcsDispatch(&g_stDcsBuf);
  if(MiReply(g_stDcsBuf) != DCS_NORMAL){
    sprintf(g_caMsg,"dcmpsuio.c:DCSREAD socket error reply=%d errno=%d",
            MiReply(g_stDcsBuf),MiErrno(g_stDcsBuf));
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    /* Stop run */
/* StopRtn(RCV_DATA_FROM_CLIENT_ERR    ); */
   SystemSignOff();
  }
  sprintf(g_caMsg,"dcmpsuio:after call DCSREAD, data dump is -->");
  ErrLog(10,g_caMsg,RPT_TO_LOG,McaData(g_stDcsBuf),MiDataLen(g_stDcsBuf));

  /* compare data comm. length and receive data length */
  memcpy(caTmpBuf,&McaDataLen(g_stDcsBuf),5);
  caTmpBuf[5]=0x00;
  iRcvLen = atoi(caTmpBuf);
  if (iRcvLen != MiDataLen(g_stDcsBuf)) {
    sprintf(g_caMsg,"PsuioMain:data len chk error ClientLen=%d,SkLen=%d",
            iRcvLen,MiDataLen(g_stDcsBuf));
    ErrLog(4000,g_caMsg,RPT_TO_LOG,0,0);
    /* Stop run */
    StopRtn(RCV_DATA_LEN_ERR            );
  }

  /* Get host name according to the peer Ip address */
/******** modified 840216 by CJS 

  iRc = GetSrcName(caHostName);

  if ( iRc != 0) {

*******/
  if (pcArgv[6][0] == 0) {
    ErrLog(4000,"PsuioMain:IP address isn't defined in /etc/hosts!",
           RPT_TO_LOG,0,0);
    /* Stop Run */
    StopRtn(iRc);
  }
  else
  {
	strcpy(caHostName,pcArgv[6]);
  }
  /* get function Kind */
  g_cKind = McKind(g_stDcsBuf);

  /* get config.dat */
  iCwaKey = GetCwaKey();
  if(iCwaKey < 0){
    ErrLog(1000,"PsuioMain:GetCwaKey fail!",RPT_TO_LOG,0,0);
    StopRtn(GET_CWA_KEY_ERR             );
  }

  /* get BIT of CWA pointer */
  iRc = AccessCwa(iCwaKey);
  if(iRc != 0){
    ErrLog(1000,"PsuioMain:AccessCwa fail!",RPT_TO_LOG,0,0);
    StopRtn(GET_CWA_SHM_ERR             );
  }

  /* Get Terminal Code Len & Branch Code Len */
  iRc=GetBrTmCodeLen(&g_iBrhCodeLen,&g_iTmCodeLen);
  if (iRc == -1) {
    sprintf(g_caMsg,"Get Br Tm Code Len falil !");
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    /* Stop Run */
    StopRtn(GET_BR_TM_CODE_LEN_ERR      );
  }
  /* Get Terminal code & Branch code by host name */
  iRc = GetBrTmCode(caHostName, g_caBrCode, g_caTmCode,g_iBrhCodeLen,
                    g_iTmCodeLen, g_caBrTxnDate);
  if (iRc == -1) {
    sprintf(g_caMsg,"HostName=%s is not registered in bit.dat",caHostName);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    /* Stop Run */
    StopRtn(GET_HOST_NAME_BY_BIT_ERR    );
  }

  /* check O.K. */
  if (iRc == 0) {
    /* search server array */
    iMaxFunArray = sizeof(sg_staDcsFun) / sizeof(struct FuncArraySt);
    for (i=0;
         (g_cKind != sg_staDcsFun[i].cKind) && (i < iMaxFunArray) ;
         i++){
      ;
    } /*end of for((g_cKind != sg_staDcsFun[i].cKind)&&(i < iMaxFunArray)) */
  
    if(i == iMaxFunArray){
      /* kind type not found */
      sprintf(g_caMsg,"PsuioMain:illegal g_cKind=%c",g_cKind);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      iRc = ILLEGAL_DATA_KIND_ERR       ;
    }else{
      /* function call */
      iRc = (*sg_staDcsFun[i].FuncPtr)(&g_stDcsBuf);
      if(iRc != 0){
        sprintf(g_caMsg,"Main:Func call fail, iRc=%d",iRc);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      } /* end of if(iRc != 0) */

    } /* end of if(i == iMaxFunArray) -- else */

  } /* end of if (iRc == 0) */

      sprintf(g_caMsg,"PsuioMain:iRc=%d",iRc);
      ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
  StopRtn(iRc);
 }/* end of while (1)*/

}  /* end of PsuioMain */



/******************************************************************
*&N& ROUTINE NAME: int TxnBridge()
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& pstDcsBuf       struct Dcsbuf *     pointer ����������Ƶ��c
*&A& 
*&R& RETURN VALUE(S):
*&R&   0 : ���`.
*&R&  -6 : Send Sif to Server error.
*&R&  -7 : Recieve Sof from Server error.
*&R&
*&D& DESCRIPTION:
*&D&  1.�q���쪺��Ƥ����o SIF.
*&D&  2.�� SIF �e�� SERVER.
*&D&  3.�� SERVER �e�Ӫ� SOF �A�e�� CLIENT.
*&D&
*/

int
TxnBridge(struct DcsBuf *pstDcsBuf)
{
  int iRc;
  char caTmpBuf[10];
 /* char *pcSif;*/
  int iSifLen;

  UCP_TRACE(P_TxnBridge);

  /*  get SIF from Received data. */
  sprintf(g_caMsg,"TxnBridge: Begin");
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);

  /*pcSif= PcaData(pstDcsBuf); */
  memcpy(caTmpBuf, PcaDataLen(pstDcsBuf), 5);
  caTmpBuf[5] = '\0';
  iSifLen = atoi(caTmpBuf) - SK_HEAD_LEN;

  sprintf(g_caMsg,"TxnBridge:Before Call SendSifToServ,SifLen=%d",iSifLen);
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);

  /* Send SIF to Input-Queue such that TPU get it. */
  iRc = SendSifToServ(PcaData(pstDcsBuf),iSifLen);
  if (iRc != 0){
    ErrLog(4000,"TxnBridge:send SIF to Server fail!",RPT_TO_LOG,0,0);
    UCP_TRACE_END(-6);
  }

  /* Transfer SOF from Server to Client. */
  iRc = TransSofToClient();
  if (iRc == -2) {
    ErrLog(4000,"TxnBridge:Rcv SOF from Server fail!",RPT_TO_LOG,0,0);
    UCP_TRACE_END(-7);
  }
/*
  UCP_TRACE_END(0);
*/
  if (iRc == -1) {        /*                     */
    UCP_TRACE_END(iRc);   /* added by YEN 950408 */
  }                       /*                     */
  else {                  /*                     */
    UCP_TRACE_END(0);     /*                     */
  }                       /*                     */

} /* end of TxnBridge */


/*******************************************************************
*&N& ROUTINE NAME: int SetupPsuioEnv()
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& pcIiiDir        char *              pointer UCP Diractory
*&A& 
*&R& RETURN VALUE(S):
*&R&   0 : ���`.
*&R&  -1 : �q config.dat �ɤ����o CWA share memory key error.
*&R&  -2 : get CWA share memory error.
*&R&
*&D& DESCRIPTION:
*&D&  1.�]�w�t���ܼ�.
*&D&  2.���o CWA share memory key.
*&D&  3.Get CWA share memory.
*&D&
*/

int
SetupPsuioEnv(char *pcIiiDir, char *pcIiiProtocol)
{
  int iRc;

  UCP_TRACE(P_SetupPsuioEnv);

  /* set env variable */
  sprintf(sg_caIiiPath,"%s%s","III_DIR=",pcIiiDir);
  sprintf(sg_caIiiProtocol,"%s%s","III_PROTOCOL=",pcIiiProtocol);
  putenv(sg_caIiiPath);
  putenv(sg_caIiiProtocol);
  sprintf(sg_caExePath,"%s/iii/bin/exe",pcIiiDir); 

#ifdef CISAM
  sprintf(sg_caCisamPath,"CISAMPATH=%s/iii/dat/CISAM/",pcIiiDir);
  putenv(sg_caCisamPath);
#endif

#ifdef UNIFY
  sprintf(sg_caUnifyPath,"DBPATH=%s/iii/dat/UNIFY",pcIiiDir);
  strcpy(sg_caDefsize,"DEFSIZE=20971520");
  putenv(sg_caUnifyPath);
  putenv(sg_caDefsize);
#endif

  umask(0000);
  chdir(sg_caExePath);
  
  UCP_TRACE_END(0);
}

/*
 *&N& ROUTINE NAME: GetCwaKey()
 *&A& ARGUMENTS:
 *&A&    �L
 *&A&
 *&R& RETURN VALUE(S):
 *&R&    0      : ����ư��榨�\
 *&R&   -1      : ����ư��楢��
 *&R&   -2      : ����ư��楢��
 *&R&
 *&D& DESCRIPTION:
 *&D&   ����ƥΥH���o�t�ΰѼ��� config.dat ���Ҵy�z���t�ΰѼƭ�,�P�ɱN�ȶǦ^
 *&D&   ���۹������ϰ��ܼ�
 *&D&               �t�ΰѼ�                �ϰ��ܼ�
 *&D&       ----------------------------------------------
 *&D&        CWA Shared Memory Key          iCwaKey
 *&D&   �U�C���Τ��@,�|�Ϧ���ư��楢��
 *&D&       1. �L�k�}�� config.dat ��
 *&D&       2. �Өt�ΰѼƤ��s�b(CWA_SHM_KEY)
 *&D&       3. config.dat �ɤ����t�ΰѼƭӼƶW�X�̤j����C
 *&d&          (�Ѧұ`�� MAX_PARA_NO ����)
 *&D&       4. �t�ΰѼƦW�٤����׶W�X�̤j����C
 *&D&          (�Ѧұ`�� MAX_PARA_NAME_LEN ����)
 *&D&
 */

int
GetCwaKey()
{
  int iRc;
  char caFileName[80];

  UCP_TRACE(P_GetCwaKey);

  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat((char *)caFileName, (char *)"/");
  strcat((char *)caFileName,  CONFIG_FILE);
  iRc = InitCnfTbl(caFileName);
  if ( iRc < 0 ){
    UCP_TRACE_END( -1 );
  }

  iRc = GetCnfValue( CWA_SHM_KEY );
  if (iRc < 0){
    UCP_TRACE_END( -2 );
  }

  UCP_TRACE_END( iRc );
}


/*
*&N& ROUTINE NAME: int GetSrcName()
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& pcHostName       char *              Client �ݪ� host name
*&A& 
*&R& RETURN VALUE(S):
*&R&   0 : ���`.
*&R&  -1 : getpeername   error.
*&R&  -2 : gethostbyaddr error.
*&R&
*&D& DESCRIPTION:
*&D&  1.getpeername()  : Ū�� Client �ݪ� IP ADDRESS. 
*&D&  3.gethostbyaddr(): �ھ� IP ADDRESS Ū�� HOST NAME.
*&D&
*/

int
GetSrcName(char *pcHostName)
{
/*
  int iInetAddr;
  struct in_addr stInAddr;
*/
  struct hostent *pstHostEnt;
  struct sockaddr_in stSkIn;	/* socket address struct */
  int iNameLen = sizeof stSkIn;
  char caPeerIpAddr[80];	/* Peer ip addres */
  int iRc;

  UCP_TRACE(P_GetSrcName);

  sprintf(g_caMsg,"GetSrcName: Begin");
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);

  /* get the peer Ip addres from socket address */
  iRc = getpeername(0,(struct socksddr *)&stSkIn,&iNameLen);
  if (iRc < 0){
    sprintf(g_caMsg,"GetSrcName:call getpeername error,errno=%d",errno);
    ErrLog(4000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(GET_PEEE_NAME_ERR           );
  }
  strcpy(caPeerIpAddr,inet_ntoa(stSkIn.sin_addr));
/*
  iInetAddr = inet_addr(caPeerIpAddr);
  memcpy((struct in_addr *)&stInAddr,&stSkIn.sin_addr,sizeof(stInAddr));
*/
  pstHostEnt=gethostbyaddr(&stSkIn.sin_addr,sizeof(stSkIn.sin_addr),AF_INET);
  if (pstHostEnt == 0){
    sprintf(g_caMsg,"GetSrcName:unknown addr=%s,errno=%d",caPeerIpAddr,errno);
    ErrLog(4000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(GET_HOST_BY_ADDR_ERR        );
  } /* end of if (pstHostEnt == 0) */
  else{
    strcpy(pcHostName,(char *)pstHostEnt->h_name);
  } /* end of if (pstHostEnt == 0) -- else */

  sprintf(g_caMsg,"GetSrcName:End IP addrress=%s,host name=%s",
          caPeerIpAddr,pcHostName);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  UCP_TRACE_END(0);
}  /* end of GetSrcName */


/*
*&N& ROUTINE NAME:int SendSofToClient()
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A&  iDataLen        int                 Sof ������
*&A&  pcDataBuf       char *              pointer SOF
*&A&  cOutKind        char                output data kind
*&A&  cMoreByte       char                more data flag
*&A&  cStatus         char                status of executing function
*&A& 
*&R& RETURN VALUE(S):
*&R&   0 : ���`.
*&R&  -1 : call DcsDispatch error.
*&R&
*&D& DESCRIPTION:
*&D&  1. set sof head data.
*&D&  2. set sof data & output kind & status & morebyte.
*&D&  3. call DcsDispatch.
*&D&
*/

int
SendSofToClient(iDataLen, pcDataBuf, cOutKind, cMoreByte, pcStatus)
int iDataLen;
char *pcDataBuf;
char cOutKind;
char cMoreByte;
char *pcStatus;
{
  int iRc;
  int iSndLen;
  char caTmpBuf[10];

  UCP_TRACE(P_SendSofToClient);

  MpstDcsSiof(g_stDcsBuf) = &g_stDcsSiof;

  /* mark 
  if (swa->offline_status & ON_LINE_MODE){
    McaData(g_stDcsBuf)[2] = '1';
  }
  else{
    McaData(g_stDcsBuf)[2] = '0';
  }
  */

  McaData(g_stDcsBuf)[2] = '0';

  /* set sof head data & error code & status & more byte & output kind */
  /*McKind(g_stDcsBuf) = '9';  /* kind of error message */
  memcpy(McaData(g_stDcsBuf)+SOF_BR_CODE_OFFSET,g_caBrCode,g_iBrhCodeLen);
  memcpy(McaData(g_stDcsBuf)+SOF_TM_CODE_OFFSET,g_caTmCode,g_iTmCodeLen );
  memcpy(McaData(g_stDcsBuf)+SOF_CTL_CODE_OFFSET, pcStatus,SOF_CTL_CODE_LEN);
  memcpy(McaData(g_stDcsBuf)+SOF_HEAD_LEN_PLUS_2,pcDataBuf,iDataLen);
  McaData(g_stDcsBuf)[SOF_DATA_LEN_OFFSET]  =(iDataLen)/256;
  McaData(g_stDcsBuf)[SOF_DATA_LEN_OFFSET+1]=(iDataLen)%256;
  iSndLen = SOF_HEAD_LEN_PLUS_2 + iDataLen + SK_HEAD_LEN;
  sprintf(caTmpBuf,"%.5d",iSndLen);
  memcpy(McaDataLen(g_stDcsBuf),caTmpBuf,5);
  McKind(g_stDcsBuf) = cOutKind;
  McMoreByte(g_stDcsBuf) = cMoreByte;

  /* send data to socket and disconnect */
/*
  if(cMoreByte == '0'){
    McRqstCode(g_stDcsBuf) = DCSWRDISCONECT;
  }
  else {
    McRqstCode(g_stDcsBuf) = DCSWRITE;
  }
*/
  McRqstCode(g_stDcsBuf) = DCSWRITE;
  McProto(g_stDcsBuf) = SOCKET_DCS;
  MiSesIdx(g_stDcsBuf) = PASSIVE_SESSION_IDX;
  MiDataLen(g_stDcsBuf) = iSndLen;

  /* dump for debug */
  sprintf(g_caMsg,"SendSofToClient:DCSWRDISCONECT SessIdx=%d",MiSesIdx(g_stDcsBuf));
  ErrLog(10,g_caMsg,RPT_TO_LOG,McaData(g_stDcsBuf),MiDataLen(g_stDcsBuf));

  iRc = DcsDispatch(&g_stDcsBuf);
  if(MiReply(g_stDcsBuf) != DCS_NORMAL){
    sprintf(g_caMsg,"SendSofToClient:DCSWRDISCONECT reply %d errno %d",
            MiReply(g_stDcsBuf),MiErrno(g_stDcsBuf));
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  }

  UCP_TRACE_END(0);
} /* end of SendSofToClient */

/*
*&N& ROUTINE NAME:int SendErrToClient()
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& iErrCode         int                 Error code
*&A& 
*&R& RETURN VALUE(S):
*&R&   0 : ���`.
*&R&  -1 : call DcsDispatch error.
*&R&
*&D& DESCRIPTION:
*&D&  1.conv int error code to string.
*&D&  2.set sof head data & error code & status & more byte & output kind.
*&D&  3.call DcsDispatch.
*&D&
*/

int
SendErrToClient(int iErrCode)
{
  int  r_code;
  char caErrCode[5];
  char caTmpBuf[6];

  UCP_TRACE(P_SendErrToClient);

  sprintf(g_caMsg,"SendErrToClient:Begin ErrorCode=%.3d",iErrCode);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  /* conv int error code to string */
  sprintf(caErrCode,"ZE%.2d", abs(iErrCode));

  /* set sof head data & error code & status & more byte & output kind */
  MpstDcsSiof(g_stDcsBuf) = &g_stDcsSiof;
  McMoreByte(g_stDcsBuf) = '0';
  McKind(g_stDcsBuf) = '9';  /* kind of error message */
  memcpy(McaData(g_stDcsBuf)+SOF_BR_CODE_OFFSET,g_caBrCode,g_iBrhCodeLen);
  memcpy(McaData(g_stDcsBuf)+SOF_TM_CODE_OFFSET,g_caTmCode,g_iTmCodeLen );
  memcpy(McaData(g_stDcsBuf)+SOF_OUT_DEV_OFFSET,"2",SOF_OUT_DEV_LEN);
  memcpy(McaData(g_stDcsBuf)+SOF_MSG_CODE_OFFSET,caErrCode,4);/* message code */
  memcpy(McaData(g_stDcsBuf)+SOF_CTL_CODE_OFFSET,"\x88\x00",SOF_CTL_CODE_LEN);
  memcpy(McaData(g_stDcsBuf)+SOF_DATA_LEN_OFFSET,"\0\0",SOF_DATA_LEN);

  MiDataLen(g_stDcsBuf) = SOF_HEAD_LEN_PLUS_2 + SK_HEAD_LEN;
  sprintf(caTmpBuf,"%.5d", MiDataLen(g_stDcsBuf) );
  memcpy(McaDataLen(g_stDcsBuf), caTmpBuf,5);	/* data length */

  /* send data to socket */
/*
  McRqstCode(g_stDcsBuf) = DCSWRDISCONECT;
*/
  McRqstCode(g_stDcsBuf) = DCSWRITE;
  McProto(g_stDcsBuf) = SOCKET_DCS;
  MiSesIdx(g_stDcsBuf) = PASSIVE_SESSION_IDX;
  McMoreByte(g_stDcsBuf) = '0';

  sprintf(g_caMsg,"SendErrToClient:DCSWRITE sess_idx=%d,data=",
          MiSesIdx(g_stDcsBuf));
  ErrLog(10,g_caMsg,RPT_TO_LOG,McaData(g_stDcsBuf),MiDataLen(g_stDcsBuf));

  DcsDispatch(&g_stDcsBuf);
  if(MiReply(g_stDcsBuf) != DCS_NORMAL){
     sprintf(g_caMsg,"SendErrToClient:DCSWRITE reply %d errno %d",
             MiReply(g_stDcsBuf),MiErrno(g_stDcsBuf));
     ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
  }

  UCP_TRACE_END(0);
}

/*
 *&N& ROUNTINE NAME : TransSofToClient()
 *&A& ARGUMENTS: �L
 *&A&
 *&R& RETURN VALUE(i);
 *&R&  ����ư��榨�\�Ǧ^ 0, ���ѶǦ^ -1
 *&R&
 *&D& DESCRIPTION:
 *&D&  ���� TPU ����X�����e��Ʀܺݥ�.
 *&D&  2.Ū�� TPU �Ҷǰe����X��� SOF.
 *&D&  3.��e TPU �Ҷǰe����X��� SOF �� DBP.
 *&D&  4.�P�O TPU �Ҷǰe����X��� SOF �� status �O�_���� dbp �� ack
 *&D&    �Y�O�h���� DBP �� ack, ����e�� tpu.
 *&D&    �_�h��������.
 *&D&
 */

int
TransSofToClient()
{
  int   iRc;
  int   iReadSize;
  char  cMoreData;
  int   iCtlFlowFlag; 
  char  caAckBuf[80];
  char  caSofCtlData[SOF_CTL_CODE_LEN      ];
  int   iSofCnt = 0;
  char  cFirstCtlDataFlag = '1';
  char  caFirstSofCtlData[SOF_CTL_CODE_LEN      ];

  UCP_TRACE(P_TransSofToClient);

  iCtlFlowFlag = CTL_ON; /* first SOF is control message */
  MpstDcsSiof(g_stDcsBuf) = &g_stDcsSiof;

  for (iSofCnt=0; ; iSofCnt++){
    /* receive Sof From TPU */
    McRqstCode(g_stDcsBuf) = DCSREAD;
    MlWaiTime(g_stDcsBuf) = PTT_DCS_TIMEOUT;
    MiDataLen(g_stDcsBuf) = DCS_MAX_DATA_LEN;
    McProto(g_stDcsBuf) = g_cProtoType; /* g_cProtocol get by SendSifToServ() */
    MiSesIdx(g_stDcsBuf) = g_iActSess ; /* g_iActSess get by SendSifToServ() */
    DcsDispatch(&g_stDcsBuf);
    if (MiReply(g_stDcsBuf) != DCS_NORMAL) {
      sprintf(g_caMsg,"TransSofToClient:sofCnt=%d,dcsreceive reply=%d,errno=%d",
              iSofCnt, MiReply(g_stDcsBuf),MiErrno(g_stDcsBuf));
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      /* disconnect */
      McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
      DcsDispatch(&g_stDcsBuf);
      UCP_TRACE_END(-2);
    }
    iReadSize = MiDataLen(g_stDcsBuf);

    sprintf(g_caMsg,"TransSofToClient:iSofCnt=%d,iReadSize=%d,dump data is",
            iSofCnt,iReadSize);
    ErrLog(100, g_caMsg, RPT_TO_LOG, McaData(g_stDcsBuf), iReadSize);

    /* access control byte from SOF header */
    memcpy( caSofCtlData, &McaData(g_stDcsBuf)[SOF_CTL_CODE_OFFSET], 
            SOF_CTL_CODE_SIZE );

    if ( iCtlFlowFlag == CTL_ON ) {

      if ( cFirstCtlDataFlag == '1'){
        memcpy(caFirstSofCtlData, caSofCtlData, SOF_CTL_CODE_SIZE );
        cFirstCtlDataFlag = '0';
      }
      /* send TPU Sof to DBP */
      McRqstCode(g_stDcsBuf) = DCSWRITE;
      McProto(g_stDcsBuf) = SOCKET_DCS;
      MiSesIdx(g_stDcsBuf) = PASSIVE_SESSION_IDX;
      ErrLog(100,"send TPU sof1 to DBP",RPT_TO_LOG,0,0); /*added by YEN*/
      DcsDispatch(&g_stDcsBuf);
      if(MiReply(g_stDcsBuf) != DCS_NORMAL){
        sprintf(g_caMsg,"TransSofToClient:DCSWRITE reply=%d errno=%d",
                MiReply(g_stDcsBuf),MiErrno(g_stDcsBuf));
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END(-1);
      }

      if ( caSofCtlData[0] & LAST_MSG_MASK ) {
        if ( caSofCtlData[0] & PRINT_MSG_MASK ){ /* AP call TPESDOUT API */
          cFirstCtlDataFlag = '1'; /* reset first control flag */
          continue; /* goto begin of while loop */
        }
        iCtlFlowFlag = CTL_OFF;
        if ( !(caFirstSofCtlData[0] & TPEO_MSG_MASK) ){
          break; /* exit while loop */
        }
        /* receive TPEO From DBP */
        McRqstCode(g_stDcsBuf) = DCSREAD;
/*
        MlWaiTime(g_stDcsBuf) = PTT_DCS_TIMEOUT;
*/
        MlWaiTime(g_stDcsBuf) = PSU_CLT_TM_OUT; /*replace by YEN 950408 */
        MiDataLen(g_stDcsBuf) = DCS_MAX_DATA_LEN;
        McProto(g_stDcsBuf) = SOCKET_DCS;
        MiSesIdx(g_stDcsBuf) = PASSIVE_SESSION_IDX;
        DcsDispatch(&g_stDcsBuf);
        if (MiReply(g_stDcsBuf) != DCS_NORMAL) {
          sprintf(g_caMsg,"TransSofToClient:dcsreceive DBP reply=%d,errno=%d",
                  MiReply(g_stDcsBuf),MiErrno(g_stDcsBuf));
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          UCP_TRACE_END(-1);
        }

        /* send DBP TPEO to TPU */
        McRqstCode(g_stDcsBuf) = DCSWRITE;
        McProto(g_stDcsBuf)=g_cProtoType;/*g_cProtocol get by SendSifToServ() */
        MiSesIdx(g_stDcsBuf)=g_iActSess; /* g_iActSess get by SendSifToServ() */
        DcsDispatch(&g_stDcsBuf);
        if(MiReply(g_stDcsBuf) != DCS_NORMAL){
          sprintf(g_caMsg,"TransSofToClient:DCSWRITE reply=%d errno=%d",
                  MiReply(g_stDcsBuf),MiErrno(g_stDcsBuf));
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
          DcsDispatch(&g_stDcsBuf);
          UCP_TRACE_END(-2);
        }

      }/* end of "if ( caSofCtlData & LAST_MSG_MASK ) " */

    }
    else {

      /* send TPU Sof to DBP */
      McRqstCode(g_stDcsBuf) = DCSWRITE;
      McProto(g_stDcsBuf) = SOCKET_DCS;
      MiSesIdx(g_stDcsBuf) = PASSIVE_SESSION_IDX;
      ErrLog(100,"send TPU sof2 to DBP",RPT_TO_LOG,0,0); /*added by YEN*/
      DcsDispatch(&g_stDcsBuf);
      if(MiReply(g_stDcsBuf) != DCS_NORMAL){
        sprintf(g_caMsg,"TransSofToClient:DCSWRITE reply=%d errno=%d",
                MiReply(g_stDcsBuf),MiErrno(g_stDcsBuf));
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END(-1);
      }

      if ( caSofCtlData[0] & LAST_MSG_MASK ){
        break; /* exit while loop */
      }

      /* receive ACK From DBP */
      McRqstCode(g_stDcsBuf) = DCSREAD;
/*
      MlWaiTime(g_stDcsBuf) = PTT_DCS_TIMEOUT;
*/
      MlWaiTime(g_stDcsBuf) = PSU_CLT_TM_OUT; /*replace by YEN 950408 */
      MiDataLen(g_stDcsBuf) = DCS_MAX_DATA_LEN;
      McProto(g_stDcsBuf) = SOCKET_DCS;
      MiSesIdx(g_stDcsBuf) = PASSIVE_SESSION_IDX;
      DcsDispatch(&g_stDcsBuf);
      if (MiReply(g_stDcsBuf) != DCS_NORMAL) {
        sprintf(g_caMsg,"TransSofToClient:dcsreceive reply %d errno %d",
        MiReply(g_stDcsBuf),MiErrno(g_stDcsBuf));
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        UCP_TRACE_END(-1);
      }

      /* send DBP ACK to TPU */
      McRqstCode(g_stDcsBuf) = DCSWRITE;
      McProto(g_stDcsBuf)=g_cProtoType;/*g_cProtocol get by SendSifToServ() */
      MiSesIdx(g_stDcsBuf)=g_iActSess; /* g_iActSess get by SendSifToServ() */
      DcsDispatch(&g_stDcsBuf);
      if(MiReply(g_stDcsBuf) != DCS_NORMAL){
        sprintf(g_caMsg,"TransSofToClient:DCSWRITE reply=%d errno=%d",
                MiReply(g_stDcsBuf),MiErrno(g_stDcsBuf));
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
        DcsDispatch(&g_stDcsBuf);
        UCP_TRACE_END(-2);
      }

   }

  } /* while(cLoopFlag == 'y') */

  /* disconnect TPU session */
  McProto(g_stDcsBuf)=g_cProtoType;/*g_cProtocol get by SendSifToServ() */
  MiSesIdx(g_stDcsBuf)=g_iActSess; /* g_iActSess get by SendSifToServ() */
  McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
  DcsDispatch(&g_stDcsBuf);

  UCP_TRACE_END ( 0 );

}  /* TransSofToClient() */

/*
*&N& ROUTINE NAME:int SendSifToServ()
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A&  pcSifBuf        char *              pointer SIF data buffer
*&A&  iSifLen         int                 length of SIF
*&A& 
*&R& RETURN VALUE(S):
*&R&   0 : ���`.
*&R&  -2 : Send Sif to Server error.
*&R&
*&D& DESCRIPTION:
*&D&  1. If first call this function then get protocol type.
*&D&  2. Prepare DcsBuf.
*&D&  3. Call DcsDispatch for sending SIF to server.
*&D&  4. If DcsDispatch error then disconnect to server.
*&D&        else keep active session index in global variable.
*&D&
*/

int
SendSifToServ(char *pcSifBuf,int iSifLen)
{
  static int s_iFirst = 0;
  char caProtoArray[80];
  char caTmpBuf[10];

  UCP_TRACE(P_SendSifToServ);

  sprintf(g_caMsg,"SendSifToServ:Begin,SifLen=%d,dump SIF",iSifLen);
  ErrLog(100,g_caMsg,RPT_TO_LOG, pcSifBuf, iSifLen);
  /* first call then get prototype */
  if (s_iFirst == 0){
    memset(caProtoArray,'\0',80);
    strcpy((char *)caProtoArray, (char *)getenv("III_PROTOCOL"));
    if (caProtoArray[0]!='\0') {
      g_cProtoType = caProtoArray[0];
    }
    else{
      g_cProtoType = QUEUE_DCS; /* default protocol */
    }
    s_iFirst = 1;
  }
 
  /* connect and write  */
  MpstDcsSiof(g_stDcsBuf) = &g_stDcsSiof;
  memcpy(McaDesCode(g_stDcsBuf),"0000000000",10);
  memcpy(McaServCode(g_stDcsBuf),pcSifBuf+4,4);
  McRqstCode(g_stDcsBuf) = DCSCONNECTWRITE;
  McProto(g_stDcsBuf) = g_cProtoType;
  McMoreByte(g_stDcsBuf) = '1';
  McKind(g_stDcsBuf) = g_cKind;
  McProtoType(g_stDcsBuf) = ' ';
  MiDataLen(g_stDcsBuf) = iSifLen + SK_HEAD_LEN;
  MlWaiTime(g_stDcsBuf) = PTT_DCS_TIMEOUT;   /* added by YEN 950506 */
  sprintf(caTmpBuf,"%.5d", MiDataLen(g_stDcsBuf));
  memcpy(McaDataLen(g_stDcsBuf), caTmpBuf, 5);
  memcpy(McaData(g_stDcsBuf),pcSifBuf,iSifLen);

  /* for debug dump DcsSiof */
  sprintf(g_caMsg,"SendSifToServ:dump g_stDcsSiof");
  ErrLog(100,g_caMsg,RPT_TO_LOG,&g_stDcsSiof,MiDataLen(g_stDcsBuf));

  DcsDispatch(&g_stDcsBuf);
  if(MiReply(g_stDcsBuf) != DCS_NORMAL){
    sprintf(g_caMsg,"SendSifToServ:DcsDispatch(DCSCONNECTWRITE) reply=%d,errno=%d",
            MiReply(g_stDcsBuf),MiErrno(g_stDcsBuf));
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    /* disconnect */
    McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
    McProto(g_stDcsBuf) = g_cProtoType;
    MiSesIdx(g_stDcsBuf) = g_iActSess;
    DcsDispatch(&g_stDcsBuf);
    UCP_TRACE_END(-2);
  }

  /* keep Active Session Index */
  g_iActSess = MiSesIdx(g_stDcsBuf);
  ErrLog(10,"SendSifToServ: End.",RPT_TO_LOG,0,0);
  
  UCP_TRACE_END(0);
}


/*
*&N& ROUTINE NAME: void StopRtn()
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A&  iRtnVal         int                 return value
*&A& 
*&R& RETURN VALUE(S):
*&R&   0 : ���`.
*&R&  -1 : �Ѽƿ��~,�Υ\��N�����~.
*&R&
*&D& DESCRIPTION:
*&D&  1. if 'return value' < 0 then Send error to client.
*&D&  2. else if 'return value' > 1 then Disconnect to client.
*&D&  3. record end time.
*&D&  4. detach CWA share memory.
*&D&
*/

void
StopRtn(int iRtnVal)
{
  int iRc;
  char *pcDummy;
  struct CwaCtl stCwaCtl;
  long lCurTime,lTLoc1,lTLoc2;	/* keep start & end time */

  if (iRtnVal < 0) {  /* not normal */
    SendErrToClient(iRtnVal);/* write control SOF to client */
  } /* end of if (iRc != 0) */
  else {
/*
    if(iRtnVal > 1) {
      McRqstCode(g_stDcsBuf) = DCSDISCONNECT;
      McProto(g_stDcsBuf) = SOCKET_DCS;
      MiSesIdx(g_stDcsBuf) = PASSIVE_SESSION_IDX;
      DcsDispatch(&g_stDcsBuf);
    }
*/
  }

  (lCurTime) = time(&lTLoc2);
/*
  sprintf(g_caMsg,"PsUiO pid=%d leave TIME=%s DIFFTIME=%3.0f",
          getpid(),ctime(&lCurTime),difftime(lTLoc2,lTLoc1));
  ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
*/

  /* Detach Cwa */
  stCwaCtl.cFunCode = CWA_DETACH;
  iRc = CwaCtlFac(&stCwaCtl,pcDummy);
  if(iRc != CWA_NORMAL){
    ErrLog(1000,"Detach Cwa fail",RPT_TO_LOG,0,0);
  }
  if (iRtnVal < 0) {  /* not normal */
    exit(iRtnVal);
  } /* end of if (iRc != 0) */
}

int SystemSignOn()
{
 int  iRc;
 struct  tel_st stTelData;

 UCP_TRACE(P_SystemSignOn);

 iRc=GetSystemStatus(stTelData.caTxnDate);/*in imscward.c*/
 if (iRc < 0)
 {
   sprintf(g_caMsg,"SystemSignOn:getSystemStatus fail !");
   ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
   UCP_TRACE_END(GET_SYSTEM_STATUS_ERR);
 }
 else
 {
   if (iRc == 0){
     stTelData.cTxnMode = ONLINE_MODE;
   }
   else{
     stTelData.cTxnMode = BATCH_MODE;
   }
 }
 memcpy(stTelData.caBrCode,g_caBrCode,g_iBrhCodeLen);
 memcpy(stTelData.caTmCode,g_caTmCode,g_iTmCodeLen );
 SendSofToClient(sizeof(stTelData), &stTelData, '0', '0', "\0\0");

 UCP_TRACE_END(0);
}

/******************************************************************
*&N& ROUTINE NAME: int GetTxnDate()
*&A& ARGUMENTS:
*&A&   NAME            TYPE                 DESCRIPTION
*&A& --------------- ----------------    -------------------------
*&A& pstDcsBuf       struct Dcsbuf *     pointer ����������Ƶ��c
*&A& 
*&R& RETURN VALUE(S):
*&R&   0 : ���`.
*&R&  -6 : Send Sif to Server error.
*&R&  -7 : Recieve Sof from Server error.
*&R&
*&D& DESCRIPTION:
*&D&  1.�q���쪺��Ƥ����o SIF.
*&D&  2.�� SIF �e�� SERVER.
*&D&  3.�� SERVER �e�Ӫ� SOF �A�e�� CLIENT.
*&D&
*/
#include "asscal.h"

struct SifHeader {
  char caTxnCode[4];
  char caTextId[6];
  char caBrhId[10];
  char caTermId[4];
  char caTellerId[4];
  char caFiller[20];
  char cLineno;
  char caStatus[2];
};

struct SofHeader {
  char caFmh[3];
  char caBrhId[10];
  char caTermId[4];
  char cOutDev;
  char caFormId[7];
  char caStatus[2];
  char caLength[2];
};

#define NSOF_HEAD_LEN  29
int
GetTxnDate(struct DcsBuf *pstDcsBuf)
{
  int iRc;
  char caTmpBuf[10];
  char caUsrBuf[256];   /* reservered for the future use */
  int  iUsrCnt;         /* reservered for the future use */
  char caSof[4000];
  char caCurBrhid[10];
 /* char *pcSif;*/
  int iSifLen;
  int iOffset;
  int iDataLen;
  struct SifHeader  stSifh;
  struct SofHeader  stSofh;
  struct DcsBuf     stDcsBuf;
  struct DcsSiof    stDcsSiof;
  struct parASDAYIN1 stPara;
  char   cRc;
  struct CwaCtl stCwaCtl;
  struct BrhArea *pstBrh;

  UCP_TRACE(P_GetTxnDate);

  memset(&stDcsBuf,0,sizeof(struct DcsBuf));
  memset(&stDcsSiof,0,sizeof(struct DcsSiof));
  memset(caSof,'\0',4000);

  /*  get SIF from Received data. */
  sprintf(g_caMsg,"GetTxnDate: Begin");
  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);

  /*pcSif= PcaData(pstDcsBuf); */
  memcpy(caTmpBuf, PcaDataLen(pstDcsBuf), 5);
  caTmpBuf[5] = '\0';
  iSifLen = atoi(caTmpBuf) - SK_HEAD_LEN;
  memcpy(&stSifh,PcaData(pstDcsBuf),iSifLen);

  sprintf(g_caMsg,"GetTxnDate:Before Get Brhid ,SifLen=%d",iSifLen);
  ErrLog(10,g_caMsg,RPT_TO_LOG,&stSifh,iSifLen);

  /* ------- modified by chi-fu-song,1995/01/05 --using BRH to get date ---*/
  stCwaCtl.cFunCode = CWA_GET_BRH_PTR;
  memcpy(stCwaCtl.caBrhId, stSifh.caBrhId , 10);
  iRc = CwaLowCtlFac(&stCwaCtl, &pstBrh);
  if ( iRc < 0 ) {
    /* the branch has not been registered in BIT */
    sprintf( g_caMsg, "GetTxnDate: Branch not registered in BIT" );
    ErrLog(1000, g_caMsg, RPT_TO_LOG, 0, 0);
    UCP_TRACE_END( -1 );
  }
  iOffset = NSOF_HEAD_LEN;
  memcpy(&caSof[iOffset],pstBrh->caTxnDate,8);
  iOffset += 8;
  memcpy(&caSof[iOffset],pstBrh->caNxtTxnDate,8);
  iOffset += 8;
  memcpy(&caSof[iOffset],pstBrh->caNNxtTxnDate,8);
  cRc = '0';
  /* ------- modified by chi-fu-song,1995/01/05 --using BRH to get date ---*/

  /* Get Brh Txndate from the Calendar API */
/*
  memcpy(stPara.caBrCode,stSifh.caBrhId,10);
  memcpy(stPara.caStartDate,stSifh.caFiller,8);
*/

  /* call the interface to get the content of the calendar file */
/*
  ErrLog(10,"before ASDAYIN",RPT_TO_LOG,0,0);
  ASDAYIN1(&stPara);  
  ErrLog(10,"after ASDAYIN",RPT_TO_LOG,0,0);
  cRc = stPara.cReturn;
  switch (cRc) {
    case '0': 
    case '7': 
      iOffset = NSOF_HEAD_LEN;
      memcpy(&caSof[iOffset],stPara.caStartDate,8);
      iOffset += 8;
      memcpy(&caSof[iOffset],stPara.caNextDate,8);
      iOffset += 8;
      memcpy(&caSof[iOffset],stPara.caNNextDate,8);
      break;
    default:
      break;
  }
*/

#ifdef DESKEY
/* -------------- Cut this segment when other use site ------------------*/
  /* call the interface to get the DESKEY */
  iUsrCnt = 0;
  ErrLog(10,"befoer getDesKey",RPT_TO_LOG,0,0);
  iRc = GetDesKey(stSifh.caBrhId,caUsrBuf);
  ErrLog(10,"after getDesKey",RPT_TO_LOG,0,0);
  switch (iRc) {
    case 0: 
      iOffset += 8;
      iUsrCnt += 8;
      memcpy(&caSof[iOffset],caUsrBuf,8);
      iOffset += 8;
      iUsrCnt += 8;
      memcpy(&caSof[iOffset],&caUsrBuf[8],8);
      iOffset += 8;
      iUsrCnt += 8;
      memcpy(&caSof[iOffset],&caUsrBuf[16],8);
      break;
    default:
      break;
  }
/* -------------- Cut this segment when other use site ------------------*/
#endif


  /* send TxnDate to EMS */
  MpstDcsSiof(stDcsBuf) = &stDcsSiof;
  McRqstCode(stDcsBuf) = DCSWRDISCONECT;
  McMoreByte(stDcsBuf) = '0';
  McProto(stDcsBuf) = SOCKET_DCS;
  MiSesIdx(stDcsBuf) = PASSIVE_SESSION_IDX;

  stSofh.caStatus[0] = cRc; 
  stSofh.caStatus[1] = (char) iRc; 
  stSofh.caLength[0] = 0x0;
  stSofh.caLength[1] = 24 + iUsrCnt;
  memcpy(caSof,&stSofh,NSOF_HEAD_LEN);
   
  iDataLen = NSOF_HEAD_LEN + 256 * stSofh.caLength[0] + stSofh.caLength[1];
  sprintf(McaDataLen(stDcsBuf),"%.4d",iDataLen + 8);
  memcpy(McaData(stDcsBuf), caSof, iDataLen);
  ErrLog(400,"SdSifRvSof() McaDataLen:",RPT_TO_LOG,McaDataLen(stDcsBuf),5);
  MlWaiTime(stDcsBuf) = 10;
  MiDataLen(stDcsBuf) = iDataLen + 8;

  DcsDispatch(&stDcsBuf);
  if(MiReply(stDcsBuf) != DCS_NORMAL){
    sprintf(g_caMsg,"TransSofToClient:DCSWRITE reply=%d errno=%d",
            MiReply(stDcsBuf),MiErrno(stDcsBuf));
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    McRqstCode(stDcsBuf) = DCSDISCONNECT;
    DcsDispatch(&stDcsBuf);
    UCP_TRACE_END(-1);
  }

  UCP_TRACE_END(0);

} /* end of GetTxnDate */

int SystemSignOff()
{
  exit(0);
}

