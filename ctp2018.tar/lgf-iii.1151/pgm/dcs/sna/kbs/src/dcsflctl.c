#include <fcntl.h>
#include <errno.h>
#include <sys/ipc.h>
#include <sys/signal.h>
#include "errlog.h"
#include "msgqop.h"
#include "dcs.h"

#define  P_DcsUcpu     68001
#define  P_DcsUcps     68002
/* ----- add by chi-fusong ----for Time out Adjustment -----begin ------ */
#define  P_RcvFromQueue 68003
extern int g_iTmin;
extern int g_iToffset;
#define RCV_SOF_FRM_SERV_ERROR -5
/* ----- add by chi-fusong ----for Time out Adjustment -----end   ------ */
#ifdef  OMIT
#define  CONTROL_BYTE 25
#define  FORM_ID 9
#define  OUT_DEVICE    17
#define  STATUS_BYTE  25
#endif
#define  CONTROL_BYTE 13
#define  FORM_ID 9
#define  OUT_DEVICE    8
#define  STATUS_BYTE  14

#define  LAST_MSG_MASK  0x80
#define  UCPS_MSG_MASK  0x02

#ifdef OMIT
  #define  WRQUETYPE      2 
  #define  RDQUETYPE      3 
#endif

#define  ALIMENT      8
#define  DCSCMDOK     '0'
#define  TMS_AP_ABEND  '5'
#define  TPE_BR_ID         10
#define  TPE_TERM_ID       20

struct HostSof {
  int  iLen;
  unsigned char ucaData[ MAX_SOFLEN ];
  };
static struct HostSof  staHostSof[ MAX_SOF ];

struct HostEj {
  int  iLen;
  unsigned char ucaData[ MAX_SOFLEN ];
  };
static struct HostEj staHostEj[ MAX_SOF ];

struct Siof {
  char cDcsCmd;
  int  iSiofLen;
  unsigned char ucaSiofData[ MAX_SOFLEN ];
  };


static unsigned char g_ucaUcpu[] = { 0xE4 , 0xC3, 0xD7, 0xE4 };/*"UCPU" ebcdic*/
static unsigned char g_ucaUcps[] = { 0xE4 , 0xC3, 0xD7, 0xE2 };/*"UCPS" ebcdic*/
static unsigned char g_ucaOK[]   = { 0xD6 , 0xD2 };            /*"OK"   ebcdic*/

static unsigned char g_ucaTpei[] = { 0xE3 , 0xD7, 0xC5, 0xC9 };/*"TPEI" ebcdic*/
static unsigned char g_ucaTpeo[] = { 0xE3 , 0xD7, 0xC5, 0xD6 };/*"TPEO" ebcdic*/
static unsigned char g_uca00[]   = { 0x00 };            /*0x00   ebcdic*/


static struct DcsSiof gs_stDcsSiof;
static struct DcsBuf  gs_stDcsBuf;

static int gs_iFirst=1;       /* first flage 0=no 1=yes          */
extern int gs_iQueKey;
static int gs_iQuId;
static long gs_iWrQueType;
static long gs_iRdQueType;
static char gs_caTermId[TPE_TERM_LEN + 1];
static char gs_caBrId[TPE_BR_LEN + 1];
static char gs_caQueType[20];
static int gs_iSofDx=0;
static int gs_iEjDx=0;

int
DcsUcpu(unsigned char *pucaHostSif, int  iHostSifLen, char *pcRmtApFlg,
        unsigned char *pucaTmpSif)
{
  int  iSofCnt=0;
  int  iRc,i;
  int iAbend=0;
  int iSiofLen = MAX_LEN;
  long lQuType;
  char cFirstCtlDataFlag='1';
  char cFirstSofCtlData;
  struct MsgBuf stMsgp;
  struct Siof stSiof;
  unsigned char caTmp[600];
  unsigned char ucaServName[4];
  unsigned char caTmpFile[20]; 

  UCP_TRACE( P_DcsUcpu );
  ErrLog(100,"dcsflctl.c:DcsUcpu().0,Begin",RPT_TO_LOG,pucaHostSif,iHostSifLen);

  if(gs_iFirst){
    iRc = DcsGetKey();
    if(iRc != DCS_NORMAL){
      ErrLog(1000,"Get Que Key error",RPT_TO_LOG,0,0);
    }
    gs_iFirst = 0;
  }


  for( i=0;i< MAX_SOF;i++)
  {
    staHostSof[ i ].iLen = 0;
    memset(staHostSof[ i ].ucaData,0x00,MAX_SOFLEN);
  }

  iRc = MsqGet(&gs_iQuId,gs_iQueKey);
  if(iRc != MSGQ_NORMAL){
    ErrLog(4000,"MsqGet:read q id get fail",RPT_TO_LOG,0,0);
    UCP_TRACE_END(DCS_E_NETWORKTBL);
  } 


#ifdef  OMIT
  memcpy(gs_caQueType,&pucaTmpSif[TPE_BR_ID+3],TPE_BR_LEN);
#endif
  memcpy(gs_caQueType,&pucaTmpSif[TPE_BR_ID],3);

/*
  sprintf(g_caMsg,"dcsflctl.c:gs_caQueType=%10s",&pucaTmpSif[TPE_BR_ID]);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
*/
   
  memcpy(&gs_caQueType[3],&pucaTmpSif[TPE_TERM_ID],2);
  memset(&gs_caQueType[3+2],0x00,1);
  gs_iWrQueType = atol(gs_caQueType);
  gs_iRdQueType = gs_iWrQueType + 1000*10000;

  MsqInit(gs_iQuId, gs_iRdQueType); /* clear the incoming msg first, by YEN */

  GetServName(ucaServName);

  stSiof.cDcsCmd=DCSCONNECTWRITE;
  stSiof.iSiofLen=iHostSifLen;

  memset(stSiof.ucaSiofData,0x00,iHostSifLen); 
  memcpy(stSiof.ucaSiofData,pucaHostSif,iHostSifLen); 
  memcpy(stSiof.ucaSiofData, ucaServName, sizeof( g_ucaUcpu ) );
  strcpy(caTmpFile,"sdc");

  iSiofLen = iHostSifLen + ALIMENT;

  stMsgp.lType=gs_iWrQueType;
  memcpy(stMsgp.caText,&stSiof,iSiofLen); 

  ErrLog(100,"dcsflctl.c:DcsUcpu().MsqWrite(DCSCONNECTWRITE).0",RPT_TO_LOG,0,0);
  iRc = MsqWrite(gs_iQuId,iSiofLen,&stMsgp,IPC_NOWAIT,caTmpFile);

  if( iRc  != MSGQ_NORMAL ) {
    UCP_TRACE_END( MSGQ_ERROR );
  } 

  lQuType = gs_iRdQueType;
  memset(&stMsgp,0x00,sizeof(struct MsgBuf) );

  iSiofLen = MAX_LEN;
  iRc = RcvFromQueue(gs_iQuId,lQuType,&iSiofLen,&stMsgp,g_iTmin+g_iToffset);
  memcpy(&stSiof,stMsgp.caText,iSiofLen); 

  if( (iRc  != MSGQ_NORMAL) || (stSiof.cDcsCmd != DCSCMDOK) ) {
    sprintf(g_caMsg,"dcsflctl.c:Rcv DcsUcpu() fail iRc=%d Cmd=%c",iRc,
            stSiof.cDcsCmd);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    MsqInit(gs_iQuId, gs_iWrQueType);  /* remove the message sent to the */
                                       /* dcxdaemon before by YEN 950505 */
    UCP_TRACE_END( RCV_SOF_FRM_SERV_ERROR );
  }

  while(1)
  {
    stSiof.cDcsCmd=DCSREAD;
    stSiof.iSiofLen= ALIMENT;
    memcpy(stSiof.ucaSiofData, 0x00, sizeof( stSiof.ucaSiofData ) );

    iSiofLen =  ALIMENT;

    stMsgp.lType=gs_iWrQueType;
    memcpy(stMsgp.caText,&stSiof,iSiofLen); 

/*
    sprintf(g_caMsg,"dcsflctl.c:DcsUcpu.MsqWrite().0,gs_iWrQueType=[%d]",gs_iWrQueType);
    ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
*/
    iRc = MsqWrite(gs_iQuId,iSiofLen,&stMsgp,IPC_NOWAIT,caTmpFile);
    sprintf(g_caMsg,"dcsflctl.c:DcsUcpu().MsqWrite(DCSREAD).1,iRc=[%d]",iRc);
    ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

    if( iRc  != MSGQ_NORMAL )
    UCP_TRACE_END( MSGQ_ERROR );

    lQuType = gs_iRdQueType;

    iSiofLen = MAX_LEN;
    iRc = RcvFromQueue(gs_iQuId,lQuType,&iSiofLen,&stMsgp,g_iTmin+g_iToffset);
    sprintf(g_caMsg,"dcsflctl.c:DcsUcpu().RcvFromQueue(DCSREAD).1,iRc=[%d]",iRc);
    ErrLog(100,g_caMsg,RPT_TO_LOG,&stSiof,iSiofLen);

    memcpy(&stSiof,stMsgp.caText,iSiofLen); 

    if( (iRc  != MSGQ_NORMAL) || (stSiof.cDcsCmd != DCSCMDOK) ) {
      sprintf(g_caMsg,"Send UCPU ERROR iRc=[%d] DCS-RC=[%c]",iRc,
              stSiof.cDcsCmd);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,&stSiof,iSiofLen);
      UCP_TRACE_END( RCV_SOF_FRM_SERV_ERROR );
    }

    if( iSiofLen >= 14   &&  iRc  == MSGQ_NORMAL )
    {
      staHostSof[ iSofCnt ].iLen  =  iSiofLen-ALIMENT;
      memcpy(staHostSof[iSofCnt].ucaData, stSiof.ucaSiofData, iSiofLen-ALIMENT);
      iSofCnt++; 

      if( stSiof.ucaSiofData[CONTROL_BYTE] == 0x82 )
      {
        iRc  =  DcsUcps(iSofCnt,pucaHostSif,iHostSifLen);
        if ( iRc < 0 ) {
          UCP_TRACE_END( RCV_SOF_FRM_SERV_ERROR );
        }
        else {
          UCP_TRACE_END( 0 );
        }
      }

      if( stSiof.ucaSiofData[CONTROL_BYTE] == 0x80 ||
          stSiof.ucaSiofData[CONTROL_BYTE] == 0x88 )
      {
        *pcRmtApFlg='1'; /* set txn error added by YEN 950329 */
        UCP_TRACE_END( DCS_NORMAL );
      }
/*
***
*/

    } 
    else
      break;
  }/*endof while() */
/*
  stSiof.cDcsCmd=DCSDISCONNECT;
  stMsgp.lType=gs_iWrQueType;
  iRc = MsqWrite(gs_iQuId,iSiofLen,&stMsgp,IPC_NOWAIT,caTmpFile);
  if( iRc  != MSGQ_NORMAL )
    UCP_TRACE_END( MSGQ_ERROR );
  lQuType = gs_iRdQueType;
  memset(&stMsgp,0x00,sizeof(struct MsgBuf) );
  iSiofLen = MAX_LEN;
  iRc = RcvFromQueue(gs_iQuId,lQuType,&iSiofLen,&stMsgp,0);

  stSiof.cDcsCmd=DCSTERMINATE;
  stMsgp.lType=gs_iWrQueType;
  iRc = MsqWrite(gs_iQuId,iSiofLen,&stMsgp,IPC_NOWAIT,caTmpFile);
  if( iRc  != MSGQ_NORMAL )
    UCP_TRACE_END( MSGQ_ERROR );
  lQuType = gs_iRdQueType;
  memset(&stMsgp,0x00,sizeof(struct MsgBuf) );
  iSiofLen = MAX_LEN;
  iRc = RcvFromQueue(gs_iQuId,lQuType,&iSiofLen,&stMsgp,0);
*/
  ErrLog(100,"dcsflctl.c:DcsUcpu().end",RPT_TO_LOG,0,0);
  UCP_TRACE_END( RCV_SOF_FRM_SERV_ERROR );
}



DcsUcps(int iDx,unsigned char *pucaSif,int iSifLen)
{
  int    iRc,iTmpDx,iEjDx=0;
  int iSiofLen;
  long lQuType;
  struct MsgBuf stMsgp;
  struct Siof stSiof;
  unsigned char caTmp[600];
  unsigned char caTmpFile[20]; 

  UCP_TRACE( P_DcsUcps );
  stSiof.cDcsCmd=DCSCONNECTWRITE;

  stSiof.iSiofLen=sizeof(g_ucaUcps);

  memset(stSiof.ucaSiofData,0x00,iSifLen); 
  memcpy(stSiof.ucaSiofData,pucaSif,iSifLen); 
  memcpy(stSiof.ucaSiofData, g_ucaUcps, sizeof( g_ucaUcps ) );

  strcpy(caTmpFile,"sdc");
  iSiofLen = sizeof(g_ucaUcps)+ ALIMENT;
/*
  iSiofLen = iSifLen + ALIMENT;
*/

  stMsgp.lType=gs_iWrQueType;
  memcpy(stMsgp.caText,&stSiof,iSiofLen); 

  ErrLog(100,"UCPS WRITE MSQ DATA",RPT_TO_LOG,stMsgp.caText,iSiofLen);

  iRc = MsqWrite(gs_iQuId,iSiofLen,&stMsgp,IPC_NOWAIT,caTmpFile);

  if( iRc  != MSGQ_NORMAL )
    UCP_TRACE_END( MSGQ_ERROR );

  lQuType = gs_iRdQueType;

  iSiofLen = MAX_LEN;
  iRc = RcvFromQueue(gs_iQuId,lQuType,&iSiofLen,&stMsgp,g_iTmin+g_iToffset);

  memcpy(&stSiof,stMsgp.caText,iSiofLen); 
/*
  ErrLog(100,"UCPS READ MSQ DATA",RPT_TO_LOG,&stSiof,iSiofLen);
*/
  if( (iRc  != MSGQ_NORMAL) || (stSiof.cDcsCmd != DCSCMDOK) )
    UCP_TRACE_END( MSGQ_ERROR );

  do
  {

    stSiof.cDcsCmd=DCSREAD;
    stSiof.iSiofLen=sizeof(g_ucaUcps);
    memcpy(stSiof.ucaSiofData, 0x00, sizeof( g_ucaUcps ) );
    iSiofLen = sizeof(g_ucaUcps)+ ALIMENT;

    stMsgp.lType=gs_iWrQueType;
    memcpy(stMsgp.caText,&stSiof,iSiofLen); 
/*
 ErrLog(100,"UCPS do while WRITE MSQ DATA",RPT_TO_LOG,stMsgp.caText,iSiofLen);
*/
    iRc = MsqWrite(gs_iQuId,iSiofLen,&stMsgp,IPC_NOWAIT,caTmpFile);

    if( iRc  != MSGQ_NORMAL )
    UCP_TRACE_END( MSGQ_ERROR );

    lQuType = gs_iRdQueType;

      iSiofLen = MAX_LEN;
    iRc = RcvFromQueue(gs_iQuId,lQuType,&iSiofLen,&stMsgp,g_iTmin+g_iToffset);

    memcpy(&stSiof,stMsgp.caText,iSiofLen); 
/*
    ErrLog(100,"UCPS do while READ MSQ DATA",RPT_TO_LOG,&stSiof,iSiofLen);
*/
    if( (iRc  != MSGQ_NORMAL) || (stSiof.cDcsCmd != DCSCMDOK) )
      {
         ErrLog(1000,"UCPS do while error",RPT_TO_LOG,0,0);
         UCP_TRACE_END( MSGQ_ERROR );
      }

    if( iSiofLen >= ALIMENT  &&  iRc  == MSGQ_NORMAL )
    {

      if( (unsigned char) stSiof.ucaSiofData[OUT_DEVICE]
           == (unsigned char) 0xf1 )  /* EJ */
      {

        staHostEj[ iEjDx ].iLen  =  iSiofLen-ALIMENT;
        memcpy( staHostEj[iEjDx].ucaData, stSiof.ucaSiofData, 
                iSiofLen-ALIMENT);
        iEjDx = iEjDx + 1 ;
/*    marked by YEN 0322
        staHostSof[ iDx ].iLen  =  iSiofLen-ALIMENT ;
        memcpy( staHostSof[iDx].ucaData, stSiof.ucaSiofData, 
                iSiofLen-ALIMENT);
        iTmpDx = iDx;
        iDx++;
*/
      }
      else
      {
        staHostSof[ iDx ].iLen  =  iSiofLen-ALIMENT ;
        memcpy( staHostSof[iDx].ucaData, stSiof.ucaSiofData, 
                iSiofLen-ALIMENT);
        iTmpDx = iDx;
        iDx++;
      } 

      if( (unsigned char) stSiof.ucaSiofData[CONTROL_BYTE]
           == (unsigned char)0x88 )
       {
          memcpy( staHostSof[iTmpDx].ucaData, "\x40\x40\xf1" ,3);
          ErrLog(100,"Rcv Host Sof ctl byte 88 ",RPT_TO_LOG,0,0);
          break;
       }

      if( (unsigned char) stSiof.ucaSiofData[CONTROL_BYTE]
           != (unsigned char)0x80 )
      {
          stSiof.cDcsCmd=DCSWRITE;
          stSiof.iSiofLen=sizeof(g_ucaOK);
          memcpy(stSiof.ucaSiofData, g_ucaOK, sizeof( g_ucaOK ) );

          iSiofLen = sizeof(g_ucaOK)+ ALIMENT;

          stMsgp.lType=gs_iWrQueType;
          memcpy(stMsgp.caText,&stSiof,iSiofLen); 

       ErrLog(100," WRITE OK",RPT_TO_LOG,stMsgp.caText,iSiofLen);

          iRc = MsqWrite(gs_iQuId,iSiofLen,&stMsgp,IPC_NOWAIT,caTmpFile);

          if( iRc  != MSGQ_NORMAL )
            UCP_TRACE_END( MSGQ_ERROR );

          lQuType = gs_iRdQueType;

      iSiofLen = MAX_LEN;
          iRc = RcvFromQueue(gs_iQuId,lQuType,&iSiofLen,&stMsgp,g_iTmin+g_iToffset);

          memcpy(&stSiof,stMsgp.caText,iSiofLen); 
/*
        ErrLog(100,"AFTER SEND 00, READ MSQ DATA",RPT_TO_LOG,&stSiof,iSiofLen);
*/
          if( (iRc  != MSGQ_NORMAL) || (stSiof.cDcsCmd != DCSCMDOK) )
            UCP_TRACE_END( MSGQ_ERROR );

      }
      else /* cntl mesg == 80 */
      {
        if( iEjDx == 0 )
        {
          staHostEj[ iEjDx ].iLen  =  iSiofLen-ALIMENT;
          memcpy( staHostEj[iEjDx].ucaData, stSiof.ucaSiofData, 
                  iSiofLen-ALIMENT);
          iEjDx++;
        }

        break;
      }


    }

  } while( iRc  ==  DCS_NORMAL );

  UCP_TRACE_END( iRc );
}


int
GetHostSof(unsigned char *pucaSof,int *piLen)
{
/*
static int iDx=0;
*/

  if( staHostSof[ gs_iSofDx ].iLen   == 0 )
  {
    gs_iSofDx  =  0;
    *piLen  =   0;
    return( 0 );
  }
  *piLen  =   staHostSof[ gs_iSofDx ].iLen ;
  memcpy( pucaSof, staHostSof[ gs_iSofDx ].ucaData,
          staHostSof[gs_iSofDx ].iLen );
  gs_iSofDx++;
  
  return( 0 );
}


int
GetHostEj(unsigned char *pucaSof,int *piLen)
{
/*
static int iDx=0;
*/

  if( staHostEj[ gs_iEjDx ].iLen   == 0 )
  {
    gs_iEjDx  =  0;
    *piLen  =   0;
    return( 0 );
  }
  *piLen  =   staHostEj[ gs_iEjDx ].iLen ;
  memcpy( pucaSof, staHostEj[ gs_iEjDx ].ucaData, staHostEj[ gs_iEjDx ].iLen );
  gs_iEjDx++;
  
  return( 0 );
}



int
GetServName(char *pcaServName)
{
 
 memcpy(pcaServName,g_ucaUcpu,4);
   
 return(0);
}



/* ----- add by chi-fusong ----for Time out Adjustment -----begin ------ */
extern int DcsQuNull();
int
RcvFromQueue(int iQuId,long lQuType,int *piSiofLen,struct MsgBuf *pstMsgBuf,
             int iTimeout)
{
  int iRc;

  UCP_TRACE(P_RcvFromQueue);
  signal(SIGALRM,DcsQuNull);
/*
  sprintf(g_caMsg,"RcvFromQueue: timeout=%d", iTimeout);
  ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
*/
  alarm(iTimeout);
  iRc = MsqRead(iQuId,lQuType,piSiofLen,pstMsgBuf,2);
  if((iRc != MSGQ_NORMAL) || (errno == EINTR)){
    ErrLog(1000,"RcvFromQueue:MsqRead fail",RPT_TO_LOG,0,0);
    if(errno == EINTR) UCP_TRACE_END(DCS_E_TIMEOUT);
    UCP_TRACE_END(DCS_E_NETWORK);
  }
  alarm(0) ;

  UCP_TRACE_END(MSGQ_NORMAL);
}
/* ----- add by chi-fusong ----for Time out Adjustment -----end   ------ */
