#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#include "errlog.h"
#include "dcs.h"
#include "banklib.c"
extern char gs_caTmCode[];
extern char gs_caBrCode[];
extern char gs_caPuName[];
extern char gs_caPortNo[];
extern unsigned char g_luname [9];
extern unsigned char g_mode   [9];
extern int  gs_iQuId ;
extern int  signonflag; /* 0 : no  ; 1 : yes */
extern int  g_nPrgCount;
/*
extern unsigned short g_lu0flag ;
*/
extern unsigned short g_ucaConverId ;
#define sleeptime 2
int   fd = -1 ;           /* used for network status monitor */
int DISP_FLAG = 0 ;
extern int AUTOLOGON;
void termdcs ();
void check_routine () ;
void test_routine  () ;
void aaa_test_routine  () ;

#define TIMESIGNAL

/*===========================================================================*/
static struct DcsSiof gs_stDcsSiof;
static struct DcsBuf  gs_stDcsBuf;

main(int iArgc, char **caaArgv)
{
  char  caCicsEnv[20], caSnaEnv[20];
  char  caTmpEnv[20];
  char  cCmd, caInpData[ DCS_MAX_DATA_LEN ];
  char  cRc , caOutData[ DCS_MAX_DATA_LEN ];
  int   iInpLen, iOutLen, iRc,SRC;
  FILE  *zFp, *fopen();
  char  caDcstmProf[16];
  int   i;
  char caLogName[256];
  char aaa [5];
  fd_set total_session;
  struct timeval l_time_out ;
  struct msqid_ds abc;

  l_time_out.tv_sec = 5 ;
  l_time_out.tv_usec= 0 ;

  signal ( SIGUSR1 , termdcs);
  signal ( SIGUSR2 , test_routine);
  UCP_TRACE(00000);
  sprintf(caLogName, "%s/iii/log/tms_errlog", getenv("III_DIR") );
  ChgLog(LOG_CHG_MODE,"0");
  ChgLog(LOG_CHG_LOG,caLogName);
/* modefied by CJS 1995-04-10 */
/********
#ifndef AUTOLOGON
  if( iArgc < 8 )
#else
  if (iArgc < 6)
#endif
  {
    ErrLog(1000,"dcxdaemon.x:dcxdaemon.x  XX",RPT_TO_LOG,0,0);
    exit(-1);
  }
********/
  if (iArgc < 8)
  {
    ErrLog(1000,"dcxdaemon.x:dcxdaemon.x  XX",RPT_TO_LOG,0,0);
    exit(-1);
  }
  else
  {
        AUTOLOGON = atoi(caaArgv[6]);
        if (AUTOLOGON !=1 && iArgc < 10)
        {
                ErrLog(1000,"dcxdaemon.x:dcxdaemon.x  XX",RPT_TO_LOG,0,0);
                exit(-1);
        }
  }

  MpstDcsSiof( gs_stDcsBuf )  =  &gs_stDcsSiof ;

  memset ( gs_caPuName,' ',8);
  memset ( g_luname   ,' ',8);
  memset ( g_mode     ,' ',8);
  sprintf( gs_caBrCode,"%s",caaArgv[1] );
  sprintf( gs_caTmCode,"%s",caaArgv[2] );
  memcpy ( gs_caPuName,caaArgv[3],strlen(caaArgv[3]));
  sprintf( gs_caPortNo,"%s",caaArgv[4] );
/******** mark by CJS 1995-04-10 */
  g_nPrgCount = atoi(caaArgv[7]);
if (AUTOLOGON == 0)
{
  memcpy ( g_luname , caaArgv[8] , strlen ( caaArgv[8]));
  memcpy ( g_mode   , caaArgv[9] , strlen ( caaArgv[9]));
/*
  printf ( "LUNAME [%s]\n", g_luname);
  printf ( "MODE   [%s]\n", g_mode);
*/
}
/**** end ****/

/*
  gets (aaa);
*/
  AsciiToEbcdic ( g_luname , 8);
  AsciiToEbcdic ( g_mode   , 8);
  /********** append by stanley chao ***********/
  lu0_setup () ;
  lu0_Estate();
  /***************** updated by Stanley chao ***************************/
   lu0_state ();
/*
   printf (" pid [%d] FD [%d]\n", getpid() , fd );
*/
/*
   gets (aaa);
*/
  /***************** updated by Stanley chao ***************************/
  signonflag =  atoi(caaArgv[5]) ;
  if (signonflag == 1 && AUTOLOGON == 0)
	lu0_act();
  signal (SIGALRM , check_routine);
  alarm  ((unsigned int ) 5);
  AttQue();
  while(1)
  {
    cRc = '0' ;
    ErrLog(10,"dcxdaemon.x,RdQue(),Begin",RPT_TO_LOG,0,0);
    iInpLen = sizeof( caInpData );

    msgctl ( gs_iQuId , IPC_STAT , &abc);
/*
    printf ("msg_rtime [%d]\n",abc.msg_rtime );
    printf ("msg_ctime [%d]\n",abc.msg_ctime );
    printf ("msg_stime [%d]\n",abc.msg_stime );
    printf ("msg_lspid [%d]\n",abc.msg_lspid );
    printf ("msg_lrpid [%d]\n",abc.msg_lrpid );
    printf ("GS_IQUID  [%d]\n",gs_iQuId);
*/
/*
    signal (SIGALRM , check_routine);
*/
    iRc  =  RdQue( &cCmd, caInpData, &iInpLen);
    if( iRc  != DCS_NORMAL || signonflag == 0 ) { 
/*
      printf ( " pid [%d] READ QUEUE ERROR rc (%d)\n" , getpid (),iRc);
*/
      sprintf(g_caMsg,"dcxdaemon.x,RdQue(),error,iRc=%d",iRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
/*
      break;
*/
      /************ need something *************/
/*
      AttQue ();
*/
/* updated by stanley chao   1995-03-29   */
      cRc = '1';
      iOutLen = 0 ;
      WrQue( &cRc , caOutData,  &iOutLen );
/* unmark by CJS 1995-04-10 */

      continue ;
    }
    sprintf(g_caMsg,"dcxdaemon.x,RdQue(),HexDmp,cCmd=%c",cCmd);
    ErrLog(10,g_caMsg,RPT_TO_LOG,caInpData,iInpLen);
    iRc      =  DCS_NORMAL;

    switch( cCmd )
    {
      case DCSCONNECTWRITE :
        ErrLog(10,"dcxdaemon.x,while.switch(),DCSCONNECTWRITE",RPT_TO_LOG,0,0);

        McRqstCode( gs_stDcsBuf )   =  DCSCONNECTWRITE;
        MiDataLen( gs_stDcsBuf )    =  iInpLen;
        memcpy( McaData( gs_stDcsBuf ), caInpData, iInpLen );
        iRc      =  DcsLu0( &gs_stDcsBuf );
        iOutLen  =  0;
/*
        ErrLog(10,"main,DcsLu0(DCSCONNECTWRITE)",RPT_TO_LOG,0,0);
*/
        break;

      case DCSWRITE :
        ErrLog(10,"dcxdaemon.x,while.switch(),DCSWRITE",RPT_TO_LOG,0,0);

        McRqstCode( gs_stDcsBuf )   =  DCSWRITE;
        MiDataLen( gs_stDcsBuf )    =  iInpLen;
        memcpy( McaData( gs_stDcsBuf ), caInpData, iInpLen );
        iRc      =  DcsLu0( &gs_stDcsBuf );
        iOutLen  =  0;
/*
        ErrLog(10,"main,DcsLu0(DCSWRITE)",RPT_TO_LOG,0,0);
*/
        break;

      case DCSREAD         :
        ErrLog(10,"dcxdaemon.x,while.switch(),DCSREAD",RPT_TO_LOG,0,0);
        McRqstCode( gs_stDcsBuf )   =  DCSREAD;
        MiDataLen( gs_stDcsBuf )    =  DCS_MAX_DATA_LEN ;
        iRc      =  DcsLu0( &gs_stDcsBuf );
/*
        printf("DCSREAD IRC [%d]\n",iRc);
*/
        if( iRc == DCS_NORMAL )
           iOutLen  =  MiDataLen( gs_stDcsBuf );
        else
          iOutLen  =  0;

        memcpy( caOutData , McaData( gs_stDcsBuf), MiDataLen(gs_stDcsBuf));
/*
        ErrLog(10,"main,DcsLu0(DCSREAD)",RPT_TO_LOG,McaData(gs_stDcsBuf),
               MiDataLen(gs_stDcsBuf));
*/
        break;

      case DCSDISCONNECT :
        ErrLog(10,"dcxdaemon.x,while.switch(),DCSWRITE",RPT_TO_LOG,0,0);

        McRqstCode( gs_stDcsBuf )   =  DCSDISCONNECT;
        MiDataLen( gs_stDcsBuf )    =  iInpLen;
        memcpy( McaData( gs_stDcsBuf ), caInpData, iInpLen );
        iRc      =  DcsLu0( &gs_stDcsBuf );
        iOutLen  =  0;
/*
        ErrLog(10,"main,DcsLu0(DCSDISCONNECT)",RPT_TO_LOG,0,0);
*/
        break;

      default :
        ErrLog(10,"dcxdaemon.x,while.switch(),default",RPT_TO_LOG,0,0);
        iOutLen  =  0;
        iRc      =  DCS_E_COMMAND ;
        break;
    }

    if( iRc != DCS_NORMAL )
        cRc   =  '1';
/*
    ErrLog(10,"dcxdaemon.x,WrQue(),Begin",RPT_TO_LOG,0, 0 );
*/
    WrQue( &cRc , caOutData,  &iOutLen );
/*
    ErrLog(10,"dcxdaemon.x,WrQue(),HexDmp",RPT_TO_LOG,caOutData, iOutLen );
*/
/*
    if ( iRc != DCS_NORMAL )
       {
        lu0_disconnect();
        lu0_end ();
        lu0_init();
        for (;;)
            {
             sleep ((unsigned int) sleeptime);
             if ( lu0_connect () == 0 )
                break ;

             iRc  =  RdQue( &cCmd, caInpData, &iInpLen);
             if( iRc  != DCS_NORMAL )
               {
                cRc = '1';
                iOutLen = 0 ;
                WrQue( &cRc , caOutData,  &iOutLen );
               }
            }
       }
*/

  }

  UCP_TRACE_END(0);
}
void termdcs ()
{
   lu0_Estate ();
   lu0_sendstatus ('D');
/*
   printf("RECEIVE SIGUSR1 , dcxdaemon will down \n", getpid());
*/
if (AUTOLOGON==0)
{
       if ( signonflag == 1 )
          lu0_deact ();
}
   lu0_disconnect();
   lu0_Estate ();
   lu0_end();
   shutdown ( fd ,2 ) ;
   close (fd);
   exit(99);
}

/*
void check_routine ()
{
    int rc ;
    unsigned short len ;
    unsigned char  tmpbuf [1025];
    rc=StatusFromBankDae(fd) ;
    switch (rc)
           {
             case 2 :
                     signonflag = 1 ;
                     lu0_act();
                     break;
             case 1 :
                     signonflag = 0 ;
                     lu0_deact();
                     break;
             case 0 :break;
             default:
                     lu0_state ();
                     break ;
           }
    rc = lu0_Estate () ;
    if ( rc < 0 )
       {
        lu0_sendstatus ('D');
        lu0_deact ();
        lu0_disconnect();
        lu0_end ();
        lu0_init();
        for (;;)
            {
             sleep ((unsigned int) sleeptime);
             if ( lu0_connect () == 0 )
                break ;
            }

         if ( signonflag == 1 )
            lu0_deact ();
         lu0_disconnect();
         lu0_end ();
         lu0_init();
         for (;;)
             {
              sleep ((unsigned int) 3);
              if ( lu0_connect () == 0 )
                 break ;
             }
if (AUTOLOGON)
{
         if ( signonflag == 1 )
            {
             for (;;)
                 {
                  sleep ((unsigned int) 3);
                  if ( lu0_act () == 0 )
                     break ;
                 }
            }
}
       }
    signal (SIGALRM , check_routine);
    alarm  ((unsigned int ) 5);
}
*/


void check_routine ()
{
    int rc,flag ;
    unsigned short len ;
    unsigned char  tmpbuf [1025];

    signal(SIGUSR2,SIG_IGN);
    rc=StatusFromBankDae(fd) ;
/*
    printf("STATUSFROMBANKDAE rc [%d]\n",rc);
*/
    switch (rc)
           {
             case 2 :
                     signonflag = 1 ;
/*
                     printf ("SYSTEM SIGNON \n");
*/
                     if (AUTOLOGON==0)
                        {
/*
                     printf ("lu0_act ()\n") ;
*/
                         lu0_act();
                        }
                     break;
             case 1 :
                     signonflag = 0 ;
/*
                     printf ("SYSTEM SIGNOFF \n");
*/
if (AUTOLOGON==0)
{
/*
                     printf ("lu0_deact ()\n") ;
*/
/*
                     lu0_deact();
*/
                     lu0_disconnect ();
                     for (;;)
                         if (lu0_connect () == 0 )
                            break ;
}
                     break;
             case 0 :break;
             default:
                     lu0_state ();
                     break ;
           }
    rc = lu0_Estate () ;
    flag = 0 ;  /* normal */
    if ( rc < 0 )
         flag = -1 ;
    switch ( rc )
       {
        case  -1 :
if (AUTOLOGON==0)
{
                     if ( signonflag == 1 )
                        lu0_deact () ;
}
                     lu0_disconnect();
                     lu0_end () ;
                     lu0_init() ;
                     lu0_connect();
if (AUTOLOGON==0)
{
                     if ( signonflag == 1 )
                        lu0_act () ;
}
                     break ;

        case  -6 :   /* ( info.session_count == 0 )         */
        case  -7 :   /* ( info.session_state < HS_ACTIVE )  */
if (AUTOLOGON)
{
                      lu0_disconnect();
                      lu0_connect   ();
}
else
{
                  if ( signonflag == 1 )
                     {
                      lu0_deact () ;
                      lu0_act   () ;
                     }
}
                  break ;
        case  -2 :   /* (info.line_state > LINE_CONNECTED )  */
        case  -3 :   /* (info.link_state > LLC_OPENED     )  */
/*
                  system ( "/usr/lib/eicon/echalt");
                  system ( "/usr/lib/eicon/ecload -v");
                  system ( "/usr/lib/eicon/sna start  3270" );
                  break ;
*/
        case  -4 :   /* ( info.pu_state  == INACTIVE     )   */
                  if ( g_nPrgCount == 0 )
                     {
                      system ( "/usr/lib/eicon/sna delete 3270" );
                      system ( "/usr/lib/eicon/sna start  3270" );
                     }
                  break ;
        case  -5 :   /* ( info.lu_state  == INACTIVE  )      */
                  lu0_disconnect () ;
                  lu0_connect () ;
if (AUTOLOGON==0)
{
                  if ( signonflag == 1 )
                      lu0_act();
}
                  break ;
        case   0 :
        case   1 :
        case   2 :   break ;
       }
    rc = lu0_Estate () ;
    if ( rc < 0 && flag > 0 )
       lu0_sendstatus ('D');
    if ( rc >= 0 && flag < 0 )
       lu0_sendstatus ('C');
    signal(SIGUSR2,test_routine);
    signal (SIGALRM , check_routine);
    alarm  ((unsigned int ) 5);
}
void test_routine ()
{
   signal (SIGALRM , SIG_IGN);
   if (DISP_FLAG == 0 )
      {
       DISP_FLAG = 1 ;
       fprintf ( stderr, "[%d] DISP_FLAG [%d]\n", getpid(),DISP_FLAG );
      }
   else 
      DISP_FLAG = 0 ;
  signal ( SIGUSR2 , test_routine);
  signal ( SIGALRM , check_routine);
  alarm  ((unsigned int ) 5);
}
void
aaa_test_routine ()
{
    signal (SIGALRM , SIG_IGN);
    switch (signonflag)
           {
             case 0 :
                     signonflag = 1 ;
                     printf ("SYSTEM SIGNON \n");
if (AUTOLOGON == 0)
{
                     lu0_act();
                     lu0_Estate ();
}
                     break;
             case 1 :
                     signonflag = 0 ;
if (AUTOLOGON==0)
{
/*
                     lu0_deact();
                     lu0_disconnect ();
*/
                     lu0_deact();
                     lu0_disconnect();
                     lu0_end();
                     lu0_setup();
/*
                     lu0_disconnect();
                     lu0_end();
                     lu0_setup();
*/
/*
                     system("aaa.bat");
*/
/*                   exit(99);*/
/*                   lu0_setup();*/
/*
                     lu0_deact();
                     lu0_Estate ();
                     lu0_disconnect ();
                     lu0_Estate ();
                     lu0_end();
                     lu0_Estate ();
                     lu0_setup();
                     lu0_Estate ();
                     for (;;)
                         if (lu0_connect () == 0 )
                            break ;
                     lu0_Estate ();
*/
}
                     break;
           }
  signal ( SIGUSR2 , aaa_test_routine);
  signal ( SIGALRM , check_routine);
  alarm  ((unsigned int ) 5);
}
