
#include <errno.h>
#include "errlog.h"
#include "dcs.h"

#define MAX_DATA_LEN    256
/* ------------- dcsqueue.c function ���D�� ------------------------- */
#define P_DcsCreat      67002
#define P_DcsRemove     67003
#define P_GetFileData   67004
#define P_IsUseQuType   67005

/* -------------------- STATIC GLOBAL DECLARATION ------------------- */
static int sg_iaQuId[MAX_NETWKTBL_ARRAY];       /* keep QuId array */
static int sg_iMaxQuId;                         /* max creat queue */

int gs_iQueKey;

int DcsCreat();

main()
{
  int iRc;
  char term_id[4];
  char port_num [3];
  char pu_name [10];
  char caLogName[256];
  FILE *zFp,*fopen(),*lu0tbl_fp;
  char caFileName[50];
  char caProcNum[10];
  char caBrNo[10];
  char caBrId[10],tmp_caBrId[10];
  char caCmd[50];
  char caTmp[50];
  char caLuName [9];
  char caMode [9];
  int AutoLogOnFlag;
  int i,iProcNum,j;
  int pid ;

  system("sna start 3270 1>/dev/null 2>/dev/null");
  sprintf(caLogName, "%s/iii/log/tms_errlog", getenv("III_DIR") );
  ChgLog(LOG_CHG_MODE,"1");
  ChgLog(LOG_CHG_LOG,caLogName);

  iRc = DcsCreat();
  if(iRc != 0){
    ErrLog(1000,"dcmcrenv.c:DcsCreat error!",RPT_TO_LOG,0,0);
    exit(-2);
  }
/* updated by stanley chao 84/02/28   */
  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat(caFileName, BIT_TABLE_PATH);
  strcat(caFileName,BITTABLE);

  if((zFp = fopen(caFileName,"r")) == (FILE *) 0){

    sprintf(g_caMsg,"open BITTABLE fail errno=%d",errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(DCS_ES_OPENTBLFILE);
  }

  if (fscanf(zFp,"%s %s",caBrNo,caBrId) == EOF)
     {
      sprintf(g_caMsg,"fileget BITTABLE fail errno=%d",errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(DCS_ES_OPENTBLFILE);
     }
  sprintf(g_caMsg,"pid [%d] caBrNo [%s] caBrId [%s]\n",getpid(),caBrNo,caBrId);
  ErrLog(0,g_caMsg,RPT_TO_LOG,0,0);
  if ( strcmp ( caBrNo ,"b" ) != 0)
     {
      sprintf(g_caMsg,"BITTABLE branch fail caBrNo=%s",caBrNo);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(DCS_ES_OPENTBLFILE);
     }

  if ( strlen ( caBrId ) == 0)
     {
      sprintf(g_caMsg,"BITTABLE branch fail caBrId IS NULL");
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(DCS_ES_OPENTBLFILE);
     }
  sprintf(g_caMsg,"pid [%d] BITTABLE branch caBrNo=%s,caBrId",getpid(),caBrNo,caBrId);
  ErrLog(0,g_caMsg,RPT_TO_LOG,0,0);
  fclose(zFp);
  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat(caFileName, DCS_TABLE_PATH);
  strcat(caFileName,"rmtprocnum");

  /*
   printf("len [%d]\n", strlen(caFileName));
  */
  if((zFp = fopen(caFileName,"r")) == (FILE *) 0){

    sprintf(g_caMsg,"open rmtprocnum fail errno=%d",errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(DCS_ES_OPENTBLFILE);
  }
/*
  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat(caFileName, DCS_TABLE_PATH);
  strcat(caFileName,LU0TABLE);

  if((lu0tbl_fp = fopen(caFileName,"r")) == (FILE *) 0){

    sprintf(g_caMsg,"open rmtprocnum fail errno=%d",errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    fclose(zFp);
    UCP_TRACE_END(DCS_ES_OPENTBLFILE);
  }
*/
  for(iRc=0;;)
     {
      memset(tmp_caBrId,0,sizeof(tmp_caBrId));
	memset(caLuName,0,sizeof(caLuName));
	memset(caMode,0,sizeof(caMode));
      if (fscanf(zFp,"%s %s %s %s %d  %s %s" ,tmp_caBrId,caProcNum,pu_name,port_num,&i,caLuName,caMode) == EOF)
           break;

	if (*caLuName == 0)
		AutoLogOnFlag = 1;
	else
		AutoLogOnFlag = 0;
      sprintf(g_caMsg,
     "pid [%d] tmp_brid [%s] caBrId [%s] procnum [%s] pu_name [%s] port_num [%s] , start [%d] ,caLuName [%s], caMode[%s]\n",
      getpid(),tmp_caBrId,caBrId,caProcNum,pu_name,port_num,i,caLuName,caMode);
/********
      printf("%s\n",g_caMsg);
********/
      ErrLog(0,g_caMsg,RPT_TO_LOG,0,0);
      if (strcmp ( tmp_caBrId + 3 , caBrId ) != 0 )
         {
           printf("------\n");
           break;
         }

      iProcNum = atoi(caProcNum);
/********
      printf (" BRID     [%s]\n",caBrId );
      printf (" PROCNUM  [%s]\n",caProcNum);
      printf (" PU_NAME  [%s]\n",pu_name);
      printf (" PORT_NUM [%s]\n", port_num);
      printf (" LUNAME   [%s]\n",caLuName );
      printf (" MODE     [%s]\n", caMode);
********/
      for (j=0;j<iProcNum;i++,j++)
          {
           sprintf(caProcNum , "%.2d",i);
/* modified by CJS 1995-04-11 */
#ifdef TEST_MODE_ON
           sprintf(caCmd, "nohup dcxdaemon.x %s %s %s %s 0 %d %d %s %s &",caBrId,caProcNum,pu_name,port_num,AutoLogOnFlag,j,caLuName,caMode);
#else
           sprintf(caCmd, "nohup dcxdaemon.x %s %s %s %s 0 %d %d %s %s &",caBrId,caProcNum,pu_name,port_num,AutoLogOnFlag,j,caLuName,caMode);
#endif
/* end */
           sprintf(g_caMsg,"pid [%d] caCmd---%s---\n",getpid(),caCmd);
           ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
           system(caCmd);
/*
           if ((pid= fork()) == 0 )
              {
               system(caCmd);
       printf ("[%d][%s]\n",pid , caCmd ); 
               exit (0);
              } 
*/
            
          }
     }
/*
  system("dcxdaemon.x 001 03 &");
*/
    fclose( zFp );
    fclose( lu0tbl_fp );
/*
  exit(0);
*/
  UCP_TRACE_END(0);
}

int
DcsCreat()
{
  int i, iRc=0;
  char caFileName[80];
  char *pcFoundFlg;
  /* for get data */
  char caDataType[5];
  long *plDataVar[5];
  /* input data variable for queuetbl */
  char caDesCode[20];
  int iQuFlag;
  long lQuSize;
  long lQuType;
  int iQuId;
  int iLastQuKey;       /* keep last queue key */
  FILE *pfQueFile;

  UCP_TRACE(P_DcsCreat);
  ErrLog(100,"DcsCreat Begin.",RPT_TO_LOG,0,0);

  iQuFlag = IsUseQuType();
  if(iQuFlag < 0){
    ErrLog(1000,"DcsCreat: IsUseQuType error!",RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  }

  /* if use queue protocol than read queuetbl to Creat Quue */
  if(iQuFlag){
    /* get file name */
    strcpy((char *)caFileName, (char *)getenv("III_DIR"));
    strcat(caFileName, DCS_TABLE_PATH);
    strcat(caFileName,"rmtquetbl");

    /* open file queue table */
    pfQueFile = fopen(caFileName,"rt");
    if( pfQueFile == NULL) {

      sprintf("DcsCreat:fopen %s fail errno=%d",caFileName,errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(DCS_E_NETWORKTBL);
    }

    strcpy(caDataType,"sdD");
    plDataVar[0] = (long *)caDesCode;
    plDataVar[1] = &gs_iQueKey;
    plDataVar[2] = &lQuType;

    i = 0;
    sg_iMaxQuId = 0;
    iLastQuKey = -1;    /* initial iLastQuKey */
    lQuSize = -1;       /* initial iQuSize = 0 */
    while((iRc = GetFileData(pfQueFile,3,caDataType,plDataVar)) == 0){

      /* first record is queue size data */
      if(lQuSize < 0){
        iRc = strncmp(caDesCode,"QUEUE_SIZE",10);
        if(iRc == 0){
          lQuSize = lQuType;
        }
        else{   /* no queue size data error */
          fclose(pfQueFile);
          ErrLog(1000,"DcsCreat: Queue Size no define error!",RPT_TO_LOG,0,0);
          UCP_TRACE_END(DCS_E_NETWORKTBL);
        } /* end of if(iRc == 0) -- else */
      }
      else{
        if((lQuSize > 0) && ((gs_iQueKey != iLastQuKey) ||
           (iLastQuKey == -1))){
          iRc = MsqCreat(&iQuId,lQuSize,gs_iQueKey);
          if(iRc != 0){ /* creat queue error */
            UCP_TRACE_END(DCS_E_LOCALDCS);
          } /* end of if(iRc != 0) */
          iLastQuKey = gs_iQueKey;
        } /* end of if((lQuSize > 0) && ((gs_iQueKey != iLastQuKey) ||
                       (iLastQuKey == -1))) */
      } /* end of if(lQuSize < 0) -- else */
    } /* end of while((iRc = GetFileData(3,caDataType,plDataVar)) == 0) */

    fclose(pfQueFile);

  } /* end of if(iQuFlag) */


  ErrLog(100,"DcsCreat End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}



int
IsUseQuType()
{
  int i;
  int iRc=0;
  char caFileName[80];
  char *pcFoundFlg;
  /* for get data */
  char caDataType[5];
  long *plDataVar[5];
  /* input data variable for prototbl */
  char caDesCode[20];
  char cProtoType;
  /* input data variable for queuetbl */
  int iQuFlag;
  FILE *pfProtoFile;

  UCP_TRACE(P_IsUseQuType);
  ErrLog(100,"IsUseQuType Begin.",RPT_TO_LOG,0,0);

  /* open input Data file */
  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat(caFileName, DCS_TABLE_PATH);
  strcat(caFileName,"rmtprototbl");

  pfProtoFile = fopen(caFileName,"rt");
  if( pfProtoFile == NULL) {
    sprintf("IsUseQuType:fopen %s fail errno=%d",caFileName,errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  }

  strcpy(caDataType,"sc");
  plDataVar[0] = (long *) caDesCode;
  plDataVar[1] = (long *) &cProtoType;

  /* read prototbl to check that is queue protocol used ? */
  iQuFlag = 0;
  while((iRc = GetFileData(pfProtoFile,2,caDataType,plDataVar)) == 0){
    if(cProtoType == 'Q'){
      iQuFlag = 1;
      break;
    }
  } /* end of while((iRc = GetFileData(2,caDataType,plDataVar)) == 0) */

  fclose(pfProtoFile);

  ErrLog(100,"IsUseQuType End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(iQuFlag);
}




int
GetFileData(FILE *pfFile, int iDataNo,char caDataType[], long* plDataVar[])
{
  int i;
  long lOffset;
  char caDataBuf[MAX_DATA_LEN];
  char cBypass,cDummy;

  UCP_TRACE(P_GetFileData);

  do {
    if(feof(pfFile)){
      UCP_TRACE_END(-1);
    }

    fgets(caDataBuf,MAX_DATA_LEN,pfFile);
    if (caDataBuf[0] != '#') {
      lOffset = (long) strlen(caDataBuf) * -1;
      fseek(pfFile,lOffset,SEEK_CUR);

      for(i=0; i < iDataNo ; i++){

        fscanf(pfFile,"%c",&cBypass);
        if( cBypass != '*') {

          fseek(pfFile,-1,SEEK_CUR);
          switch(caDataType[i]){
            case 't' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%d\n",(short *) plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%d ",(short *) plDataVar[i]);
              }
              break;
            case 'd' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%d\n",(int *) plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%d ",(int *) plDataVar[i]);
              }
              break;
            case 'D' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%ld\n",(long *) plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%ld ",(long *) plDataVar[i]);
              }
              break;
            case 'o' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%o\n",(int *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%o ",(int *)plDataVar[i]);
              }
              break;
            case 'O' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%lo\n",(long *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%lo ",(long *)plDataVar[i]);
              }
              break;
            case 'x' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%x\n",(int *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%x ",(int *)plDataVar[i]);
              }
              break;
            case 'X' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%lx\n",(long *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%lx ",(long *)plDataVar[i]);
              }
              break;
            case 'i' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%i\n",(int *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%i ",(int *)plDataVar[i]);
              }
              break;
            case 'I' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%li\n",(long *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%li ",(long *)plDataVar[i]);
              }
              break;
            case 's' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%s\n",(char *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%s ",(char *)plDataVar[i]);
              }
              break;
            case 'c' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%c\n",(char *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%c ",(char *)plDataVar[i]);
              }
              break;
            default :
              sprintf(g_caMsg,"GetFileData: data-type=%c error",caDataType[i]);
              ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
              UCP_TRACE_END(-2);
          }  /* end switch */
        }
        else {
          if( (i == iDataNo-1) && (cDummy == '\n') ) {
            fscanf(pfFile,"\n");
            UCP_TRACE_END(0);
          }
          else fscanf(pfFile," ");
        } /* end if '*' */
      }  /* end for */
    }  /* end if  '#' */
  } while(caDataBuf[0] == '#');

  UCP_TRACE_END(0);
}
