#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <memory.h>
#include <malloc.h>
#include <string.h>
#include <malloc.h>
#include <sys/types.h>
#include <sys/time.h>
/*
#include <sys/select.h>
*/
#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <signal.h>
#include <unistd.h>
#include <sys/socket.h>
/*
#include <sys/un.h>
*/
#include <sys/ioctl.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <netdb.h>
#include "bankdae.h"
#include "bankdae.err"
#include "tellinfo.c"

main(argc,argv)
int     argc;
char    **argv;
{
/*
        struct sigvec   vec;
*/
        int             i;

	memset(III_DIR,0,sizeof(III_DIR));
        for (i=0;i<64;i++)
                signal(i,SIG_IGN);
/*
        signal(SIGPIPE,SIG_IGN);

        vec.sv_handler = (void *) del_zom;
        vec.sv_mask = 0;
        vec.sv_flags = 0;

        if (sigvec(SIGCLD,&vec,(struct sigvec *) 0) < 0)
                exit(-1);

        prnmsg("signal set ok !!\n");
*/

        if (argc < 4)
                port_flag = 0;
        else
        {
                port_flag = 1;
                session_port = atoi(argv[3]);
        }
        if (argc < 3)
                show_flag = 0;
        else
                show_flag = atoi(argv[2]);

        if (argc < 2)
		strcpy(III_DIR,"/home/iii/tpe");
	else
		strcpy(III_DIR,argv[1]);

        init_fileset();
/*
        if (init_confirm_table() != SUCCESS)
                exit(-1);
        if (init_manager_table() != SUCCESS)
                exit(-1);
*/
/*
        if (pipe(local_erg_sock) < 0)
                exit(-1);
*/
        if (port_flag == 1)
        {
                if ((remote_sock = init_remote_sock(session_port)) < 0)
                        exit(-1);
        }
        else
                if ((remote_sock = init_remote_sock(SESSION_PORT)) < 0)
                        exit(-1);

        if (argc < 5)
        {
                if ((local_super_sock = init_remote_sock(SUPER_PORT)) < 0)
                        exit(-1);
        }
        else
                if ((local_super_sock = init_remote_sock(atoi(argv[4]))) < 0)
                        exit(-1);

        for (;;)
                if (wait_for_event() < 0)
                        prnmsg(sess_errmsg);
}

int     wait_for_event()
{
        int     i;
        int     maxfile=0;
        fd_set  rmask;

        FD_ZERO(&rmask);
/*
        FD_SET(local_erg_sock[0],&rmask);
*/
        FD_SET(local_super_sock,&rmask);
        FD_SET(remote_sock,&rmask);

        maxfile = local_super_sock;
        if (maxfile < remote_sock)
                maxfile = remote_sock;

        for (i=0;i<MAXFD;i++)
        {
                if (fileset[i].r_fd > 0)
                {
                        if (maxfile < fileset[i].r_fd )
                                maxfile = fileset[i].r_fd;
                        FD_SET(fileset[i].r_fd,&rmask);
                }
                if (fileset[i].l_fd[0] > 0)
                {
                        if (maxfile < fileset[i].l_fd[0] )
                                maxfile = fileset[i].l_fd[0];
                        FD_SET(fileset[i].l_fd[0],&rmask);
                }
        }

        if (select(maxfile+1,&rmask,0,0,0) <= 0)
        {
                strcpy(sess_errmsg,"wait_for_event(): select err !!\n");
                return(SELECT_ERR);
        }

        for (i=0;i<MAXFD;i++)
                if (r_resend[i] == 1)
                        check_write_buffer(i);
/*
        if (FD_ISSET(local_erg_sock[0],&rmask))
                check_write_buffer();
*/
        if (FD_ISSET(remote_sock,&rmask))
                remote_accept(remote_sock);

        if (FD_ISSET(local_super_sock,&rmask))
                remote_accept(local_super_sock);

        for (i=0;i<MAXFD;i++)
        {
                if (fileset[i].r_fd > 0 && r_resend[i] == 0)
                {
                        if (FD_ISSET(fileset[i].r_fd,&rmask))
                                r_read(i);
                }
                if (fileset[i].l_fd[0] > 0 && r_resend[i] == 0)
                {
                        if (FD_ISSET(fileset[i].l_fd[0],&rmask))
                                l_read(i);
                }
        }
}

int     l_read(id)
int     id;
{
        char            buf[256];
        int             rt_code1,rt_code2;

        sprintf(buf,"l_read(%d): begin !!\n",id);
        prnmsg(buf);
        if ((rt_code1 = read(fileset[id].l_fd[0],local_read_buf[id],SOCKSIZE)) <= 0)
        {
                strcpy(sess_errmsg,"l_read(): read() err !!\n");
                sprintf(buf,"l_read(%d): read remove session (%d) !!\n",id,errno);
                prnmsg(buf);
                remove_session(id);
                return(rt_code1);
        }
        sprintf(buf,"l_read(%d): read %d byte(s) ok !!\n",id,rt_code1);
        prnmsg(local_read_buf[id]);
        prnmsg("-------- local data end -------- !!\n");

        if ((rt_code2 = write(fileset[id].r_fd,local_read_buf[id],rt_code1)) <= 0)
        {
                if ((errno == EAGAIN) || (errno == EWOULDBLOCK))
                {
                        r_resend[id] = 1;
                        r_resend_off[id] = 0;
                        r_resend_length[id] = rt_code1;
                        sprintf(buf,"l_read(%d): must be resend 1 !!\n",id);
                        prnmsg(buf);
                        return(BLOCK_ERR);
                }
                strcpy(sess_errmsg,"l_read(): write() err !!\n");
                sprintf(buf,"l_read(%d): write remove session (%d) !!\n",id,errno);
                prnmsg(buf);
                remove_session(id);
                return(REMOTE_CLOSE);
        }
        if (rt_code1 != rt_code2)
        {
                r_resend[id] = 1;
                r_resend_off[id] = rt_code2;
                r_resend_length[id] = rt_code1-rt_code2;
                sprintf(buf,"l_read(%d): must be resend 2 !!\n",id);
                prnmsg(buf);
                return(BLOCK_ERR);
        }
        sprintf(buf,"l_read(%d): end !!\n",id);
        prnmsg(buf);
        return(rt_code2);
}

/*

*/

int     r_read(id)
int     id;
{
        char    buf[256];
        int     rt_code1,rt_code2;


        if ((rt_code1 = read(fileset[id].r_fd
            ,remote_read_buf[id]+remote_read_off[id],remote_read_length[id])) <= 0)
        {
                strcpy(sess_errmsg,"r_read(): read() err !!\n");
                sprintf(buf,"r_read(%d): read remove session (%d) !!\n",id,errno);
                prnmsg(buf);
                remove_session(id);
                return(rt_code1);
        }
        sprintf(buf,"r_read(%d): read %d byte(s) ok !!\n",id,rt_code1);
        prnmsg(buf);
        prnmsg(remote_read_buf[id]);
        prnmsg("-------- remote data end -------- !!\n");

        remote_read_off[id] += rt_code1;
        remote_read_length[id] -= rt_code1;
        if (remote_read_length[id] == 0)
        {
		switch (remote_read_type[id])
                {
                        case DATA_MORE:
                        {
                                char    tmp[8];

                                memset(tmp,0,sizeof(tmp));
                                memcpy(tmp,remote_read_buf[id]+3,5);
                                remote_data_length[id] = atoi(tmp);
                                remote_read_length[id] = remote_data_length[id] - HEADER_LEN;
                                if (remote_read_length[id] != 0)
                                {
                                        remote_read_type[id] = DATA_BODY;
                                        sprintf(buf,"r_read(%d): read data header ok !!\n",id);
                                        prnmsg(buf);
                                        return(rt_code1);
                                }
                        }
                        case DATA_BODY:
                                remote_read_type[id] = DATA_MORE;
                                remote_read_off[id] = 0;
				remote_read_length[id] = HEADER_LEN;
                                sprintf(buf,"r_read(%d): read data body ok !!\n",id);
                                prnmsg(buf);
                                break;
                }
        }
        else
        {
                sprintf(buf,"r_read(%d): continue read !!",id);
                prnmsg(buf);
                return (rt_code1);
        }

        switch (remote_read_buf[id][1])
        {
		case KIND_KILLDAE:
			read_killdae(id);
			break;
		case KIND_PSWDRQ:
			read_pswdrq(id);
			break;
		case KIND_PSWDACK:
			break;
		case KIND_LU0:
			read_lu0(id);
			break;
		case KIND_PRINT:
			read_print(id);
			break;
		case KIND_SIGNON:
			read_signon(id);
			break;
		case KIND_SIGNOFF:
			read_signoff(id);
			break;
		case KIND_LU0CON:
			read_lu0con(id);
			break;
		case KIND_CNFRQ:
			read_cnfrq(id);
			break;
		case KIND_CNFACK:
			read_cnfack(id);
			break;
		case KIND_BROAD:
			read_broad(id);
			break;
		case KIND_TOKEN:
			read_token(id);
			break;
		default:
			if ((rt_code2 = write(fileset[id].l_fd[1],remote_read_buf[id]
					  ,remote_data_length[id])) <= 0)
			{
				strcpy(sess_errmsg,"r_read(): write() err !!\n");
				sprintf(buf
				,"r_read(%d): write remove session (%d) !!\n"
				,id,errno);
				prnmsg(buf);
				remove_session(id);
				return(rt_code1);
			}
	}

	sprintf(buf,"r_read(%d): end of data !!\n",id);
	prnmsg(buf);
	memset(remote_read_buf[id],0,SOCKSIZE);

	return(rt_code2);
}

int   check_write_buffer(id)
{
        char    buf[256];
        int     rt_code;

        if ((rt_code = write(fileset[id].r_fd,local_read_buf[id]+r_resend_off[id],r_resend_length[id])) <= 0)
        {
                if ((errno == EAGAIN) || (errno == EWOULDBLOCK))
                {
                        sprintf(buf,"check_write_buffer(%d): must be resend 1 !!\n",id);
								prnmsg(buf);
                        return(BLOCK_ERR);
					 }
                strcpy(sess_errmsg,"check_write_buffer(): write() err !!\n");
                sprintf(buf,"check_write_buffer(%d): write remove session (%d) !!\n",id,errno);
                prnmsg(buf);
                remove_session(id);
                return (REMOTE_CLOSE);
        }
        if (rt_code != r_resend_length[id])
        {
                r_resend_off[id] += rt_code;
                r_resend_length[id] -= rt_code;
                sprintf(buf,"check_write_buffer(%d): must be resend 2 !!\n",id);
                prnmsg(buf);
                return(BLOCK_ERR);
        }
        else
        {
                r_resend[id] = 0;
                r_resend_off[id] = 0;
                r_resend_length[id] = 0;
        }
        return (SUCCESS);
}

int     init_remote_sock(port_no)
int     port_no;
{
        struct sockaddr_in      server;
        int                     fd;

        if ((fd = socket(AF_INET,SOCK_STREAM,0)) < 0)
        {
                strcpy(sess_errmsg,"init_remote_sock(): socket err !!\n");
                return(SOCKET_ERR);
        }
        prnmsg("init_remote_sock(): socket ok !!\n");

        server.sin_family = AF_INET;
        server.sin_port = htons(port_no);
        server.sin_addr.s_addr = INADDR_ANY;
        if (bind(fd,&server,sizeof(server)) < 0)
        {
                close(fd);
                strcpy(sess_errmsg,"init_remote_sock(): bind err !!\n");
                return(BIND_ERR);
        }
        prnmsg("init_remote_sock(): bind ok !!\n");

        listen(fd,5);

		  return(fd);
}

int     remote_accept(fd1)
int     fd1;
{
        int             fd2;
        int             len;
        int             id;
        int             pid,rp[2],wp[2];
        char            arg4[32],arg5[32];
        char            hostname[256];
        char            buf[256];
        struct hostent  *hostent;
        struct  sockaddr_in     client;
        struct  ip_addr         *ip;
        char            iiidir[256],psupath[256];
        char            *tmp;

        strcpy(hostname,"NULL_HOST");
        strcpy(iiidir,"NULL_DIR");

        len = sizeof(client);
        if ((fd2 = accept(fd1,&client,&len)) <= 0)
        {
                strcpy(sess_errmsg,"remote_accept(): accept err !!\n");
					 return(ACCEPT_ERR);
        }
		  prnmsg("remote_accept(): accept ok !!\n");

        if ((id=insert_r_fd(fd2)) < 0)
        {
                close(fd2);
                strcpy(sess_errmsg,"remote_accept(): insert_r_fd() err !!\n");
                return(SESSION_FULL);
        }

        sprintf(buf,"remote_accept(): insert_r_fd(%d) ok !!\n",id);
        prnmsg(buf);

        set_sock_size(fd2,BUFSIZE);

        if (fd1 != local_super_sock)
        {
                pipe(rp);
                pipe(wp);
                fileset[id].l_fd[0] = rp[0];
                fileset[id].l_fd[1] = wp[1];
		fileset[id].type = TYPE_DBP;
                sprintf(arg4,"%d",wp[0]);
                sprintf(arg5,"%d",rp[1]);
                if ((hostent=gethostbyaddr(&client.sin_addr
								,sizeof(client.sin_addr),AF_INET)) != 0)
                {
								char buf[256];
                        sprintf(buf,"remote_accept(): host name is %s\n"
                                ,hostent->h_name);
                        prnmsg(buf);
                        strcpy(hostname,hostent->h_name);
                 }
/*
                if ((tmp = getenv("III_DIR")) != NULL)
                {
                        strcpy(iiidir,tmp);
                }
		sprintf(psupath,"%s%s%s",iiidir,EXE_PATH,EXE_FILE);
*/
		sprintf(psupath,"%s%s%s",III_DIR,EXE_PATH,EXE_FILE);
                if ((pid = fork()) == 0)
                {
                        execl(psupath,EXE_FILE,III_DIR,"QUEUE","y",
                                arg4,arg5,hostname,0);
                        exit(0);
                }
                close(wp[0]);
                close(rp[1]);
		fileset[id].cid = pid;
        }
	else
		fileset[id].type = TYPE_LU0;
        return(fd2);
}

int     set_sock_size(fd,len)
int     fd;
int     len;
{
        int     flag=1;

        setsockopt(fd,SOL_SOCKET,SO_SNDBUF,(char *) &len,sizeof(len));
        setsockopt(fd,SOL_SOCKET,SO_RCVBUF,(char *) &len,sizeof(len));
        ioctl(fd,FIONBIO,&flag);
        return(SUCCESS);
}

int     insert_r_fd(fd)
int     fd;
{
        char    buf[256];
        int     i;

        sprintf(buf,"insert_r_fd(): begin !!\n");
        prnmsg(buf);
        for (i=0;i<MAXFD;i++)
                if (fileset[i].l_fd[0] < 0 && fileset[i].l_fd[1] < 0
                && fileset[i].r_fd < 0)
                {
                        remote_read_buf[i] = (char *) malloc(SOCKSIZE);
                        if (remote_read_buf[i] == NULL)
				return (SHM_ERR);
                        memset(remote_read_buf[i],0,SOCKSIZE);
			local_read_buf[i] = (char *) malloc(SOCKSIZE);
                        if (local_read_buf[i] == NULL)
                        {
                                free(remote_read_buf[i]);
                                remote_read_buf[i] = NULL;
                                return (SHM_ERR);
                        }
                        memset(local_read_buf[i],0,SOCKSIZE);
                        fileset[i].r_fd = fd;
                        return(i);
                }
        sprintf(buf,"insert_r_fd(): end !!\n");
        prnmsg(buf);
        return(-1);
}

int     remove_session(id)
int     id;
{
        char    buf[256];

        sprintf(buf,"remove_session(%d): begin !!\n",id);
        prnmsg(buf);
        if (fileset[id].r_fd >= 0)
		close(fileset[id].r_fd);
        if (fileset[id].l_fd[0] >= 0)
		close(fileset[id].l_fd[0]);
        if (fileset[id].l_fd[1] >= 0)
                close(fileset[id].l_fd[1]);
        if (remote_read_buf[id] != NULL)
        {
                free(remote_read_buf[id]);
                remote_read_buf[id] = NULL;
        }
        if (local_read_buf[id] != NULL)
        {
                free(local_read_buf[id]);
                local_read_buf[id] = NULL;
        }
        fileset[id].r_fd = -1;
        fileset[id].l_fd[0] = -1;
        fileset[id].l_fd[1] = -1;
	fileset[id].type = 0;
        memset(fileset[id].id,0,sizeof(fileset[id].id));
        memset(fileset[id].bcode,0,sizeof(fileset[id].bcode));
        memset(fileset[id].tcode,0,sizeof(fileset[id].tcode));
        memset(fileset[id].file,0,sizeof(fileset[id].file));
        fileset[id].prn = NULL;
        fileset[id].power = 0;
        fileset[id].mode = MODE_FREE;
        remote_read_type[id] = DATA_MORE;
	remote_read_length[id] = HEADER_LEN;
        remote_read_off[id] = 0;
	remote_data_length[id] = 0;
        r_resend[id] = 0;
        r_resend_off[id] = 0;
        r_resend_length[id] = 0;
	if (fileset[id].cid > 0)
	{
		char	buf[256];

		sprintf(buf,"kill -9 %d",fileset[id].cid);
		system(buf);
	}
	fileset[id].cid = -1;
        sprintf(buf,"remove_session(%d): end !!\n",id);
        prnmsg(buf);
        return (SUCCESS);
}

int     init_fileset()
{
        int     i;

        for(i=0;i<MAXFD;i++)
        {
                fileset[i].r_fd = -1;
                fileset[i].l_fd[0] = -1;
                fileset[i].l_fd[1] = -1;
		fileset[i].type = 0;
                memset(fileset[i].id,0,sizeof(fileset[i].id));
                memset(fileset[i].bcode,0,sizeof(fileset[i].bcode));
                memset(fileset[i].tcode,0,sizeof(fileset[i].tcode));
                memset(fileset[i].file,0,sizeof(fileset[i].file));
                fileset[i].prn = NULL;
                fileset[i].power = 0;
		fileset[i].mode = MODE_FREE;
		fileset[i].cid = -1;
                memset(confirm[i].tid,0,sizeof(confirm[i].tid));
                memset(confirm[i].mid1,0,sizeof(confirm[i].mid1));
                memset(confirm[i].mid2,0,sizeof(confirm[i].mid2));
                memset(manager[i].id,0,sizeof(manager[i].id));
                manager[i].total = -1.0;
                manager[i].ratio = -1.0;
                monitor_sock[i] = -1;
                remote_read_length[i] = HEADER_LEN;
                remote_read_type[i] = DATA_MORE;
                remote_read_off[i] = 0;
                remote_read_buf[i] = NULL;
                local_read_buf[i] = NULL;
                remote_data_length[i] = 0;
                r_resend[i] = 0;
                r_resend_off[i] = 0;
                r_resend_length[i] = 0;
        }
}

/*
int     init_confirm_table()
{
        FILE    *in;
        char    filename[256],*tmp;
        int     index=0;

	prnmsg("init_confirm_table(): begin !!\n");
        if ((tmp = getenv("III_DIR")) == NULL)
        {
                prnmsg("init_confirm_table(): III_DIR not defined !!\n");
                return (FILE_ERR);
        }
        sprintf(filename,"%s%s",tmp,CONFIRM_TABLE);
        if ((in = fopen(filename,"r")) == NULL)
        {
                prnmsg("init_confirm_table(): file open error !!\n");
                return (FILE_ERR);
        }
        while (fscanf(in,"%s %s %s",confirm[index].tid,confirm[index].mid1
                        ,confirm[index].mid2) != EOF)
        {
                index++;
        }
        fclose(in);
        prnmsg("init_confirm_table(): end !!\n");
        return (SUCCESS);
}

int     init_manager_table()
{
        FILE    *in;
        char    total[32],ratio[32];
	char    filename[256],*tmp;
        int     index=0;

        prnmsg("init_manager_table(): begin !!\n");
        if ((tmp = getenv("III_DIR")) == NULL)
        {
                prnmsg("init_manager_table(): III_DIR not defined !!\n");
                return (FILE_ERR);
        }
        sprintf(filename,"%s%s",tmp,PRIORITY_TABLE);
        if ((in = fopen(filename,"r")) == NULL)
        {
                prnmsg("init_manager_table(): file open error !!\n");
                return (FILE_ERR);
        }
        while (fscanf(in,"%s %s %s %s",manager[index].id,total
                ,ratio,manager[index].pswd) != EOF)
        {
                manager[index].total = atof(total);
                manager[index].ratio = atof(ratio);
                index++;
        }
        fclose(in);
        prnmsg("init_manager_table(): end !!\n");
        return (SUCCESS);
}
*/

int     read_lu0(id)
int     id;
{
        int     i;
        char    bcode[4],tcode[3],status;
        char    buf[256];

        prnmsg("read_lu0(): begin !!\n");

        memset(bcode,0,sizeof(bcode));
        memset(tcode,0,sizeof(tcode));

        memcpy(bcode,remote_read_buf[id]+HEADER_LEN,3);
        memcpy(tcode,remote_read_buf[id]+HEADER_LEN+3,2);
        status = remote_read_buf[id][HEADER_LEN+5];

        sprintf(buf,"read_lu0(): bid[%s] tid[%s] status[%c] !!\n"
                ,bcode,tcode,status);
        prnmsg(buf);

        for (i=0;i<MAXFD;i++)
        {
                if (fileset[i].type == TYPE_DBP
		&& strcmp(fileset[i].tcode,tcode) == 0
                && strcmp(fileset[i].bcode,bcode) == 0)
                {
			prnmsg("read_lu0(): find bcode && tcode !!\n");
                        write(fileset[i].r_fd,remote_read_buf[id]
                        ,remote_data_length[id]);
                        break;
                }
        }
        prnmsg("read_lu0(): end !!\n");
        return (SUCCESS);
}

int     read_print(id)
int     id;
{
        prnmsg("read_print(): begin !!\n");
        switch (remote_read_buf[id][HEADER_LEN])
        {
                case CMD_BEGIN:
                {
                        char    *fname,*tmp;
                        char    directory[128];
                        char    buf[256];

                        prnmsg("read_print(): read BEGIN CMD !!\n");
/*
                        if ((tmp = getenv("III_DIR")) == NULL)
                        {
                                prnmsg("read_print(): III_DIR undefined !!\n");
				return (FILE_ERR);
                        }
                        sprintf(directory,"%s%s",tmp,TMP_PRINT_PATH);
*/
                        sprintf(directory,"%s%s",III_DIR,TMP_PRINT_PATH);
                        fname = tempnam(directory,TMP_PRINT_FILE);
                        if (fname == NULL)
                        {
                                prnmsg("read_print(): tmp file name err !!\n");
                                return (FILE_ERR);
                        }
                        strcpy(fileset[id].file,fname);
                        sprintf(buf,"read_print(): tmpname [%s] !!\n",fname);
                        prnmsg(buf);
                        free(fname);
			if ((fileset[id].prn = fopen(fileset[id].file,"w"))
			== NULL)
                        {
                                prnmsg("read_print(): tmp file open err !!\n");
                                return (FILE_ERR);
                        }
                        break;
                }
                case CMD_PRINT:
                {
                        prnmsg("read_print(): read PRINT CMD !!\n");
                        if (fileset[id].prn != NULL)
                        {
				prnmsg("read_print(): write data to file !!\n");
                                fwrite(remote_read_buf[id]+HEADER_LEN+2
                                        ,1
                                        ,remote_data_length[id]-HEADER_LEN-2
                                        ,fileset[id].prn);
                        }
                        break;
                }
                case CMD_END:
                {
                        char    buf[256];

			prnmsg("read_print(): read END CMD !!\n");
			if (fileset[id].prn != NULL)
                        {
                                prnmsg("read_print(): close tmp file !!\n");
                                fclose(fileset[id].prn);
                                fileset[id].prn = NULL;
#ifdef PRINT_TMP
                                sprintf(buf,"lp -d sysprn %s",fileset[id].file);
                                system(buf);
                                sprintf(buf,"rm %s",fileset[id].file);
                                system(buf);
                                memset(fileset[id].file,0
                                        ,sizeof(fileset[id].file));
#endif
			}
                        break;
                }
                default:
                        prnmsg("read_print(): CMD undefined !!\n");
                        break;
        }
        prnmsg("read_print(): end !!\n");
        return (SUCCESS);
}

int     read_pswdrq(id)
int     id;
{
        int     i;
        char    buf[256];
        char    tid[5],mid[5],pswd[9];

        prnmsg("read_pswdrq(): begin !!\n");
        memset(tid,0,sizeof(tid));
        memset(mid,0,sizeof(mid));
        memset(pswd,0,sizeof(pswd));
        memcpy(tid,remote_read_buf[id]+HEADER_LEN,4);
        memcpy(mid,remote_read_buf[id]+HEADER_LEN+4,4);
        memcpy(pswd,remote_read_buf[id]+HEADER_LEN+8,4);

	sprintf(buf,"read_pswdrq(): tid-[%s] mid-[%s] pswd-[%s] !!\n"
	,tid,mid,pswd);
        prnmsg(buf);
        memset(buf,0,sizeof(buf));
        buf[0] = '0';
        buf[1] = KIND_PSWDACK;
        buf[2] = 'S';
        buf[3] = '0';buf[4] = '0';buf[5] = '0';buf[6] = '1';buf[7] = '7';

        switch (check_pswd(fileset[id].bcode,mid,pswd))
	{
		case SUCCESS:
                	buf[HEADER_LEN+8] = PSWD_YES;
			break;
		case FILE_ERR:
                	buf[HEADER_LEN+8] = PSWD_MAN;
			break;
		default:
                	buf[HEADER_LEN+8] = PSWD_NO;
			break;
	}
/*
        if (check_pswd(fileset[id].bcode,mid,pswd) == SUCCESS)
                buf[HEADER_LEN+8] = PSWD_YES;
        else
               	buf[HEADER_LEN+8] = PSWD_NO;
*/

        memcpy(buf+HEADER_LEN,tid,4);
        memcpy(buf+HEADER_LEN+4,mid,4);

        write(fileset[id].r_fd,buf,17);

        prnmsg("read_pswdrq(): end !!\n");
        return (SUCCESS);
}

int     check_pswd(bcode,mid,pswd)
char    *bcode,*mid,*pswd;
{
        int     i;
	char	mpswd[9];
	char	buf[256];
	char	power;

        prnmsg ("check_pswd(): begin !!\n");
	memset(mpswd,0,sizeof(mpswd));
	if (GetTelPasswd(bcode,mid,mpswd,&power) < 0)
	{
        	prnmsg ("check_pswd(): GetTelPasswd error !!\n");
		return (PROTOCOL_ERR);
	}
	sprintf(buf,"check_pswd(): get manager pswd[%s] !!\n",mpswd);
	prnmsg(buf);
	if (IsManager(power) != 1)
	{
		prnmsg("check_pswd(): not a manager !!\n");
		return (FILE_ERR);
	}
	if (strcmp(mpswd,pswd) == 0)
	{
		prnmsg("check_pswd(): pswd match !!\n");
		return (SUCCESS);
	}
	else
	{
        	prnmsg ("check_pswd(): pswd not match !!\n");
        	return (PROTOCOL_ERR);
	}
/*
        for (i=0;i<MAXFD;i++)
        {
                if (strcmp(manager[i].id,mid) == 0)
                {
                        prnmsg("check_pswd(): find mid !!\n");
                        if (strcmp(manager[i].pswd,pswd) == 0)
                        {
                                prnmsg("check_pswd(): pswd match !!\n");
                                return (SUCCESS);
                        }
			break;
                }
        }
        prnmsg ("check_pswd(): end !!\n");
        return (PROTOCOL_ERR);
*/
}

int     read_killdae(id)
int     id;
{
        int     i;

        prnmsg("read_killdae(): begin !!\n");
	for (i=0;i<MAXFD;i++)
		if (fileset[i].r_fd >= 0)
			remove_session(i);
	prnmsg("read_killdae(): end !!\n");
	exit (0);
}

int     read_signon(id)
int     id;
{
	int     i,ilu0;
	char    buf[256];

	prnmsg("read_signon(): begin !!\n");
	memcpy(fileset[id].id,remote_read_buf[id]+HEADER_LEN,4);
	fileset[id].power = remote_read_buf[id][HEADER_LEN+4];
	if (remote_data_length[id] > HEADER_LEN+5)
	{
		memcpy(fileset[id].bcode,remote_read_buf[id]+HEADER_LEN+5,3);
		memcpy(fileset[id].tcode,remote_read_buf[id]+HEADER_LEN+8,2);
	}
	sprintf(buf,"read_signon(): tellerid:[%s] pri:[%x] bid[%s] tid[%s]!!\n"
		 ,fileset[id].id,fileset[id].power,fileset[id].bcode
		 ,fileset[id].tcode);
	prnmsg(buf);
	for (i=0;i<MAXFD;i++)
	{
/* added by YEM 19950503 begin  */
		if (i != id && fileset[i].type == TYPE_DBP
		&& strcmp(fileset[i].tcode,fileset[id].tcode) == 0) {
                  remove_session(i);
                  continue;
                }
/* added by YEM 19950503 end  */
		if (i != id && fileset[i].type == TYPE_DBP
		&& strcmp(fileset[i].id,fileset[id].id) == 0)
		{
			if (strcmp(fileset[i].tcode,fileset[id].tcode) == 0)
			{
			prnmsg("read_signon(): find duplicate teller id && terminal code !!\n");
			remove_session(i);
			}
			else
			{
			prnmsg("read_signon(): find duplicate teller id !!\n");
			write(fileset[id].r_fd,"0SS00008",8);
			}
		}
		if (i != id && fileset[i].type == TYPE_LU0
		&& strcmp(fileset[i].bcode,fileset[id].bcode) == 0
		&& strcmp(fileset[i].tcode,fileset[id].tcode) == 0)
		{
			prnmsg("read_signon(): find dcxdaemon login !!\n");
			write(fileset[i].r_fd,"2",1);
		}
	}

	prnmsg("read_signon(): end !!\n");
	return (SUCCESS);
}

int     read_cnfrq(id)
int     id;
{
	char    mid[5],tid[5];
	int     i,j,nid1=-1,nid2=-1;
	char    buf[256];
	char    msg[256];

	prnmsg("read_cnfrq(): begin !!\n");
	memset(mid,0,sizeof(mid));
	memset(tid,0,sizeof(tid));
	memcpy(mid,remote_read_buf[id]+HEADER_LEN+4,4);
	memcpy(tid,remote_read_buf[id]+HEADER_LEN,4);
	sprintf(buf,"read_cnfrq(): -------- tid:[%s] mid:[%s] !!\n"
		,tid,mid);
	prnmsg(buf);
	memset(buf,0,sizeof(buf));
	buf[0] = '0';
	buf[1] = KIND_DAEMON;
	buf[2] = 'S';
	/* fill data length header */
	buf[3] = '0';buf[4] = '0';buf[5] = '0';buf[6] = '1';buf[7] = '3';
	buf[HEADER_LEN+4] = STATE_NOTFIND;
	memcpy(buf+HEADER_LEN,mid,4);

	if (*mid != 0)
	{
		prnmsg("read_cnfrq(): search mid != NULL begin !!\n");
		for (i=0;i<MAXFD;i++)
		{
			if (strcmp(fileset[i].id,mid) == 0)
			{
				prnmsg("read_cnfrq(): find mid !!\n");
				memcpy(buf+HEADER_LEN,fileset[i].id,4);
				if (fileset[i].mode == MODE_FREE)
				{
					prnmsg("read_cnfrq(): mode free !!\n");
	 /*Add Ann*/                    if(IsManager(fileset[i].power)){
						write(fileset[i].r_fd
							,remote_read_buf[id]
							,remote_data_length[id]);
						buf[HEADER_LEN+4] = STATE_WAITCNF;
	 /*Add Ann*/			}
	 /*Add Ann*/            	else{
	 /*Add Ann*/           			buf[HEADER_LEN+4] = STATE_NOPV;
	 /*Add Ann*/            	}
				}
				else
				{
					prnmsg("read_cnfrq(): mode lock !!\n");
					buf[HEADER_LEN+4] = STATE_BUSY;
				}
				break;
			}
		}
		prnmsg("read_cnfrq(): search mid != NULL end !!\n");
	}
	else
	{
		char	mid1[5],mid2[5];

		prnmsg("read_cnfrq(): search mid == NULL begin !!\n");
		memset(mid1,0,sizeof(mid1));
		memset(mid2,0,sizeof(mid2));
		if (GetTelSup(fileset[id].bcode,tid,mid1,mid2) > 0)
		{
		sprintf(msg,"read_cnfrq(): find mid1[%s] mid2[%s]\n",mid1,mid2);
		prnmsg(msg);
		for (i=0;i<MAXFD;i++)
		{
			if (fileset[i].type != TYPE_DBP)
				continue;
			if (strcmp(fileset[i].id,mid1) == 0)
				nid1 = i;
			if (strcmp(fileset[i].id,mid2) == 0)
				nid2 = i;
		}
                if (nid1 >= 0)
		{
			memcpy(buf+HEADER_LEN,fileset[nid1].id,4);
                        if (fileset[nid1].mode == MODE_FREE)
                        {
                                prnmsg("read_cnfrq(): mode free1 !!\n");
                                memcpy(remote_read_buf[id]+HEADER_LEN+4
                                	,fileset[nid1].id,4);
    	/*Add Ann*/             if(IsManager(fileset[nid1].power)){
                               		write(fileset[nid1].r_fd
                                        	,remote_read_buf[id]
						,remote_data_length[id]);
                                  	buf[HEADER_LEN+4] = STATE_WAITCNF;
    	/*Add Ann*/             }
	/*Add Ann*/            	else{
	/*Add Ann*/                 	buf[HEADER_LEN+4] = STATE_NOPV;
	/*Add Ann*/             }
                        }
                        else
                        {
                                prnmsg("read_cnfrq(): mode lock1 !!\n");
                                buf[HEADER_LEN+4] = STATE_BUSY;
                        }
                }
		else
                {
                        if (nid2 >= 0)
			{
				memcpy(buf+HEADER_LEN,fileset[nid2].id,4);
                                if (fileset[nid2].mode == MODE_FREE)
                                {
                                        prnmsg("read_cnfrq(): mode free2 !!\n");
                                        memcpy(remote_read_buf[id]+HEADER_LEN+4
                                        	,fileset[nid2].id,4);
	/*Add Ann*/			if(IsManager(fileset[nid2].power)){
                                       		write(fileset[nid2].r_fd
                                                	,remote_read_buf[id]
							,remote_data_length[id]);
                                           	buf[HEADER_LEN+4] = STATE_WAITCNF;
	/*Add Ann*/	                }
	/*Add Ann*/                 	else{
        /*Add Ann*/                   		buf[HEADER_LEN+4] = STATE_NOPV;
        /*Add Ann*/                 	}
                                }
                                else
                                {
                                        prnmsg("read_cnfrq(): mode lock2 !!\n");
                                        buf[HEADER_LEN+4] = STATE_BUSY;
                                }
                        }
		}
		}
                prnmsg("read_cnfrq(): search mid == NULL end !!\n");
        }

	write(fileset[id].r_fd,buf,DAEMON_ACKLEN);
	prnmsg("read_cnfrq(): end !!\n");
        return (SUCCESS);
}

int     read_broad(id)
int     id;
{
        int     i;

	prnmsg("read_broad(): begin !!\n");
        for (i=0;i<MAXFD;i++)
        {
		if (fileset[i].r_fd > 0)
			write(fileset[i].r_fd,remote_read_buf[i]
				,remote_data_length[i]);
	}

	prnmsg("read_broad(): end !!\n");
	return (SUCCESS);
}

int     read_token(id)
int     id;
{
        prnmsg("read_token(): begin !!\n");

        fileset[id].mode = remote_read_buf[id][HEADER_LEN];

	prnmsg("read_token(): end !!\n");
	return (SUCCESS);
}

int     read_cnfack(id)
int     id;
{
        char    tid[5];
        int     i;
        char    buf[256];

        prnmsg("read_cnfack(): begin !!\n");
	memset(tid,0,sizeof(tid));
	memcpy(tid,remote_read_buf[id]+HEADER_LEN,4);
	sprintf(buf,"read_cnfack(): tid:[%s] !!\n",tid);
	prnmsg(buf);
	for (i=0;i<MAXFD;i++)
	{
		if (strcmp(fileset[i].id,tid) == 0)
		{
			prnmsg("read_cnfack(): find tid !!\n");
                        write(fileset[i].r_fd,remote_read_buf[id]
                                ,remote_data_length[id]);
			break;
		 }
	}

	prnmsg("read_cnfack(): end !!\n");
	return (SUCCESS);
}

int	read_lu0con(id)
int	id;
{
	char	buf[256];

	prnmsg("read_lu0con(): begin !!\n");

	if (fileset[id].type == TYPE_LU0)
	{
		memcpy(fileset[id].bcode,remote_read_buf[id]+HEADER_LEN,3);
		memcpy(fileset[id].tcode,remote_read_buf[id]+HEADER_LEN+3,2);
		sprintf(buf,"read_lu0con(): bcode:[%s] tcode:[%s]\n",fileset[id].bcode
			,fileset[id].tcode);
		prnmsg(buf);
	}
	else
		prnmsg("read_lu0con(): type error !!\n");

	prnmsg("read_lu0con(): end !!\n");
	return (SUCCESS);
}

int	read_signoff(id)
int	id;
{
	int	i;

	prnmsg("read_signoff(): begin !!\n");

	for (i=0;i<MAXFD;i++)
	{
		if (i != id && fileset[i].type == TYPE_LU0
		&& strcmp(fileset[i].bcode,fileset[id].bcode) == 0
		&& strcmp(fileset[i].tcode,fileset[id].tcode) == 0)
		{
			prnmsg("read_signoff(): find dcxdaemon logoff !!\n");
			write(fileset[i].r_fd,"1",1);
		}
	}

	prnmsg("read_signoff(): end !!\n");

	return (SUCCESS);
}

int     prnmsg(msg)
char    *msg;
{
	if (show_flag != 0)
		fprintf(stderr,"%s",msg);
}
/****/
IsManager(c)
char c;
{
  char buf[80];

  sprintf(buf,"IsManager? [%d]\n",c);
  prnmsg(buf);
  if( (c == '3')||(c == '4')||(c == '5')) return(1);
  return(0);
}
