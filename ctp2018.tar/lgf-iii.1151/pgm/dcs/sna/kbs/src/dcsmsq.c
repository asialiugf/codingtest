

/* -------------------- INCLUDE FILES DECLARATION ------------------- */
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <fcntl.h>

#include "errlog.h"
#include "msgqop.h"

/* ------------------------------------------------------------------ */
/* dcsqtool.c */
#define P_DspQuInfo 		50001
#define P_MsqCreat 		50002
#define P_MsqGet 		50003
#define P_MsqInit 		50004
#define P_MsqRead 		50005
#define P_MsqRemove 		50006
#define P_MsqWrite 		50007
#define P_RmTmpFile 		50008


/* ------ CALL FUNCTION & SUBROUTINE PROTOTYPE DECLARATIONS --------- */
  
int MsqCreat(int *iQuId,int iQuSize,int iQuKey);
int MsqInit(int iQuId,long lQuType);
int MsqGet(int *iQuId,int iQuKey);
int MsqWrite(int iQuId,int iQuSize,struct MsgBuf *pstMsgBuf,
              int iIpcFlag,char *file_pre);
int MsqRead(int iQuId,long lQuType,int *iMaxLen,struct MsgBuf *pstMsgBuf,
             int iIpcFlag);
int MsqRemove(int iQuId);


int
MsqCreat(int *iQuId,int iQuSize,int iQuKey)
{
  int iRc;
  struct msqid_ds stMsqIdBuf;

  UCP_TRACE(P_MsqCreat);

  *iQuId = msgget((key_t)iQuKey, IPC_CREAT);
  if(*iQuId == -1) {
    sprintf(g_caMsg,"MsqCreat:creat q fail errno=%d",errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(MSGQ_ERROR);
  }

  stMsqIdBuf.msg_perm.mode = 000660;
  stMsqIdBuf.msg_perm.uid=getuid();
  stMsqIdBuf.msg_perm.cuid=getuid();
  stMsqIdBuf.msg_perm.gid=getgid();
  stMsqIdBuf.msg_qbytes = iQuSize; 
  iRc = msgctl((int) *iQuId, IPC_SET, &stMsqIdBuf);
  if(iRc == -1) {
    sprintf(g_caMsg,"MsqCreat:msgctl IPC_SET  errno= %d", errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(MSGQ_ERROR);
  } 
  UCP_TRACE_END(MSGQ_NORMAL);
}


int
MsqInit(int iQuId,long lQuType)
{
  int iRc;
  struct MsgBuf stMsgBuf;
  struct MsgqHead stMsgqHead;
  char   caMsgFileName[80];

  UCP_TRACE(P_MsqInit);

  errno=0;
  /*  clear MSGQ messages with key = msg_typ avoid reused old mesgs  */
  while((iRc = msgrcv(iQuId,&stMsgBuf,MSGQ_MAX_LEN,lQuType,IPC_NOWAIT)) > 0){ 
    /* for queue overflow management */
    memcpy(&stMsgqHead,stMsgBuf.caText,sizeof(stMsgqHead));
    if((stMsgqHead.caFileName[0] != '\0') && 
       (memcmp(stMsgqHead.caFileName,"             ",MSGQ_TMP_FNAME_LEN) != 0)){
      memcpy(caMsgFileName,stMsgqHead.caFileName,9);
      caMsgFileName[9] = '\0';
      Ge2RmTmpFile(caMsgFileName);
    }
  }

  if(errno == ENOMSG){
    UCP_TRACE_END(MSGQ_EOF_ERROR);
  }
  else{
    if (errno != 0) {
      sprintf(g_caMsg,"MsqInit:msgrcv fail errno=%d",errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(MSGQ_ERROR);
    }
  }

  UCP_TRACE_END(MSGQ_NORMAL);
}


int
MsqGet(int *iQuId,int iQuKey)
{
  UCP_TRACE(P_MsqGet);

  /* get the q-id */
  *iQuId=msgget(iQuKey,0);
  if((int) *iQuId == -1 ) {
    sprintf(g_caMsg,"MsqGet:msgget fail errno = %d\n",errno);    
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(MSGQ_ERROR);
  }
  UCP_TRACE_END(MSGQ_NORMAL);
} 
  

int
MsqWrite(int iQuId,int iQuSize,struct MsgBuf *pstMsgBuf,
          int iIpcFlag,char *file_pre)
{ 
  int iRc;
  int iOverflow;
  int iMsgFd;
  int iErrCount=0;
  static int iMsgFnameSeq=0;
  struct MsgqHead stMsgqHead;
  char caMsgFileName[80];
  char caTmpFname[80];

  UCP_TRACE(P_MsqWrite);

  /* reset tmp f_name */
  if((iIpcFlag != IPC_NOWAIT) && (iIpcFlag != 0)) {
    sprintf(g_caMsg,"MsqWrite:flag=%d error",iIpcFlag);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(MSGQ_ERROR);
  }

  /* reach the threshold of the Q */
  if(Ge2DspQuInfo(iQuId,0,iQuSize) == -1){
    iOverflow = 1;
  }
  else {
    iRc = msgsnd(iQuId,pstMsgBuf,iQuSize,iIpcFlag);

    if(iRc == -1 ){
      /* queue is overflow */
      if(errno == EAGAIN)
        iOverflow = 1;
      else{
        sprintf(g_caMsg,"MsqWrite:msgsnd errno=%d Qid=%d Qtyp=%d Qsize=%d",
                errno,iQuId,pstMsgBuf->lType,iQuSize);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        Ge2DspQuInfo(iQuId,1,iQuSize);
        UCP_TRACE_END(MSGQ_ERROR);
      }
    }
    else {
      iOverflow = 0;
    }
  }

  if(iOverflow == 1){
    /*if sequential no. reaches the upper bound, reset it */
#ifdef OLD_GET_FILENAME
    if((++iMsgFnameSeq) == 99999){
      iMsgFnameSeq=0;
    }
    sprintf(caMsgFileName,"%s%d",file_pre,iMsgFnameSeq);
#else
    memset(caMsgFileName, '\0', sizeof(caMsgFileName));
    tmpnam(caTmpFname);
    sprintf(g_caMsg,"Q. overflowed tmpnam(tmp_fname)=%s",caTmpFname);
    ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);  /* for debugging */
    /* bypass P_tmpdir=/var/tmp/ define in stdio.h */
    strcpy(caMsgFileName,caTmpFname+strlen(P_tmpdir));
    caMsgFileName[9] = '\0';
#endif
    /* for debugging */
    sprintf(g_caMsg,"MsqWrite:Q overflow TmpFileName=%s",caMsgFileName);
    ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

    while((iMsgFd = open(caMsgFileName,O_WRONLY|O_EXCL|O_CREAT,0660)) < 0){
      /* opening an in-used temporary file, try next */
      /* seqential  no. reaches the upper bound, reset it. */
#ifdef OLD_GET_FILENAME
      if((++iMsgFnameSeq) == 99999){
        iMsgFnameSeq=0;
      }
      sprintf(caMsgFileName,"%s%d",file_pre,iMsgFnameSeq);
      if((++iErrCount) == 99999){
        ErrLog(1000,"MsqWrite:Msg Temp file open fail !!",RPT_TO_LOG,0,0);
        UCP_TRACE_END(MSGQ_ERROR);
      }
#endif
    }

    iRc = write(iMsgFd,pstMsgBuf->caText+sizeof(stMsgqHead),
                iQuSize-sizeof(stMsgqHead));
    if(iRc < iQuSize-sizeof(stMsgqHead)){
      close(iMsgFd);
      sprintf(g_caMsg,"MsqWrite:write MsgFile fail,errno=%d",errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(MSGQ_ERROR);
    } 
    close(iMsgFd);  /* close temporary file if write succefully */
    memcpy(stMsgqHead.caFileName,caMsgFileName,9);
    memcpy(pstMsgBuf->caText,&stMsgqHead,sizeof(stMsgqHead));
    iRc = msgsnd(iQuId,pstMsgBuf,sizeof(stMsgqHead),iIpcFlag);
    if(iRc == -1){
      Ge2RmTmpFile(caMsgFileName);
      sprintf(g_caMsg,"MsqWrite:ctl msg send errno=%d Qid=%d Qtyp=%d Qsize=%d",
              errno,iQuId,pstMsgBuf->lType,iQuSize);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      Ge2DspQuInfo(iQuId,1,iQuSize);
      UCP_TRACE_END(MSGQ_ERROR);
    }
  } /* end of (iOverflow == 1) */

  UCP_TRACE_END(MSGQ_NORMAL);
}

/**************************************************************************/
/* iIpcFlag:IPC_NOWAIT -> read queue in non-block mode                    */
/* iIpcFlag:0 -> read queue in block mode and will ignore time out signal */
/* iIpcFlag:2 -> read queue in block mode and will be interrupted by the  */
/*               time out signal                                          */
/**************************************************************************/

int
MsqRead(int iQuId,long lQuType,int *iMaxLen,struct MsgBuf *pstMsgBuf,
         int iIpcFlag)
{
  int iRc;
  int iMsgFd;
  int iMsgLen;  /* for debugging only */
  int iQuMaxLen;
  struct MsgqHead stMsgqHead;
  char caMsgFileName[80];

  UCP_TRACE(P_MsqRead);

  if((iIpcFlag != IPC_NOWAIT) && (iIpcFlag != 0) && (iIpcFlag != 2) ) {
    sprintf(g_caMsg,"MsqRead:flag=%d error",iIpcFlag);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(MSGQ_ERROR);
  }

  iQuMaxLen = *iMaxLen;
  for (;;)
      {
       errno = 0 ;
       iMsgLen = msgrcv(iQuId,pstMsgBuf,iQuMaxLen,lQuType,iIpcFlag);
/*
       printf("MSQLEN len %d errno [%d]\n", iMsgLen,errno );
       if(iMsgLen == -1 && errno ==  EINTR )
          continue ; 
*/
       if ( errno == EINVAL )
          break; 
       if ( iMsgLen > 0 )
          break ;
       if ( errno == EINTR && iIpcFlag == 2 )
          break; 
      }
  if(iMsgLen == -1){
    if(errno == ENOMSG){
      ErrLog(10,"MsqRead:No more msg",RPT_TO_LOG,0,0);
      UCP_TRACE_END(MSGQ_EOF_ERROR);
    }
    else {
      sprintf(g_caMsg,"MsqRead:msgrcv fail errno=%d",errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);

      if(errno != E2BIG){ 
        UCP_TRACE_END(MSGQ_ERROR);
      }
      else {
        iIpcFlag &= MSG_NOERROR;
        iQuMaxLen = *iMaxLen;
        iMsgLen = msgrcv(iQuId,pstMsgBuf,iQuMaxLen,lQuType,iIpcFlag);
        if(iMsgLen == -1) {
          sprintf(g_caMsg,"MsqWrite:msgrcv retry fail errno=%d",errno);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          UCP_TRACE_END(MSGQ_ERROR);
        }
        else {
          sprintf(g_caMsg,"MsqWrite:Rcv Truncated Msg! MaxLen=%d",iMaxLen);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          UCP_TRACE_END(MSGQ_TRUN_ERROR);
        }
      }  /* for if (errno != E2BIG) */
    }  /* for if (errno == ENOMSG) */
  }

  if(iMsgLen >0) {
    *iMaxLen = iMsgLen;
    UCP_TRACE_END(MSGQ_NORMAL);
  }
  else {
    /* the content of the message is in the file */
    sprintf(g_caMsg,"MsqRead:Data in file:%.9s",stMsgqHead.caFileName);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    memcpy(caMsgFileName, stMsgqHead.caFileName, 9);
    caMsgFileName[9] = '\0';
    iMsgFd = open(caMsgFileName,O_RDONLY);
    if(iMsgFd < 0) {
      sprintf(g_caMsg,"MsqWrite:open %s fail,errno=%d", caMsgFileName,errno);
    printf("MSGRCV 3333\n");
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(MSGQ_ERROR);
    }
    iRc = read(iMsgFd,pstMsgBuf->caText+sizeof(stMsgqHead),*iMaxLen);
    if(iRc <= 0 ){
      close(iMsgFd);
    printf("MSGRCV 4444\n");
      sprintf(g_caMsg,"MsqRead:Read %s fail,errno=%d", caMsgFileName,errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(MSGQ_ERROR);
    }
    *iMaxLen = iRc + sizeof(stMsgqHead);
    close(iMsgFd);
    Ge2RmTmpFile(caMsgFileName);
    UCP_TRACE_END(MSGQ_NORMAL);
  }
}



int
MsqRemove(int iQuId)
{
  int iRc;

  UCP_TRACE(P_MsqRemove);
  iRc = msgctl(iQuId, IPC_RMID, 0);
  if(iRc == -1){
    sprintf(g_caMsg,"MsqRemove:remove Q errno=%d",errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(MSGQ_ERROR);
  }
  UCP_TRACE_END(MSGQ_NORMAL);
}


/*
 *&N& ROUTINE NAME:
 *&A& ARGUMENTS:
 *&A&   NAME            TYPE                 DESCRIPTION
 *&A& --------------- ----------------    -------------------------
 *&A& 
 *&A& 
 *&R& RETURN VALUE(S):
 *&R&
 *&R&
 *&D& DESCRIPTION:
 *&D&   Modify by Dao-Ming  81/06/25
 *&D&   DspQuInfo(iQid,iDisp) 
 *&D&   DspQuInfo(iQid,iDisp,iDataSize)
 *&D&   iWaterLev=((((stMsqIdBuf.msg_cbytes*1000)/stMsqIdBuf.msg_qbytes)+5/10)
 *&D&   iWaterLev=((((stMsqIdBuf.msg_cbytes+iDataSize)*1000)/
 *&D&                 stMsqIdBuf.msg_qbytes)+5/10);
 */

int
Ge2DspQuInfo(int iQid,int iDisp,int iDataSize)
{
  int iWaterLev;
  struct msqid_ds stMsqIdBuf;

  msgctl(iQid,IPC_STAT,&stMsqIdBuf);

  /*if iDisp flag is 1 then show Q. information to log file*/
  if(iDisp == 1){
    sprintf(g_caMsg,"number of byte on queue:%d",stMsqIdBuf.msg_cbytes);
    ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
    sprintf(g_caMsg,"number of message on queue:%d",stMsqIdBuf.msg_qnum);
    ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
    sprintf(g_caMsg,"max. number of bytes allowed on queue:%d",
            stMsqIdBuf.msg_qbytes);
    ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
    sprintf(g_caMsg,"last process perform msgsnd:%d",stMsqIdBuf.msg_lspid);
    ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
    sprintf(g_caMsg,"last process perform msgrcv:%d",stMsqIdBuf.msg_lrpid);
    ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
  }

  /* check if the occupied space in the queue reach the threshold */
  iWaterLev=((((stMsqIdBuf.msg_cbytes+iDataSize)*1000)/
                stMsqIdBuf.msg_qbytes+5)/10);
  if(iWaterLev >= MSGQ_THRESHOLD) {
    sprintf(g_caMsg,"Q-id:%d  water-level=%d",iQid,iWaterLev);
    ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
    return(-1);
  }
  else{
    return(0);
  }
}


/*
 *&N& ROUTINE NAME:
 *&A& ARGUMENTS:
 *&A&   NAME            TYPE                 DESCRIPTION
 *&A& --------------- ----------------    -------------------------
 *&A& 
 *&A& 
 *&R& RETURN VALUE(S):
 *&R&
 *&R&
 *&D& DESCRIPTION:
 *&D&
 *&D&
 */

int 
Ge2RmTmpFile(char *pcTmpFile)
{
  int  iRc;
  iRc = unlink(pcTmpFile);
  return(iRc);
}
