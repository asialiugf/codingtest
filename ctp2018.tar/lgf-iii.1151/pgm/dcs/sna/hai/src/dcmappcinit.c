/* FUNCTION & SUBROUTINE DESCRIPTION
 *&N&   TYPE      NAME                     DESCRIPTION
 *&N&-------- -------------  ----------------------------------------------
 *&N& int     DcsCreat()
 *&N& int     GetFileData()
*/

/* ---------------- INCLUDE FILES DECLARATION ------------------------ */
#include <errno.h>
#include <stdio.h>
#include "errlog.h"
#include "dcs.h"

#define MAX_DATA_LEN	256
#define MAX_ITEM_LEN    80     /* MAX. ITEM LENGHT in the rmtprocnum */

/* ------------- the routine id of the dcmappcinit.c ----------------- */
#define P_DcsCreat	67002
#define P_GetFileData	67004

/* -------------------- STATIC GLOBAL DECLARATION ------------------- */
static int sg_iaQuId[MAX_NETWKTBL_ARRAY];	/* keep QuId array */
static int sg_iMaxQuId;				/* max creat queue */

int gs_iQueKey;
 
int DcsCreat();
/**********************************************************************
 *&N& ROUTINE NAME:main()
 *&A& ARGUMENTS:NONE
 *&R& RETURN VALUE(S):NONE
 *&D& DESCRIPTION:
 *&D&             This main program will be invoked by the EMS when the 
 *&D&             TPE is starting up.
 *&D&             It will prepare the environment for the dcxdaemon.x
 *&D&             and fork the dcxdaemon.x
 *&D&             1. Create the queue according the speification of the
 *&D&                "rmtquetbl"
 *&D&             2. Fork the dcxdaemon.x processes according to the
 *&D&                specification of the "rmtprocnum".
 *&D&             3. The parameneters of the dcxdaemon.x are BRCODE and 
 *&D&                TERMINAL CODE.(depends on the dcxdaemon.x)
 *&D&             4. Use the last 4 digits of the BRCODE as the 1st argument
 *&D&                of the dcxdaemon.x
 *&D&             5. modification note 950707
 *&D&                the layout of the rmtprocnum is modified as follows: 
 *&D&                BRCODE NUMBER-OF-dcxdaemon LUPROFILE-PREFIX 
 **********************************************************************/
main(int iArgc,char *paArgv[])
{
    int iRc;
    char caLogName[256];
    FILE  *zFp;
    char  caFileName[80];
    char  caProcNum[MAX_ITEM_LEN];  
    char  caBrId[MAX_ITEM_LEN];
    char  caPrefix[MAX_ITEM_LEN];
    char  caCmd[50];
    int i,j,iProcNum;


    sprintf(caLogName, "%s/iii/log/tms_errlog", getenv("III_DIR") );
/*
    ChgLog(LOG_CHG_MODE,"1");
*/
    ChgLog(LOG_CHG_LOG,caLogName);

    /* create the QUEUE for the communication between the dcxdaemon.x */
    /* and the tpu.x                                                  */

    iRc = DcsCreat();
    if(iRc != 0){
      sprintf(g_caMsg,"dcxappcinit.x:DcsCreat error iRc=%d",iRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      exit(-1);
    }

    strcpy((char *)caFileName, (char *)getenv("III_DIR"));
    strcat(caFileName, DCS_TABLE_PATH);
    strcat(caFileName,"rmtprocnum");

    /* according to the specification of the "rmtprocnum" to fork the */
    /* dcxdaemon.x                                                    */ 
    if((zFp = fopen(caFileName,"r")) == (FILE *) 0) { 
      sprintf(g_caMsg,"dcxappcinit.x:open rmtprocnum fail errno=%d",errno);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      exit(-2);
      UCP_TRACE_END(DCS_ES_OPENTBLFILE);
    }

    memset(caBrId,0x00,MAX_ITEM_LEN);
    memset(caProcNum,0x00,MAX_ITEM_LEN);
    memset(caPrefix,0x00,MAX_ITEM_LEN);


    while( fscanf(zFp,"%s %s %s",caBrId,caProcNum,caPrefix) 
           != (int) EOF ) {
      if (strlen(caProcNum) > 3) {
        sprintf(g_caMsg,
                "no(%s) of dcxdaemon.x defined in the rmtprocnum too large",
                caProcNum);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        exit(-3);
      }  
      if (strlen(caBrId) > 10) {
        sprintf(g_caMsg,"BrCode(%s) defined in the rmtprocnum too long",
                caBrId);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        exit(-3);
      }  
      iProcNum = atoi(caProcNum); /*number of the dcxdaemon.x to be forked*/
      /* use the last 4 digits of the Branch Code as the 1st argument of */
      /* the dcxdaemon.x                                                 */
      j=(strlen(caBrId)<=4)?0:(strlen(caBrId)-4);
      for (i=1;i<=iProcNum;i++) {
        sprintf(caProcNum,"%.2d",i);
        sprintf(caCmd, "dcxdaemon.x %s %s %s &",&caBrId[j],caProcNum,
                caPrefix);
/*
        printf("caCmd---%s---\n",caCmd); 
*/
        system(caCmd);
      }
      memset(caBrId,0x00,MAX_ITEM_LEN);
      memset(caProcNum,0x00,MAX_ITEM_LEN);
      memset(caPrefix,0x00,MAX_ITEM_LEN);
    }  /* for while */
    fclose( zFp );
    exit(0);
}


/**********************************************************************
 *&N& ROUTINE NAME:DcsCreat
 *&A& ARGUMENTS:NONE
 *&R& RETURN VALUE(S):NONE
 *&D& DESCRIPTION:Create the queue for communication of the dcxdaemon.x
 *&D&             and tpu.x. It will read the "rmtquetbl" to create the 
 *&D&             queue 
 **********************************************************************/
int
DcsCreat()
{
  int i, iRc=0;
  char caFileName[80];
  char *pcFoundFlg;
  /* for get data */
  char caDataType[5];
  long *plDataVar[5];
  /* input data variable for queuetbl */
  char caDesCode[20];
  int iQuFlag;
  long lQuSize;
  long lQuType;
  int iQuId;
  int iLastQuKey;	/* keep last queue key */
  FILE *pfQueFile;

  UCP_TRACE(P_DcsCreat);
  ErrLog(100,"DcsCreat Begin.",RPT_TO_LOG,0,0);
 
  /* 
     create the queue for the communication between dcxdaemon.x and
     tpu.x 
  */
  /* get path name */
  strcpy((char *)caFileName, (char *)getenv("III_DIR"));
  strcat(caFileName, DCS_TABLE_PATH);
  strcat(caFileName,"rmtquetbl");

  /* open file queue table */
  pfQueFile = fopen(caFileName,"rt");

  if( pfQueFile == NULL) {
    sprintf(g_caMsg,"DcsCreat:fopen %s fail errno=%d",caFileName,errno);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(DCS_E_NETWORKTBL);
  }

  strcpy(caDataType,"sdD");
  plDataVar[0] = (long *)caDesCode;
  plDataVar[1] = &gs_iQueKey;
  plDataVar[2] = &lQuType;

  i = 0;
  sg_iMaxQuId = 0;
  iLastQuKey = -1;	/* initial iLastQuKey */ 
  lQuSize = -1;	/* initial iQuSize = 0 */
  while((iRc = GetFileData(pfQueFile,3,caDataType,plDataVar)) == 0){

    /* first record is queue size data */
    if(lQuSize < 0){
      iRc = strncmp(caDesCode,"QUEUE_SIZE",10);
      if(iRc == 0){
        lQuSize = lQuType;
      }
      else{	/* no queue size data error */
        fclose(pfQueFile);
        ErrLog(1000,"DcsCreat: Queue Size no define error!",RPT_TO_LOG,0,0);
        UCP_TRACE_END(DCS_E_NETWORKTBL);
      } /* end of if(iRc == 0) -- else */
    }
    else{
      if((lQuSize > 0) && ((gs_iQueKey != iLastQuKey) ||
         (iLastQuKey == -1))) {
        iRc = MsqCreat(&iQuId,lQuSize,gs_iQueKey);
        if(iRc != 0) {   /* creat queue error */
          UCP_TRACE_END(DCS_E_LOCALDCS);
        } /* end of if(iRc != 0) */
        iLastQuKey = gs_iQueKey;
      } /* end of if((lQuSize > 0) && ((gs_iQueKey != iLastQuKey) ||
                     (iLastQuKey == -1))) */
    } /* end of if(lQuSize < 0) -- else */ 
  } /* end of while((iRc = GetFileData(3,caDataType,plDataVar)) == 0) */

  fclose(pfQueFile);
  ErrLog(100,"DcsCreat End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}

int
GetFileData(FILE *pfFile, int iDataNo,char caDataType[], long* plDataVar[])
{
  int i;
  long lOffset;
  char caDataBuf[MAX_DATA_LEN];
  char cBypass,cDummy;

  UCP_TRACE(P_GetFileData);

  do {
    if(feof(pfFile)){
      UCP_TRACE_END(-1);
    }

    fgets(caDataBuf,MAX_DATA_LEN,pfFile);
    if (caDataBuf[0] != '#') {
      lOffset = (long) strlen(caDataBuf) * -1;
      fseek(pfFile,lOffset,SEEK_CUR);

      for(i=0; i < iDataNo ; i++){

        fscanf(pfFile,"%c",&cBypass);
        if( cBypass != '*') {

          fseek(pfFile,-1,SEEK_CUR);
          switch(caDataType[i]){
            case 't' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%d\n",(short *) plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%d ",(short *) plDataVar[i]);
              }
              break;
            case 'd' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%d\n",(int *) plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%d ",(int *) plDataVar[i]);
              }
              break;
            case 'D' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%ld\n",(long *) plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%ld ",(long *) plDataVar[i]);
              }
              break;
            case 'o' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%o\n",(int *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%o ",(int *)plDataVar[i]);
              }
              break;
            case 'O' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%lo\n",(long *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%lo ",(long *)plDataVar[i]);
              }
              break;
            case 'x' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%x\n",(int *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%x ",(int *)plDataVar[i]);
              }
              break;
            case 'X' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%lx\n",(long *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%lx ",(long *)plDataVar[i]);
              }
              break;
            case 'i' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%i\n",(int *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%i ",(int *)plDataVar[i]);
              }
              break;
            case 'I' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%li\n",(long *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%li ",(long *)plDataVar[i]);
              }
              break;
            case 's' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%s\n",(char *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%s ",(char *)plDataVar[i]);
              }
              break;
            case 'c' :
              if(i == (iDataNo-1)) {
                fscanf(pfFile,"%c\n",(char *)plDataVar[i]);
              }
              else {
                fscanf(pfFile,"%c ",(char *)plDataVar[i]);
              }
              break;
            default :
              sprintf(g_caMsg,"GetFileData: data-type=%c error",caDataType[i]);
              ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
              UCP_TRACE_END(-2);
          }  /* end switch */
        }
        else {
          if( (i == iDataNo-1) && (cDummy == '\n') ) {
            fscanf(pfFile,"\n");
            UCP_TRACE_END(0);
          }
          else fscanf(pfFile," ");
        } /* end if '*' */
      }  /* end for */
    }  /* end if  '#' */
  } while(caDataBuf[0] == '#');

  UCP_TRACE_END(0);
}
