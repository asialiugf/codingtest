#include <cmc.h>		/* CPI-C external definitions		*/
#include <errno.h>		/* global error numbers			*/
#include <fcntl.h>		/* for using file permissions		*/
#include <signal.h>		/* for using signal handler		*/
#include <stdio.h>		/* for using printf command		*/
#include <string.h>		/* for using strcpy, strcat commands    */
#include <malloc.h>		/* for using malloc command		*/
#include <sys/types.h>
#include <sys/signal.h>
#include "errlog.h"
#include "dcs.h"

#define MAX_LISTEN 5
#define MAX_NETWKTBL_ARRAY 30

#define SYMMAX		9		/* maxlen of sym dest name +1  */
#define FILEMAX		80		/* arbitrary max file name len */
#define BUFFERLEN	80		/* arbitrary max data rcv len  */
#define CONV_ID_LEN	8		/* length of conv id area      */
#define SENDMAX		32000		/* max # of bytes to send      */
#define TPE_BR_ID       10
#define TPE_TERM_ID     20


struct Lu62Sess {
  unsigned char ucaConverId[CONV_ID_LEN];
  char cStatus;
  char cMode;
};

#define P_DcsLUAccept 		52001
#define P_DcsLUConnect 		52002
#define P_DcsLUDisconnect 	52003
#define P_DcsLUInitial 		52004
#define P_DcsLUNull   		52005
#define P_DcsLUReceive 		52006
#define P_DcsLUSend   		52007
#define P_DcsLUTerminate 	52008
#define P_DcsLU       		52009

/* -------------------- STATIC GLOBAL DECLARATION ------------------- */
static int gs_iFirst=1;            /* first flage 1=yes 0=no          */
static int gs_iMaxLoad;

struct Lu62Sess g_stLu62SesTbl[MAX_SESS];

static  char gs_caLuProfileName[SYMMAX];	/* symbolic name*/

/* ------ CALL FUNCTION & SUBROUTINE PROTOTYPE DECLARATIONS --------- */
int DcsLU(struct DcsBuf *pstDcsBuf, char *pcPrefix);
int DcsLUInitial(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess,
                   char cMode);
int DcsLUConnect(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess);
int DcsLUAccept(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess);
int DcsLUSend(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess);
int DcsLUReceive(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess);
int DcsLUDisconnect(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess);
int DcsLUTerminate(struct DcsBuf *pstDcsBuf);
void DcsLUNull();

CM_PREPARE_TO_RECEIVE_TYPE     	g_lPrepareType;	/* prep to receive type	*/
CM_RECEIVE_TYPE		        g_lReceiveType;	/* receive type 	*/
CM_REQUEST_TO_SEND_RECEIVED     g_lReqToSend;	/* req to send indicator*/
CM_SYNC_LEVEL			g_lSyncLevel;	/* sync level for conv  */
CM_SEND_TYPE			g_lSendType;	/* send type		*/
CM_INT32			g_lLength;	/* data length          */
CM_INT32			g_lReceivedLength;/* how much data rcvd   */
CM_STATUS_RECEIVED		g_lStatusReceived;/* status from remote   */
CM_DATA_RECEIVED_TYPE		g_lDataReceived;  /* was of data rcvd?   */
CM_DEALLOCATE_TYPE		g_lDeallocateType;/* type of deallocate   */

CM_INT32                        g_lSecurType;
CM_INT32                        g_lSecurPasswdLen;
CM_INT32                        g_lSecurUseridLen;

unsigned char *                 g_ucaSecurUserid[5];
unsigned char *                 g_ucaSecurPasswd[5];
unsigned char *                 g_ucaTpName[20];

CM_INT32                        g_lTpNameLen;

static  unsigned char		g_ucaConverId[CONV_ID_LEN];
static  char gs_caTermId[5];
static  char gs_caBrId[5];
static  char gs_caTermIdAscii[5];
static  char gs_caBrIdAscii[5];
static  int gs_iTermId;
static  int gs_iBrId;
int g_iTmFlag = 1;

int
DcsLU(struct DcsBuf *pstDcsBuf, char *pcPrefix)
{
  int iRc;
  struct Lu62Sess *pstSess;

  UCP_TRACE(P_DcsLU);

  g_lStatusReceived = CM_NO_STATUS_RECEIVED;
  g_lDataReceived = CM_NO_DATA_RECEIVED;
  g_lReqToSend = CM_REQ_TO_SEND_NOT_RECEIVED;

  pstSess = g_stLu62SesTbl;
  iRc = 0;
  switch (PcRqstCode(pstDcsBuf)){
   case DCSINITIAL:
     if(gs_iFirst){
       strcpy(gs_caLuProfileName,pcPrefix); /* set profile prefix in 1st time */
       iRc = DcsLUInitial(pstDcsBuf,pstSess,'A');
       if(iRc != DCS_NORMAL){
         break;
       }
       gs_iFirst = 0;
     }
     break;

   case DCSCONNECT:
     /* do DcsLUInitial when FIRST */
     if(gs_iFirst){
       strcpy(gs_caLuProfileName,pcPrefix); /* set profile prefix in 1st time */
       iRc = DcsLUInitial(pstDcsBuf,pstSess,'A');
       if(iRc != DCS_NORMAL){
         break;
       }
       gs_iFirst = 0;
     }
     iRc = DcsLUConnect(pstDcsBuf,pstSess);
     break;

   case DCSACCEPT:
     /* do DcsLUInitial when FIRST */
     if(gs_iFirst){
       strcpy(gs_caLuProfileName,pcPrefix); /* set profile prefix in 1st time */
       iRc = DcsLUInitial(pstDcsBuf,pstSess,'P');
       if(iRc != DCS_NORMAL){
         break;
       }
       gs_iFirst = 0;
     }
     iRc = DcsLUAccept(pstDcsBuf,pstSess);
     break;

   case DCSCONNECTWRITE:
     /* do DcsLUInitial when FIRST */

     if(gs_iFirst){
       strcpy(gs_caLuProfileName,pcPrefix); /* set profile prefix in 1st time */
       gs_iFirst = 0;
     }

     iRc = DcsLUInitial(pstDcsBuf,pstSess,'A');
     if(iRc != DCS_NORMAL){
       break;
     }

     iRc = DcsLUConnect(pstDcsBuf,pstSess);
     if(iRc != DCS_NORMAL){
       break;
     }

     iRc = DcsLUSend(pstDcsBuf,pstSess);
     break;

   case DCSWRITE:
     iRc = DcsLUSend(pstDcsBuf,pstSess);
     break;

   case DCSWRDISCONECT:
     iRc = DcsLUSend(pstDcsBuf,pstSess);
     if(iRc == DCS_NORMAL){
       iRc = DcsLUDisconnect(pstDcsBuf,pstSess);
     }
     break;

   case DCSACCEPTREAD:
     /* do DcsLUInitial when FIRST */
     if(gs_iFirst){
       strcpy(gs_caLuProfileName,pcPrefix); /* set profile prefix in 1st time */
       iRc = DcsLUInitial(pstDcsBuf,pstSess,'P');
       if(iRc != DCS_NORMAL){
         break;
       }
       gs_iFirst = 0;
     }
     iRc = DcsLUAccept(pstDcsBuf,pstSess);
     if(iRc != DCS_NORMAL){
       break;
     }
     iRc = DcsLUReceive(pstDcsBuf,pstSess);
     break;

   case DCSREAD:
     iRc = DcsLUReceive(pstDcsBuf,pstSess);
     break;

   case DCSDISCONNECT:
     iRc = DcsLUDisconnect(pstDcsBuf,pstSess);
     break;

   case DCSTERMINATE:
     iRc = DcsLUTerminate(pstDcsBuf);
     break;

   default:
     sprintf(g_caMsg,"DcsLU:reguest error[%c]",PcRqstCode(pstDcsBuf));
     ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
     iRc = DCS_E_COMMAND;
     break;
  } /* end switch */

  PiReply(pstDcsBuf) = iRc;
  UCP_TRACE_END(iRc);
} /* end of sbdbs */


int
DcsLUInitial(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess,char cMode)
{
  CM_RETURN_CODE  iCmRc;      /* ret code from CPI-C  */
  int iIdx;
  int iLu62Id;
  int iRc;

  UCP_TRACE(P_DcsLUInitial);

  for(iIdx=0; iIdx<MAX_SESS; iIdx++){
    memset(&pstSess[iIdx], 0x00 , sizeof(struct Lu62Sess) );
    pstSess[iIdx].cStatus = DCS_S_FREE ;
  }

  memset(g_ucaConverId,0x00,8);

  if(cMode == PASSIVE_MODE) {
    ErrLog(1000,"DcsLUInitial:ok.",RPT_TO_LOG,0,0);
    UCP_TRACE_END(DCS_NORMAL);
  }

  if(g_iTmFlag) {

    memset(gs_caTermId,0x00,TPE_TERM_LEN+1);
    memcpy(gs_caTermId,&(PcaData(pstDcsBuf)[TPE_TERM_ID]),TPE_TERM_LEN);

    memset(gs_caTermIdAscii,0x00,TPE_TERM_LEN+1);
    NLxin( gs_caTermIdAscii, gs_caTermId ,TPE_TERM_LEN+1);
    gs_iTermId = atoi(gs_caTermIdAscii);

    ErrLog(100,"caTermId ",RPT_TO_LOG,gs_caTermIdAscii,TPE_TERM_LEN+1);
    sprintf(g_caMsg,"TERMID = [%d]",(int)gs_iTermId);
    ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

    memset(gs_caBrId,0x00,TPE_BR_LEN+1);
    memcpy(gs_caBrId,&(PcaData(pstDcsBuf)[TPE_BR_ID+3]),TPE_BR_LEN);

    memset(gs_caBrIdAscii,0x00,TPE_BR_LEN+1);
    NLxin( gs_caBrIdAscii, gs_caBrId ,TPE_BR_LEN+1);
    gs_iBrId = atoi(gs_caBrIdAscii);

    ErrLog(100,"caBrId ",RPT_TO_LOG,gs_caBrIdAscii,TPE_BR_LEN+1);
    sprintf(g_caMsg,"BRID = [%d]",(int)gs_iBrId);
    ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

    memcpy(&gs_caLuProfileName[2],gs_caBrIdAscii,TPE_BR_LEN);
    memcpy(&gs_caLuProfileName[6],gs_caTermIdAscii,TPE_TERM_LEN);

    g_iTmFlag = 0;
 }

  sprintf(g_caMsg,"CPIC PROFILE NAME=%s",gs_caLuProfileName);
  ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);

  cminit(g_ucaConverId,
        (unsigned char *)gs_caLuProfileName,
        &iCmRc);

  ErrLog(100,"cminit ucaConverId",RPT_TO_LOG,g_ucaConverId,20);

  if (iCmRc != CM_OK) {
      sprintf(g_caMsg,"DcsSkInitial(cminit):lu62 fail, errno=[%d]",(int)iCmRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
  }

  g_lSyncLevel = CM_NONE;

/*
  g_lSyncLevel = CM_CONFIRM;
*/
  cmssl(g_ucaConverId,
        &g_lSyncLevel,
        &iCmRc);

  if (iCmRc != CM_OK) {
      sprintf(g_caMsg,"DcsSkInitial(cmssl):lu62 fail, errno=[%d]",(int)iCmRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
  }
   
  g_lReceiveType = CM_RECEIVE_AND_WAIT;

  cmsrt(g_ucaConverId,
        &g_lReceiveType,
        &iCmRc);

  if (iCmRc != CM_OK) {
      sprintf(g_caMsg,"DcsSkInitial(cmsrt):lu62 fail, errno=[%d]",(int)iCmRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
  }
 
  g_lPrepareType = CM_PREP_TO_RECEIVE_FLUSH;

  cmsptr(g_ucaConverId,
         &g_lPrepareType,
         &iCmRc);

  if (iCmRc != CM_OK) {
      sprintf(g_caMsg,"DcsSkInitial(cmsptr):lu62 fail, errno=[%d]",(int)iCmRc );
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
  }

  g_lSendType = CM_SEND_AND_PREP_TO_RECEIVE;

  cmsst(g_ucaConverId,
        &g_lSendType,
        &iCmRc);


  if (iCmRc != CM_OK) {
      sprintf(g_caMsg,"DcsLUSend(cmsst):write fail, errno=[%d]",iCmRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstSess[iIdx].cStatus = DCS_S_ERROR;
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iRc);
  }

  g_lSecurType = XC_SECURITY_PROGRAM;

  xcscst(g_ucaConverId,
	 &g_lSecurType,
	 &iCmRc);

  if (iCmRc != CM_OK) {
      sprintf(g_caMsg,"DcsSkInitial(xcscst):lu62 fail, errno=[%d]",(int)iCmRc );
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
  }

  g_lSecurUseridLen = 4;
  strcpy(g_ucaSecurUserid,"LIAN");

  xcscsu(g_ucaConverId,
         g_ucaSecurUserid,
	 &g_lSecurUseridLen,
	 &iCmRc);

  if (iCmRc != CM_OK) {
      sprintf(g_caMsg,"DcsSkInitial(xcscsu):lu62 fail, errno=[%d]",(int)iCmRc );
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
  }

  g_lSecurPasswdLen = 4;
  strcpy(g_ucaSecurPasswd,"LIAN");

  xcscsp(g_ucaConverId,
         g_ucaSecurPasswd,
	 &g_lSecurPasswdLen,
	 &iCmRc);

  if (iCmRc != CM_OK) {
      sprintf(g_caMsg,"DcsSkInitial(xcscsp):lu62 fail, errno=[%d]",(int)iCmRc );
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
  }

  ErrLog(100,"DcsLUInitial:End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}



int
DcsLUConnect(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess)
{
  CM_RETURN_CODE  iCmRc=CM_OK;      /* ret code from CPI-C  */
  int iRc;
  int iIdx;
  int iLu62Id;
  char caCicsName[20];
 
  UCP_TRACE(P_DcsLUConnect);
  ErrLog(10,"DcsLUConnect Begin.",RPT_TO_LOG,0,0);

  /* search a usable dialogue  */
  iIdx = 1;
  while(pstSess[iIdx].cStatus != DCS_S_FREE &&
        pstSess[iIdx].cStatus != DCS_S_ERROR &&
        pstSess[iIdx].cStatus != DCS_S_USABLE &&
        iIdx < MAX_SESS) iIdx++;

  if(iIdx == MAX_SESS){
    ErrLog(1000,"DcsLUConnect:Sess over error",RPT_TO_LOG,0,0);
    PiErrno(pstDcsBuf) = DCS_ES_SESOVERFLW;
    UCP_TRACE_END(DCS_E_LOCALDCS);
  }
  /* initial sess */
  memset(&pstSess[iIdx], 0x0, sizeof(struct Lu62Sess) );

  GetCicsName(PcaData(pstDcsBuf),caCicsName);

ErrLog(100,"PcaData()",RPT_TO_LOG,PcaData(pstDcsBuf),80);
ErrLog(100,"caCicsName",RPT_TO_LOG,caCicsName,4);

/*
  g_ucaTpName = malloc(20);
*/
  strcpy(g_ucaTpName,caCicsName);

  g_lTpNameLen = 19;

  cmstpn(g_ucaConverId,
         g_ucaTpName,
         &g_lTpNameLen,
         &iCmRc);

  if (iCmRc != CM_OK) {
     sprintf(g_caMsg,"DcsLuConnect(xcstpn):lu62 fail, errno=[%d]",(int)iCmRc );
     ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
     PiErrno(pstDcsBuf) = iCmRc;
     UCP_TRACE_END(iCmRc);
  } 

  cmallc(g_ucaConverId,
	 &iCmRc);

  if (iCmRc != CM_OK) {
      ErrLog(1000,"cmalloc ucaConverId",RPT_TO_LOG,g_ucaConverId,20);
      ErrLog(1000,"RTPN",RPT_TO_LOG,g_ucaTpName,4);
      sprintf(g_caMsg,"DcsLUConnect(cmalloc):connect fail, errno=[%d]",iCmRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
  }

     
  /* save the session information */
  pstSess[iIdx].cStatus = DCS_S_USED ;
  memcpy(pstSess[iIdx].ucaConverId , g_ucaConverId,CONV_ID_LEN);
  pstSess[iIdx].cMode = ACTIVE_MODE;

  /* fill DCS buff */
  PiSesIdx(pstDcsBuf) = iIdx;
  PiErrno(pstDcsBuf) = 0;
  PcProto(pstDcsBuf) = LU62_DCS;

  sprintf(g_caMsg,"DcsLUConnect End.iIdx=%d ucaConverId=%s",
          iIdx,pstSess[iIdx].ucaConverId);
  ErrLog(10,g_caMsg,RPT_TO_LOG,pstSess[iIdx].ucaConverId,10);
  UCP_TRACE_END(DCS_NORMAL);
}


int
DcsLUAccept(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess)
{
  CM_RETURN_CODE  iCmRc=CM_OK;      /* ret code from CPI-C  */
  int iAcepLu62Id,iIdx,iRc;
  int iServLen;

  UCP_TRACE(P_DcsLUAccept);
  ErrLog(10,"DcsLUAccept Begin.",RPT_TO_LOG,0,0);

  /* search a usable dialogue  */
  iIdx = 1;
  while(pstSess[iIdx].cStatus != DCS_S_FREE &&
        pstSess[iIdx].cStatus != DCS_S_USABLE &&
        pstSess[iIdx].cStatus != DCS_S_ERROR &&
        iIdx < MAX_SESS) iIdx++;

  if(iIdx == MAX_SESS){
    ErrLog(1000,"DcsLUAccept:Sess over error",RPT_TO_LOG,0,0);
    PiErrno(pstDcsBuf) = DCS_ES_SESOVERFLW;
    UCP_TRACE_END(DCS_E_LOCALDCS);
  }
  /* initial sess */
  memset(&pstSess[iIdx], 0x0, sizeof(struct Lu62Sess) );

    
  cmaccp(g_ucaConverId,
         &iCmRc);

  if (iCmRc != CM_OK)
    {
      sprintf(g_caMsg,"DcsSkAccept(cmaccp):accept fail, errno=[%d]",iCmRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
    }


  /**********************************************************/
  /* set the deallocate type so that this side will ask for */
  /* confirmation from the source when making a deallocate  */
  /* call.						    */
  /**********************************************************/

  g_lDeallocateType = CM_DEALLOCATE_SYNC_LEVEL;

  cmsdt(g_ucaConverId,
        &g_lDeallocateType,
	&iCmRc);

  if (iCmRc != CM_OK)
    {
      sprintf(g_caMsg,"DcsSkAccept:set dealloc. type fail, errno=[%d]",iCmRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = iCmRc;
      UCP_TRACE_END(iCmRc);
    }
 
  /* save the session information */
  pstSess[iIdx].cStatus = DCS_S_USED ;
  memcpy(pstSess[iIdx].ucaConverId , g_ucaConverId,CONV_ID_LEN );
  pstSess[iIdx].cMode = PASSIVE_MODE;

  /* fill DCS buff */
  PiSesIdx(pstDcsBuf) = iIdx;
  PiErrno(pstDcsBuf) = 0;
  PcProto(pstDcsBuf) = LU62_DCS;

  sprintf(g_caMsg,"DcsLUAccept End.iIdx=%d ucaConverId=%s",
          iIdx,pstSess[iIdx].ucaConverId);

  ErrLog(10,g_caMsg,RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}


int
DcsLUSend(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess)
{
  CM_RETURN_CODE  iCmRc=CM_OK;      /* ret code from CPI-C  */
  int iIdx;
  unsigned char ucaWdLu62Id[CONV_ID_LEN];
  int iRc;
  int iMsgLen;
  char caDummy[20];
 
  UCP_TRACE(P_DcsLUSend);
  ErrLog(10,"DcsLUSend Begin.",RPT_TO_LOG,0,0);
  memset(ucaWdLu62Id , 0x00,CONV_ID_LEN);

  iIdx = PiSesIdx(pstDcsBuf);

  if(iIdx > 0){
    if(pstSess[iIdx].cStatus != DCS_S_USED || iIdx >= MAX_SESS){
      ErrLog(1000,"DcsLUSend:unusable Session!",RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = DCS_ES_SESUNUSE;
      UCP_TRACE_END(DCS_E_COMMAND);
    }
    memcpy(ucaWdLu62Id , pstSess[iIdx].ucaConverId,CONV_ID_LEN);
  }
  else{
    strcpy(ucaWdLu62Id , "0000001");
  }
  sprintf(g_caMsg,"DcsLUSend:iIdx=%d ucaWdLu62Id=%s ",
          iIdx,ucaWdLu62Id);
  ErrLog(100,g_caMsg,RPT_TO_LOG,ucaWdLu62Id,10);


  /* send a service reguest */
/*mod by eric */
  iMsgLen = PiDataLen(pstDcsBuf);

/*
  sprintf(g_caMsg,"DcsLUSend:iMsgLen=%d ",iMsgLen);
  ErrLog(1000,g_caMsg,RPT_TO_LOG,PcaData(pstDcsBuf),iMsgLen);
*/

  /**************************************************************/
  /* Send data to the target transaction program. This command  */
  /* will issue a packet of data of (length) bytes. The data    */
  /* going to the target can be found in the string send_buffer */
  /* Req_to_send indicates whether the remote program has made  */
  /* a request to send.		                                */
  /**************************************************************/
  g_lLength = (long) iMsgLen;
   
  cmsend(ucaWdLu62Id,
         PcaData(pstDcsBuf),
         &g_lLength,
         &g_lReqToSend,
         &iCmRc);

  if (iCmRc != CM_OK) {
      sprintf(g_caMsg,"DcsLUSend(cmsend):write fail, errno=[%d]",iCmRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      pstSess[iIdx].cStatus = DCS_S_ERROR;
      PiErrno(pstDcsBuf) = errno;
      UCP_TRACE_END(iRc);
  }

  /* update session */
  PiErrno(pstDcsBuf) = 0;

  if(iIdx == 0 && (pstSess[iIdx].cStatus == DCS_S_FREE ||
                  pstSess[iIdx].cStatus == DCS_S_USABLE)){
    pstSess[iIdx].cStatus = DCS_S_USED ;
    pstSess[iIdx].cMode = ACTIVE_MODE;
    PcProto(pstDcsBuf) = LU62_DCS;
  }

  ErrLog(10,"DcsLUSend End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}


int
DcsLUReceive(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess)
{
  CM_RETURN_CODE  iCmRc=CM_OK;      /* ret code from CPI-C  */
  unsigned char ucaRdLu62Id[CONV_ID_LEN];
  int iIdx;
  int iRc;
  int iMsgLen;
  char caDummy[10];
  void DcsLUNull();
  char caTmpBuf[10];
 
  UCP_TRACE(P_DcsLUReceive);
  memset(ucaRdLu62Id , 0x00,CONV_ID_LEN);

  iIdx = PiSesIdx(pstDcsBuf);

  if(iIdx > 0){
    if(pstSess[iIdx].cStatus != DCS_S_USED || iIdx >= MAX_SESS){
      ErrLog(1000,"DcsLUReceive:unusable Session!",RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = DCS_ES_SESUNUSE;
      UCP_TRACE_END(DCS_E_COMMAND);
    }
    memcpy(ucaRdLu62Id , pstSess[iIdx].ucaConverId,CONV_ID_LEN);
  }
  else{
    strcpy(ucaRdLu62Id , "0000001");
  }
  sprintf(g_caMsg,"DcsLUReceive:iIdx=%d ucaRdLu62Id=%s. timeout=%d",
          iIdx,ucaRdLu62Id,PlWaiTime(pstDcsBuf) );
  ErrLog(100,g_caMsg,RPT_TO_LOG,ucaRdLu62Id,10);


  signal(SIGALRM,DcsLUNull)  ;
  signal(SIGINT,SIG_DFL)  ;
  alarm(PlWaiTime(pstDcsBuf)) ;

  iMsgLen = PiDataLen(pstDcsBuf);
  g_lLength = (long) iMsgLen;


  cmrcv(ucaRdLu62Id,
        PcaData(pstDcsBuf),
        &g_lLength,
	&g_lDataReceived,
	&g_lReceivedLength,
	&g_lStatusReceived,
	&g_lReqToSend,
	&iCmRc);
/*
sprintf(g_caMsg,"cmrcv():status [%d] data_rcvd [%d] ",
                 (int)g_lStatusReceived,(int)g_lDataReceived);
ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
*/

  
  if ( !((iCmRc == CM_OK) || (iCmRc == CM_DEALLOCATED_NORMAL)) ) {
      sprintf(g_caMsg,"DcsLUReceive(cmrcv):read fail, errno=[%d]",iCmRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,PcaData(pstDcsBuf),g_lReceivedLength);
      pstSess[iIdx].cStatus = DCS_S_ERROR;
      PiErrno(pstDcsBuf) = iCmRc;
      alarm(0);  /* add by chi-fusong at PSB-HAINAN 1995/09/06 */
      if(errno == EINTR) UCP_TRACE_END(DCS_E_TIMEOUT);
      UCP_TRACE_END(iCmRc);
  }

  sprintf(caTmpBuf,"%.5d",g_lReceivedLength);
  memcpy(PcaDataLen(pstDcsBuf),caTmpBuf,5);

  sprintf(g_caMsg,"DcsLUReceive(cmrcv):read ok, iCmRc=[%d] len=%d",
          iCmRc,g_lReceivedLength);
  ErrLog(100,g_caMsg,RPT_TO_LOG,PcaData(pstDcsBuf),g_lReceivedLength);


  if (g_lStatusReceived == CM_CONFIRM_RECEIVED || 
      g_lStatusReceived == CM_CONFIRM_SEND_RECEIVED) {

      cmcfmd(ucaRdLu62Id,
             &iCmRc);
     
      if (iCmRc != CM_OK) {
          sprintf(g_caMsg,"DcsLUReceive(cmcfmd) fail, errno=[%d]",iCmRc);
          ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
          pstSess[iIdx].cStatus = DCS_S_ERROR;
          PiErrno(pstDcsBuf) = iCmRc;
          alarm(0);  /* add by chi-fusong at PSB-HAINAN 1995/09/06 */
          UCP_TRACE_END(iCmRc);
      }

      /***********************************************************/
      /* issue the request to send command to request permission */
      /* from the source program to enter send state. Only do    */
      /* this before the send token has arrived from the other   */
      /* side of the conversation.            		     */
      /***********************************************************/
/*
      if (g_lStatusReceived == CM_CONFIRM_RECEIVED) 
        {

          cmrts(ucaRdLu62Id,
                &iCmRc);

          if (iCmRc != CM_OK)
            {
              sprintf(g_caMsg,"DcsLUReceive:cmrts fail, errno=[%d]",iCmRc);
              ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
              pstSess[iIdx].cStatus = DCS_S_ERROR;
              PiErrno(pstDcsBuf) = iCmRc;
              UCP_TRACE_END(iCmRc);
            }
        }
*/

    } 

  alarm(0) ;
  iMsgLen = (int) g_lReceivedLength;


  /* save the session information */
  PiDataLen(pstDcsBuf) = iMsgLen ;
  PiErrno(pstDcsBuf) = 0;

  if(iIdx == 0 && (pstSess[iIdx].cStatus == DCS_S_FREE ||
                  pstSess[iIdx].cStatus == DCS_S_USABLE)){
    pstSess[iIdx].cStatus = DCS_S_USED ;
    pstSess[iIdx].cMode = PASSIVE_MODE;
    PcProto(pstDcsBuf) = LU62_DCS;
  }

  ErrLog(10,"DcsLUReceive End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}




int
DcsLUDisconnect(struct DcsBuf *pstDcsBuf,struct Lu62Sess *pstSess)
{
  CM_RETURN_CODE  iCmRc=CM_OK;      /* ret code from CPI-C  */
  int iRc;
  int iIdx;
  unsigned char ucaConverId[CONV_ID_LEN];
 
  UCP_TRACE(P_DcsLUDisconnect);
  memset(ucaConverId , 0x00,CONV_ID_LEN);

  /* Is the dialogue usable */
  iIdx = PiSesIdx(pstDcsBuf);

  if(iIdx > 0){
    if(pstSess[iIdx].cStatus == DCS_S_FREE || iIdx >= MAX_SESS){
      ErrLog(1000,"DcsLUDisconnect: unusable Session!",RPT_TO_LOG,0,0);
      PiErrno(pstDcsBuf) = DCS_ES_SESUNUSE;
      UCP_TRACE_END(DCS_E_COMMAND);
    }
    memcpy(ucaConverId , pstSess[iIdx].ucaConverId,CONV_ID_LEN);
  }
  else{
    strcpy(ucaConverId , "0000001");
  }


  g_lDeallocateType = CM_DEALLOCATE_ABEND;

  cmsdt(ucaConverId,
        &g_lDeallocateType,
        &iCmRc);

  if (iCmRc != CM_OK) {
    ErrLog(1000,"cmdeal ucaConverId",RPT_TO_LOG,ucaConverId,20);
    sprintf(g_caMsg,"DcsLUDisconnect(cmsdt):cmsdt fail, errno=[%d]",iCmRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstSess[iIdx].cStatus = DCS_S_ERROR;
    PiErrno(pstDcsBuf) = iCmRc;
    UCP_TRACE_END(iCmRc);
  }

  cmdeal(ucaConverId,
         &iCmRc);

  if (iCmRc != CM_OK) {
    sprintf(g_caMsg,"DcsLUDisconnect(cmdeal) fail, errno=[%d]",iCmRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    pstSess[iIdx].cStatus = DCS_S_ERROR;
    PiErrno(pstDcsBuf) = iCmRc;
    UCP_TRACE_END(iCmRc);
  }

  /* save the session information */
  pstSess[iIdx].cStatus = DCS_S_FREE;
  strcpy(pstSess[iIdx].ucaConverId , "00000-1");

  /* fill DCS buff */
  PiSesIdx(pstDcsBuf) = -1;
  PiErrno(pstDcsBuf) = 0;
  PcProto(pstDcsBuf) = ' ';

  ErrLog(100,"DcsLUDisconnect End.",RPT_TO_LOG,0,0);
  UCP_TRACE_END(DCS_NORMAL);
}


int
DcsLUTerminate(struct DcsBuf *pstDcsBuf)
{
  UCP_TRACE(P_DcsLUTerminate);
  UCP_TRACE_END(DCS_NORMAL);
}


void
DcsLUNull()
{
  ErrLog(1000,"dcslu62 timeout occurse !",RPT_TO_LOG,0,0);
}

GetCicsName(unsigned char *pcaData,char *pcaCicsName)
{
int iRc;

  switch (pcaData[3]){
   case 0xC9:
     strcpy(pcaCicsName,"TPEI");
     break;

   case 0xD1:
     strcpy(pcaCicsName,"TPEJ");
     break;

   case 0xD6:
     strcpy(pcaCicsName,"TPEO");
     break;

   default:
     strcpy(pcaCicsName,"TPEO");
     break;
  } /* end switch */
}

