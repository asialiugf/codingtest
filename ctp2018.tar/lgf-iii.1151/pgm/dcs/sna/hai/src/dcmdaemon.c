
/* FUNCTION & SUBROUTINE DESCRIPTION
 *&N&   TYPE      NAME                     DESCRIPTION
 *&N&-------- -------------  ----------------------------------------------
 *&N& int     DcsCreat()
 *&N& int     GetFileData()
*/
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <sys/types.h>

#include "errlog.h"
#include "dcs.h"
char gs_caTmCode[20];
char gs_caBrCode[20];

/*===========================================================================*/
static struct DcsSiof gs_stDcsSiof;
static struct DcsBuf  gs_stDcsBuf;
int    g_iTmin; 
int    g_iTestMode;
/**********************************************************************
 *&N& ROUTINE NAME:main()
 *&A& ARGUMENTS:NONE
 *&A&           ARG1:branch code
 *&A&           ARG2:terminal code
 *&A&           ARG3:LU profile prefix
 *&R& RETURN VALUE(S):NONE
 *&D& DESCRIPTION:
 *&D&             This main program will be invoked by the dcxappcinit
 *&D&             when the TPE is starting up.
 **********************************************************************/
main(int iArgc, char **caaArgv)
{
  char  cCmd, caInpData[ DCS_MAX_DATA_LEN ];
  char  cRc , caOutData[ DCS_MAX_DATA_LEN ];
  int   iInpLen, iOutLen, iRc;
  int   i;
  char caLogName[256];



  if( iArgc < 4 )
  {
    ErrLog(1000,
          "Invalid argument, usage:dcxdaemon.x  BRCODE TMCODE PREFIX"
          ,RPT_TO_LOG,0,0);
    exit(-1);
  }

  SignlHdl();

  GetConfg();  /* get the T_MIN in the config.dat */

  sprintf(caLogName, "%s/iii/log/tms_errlog", getenv("III_DIR") );
  if ( g_iTestMode == 0 ) {
      ChgLog(LOG_CHG_MODE,"0");
  }
  else {
      ChgLog(LOG_CHG_MODE,"1");
  }
  ChgLog(LOG_CHG_LOG,caLogName);

  MpstDcsSiof( gs_stDcsBuf )  =  &gs_stDcsSiof ;

  sprintf( gs_caBrCode,"%s",caaArgv[1] );
  sprintf( gs_caTmCode,"%s",caaArgv[2] );

  if ( AttQue() != 0 ) {
    ErrLog(1000,"dcxdaemon.x:AttQue error",RPT_TO_LOG,0,0);
    exit(-2);
  }

  while(1)
  {
    iInpLen = sizeof( caInpData );
    iRc  =  RdQue( &cCmd, caInpData, &iInpLen);
    if( iRc  != DCS_NORMAL ) {
      sprintf(g_caMsg,"dcxdaemon.x,RdQue(),error,iRc=%d",iRc);
      ErrLog(40000,g_caMsg,RPT_TO_LOG,0,0);
      break;
    }
    sprintf(g_caMsg,"dcxdaemon.x,RdQue(),HexDmp,cCmd=%c",cCmd);
    ErrLog(10,g_caMsg,RPT_TO_LOG,caInpData,iInpLen);
    iRc      =  DCS_NORMAL;

    switch( cCmd )
    {
      case DCSCONNECTWRITE :
        ErrLog(10,"dcxdaemon.x:in switch(),DCSCONNECTWRITE",RPT_TO_LOG,0,0);

        McRqstCode( gs_stDcsBuf )   =  DCSCONNECTWRITE;
        MiDataLen( gs_stDcsBuf )    =  iInpLen;
        memcpy( McaData( gs_stDcsBuf ), caInpData, iInpLen );
        iRc      =  DcsLU( &gs_stDcsBuf,caaArgv[3] );
        iOutLen  =  0;
        break;
 
      case DCSWRITE :
        ErrLog(10,"dcxdaemon.x,while.switch(),DCSWRITE",RPT_TO_LOG,0,0);

        McRqstCode( gs_stDcsBuf )   =  DCSWRITE;
        MiDataLen( gs_stDcsBuf )    =  iInpLen;
        memcpy( McaData( gs_stDcsBuf ), caInpData, iInpLen );
        iRc      =  DcsLU( &gs_stDcsBuf,caaArgv[3] );
        iOutLen  =  0;
        break;

      case DCSREAD         :
        ErrLog(10,"dcxdaemon.x,while.switch(),DCSREAD",RPT_TO_LOG,0,0);
        McRqstCode( gs_stDcsBuf )   =  DCSREAD;
        MiDataLen( gs_stDcsBuf )    =  DCS_MAX_DATA_LEN ;
        MlWaiTime( gs_stDcsBuf )    =  g_iTmin;
        iRc      =  DcsLU( &gs_stDcsBuf,caaArgv[3] );
        
        if( iRc == DCS_NORMAL ) {
          iOutLen  =  MiDataLen( gs_stDcsBuf );
        }
        else {
          iOutLen  =  0;
        }
        memcpy( caOutData , McaData( gs_stDcsBuf), MiDataLen(gs_stDcsBuf));
        break;

      case DCSDISCONNECT :
        ErrLog(10,"dcxdaemon.x,while.switch(),DCSWRITE",RPT_TO_LOG,0,0);

        McRqstCode( gs_stDcsBuf )   =  DCSDISCONNECT;
        MiDataLen( gs_stDcsBuf )    =  iInpLen;
        memcpy( McaData( gs_stDcsBuf ), caInpData, iInpLen );
        iRc      =  DcsLU( &gs_stDcsBuf,caaArgv[3] );
        iOutLen  =  0;
        break;

      default :
        ErrLog(1000,"dcxdaemon.x,while.switch(),default",RPT_TO_LOG,0,0);
        iOutLen  =  0;
        iRc      =  DCS_E_COMMAND ;
        break;
    } /* for switch( cCmd ) */

    if( iRc == DCS_NORMAL ) {
      cRc   =  '0';
    }
    else {
      cRc   =  '1';
    }
    if ( WrQue(&cRc,caOutData,&iOutLen) != 0 ) {
      ErrLog(1000,"dcxdaemon.x WrQue error !",RPT_TO_LOG,0,0);
    }
  } /* for  while(1) */
  return(0);
}
/* ======add for dcmpsuio to get T_MIN          =====begin=========== */
int
GetConfg()
{
  int iRc;
  char caFileName[ 256 ];

  strcpy(caFileName, (char *)getenv( "III_DIR" ));
  strcat(caFileName, "/");
  strcat(caFileName, "iii/etc/tbl/config.dat");

  iRc = InitCnfTbl( caFileName );
  if ( iRc < 0 ) {
    ErrLog(1000, "GetConfg: InitCnfTbl() fails!", RPT_TO_LOG, 0, 0);
    return ( -1 );
  }

  g_iTestMode = GetCnfValue( "TEST_MODE" );
  if (g_iTestMode < 0){
    ErrLog(1000, "GetConfg: GetCnfValue() fails!", RPT_TO_LOG, 0, 0);
    return( -1 );
  }

  g_iTmin = GetCnfValue( "T_MIN" );
  if (g_iTmin < 0){
    ErrLog(1000, "GetConfg: GetCnfValue() fails!", RPT_TO_LOG, 0, 0);
    return( -1 );
  }

  return ( 0 );
}
/* ======add for dcmpsuio to get T_MIN          =====end  =========== */
