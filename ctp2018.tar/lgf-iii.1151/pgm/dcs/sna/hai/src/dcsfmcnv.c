#define         TPEI_TPEO           1 
#include        <sys/types.h>
#include        <errno.h>
#include        <fcntl.h>
#include        <stdio.h>
#include        <malloc.h>

#include        "errlog.h"	/* error log include file */
#include        "dcs.h"		/* dcs api include file */
#include        "twa.h"		/* dcs api include file */
#include        "dccpgdef.h" 

#define  TMS_AP_ABEND                '5' 

#define  SIF_HEAD_LEN                51
#define  STATUS                      25 

#define  SOF_DATA_LEN_OFFSET         27  /* added by chi-fusong 1995/03/20 */

#define  START_PGM_ERR	             -4
#define  FILE_OVER                   -9
#define  FORMAT_CONV_ERROR           -1
#define  CODE_CONV_ERROR             -2
#define  GET_SERV_NAME_ERROR         -3
#define  SND_SIF_TO_SERV_ERROR       -4
#define  RCV_SOF_FRM_SERV_ERROR      -5
 
#define  RCV_OK                      '1'
#define  RCV_ERR                     '0'

extern char       *g_pcCtf;
extern struct TMA *g_pstTma;
extern struct TBA *g_pstTba;
extern struct APA *g_pstApa;
extern int        g_iBrhCodeLen;
extern int        g_iTmCodeLen;

char              g_cRcvRmtDataFlag; /* indicate rcv rmt data OK or not? */

struct TpuSof {
  int  iLen;
  unsigned char ucaData[SOF_SIZE];
} g_staTpuSof[MAX_SOF];

extern struct DcsApi *g_pstDcsApi;
extern struct DcsBuf g_stDcsBuf;
char cnv_ptr;    /* dummy variable for CONVERTION TABLE */
int   g_iSofTolCnt = 0;
int   g_iEjTolCnt = 0;
int   g_iReinput = 0;

/* ----- add by chi-fusong ----for Time out Adjustment -----begin ------ */
/* *********************************************************** */
/* g_caMemBuf contain MemBufCtl MSGP + REINPUT SIF + remote reverse txn SIF + 
   POST + SOF_HEAD_LEN_PLUS_2*2 (for control) + g_stHostToBrhInfo(100 bytes) */
extern char g_caMemBuf[MAX_MSGP_LEN * 2];
struct  MemBufCtlSt{
  int iMsgCnt;
  int iNextOffset;
};
extern struct  MemBufCtlSt g_stMemBufCtl;
/* ----- add by chi-fusong ----for Time out Adjustment -----end   ------ */


int
RmtProc(unsigned char *caSifTmpBuf,int iTpeSifLen,char *pcRmtApFlg)
{
  int i;
  int iRc;
  int iTpeTmpSifLen ;
  unsigned char caSifBuf[ SIF_SIZE ];
  struct MemBufCtlSt *pstMemBufCtl;


  g_iSofTolCnt = 0;  /* reset the count */
  g_iEjTolCnt = 0;   /* reset the count */
  g_iReinput = 0;    /* reset the reinput flag */

  iTpeTmpSifLen = iTpeSifLen;
#ifndef TPEI_TPEO
  caSifTmpBuf[3]='J';  /* overwrite the SIF for TPEJ */
#endif
  sprintf(g_caMsg,"RmtProc: TPE Sif Len %d, SIF=",iTpeTmpSifLen);
  ErrLog(100,g_caMsg,RPT_TO_LOG,caSifTmpBuf,iTpeTmpSifLen);

  ErrLog(1000,"RMTPROC: begin",RPT_TO_LOG,caSifTmpBuf,iTpeTmpSifLen);
  /* convert the SIF to the right format & right code */
  if ((iRc=SifConvt(caSifTmpBuf, caSifBuf, &iTpeTmpSifLen))<0) {
    return(iRc);
  }
 
  /* invoke the txn. in the remote site and receive the txn. output */ 
  if( (iRc=TxnStart(caSifBuf, iTpeTmpSifLen, pcRmtApFlg,caSifTmpBuf) ) < 0 ) {
    sprintf(g_caMsg,"<RmtProc>: send data to RMT HOST error!");
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    return(iRc);
  }

  /* get the txn. output from the buffer and convert them to the right */
  /* code and right format                                             */
  iRc = GetAllSof(&g_iSofTolCnt,pcRmtApFlg);

  /* Clear  g_caMemBuf */
  memset(g_caMemBuf, '\0', sizeof(g_caMemBuf));
  pstMemBufCtl = (struct MemBufCtlSt *)&g_stMemBufCtl ;
  pstMemBufCtl->iNextOffset = sizeof(struct MemBufCtlSt);
  pstMemBufCtl->iMsgCnt     = 0;

  /* move the sof received from the HOST to the TPU buffer through    */
  /* MemWrite() in the tmsoutp.c                                      */
  for(i=0;i<g_iSofTolCnt;i++) {
    if( (unsigned char) g_staTpuSof[i].ucaData[STATUS]
         ==(unsigned char)0x08 ) {
      g_staTpuSof[i].ucaData[STATUS] = (unsigned char) 0x88 ;
      iRc = MemWrite(g_staTpuSof[i].ucaData,g_staTpuSof[i].iLen,1);
      g_iSofTolCnt = i+1;
      sprintf(g_caMsg,"after write output file dbp SofCnt %d",g_iSofTolCnt);
      ErrLog(100,g_caMsg,RPT_TO_LOG,g_staTpuSof[i].ucaData,
                  g_staTpuSof[i].iLen );

      if( iRc !=  g_staTpuSof[i].iLen ) {
        sprintf(g_caMsg,
        "write() sof error! write size=%d,write() rtn size=%d",
                g_staTpuSof[i].iLen,iRc);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        return(-5);   /* recevice SOF ERROR */
      }

      break;
    }
    iRc = MemWrite(g_staTpuSof[i].ucaData,g_staTpuSof[i].iLen,1);
    sprintf(g_caMsg,"after write output file dbp SofCnt %d",g_iSofTolCnt);
    ErrLog(100,g_caMsg,RPT_TO_LOG,g_staTpuSof[i].ucaData,
                g_staTpuSof[i].iLen );
    if( iRc !=  g_staTpuSof[i].iLen ) {
      sprintf(g_caMsg,"write() sof error! write size=%d,write() rtn size=%d",
              g_staTpuSof[i].iLen,iRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      return(-5);   /* recevice SOF ERROR */
    }
  } /* for 'for(i=0;i<g_iSofTolCnt;i++)' */ 

  g_cRcvRmtDataFlag = RCV_OK;
  ErrLog(1000,"RMTPROC: end",RPT_TO_LOG,0,0);
  return(iRc);
}


int
GetAllSof(int *iSofCnt,char *pcRmtApFlg)
{
  int iDx=0;
  int iSofLen;
  int iEjLen; /* added by chi-fusong , 1995/03/20 */
  unsigned char caSofTmpBuf[ SOF_SIZE ];
  unsigned char caSofBuf[ SOF_SIZE ];
  /* ------------------- Decompress SOF ---------------------- */
  int iRc;
  char caCnvInBuff[3072];
  /* ------------------- Decompress SOF ---------------------- */

/*  ErrLog(100,"start GetAllSof",RPT_TO_LOG,0,0); */

  for( GetHostSof(caSofTmpBuf,&iSofLen);
       iSofLen > 0; GetHostSof(caSofTmpBuf,&iSofLen)) {

    /* ------------------- Decompress SOF ---------------------- */
/* marked by Chi Fu-Song,1997/05/23, no compress/decompress to TPE/CICS */
/*
    iRc = SofDecprs(caSofTmpBuf,&iSofLen,caCnvInBuff);
    if ( iRc < 0 ) {
      sprintf(g_caMsg,"TPE sof code decompress error iRc=%d",iRc);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,caSofTmpBuf,iSofLen);
      UCP_TRACE_END(iRc);
    }
    memcpy(caSofTmpBuf,caCnvInBuff,iSofLen);
*/
    /* ------------------- Decompress SOF ---------------------- */

    memset(caSofBuf,0x00,iSofLen);
    ErrLog(100,"GetAllSof() HostSof data",RPT_TO_LOG,caSofTmpBuf,iSofLen);
    if(g_iReinput == 1) {
      TpeReinputProc(caSofTmpBuf, caSofBuf, &iSofLen);
      g_iReinput = 0;
    }
    else {
      SofConvt(caSofTmpBuf, caSofBuf, &iSofLen);
    }
    if ( ((unsigned char)caSofTmpBuf[STATUS]==0x20)||
         ((unsigned char)caSofTmpBuf[STATUS] == 0x22) ) {
      g_iReinput = 1;
    }
    g_staTpuSof[ iDx ].iLen = iSofLen;
    memcpy( g_staTpuSof[ iDx ].ucaData, caSofBuf, g_staTpuSof[ iDx ].iLen );

    /* ==================================================================== */
    /* added by chi-fusong , 1995/03/20                                     */
    /* ---- added for collect EJ data to TBA.caPara from the first SOF      */
    /* First, check the length of first SOF , if (length > 0) means EJ data */
    /*      available, otherwise not.                                       */
    /* ==================================================================== */
    if ( iDx == 0 ) {
      if ( g_staTpuSof[iDx].ucaData[STATUS] == (unsigned char) 0x88 ) {
        *pcRmtApFlg=TMS_AP_ABEND;
      }
    }

    if ( iDx == 0 ) {  /* means the first SOF from TPE/CICS */
      iEjLen=(int) ((unsigned char)g_staTpuSof[iDx].ucaData[SOF_DATA_LEN_OFFSET]
                   *256+(unsigned char)g_staTpuSof[iDx].ucaData[SOF_DATA_LEN_OFFSET+1] ) ;
/*
      ErrLog(10,"GetAllSof: first SOF last 2 byte=",RPT_TO_LOG,
             &g_staTpuSof[iDx].ucaData[SOF_DATA_LEN_OFFSET],2); */
      if ( iEjLen > 0 ) {
       memcpy(g_pstTba->caPara,&g_staTpuSof[iDx].ucaData[SOF_DATA_LEN_OFFSET+2],
               iEjLen);
       sprintf(g_caMsg,"GetAllSof:EjLen=%d EJ DATA=",iEjLen);
       ErrLog(100,g_caMsg,RPT_TO_LOG,     
              &g_staTpuSof[iDx].ucaData[SOF_DATA_LEN_OFFSET+2],iEjLen);
      }
      else {
       ErrLog(10,"GetAllSof: this Txn has no EJ data!",RPT_TO_LOG,0,0);     
      }
    }

    iDx++;
  } /* for "for( GetHostSof(caSofTmpBuf,&iSofLen)" */
  *iSofCnt = iDx;  
  return(0);
}

int 
TpeReinputProc(char *pcaUcpSof,char *pcaTpeSof, int *iSofLen)
{
int iRc;
int iTpeSofLen;
unsigned char caHostTpeSof[ MAX_LEN +8 ];


  iTpeSofLen = *iSofLen;

  memcpy(pcaTpeSof,pcaUcpSof,iTpeSofLen);

  if( (iRc=ReinputSofConvt( pcaTpeSof , &iTpeSofLen )) ==  DCS_NORMAL) {
    *iSofLen = iTpeSofLen;
    sprintf(g_caMsg,"TpeReinputProc() iTpeSofLen %d ",iTpeSofLen);
    ErrLog(100,g_caMsg,RPT_TO_LOG,pcaTpeSof,iTpeSofLen);
  }
  else { 
    ErrLog(1000,"Reinput Data convert error",RPT_TO_LOG,pcaTpeSof,iTpeSofLen);
    return ( CODE_CONV_ERROR);
  }
  return(0);
} 
