#include  "big2host.h"
#include  "errlog.h"
#include  "dccpgdef.h" 
#include  "dcs.h"
/*********************************************************************/
/* PROGRAM-NAME:dcsiftxf.c                                           */
/* LAST-UPDATE-DATE:                                                 */
/*********************************************************************/
#define  SIF_TTYPE_LEN       4
#define  SIF_TCODE_LEN       6
#define  SIF_BRCODE_LEN      10
#define  SIF_TMCODE_LEN      4
#define  SIF_TLCODE_LEN      4
#define  SIF_HEAD_LEN        51

#define  SIF_TCODE_OFF       4  /* offset of the TXN-ID in the SIF */
#define  SIF_BR_OFF          10 /* offset of the BrCode in the SIF */
#define  SIF_TM_OFF          20 /* offset of the TmCode in the SIF */
#define  SIF_TELL_OFF        24 /* offset of the TellerCode in the SIF */
#define  SIF_LINENO_OFFS     48 /* offset of the Lineno in the SIF */
#define  SIF_CTL_OFFS        49 /* offset of the CTLByte in the SIF */
#define  SIF_ITEMDATA_OFFS   51 /* offset of the 1st item len in the SIF */

extern struct table_array cnv_tbl;
extern struct table_array *cnv_ptr;

/* TPE SIF FORMAT for referance */
struct TPESIF {            
  char txn_code[4];
  char txt_id[6];
  char br_id[10];
  char tm_id[4];
  char tell_id[4];
  char user_data[20];
  char line_no;
  char ctl_byte[2];
  char lendata[469];
  } ;

#define   P_SifConvt                10001
#define   P_SifCodeConvt            10002
#define   P_HostSifConvt            10003

/**********************************************************************
 *&N& ROUTINE NAME:SifConvt()
 *&A& ARGUMENTS:SIF-BEFORE-CONVERT
 *&A& ARGUMENTS:SIF-AFTER-CONVERT
 *&A& ARGUMENTS:LEN-OF-THE-SIF-BEFORE-CONVERT & return the length after 
 *&A&           converting
 *&R& RETURN VALUE(S):0 -> convert O.K.
 *&R&                -1 -> SIF FORMAT ERROR   
 *&R&                -2 -> code convertion error
 *&D& DESCRIPTION:
 *&D&             This subroutine will convert the SIF to the transaction
 *&D&             input data format of the target platform. It includes
 *&D&             the code convert such as ASCII -> EBCDIC, Chinese code
 *&D&             convertion.                                            
 *&D&             1. Call UnixToCics() to handle the digit dot problem.
 *&D&                (Remove the digit dot and dot stuffing, this
 *&D&                difference is between the UNIX & CICS SIF
 *&D&             2. Call SifCodeConvt() to convert the ASCII to EBCDIC,
 *&D&                Chinese Code.
 **********************************************************************/
int 
SifConvt(unsigned char *pcaTpeSif,unsigned char *pcaTargetSif, int *iSifLen)
{
  int iRc;
  int iTpeSifLen;
  unsigned char caHostTpeSif[ MAX_LEN +8 ];
  unsigned char caHostUcpSif[ MAX_LEN +8 ];
  /* ------------------ compress SIF -------------------- */
  char caCnvOutBuff[1024];
  /* ------------------ compress SIF -------------------- */


  UCP_TRACE(P_SifConvt);
  sprintf(g_caMsg,"SifConvt:before UnixToCicsSif,*iSifLen=%d,dump pcaTpeSif",
          *iSifLen);
  ErrLog(100,g_caMsg,RPT_TO_LOG,pcaTpeSif,*iSifLen);

  /* UnixToCicsSif is loacted in the tmsinedt.c */
  iTpeSifLen = UnixToCicsSif(pcaTpeSif,pcaTargetSif);
  sprintf(g_caMsg,"SifConvt:after UnixToCicsSif,iTpeSifLen=%d,dumppcaTpeSif",
          iTpeSifLen);
  ErrLog(100,g_caMsg,RPT_TO_LOG,pcaTargetSif,iTpeSifLen);
  
  /* Convert the SIF code to the target system's code */
  if((iRc  =  SifCodeConvt( pcaTargetSif, caHostTpeSif , &iTpeSifLen ))
      !=  DCS_NORMAL) {
    sprintf(g_caMsg,"TPE sif code convert error iRc=%d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,caHostTpeSif,iTpeSifLen);
    UCP_TRACE_END(iRc);
  }

  /* ------------------ compress SIF -------------------- */
/* marked by Chi Fu-Song,1997/05/23, no compress/decompress to TPE/CICS */
/*
  iRc = SifCprs(caHostTpeSif,caCnvOutBuff,iTpeSifLen);
  if ( iRc < 0 ) {
    sprintf(g_caMsg,"TPE sif code compress error iRc=%d",iRc);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,caHostTpeSif,iTpeSifLen);
    UCP_TRACE_END(iRc);
  }
  iTpeSifLen = iRc;
  memcpy(caHostTpeSif,caCnvOutBuff,iTpeSifLen);
*/
  /* ------------------ compress SIF -------------------- */

  *iSifLen = iTpeSifLen;
  memcpy(pcaTargetSif,caHostTpeSif,iTpeSifLen);
  UCP_TRACE_END(0);
} 

/**********************************************************************
 *&N& ROUTINE NAME:SifCodeConvt()
 *&A& ARGUMENTS:SIF-BEFORE-CONVERT
 *&A& ARGUMENTS:SIF-AFTER-CONVERT
 *&A& ARGUMENTS:LEN-OF-THE-SIF-BEFORE-CONVERT & return the length after 
 *&A&           converting
 *&R& RETURN VALUE(S):0 -> convert O.K.
 *&R&                -1 -> SIF FORMAT ERROR   
 *&R&                -2 -> code convertion error
 *&D& DESCRIPTION:
 *&D&             It will convert the SIF from ASCII & BIG-5 Chinese code 
 *&D&             to EBCDIC & IBM HOST Chinese CODE
 **********************************************************************/
int
SifCodeConvt(unsigned char *pbaUnixSif,unsigned char *pbaHostSif,
              int *piSifLen)
{
  short data_len,cnv_len;
  int   i,iUnixSifNo,iHostSifNo;

  UCP_TRACE(P_SifCodeConvt);
  ErrLog(100,"SifCodeConvt:input sif:",RPT_TO_LOG,pbaUnixSif,*piSifLen);
  /* convert the SIF HEADER first */
  if ( (i = big5_host(pbaUnixSif,pbaHostSif,SIF_HEAD_LEN,cnv_ptr))
        !=SIF_HEAD_LEN ) {
    sprintf(g_caMsg,"SIF head code conversion error len=%d !",i);
    ErrLog(2000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  }

  /* copy the LINE-NO & CTL-BYTES in the SIF */
  memcpy(pbaHostSif+SIF_LINENO_OFFS,pbaUnixSif+SIF_LINENO_OFFS,3); 

  /* begin to convert the input item */
  for ( iUnixSifNo = SIF_ITEMDATA_OFFS,iHostSifNo = SIF_ITEMDATA_OFFS ; 
        iUnixSifNo < *piSifLen; ) {
    data_len=pbaUnixSif[iUnixSifNo]*256+pbaUnixSif[iUnixSifNo+1];
    if ( (data_len + iUnixSifNo + 2) > *piSifLen) {
      sprintf(g_caMsg,"sif item length error, final offset=%d SIF:",
              data_len + iUnixSifNo + 2);
      ErrLog(1000,g_caMsg,RPT_TO_LOG,pbaUnixSif,*piSifLen);
      UCP_TRACE_END(-1);
    }
    cnv_len  =  big5_host(pbaUnixSif+iUnixSifNo+2,pbaHostSif+iHostSifNo+2,
                          data_len,cnv_ptr);
    /* adjust the item data length for the converted SIF */
    pbaHostSif[ iHostSifNo ]  =  cnv_len / 256;
    pbaHostSif[ iHostSifNo + 1 ]  =  cnv_len % 256;

    iUnixSifNo  =  iUnixSifNo+2 + data_len;
    iHostSifNo  =  iHostSifNo+2 + cnv_len;
  }  /* for 'for loop' */

  *piSifLen  =  iHostSifNo ;
  UCP_TRACE_END(0);
}


/**********************************************************************
 *&N& ROUTINE NAME:HostSifConvt()
 *&A& ARGUMENTS:NONE
 *&R& RETURN VALUE(S):NONE
 *&D& DESCRIPTION:Convert the HOST SIF to the UNIX SIF
 *&D&     
 **********************************************************************/

int
HostSifConvt(unsigned char *pbaUnixSif,unsigned char *pbaHostSif,
              int *piSifLen)
{
  short data_len,cnv_len;
  int   i,iUnixSifNo,iHostSifNo;

  UCP_TRACE(P_HostSifConvt);

  ErrLog(100,"HostSifConvt:input SIF:",RPT_TO_LOG,pbaUnixSif,*piSifLen);

  /* convert the SIF header first */
  if ( (i = host_big5(pbaUnixSif,pbaHostSif,SIF_HEAD_LEN,cnv_ptr))
        !=SIF_HEAD_LEN ) {
    sprintf(g_caMsg,"SIF head code conversion error len=%d !",i);
    ErrLog(2000,g_caMsg,RPT_TO_LOG,0,0);
    UCP_TRACE_END(-1);
  }

  /* copy the LINE-NO & CTL-BYTES in the SIF */
  memcpy(pbaHostSif+SIF_LINENO_OFFS,pbaUnixSif+SIF_LINENO_OFFS,3); 

  /* begin to convert the input item */
  for ( iUnixSifNo = SIF_ITEMDATA_OFFS,iHostSifNo = SIF_ITEMDATA_OFFS ; 
        iUnixSifNo < *piSifLen; ) {
    data_len = pbaUnixSif[ iUnixSifNo ] * 256
             + pbaUnixSif[ iUnixSifNo + 1 ];
    if ( (data_len + iUnixSifNo + 2) > *piSifLen) {
      sprintf(g_caMsg,"sif item length error, final offset=%d",
              data_len + iUnixSifNo + 2);
      ErrLog(1001,g_caMsg,RPT_TO_LOG,0,0);
      UCP_TRACE_END(-1);
    }
    cnv_len=host_big5(pbaUnixSif+iUnixSifNo+2,pbaHostSif+iHostSifNo+2,
                      data_len,cnv_ptr);

    /* cnv_len does not include the length of SI & SO, so if the length */
    /* of the data is shorter than it is before convertion, then stuff  */
    /* with the NULL char in the tail of the data                          */
   
    memset(pbaHostSif+iHostSifNo+2+cnv_len,'\0',data_len-cnv_len);  
    pbaHostSif[ iHostSifNo ]  =  data_len / 256;
    pbaHostSif[ iHostSifNo + 1 ]  =  data_len % 256;
    iUnixSifNo  =  iUnixSifNo+2 + data_len;
    iHostSifNo  =  iHostSifNo+2 + data_len;
  } /* for 'for loop' */
  *piSifLen  =  iHostSifNo ;
  UCP_TRACE_END(0);
}
