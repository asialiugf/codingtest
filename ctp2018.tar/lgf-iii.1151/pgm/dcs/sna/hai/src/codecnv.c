#include <stdio.h>
#include <nl_types.h>
#include <iconv.h>
#include <locale.h>
#include <fcntl.h>
#include <errno.h>
#include "errlog.h"


#define BUFSIZE 3000  /* max string length to be convert is 3000 */

int big5_host(ptr1,ptr2,slen,tab_p)
unsigned char *ptr1;
unsigned char *ptr2;
int slen;
struct table_array *tab_p;
{ 
   size_t inbytes, outbytes;
   nl_catd cd;
   iconv_t convd;
   int ret, conv_retcode;
   char outbuf[BUFSIZE*2];
   char inbuf[BUFSIZE];
   char *inptr, *outptr;
   int iCnvLen;
   
   setlocale(LC_ALL,"");
   cd = catopen("convert.cat",0);
   errno =0;
   if (slen > BUFSIZE ) {
     ErrLog(1000,"convertion length is too long !",RPT_TO_LOG,0,0);
     return(-1);
   }
   if ((convd = iconv_open("IBM-935","IBM-eucCN")) == -1) {
     ErrLog(1000,"GB CONV error",RPT_TO_LOG,0,0);
     return(-1);
   }

   memset(inbuf,0x20,BUFSIZE);
   memcpy(inbuf,ptr1,slen);
/*
   memcpy(&inbuf[slen],0x20,1);
*/
   inptr=inbuf;
   outptr=outbuf;
   outbytes=BUFSIZE*2;
   inbytes  = slen +1 ;
   conv_retcode = iconv(convd, &inptr, &inbytes, &outptr, &outbytes);
   switch(conv_retcode)
   {
   case EILSEQ:
     ErrLog(1000,"GB CONV EILSEQ error",RPT_TO_LOG,0,0);
     iCnvLen=-1;
     break;
   case E2BIG:
     ErrLog(1000,"GB CONV E2BIG error",RPT_TO_LOG,0,0);
     iCnvLen=-1;
     break;
   case EINVAL:
     ErrLog(1000,"GB CONV EINVAL error",RPT_TO_LOG,0,0);
     iCnvLen=-1;
     break;
   case 0:
     iCnvLen = BUFSIZE*2 - outbytes -1;
     memcpy(ptr2,outbuf,iCnvLen);
/*
     ErrLog(100,"after euc-935 DATA",RPT_TO_LOG,ptr2,iCnvLen);
*/
     break;
   }
   return(iCnvLen );

}


int host_big5(ptr1,ptr2,slen,tab_p)
unsigned char *ptr1;
unsigned char *ptr2;
int slen;
struct table_array *tab_p;
{ 
   size_t inbytes, outbytes;
   nl_catd cd;
   iconv_t convd;
   int ret, conv_retcode;
   char outbuf[BUFSIZE*2];
   char inbuf[BUFSIZE*2];
   char *inptr, *outptr;
   int iCnvLen;
   
   if (slen > BUFSIZE ) {
     ErrLog(1000,"convertion length is too long !",RPT_TO_LOG,0,0);
     return(-1);
   }
   setlocale(LC_ALL,"");
   cd = catopen("convert.cat",0);
   errno =0;
   if ((convd = iconv_open("IBM-eucCN","IBM-935")) == -1)
   {
     ErrLog(1000,"GB CONV 935 error",RPT_TO_LOG,0,0);
     return(-1);
   }


   memset(inbuf,0x40,BUFSIZE*2);
   memcpy(inbuf,ptr1,slen);
   inptr=inbuf;
   outptr=outbuf;
   outbytes=BUFSIZE*2;
   inbytes  = slen +1 ;
   conv_retcode = iconv(convd, &inptr, &inbytes, &outptr, &outbytes);
   switch(conv_retcode)
   {
   case EILSEQ:
     iCnvLen=-1;
     ErrLog(1000,"GB CONV EILSEQ error",RPT_TO_LOG,0,0);
     break;
   case E2BIG:
     iCnvLen=-1;
     ErrLog(1000,"GB CONV E2BIG error",RPT_TO_LOG,0,0);
     break;
   case EINVAL:
     iCnvLen=-1;
     ErrLog(1000,"GB CONV EINVAL error",RPT_TO_LOG,0,0);
     break;
   case 0:
     iCnvLen = BUFSIZE*2 - outbytes -1;
     memcpy(ptr2,outbuf,iCnvLen);
/*
     ErrLog(100,"after 935-euc OUT DATA",RPT_TO_LOG,ptr2,iCnvLen);
*/
     break;
   }
   return(iCnvLen );

}



Init_Cvt_Table(tab_p)
struct table_array *tab_p;
{
  return(0);
}
