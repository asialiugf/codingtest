
/* ---------------- define constants ---------------------------------- */
#define MSGQ_CREAT     '1'
#define MSGQ_INIT      '2'
#define MSGQ_READ      '3'
#define MSGQ_WRITE     '4'
#define MSGQ_REMOVE    '5'

#define MSGQ_NORMAL	0
#define MSGQ_EOF_ERROR	-2
#define MSGQ_ARG_ERROR	-3 
#define MSGQ_ERROR	-4
#define MSGQ_TRUN_ERROR	-5
#define MSGQ_TIMEOUT	-6

#define MSGQ_MAX_LEN    16400  /* Update by Dao-Ming 81/06/26 */
#define MSGQ_TMP_FNAME_LEN     9    /*the length of the temporary file's name*/
#define MSGQ_THRESHOLD     80   /*THRESHOLD is 80 % of the total Q. space*/
#define MSGQ_HEAD	sizeof(MsgqHead)

struct MsgBuf {
  long  lType;
  char  caText[MSGQ_MAX_LEN - sizeof(long)]; /* Dao810704 */
};

/* ********************************************************************* */
/* Any message in UCP has twa parts, one is MsgqHead, the other is data. */
/* MsgqHead records the control message pertaining to the messager.      */
/* ********************************************************************* */
struct MsgqHead {
  long lExpType;  /* i.e. the source of the message               */
  int  iKind;     /* what kind of message it convery              */
  int  iLen;      /* the total length of the data part.           */ 
  char caFileName[MSGQ_TMP_FNAME_LEN];
                  /* the file name of the message content, if any */
};

