extern  int  g_iTestCaseId;
extern  char g_caBrCode[10], g_caTmCode[6], g_caTelCode[6];

/*
 *&N& File : tssredo.c
 *&N&
 *&N&
 *&N&    TYPE         NAME                 DESCRIPTION
 *&N& -------------------------------------------------------------------
 *&N&    int       main()
 */

/* -------------------- INCLUDE FILES DECLARATION ------------------ */
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include "errlog.h"
#include "ucp.h"	
#include "lgclgfmt.h"	

#define  LAST_MSG_STATUS   0x80
#define  LG_REC_SIZE       1000
#define	 REVERSE_MASK	   0x04

/*
 *&N& ROUNTINE NAME : SndSifRcvSof()
 *&A& ARGUMENTS: 
 *&A&
 *&R& RETURN VALUE(i);
 *&R& 
 *&R&
 *&D& DESCRIPTION:1.generate a SIF according to the testing case's ID.
 *&D&             2.send the SIF to the TPU to start the transaction.
 *&D&             3.receive the output SOF from the TPU.
 *&D&             4.write the output data to the testing case result file 
 *&D&               according to the SOF receive from the TPU. 
 *&D&
 */

int
SndSifRcvSof(zFp,iCount,pcaRedoName)
FILE *zFp;
int iCount;
char *pcaRedoName;
{
  int iRc;
  int iSifLen;
  int iSofLen;
  unsigned char cSofCtlByte;
  char caSifBuf[MAX_SIF_LEN];
  unsigned char caSofBuf[6400];
  char caTxnMsg[10];
  char cOutFlag;
  int  iFirst;
  unsigned char cFirstSofCtlByte;
  char caTxnId[5];
  char caCodeFlag[3];

  memset(caTxnMsg,0,10);

  iRc = StartRequest();
  if ( iRc < 0 ) {
    return( -1 );
  }
  /* indicate cobol subprogram REDO beginning */
  if ( iCount == 0 ) {
    memset(caCodeFlag,0,3);
    memcpy(caCodeFlag,"02",2);
  } 
  else {
    memset(caCodeFlag,0,3);
    memcpy(caCodeFlag,"00",2);
  }

  memset(caSifBuf,0,MAX_SIF_LEN);
  GENSIF(caSifBuf,pcaRedoName,caCodeFlag);
  /* get sif occurs error */
  if ( memcmp(caCodeFlag,"01",2) == 0 ) {
    return( -2 );
  }
  /* get sif occurs EOF */
  if ( memcmp(caCodeFlag,"03",2) == 0 ) {
    return( -99 );
  }
  /* get sif occurs skipping, when LOG is inserted by txn. which is issued */
  if ( memcmp(caCodeFlag,"04",2) == 0 ) {
    return( -6 );
  }

  iSifLen = 400 ;
  ErrLog(100,"SndSifRcvSof: get SIF:",RPT_TO_LOG,caSifBuf,iSifLen);
  iRc = SendSifToServ(caSifBuf,iSifLen);
  if ( iRc < 0 ) {
    return( -3 );
  }
 
  cOutFlag='1';
  iFirst = 1;
  do {
    iRc = RecSofFromServ(caSofBuf);
    if ( iRc < 0 ) {
      if (iRc == -4 || iRc == -5) { /* DCS_E_TIMEOUT or DCS_E_NETWORK */
        memset(caTxnId, '\0', 5);
        memcpy(caTxnId, caSifBuf + 4, 4);
        sprintf(g_caMsg,"SndSifRcvSof: NewRecSofFromServ rtn code=%d",iRc);
        ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
        printf("Txn: %s Timeout!! Now skip to the next.\n", caTxnId );
        return( -6 );
      }
      else {
        sprintf(g_caMsg,"SndSifRcvSof: NewRecSofFromServ rtn code=%d",iRc);
        ErrLog(100,g_caMsg,RPT_TO_LOG,0,0);
        return( -4 );
      }
    }
    iSofLen = 256 * caSofBuf[SOF_DATA_LEN_OFFSET] + 
              caSofBuf[SOF_DATA_LEN_OFFSET+1];
    cSofCtlByte = caSofBuf[SOF_CTL_CODE_OFFSET];
    ErrLog(100,"SndSifRcvSof: dump SOF DATA=", RPT_TO_LOG,
                                        caSofBuf,SOF_HEAD_LEN+iSofLen);
    if ( iFirst == 1 ) {
      cFirstSofCtlByte = cSofCtlByte;
    }
    if ( (cSofCtlByte == (unsigned char) 0x88) && (cOutFlag == '1') ) { /* AP process error */
      ErrLog(100,"SndSifRcvSof: Txn occur error!", RPT_TO_LOG,&caSofBuf[18],7);
      memcpy(caTxnMsg,&caSofBuf[18],7);
      caTxnMsg[7]='\0';
      cOutFlag='0';
    }
    if( ((cSofCtlByte == (unsigned char) 0x20)||(cSofCtlByte == (unsigned char) 0x22)) && (cOutFlag == '1') ) {
      ErrLog(100,"SndSifRcvSof: Txn has SCR-REINPUT", RPT_TO_LOG,0,0);
      memcpy(caTxnMsg,"REIN",4); /* AP request REINPUT */
      caTxnMsg[4]='\0';
      cOutFlag='0';
    }
    if ( ((cSofCtlByte == (unsigned char) 0x80)||(cSofCtlByte == (unsigned char) 0x82)) && (cOutFlag == '1') ) {
      ErrLog(100,"SndSifRcvSof: Txn is done!", RPT_TO_LOG,&caSofBuf[18],7);
      memcpy(caTxnMsg,"O.K.",4); /* AP process OK */
      caTxnMsg[4]='\0';
      cOutFlag='0';
    }
    iFirst=0;
  } while(!(cSofCtlByte & LAST_MSG_STATUS)||(cSofCtlByte == (unsigned char) 0x82)|| ((cSofCtlByte == (unsigned char) 0xa0)&&(cFirstSofCtlByte & (unsigned char) 0x02)) ); 

  iRc = EndRequest();
  if ( iRc < 0 ) {
    return( -5 );
  }
  fprintf(zFp,"TxnNo:%.4d  TXNID=%.4s  TXN-RETURN-MSG=%.7s\n",
          iCount, caSifBuf+4, caTxnMsg); 

  return( 0 );

}
