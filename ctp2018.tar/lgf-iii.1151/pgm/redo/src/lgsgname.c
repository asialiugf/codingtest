GETLGNAME(char *pcInLogName,char *pcOutLogName)
{
  if ( pcInLogName[0] != '/' ) {
    strcpy(pcOutLogName,(char *)getenv("III_DIR"));
    strcat(pcOutLogName,"/iii/log/");
    strcat(pcOutLogName,pcInLogName);
  }
  else {
    strcpy(pcOutLogName,pcInLogName);
  }
  return;
}

   
