#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include "errlog.h"
/**************************************************************************/
/* Main program of the testing driver. There are 1 arguments:             */
/* Redo Log file name: the log file name needed to redo                   */
/* Output file name:assign the file name of the testing result            */
/**************************************************************************/
/* global variables declaration  ---------------------------------- BEGIN */
/* global variables declaration  ----------------------------------   END */

main(argc,argv) 
int  argc;
char *argv[];
{
  int iLoopCount;
  char caOutputFName[256];
  int  i;  /* loop count */
  FILE *zFp;
  char caSofData[6400];   /* txn output's sof */
  int  iRc;
  char caRedoName[256];
  char caLogName[256];


  if (argc != 3) {
    printf("Usage:tsxredo.x RedoLogName OutputName!\n");
    exit(-1);
  } 
  /*------        prepare arguments      ------*/
  strcpy(caRedoName,argv[1]);
  strcpy(caOutputFName,argv[2]);


  sprintf(caLogName, "%s/iii/log/redo_errlog", getenv("III_DIR") );
  ChgLog(LOG_CHG_MODE,"1");
  ChgLog(LOG_CHG_LOG,caLogName);

  if ( (zFp=fopen(caOutputFName,"w+")) == NULL) {
    printf("output file:%s open error, errno=%d\n",caOutputFName,errno);
    return(-1);
  }

  i=0;
  while( 1 ) {
    iRc=SndSifRcvSof(zFp,i,caRedoName);
    switch(iRc) {
      case  0: 
               printf("Loop Cnt:%d ,Normal REDO        -----> iRc=%d\n",i,iRc);
               break;
      case -1:  
               printf("Loop Cnt:%d ,StartRequest fail  -----> iRc=%d\n",i,iRc);
               break;
      case -2: 
               printf("Loop Cnt:%d ,GenSif fail        -----> iRc=%d\n",i,iRc);
               break;
      case -3: 
               printf("Loop Cnt:%d ,SendSifToServ fail -----> iRc=%d\n",i,iRc);
               break;
      case -4: 
               printf("Loop Cnt:%d ,RecSofFromServ fail-----> iRc=%d\n",i,iRc);
               break;
      case -5: 
               printf("Loop Cnt:%d ,EndRequest fail    -----> iRc=%d\n",i,iRc);
               break;
      case -6:  /* added by Willy */
               printf("Loop Cnt:%d ,GenSif( skip SIF )  -----> iRc=%d\n",i,iRc);
               break;
      case -99: 
               printf("Loop Cnt:%d ,REDO OVER !!!      -----> iRc=%d \n",i,iRc);
               break;
      default: break;
    }

    if ( (iRc == -99 || iRc < 0 ) && (iRc != -6) ) 
      break;
    else
      i++;
  } /* while ( 1 ) */
  fclose(zFp);
}        
 
