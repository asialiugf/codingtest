#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include "errlog.h"
#include "ucp.h"	
#include "lgclgfmt.h"	

void ErrClose(int);
void
GENSIF(char *pcSifBuf,char *pcaRedoName,char *pcaCodeFlag)
{
  void PrintLog();
  int  iRc;
  int  iSifLen;
  static int  s_iLogFd;
  char caLogName[256];
  static long s_lTotNum=0;
  static off_t s_offCurOffset;
  static long s_lCurNum=0;
  static char s_cFirst='n';
  struct stat stStatus;
  struct LogFmtSt stLogData;

  /* setup REDO environment */
  if ( s_cFirst == 'n' ) {
    if( pcaRedoName[0] != '/' ) {
      memset(caLogName,0,80);
      sprintf(caLogName,"%s/iii/log/%s",getenv("III_DIR"),pcaRedoName);
    }
    else {
      strcpy(caLogName,pcaRedoName);
    }
    if ( (s_iLogFd=open(caLogName,O_RDONLY)) < 0 ) {
      sprintf(g_caMsg,"GENSIF: open log file error!");
      ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
      memcpy(pcaCodeFlag,"01",2);
      return;
    }
    if (lseek(s_iLogFd,0,SEEK_SET) < 0) {
        sprintf(g_caMsg,"GENSIF: lseek SEEK_SET error =%d",errno);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        ErrClose(s_iLogFd);
        memcpy(pcaCodeFlag,"01",2);
        return;
    }
    if (fstat(s_iLogFd,&stStatus) < 0) {
        sprintf(g_caMsg," GENSIF: get file status error =%d",errno);
        ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
        ErrClose(s_iLogFd);
        memcpy(pcaCodeFlag,"01",2);
        return;
    }
    s_lTotNum = ((long) (stStatus.st_size / LG_REC_SIZE)) ;
    s_lCurNum = 1;
    s_cFirst = 'y';
  }
  
  if ( s_lCurNum > s_lTotNum ) {
    sprintf(g_caMsg," GENSIF: get SIF over s_lCurNum=%d , s_lTotNum=%d",
            s_lCurNum,s_lTotNum);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    memcpy(pcaCodeFlag,"03",2);
    return;
  }

  s_offCurOffset = (off_t) ((s_lCurNum - 1) * LG_REC_SIZE);
  if ((iRc=lseek(s_iLogFd,s_offCurOffset,SEEK_SET)) < 0) {
    sprintf(g_caMsg,"lseek : GENSIF: lseek SEEK_SET error =%d RRN=%d",
            errno,s_lCurNum);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    ErrClose(s_iLogFd);
    memcpy(pcaCodeFlag,"01",2);
    return;
  }

  memset(&stLogData,0,sizeof(struct LogFmtSt));
  if ((iRc = read(s_iLogFd,&stLogData,LG_REC_SIZE)) != LG_REC_SIZE) {
    sprintf(g_caMsg,"GENSIF: Read log data Error =%d RRN=%d",
            errno,s_lCurNum);
    ErrLog(1000,g_caMsg,RPT_TO_LOG,0,0);
    ErrClose(s_iLogFd);
    memcpy(pcaCodeFlag,"01",2);
    return;
  }

/* added for print log content x/
  ErrLog(100,"GENSIF: dump each log=",RPT_TO_LOG,&stLogData,1000);
  PrintLog( &stLogData );
/x end */

  if (stLogData.caApRqt[0] == '1') {
    /* skip this SIF */
    ErrLog(100,"GENSIF: skip this SIF",RPT_TO_LOG,0,0);
    s_lCurNum++; 
    memcpy(pcaCodeFlag,"04",2);
    return;
  }
  else { /* get this SIF */
    memcpy(pcSifBuf,stLogData.caSifArea,450);
    /* Added by Willy 1995/07/01 */
    memset(pcSifBuf + 28, 0, 20);
    /* End Addition */
    s_lCurNum++; 
    memcpy(pcaCodeFlag,"00",2);
    return;
  }

}


void
ErrClose(iLogFd)
int iLogFd;
{
  close(iLogFd);
}
/******************************* test ******************/

void
PrintLog(pstLogFmt)
LOGFMT *pstLogFmt;
{
   char Buf[80];
   char cDump;
   sprintf(Buf,"caReverse->%.2s               caCurrLogRrn->%.*s",
                      pstLogFmt->caReverse,LG_RRN_SIZE,pstLogFmt->caCurrLogRrn);
   printf("%s \n",Buf);
   sprintf(Buf,"caRecId->%.1s                caTastNo->%.4s",
                                        pstLogFmt->caRecId,pstLogFmt->caTaskNo);
   printf("%s \n",Buf);
   sprintf(Buf,"caRecCnt->%.4s               caSifLen->%.4s",
                                       pstLogFmt->caRecCnt,pstLogFmt->caSifLen);
   printf("%s \n",Buf);
   sprintf(Buf,"caSuncPointCd->%.1s            caNextAvBtefRrn->%.*s",
            pstLogFmt->caSyncPointCd,LG_RRN_SIZE,pstLogFmt->caNextAvBtefRrn);
   printf("%s \n",Buf);
   sprintf(Buf,"caLastLogRecRrb->%.*s          caSystemTxnSeqNo=>%.10s",
           LG_RRN_SIZE,pstLogFmt->caLastLogRecRrn,pstLogFmt->caSystemTxnSeqNo);
   printf("%s \n",Buf);
   sprintf(Buf,"caAccTxnSeqNo->%.*s            caNonAccTxnSeqNo->%.*s",
                                   LG_TXN_SEQ_SIZE,pstLogFmt->caAccTxnSeqNo,
                                  LG_TXN_SEQ_SIZE,pstLogFmt->caNonAccTxnSeqNo);
   printf("%s \n",Buf);
   sprintf(Buf,"caBatchTxnSeqNo->%.*s           caTxnId->%.*s",
                                   LG_TXN_SEQ_SIZE,pstLogFmt->caBatchTxnSeqNo,
                                   LG_MAX_TXN_ID_SIZE,pstLogFmt->caTxnId);
   printf("%s \n",Buf);
   sprintf(Buf,"caBrCode->%.*s                   caTmCode->%.*s",
                                        LG_MAX_BR_CODE_SIZE,pstLogFmt->caBrCode,
                                       LG_MAX_TM_CODE_SIZE,pstLogFmt->caTmCode);
   printf("%s \n",Buf);
   sprintf(Buf,"caTellerCd->%.4s                  caTxnDate->%.8s",
                                    pstLogFmt->caTellerCd,pstLogFmt->caTxnDate);
   printf("%s \n",Buf);
   sprintf(Buf,"caNextDate->%.8s                  caNextDayCnt->%.1s",
                                 pstLogFmt->caNextDate,pstLogFmt->caNextDayCnt);
   printf("%s \n",Buf);
   sprintf(Buf,"caTxnTime->%.6s                   caOriginBrStatus ->%.1s",
                              pstLogFmt->caTxnTime,pstLogFmt->caOriginBrStatus);
   printf("%s \n",Buf);
   sprintf(Buf,"caTmType->%.1s                     caSupKeyStatus->%.1s",
                                 pstLogFmt->caTmType,pstLogFmt->caSupKeyStatus);
   printf("%s \n",Buf);
   sprintf(Buf,"caBookStatus->%.1s                  caTxnStatus->%.1s",
                                pstLogFmt->caBookStatus,pstLogFmt->caTxnStatus);
   printf("%s \n",Buf);
   sprintf(Buf,"caApRqt->%.1s                       caLineReentryStatus->%.1s",
                             pstLogFmt->caApRqt,pstLogFmt->caLineReentryStatus);
   printf("%s \n",Buf);
   sprintf(Buf,"caTxnReturnCd->%.1s                   caFiscSwitch->%.1s",
                              pstLogFmt->caTxnReturnCd,pstLogFmt->caFiscSwitch);
   printf("%s \n",Buf);
   sprintf(Buf,"caFiscApReturnCd->%.1s                  caOverTime->%.1s",
                             pstLogFmt->caFiscApReturnCd,pstLogFmt->caOverTime);
   printf("%s \n\n\n",Buf);

   fflush(stdin);
/*   cDump = (char ) getchar(); */
}
