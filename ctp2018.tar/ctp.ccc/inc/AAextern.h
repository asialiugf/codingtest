// USER_API参数
extern CThostFtdcMdApi* pUserApi;
// 配置参数 
extern char FRONT_ADDR[];
extern TThostFtdcBrokerIDType   BROKER_ID;
extern TThostFtdcInvestorIDType INVESTOR_ID;
extern TThostFtdcPasswordType   PASSWORD;
// extern char* ppInstrumentID[];
extern char* ppFutureID[];
extern int iInstrumentID;
extern int iRequestID;
