#include "MdSpi.h"
#include <iostream>
#include <string.h>
#include <AAextern.h>

using namespace std;


// USER_API����
// extern CThostFtdcMdApi* pUserApi;

// ���ò���
// extern char FRONT_ADDR[];		
// extern TThostFtdcBrokerIDType	BROKER_ID;
// extern TThostFtdcInvestorIDType INVESTOR_ID;
// extern TThostFtdcPasswordType	PASSWORD;
// extern char* ppInstrumentID[];	
// extern int iInstrumentID;

// ������
// extern int iRequestID;

void CMdSpi::OnRspError(CThostFtdcRspInfoField *pRspInfo,
		int nRequestID, bool bIsLast)
{
	cerr << "--->>> "<< "OnRspError" << endl;
	IsErrorRspInfo(pRspInfo);
}

void CMdSpi::OnFrontDisconnected(int nReason)
{
	cerr << "--->>> " << "OnFrontDisconnected" << endl;
	cerr << "--->>> Reason = " << nReason << endl;
}
		
void CMdSpi::OnHeartBeatWarning(int nTimeLapse)
{
	cerr << "--->>> " << "OnHeartBeatWarning" << endl;
	cerr << "--->>> nTimerLapse = " << nTimeLapse << endl;
}

void CMdSpi::OnFrontConnected()
{
	cerr << "--->>> " << "OnFrontConnected 00000000000000000" << endl;
	///�û���¼����
	ReqUserLogin();
}

void CMdSpi::ReqUserLogin()
{
	CThostFtdcReqUserLoginField req;
	memset(&req, 0, sizeof(req));
	strcpy(req.BrokerID, BROKER_ID);
	strcpy(req.UserID, INVESTOR_ID);
	strcpy(req.Password, PASSWORD);
	int iResult = pUserApi->ReqUserLogin(&req, ++iRequestID);
	cerr << "--->>> send login request : " << ((iResult == 0) ? "ok!" : "failure!") << endl;
    cerr << "-------------------------- iRequestID" << iRequestID << endl;
}

void CMdSpi::OnRspUserLogin(CThostFtdcRspUserLoginField *pRspUserLogin,
		CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	cerr << "--->>> " << "OnRspUserLogin" << endl;
	if (bIsLast && !IsErrorRspInfo(pRspInfo))
	{
		///��ȡ��ǰ������
		cerr << "--->>> get date : = " << pUserApi->GetTradingDay() << endl;
		// ����������
		SubscribeMarketData();	
	}
}

void CMdSpi::SubscribeMarketData()
{
	int iResult = pUserApi->SubscribeMarketData(ppFutureID, iInstrumentID);
	cerr << "--->>> send subscribe request: " << ((iResult == 0) ? "ok!" : "failure!") << endl;
}

void CMdSpi::OnRspSubMarketData(CThostFtdcSpecificInstrumentField *pSpecificInstrument, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	cerr << "OnRspSubMarketData !!!" << endl;
}

void CMdSpi::OnRspUnSubMarketData(CThostFtdcSpecificInstrumentField *pSpecificInstrument, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	cerr << "OnRspUnSubMarketData" << endl;
}

void CMdSpi::OnRtnDepthMarketData(CThostFtdcDepthMarketDataField *pDepthMarketData)
{
	cerr << "OnRtnDepthMarketData !!!!!" << endl;
    cerr << pDepthMarketData->TradingDay << "  " << endl;
    cerr << pDepthMarketData->InstrumentID << "  " << endl;
    cerr <<"OpenPrice:" << pDepthMarketData->OpenPrice << "  " << endl;
    cerr <<" Volume:" << pDepthMarketData-> Volume << "  " << endl;
    cerr <<"BidPrice1:" << pDepthMarketData->BidPrice1 << "  " << pDepthMarketData->BidVolume1 << endl;
    cerr <<"AskPrice1:" << pDepthMarketData->AskPrice1 << "  " << pDepthMarketData->AskVolume1 << endl;
    cerr <<"UpdateTime:" << pDepthMarketData->UpdateTime << "  " << endl;
    cerr <<"UpdateMillisec:" << pDepthMarketData->UpdateMillisec << "  " << endl;
    cerr << endl;
}

void OnRspQryDepthMarketData(CThostFtdcDepthMarketDataField *pDepthMarketData, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	cerr << "OnRspQryDepthMarketData" << endl;
}
bool CMdSpi::IsErrorRspInfo(CThostFtdcRspInfoField *pRspInfo)
{
	// ���ErrorID != 0, ˵���յ��˴������Ӧ
	bool bResult = ((pRspInfo) && (pRspInfo->ErrorID != 0));
	if (bResult)
		cerr << "--->>> ErrorID=" << pRspInfo->ErrorID << ", ErrorMsg=" << pRspInfo->ErrorMsg << endl;
	return bResult;
}
